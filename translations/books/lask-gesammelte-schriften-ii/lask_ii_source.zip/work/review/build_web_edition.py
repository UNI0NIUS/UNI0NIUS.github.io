"""Volume II data for the existing bilingual reader, including nested notes."""
import collections,hashlib,json,re
from pathlib import Path
from note_display import note_display
R=Path(__file__).resolve().parent;O=R.parent.parent/'output/reviewed/webdata';O.mkdir(parents=True,exist_ok=True)
D=json.loads((R/'reading_groups.json').read_text(encoding='utf-8'))
U={u['id']:u for u in map(json.loads,(R/'translation_units.jsonl').read_text(encoding='utf-8-sig').splitlines())}
U.update({u['id']:u for u in D['extra_units']})
S={u['id']:u for u in map(json.loads,(R.parent/'source/source_units.jsonl').read_text(encoding='utf-8-sig').splitlines())}
assert D['canonical_sha256']==hashlib.sha256((R/'translation_units.jsonl').read_bytes()).hexdigest()
base='translations/books/lask-gesammelte-schriften-ii/'
sections=collections.OrderedDict();refs=collections.Counter();components=[]
owners={c['unit_id']:g['section'] for g in D['groups'] for c in g['components']}
def tokens(s,uid,language):
 out=[]
 for i,p in enumerate(re.split(r'(⟦p\.[^⟧]+⟧|\n\n|\n)',s)):
  if not p:continue
  if p.startswith('⟦p.'):out.append(dict(type='page',page=p[3:-1],id=f'{language}-{uid}-page-{i}'))
  elif p=='\n\n':out.append(dict(type='break'))
  elif p=='\n':out.append(dict(type='linebreak'))
  else:out.append(p)
 return out
def runs(values,uid,key,track=True):
 out=[]
 for i,v in enumerate(values):
  if v['type']=='text':out+=tokens(v['text'],uid+f'-r{i}',key)
  else:
   # The appended original repeats the translated note's reference. Preserve
   # its printed superscript without creating a second HTML return anchor.
   out.append(dict(type='note',id=v['note_id'],label=str(v['original_number'])) if track else dict(type='sup',children=[str(v['original_number'])]))
   if track:refs[(key,v['note_id'])]+=1
 return out
for g in D['groups']:
 sec=sections.setdefault(g['section'],dict(id=g['section'],body=[],notes={},sourceLanguage='de',sourceLanguageLabel='Deutsch'))
 row=dict(id=g['id'],type='heading' if g['kind']=='heading' else 'paragraph',page=U[g['id']].get('page_label') or '')
 for lang,key in [('zh','zh'),('de','en')]:
  row[key]=[]
  for i,c in enumerate(g['components']):
   if lang=='zh':components.append(c['unit_id'])
   if i and lang=='de':row[key].append(' ')
   row[key].append(dict(type='anchor',id=key+'-'+c['unit_id']))
   row[key]+=runs(c[lang+'_runs'],c['unit_id'],key)
 sec['body'].append(row)
for n in D['notes']:
 page,_,_=note_display(n,U);sec=sections[owners[n['body_unit_id']]]
 source_pages=[S[s].get('pdf_page') for s in U[n['note_id']]['source_unit_ids'] if S[s].get('pdf_page')]
 sec['notes'][n['note_id']]=dict(number=str(n['original_number']),sourcePdfPage=min(source_pages),sourcePrintedPage=page,
  zh=['[原书第'+page+'页] ']+runs(n['zh_runs'],n['note_id'],'zh')+[dict(type='break'),'原文：']+runs(n['de_runs'],n['note_id']+'-original','zh',False),
  en=['[S. '+page+'] ']+runs(n['de_runs'],n['note_id'],'en'))
meta=dict(id='lask-gesammelte-schriften-ii',title='拉斯克文集：第二卷',originalTitle='Gesammelte Schriften. II',
 tags=['哲学 Philosophy'],author='Emil Lask',authorZh='埃米尔·拉斯克',language='zh-CN',languagePair='Deutsch / 中文',
 structured=True,bilingual=True,views=['zh','en','parallel'],sourceLanguage='de',sourceLanguageLabel='Deutsch',
 editionNotice='据1923年图宾根J. C. B. Mohr版校订。原页码随文保留，原注保留页内编号；中文原注附德文原文。',chapters=[],downloads=[])
special={'front-matter':('书前材料','Vorsatz'),'original-toc':('原书目录','Originales Inhaltsverzeichnis'),'back-matter':('原书卷末书目广告','Verlagsanzeige')}
for sec in sections.values():
 first=next((row for row in sec['body'] if row['type']=='heading'),sec['body'][0])
 def title(key):return ' '.join(t for t in first[key] if isinstance(t,str)).replace('\n',' ')
 sec['title'],sec['originalTitle']=special.get(sec['id'],(title('zh'),title('en')))
 (O/(sec['id']+'.json')).write_text(json.dumps(sec,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 meta['chapters'].append(dict(id=sec['id'],title=sec['title'],originalTitle=sec['originalTitle'],dataUrl=base+sec['id']+'.json'))
toc=json.loads((R/'original_toc.json').read_text(encoding='utf-8'))['entries']
parents={U[e['unit_id']]['section']:U[e['parent_unit_id']]['section'] if e['parent_unit_id'] else None for e in toc}
for c in meta['chapters']:
 if parents.get(c['id']):c['parentId']=parents[c['id']]
assert len(refs)==882 and set(refs.values())=={1}
assert sum(len(s['notes']) for s in sections.values())==441
assert len(components)==len(set(components))==D['validation']['body_components']+len(D['extra_units'])
for sec in sections.values():
 for values in [row[key] for row in sec['body'] for key in ['zh','en']]+[note[key] for note in sec['notes'].values() for key in ['zh','en']]:
  for v in values:
   if isinstance(v,dict) and v['type']=='note':assert v['id'] in sec['notes']
(O/'book-metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(R/'web_export_check.json').write_text(json.dumps(dict(canonical_sha256=D['canonical_sha256'],sections=len(sections),components=len(components),notes=441,references_per_language=441,status='local_export_passed_browser_and_online_pending',files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in O.glob('*.json')}),indent=2)+'\n',encoding='utf-8')
print('Exported',len(sections),'sections, 441 notes; local references validated')
