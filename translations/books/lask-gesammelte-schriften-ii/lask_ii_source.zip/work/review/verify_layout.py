"""Check all page bounds/links and render representative pages for visual review."""
import hashlib,json
from pathlib import Path
import pymupdf
R=Path(__file__).resolve().parent;O=R.parent.parent/'output/reviewed'
result={}
for mode in ['zh','de','bilingual']:
 path=O/f'lask_ii_{mode}.pdf';doc=pymupdf.open(path);outside=[];bad=[]
 for i,page in enumerate(doc):
  for block in page.get_text('dict')['blocks']:
   for line in block.get('lines',[]):
    for span in line['spans']:
     x0,y0,x1,y1=span['bbox']
     if x0<-.5 or x1>page.rect.width+.5 or y0<-.5 or y1>page.rect.height+.5:
      outside.append({'page':i+1,'text':span['text'],'bbox':span['bbox']})
  for link in page.get_links():
   if link['kind']==pymupdf.LINK_GOTO and not 0<=link.get('page',-1)<len(doc):bad.append({'page':i+1,'link':str(link)})
 assert not outside and not bad,(mode,outside,bad)
 assert len(doc.get_toc())==46
 names=doc.resolve_names()
 pages=sorted(set([4,5,names['note-p62-n*']['page'],names['note-p426-n*']['page'],len(doc)-1]))
 images=[]
 for i in pages:
  image=R/f'ocr/final_layout_{mode}_{i+1}.png';doc[i].get_pixmap(matrix=pymupdf.Matrix(1.15,1.15)).save(image)
  images.append({'page':i+1,'path':str(image.resolve()),'sha256':hashlib.sha256(image.read_bytes()).hexdigest(),'viewed':False})
 result[mode]={'pdf_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'pages':len(doc),'bookmark_count':46,'outside_page_spans':outside,'invalid_internal_links':bad,'images':images}
 print(mode,len(doc),'pages; all bounds/links passed; visual pages',pages)
(R/'final_pdf_geometry_check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
