"""Lossless reading projection, with explicit nested-note ownership."""
import collections, hashlib, json, re
from pathlib import Path
R=Path(__file__).resolve().parent
def load(name): return json.loads((R/name).read_text(encoding='utf-8-sig'))
def digest(name): return hashlib.sha256((R/name).read_bytes()).hexdigest()
rows=list(map(json.loads,(R/'translation_units.jsonl').read_text(encoding='utf-8-sig').splitlines()))
assert load('final_review_acceptance.json')['canonical_sha256']==digest('translation_units.jsonl')
units={u['id']:u for u in rows}
notes={u['id']:u for u in rows if u['kind']=='note'}
callers={}
for u in rows:
 for nid in u.get('note_refs',[]):
  assert nid in notes and nid not in callers,(u['id'],nid)
  callers[nid]=u['id']
assert set(callers)==set(notes)
def root(nid):
 seen=set()
 while nid in notes:
  assert nid not in seen,nid
  seen.add(nid);nid=callers[nid]
 return nid
def runs(u,field):
 out=[];refs=iter(u.get('note_refs',[]));text=u[field];last=0
 for m in re.finditer(r'⟦n\.([^⟧]+)⟧',text):
  if m.start()>last:out.append({'type':'text','text':text[last:m.start()]})
  nid=next(refs);number=str(notes[nid]['marker']);assert number==m[1],(u['id'],nid)
  out.append({'type':'note_ref','note_id':nid,'original_number':number});last=m.end()
 if last<len(text):out.append({'type':'text','text':text[last:]})
 assert next(refs,None) is None
 return out
groups=[];byid={};projected_notes=[]
for u in rows:
 c={'unit_id':u['id'],'kind':u['kind'],'section':u['section'],
    'de_runs':runs(u,'source_text'),'zh_runs':runs(u,'translation')}
 if u['kind']=='note':
  projected_notes.append(dict(c,note_id=u['id'],original_number=u['marker'],
    body_unit_id=root(u['id']),parent_unit_id=callers[u['id']],source_text=u['source_text'],translation=u['translation']))
  continue
 parent=u.get('continuation_of')
 if parent:
  assert parent in byid and byid[parent] is groups[-1],(u['id'],parent)
  assert byid[parent]['section']==u['section']
  g=byid[parent];g['components'].append(c)
 else:
  g={'id':u['id'],'kind':u['kind'],'section':u['section'],'components':[c]};groups.append(g)
 byid[u['id']]=g
# Preserve original TOC separately from the generated reading-edition TOC.
toc=load('original_toc.json')['entries']
toc_text={}
for lang,key in [('de','title_source'),('zh','title_translation')]:
 lines=['Originales Inhaltsverzeichnis' if lang=='de' else '原书目录']
 for e in toc:
  override='original_toc_title' if lang=='de' else 'original_toc_translation'
  title=re.sub(r'⟦[^⟧]+⟧','',e.get(override,e[key]))
  lines.append('  '*e['level']+title+' …… '+str(e['original_printed_pages']))
 toc_text[lang]='\n'.join(lines)
extras=[{'id':'original-toc-transcript','kind':'front_matter','section':'original-toc','source_text':'Originales Inhaltsverzeichnis','translation':'原书目录','page_label':None}]
for index,e in enumerate(toc,1):
 de=re.sub(r'⟦[^⟧]+⟧','',e.get('original_toc_title',e['title_source']))
 zh=re.sub(r'⟦[^⟧]+⟧','',e.get('original_toc_translation',e['title_translation']))
 suffix=' …… '+str(e['original_printed_pages'])
 extras.append({'id':f'original-toc-entry-{index:02}','kind':'front_matter','section':'original-toc','source_text':de+suffix,'translation':zh+suffix,'page_label':None})
for m in load('supplemental_materials.json')['materials']:
 extras.append(dict(m,section='back-matter',page_label=None,kind='publisher_advertisement'))
toc_insert=2
for u in extras:
 units[u['id']]=u
 c={'unit_id':u['id'],'kind':u['kind'],'section':u['section'],'de_runs':[{'type':'text','text':u['source_text']}],'zh_runs':[{'type':'text','text':u['translation']}]}
 g={'id':u['id'],'kind':u['kind'],'section':u['section'],'components':[c]}
 if u['section']=='original-toc':groups.insert(toc_insert,g);toc_insert+=1
 else:groups.append(g)
for lang in ['de','zh']:
 refs=[run['note_id'] for g in groups for c in g['components'] for run in c[lang+'_runs'] if run['type']=='note_ref']
 refs += [run['note_id'] for n in projected_notes for run in n[lang+'_runs'] if run['type']=='note_ref']
 assert len(refs)==len(set(refs))==len(notes)
out={'canonical_sha256':digest('translation_units.jsonl'),'supplemental_sha256':digest('supplemental_materials.json'),
     'original_toc_sha256':digest('original_toc.json'),'groups':groups,'notes':projected_notes,'extra_units':extras,
     'validation':{'canonical_units':len(rows),'body_components':len(rows)-len(notes),'notes':len(notes),'nested_notes':sum(callers[n] in notes for n in notes),'source_text_changed':False}}
(R/'reading_groups.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(out['validation'])
