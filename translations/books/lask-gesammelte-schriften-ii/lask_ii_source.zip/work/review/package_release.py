"""Bundle reproducible Volume II sources and version-bound checks."""
import hashlib,json,zipfile
from pathlib import Path
R=Path(__file__).resolve().parent;B=R.parent.parent;O=B/'output/reviewed'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
names=['translation_units.jsonl','reading_groups.json','original_toc.json','supplemental_materials.json',
 'final_review_acceptance.json','frontmatter_coverage.json','source_exclusions.json','source_page_exclusions.json',
 'source_line_decisions.json','short_line_decisions.json','pdf_text_readback_check.json','final_pdf_geometry_check.json',
 'final_visual_check.json','markdown_export_check.json','web_export_check.json','edition_build_manifest.json',
 'build_reading_data.py','build_reading_editions.py','build_markdown_editions.py','build_web_edition.py',
 'note_display.py','check_pdf_text.py','verify_layout.py','package_release.py']
files=[R/n for n in names]+[R.parent/'source/source_units.jsonl']
files+=sorted(R.glob('review_plan_*.json'))+sorted(R.glob('revisions_*.json'))
files+=sorted(O.glob('lask_ii_*.tex'))+sorted(O.glob('lask_ii_*.md'))+sorted((O/'webdata').glob('*.json'))
readme='''# Gesammelte Schriften. II 校订阅读成果源码

底本：Emil Lask, Gesammelte Schriften, II. Band, herausgegeben von Eugen
Herrigel, Tübingen: J. C. B. Mohr (Paul Siebeck), 1923。

规范稿包含德文、中文、稳定单元ID、原印页码及原注关系。原目录和原书卷末广告
单独保存并纳入所有阅读成果。保留原书疑似印误，不以现代拼写或推测静默替换。
原始扫描PDF及定向OCR原图留存工作区，不随本包分发；修订计划保留定位与理由。

## 复现

保留目录结构，使用Python 3执行：

    python work/review/build_reading_data.py
    python work/review/build_reading_editions.py --compile
    python work/review/build_markdown_editions.py
    python work/review/build_web_edition.py
    python work/review/check_pdf_text.py

PDF需要XeLaTeX、fontspec、xeCJK、paracol等TeX包及Times New Roman、SimSun字体；
PDF回读需要PyMuPDF。字体不随包分发，更换字体后须重新验收分页与版式。
中文、德文和逐段对照PDF与两种Markdown、网页JSON都来自同一reading_groups数据。
中文原注附德文原文，原注保留底本页内编号，嵌套注释有独立链接。

修改规范稿后须重新校对并更新验收记录，不应绕过生成器的版本断言。
本包的文本校对、排版检查与线上发布是不同状态，报告记载其实际验证范围。
'''
(O/'README-source.md').write_text(readme,encoding='utf-8');files.append(O/'README-source.md')
assert all(p.is_file() for p in files)
manifest={p.relative_to(B).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in files}
target=O/'lask_ii_source.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files:z.write(p,p.relative_to(B).as_posix())
 z.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2))
with zipfile.ZipFile(target) as z:
 assert z.testzip() is None
 for name,entry in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==entry['sha256']
(R/'source_package_check.json').write_text(json.dumps({'canonical_sha256':sha(R/'translation_units.jsonl'),'file':target.name,'sha256':sha(target),'bytes':target.stat().st_size,'members':len(manifest)+1,'status':'all_member_hashes_verified'},indent=2)+'\n',encoding='utf-8')
print('Validated',target.name,len(manifest)+1,'members')
