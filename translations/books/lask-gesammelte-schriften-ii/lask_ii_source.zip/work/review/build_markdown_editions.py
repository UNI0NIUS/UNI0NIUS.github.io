"""Export the same grouped text and recursive original notes as the PDFs."""
import hashlib,json,re
from pathlib import Path
from note_display import note_display
R=Path(__file__).resolve().parent
O=R.parent.parent/'output/reviewed';O.mkdir(parents=True,exist_ok=True)
D=json.loads((R/'reading_groups.json').read_text(encoding='utf-8'))
U={u['id']:u for u in map(json.loads,(R/'translation_units.jsonl').read_text(encoding='utf-8-sig').splitlines())}
U.update({u['id']:u for u in D['extra_units']})
assert D['canonical_sha256']==hashlib.sha256((R/'translation_units.jsonl').read_bytes()).hexdigest()
levels={e['unit_id']:e['level'] for e in json.loads((R/'original_toc.json').read_text(encoding='utf-8'))['entries']}
report={}
for lang in ['zh','de']:
    out=['# 文集第二卷 / Gesammelte Schriften. II',
         'Emil Lask · Herausgegeben von Eugen Herrigel · Tübingen: J. C. B. Mohr, 1923.',
         '校订版。原页码以 ⟦p.…⟧ 标记；原注保留页内编号，中文原注附德文原文。']
    refs=[];components=[];lastpage=None
    def render(values,track=True):
        result=[]
        for v in values:
            if v['type']=='text':result.append(v['text'])
            else:
                if track:refs.append(v['note_id'])
                result.append('[^'+v['note_id']+']')
        return ''.join(result)
    for g in D['groups']:
        parts=[]
        for i,c in enumerate(g['components']):
            components.append(c['unit_id'])
            parts.append('<a id="'+lang+'-'+c['unit_id']+'"></a>')
            if i and lang=='de':parts.append(' ')
            value=render(c[lang+'_runs']);page=U[c['unit_id']].get('page_label')
            if page and page!=lastpage and not value.startswith('⟦p.'+str(page)+'⟧'):
                value='⟦p.'+str(page)+'⟧'+value
            marks=re.findall(r'⟦p\.([^⟧]+)⟧',value)
            if marks:lastpage=marks[-1]
            parts.append(value)
        value=''.join(parts)
        if g['kind']=='heading':value='#'*min(levels.get(g['id'],3)+2,6)+' '+value.replace('\n',' ')
        if g['section']=='back-matter':out.append('## 原书卷末书目广告 / Verlagsanzeige')
        out.append(value)
    out.append('## 原注 / Anmerkungen')
    for n in D['notes']:
        page,_,_=note_display(n,U)
        label=('[原书第'+page+'页，注'+str(n['original_number'])+'] ') if lang=='zh' else ('[S. '+page+', Anm. '+str(n['original_number'])+'] ')
        body=label+render(n[lang+'_runs'])
        if lang=='zh':body+='\n\n原文：'+render(n['de_runs'],False)
        out.append('[^'+n['note_id']+']: '+body.replace('\n','\n    '))
    result='\n\n'.join(out)+'\n'
    assert len(refs)==len(set(refs))==len(D['notes'])==441
    assert set(refs)=={n['note_id'] for n in D['notes']}
    assert len(components)==len(set(components))==D['validation']['body_components']+len(D['extra_units'])
    assert '⟦n.' not in result
    path=O/f'lask_ii_{lang}.md';path.write_text(result,encoding='utf-8')
    report[lang]={'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'components':len(components),'notes':len(refs)}
(R/'markdown_export_check.json').write_text(json.dumps({'canonical_sha256':D['canonical_sha256'],'editions':report},indent=2)+'\n',encoding='utf-8')
print('Chinese/German Markdown exported:',len(components),'components and 441 notes each')
