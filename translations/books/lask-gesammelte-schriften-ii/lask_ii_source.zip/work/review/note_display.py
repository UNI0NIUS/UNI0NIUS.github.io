"""Volume II note labels are already separate from canonical note text."""
def note_display(note, units):
    unit=units[note['note_id']]
    pages=unit['printed_pages']
    assert pages, note['note_id']
    return str(pages[0]), note['source_text'], ''
