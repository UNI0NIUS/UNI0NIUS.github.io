# Gesammelte Schriften. II 校订阅读成果源码

底本：Emil Lask, Gesammelte Schriften, II. Band, herausgegeben von Eugen
Herrigel, Tübingen: J. C. B. Mohr (Paul Siebeck), 1923。

规范稿包含德文、中文、稳定单元ID、原印页码及原注关系。原目录和原书卷末广告
单独保存并纳入所有阅读成果。保留原书疑似印误，不以现代拼写或推测静默替换。
原始扫描PDF及定向OCR原图留存工作区，不随本包分发；修订计划保留定位与理由。

## 复现

保留目录结构，使用Python 3执行：

    python work/review/build_reading_data.py
    python work/review/build_reading_editions.py --compile
    python work/review/build_markdown_editions.py
    python work/review/build_web_edition.py
    python work/review/check_pdf_text.py

PDF需要XeLaTeX、fontspec、xeCJK、paracol等TeX包及Times New Roman、SimSun字体；
PDF回读需要PyMuPDF。字体不随包分发，更换字体后须重新验收分页与版式。
中文、德文和逐段对照PDF与两种Markdown、网页JSON都来自同一reading_groups数据。
中文原注附德文原文，原注保留底本页内编号，嵌套注释有独立链接。

修改规范稿后须重新校对并更新验收记录，不应绕过生成器的版本断言。
本包的文本校对、排版检查与线上发布是不同状态，报告记载其实际验证范围。
