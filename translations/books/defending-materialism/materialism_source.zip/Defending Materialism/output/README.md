# 《捍卫唯物主义》阅读版源码

目录结构保留工作区相对路径。主要内容在`Defending Materialism/output`，校对单元在`Defending Materialism/work/packets`，脚本在`tools`。

TeX源使用XeLaTeX，字体为Times New Roman和SimSun。进入output目录，分别对`materialism_bilingual.tex`和`materialism_en.tex`编译两遍。图片位于相邻assets目录。其他系统需要安装对应字体，或自行调整字体配置。

Python生成流程：

1. 如重新生成某批校对数据，运行相应`review_materialism_*.py`。不要用旧批次生成器覆盖后续全局编辑后直接发布。
2. 运行`tools/finalize_materialism_editorial.py`恢复最后一轮统一编辑。
3. 运行`tools/audit_materialism_coverage.py`核对全书源行。
4. 运行`tools/render_materialism.py --full-text`生成TeX和中文Markdown。`--compile`调用本工作站配置的XeLaTeX路径；异机应调整路径或手动编译。
5. `tools/export_materialism_site.py`面向既有个人主页阅读器导出JSON，不会自行发布或注册书目。

网站公式使用KaTeX 0.16.22，依赖采用MIT许可；完整网站阅读器及依赖不包含在本书源码包中。原书封面、图像和正文版权归原权利人所有，保留出版信息。

`*_text_audit.json`是各次工作检查点；其`layout: pending`及`full_book_complete: false`描述当时批次状态，不代表整书后续审核结论。请同时查看全书覆盖审计、图片审计、网页检查与最终交付记录。校对来源与限制见`review.md`。
