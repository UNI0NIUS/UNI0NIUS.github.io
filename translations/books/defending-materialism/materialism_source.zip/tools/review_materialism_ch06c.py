from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch06-{len(rows)+33:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(138,5),[],'figure',text='图6.3 真正的力的分割装置示意图。两侧重物的平衡力与中央重物的力同时作用。作者绘图。',reason='恢复遗漏原图及图注。')
rows[-1].update(image='assets/figure-6-3.png',source_image={'pdf_page':138,'block':4,'xref':849})
add(rr(138,1),rr(69,24,27),text='马赫声称库仑目睹了力的分割，这是一种歪曲。库仑实际注意到的是某种能够产生力的东西被分割了。马赫反对认识物自体的康德主义偏见，促使他拒绝这一观念，并错误地声称观察到的是力的分割。在力学中，力是加速度的直接动因。因此，能够积聚在髓球上或莱顿瓶内的并不是力本身，而是有潜能产生力的某种物质。',reason='pith balls为髓球；保留作者从潜在致力之物到物质的论述顺序。')
add(rr(138,2),rr(69,28,30))
en=extract(EN,rr(138,3)+rr(139,1),True).replace('h h h 0 2 3',r'$h_0>h_2+h_3$').replace('voltage[[2]]',r'voltage$^2$')
add(rr(138,3)+rr(139,1),rr(69,31)+rr(70,0,5),english=en,text=r'若不测量$h_1$，即把一半电荷转移到电容器C2时释放的热量，我们得到的实验就类似于库仑实验，但会发现$h_0>h_2+h_3$。这样看来，电似乎就不守恒了。他想要在电荷的电压与假想热质的温度之间建立类比，但所用的思想实验，是使电能（电荷×电压平方）通过电阻放电转化为热。在图6.4中，他把电阻R1上损失的热量比作卡诺热机输出的功；从热力学来看，这个类比荒谬不通。马赫把有用能经电阻损失为热，与热转化为有用能相提并论。但热力学第二定律告诉我们，这两种转化并不对称。电能可以以100%的效率转化为热，而热转化为有用能，无论是电能还是机械功，效率总是低于100%。',reason='恢复不等式；原文voltage的上标2是平方而非注号，须保留并校注；旧译转化方向句法混乱。')
rows[-1]['editor_note']='底本电能括号中写作charge × voltage²，量纲可疑；此处保留其平方标记，未静默改为电荷×电压。'
add(rr(139,7),[],'figure',text=r'图6.4 用现代电路图表示马赫所描述的莱顿瓶实验。步骤：（1）闭合开关S0，给C1充电；（2）断开S0，再闭合S2，测量R2上耗散的热量，记为$h_0$；（3）重复步骤（1）；（4）闭合S1，测量R1上耗散的热量，记为$h_1$；（5）断开S1，再同时闭合S2和S3，测量R2上的热量（$h_2$）和R3上的热量（$h_3$）。作者绘图。',reason='恢复原图及完整五步图注。')
rows[-1].update(image='assets/figure-6-4.png',source_image={'pdf_page':139,'block':6,'xref':854},image_labels_zh='S0—S3：开关；C1、C2：电容器；R1—R3：电阻；V+：正电压端；下方符号：接地。')
add(rr(139,2),rr(70,6,7),end='在原始图',text='假设有一幅与图6.4对应的热学示意图：用热库代替电容器，并在原图电阻所在的位置放置热机。')
add(rr(139,3),rr(70,7,8),start='在原始图')
add(rr(139,4),rr(70,9,11))
add(rr(139,5)+rr(140,1),rr(70,12,16),text='或许可以为他辩解说，这本书初版于1872年，时间还相当早，恰逢玻尔兹曼发表那篇关于熵的里程碑式论文。那时尚早于麦克斯韦的《热学理论》一书，[[10]]但麦克斯韦论述中的关键内容已经发表。[[11]]即便允许马赫用几年时间消化这些思想，这个借口也很勉强。马赫在此后的岁月里并未撤回异议。1894年10月，他又在The Monist第5卷第1期上以英语发表了这篇文章，只作少量修改，再次使用同样的静电类比来反对热的机械理论。',reason='补漏注10、11，保留原书关于出版先后关系的陈述。')
rows[-1]['editor_note']='“早于麦克斯韦的《热学理论》”为底本原述；注10列1875年版本，未据此改写正文。'
add(rr(140,2),rr(70,17,18))
for j,text in enumerate(['1. 温度和压力。','2. 熵的增加。','3. 气体的黏度。','4. 气体中的“等体积定律”。','5. 与化学的原子理论相一致。']):
    add([[140,3,j,j+1]],rr(70,19+j),'list_item',text=text,reason='逐项保留原文五项列表，避免合并为一段。')
add(rr(140,4),rr(70,24),'heading',text='爱因斯坦驳倒马赫派对原子的反对',reason='从旧译合并段落中恢复小节标题。')
add(rr(140,5),rr(70,24,28),'quote',start='谁能想到',text='谁能想到，就在1900年，人们还在围绕原子是否真实存在争斗，甚至可以说斗得你死我活。维也纳的大哲学家恩斯特·马赫说：不。大化学家威廉·奥斯特瓦尔德也说：不。然而在那个关键的世纪之交，一个人基于根本的理论依据，挺身捍卫原子的实在性。他就是路德维希·玻尔兹曼。……人类的进步在那一刻悬于一架精细的思想天平之上；倘若当时反原子学说真的占了上风，我们的进步肯定会倒退几十年，甚至可能倒退一百年。[[12]]',reason='恢复独立引文与原有省略号；real/reality按实在性表达。')
add(rr(140,6),rr(70,29,30))
add(rr(140,7,8),rr(70,31,32),'list_item',text='1. 1905年6月：a.《论热的分子动理论所要求的静止液体中悬浮微粒的运动》。[[13]]',reason='修正molecular-kinetic theory误译分子热力学理论，保留原列表日期与层次。')
add(rr(140,9,10),rr(70,33),'list_item')
add(rr(140,11),rr(70,34),'list_item',text='c.《论运动物体的电动力学》。[[15]]',reason='electrodynamics译作电动力学。')
add(rr(140,12),rr(70,35),'list_item')
nt={10:'James Clerk Maxwell：《热学理论》（The Theory of Heat）（Longmans, Green, and Co，1875）。',11:'James Clerk Maxwell：“IV. 论气体的动力学理论”（IV. On the Dynamical Theory of Gases），Philosophical Transactions of the Royal Society of London，第157期（1867），第49—88页。',12:'Jacob Bronowski：《人类的进步》（The Ascent of Man）（Random House，2011）。',13:'A. Einstein：“论热的分子动理论所要求的静止液体中悬浮微粒的运动”（On the Movement of Small Particles Suspended in Stationary Liquids Required by the Molecular-kinetic Theory of Heat），Annals of Physics，第17卷（1905），第549页。',14:'A. Einstein：“关于光的发射和转化的一种启发式观点”（Concerning an Heuristic Point of View Toward the Emission and Transformation of Light），American Journal of Physics，第33卷第5期（1965），第367页。',15:'Albert Einstein：“论运动物体的电动力学”（On the Electrodynamics of Moving Bodies），Annalen der physik，第17卷第10期（1905），第891—921页。',16:'Albert Einstein：“物体的惯性是否取决于其能量含量”（Does the Inertia of a Body Depend Upon its Energy-content），Annals of Physics，第18卷（1905），第639—641页。'}
notes=[]
for n,refs in note_groups(rr(259,3)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch06-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['250'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
import sys
sys.path.insert(0,str(R/'tools/python_libs'))
import fitz
d=fitz.open(json.loads((W/'source_manifest.json').read_text('utf8'))['path'])
for xref,name in [(849,'figure-6-3.png'),(854,'figure-6-4.png')]:fitz.Pixmap(d,xref).save(str(R/'Defending Materialism/output/assets'/name))
save('ch06c',6,rows,notes,rr(138,1,3)+rr(138,5)+rr(139,1,5)+rr(139,7)+rr(140,1,12))
(W/'checkpoint_ch06c.json').write_text(json.dumps({'next_source_pdf_page':140,'next_source_block':13,'next_supplied_pdf_page':70,'next_supplied_block':36,'next_unit':len(rows)+33,'next_note':17,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
