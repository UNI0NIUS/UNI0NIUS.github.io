from materialism_common import *

groups=[]
for b in EN[287]['blocks'][1:]:
    for j,l in enumerate(b['lines']):
        x=l['bbox'][0]
        if x<80 or 225<x<250:groups.append([])
        groups[-1].append([288,b['block'],j,j+1])
oldrefs=rr(175,20,43)+rr(176,0,43)+rr(177,0,1)+rr(177,3,15)
assert len(groups)==len(oldrefs)==83
fixes={
 'Elements of Logic (Whately)':('《逻辑要素》','《逻辑原理》（惠特利）'),
 'English kinetic theory':('英国动能理论','英国分子运动论'),
 'Excursions of a Socialist into the Domain of Epistemology (Dietzgen)':('《一位社会主义者对认识论领域的探索》','《一位社会主义者对认识论领域的探索》（狄慈根）'),
 'ferro-cyanet of potash':('氰化钾铁','亚铁氰化钾'),
 'First Draft of a Report on the EDVAC (von Neumann)':('《EDVAC 报告初稿》','《关于EDVAC的报告初稿》（冯·诺伊曼）'),
 'The Foundations of Arithmetic (Frege)':('《算术基础》','《算术基础》（弗雷格）'),
 'Frankenstein (Shelly)':('《弗兰肯斯坦》','《弗兰肯斯坦》（雪莱）'),
 'From a Logical Point of View (Quine)':('《从逻辑角度看》','《从逻辑的观点看》（奎因）'),
 'The German Ideology (Marx and Engels)':('《德意志意识形态》','《德意志意识形态》（马克思和恩格斯）'),
 'Grundzüge der theoretische Logik (Hilbert and Ackermann)':('《理论逻辑纲要》','《理论逻辑纲要》（希尔伯特和阿克曼）'),
}
rows=[];parents={}
for i,(refs,zref) in enumerate(zip(groups,oldrefs),152):
    en=extract(EN,refs,True);old=extract(ZH,[zref]);zh=old
    m=re.search(r'\s+(\d[\d, ––-]*)$',en);assert m,en
    if en.startswith('Harvard Mark 1 '):m=re.search(r'\s+(194)$',en)
    term=en[:m.start()].strip();locator=m[1]
    oldloc=re.search(r'(\d[\d, ––-]*)$',old);assert oldloc,old
    assert re.sub(r'\s','',oldloc[1])==re.sub(r'\s','',locator),(en,old)
    if term in fixes:
        a,b=fixes[term];assert a in zh,(term,zh);zh=zh.replace(a,b)
    row={'id':f'dm-index-{i:03}','kind':'index_entry','source_blocks':refs,'supplied_translation_blocks':[zref],'printed_pages':['279'],'en':en,'zh':zh,'supplied_zh':old,'index_term':term,'index_locators':locator,'index_level':0,'status':'text_compared_layout_pending'}
    if term in ['finite','Hegel, Georg Wilhelm Friedrich']:parents[term]=row['id']
    if term in ['element methods','model system','representations','sets']:
        row['index_level']=1;row['index_parent']=parents['finite']
    if term in ['idealism','model of dialectics','Spirit','system']:
        row['index_level']=1;row['index_parent']=parents['Hegel, Georg Wilhelm Friedrich']
    if term=='Frankenstein (Shelly)':row['editor_note']='作者姓氏Shelly按原索引保留。'
    if zh!=old:row['revision_reason']='修正术语、补回作者括注并逐项核对页码；子条目恢复原索引层级。'
    rows.append(row)
save('index03',13,rows,[],rr(288,1,17))
(W/'checkpoint_index03.json').write_text(json.dumps({'next_source_pdf_page':289,'next_supplied_pdf_page':177,'next_supplied_block':16,'next_index_entry':235,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
