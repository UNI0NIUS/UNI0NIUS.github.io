from materialism_common import *
groups=[]
for b in EN[279]['blocks'][1:]:
    for j,l in enumerate(b['lines']):
        if l['bbox'][0]<62:groups.append([])
        groups[-1].append([280,b['block'],j,j+1])
oldrefs=[rr(163,23,24),rr(163,25),rr(163,26),rr(163,27)+rr(164,0),rr(164,1,2),rr(164,3,4),rr(164,5,6),rr(164,7,8),rr(164,9,10),rr(164,11),rr(164,12,13),rr(164,14),rr(164,15,16),rr(164,17,19),rr(164,20),rr(164,21,22),rr(164,23,24),rr(164,25,26),rr(164,27,28),rr(165,0,1),rr(165,2,3),rr(165,4,6),rr(165,7,8),rr(165,9,10)]
translations=[
'Andrey Kolmogorov：“论排中律”。载《从弗雷格到哥德尔：数理逻辑文献集，1879—1931》，Jean van Heijenoort编，414—437。Harvard University Press，1967。',
'Pavel V. Kopnine：“辩证法与逻辑”。Diogenes 15，第60期（1967）：87—102。',
'Walther Kranz、Hermann Diels：《前苏格拉底哲学家残篇》。第3卷。Weidmann，1952。',
'Leopold Kronecker：“克罗内克1886年著作的脚注”。载《从康德到希尔伯特：数学基础文献集》第2卷，W. Ewald编，946—947。Oxford University，1996。',
'Joan Kung：“亚里士多德论‘存在有多种说法’”。History of Philosophy Quarterly 3，第1期（1986）：3—18。',
'Boris A. Kushner：“马尔可夫的构造性分析：一个参与者的看法”。Theoretical Computer Science 219（1999）：267—285。',
'Boris A. Kushner：“A. A. 马尔可夫的构造性数学”。The American Mathematical Monthly 113，第6期（2006）：559—566。',
'Semen S. Kutateladze：“俄国数学的悲剧”。Siberian Electronic Mathematical Reports 9（2011）：A85—A100。https://arxiv.org/abs/math/0702632。',
'Rolf Landauer：“计算过程中的不可逆性与生热”。IBM Journal of Research and Development 5（1961）：183—191。',
'Dominique Lecourt：《无产阶级科学？李森科案例》。Verso，1977。',
'Gottfried W. Leibniz：“形而上学论”。1686。http://www.earlymoderntexts.com/assets/pdfs/leibniz1686d.pdf。',
'弗拉基米尔·伊里奇·列宁：《唯物主义和经验批判主义》。International Publishers，1908。',
'弗拉基米尔·伊里奇·列宁：“谈谈辩证法问题”。载《列宁全集》，列宁编，第38卷。Progress Publishers，1915。',
'弗拉基米尔·伊里奇·列宁：“再论工会、目前局势及托洛茨基和布哈林的错误”。载《列宁全集》英文第1版，Y. Sdobnikov译，第32卷，70—107。Progress Publishers，1965。https://www.marxists.org/archive/lenin/works/1921/jan/25.htm。',
'弗拉基米尔·伊里奇·列宁：《国家与革命》。Haymarket Books，2015。',
'弗拉基米尔·伊里奇·列宁：《马克思主义的三个来源和三个组成部分》。第1卷。Foreign Languages Press，1977。',
'W. Lenzen：“莱布尼茨：逻辑”。载Internet Encyclopedia of Philosophy。University of Tennessee at Martin，2017。https://iep.utm.edu/leib-log/。',
'Rocco Leonardis：“古希腊建筑师对几何学的运用”。A Companion to Greek Architecture（2016）：92—104。',
'Hyman Levy：“一位科学工作者看辩证唯物主义”。载《辩证唯物主义的诸方面》，1—30。Watts & Co.，1934。',
'Hyman Levy：“斗争中的数学家”。载《大卫·盖斯特：一位科学家为自由而战》，C. H. Guest编，150—160。Lawrence & Wishart，1939。',
'Hyman Levy、John. MacMurray、Ralph Fox、RalphPage Arnott、John D. Bernal、Edgar. F. Carritt编：《辩证唯物主义的诸方面》。Watts & Co.，1934。',
'Sheng-Kai Liao、Wen-Qi Cai、Wei-Yue Liu、Liang Zhang、Yang Li、Ji-Gang Ren、Juan Yin、Qi Shen、Yuan Cao、Zheng-Ping Li等：“星地量子密钥分发”。Nature 549，第7670期（2017）：43—47。',
'George G. Lorentz：“1928至1953年苏联的数学与政治”。Journal of Approximation Theory 116（2002）：169—223。',
'Johann Loshmidt：“考虑重力时物体系的热平衡状态”。Wiener Berichte 73（1876）：135。'
]
assert len(groups)==len(oldrefs)==len(translations)==24
rows=[]
for i,(refs,zrefs,zh) in enumerate(zip(groups,oldrefs,translations),157):
    raw=extract(EN,refs,True);en=raw.replace('\u200b','')
    for a,b in [('com /assets','com/assets'),('pdfs/ leibniz','pdfs/leibniz'),('marxists .org','marxists.org'),('lenin/ works','lenin/works')]:en=en.replace(a,b)
    row={'id':f'dm-ref-{i:03}','kind':'bibliography','source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['271'],'en':en,'zh':zh,'supplied_zh':extract(ZH,zrefs),'status':'text_compared_layout_pending','revision_reason':'完整核对书目信息并补译题名，不省略原书版本和出版数据。'}
    if en!=raw:row['source_transcription_note']='移除URL零宽字符与换行空格；原始span保留，未验证网络可达性。'
    if i==176:row['editor_note']='原书文集题名末词拼作Freedon，英文照录，中文按自由译出。'
    if i==177:row['editor_note']='编者姓名中的John.、RalphPage和Edgar.沿用本条源书写法；本书其他条目有不同拼写。'
    if i==180:row['editor_note']='原书德文题名中的znstand、Warmegleichgewichtes、Korpern及Ruck- sicht均照录；中文按题名语义译出。'
    rows.append(row)
save('refs08',12,rows,[],rr(280,1,21))
(W/'checkpoint_refs08.json').write_text(json.dumps({'next_source_pdf_page':281,'next_source_block':1,'next_supplied_pdf_page':165,'next_supplied_block':11,'next_reference':181,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
