from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch05-{len(rows)+61:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(90,9),rr(43,16),'heading',text='牛顿式的马克思')
add(rr(90,10)+rr(91,1),rr(43,16,18),'quote',start='一个国家',fixes=[('而这正是本著作的最终目标，即揭示现代社会的经济运动规律','而本著作的最终目标，正是揭示现代社会的经济运动规律'),('这些阵痛','这些分娩的阵痛')],reason='恢复插入语主干与birth-pangs的分娩比喻。')
add(rr(91,2),rr(43,19,20),end='因为哲学',fixes=[('就是为现代社会做牛顿为自然界所做的那样','就是对现代社会做牛顿对自然界所做的工作')])
add(rr(91,3),rr(43,20,22),'quote',start='因为哲学')
add(rr(91,4),rr(43,23))
add(rr(91,5,8),rr(43,24,27),fixes=[('从实验和观察出发，推导出运动定律','从实验和观察出发，表述运动定律'),('通过几何推导，进而推导出向心力的普遍性质','借助几何学进行演绎，进而得出向心力的普遍性质')],reason='区分从观察制定定律与随后几何演绎的步骤。')
add(rr(91,9),rr(43,28))
add(rr(91,10),rr(43,29))
add(rr(91,11),rr(43,30))
add(rr(91,12),rr(43,31))
add(rr(91,13),rr(43,32))
add(rr(91,14),rr(43,33))
add(rr(91,15,16),rr(43,34,35),fixes=[('重力遵循','引力遵循')])
rows[-1]['editor_note']='底本写作“向心力在相等时间内扫过相等面积”，此处按原文保留其表述；通常扫过面积的是运动物体与力心的连线。'
add(rr(91,17),rr(43,36),end='让我们')
add(rr(91,18)+rr(92,1),rr(43,36,38),'quote',start='让我们',text='让我们以两种商品为例，例如谷物和铁。无论它们的交换比例如何，总可以用一个等式来表示这个比例，使一定量的谷物与一定量的铁相等：例如，1夸特谷物＝x英担铁。这个等式告诉我们什么？',reason='corn在此译谷物；quarter统一译夸特并保留原单位，cwt统一译英担，避免与quart夸脱混淆。')
add(rr(92,2),rr(43,39,40)+rr(44,0),'quote',text='它告诉我们，在两种不同的东西中——在1夸特谷物和x英担[[39]]铁中——存在着某种两者共有的、数量相等的东西。因此，这两种东西必定等于第三种东西，而这第三种东西本身既不是前者，也不是后者。因此，两者中的每一种，就其作为交换价值而言，都必定能够还原为这第三种东西。',reason='恢复旧译遗漏的原注39，统一计量单位。')
add(rr(92,3),rr(44,1,3),'quote',fixes=[('[[4]] [[0]]','[[40]]'),('但三角形本身的面积所表达的，与其可见的图形完全不同，即底边与高之积的一半','但三角形本身的面积，是用一种与其可见形状完全不同的东西来表示的，即底边与高之积的一半')],reason='修正expressed by主客关系，恢复拆开的原注40。')
nt={38:'卡尔·马克思：《资本论》，第1卷，Marxist Internet Archive在线版（Progress Publishers，1954），第7页。',39:'cwt是一种英制计量单位，表示112磅。1 quarter为$\\frac{1}{4}$英担，即28磅。',40:'马克思：《资本论》，第1章，第28页。'}
notes=[]
for n,refs in note_groups([[254,2,4,9]]):
    en=extract(EN,refs,True)
    if n==39:en=en.replace('[[1]] 4cwt',r'$\frac{1}{4}$ cwt')
    note={'id':f'dm-ch05-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['245'],'en':en,'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'}
    if n==39:note['editor_note']='本注按底本所列重量换算照译；正文中的quarter统一保留为“夸特”，不与液量单位quart（夸脱）混同。底本分数已依据原注图像恢复。'
    notes.append(note)
save('ch05e',5,rows,notes,rr(90,9,10)+rr(91,1,18)+rr(92,1,3))
(W/'checkpoint_ch05e.json').write_text(json.dumps({'next_source_pdf_page':92,'next_source_block':4,'next_supplied_pdf_page':44,'next_supplied_block':4,'next_unit':len(rows)+61,'next_note':41,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
