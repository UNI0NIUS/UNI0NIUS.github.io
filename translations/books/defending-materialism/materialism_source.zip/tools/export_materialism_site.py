"""Export reviewed packets without publishing or registering the book."""
from materialism_common import *
import shutil

S=R/'github-sync';D=S/'translations/books/defending-materialism';D.mkdir(parents=True,exist_ok=True)
BASE='translations/books/defending-materialism/';BOOK='defending-materialism'
packets=sorted((json.loads(p.read_text('utf8')) for p in (W/'packets').glob('*.json')),key=lambda p:(p['reading_order'],p['packet']))
by={}
for p in packets:
    section={'0':'front','12':'references','13':'index'}.get(p['chapter'],'chapter-'+p['chapter'])
    if p['packet']=='front02':section='contents'
    if p['packet']=='front03':section='figures'
    by.setdefault(section,{'units':[],'notes':[],'chapter':p['chapter']})
    by[section]['units']+=p['units'];by[section]['notes']+=p['notes']
targets={u['id']:section for section,p in by.items() for u in p['units']}
def raw(s,ch):
    out=[];last=0
    pattern=r'\[\[(\d+)\]\]|\$([^$]+)\$|(?:https?|ttps)://[^\s。；，（）\u4e00-\u9fff]+|\n\n'
    for m in re.finditer(pattern,s):
        if m.start()>last:out.append(s[last:m.start()])
        if m[1]:out.append({'type':'note','id':f'dm-{ch}-{m[1]}'})
        elif m[2]:out.append({'type':'math','tex':m[2]})
        elif m[0]=='\n\n':out.append({'type':'break'})
        else:
            url=m[0].rstrip('.,;)');out.append({'type':'link','url':url.replace('\u200b',''),'children':[url]})
            if len(url)<len(m[0]):out.append(m[0][len(url):])
        last=m.end()
    if last<len(s):out.append(s[last:])
    return out
def inline(u,lang,ch):
    s=u[lang]
    if lang!='en':return raw(s,ch)
    runs=[];styles=[]
    for p,b,j,l in lines(EN,u['source_blocks']):
        for span in l['spans']:
            if span['flags']&1:continue
            style=bool(span['flags']&2)
            if styles and styles[-1][0]==style:styles[-1]=(style,styles[-1][1]+span['text'])
            else:styles.append((style,span['text']))
        if styles:styles[-1]=(styles[-1][0],styles[-1][1]+' ')
    protected=[m.span() for m in re.finditer(r'\$[^$]+\$|\[\[\d+\]\]|(?:https?|ttps)://\S+',s)]
    for style,t in styles:
        t=re.sub(r'\s+',' ',t).strip()
        if style and t:
            for m in re.finditer(r'(?<!\w)'+re.escape(t)+r'(?!\w)',s):
                if not any(m.start()<b and m.end()>a for a,b in protected):runs.append(m.span())
    out=[];last=0
    for a,b in sorted(set(runs)):
        if a<last:continue
        out+=raw(s[last:a],ch);out.append({'type':'em','children':raw(s[a:b],ch)});last=b
    return out+raw(s[last:],ch)
def flat(ts):
    return ''.join(t if isinstance(t,str) else '[['+t['id'].split('-')[-1]+']]' if t['type']=='note' else '$'+t['tex']+'$' if t['type']=='math' else '\n\n' if t['type']=='break' else flat(t.get('children',[])) for t in ts)
def noteids(ts):
    return [n for t in ts if isinstance(t,dict) for n in ([t['id']] if t['type']=='note' else noteids(t.get('children',[]))+[x for row in t.get('rows',[]) for cell in row for x in noteids(cell)])]
descriptors=[];total=0;ntotal=0
for section,p in by.items():
    ch=p['chapter'];units=p['units'];first=units[0]
    title,eng=first['zh'],first['en']
    if section=='front':title,eng='封面、扉页与出版信息','Cover, Title and Publication Details'
    descriptors.append({'id':section,'title':title,'originalTitle':eng,'dataUrl':BASE+section+'.json'})
    body=[]
    if section=='front':body.append({'id':'dm-cover','type':'figure','page':'','src':BASE+'assets/source_cover.png','zh':['原书封面'],'en':['Original cover']})
    for u in units:
        row={'id':u['id'],'type':{'chapter':'heading','heading':'subheading','quote':'quote','figure':'figure','publisher_mark':'figure','code':'code'}.get(u['kind'],'paragraph'),'page':'–'.join(dict.fromkeys(u['printed_pages']))}
        for lang in ['zh','en']:
            row[lang]=inline(u,lang,ch)
            assert flat(row[lang])==u[lang],(u['id'],lang)
        if u.get('math_lines'):
            for lang in ['zh','en']:row[lang]=[{'type':'math','tex':r'\begin{aligned}'+r'\\'.join(u['math_lines'])+r'\end{aligned}','display':True}]
        if u.get('table'):
            t=u['table']
            for lang in ['zh','en']:
                row[lang]=([*row[lang],{'type':'break'}] if u['en'].startswith('Table ') else [])+[{'type':'table','rows':[[raw(c,ch) for c in cells] for cells in [t['headers_'+lang]]+t['rows_'+lang]]}]
        if u.get('image'):row['src']=BASE+u['image']
        if u.get('image_labels_zh'):row['zh']+=[{'type':'break'},u['image_labels_zh']]
        if u.get('editor_note'):row['review']=u['editor_note']
        if u.get('index_level') or u.get('toc_level'):row['indent']=1
        if u.get('index_parent'):row['parent']=u['index_parent']
        if u['kind']=='toc_entry':
            locator=u['toc_locator'];candidates=[v for pp in by.values() for v in pp['units'] if v['kind'] in ['chapter','heading','figure'] and locator in v['printed_pages'] and targets[v['id']] not in ['contents','figures','front']]
            def key(s):return re.sub(r'[^\w]','',s.casefold())
            label=u['en'].rsplit(' ',1)[0]
            exact=[v for v in candidates if key(v['en'])==key(label)]
            if exact:candidates=exact
            if u.get('figure_number'):candidates=[v for v in candidates if re.match(r'Figure\s+'+re.escape(u['figure_number'])+r'\b',v['en'])]
            match=re.match(r'Chapter (\d+) ',u['en'])
            if match:candidates=[v for v in candidates if v['id']==f'dm-ch{int(match[1]):02}-001']
            if u['id'].startswith('dm-toc-') and not match and not exact:
                candidates=[]  # Never silently link a section to a different heading on the same page.
            if candidates:
                target=candidates[0];url='translations/book.html?id='+BOOK+'&chapter='+targets[target['id']]+'#'+target['id']
                for lang in ['zh','en']:row[lang]=[{'type':'link','url':url,'children':row[lang]}]
            if u['id']=='dm-toc-001':
                for lang in ['zh','en']:row[lang]=[{'type':'link','url':'translations/book.html?id='+BOOK+'&chapter=figures#dm-lof-title','children':row[lang]}]
            if u['id']=='dm-toc-089':
                for lang in ['zh','en']:row[lang]=[{'type':'link','url':'translations/book.html?id='+BOOK+'&chapter=chapter-1#note-'+lang+'-dm-1-1','children':row[lang]}]
        body.append(row)
    notes={}
    for n in p['notes']:
        nn=dict(n)
        for lang in ['zh','en']:nn[lang]=re.sub(r'^\d+[.．]?\s*','',n[lang])
        notes[f'dm-{ch}-{n["note_number"]}']={lang:inline(nn,lang,ch) for lang in ['zh','en']}
        if n.get('editor_note'):notes[f'dm-{ch}-{n["note_number"]}']['review']=n['editor_note']
    for lang in ['zh','en']:
        refs={x for row in body for x in noteids(row[lang])}
        assert refs==set(notes),(section,lang,refs^set(notes))
    (D/(section+'.json')).write_text(json.dumps({'id':section,'title':title,'originalTitle':eng,'sourceLanguage':'en','sourceLanguageLabel':'English','body':body,'notes':notes},ensure_ascii=False,indent=2)+'\n','utf8')
    total+=len(body);ntotal+=len(notes)
shutil.copytree(R/'Defending Materialism/output/assets',D/'assets',dirs_exist_ok=True)
(W/'site_chapters.json').write_text(json.dumps(descriptors,ensure_ascii=False,indent=2),'utf8')
metadata={'id':BOOK,'title':'捍卫唯物主义：原子在科学与哲学中的坎坷历程','originalTitle':'Defending Materialism: The Uneasy History of the Atom in Science and Philosophy','author':'Katarina Kolozova, William Paul Cockshott and Greg Michaelson','translator':'Xiaoyang Hao (AI-assisted working translation)','languagePair':'English / 中文','language':'zh-CN','bilingual':True,'example':False,'description':'唯物主义、原子论、逻辑与科学史。包括十一章正文、完整原注、图表、参考文献和索引。','editionNotice':'校对阅读版。p.为原书印刷页码；原注随对应段落显示，源书疑点另列校注。','chapters':descriptors,'downloads':[{'label':label,'url':BASE+name} for label,name in [('中英对照 PDF','materialism_bilingual.pdf'),('英文 PDF','materialism_en.pdf'),('中文 Markdown','materialism_zh.md'),('术语表','glossary.md'),('校对记录','review.md'),('源码包 ZIP','materialism_source.zip')]]}
(W/'site_metadata_candidate.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2),'utf8')
(W/'site_export_check.json').write_text(json.dumps({'rows':total,'notes':ntotal,'sections':len(descriptors),'canonical_inline_text':'pass','note_reference_sets':'pass','publication':'not registered or published','layout':'pending'},ensure_ascii=False,indent=2),'utf8')
print(total,'rows;',ntotal,'notes;',len(descriptors),'sections')
