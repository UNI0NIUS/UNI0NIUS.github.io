from materialism_common import *
groups=[]
for b in EN[276]['blocks'][1:]:
    for j,l in enumerate(b['lines']):
        if l['bbox'][0]<60:groups.append([])
        groups[-1].append([277,b['block'],j,j+1])
groups[-1].append([278,1,0,2])
oldrefs=[rr(159,9,10),rr(159,11,12),rr(159,13,14),rr(159,15,16),rr(159,17),rr(159,18,19),rr(159,20),rr(159,21,22),rr(159,23),rr(159,24),rr(159,25),rr(159,26),rr(160,0,1),rr(160,2,3),rr(160,4,5),rr(160,6),rr(160,7,10),rr(160,11,12),rr(160,13,14),rr(160,15,16),rr(160,17,18),rr(160,19,21),rr(160,22),rr(160,23,24),rr(160,25,27)]
translations=[
'阿尔伯特·爱因斯坦：“关于光的发射和转化的一个启发性观点”。American Journal of Physics 33，第5期（1965）：367。',
'阿尔伯特·爱因斯坦：“物体的惯性是否取决于其能量含量”。Annals of Physics 18（1905）：639—641。',
'阿尔伯特·爱因斯坦：“论动体的电动力学”。Annalen der physik 17，第10期（1905）：891—921。',
'阿尔伯特·爱因斯坦：“热的分子运动论所要求的悬浮在静止液体中的小粒子的运动”。Annals of Physics 17（1905）：549。',
'阿尔伯特·爱因斯坦：《相对论》。Methuen / Company，1920。',
'Albert Einstein、Boris Podolsky、Nathan Rosen：“对物理实在的量子力学描述能否被认为是完备的？”Physical Review 47，第10期（1935）：777。',
'Diane Elson：《价值：资本主义中劳动的表现》。Verso Books，2016。',
'A. Emery：“辩证法与机械论：关于科学方法的一场共产主义论争”。Philosophy of Science 2，第1期（1935）：9—38。',
'弗里德里希·恩格斯：《反杜林论》。Foreign Languages Publishing House，1954。',
'弗里德里希·恩格斯：《自然辩证法》。Foreign Languages Publishing House，1954。',
'弗里德里希·恩格斯：《自然辩证法》。Wellred Books，1960。',
'弗里德里希·恩格斯：《自然辩证法》。Progress Publishers，1974。',
'弗里德里希·恩格斯：“路德维希·费尔巴哈和德国古典哲学的终结”。载《马克思恩格斯选集》第II卷。Foreign Languages Publishing House，1951。',
'弗里德里希·恩格斯：“《反杜林论》的准备材料”。载《马克思恩格斯全集》第25卷。Lawrence & Wishart，1987。',
'弗里德里希·恩格斯：“社会主义从空想到科学的发展”。载《马克思恩格斯选集》第II卷。Foreign Languages Publishing House，1951。',
'Friedrich Engels、Tristram Hunt：《家庭、私有制和国家的起源》。Penguin，2010。',
'Kord Ernstson、Werner Mayer、Andreas Neumair、Barbara Rappenglück、Michael A. Rappenglück、Dirk Sudhaus、Kurt W. Zeller：“基姆高陨石坑散布区：德国巴伐利亚东南部全新世大型撞击事件的证据”。Journal of Siberian Federal University. Engineering & Technologies 1，第3期（2010）：72—103。',
'Hugh Everett：“量子力学的‘相对态’表述”。The Many Worlds Interpretation of Quantum Mechanics（2015）：141—150。',
'Emmanuel Farjoun：“用什么生产商品？”载《李嘉图、马克思、斯拉法》，E. Mandel编。Verso，1984。',
'Emmanuel Farjoun、Moshe Machover：《混沌的规律：政治经济学的概率论进路》。Verso，1983。',
'Jan Faye：“量子力学的哥本哈根解释”。载The Stanford Encyclopedia of Philosophy，Edward N. Zalta编。Metaphysics Research Lab, Stanford University，2019。',
'Ronald Aylmer Fisher：“不确定推理逻辑中的概率、似然与信息量”。Proceedings of the Royal Society of London. Series A, Containing Papers of a Mathematical and Physical Character 146，第856期（1934）：1—8。',
'Steven Frautschi：“膨胀宇宙中的熵”。Science 217，第4560期（1982）：593—599。',
'Edward Fredkin、Tommaso Toffoli：“守恒逻辑”。International Journal of Theoretical Physics 21，第3期（1982）：219—253。',
'戈特洛布·弗雷格：“概念文字：一种仿照算术语言构造的纯思维公式语言”。载《从弗雷格到哥德尔：数理逻辑文献集，1879—1931》，J. van Heijenoort编，S. Bauer-Mengelberg译。Harvard University Press，1967。'
]
assert len(groups)==len(oldrefs)==len(translations)==25
rows=[]
for i,(refs,zrefs,zh) in enumerate(zip(groups,oldrefs,translations),87):
    rows.append({'id':f'dm-ref-{i:03}','kind':'bibliography','source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in refs)),'en':extract(EN,refs,True),'zh':zh,'supplied_zh':extract(ZH,zrefs),'status':'text_compared_layout_pending','revision_reason':'逐项核对作者、完整题名与出版信息；同书不同版本分别保留。'})
save('refs05',12,rows,[],rr(277,1,20)+[[278,1,0,2]])
(W/'checkpoint_refs05.json').write_text(json.dumps({'next_source_pdf_page':278,'next_source_block':1,'next_source_line':2,'next_supplied_pdf_page':160,'next_supplied_block':28,'next_reference':112,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
