from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch11-{len(rows)+186:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(241,7),rr(129,24,26),'figure',text='图11.2 左：计算机芯片中的一种标准元件——CMOS反相器。向输入端A施加正电压，会使上方晶体管关断、下方晶体管导通，从而把非A输出端的电压拉低至地电位。右：反相器的逻辑符号。逻辑符号使我们能够撇开实现逻辑的具体电路。作者绘图。')
rows[-1].update(image='assets/figure-11-2.jpeg',source_image={'pdf_page':241,'block':6,'xref':1660},image_labels_zh='A：输入信号；not A：非A输出；Vdd：电源；GND：地。')
add(rr(241,1),rr(129,27,28),text='把同时包含一个信号及其反相信号的电路描述为“矛盾”，或许是相当自由的隐喻；因为虽然A与非A信号可以同时存在于逻辑电路中，但其中只有一个会被置为有效。',reason='complement不是补码；asserted译置为有效。')
add(rr(241,2),rr(129,29),text='毛泽东强调，不同矛盾有其特定的“解决”形式。')
add(rr(241,3),rr(129,29,32),'quote',text='性质不同的矛盾，只有用性质不同的方法才能解决。例如，无产阶级与资产阶级的矛盾，用社会主义革命的方法解决；广大人民群众与封建制度的矛盾，用民主革命的方法解决；殖民地与帝国主义的矛盾，用民族革命战争的方法解决；社会主义社会中工人阶级与农民阶级之间的矛盾，用农业集体化和机械化的方法解决；[[41]]',reason='恢复被旧译拆为4、1的原注41，保留原书引文末尾分号。')
add(rr(241,4),rr(129,33,35)+rr(130,0),text='他还引入了“主要矛盾”的概念，大致是指在决定社会发展进程方面最重要的矛盾。主要矛盾这一概念本质上与政治相联系。他说，在资本主义中，“处于矛盾之中的两个力量——无产阶级和资产阶级——构成主要矛盾”。这是因为，这些相互对立的阶级塑造了政治结构。他将它与所谓基本矛盾或根本矛盾区分开来；后者作用于生产关系层面，直到社会发展的某个阶段完成，才会消失。[[42]]',reason='完整接合跨页句并恢复注42；基本/根本保留原文两个对应词。')
add(rr(241,5)+rr(242,1),rr(130,0,3),'quote',text='马克思和恩格斯把事物中的矛盾规律应用于社会历史过程的研究时，发现了生产力与生产关系之间的矛盾，发现了剥削阶级与被剥削阶级之间的矛盾，以及由此产生的经济基础与其上层建筑（政治、意识形态等）之间的矛盾，并发现这些矛盾如何在不同类型的阶级社会中，必然导致不同类型的社会革命。')
add(rr(242,2),rr(130,4,6),'quote',text='马克思把这一规律应用于资本主义社会经济结构的研究时，发现这一社会的基本矛盾，是生产的社会性与所有制的私人性质之间的矛盾。这种矛盾表现为个别企业内部生产的有组织性与整个社会生产的无政府性之间的矛盾。在阶级关系上，它表现为资产阶级与无产阶级之间的矛盾。[[43]]')
add(rr(242,3),rr(130,7,10),text='将这一点应用于现代资本主义，生产力与生产关系之间的矛盾，就以利润率下降趋势的形式产生一种基本经济矛盾。在阶级层面，它表现为工人与雇主围绕工资、工作日及工作条件展开的经济阶级斗争。正是这一阶级矛盾居于主要地位，压倒了资本家与土地所有权之间的阶级冲突。理解这些矛盾之间的关系，就能说明危机如何在经济和政治层面展开。')
add(rr(242,4),rr(130,11,12),text='只要政治层面上工人阶级与资本家之间的主要矛盾还没有通过社会主义革命解决，基本经济矛盾就依然存在。利润率下降的趋势并未消除！')
add(rr(242,5),rr(130,13),'heading',text='作为问题解决方法的辩证法')
add(rr(242,6),rr(130,14,15),text='现在，让我们根据上述讨论，重新审视辩证法的三条经典规律。我们认为，最善意而有成效的理解，是把它们看作分析方法，而不是解释方法。')
add(rr(242,7),rr(130,16,22),text='首先，量向质的转化，如今通常被称为涌现。观察性质在可测量的边界上发生变化，并试图解释其原因，是科学的核心内容。然而，声称某事物通过量向质的转化而改变，是在诉诸魔法，而不只是承认某些可观察的现象尚无法用科学术语解释。诉诸涌现的说法，最常见于人工智能（AI）的讨论，尤其是奇点这一概念，即人工智能将获得超过人类的能力的时刻。人工智能日益取得成功的说法，掩盖了奇点究竟如何到来的问题；据说这些成功会以某种方式加速，并导致质变。我们当然不排除通用人工智能的可能性，但当前证据表明，在特定领域取得的小规模而且确实令人印象深刻的成果，并不能很好地扩展规模、推广到其他领域或与其他成果整合。',reason='译出原书发表时的判断，不以当前AI状况改写作者原文。')
add(rr(243,1),rr(130,23,24),text='同样，否定之否定常被表述为正题、反题、合题三元结构的抽象。与量向质的转化一样，它通常被用作事后解释。从纯粹逻辑的角度说，对一个否定再作否定，就会回到起点。')
add(rr(243,2),rr(130,25,30),text='最后，对立面的相互渗透，表达的是过程往往包含相互制衡、彼此作用的子过程。就其本身而言，寻找相互作用的“对立面”，是通过分解来解决问题的诸多进路之一。因此，在当代计算思维中，对立面的相互渗透是一种分而治之的形式，[[44]]其中把问题分解为两个子问题，是最简单的情况。在解决任意问题时，这些子问题通常相互补充，而不是相互矛盾。尽管如此，通过寻找社会阶级之间的矛盾来理解社会过程，仍是历史唯物主义的关键洞见。马克思、恩格斯、列宁和毛泽东娴熟地运用了这一洞见，为了改变世界而解释世界。',reason='countervailing译相互制衡，不必完全抵消；恢复原注44。')
nt={41:'毛泽东，《矛盾论》，第321页。',42:'毛泽东，《矛盾论》，第325页。',43:'毛泽东，《矛盾论》，第328—329页。',44:'G. Michaelson：“编程范式、图灵完备性与计算思维”，The Art, Science, and Engineering of Programming 4，第3期（2020）：第4篇，https://arxiv.org/abs/2002.06178。'}
notes=[]
for n,refs in note_groups(rr(272,3)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch11-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['263'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch11q',11,rows,notes,rr(241,1,5)+rr(241,7)+rr(242,1,7)+rr(243,1,2))
(W/'checkpoint_ch11q.json').write_text(json.dumps({'next_source_pdf_page':244,'next_source_block':0,'next_supplied_pdf_page':130,'next_supplied_block':31,'next_unit':len(rows)+186,'next_note':None,'chapter_text_complete':True,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
