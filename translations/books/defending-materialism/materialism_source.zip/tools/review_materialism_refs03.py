from materialism_common import *
groups=[]
for b in EN[274]['blocks'][1:]:
    for j,l in enumerate(b['lines']):
        if l['bbox'][0]<60:groups.append([])
        groups[-1].append([275,b['block'],j,j+1])
oldrefs=[rr(156,13),rr(156,14,16),rr(156,17,18),rr(156,19,20),rr(156,21,22),rr(156,23),rr(156,24,25),rr(156,26,27),rr(156,28),rr(157,0,1),rr(157,2),rr(157,3,4),rr(157,5),rr(157,6,7),rr(157,8,9),rr(157,10),rr(157,11,12),rr(157,13,14),rr(157,15,16),rr(157,17,18),rr(157,19,20),rr(157,21,22),rr(157,23,24)]
translations=[
'Charles A. Campbell：“苏联的逻辑观”。Soviet Studies 3，第3期（1952）：278—287。',
'格奥尔格·康托尔：“一般集合论基础：关于无限理论的数学—哲学研究”。载《从康德到希尔伯特：数学基础文献集》第II卷，W. Ewald编，878—920。Clarendon Press，1996。',
'Donald Stephen Lowell Cardwell：《从瓦特到克劳修斯：工业时代早期热力学的兴起》。Cornell University Press，1971。',
'鲁道夫·卡尔纳普：《意义与必然性：语义学和模态逻辑研究》。University of Chicago Press，1947。',
'鲁道夫·卡尔纳普：《世界的逻辑构造；哲学中的伪问题》。R. A. George译。University of California Press，1967。',
'Edward H. Carr：《苏俄史》。Macmillan，1950—1978。',
'John W. Carr III、Alan J. Perlis、James E. Robertson、Norman R. Scott：“访问苏联计算中心”。Communications of the ACM 2，第6期（1959）：8—20。',
'Titus Lucretius Carus：《物性论》第1册（第I—III卷）。Marcus Deufert编。de Gruyter GmbH，2019。',
'Titus Lucretius Carus：《卢克莱修全集》。Delphi Classics，2015。',
'Carlo Cercignani、Roger Penrose：《路德维希·玻尔兹曼：相信原子的人》。Oxford University Press，1998。',
'Gregory J. Chaitin：“随机性与数学证明”。Scientific American 232，第5期（1975）：47—53。',
'Robert Chambers：《创世自然史的遗迹》［R. Chambers著］。John Churchill，Princes Street，Soho，1853。https://books.google.co.uk/books?id=qDoDAAAAQAAJ。',
'诺姆·乔姆斯基：“论语法的若干形式性质”。Information and Control 2（1959）：137—167。',
'Debashish Chowdhury：“爱因斯坦布朗运动理论一百年：从花粉颗粒到蛋白质列车——1”。Resonance 10，第9期（2005）：63—78。',
'Alonso Church：“逻辑基础的一组公设”。Annals of Mathematics，第2辑，第33卷第2期（1932）：346—366。',
'Paul Cockshott：“对称性与交换关系”。Política y Cultura，第23期（2005）：279—304。',
'Paul Cockshott、Allin Cottrell：“劳动时间与其他价值基础：一则研究札记”。Cambridge Journal of Economics 21，第4期（1997）：545。',
'Paul Cockshott、Allin Cottrell：“价格与劳动价值之间的稳健相关性：一则评论”。Cambridge Journal of Economics 29，第2期（2005）：309—316。',
'Paul Cockshott、Allin Cottrell、Greg Michaelson：《用投入产出表检验劳动价值论》。Department of Computer Science, University of Strathclyde，1993。',
'Paul Cockshott、Allin Cottrell、Greg Michaelson：“检验马克思：英国数据的一些新结果”。Capital & Class 19，第1期（1995）：103—130。',
'P. Cockshott、Allin Cottrell、Greg Michaelson、I. Wright、V. Yakovenko：《经典经济物理学：古典政治经济学、热力学与信息论论集》。Routledge，2008。',
'Paul Cockshott、Lewis M. Mackenzie、Gregory Michaelson：《计算及其限度》。Oxford University Press，2012。',
'B. Jack Copeland：《Colossus：布莱切利园破译计算机的秘密》。Oxford University Press，2010。'
]
assert len(groups)==len(oldrefs)==len(translations)==23
rows=[]
for i,(refs,zrefs,zh) in enumerate(zip(groups,oldrefs,translations),41):
    en=extract(EN,refs,True).replace('\u200b','').replace('books?id =','books?id=')
    row={'id':f'dm-ref-{i:03}','kind':'bibliography','source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['266'],'en':en,'zh':zh,'supplied_zh':extract(ZH,zrefs),'status':'text_compared_layout_pending','revision_reason':'核对完整书目信息并补译题名；保留源书作者与出版者写法。'}
    if i==55:row['editor_note']='原书作者名拼作Alonso Church，现成稿写Alonzo；此处按原书照录。'
    if i==52:row['source_transcription_note']='移除URL中的零宽字符及换行空格，原始span保留。'
    rows.append(row)
save('refs03',12,rows,[],rr(275,1,21))
(W/'checkpoint_refs03.json').write_text(json.dumps({'next_source_pdf_page':276,'next_source_block':1,'next_supplied_pdf_page':157,'next_supplied_block':25,'next_reference':64,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
