from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,fixes=(),start=None,end=None,english=None):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch03-{len(rows)+1:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if english is not None:row['source_transcription_note']='公式、断字或章号依源PDF目视恢复；原始span保存在source_pages.json。'
    if reason:row['revision_reason']=reason
    rows.append(row)
add(rr(28,0,1),rr(10,38),'chapter',english='Chapter 3. CLASSICAL ATOMISM')
add(rr(28,2),rr(10,39,40))
add(rr(28,3),rr(11,0,2))
add(rr(28,4),rr(11,3),'heading')
add(rr(28,5),rr(11,4),fixes=[('是阿基米德。','是阿基米德[[1]]。')],reason='补回原注1。')
add(rr(28,6),rr(11,5),'quote')
add(rr(28,7,10),rr(11,6,9),'quote',reason='原书三条公设属于同一列举；合并OCR错切的行块，不丢掉各条编号。')
add(rr(28,11),rr(11,10),end='两个量，')
add(rr(28,12),rr(11,10,11),'quote',start='两个量，')
add(rr(29,1),rr(11,12),text='原理（2）和（3）在这一语境中表达了 ex nihilo nihil fit（无中不能生有）原则：若不向处于平衡状态的物体添加物质，或从中移除物质，就不会产生运动。',reason='恢复拉丁原语，避免把equilibrium position误解为可增减物质的空间位置。')
en=extract(EN,rr(29,2),True).replace('πr[[2]]',r'$\pi r^2$').replace('4 2 πr',r'$4\pi r^2$')
add(rr(29,2),rr(11,13,17),end='任何圆的面积',fixes=[(r'\pi r^2',r'$\pi r^2$'),(r'4$\pi r^2$',r'$4\pi r^2$')],english=en,reason='恢复数学上标与公式，避免误识为原注；拆开后面的引文。')
add(rr(29,3),rr(11,17),'quote',start='任何圆的面积')
add(rr(29,4),rr(11,18,19),fixes=[(r'\pi r^2',r'$\pi r^2$')],english=extract(EN,rr(29,4),True).replace('πr[[2]]',r'$\pi r^2$'))
add(rr(29,5),rr(11,20,22),fixes=[(r'\pi',r'$\pi$')])
add(rr(29,6),rr(11,23),'equation',r'$3\frac{10}{71}<\pi<3\frac{1}{7}$',english=r'$3\frac{10}{71}<\pi<3\frac{1}{7}$')
add(rr(29,7),rr(11,24))
add(rr(29,8),rr(11,25),'equation',r'$3.1408<\pi<3.1428$',english=r'$3.1408<\pi<3.1428$')
rows[-1]['editor_note']='小数界限依原书照录；其中上界3.1428是截短值，不等于分数上界22/7的精确小数展开。'
add(rr(29,9),rr(11,26),fixes=[(r'\pi = 3.141592654',r'$\pi = 3.141592654$')])
add(rr(29,10),rr(11,27,29))
en='Archimedes’ approach shows a close and mutually supportive relationship between geometry and mechanics. For example, his derivation of the volume of a sphere as $\\frac{4}{3}\\pi r^3$ uses explicitly mechanical arguments. His first step is to show that a unit cylinder has the same volume as the sum of the volumes of a unit hemisphere plus a unit cone.'
add(rr(29,11,14)+rr(30,1),rr(11,30,32),fixes=[(r'\frac{4}{3}\pir^3',r'$\frac{4}{3}\pi r^3$')],english=en)
add(rr(30,2),rr(12,0))
add(rr(30,3),rr(12,1,2))
add(rr(30,9),[],'figure','图3.1 阿基米德证明，单位圆柱体的体积等于单位圆锥体与单位半球体的体积之和。作者绘图。',reason='所供中文稿漏图与图注，恢复原图及完整图注。')
rows[-1].update({'image':'assets/figure-3-1.png','source_image':{'pdf_page':30,'block':8},'image_labels_zh':'FULCRUM：支点；Balance Lever：平衡杠杆；Unit Hemisphere：单位半球体；Unit cylinder：单位圆柱体；Unit Cone：单位圆锥体。X、Y、r及数字为原图符号。'})
add(rr(30,4),rr(12,3,4))
add(rr(30,5,7),rr(12,5,7),'quote',r'1. 圆柱切片的面积很容易计算。它们是单位圆，所以面积为 $\pi=\pi 1^2$。2. 假设我们处于距每个立体顶端为 $Y$ 的位置。由于圆锥的高与其底面半径相等，在 $Y$ 处圆锥的半径也为 $Y$，因此切片面积为 $\pi Y^2$。',english=r'1. The area of the cylinder slices is easy. Since they are unit circles, they have an area of $\pi=\pi 1^2$. 2. Suppose we are at distance $Y$ from the top of each solid. The radius of the cone at $Y$ will also be $Y$, since it is a cone whose height is the same as its radius. So the area will be $\pi Y^2$.')
add(rr(31,1,2),rr(12,8),'quote',r'3. 根据毕达哥拉斯定理，穿过半球的切片的半径 $X$ 必须为 $\pi(1^2-Y^2)=\pi(1-Y^2)$。',english=r'3. By Pythagoras’ theorem, the radius $X$ of the slice through the hemisphere must be $\pi(1^2-Y^2)=\pi(1-Y^2)$',reason='旧稿默默修正了原书错误；现正文照录，另加校注说明。')
rows[-1]['editor_note']='原书称下式为半径X，但式子实际表示截面面积。按图3.1，半径应为X=√(1−Y²)，面积为π(1−Y²)。所供旧译已改为X²=1²−Y²，现将作者原文与校正说明分开。'
add(rr(31,3,4),rr(12,9,11),'quote',r'4. 因此，半球与圆锥的圆形截面面积之和必定为 $\pi(1-Y^2)+\pi Y^2=\pi$，证毕。',english=r'4. Thus the sum of the circles in the hemisphere and cone must be $\pi(1-Y^2)+\pi Y^2=\pi$, Q.E.D.')
add(rr(31,5,9),rr(12,12,15),text=r'阿基米德还独立于这一论证，证明了单位圆柱体的体积是单位圆锥体的三倍。因此，半球的体积必为 $\frac{2}{3}\pi$，单位球的体积必为 $\frac{4}{3}\pi$。将其按比例放大到任意半径 $r$，就得到熟悉的 $\frac{4}{3}\pi r^3$。数学抽象与实际力学在这里存在密切联系。先前公理化力学中关于天平的公设，被用作出发点，推导出一种实质上属于积分学的证明。',english=r'Archimedes has independently of this argument proven that the volume of a unit cylinder is three times the volume of the unit cone, so the volume of the hemisphere must be $\frac{2}{3}\pi$, and that of the unit sphere must be $\frac{4}{3}\pi$. Scaling for a sphere of arbitrary radius $r$ we get the familiar $\frac{4}{3}\pi r^3$. There is an intimate relationship here between the mathematical abstraction and the real mechanics. Prior axiomatic mechanics postulates about balances are used as a stepping stone to derive what amounts to an integral calculus proof.')
add(rr(31,10),rr(12,16,17))
add(rr(31,11),rr(12,18,21),fixes=[('鲁索认为','鲁索[[2]]认为')],english=extract(EN,rr(31,11),True).replace('hydro-statics','hydrostatics'),reason='补回原注2，恢复行末断词hydrostatics。')
add(rr(31,12),rr(12,22,23))
add(rr(31,13),rr(12,24,27),fixes=[('内陆海地区','地中海地区')],reason='此处inland sea指本段罗马统治下的地中海。')
add(rr(31,14),rr(12,28,29),fixes=[('先验公理','先前的公理')],reason='prior表示论证次序在先，未必指认识论先验。')
add(rr(32,1),rr(12,30,32),text='这也适用于他在流体静力学方面那些更为人熟知的发现。这里的关键定律是：漂浮物体排开与自身等重的液体；浸没物体则排开与自身等体积的液体，这比它自身的重量要小。我们在这里再次遇到体积的相等与重量的相等，这正是上述证明的主题。',reason='保留底本物理量比较的疑义，不静默替作者改写。')
rows[-1]['editor_note']='底本“this being less than its own weight”指代不清，字面上混用了体积与重量。若指下沉物体所排液体的重量小于物体重量，则需限定密度条件；正文保留其原有表述。'
add(rr(32,2),rr(13,0,3),fixes=[('以有理数为单位的实际计算','用有理数进行的实际计算'),(r'\pi',r'$\pi$')])
add(rr(32,3),rr(13,4,10),fixes=[('未来神庙的物质模型。','未来神庙的物质模型。[[3]]'),('“正方形倍增法”','“正方形面积加倍法”')],reason='补回原注3；square doubling指面积加倍。')
add(rr(32,4),rr(13,11,14),fixes=[('建筑的telos','建筑的目的（telos）')])
add(rr(32,5),rr(13,15),'heading')
add(rr(32,6)+rr(33,1),rr(13,16,18),fixes=[('摩擦过的琥珀会','摩擦过的琥珀棒会')])
add(rr(33,2),rr(13,19,20),fixes=[('吸引物体（琥珀或磁石）','起吸引作用的物体（琥珀或磁石）')])
add(rr(33,3),rr(13,21,23))
add(rr(33,4),rr(13,24,25),fixes=[('“流”','“流溢”')])
add(rr(33,5),rr(13,26,27),fixes=[('是可能病理','可能是病理现象')])
add(rr(33,6),rr(13,28,29),end='现在，证明方法如下。')
add(rr(33,7),rr(13,29,31),'quote',start='现在，证明方法如下。',fixes=[('充盈尿液。','充盈尿液。[[4]]'),('可见膀胱已排空','显示膀胱是空的')],reason='补回原注4；empty并未说明发生了排空过程。')
add(rr(33,8),rr(13,32,34)+rr(14,0),end='粒子与铁碰撞后')
add(rr(33,9)+rr(34,1),rr(14,0,2),'quote',start='粒子与铁碰撞后')
add(rr(34,2),rr(14,3,9),'quote',fixes=[('第二根针尖','第二根铁笔'),('因分解为这些散发物而消散。','因分解为这些散发物而消散。[[5]]')],reason='stylet指铁制书写工具，并未特指针尖；补回原注5。')
add(rr(34,3),rr(14,10,11))
add(rr(34,4),rr(14,12,13))
add(rr(34,5),rr(14,14,17),text='盖伦认为，神经以气动方式工作。这一理论最早由埃拉西斯特拉图斯提出，他认为神经中有空腔，精神之气（psychic pneuma）[[6]]从中通过。气压沿神经传导，使肌肉膨胀并由此收缩。盖伦与埃拉西斯特拉图斯在生理学上都相信“气”（pneuma）的作用。吸入的空气在肺中转化为生命之气（vital pneuma），与血液混合并到达脑部。在那里，它被转化为精神之气，即“动物精气”（spiritus animalis），调节脑与神经的功能。[[7]]',reason='恢复原注6、7，统一古代生理学术语，保留原语；不将其误作现代医学说明。')
add(rr(34,6),rr(14,18,20),fixes=[('先进技术。','先进技术。[[8]]')],reason='恢复原注8。')
add(rr(34,7),rr(14,21,23),fixes=[('一种修改理论出现','一种经过修改的理论出现')])
add(rr(35,1),rr(14,24,26),end='基督教关于人的观点',fixes=[('动物精神','动物精气')])
add(rr(35,2),rr(14,24,26),'quote',start='基督教关于人的观点')
add(rr(35,3),[],'quote','……',reason='恢复原书引文间的省略号。')
add(rr(35,4),rr(14,27),'quote')
add(rr(35,5),rr(14,28,29),fixes=[('盖伦pneuma 的拉丁译名','盖伦 pneuma 的拉丁译名')])
nt=[
'阿基米德：《阿基米德著作集：以现代符号编订并附导论各章》（The Works of Archimedes: Edited in Modern Notation with Introductory Chapters），Thomas L. Heath 编，Cambridge Library Collection – Mathematics（剑桥大学出版社，2009），https://doi.org/10.1017/CBO9780511695124。',
'Lucio Russo：《被遗忘的革命：科学如何诞生于公元前300年，以及为何必须重新诞生》（The Forgotten Revolution: How Science Was Born in 300 BC and Why it Had to be Reborn）（Springer Science & Business Media，2013）。',
'Rocco Leonardis：“古希腊建筑师对几何学的运用”（The Use of Geometry by Ancient Greek Architects），A Companion to Greek Architecture（2016），第92–104页，https://doi.org/10.1002/9781118327586。',
'Galen、Arthur John Brock：《盖伦论自然机能，附英译》（Galen On the Natural Faculties with an English Translation）（W. Heinemann，1916），第1卷第13章。',
'Galen、Brock：《盖伦论自然机能，附英译》（Galen On the Natural Faculties with an English Translation），第1卷第14章。',
'pneuma 一词在希腊语中意为“空气”。',
'C. E. Quin：“盖伦之后关于神经系统功能的灵魂与气”（The Soul and the Pneuma in the Function of the Nervous System after Galen），Journal of the Royal Society of Medicine，第87卷第7期（1994），第393–395页，ISSN：0141-0768，https://europepmc.org/articles/PMC1294649。',
'这与19世纪弗兰肯斯坦博士利用新发现的电能使尸体获得生命的观念，有相似之处。']
notes=[]
for num,refs in note_groups([[246,3]])[:8]:
    en=extract(EN,refs,True).replace('\u200b','').replace('https: //','https://')
    notes.append({'id':f'dm-ch03-note-{num}','kind':'note','note_number':num,'source_blocks':refs,'printed_pages':['237'],'en':en,'zh':str(num)+'. '+nt[num-1],'status':'text_compared_layout_pending'})
expected=[[p,b['block']] for p in range(28,35) for b in EN[p-1]['blocks'] if p==28 or b['block']!=0]+rr(35,1,5)
save('ch03a',3,rows,notes,expected)
