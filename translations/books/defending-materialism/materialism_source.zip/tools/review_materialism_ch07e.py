from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch07-{len(rows)+70:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(166,12)+rr(167,1),rr(84,32,34),text='首先，在《解释篇》[[15]]中，亚里士多德定义了命题的句法，但没有使用任何符号。单句由名词及作用于名词的动词构成，还可以进一步连接。命题则是作出肯定或否定的句子，主项可以是全称的，也可以是单称的。《解释篇》还引入了矛盾命题这一关键概念。',reason='singular为单称而非单数；恢复动词作用于名词和句子连接。')
add(rr(167,2),rr(85,0))
for b in range(3,7):add(rr(167,b),rr(85,b-2),'list_item')
add(rr(167,7),rr(85,5,6),text='这些模式都具有“主项是谓项”的结构。这里的X、Y、Z可以一致地替换为具体名词。开头的字母A、I、E、O是传统的标识。',reason='补回consistently，强调替换的一致性。')
add(rr(167,8),rr(85,7),text='于是，《前分析篇》[[16]]探讨的三种三段论格可以表述为：',reason='补漏注16，figure用三段论格。')
for j in range(3):add([[167,9,j,j+1]],rr(85,8+j),'list_item')
add(rr(167,10),rr(85,11,12))
add(rr(167,11),rr(85,13,14),fixes=[('图式','格'),('术语','项'),('主词和谓词','主项和谓项')])
add(rr(167,12),rr(85,15,16),text='亚里士多德穷尽考察了这三种格中全称／特称与主项／谓项的所有可能组合，通过推导矛盾排除了其中许多组合。他还说明了如何把第二格和第三格归约为第一格。',reason='统一全称/特称，避免旧译普遍/特殊混同概念。')
add(rr(167,13),rr(85,17,18))
add(rr(167,14),rr(85,19),'heading')
add(rr(167,15),rr(85,20,23),text='亚里士多德的著作由波爱修斯[[17]]译成拉丁文；他约生活于公元475年至526年。此后，这些著作实际上从欧洲思想中失落了数百年，直到被阿拉伯学者“重新发现”。后来，亚里士多德哲学在中世纪天主教学者的一场重要思潮中稳步取得影响，这场思潮如今称为经院哲学。七门自由学艺的划分及其分为“三艺”“四艺”，构成欧洲教育的核心；尤其是11世纪末起，第一批大学得到梵蒂冈认可而建立之后，更是如此。',reason='17归位，保留原文重新发现引号，Seven Liberal Arts译出自由学艺。')
notes=[]
nt={15:'Aristotle：《解释篇》（On Interpretation），H. P. Cook英译，洛布古典丛书（William Heinemann，1962）。',16:'Aristotle：《前分析篇》（Prior Analytics）。',17:'J. Marenbon编：《剑桥波爱修斯指南》（The Cambridge Companion to Boethius）（Cambridge University Press，2009）。'}
for n,refs in note_groups(rr(263,3))+note_groups(rr(264,1)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch07-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':[str(refs[0][0]-9)],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch07e',7,rows,notes,rr(166,12)+rr(167,1,15))
(W/'checkpoint_ch07e.json').write_text(json.dumps({'next_source_pdf_page':168,'next_source_block':1,'next_supplied_pdf_page':85,'next_supplied_block':24,'next_unit':len(rows)+70,'next_note':18,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
