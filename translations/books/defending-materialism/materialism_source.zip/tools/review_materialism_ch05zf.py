from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch05-{len(rows)+357:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(131,4),rr(66,16,20),text=r'弗劳奇[[133]]依据玻尔兹曼的S公式，为此构造了一个简单论证。把公式应用于最初含有N个粒子的整个宇宙，就得到$S=k\log(N\text{个粒子的状态数})$。接着他指出，由于对数值即使对于宇宙学数量也小于100，初始中子—质子气体的熵可以近似为$S(n,p\ \mathrm{gas})\approx kN$。如果四个核子结合成一个α粒子，即卢克莱修所谓实体的首次聚合，就会释放出一个7 MeV的γ光子。所得α粒子与光子构成的气体或等离子体，其熵可写为：',english=r'Frautschi[[133]] constructs a simple argument based on Boltzmann’s S formula for this. Applying it to the whole universe with N initial particles, we have $S=k\log(\text{number of }N\text{ particle states})$. Next, he shows that since logs, even for cosmological quantities, are less than 100, you can approximate the entropy of the initial neutron-proton gas by $S(n,p\ \mathrm{gas})\approx kN$. If four nucleons combine to form an alpha particle, a first agglomeration of Lucretian corpora, a 7 MeV (γ) photon is released. The entropy of the resulting alpha and photon gas, or plasma, can be written:',reason='补回漏注133，恢复熵公式、粒子状态数与聚合论述。')
formula=r'$S(\alpha,\gamma\ \mathrm{gas})\approx k(N_\alpha+N_\gamma)\approx k\left(\frac{N}{4}+\frac{N\,7\mathrm{MeV}}{3kT}\right)$'
add(rr(131,5,9),rr(66,21,22),text=formula,english=formula,reason='依据源图恢复分式、上下标及括号。')
add(rr(131,10),rr(66,23,25),text=r'这里的关键是，光子的熵贡献与温度T成反比。如果$kT>7\ \mathrm{MeV}$，解离的中子和质子的熵就高于α粒子与γ射线的熵之和。随着宇宙膨胀，中子—质子气体的温度降至某一临界值以下，[[134]]在这一温度下，氦核与γ射线的熵之和超过孤立核子的熵，于是形成了原初氦。进一步的膨胀使γ光子冷却为我们如今观测到的2.4开尔文微波背景。',english=extract(EN,rr(131,10),True),reason='补回漏注134；保留原书2.4开尔文数值。')
rows[-1]['editor_note']='2.4 Kelvin为底本原述，照录。'
add(rr(131,11),rr(66,26,29),text='弗劳奇[[135]]关于秩序源于混沌的论证，依赖于玻尔兹曼本人尚不知道的几项知识：亚原子粒子、α粒子的结合能以及爱因斯坦的质能等价关系。这些发现都出现在玻尔兹曼自杀早逝后的二十年内；倘若他没有自杀，我们有理由认为他本可以亲眼见到这些发现。自玻尔兹曼发表最初那篇论文以来的一个半世纪中，他的思想得到了日益广泛的应用。我们对信息、[[136]]经济[[137]]乃至引力[[138]]的理解，均已被证明可以从他的熵统计理论中推导出来。',reason='补回135、137、138并归位136；恢复α粒子，see them指亲眼见到而非预见。')
nt={133:'Frautschi：“膨胀宇宙中的熵”（Entropy in an Expanding Universe）。',134:r'按他的近似计算，此时$kT\approx 28/9\ \mathrm{MeV}$。',135:'Frautschi：“膨胀宇宙中的熵”（Entropy in an Expanding Universe）。',136:'参见C. Shannon：“通信的数学理论”（A Mathematical Theory of Communication），The Bell System Technical Journal，第27卷（1948），第379—423、623—656页；Rolf Landauer：“计算过程中的不可逆性与热量产生”（Irreversibility and Heat Generation in the Computing Process），IBM Journal of Research and Development，第5卷（1961），第183—191页。',137:'参见Farjoun和Machover：《混沌的规律：政治经济学的概率方法》（Laws of Chaos, a Probabilistic Approach to Political Economy）；W. Paul Cockshott等：《经典经济物理学》（Classical Econophysics），第2卷（Routledge，2009）；J. Barkley Rosser：“熵与经济物理学”（Entropy and Econophysics），The European Physical Journal Special Topics，第225卷第17期（2016），第3091—3104页。',138:'参见Erik Verlinde：“论引力的起源与牛顿定律”（On the Origin of Gravity and the Laws of Newton），Journal of High Energy Physics，2011年第4期，第1—27页；他从熵推导出牛顿定律。这一推导虽有影响，却存在争议；参见Shan Gao：“引力是熵力吗？”（Is Gravity an Entropic Force?），Entropy，第13卷第5期（2011），第936—948页。'}
nr={133:[[258,1,128,129]],134:[[258,1,129,131]],135:[[258,1,131,132]],136:[[259,1,0,4]],137:[[259,1,4,8]],138:[[259,1,8,12]]}
notes=[]
for n,refs in nr.items():
    en=extract(EN,refs,True) if n!=134 else r'134 In his approximate calculation when $kT\approx 28/9\ \mathrm{MeV}$.'
    notes.append({'id':f'dm-ch05-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':[str(refs[0][0]-9)],'en':en,'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch05zf',5,rows,notes,rr(131,4,11))
(W/'checkpoint_ch05zf.json').write_text(json.dumps({'next_source_pdf_page':132,'next_source_block':0,'next_supplied_pdf_page':66,'next_supplied_block':30,'next_chapter':6,'next_note':1,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
