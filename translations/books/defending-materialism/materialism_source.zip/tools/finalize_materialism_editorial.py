"""Repeatable final editorial pass; run after regenerating review packets."""
from materialism_common import *

paths=sorted((W/'packets').glob('*.json'))
data={p:json.loads(p.read_text('utf8')) for p in paths}
units={u['id']:u for d in data.values() for u in d['units']+d['notes']}
changes=[]
for ident,replacements in {
    'dm-ch01-045':[('马尔科夫','马尔可夫'),('建构主义','构造主义')],
    'dm-ch05-058':[('卡捷琳娜','卡塔琳娜')],
}.items():
    u=units[ident]
    for a,b in replacements:u['zh']=u['zh'].replace(a,b)
    changes.append({'id':ident,'action':'unify reviewed names and mathematical terminology'})
# Align the contents with the actual reviewed chapter titles, without changing
# the original English wording or source page locators.
chapters={int(d['chapter']):next((u for u in d['units'] if u['kind']=='chapter'),None) for d in data.values() if 1<=int(d['chapter'])<=11 and any(u['kind']=='chapter' for u in d['units'])}
for n,u in chapters.items():u['zh']=re.sub(r'^第\s*\d+\s*章\s*',f'第{n}章 ',u['zh'])
for u in units.values():
    if u['kind']=='toc_entry':
        m=re.match(r'Chapter (\d+) ',u['en'])
        if m:u['zh']=chapters[int(m[1])]['zh']+'　'+u['toc_locator']
for ident in ['dm-ch05-066','dm-ch05-174','dm-ch05-308']:
    for lang in ['en','zh']:
        u=units[ident];u[lang]=re.sub(r'\s*([2-4]\. )',r'\n\n\1',u[lang])
    changes.append({'id':ident,'action':'restore numbered-list paragraph breaks'})
u=units['dm-ch05-084']
u['en']='The expanded relative value form is, however, nothing but the sum of the elementary relative expressions or equations of the first kind, such as:\n\n20 yards of linen = 1 coat\n\n20 yards of linen = 10 lbs of tea, etc.\n\nEach of these implies the corresponding inverted equation,\n\n1 coat = 20 yards of linen\n\n10 lbs of tea = 20 yards of linen, etc.[[42]]'
u['zh']='然而，这种扩大的相对价值形式无非是第一类简单的相对价值表达式或等式的总和，例如：\n\n20码亚麻布＝1件外套\n\n20码亚麻布＝10磅茶叶，等等。\n\n上述每条等式都隐含相应的逆等式：\n\n1件外套＝20码亚麻布\n\n10磅茶叶＝20码亚麻布，等等。[[42]]'
changes.append({'id':u['id'],'action':'restore separate value equations and explanatory paragraphs'})
u=units['dm-ch11-note-11']
for lang,breaks in {
    'en':['We may define','From this he was able','Any experiment by','He was able to use'],
    'zh':['“我们可以定义','由此，他得以','“凡是从一个','他能够利用']
}.items():
    for text in breaks:
        u[lang]=u[lang].replace(text,'\n\n'+text)
    u[lang]=re.sub(r'\n{3,}','\n\n',u[lang])
changes.append({'id':u['id'],'action':'restore two quotation paragraphs and intervening argument'})
for p,d in data.items():p.write_text(json.dumps(d,ensure_ascii=False,indent=2),'utf8')
(W/'editorial_final_pass.json').write_text(json.dumps({'changes':changes,'chapter_titles_aligned_with_contents':True,'layout':'pending'},ensure_ascii=False,indent=2),'utf8')
print('Editorial repairs:',len(changes))
