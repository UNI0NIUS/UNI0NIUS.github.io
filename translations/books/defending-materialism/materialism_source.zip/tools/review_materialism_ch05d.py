from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch05-{len(rows)+49:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(89,1),rr(42,12,13),fixes=[('物种存在','类存在')])
add(rr(89,2),rr(42,14,20),fixes=[('因为它缺乏理性）。','因为它缺乏理性）。[[28]]'),('它是一种理念，','它是一种理念，[[29]]'),('却并非如此。[[28]]','却并非如此。'),('是自动的','是自运动的'),('这种自动的物质现实','这种自运动的物质现实')],reason='原注28错置段尾且29遗漏；self-moved应与自动机术语区分。')
add(rr(89,3),rr(42,21,23),end='原子通过其属性',fixes=[('如果抽象出','如果抽去')],reason='abstracts在此指排除完美理念这一假定，旧译方向相反。')
add(rr(89,4),rr(42,23,27),'quote',start='原子通过其属性',fixes=[('矛盾客观化','矛盾对象化')],reason='统一马克思引文objectify术语。')
add(rr(89,5),rr(42,28,32),fixes=[('物质属性的客观化','物质属性的对象化'),('它在任何意义上都不是“理想”的（包括“伦理”或道德意义上的）','它在这个词的任何意义上都不是观念性的（或唯心主义的），包括“伦理的”或道德的（或道德主义的）意义')],reason='保留ideal(ist)、moral(ist)双重词义，旧译仅有理想/道德。')
add(rr(89,6),rr(42,33),end='那些哲')
add(rr(89,7)+rr(90,1),rr(42,33,36),'quote',start='那些哲学家')
add(rr(90,2),rr(42,37,39)+rr(43,0),end='要客观',fixes=[('[[3]][[4]]','[[34]]')],reason='恢复拆开的原注34。')
add(rr(90,3),rr(43,0,1),'quote',start='要客观',text='作为对象性的、自然的、感性的存在，同时在自身之外拥有对象、自然和感性，或者自身对于第三者而言就是对象、自然和感性，乃是一回事。[[35]]',reason='to be objective在此是对象性存在，而非要求思考客观公正。')
add(rr(90,4),rr(43,2,7),end='达朗贝尔：',fixes=[('生命论者','活力论者'),('我的著作《卡捷琳娜·科洛佐娃》（Punctum Books，2015 年）中进行了详细讨论。[[36]] 《迈向社会主义的激进形而上学》。','我的著作《迈向社会主义的激进形而上学》（卡捷琳娜·科洛佐娃，Punctum Books，2015）中进行了详细讨论。[[36]]')],reason='源书作者名、书名与脚注位置错排，中文按书目信息整理，英文仍照录。')
rows[-1]['editor_note']='底本将bookKaterina Kolozova、出版社及书名错排在正文中；中文据本段及对应原注整理，未把作者名当书名。'
add(rr(90,5,7),rr(43,7,11),'quote',start='达朗贝尔：',fixes=[('构建三段论或进行推理','形成三段论或作出推论'),('我们并非推导它们','我们并不作出这些推论')])
add(rr(90,8),rr(43,12,15),fixes=[('泛灵论活力论','泛灵论式的活力论')])
nt={28:'亚里士多德：《物理学》，载《亚里士多德全集》修订牛津译本，Jonathan Barnes译编（Oxford University Press，1991），195b31—199a9—199a19。',29:'亚里士多德：《形而上学》，W. D. Ross修订并撰导论与评注（Clarendon Press，1924），第12卷，MIT Classics Internet Archive，http://classics.mit.edu/Aristotle/metaphysics.html。',30:'卡尔·马克思：《德谟克利特的自然哲学和伊壁鸠鲁的自然哲学的差别》，载《马克思恩格斯全集》英文版第1卷（Progress Publishers，1975），无页码，Marxist Internet Archive，https://www.marxists.org/archive/marx/works/1841/dr-theses/index.htm（访问日期：2021年11月27日）。',31:'Julian Hocheld：“阶级利益概念”（The Concept of Class Interest），The Polish Sociological Bulletin，第16期（1967），第5—14页，http://www.jstor.org/stable/44815383。',32:'Denis Diderot：《狄德罗全集》（OEuvres complètes de Diderot），第1卷，J. Assézat编（巴黎，1875），第304页。',33:'马克思：《1844年经济学哲学手稿》，https://www.marxists.org/archive/marx/works/download/pdf/Economic-Philosophic-Manuscripts-1844.pdf（访问日期：2023年1月9日）。',34:'Katerina Kolozova：“现代性中什么值得挽救：从非哲学马克思主义到齐泽克普遍主义的实在论视角”（What Is Worth Salvaging In Modernity: A Realist Perspective From Non-Philosophical Marxism to Žižek’s Universalism），载Understanding Žižek, Understanding Modernism，Zahi Zaloua与Jeffrey R. Di Leo编（Bloomsbury，2022）。',35:'卡尔·马克思：《对黑格尔哲学的总体批判》，无页码，https://www.marxists.org/archive/marx/works/down-load/pdf/Economic-Philosophic-Manuscripts-1844.pdf（访问日期：2023年1月9日）。',36:'Katerina Kolozova：《迈向社会主义的激进形而上学：马克思与拉鲁埃尔》（Toward Radical Metaphysics of Socialism: Marx and Laruelle）（Punctum Books，2015）。',37:'狄德罗：“达朗贝尔与狄德罗的对话（1769）”，https://www.marxists.org/reference/archive/diderot/1769/conversation.htm（访问日期：2023年12月12日）。'}
notes=[]
groups=[(n,refs) for n,refs in note_groups([[254,1,0,24]]) if n and n>=28]
groups += [(36,[[254,1,24,25],[254,2,0,1]]),(37,[[254,2,0,4]])]
for n,refs in groups:
    en=extract(EN,refs,True).replace('\u200b','')
    for a,b in [('http:// classics','http://classics'),('org/ archive','org/archive'),('/dr -theses','/dr-theses'),('1769/ conversation','1769/conversation')]:en=en.replace(a,b)
    if n==36:en='36 '+en.rsplit('37',1)[0].strip()
    if n==37:en='37 '+en.split('37',1)[1].strip()
    note={'id':f'dm-ch05-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['245'],'en':en,'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'}
    if n==36:note['editor_note']='底本此条漏印注号36；据正文注36和前后35、37序列恢复。原文第254页block2第0行同时含本注末尾和注37号，源行引用因此交叠。'
    if n==37:note['editor_note']='底本网址前缀误印fh ttps://；中文恢复https://，英文保留底本。'
    if n==35:note['editor_note']='底本网址路径作down-load，与原注33的download不同；两者分别按底本保留。'
    notes.append(note)
save('ch05d',5,rows,notes,rr(89,1,7)+rr(90,1,8))
(W/'checkpoint_ch05d.json').write_text(json.dumps({'next_source_pdf_page':90,'next_source_block':9,'next_supplied_pdf_page':43,'next_supplied_block':16,'next_unit':len(rows)+49,'next_note':38,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
