from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,fixes=(),start=None,end=None):
    old=extract(ZH,zh) if zh else ''
    s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,(a,s[:80]);s=s.replace(a,b)
    row={'id':f'dm-ch02-{len(rows)+1:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    rows.append(row)
add(rr(16,0,2),rr(4,10),'chapter','第2章 探索古希腊所提供的概念材料及其影响的跨千年交流')
rows[-1]['en']='Chapter 2. EXPLORING THE CONCEPTUAL MATERIAL PRESENTED BY GREEK ANTIQUITY AND THE TRANS-MILLENNIAL EXCHANGES IT HAS INFLUENCED'
add(rr(16,3),rr(4,11,22),fixes=[('（欧洲）哲学','（欧洲）[[1]]哲学'),('则在本体论意义上意味着“生成”','则意味着本体论意义上的“生成”，这一论述诉诸的是本体论，而不是自然哲学')],reason='恢复原注1及与自然哲学相区别的限定。')
add(rr(16,4)+rr(17,1),rr(4,23,27),end='并不存在超越事物本身的运动。')
add(rr(17,2),rr(4,27,28),'quote',start='并不存在超越事物本身的运动。',fixes=[('[[23]]','[[2]][[3]]')],reason='恢复引文独立段落与并列原注2、3，防止合并成注23。')
add(rr(17,3),rr(4,29,37),fixes=[('（希腊语to ti，即某种“什么”）','（希腊语 to ti，即某种“什么”）')])
add(rr(17,4),rr(5,0),'heading')
add(rr(17,5)+rr(18,1),rr(5,1,20),fixes=[('“因为虚空并非事物”','“因为虚空就是无”'),('τὸγὰρ κενὸν οὐδέν ἐστιν','τὸ γὰρ κενεὸν οὐδέν ἐστιν'),('（DK 30B7.7）。','（DK 30B7.7）。[[5]]'),('对塞拉斯的一种特定接受，','对塞拉斯的一种特定接受[[7]]，'),('“现实的显性形象”','“现实的显现图景”')],reason='恢复原注5、7及希腊原文；manifest image 统一为“显现图景”。')
add(rr(18,2,3),rr(5,21),'heading')
add(rr(18,4),rr(5,22,26))
rows[-1]['editor_note']='此处底本拼作 Hawkins，原书第10页同一论述使用 Hawking；中文沿用所供译稿的“霍金”，英文保留底本拼写。'
add(rr(18,5),rr(5,27,29),end='哲学从古至今',fixes=[('对经验主义的蔑视','对经验材料的蔑视'),('物理与理想','物质与观念')],reason='empirical 并非作为学派的empiricism；ideal 不是“理想”。')
add(rr(18,6)+rr(19,1),rr(5,29,38)+rr(6,0),start='哲学从古至今',fixes=[('普遍利己主义者的概念。','普遍利己主义者的概念。[[10]]'),('归根结底都是唯心主义。','归根结底都是唯心主义。[[11]]'),('第三方的（想象中的）视角。','第三方的（想象中的）视角。[[12]]'),('只是为了理论化其社会效果；','只是为了理论化其社会效果[[13]]；')],reason='补回连续漏掉的原注10—13；恢复跨页原段。')
add(rr(19,2),rr(6,1,7),fixes=[('异族女性主义','异质女性主义（xenofeminism）')],reason='xeno- 在此不指异族；保留原词供辨认。')
add(rr(19,3)+rr(20,1),rr(6,8,19),end='人们不容易',fixes=[('人类推理（范畴应用）和存在本身的崩溃','将人类推理（范畴应用）与存在本身混同'),('“简言之，存在总是以多种方式被述说”','“简言之，存在总是以复数形式被述说”'),('τὸὂν τὸἁπλῶς λεγόµενον λέγεται πολλαχῶς','τὸ ὂν τὸ ἁπλῶς λεγόμενον λέγεται πολλαχῶς')],reason='collapse 此处指混同而非崩溃；保留作者英文引文plural的措辞，希腊文照底本。')
add(rr(20,2),rr(6,19,21),'quote',start='人们不容易',fixes=[('另一个genus','另一个属（genus）')])
add(rr(20,3),rr(6,22),text='此外，他论证道：')
add(rr(20,4),rr(6,22,23),'quote',start='因此，有人说')
add(rr(20,5),rr(6,24,27),fixes=[('独立的本体论实体','独立的存在者'),('及其在当时可能性和局限','及其在当时的可能性和局限')],reason='区分ontic与ontological；修复漏字。')
add(rr(20,6)+rr(21,1),rr(6,28,38),text='亚里士多德《物理学》的上述引文带有鲜明的唯物主义色彩：物质与“存在之物”——某物，或 tò tí，或 ousia——不可分离。因此，物体并不是能够“承载”或容纳虚空或空的空间的东西，不能像留基伯和德谟克利特所尝试的那样，借此既使运动成为可能，又避免反驳埃利亚学派。恰恰相反，亚里士多德确实进行了这种反驳。按照亚里士多德的说法，早期原子论者所提出的妥协是：“他们说元素是充实与虚空，并分别把它们称为存在与非存在”［στοιχεῖα μὲν τὸ πλῆρες καὶ τὸ κενὸν εἶναί φασι, λέγοντες τὸ μὲν ὂν τὸ δὲ μὴ ὄν］（亚里士多德，《形而上学》A.4 985b5–6）。[[16]]这是一种谬误，一种推理错误，而且极可能是一种本体论上的不可能性。我们在这里使用“极可能”，因为亚里士多德似乎并不认为：仅仅由于我们所能依靠的是认知工具（organon）的完善，外部世界就不可通达。非存在是相对于某种 ousia 而言的偶发、巧合，或更确切地说，偶然性（sumbebekos）；它可以是一种虚假，最后，也可以是一种潜能（即作为存在者现象的生成）。[[17]]正如质料依存于某种 ousia，存在因而是正确谓述与现实性的范畴。正确使用范畴，能够导向对实在或存在的正确说明。亚里士多德的方法可以与今天所谓的科学推理相比：证明的工具（organon）的完善，能够使我们对外部世界、实在或存在的说明更加准确。',reason='纠正“留基伯和德谟克利特试图反驳埃利亚学派”的反向误译，补原注17，恢复希腊文。')
add(rr(21,2),rr(6,39)+rr(7,0,5),fixes=[('被欲求者和被思想者运动而自身不动','被欲求者和思想的对象推动运动而自身不动')],reason='原作者所引prime mover的move在此为使动义；修复与unmoved的逻辑关系。')
add(rr(21,3),rr(7,6))
add(rr(21,4),rr(7,7),'heading')
add(rr(21,5),rr(7,8,15))
add(rr(22,1),rr(7,16),'heading')
add(rr(22,2),rr(7,17,21),fixes=[('《论生成与毁灭》','《论生成与消灭》')])
add(rr(22,3),rr(7,22,26),end='所有这一切都以')
add(rr(22,4),rr(7,26,32),start='所有这一切都以',fixes=[('对physis 的经验基础说明','对自然（physis）的一种以经验为基础的说明')])
add(rr(22,5),rr(7,33),text='亚里士多德进一步为原子论立场提供佐证，他论证道：')
add(rr(22,6)+rr(23,1),rr(7,33,36)+rr(8,0,1),'quote',start='事物既被认为',fixes=[('（驳斥不可分割线的理论并不困难。）','（驳斥不可分割线的理论并不困难。）')])
add(rr(23,2),rr(8,2),'heading')
add(rr(23,3),rr(8,3,13),text='亚里士多德在说明早期原子论者时写道：“元素或者是充实的，或者是空的，也可以分别称为存在或非存在”；原文为：“στοιχεῖα μὲν τὸ πλῆρες καὶ τὸ κενὸν εἶναί φασι, λέγοντες τὸ μὲν ὂν τὸ δὲ μὴ ὄν.”（《形而上学》A.4 985b5–6）这样，“非存在”就参与存在，因为它的在场是对构成物质的原子的掏空——kenosis。因此，虚无参与存在，却不是存在的起源；它毋宁嵌在主要被视为物质或自然（physis）的存在的核心之中。原子论者必须提出两个论点：存在是多重的，而空或虚空——空间的缺失，或任何东西的缺失——是物质现实的一个方面。这是在试图克服一种困境：遵守埃利亚法则，阻碍了对运动、变化、生成和衰亡问题的科学与哲学考察。这一尝试类似赫拉克利特的解决办法：“一”实际上是多；即使它几乎熄灭，也不会彻底熄灭，而会“按照一定的尺度”重新燃起，也就是遵循自然与存在的内在法则，亦即科学与本体论的法则。（DK22B30）原文为：κόσμον τόνδε, τὸν αὐτὸν ἁπάντων, οὔτε τις θεῶν οὔτε ἀνθρώπων ἐποίησεν, ἀλλ’ ἦν ἀεὶ καὶ ἔστιν καὶ ἔσται πῦρ ἀείζωον, ἁπτόμενον μέτρα καὶ ἀποσβεννύμενον μέτρα（DK22B30）。赫拉克利特假定存在几乎完全熄灭；与之不同，原子论者谈论的是原子内部的绝对虚空。',reason='按底本恢复希腊语，不用旧译合字或误替换的字符；作者关于原子内部虚空的论断照译。')
add(rr(23,4),rr(8,14,23),text='希腊哲学中理解运动的困难——并不只见于前苏格拉底思想家——在于它对运动的本体论定义：运动是存在与生成的问题，是从一种 ousia 转变为另一种 ousia。从纯粹本体论上说，这种运动似乎不可能，而且确实涉及存在从非存在中产生这一前提。存在过去存在、现在存在，而且将永远存在；生成是不可能的。运动很少被同空间、自然哲学，或关于物质行为的精确推理联系起来。即使前苏格拉底思想家，尤其是原子论者，确实建立了这种联系，空的空间也成为非存在的一种可能性，存在的充实与无限在场因而受到损害。梅利索斯认为，“空”——显然被理解为一个空间范畴——就是无：“因为虚空就是无”，原文为 τὸ γὰρ κενεὸν οὐδέν ἐστιν（DK 30B7.7）。为了使某物生成，就必须假定此前没有这种 ousia；为了使一种 ousia“位移”，便必须设想空间被腾空，它又在一个此前绝对空无的空间中重新出现；而那个空间被理解为非存在。亚里士多德在《物理学》中记述了原子论者对运动的这种理解：“这些人认为，虚空是一道间隙，非存在以可感物体的方式在其中存在。”（《物理学》IV.6 213a27–9）希腊文底本为：οἱ δὲ ἄνθρωποι βούλονται κενὸν εἶναι διάστημα ἐν ᾧ μηδέν ἐστι σῶμα ἰσθητόν。',reason='去除nothing未译残留；修复旧译“通过它像通过物体一样通过”的增译，保留作者英译与希腊原句的差异。')
rows[-1]['editor_note']='这里的中文引句依本书英文释义译出。书中所附希腊文的句意为“人们认为虚空是其中没有可感物体的间隔”，与其英文释义不完全相合；底本希腊词形 ἰσθητόν 照录，不静默改写。'
add(rr(24,1),rr(8,24,26))
add(rr(24,2),rr(8,27,28),end='nec porro')
add(rr(24,3,4),rr(8,28,33),'quote',text=extract(EN,rr(24,3,4),True),reason='拉丁引文逐字保留；后续单元另载作者使用的英译及其中文。')
add(rr(24,5),[],'paragraph','按照古典语文学的规范，这里使用原典的页边编号，以便在不同版本与译本之间查找对应位置。',reason='补回中文旧稿整句漏译。')
add(rr(24,6),rr(8,34,39)+rr(9,0,2),text='或者，依英译：“假如生命能从无中增长，万物的成长还需要空间吗？那样，小小的婴儿顷刻便会成为能行走的成人，枝繁叶茂的树也会突然从地上跃起——这些都是闻所未闻的奇迹；因为依自然之道，每一种东西都从合乎其规律的种子缓慢生长，并在这生长中保持自身的种类。”[[21]]伊壁鸠鲁派无需假设“原子包含虚空”便能解释运动与变化：原子是“坚实的”物质，而生长与衰亡遵循物质保存的法则：',reason='修复反问句被改为假设句、lawful seed误作“合法种子”；补原注21。')
add(rr(24,7,8),rr(9,2,10),'quote',text=extract(EN,rr(24,7,8),True),reason='保留原书拉丁引文及卷、行号。')
add(rr(24,9)+rr(25,1),rr(9,11,28),text='或者，依英译：“因此，原初物体是坚实的，内部没有虚空。但既然一切生成之物中都有虚空，坚实的物质就必然环绕着它。除非你承认那容纳虚空的东西本身是坚实的，否则便无法凭正确的推理证明：某物在自己的躯体中隐藏着、容纳着虚空。须知，能够将虚空容纳在事物之中的，只能是结合在一起的物质。”[[22]]为了使物质在其有限或受限却无界的存在中不断运动与生长[[23]]——因为存在之外别无所有，那里是无，因而无法在物质现实领域之外找到它——就需要空间，也需要物质宇宙内部所包含的虚无：“如此广袤的空间向万物四周敞开——各个方向都有余地，没有尽头。最后，我们亲眼可见，事物界定着事物：空气隔开山丘，山峦又围住空气；陆地终结海洋，海洋反过来又界定所有陆地；然而，对于全体而言，确实没有任何东西能从外部为它划定边界。”[[24]]',reason='补原注22、23，修复huge abundance在空间论述中的含义；保留作者finite yet unbound的表述。')
add(rr(25,2),rr(9,29,32),end='或由自身重量',fixes=[('理想的“垂直运动”','理想的“垂直向下运动”')],reason='downright含向下方向；将后续引文独立。')
add(rr(25,3),rr(9,32,38),'quote',text='它们或者由自身的重量推动，或者偶然受到外来的撞击而运动。它们在不停的运动中频繁相遇、碰撞，便会猛然彼此弹开、相向而去；这并不奇怪——因为它们极其坚硬，具有坚实的重量，而且身后没有什么阻碍它们的运动。（卢克莱修·卡鲁斯，《物性论》第2卷，83–88）[[25]]',reason='修复旧译漏掉Being most hard的因果关系，恢复独立引文。')
add(rr(25,4),rr(9,39,43),end='也没有任何地方，')
add(rr(25,5),rr(9,43)+rr(10,0,5),'quote',start='也没有任何地方，')
add(rr(25,6),rr(10,6),text='或依原文：')
add(rr(25,7),rr(10,6,12),'quote',text=extract(EN,rr(25,7),True),reason='拉丁原文照底本保留；不静默把com改成cum。')
add(rr(25,8)+rr(26,1),rr(10,13,21),end='在光线所照的虚空中，',fixes=[('那种不产生任何东西的虚无','那种使变化成为可能、却不产生任何东西的虚无'),('原子所构成的、本应坚实的物质中','除此以外皆为坚实物质的原子之间')],reason='补enabling限定；otherwise并非应然。')
add(rr(26,2),rr(10,21,29),'quote',text='在光线所照的虚空中，它们不断战斗，仿佛永恒争斗；成队交锋，毫不停歇，在相遇与分离中上下奔忙。由此你便可推想，原初种子在更大的虚空中不停颠簸，究竟是怎样的情形——至少在这限度之内。（卢克莱修·卡鲁斯，第2卷，118–123）',reason='旧译合并了英文节选与较长拉丁文，且卷行号改成116—124；分别恢复作者两版引文。')
add(rr(26,3),[],text='或依原文：',reason='补回因合并引文而漏掉的说明。')
add(rr(26,4),[],'quote',text=extract(EN,rr(26,4),True),reason='补回整段漏掉的拉丁原文（第2卷116—124行）。')
add(rr(26,5)+rr(27,1),rr(10,30,37),fixes=[('不是存在论现实','不是一种作为存在者的实在'),('“操作者”','“运算子”')],reason='区分ontological概念与ontic实在；operator按此处作用机制译为“运算子”。')
rows[-1]['editor_note']='底本末句使用 special position；按上下文译为空间位置（spatial position），英文保留 special。关于虚空与反粒子的类比是作者的论述，未替作者作科学事实上的更正。'

# Notes: retain complete source, including the substantial text omitted by the supplied PDF.
groups=note_groups([[244,4],[245,1],[246,1]])
assert [n for n,r in groups]==list(range(1,27))
ztext='\n'.join(normzh(''.join(s['text'] for l in b['lines'] for s in l['spans'])) for p in ZH[130:132] for b in p['blocks'])
ztext=ztext.split('第2 章',1)[1].split('第3 章',1)[0]
zn={int(m[1]):m[2].replace('\n','') for m in re.finditer(r'(?m)^(\d+)\.\s*(.*?)(?=\n\d+\.\s|\Z)',ztext,re.S)}
nt={
1:'“西方”通常与“欧洲”同义使用，并意在涵盖欧洲的跨大西洋延伸部分。我们选择使用“欧洲”，因为它对欧洲东南部和东部的排斥性较小，尤其是因为这一地理范围发挥作用的时间，远远长于其西方化的变体。伊斯兰哲学与数学对于其历史延续和科学进步都有关键影响。此外，我们在这里将哲学与欧洲哲学等同，因为我们赞同弗朗索瓦·拉吕埃勒，认为哲学是一种欧洲特有的现象；这并不否认阿拉伯文化对其保存和发展的贡献，事实上还将这种贡献包含在内。',
2:'亚里士多德：《物理学》，载《亚里士多德全集》，R. P. Hardie、R. K. Gaye 译，第2卷（普林斯顿大学出版社，1984），第315–446页；参见 WilliamDavid Ross 编，Aristotelis Physica，Clarendon Press（牛津大学出版社，1950），200b33–201a3。',
3:'请注意，对于古典文本，我们使用原典的页边编号，因为这种编号可以跨越版本和语言得到普遍辨识。',
4:'Joan Kung：“亚里士多德论‘存在以多种方式被述说’”（Aristotle on “Being Is Said in Many Ways”），History of Philosophy Quarterly，第3卷第1期（1986），第3–18页。',
5:'Walther Kranz、Hermann Diels：《前苏格拉底哲学家残篇》（Die Fragmente der Vorsokratiker），第3卷（Weidmann，1952）。本文行内引用将其缩写为 DK，使用原出版物（以及后续所有版本）所采用的页边编号。',
6:'柏拉图：《斐多篇》（Phaedo），C. J. Rowe 编订并作评注，Christopher J. Rowe 编（剑桥大学出版社，1992）。行内引文采用国际通行的柏拉图原典页码编号。',
7:'Peter Wolfendale：《面向对象的哲学：物自身的新衣》（Object-oriented Philosophy: The Noumenon’s New Clothes），第1卷（MIT Press，2019）。',
8:'Wilfrid Sellars：《科学、知觉与实在》（Science, Perception, and Reality）（Routledge & Kegan Paul，1963），第1–40页。',
9:'Georg Wilhelm Fredrich Hegel，Georg Wilhelm Friedrich Hegel: The Science of Logic，A. V. Miller 译（牛津大学出版社，1977），第82页。',
10:'“这种自我抽象、被固定为自为的实体，就是作为抽象利己主义者的人——即在其纯粹抽象中被提升到思想层面的利己主义。”（Karl Marx、Friedrich Engels：《1844年经济学哲学手稿与共产党宣言》，The Economic and Philosophic Manuscripts of 1844 and the Communist Manifesto，Prometheus Books，2009，“对黑格尔哲学的一般批判”。）',
11:'Karl Marx、Friedrich Engels、W. Lough，Theses On Feuerbach Ludwig Feuerbach and the End of Classical German Philosophy（1845），无页码：“以往一切唯物主义——包括费尔巴哈的唯物主义——的主要缺点是：对事物、现实、感性，只从客体或直观的形式去理解，而不是把它们理解为人的感性活动、实践，不从主体方面去理解。因此，与唯物主义相反，能动的方面被唯心主义抽象地发展了；当然，唯心主义并不知道现实的、感性的活动本身。”',
12:'马克思、恩格斯：《1844年经济学哲学手稿与共产党宣言》（The Economic and Philosophic Manuscripts of 1844 and the Communist Manifesto）：“对黑格尔哲学的一般批判”。',
13:'Rosi Braidotti、Maria Hlavajova：《后人类术语表》（Posthuman Glossary）（Bloomsbury Publishing，2018）。',
14:'亚里士多德：《物理学》。',15:'亚里士多德。',
16:'亚里士多德，Aristotelis Opera，Immanuelis Bekkeri、Olof Gigon、Hermann Bonitz 编（Walter de Gruyter，1970）。',
17:'《形而上学》ν.2，1089a15–19：ἔπειτα ἐκ ποίου μὴ ὄντος καὶ ὄντος τὰ ὄντα; πολλαχῶς γὰρ καὶ τὸ μὴ ὄν, ἐπειδὴ καὶ τὸ ὄν· καὶ τὸ μὲν μὴ ἄνθρωπον σημαίνει τὸ μὴ εἶναι τοδί, τὸ δὲ μὴ εὐθὺ τὸ μὴ εἶναι τοιονδί, τὸ δὲ μὴ τρίπηχυ τὸ μὴ εἶναι τοσονδί.〔中译：再者，存在者来自哪一种非存在与存在？非存在也有多种说法，因为存在亦然：“非人”表示不是这个，“非直”表示不是如此这般，“非三肘长”表示不是这样大的量。〕',
18:'此处以及下文对原典的翻译均出自我本人。',
19:'亚里士多德：“论生成与消灭”（On Generation and Corruption），载《亚里士多德全集》，Harold H. Joachim 译（普林斯顿大学出版社，2014）。',
20:'Titus Lucretius Carus，De rerum natura Volume primo（Libri I–III），Marcus Deufert 编（de Gruyter GmbH，2019）。',
21:'Titus Lucretius Carus：《物性论》（On the Nature of Things），William Ellery Leonard 译，取自古腾堡计划，发布日期2008年7月31日［电子书第785号］，最后更新于2013年2月4日，访问于2021年4月。本书对该书的所有引文均取自这一译本。引用时不使用译本页码，而遵循古典文献规范，使用原典页边编号，以确保准确定位原文并便于与其他译本比较。',
22:'如前所述，译文取自 Titus Lucretius Carus：《物性论》（On the Nature of Things），William Ellery Leonard 译，古腾堡计划，发布日期2008年7月31日［电子书第785号］，最后更新于2013年2月4日，访问于2021年4月。本书对该书的所有引文均取自这一译本。引用时不使用译本页码，而遵循古典文献规范，使用原典页边编号，以确保准确定位原文并便于与其他译本比较。',
24:'译文取自 Titus Lucretius Carus：《物性论》（On the Nature of Things），William Ellery Leonard 译，古腾堡计划，发布日期2008年7月31日［电子书第785号］，最后更新于2013年2月4日，访问于2021年4月。本书对该书的所有引文均取自这一译本。引用时不使用译本页码，而遵循古典文献规范，使用原典页边编号，以确保准确定位原文并便于与其他译本比较。',
25:'与注24相同，我们使用 William Ellery Leonard 的译文，并按原典页边编号引用。',
26:'原始来源与以上引文相同。'}
notes=[]
for num,refs in groups:
    en=extract(EN,refs,True)
    if num==23:
        latin=en.split('In the Latin original: ',1)[1].split(', or in English',1)[0]
        nt[num]='拉丁文原文：'+latin+'。至于英文，这里破例使用 Martin Ferguson Smith 的译文，因为它更便于同拉丁原文逐行对照：“再假定一切现存的空间是有限的，有人跑到其最远边缘，将一支矛掷出去：你认为这支用强劲力量掷出的矛会远飞并抵达目标，还是认为会有什么东西挡住它的去路，使它停下？你必须认可并选择这两种假设中的一种，但二者都会堵住你的退路，迫使你承认宇宙的广延是无限的。因为，无论有什么东西挡住长矛，使它无法击中并留在目标上，还是它继续飞行，它都不是从宇宙的尽头出发的。我就这样紧追着你：无论你把最远边界设在哪里，我都会追问长矛最终怎样了。我们的结论是，任何地方都不能固定一条边界；面对飞行的无限可能性，永远无从逃避。”（第1卷，968–991）引自 Lucretius：《物性论》（On the Nature of Things），Martin Ferguson Smith 译并作导论与注释（Hackett Publishing Company，1969）。'
    notes.append({'id':f'dm-ch02-note-{num}','kind':'note','note_number':num,'source_blocks':refs,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,a,z in refs)),'en':en,'supplied_zh':zn.get(num,''),'zh':str(num)+'. '+nt[num],'status':'text_compared_layout_pending','revision_reason':'对照完整原注校订；保留书目信息，不沿用缩写造成的遗漏。'})
    if num==23:notes[-1]['revision_reason']='旧稿将大段拉丁文及整段英文引文缩成省略号和书目；现完整恢复拉丁文，并补全引文中文。'
    if num in [2,6,9,11,17,23]:notes[-1]['editor_note']='书目信息、卷行号及原文拼写依底本保留；未独立查证所有引文版本。'
expected=[r for p in range(16,28) for r in rr(p,0 if p==16 else 1,max(b['block'] for b in EN[p-1]['blocks']))]
save('ch02',2,rows,notes,expected)
