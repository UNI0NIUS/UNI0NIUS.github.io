const fs=require('fs'),path=require('path'),katex=require('./webdeps/node_modules/katex');
const dir=path.resolve(__dirname,'../github-sync/translations/books/defending-materialism');
const errors=[];let count=0;
function walk(tokens,where){for(const t of tokens||[]){if(typeof t==='string')continue;if(t.type==='math'){count++;try{katex.renderToString(t.tex,{displayMode:!!t.display,throwOnError:true,trust:false,strict:'ignore'});}catch(e){errors.push({where,tex:t.tex,error:e.message});}}walk(t.children,where);for(const row of t.rows||[])for(const c of row)walk(c,where);}}
for(const f of fs.readdirSync(dir).filter(f=>f.endsWith('.json'))){const d=JSON.parse(fs.readFileSync(path.join(dir,f)));for(const r of d.body||[])for(const l of ['en','zh'])walk(r[l],r.id+':'+l);for(const [id,n] of Object.entries(d.notes||{}))for(const l of ['en','zh'])walk(n[l],id+':'+l);}
fs.writeFileSync(path.resolve(__dirname,'../Defending Materialism/work/site_math_audit.json'),JSON.stringify({formulaOccurrences:count,errors},null,2));console.log(JSON.stringify({formulaOccurrences:count,errors},null,2));if(errors.length)process.exitCode=1;
