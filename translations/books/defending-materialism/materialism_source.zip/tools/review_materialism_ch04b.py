from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch04-{len(rows)+13:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(71,2),rr(32,40)+rr(33,0,5),end='我们第一次')
add(rr(71,3),rr(33,5,10),'quote',start='我们第一次')
add(rr(71,4),rr(33,11,15),end='如果我们从人口')
add(rr(71,5)+rr(72,1),rr(33,15,19),'quote',start='如果我们从人口',fixes=[('混沌概念［Vorstellung］','混沌表象［Vorstellung］'),('进一步的限定','进一步的规定'),('最简单的限定','最简单的规定'),('一个由众多规定性和关系的丰富总体','一个由众多规定性和关系构成的丰富总体')],reason='保留Vorstellung与Begriff（表象与概念）的区分，统一determination为规定，修复漏词。')
add(rr(72,2),rr(33,20,31),fixes=[('根本二元对立','根本二元组'),('根本二元对','根本二元组'),('指涉行为','意指行为'),('{•,•}','{■,▫}'),('余辉（Yuk Hui）','许煜（Yuk Hui）')],reason='dyad不预先蕴含对立关系；恢复两个不同方块符号，旧译两个相同圆点破坏论证；统一人名。')
add(rr(72,3),rr(33,32,36),end='自然的终极目标',fixes=[('许辉','许煜'),('余辉','许煜'),('转瞬之间','总是已经'),('这在本质上就是偶然的','这在本性上是偶然的')],reason='always already不是时间短暂而是总是已经；统一人名。')
add(rr(72,4),rr(33,36,39),'quote',start='自然的终极目标',fixes=[('A⇒B⇒C⇒A','A→B→C→A')],reason='保留原文递归箭头。')
add(rr(72,5)+rr(73,1),rr(33,40,42)+rr(34,0,17),fixes=[('机械论与唯物主义相互制约','机械性与唯物主义互为条件'),('科克肖特在此提及图灵关于“机械性”的章节，以及关于图灵的论文','Cockshott Turing在此指向他关于“机械性”的章节，以及关于图灵的论文'),('作为科学萌芽时期的思想推动者','作为推动思想的前科学动力'),('任何形而上学问题都具有现实意义','任何形而上学问题都有相关性'),('机械论——通常与原子论相结合','机械性——通常与原子论相结合'),('原理或“阿卡伊”','原理或始原')],reason='mechanicity与mechanicism并非同一词；保留底本括号中未清理的编写提示并校注，不捏造图灵撰写本书章节。')
rows[-1]['editor_note']='英文括号“Cockshott Turing refers to his chapter here on Mechanicity plus the paper/s on Turing”形似未清理的编写提示，按底本保留；原注16实际列科克肖特讨论图灵的文章。本文其他作者可能对“形而上学”采用不同定义，这是本段原作者明确指出的差异。'
add(rr(73,2),rr(34,18,21),'quote',fixes=[('亦未从主观角度加以理解','亦未从主体方面加以理解')],reason='subjectively在此与实践和能动性相连，避免仅作主观意见理解。')
add(rr(73,3),rr(34,22,24))
nt={12:'费迪南·德·索绪尔：《普通语言学教程》（Course in General Linguistics），Wade Baskin译，Charles Bally与Albert Reidlinger编（Philosophical Library，1959），第53页。',13:'卡尔·马克思：《政治经济学批判大纲》（Grundrisse: Outlines of the Critique of Political Economy），Martin Nicolaus译（Penguin Books，1973），第41页。',14:'拉鲁埃尔：《哲学与非哲学》（Philosophy and Non-Philosophy），第91—126页。',15:'许煜（Yuk Hui）：《递归性与偶然性》（Recursivity and Contingency）（Rowman & Littlefield International，2019），第41页。',16:'Paul Cockshott：“图灵：唯物主义闯入思想”（Turing: The Irruption of Materialism into Thought），Oxford University Press’s Blog: Academic Insights for the Thinking World（2012），https://blog.oup.com/2012/06/turing-the-irruption-of-materialism-into-thought/（访问日期：2021年11月27日）。',17:'Katerina Kolozova：《走向社会主义的激进形而上学：马克思与拉鲁埃尔》（Toward a Radical Metaphysics of Socialism: Marx and Laruelle）（Punctum Books，2015），第8—10页。',18:'卡尔·马克思：《关于费尔巴哈的提纲》，W. Lough自德文译出（Progress Publishers，1969），无页码，https://www.marxists.org/archive/marx/works/1845/theses/theses.htm（访问日期：2019年3月22日）。本引文取自无页码的在线来源。'}
notes=[]
for n,refs in note_groups([[250,1],[251,1]]):
    if n not in nt:continue
    en=extract(EN,refs,True).replace('\u200b','').replace('https:// blog','https://blog').replace('/theses /theses','/theses/theses')
    notes.append({'id':f'dm-ch04-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':list(dict.fromkeys(str(x[0]-9) for x in refs)),'en':en,'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
    if n==15:notes[-1]['editor_note']='正文将题名写作Contingency and Recursivity，原注作Recursivity and Contingency，正文与原注各按底本保留。'
expected=rr(71,2,5)+rr(72,1,5)+rr(73,1,3)
save('ch04b',4,rows,notes,expected)
(W/'checkpoint_ch04b.json').write_text(json.dumps({'next_source_pdf_page':74,'next_source_block':1,'next_supplied_pdf_page':34,'next_supplied_block':25,'next_unit':len(rows)+13,'next_note':19,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
