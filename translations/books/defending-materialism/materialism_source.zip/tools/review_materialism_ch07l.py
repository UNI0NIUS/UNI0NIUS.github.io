from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch07-{len(rows)+173:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(176,3),rr(91,26,27)+rr(92,0))
add(rr(176,28,29),rr(92,5,9),'table',text='表7.5 幂集',english=extract(EN,rr(176,28),True),reason='原图空集{}被旧译误成{1}，逐项恢复幂集元素及省略行。')
tab=[['{1}','1','{{},{1}}','2'],['{1,2}','2','{{},{1},{2},{1,2}}','4'],['{1,2,3}','3','{{},{1},{2},{3},{1,2},{1,3},{2,3},{1,2,3}}','8'],['…','','','']]
rows[-1]['table']={'headers_en':['set','ordinality','power set','cardinality'],'headers_zh':['集合','序数','幂集','基数'],'rows_en':tab,'rows_zh':tab}
rows[-1]['table']['column_weights']=[.65,.55,2.25,.55]
add(rr(176,4),rr(92,1,4),text=r'幂集的基数总大于原集合，即成员更多：N个元素的集合，其幂集有$2^N$个元素。特别地，若整数集基数为$\aleph_0$，则整数幂集基数为$2^{\aleph_0}$，记作$\aleph_1$（aleph一）。因此，整数的幂集不可数，因为$\aleph_1$必然大于$\aleph_0$。康托尔随后证明，实数集也有基数$\aleph_1$。',english=r'A power set always has greater cardinality, that is, more members, than the original set: for a set of N elements, the power set has $2^N$ elements. In particular, if the set of integers has cardinality $\aleph_0$, then the power set of integers has cardinality $2^{\aleph_0}$, denoted $\aleph_1$ (aleph one). Thus, the powerset of integers is uncountable, as $\aleph_1$ is necessarily bigger than $\aleph_0$. Cantor then demonstrated that the set of real numbers also has cardinality $\aleph_1$.',reason='恢复幂指数与aleph，保留底本命题并另加校注。')
rows[-1]['editor_note']='底本将2^{ℵ₀}与ℵ₁直接等同并称康托尔证明实数基数为ℵ₁；这涉及连续统假设，不能作为一般集合论中已证明的结论。正文保留作者说法。'
add(rr(176,5),rr(92,10,11))
save('ch07l',7,rows,[],rr(176,3,5)+rr(176,28,29))
(W/'checkpoint_ch07l.json').write_text(json.dumps({'next_source_pdf_page':178,'next_source_block':0,'next_supplied_pdf_page':92,'next_supplied_block':12,'next_chapter':8,'next_note':1,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
