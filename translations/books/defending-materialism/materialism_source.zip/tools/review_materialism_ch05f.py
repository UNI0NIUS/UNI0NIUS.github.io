from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch05-{len(rows)+78:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(92,4,6),rr(44,4,5),text=r'因此，如果发生$\frac{1}{4}$英担谷物＝$x$英担铁这样的交换，双方就包含了同样数量的某种东西：这就是牛顿的原理，即作用会产生大小相等、方向相反的反作用。',english=r'So, if an exchange takes place between $\frac{1}{4}$ cwt of corn = $x$ cwt Iron both sides contain the same amount of something: Newton’s principle of action producing an equal and opposite reaction.',reason='旧译将四分之一漏为一；根据源图恢复分数，统一谷物及英担。')
add(rr(92,7),rr(44,6,8),fixes=[('\\pi r^2',r'$\pi r^2$')],english=extract(EN,rr(92,7),True).replace('πr[[2]]',r'$\pi r^2$'))
add(rr(92,8),rr(44,9,11),text='交换价值的形式是经验观察所得的。马克思从这一观察的性质推导出，这里存在一个守恒过程。在等价物的交换中，有某种实体——价值——保持守恒。这与牛顿从相互碰撞的摆的运动形式推导出运动守恒（用我们今天的话说，就是动量守恒）相对应。',reason='保留原文motion与现代术语momentum的区别，旧译把两者都译作动量。')
e=extract(EN,rr(92,9),True)
e=e.replace('a a ≡',r'$a\equiv a$').replace('a b b a and transitive a b b c a c , .',r'$a\equiv b\Rightarrow b\equiv a$ and transitive $a\equiv b,b\equiv c\Rightarrow a\equiv c$.')
add(rr(92,9),rr(44,12,16),end='B. 价值',fixes=[('（a\\equiv a）',r'（$a\equiv a$）'),('（a\\equiv b\\Rightarrow b\\equiv a）',r'（$a\equiv b\Rightarrow b\equiv a$）'),('（a\\equiv b,b\\equiv c\\Rightarrow a\\equiv c）',r'（$a\equiv b,b\equiv c\Rightarrow a\equiv c$）')],english=e)
add(rr(92,10),rr(44,16,17),'quote',start='B. 价值',fixes=[('价值的总形式或扩展形式','总和的或扩大的价值形式'),('[[4]] [[1]]','[[41]]')])
add(rr(92,11),rr(44,18),fixes=[('a\\equiv b\\Rightarrow b\\equiv a',r'$a\equiv b\Rightarrow b\equiv a$')],english=extract(EN,rr(92,11),True).replace('a b b a',r'$a\equiv b\Rightarrow b\equiv a$'))
rows[-1]['editor_note']='底本此处称reflexivity（自反性），但所列蕴含式表达的是对称性；译文保留底本用词，不静默更改。'
add(rr(92,12)+rr(93,1),rr(44,19,24),'quote',fixes=[('扩展的相对价值形式','扩大的相对价值形式'),('基本相对表达式或方程','简单的相对价值表达式或等式'),('[[4]] [[2]]','[[42]]')])
add(rr(93,2),rr(44,25))
rows[-1]['editor_note']='底本此处称symmetry（对称性），但所列同一商品等于自身的式子表达的是自反性；这与上一段的术语倒置均按底本保留并说明。'
add(rr(93,3),rr(44,26,29),fixes=[('等价关系是能量守恒的指标','等价关系是守恒的标志'),('某种抽象第三种事物','某种抽象的第三种东西'),('共同物质','共同实体')],reason='原文conservation未限定为能量守恒；substance在论证中译实体，避免预先限定为物质。')
nt={41:'马克思：《资本论》，第42页。',42:'马克思：《资本论》，第43页。'}
notes=[]
for n,refs in note_groups([[254,2,9,11]]):
    notes.append({'id':f'dm-ch05-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['245'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch05f',5,rows,notes,rr(92,4,12)+rr(93,1,3))
(W/'checkpoint_ch05f.json').write_text(json.dumps({'next_source_pdf_page':93,'next_source_block':4,'next_supplied_pdf_page':44,'next_supplied_block':30,'next_unit':len(rows)+78,'next_note':43,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
