from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch06-{len(rows)+166:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(157,1,12),rr(79,22,25),text=r'玻尔的解释是，在表达式$\frac{1}{\sqrt{2}}|L\rangle+\frac{1}{\sqrt{2}}|R\rangle$中，右矢前的振幅系数$\frac{1}{\sqrt{2}}$表示在这条路径上发现光子的概率的平方根。这显然与经典解释一样符合实验。无论为$\frac{1}{\sqrt{2}}$赋予何种本体论含义，$\left(\frac{1}{\sqrt{2}}\right)^2$仍意味着亮度是原来的$\frac{1}{2}$。',english=r'The Bohr interpretation is that the $\frac{1}{\sqrt{2}}$ amplitude coefficients in front of the kets in the expression $\frac{1}{\sqrt{2}}|L\rangle+\frac{1}{\sqrt{2}}|R\rangle$ express the square root of the probability that the photon will be found going down this path. This clearly fits the experiment just as well as the classical account. Whatever ontological semantics you associate it with the $\frac{1}{\sqrt{2}}$, $\left(\frac{1}{\sqrt{2}}\right)^2$ is still $\frac{1}{2}$ as bright.',reason='据原图恢复根号与平方；删除旧译把概率平方根又等同于概率的重复误述。')
add(rr(157,13),rr(79,26,29))
add(rr(157,14),rr(79,30,32)+rr(80,0))
add(rr(157,15),rr(80,1,2))
add(rr(157,16),rr(80,3,7),text='玻尔的这一表述并没有内在的唯心主义性质。如果一个人是严格的唯物主义者，承认存在的一切就是原子以及原子借以交换力和能量的光子，[[60]]那么谈论光子在两次影响原子之间的位置，就成了没有意义的唯心主义。我们可能愿意想象光子在发射与吸收之间具有一个位置，但那只是想象，只是在头脑中构造一幅观念图景。既然光子和原子是实在的基本组成部分，那么，独立于原子相互作用的、观念中的光子位置，按定义就是不真实的。',reason='补漏注60；ideal picture/position在此是观念图景/位置，不是理想位置。')
add(rr(157,17)+rr(158,1),rr(80,8,12),text='但海森堡的解释确实可能引向唯心主义的解释，如今常称为哥本哈根诠释。[[61]]按照这种解释，正是认识主体即观察者的参与，使波函数坍缩并出现一个确定的结果。海森堡[[62]]声称：“当‘客观实在’这样的概念用于原子物理学中的情形时，它们并没有不言自明的含义。”赋予观察者的心理体验以特权地位，这看起来很像回到马赫式实证主义；在他受训练的年代，这种思潮曾深刻影响德国物理学。',reason='补漏注61、归位62，immediately evident译不言自明而非立即可见。')
add(rr(158,2),rr(80,13,14),fixes=[('当廖等人','当廖等人[[63]]')],reason='补漏注63。')
add(rr(158,3),rr(80,15,17))
add(rr(158,4),rr(80,18),text='抑或我们只应承认，哲学意义上的主体[[64]]与理解这类工程技术无关？',reason='补漏注64。')
nt={60:'或者用更符合当代的说法：基本粒子和玻色子。',61:'Howard（“谁发明了‘哥本哈根诠释’？一项神话研究”）认为，哥本哈根诠释这个术语是海森堡在1955年的一篇论文中发明的：Werner Heisenberg，“量子理论诠释的发展”（The Development of the Interpretation of the Quantum Theory），Niels Bohr and the Development of Physics，1955，第12页。在文中，他试图把自己的观点投射到丹麦人玻尔身上：1955年的新情况，是海森堡把他混合起来的一套思想命名为“哥本哈根诠释”；一经这样命名，他便经常强化这种统一的哥本哈根观点的发明，并以其主要代言人自居（例如见Heisenberg [1955]）。为什么？回想海森堡1955年的处境会有所帮助：这位20世纪20年代曾深受玻尔喜爱的人，在战后却成为被哥本哈根核心圈从道义上排斥的人，主要因为1941年9月他接掌德国原子弹计划之后访问哥本哈根，那次不幸的访问使他与玻尔的关系严重破裂。对于骄傲而曾雄心勃勃的海森堡来说，还有什么办法比让自己成为哥本哈根诠释的声音更适合重获这个家族的成员身份呢？Howard：“谁发明了‘哥本哈根诠释’？一项神话研究”（Who Invented the “Copenhagen Interpretation”? A Study in Mythology）。',62:'Heisenberg：“量子理论诠释的发展”（The Development of the Interpretation of the Quantum Theory），第23页。',63:'Liao等：“卫星到地面的量子密钥分发”（Satellite-to-ground Quantum Key Distribution）。',64:'进一步讨论见第[sec:altsub]??节。'}
notes=[]
for n,refs in note_groups(rr(262,1))+note_groups(rr(262,3)):
    if n not in nt:continue
    if n==61:refs=refs+rr(262,2)
    notes.append({'id':f'dm-ch06-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['253'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
    if n==64:notes[-1]['editor_note']='底本交叉引用未解析，显示为[sec:altsub]??；保留，不猜填节号。'
save('ch06m',6,rows,notes,rr(157,1,17)+rr(158,1,4))
(W/'checkpoint_ch06m.json').write_text(json.dumps({'next_source_pdf_page':158,'next_source_block':5,'next_supplied_pdf_page':80,'next_supplied_block':19,'next_unit':len(rows)+166,'next_note':65,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
