from materialism_common import *
groups=[]
for b in EN[272]['blocks'][1:]:
    for j,l in enumerate(b['lines']):
        if l['bbox'][0]<60:groups.append([])
        groups[-1].append([273,b['block'],j,j+1])
assert len(groups)==18,len(groups)
oldrefs=[rr(153,30,34),rr(153,35,37),rr(153,38,39),rr(154,0,1),rr(154,2),rr(154,3,4),rr(154,5),rr(154,6),rr(154,7,8),rr(154,9,11),rr(154,12),rr(154,13,14),rr(154,15,16),rr(154,17,18),rr(154,19,20),rr(154,21,22),rr(154,23,24)]
oldrefs.append(rr(154,25,26))
translations=[
'Anellis, Irving H.：“苏联的形式逻辑与辩证唯物主义：评Fania Cavaliere《苏联的形式逻辑：1946—1965年的论争时期》与A. R. D. Mathias〈逻辑与恐怖〉”。Modern Logic 4，第2期（1994）：210—218。https://projecteuclid.org/journals/review-of-modern-logic/volume-4/issue-2/Formal-logic-and-dialectical-materialism-in-the-Soviet-Union/rml/1204835224.full。',
'阿基米德：《阿基米德著作集：采用现代记号编订，附导论各章》。Thomas L. Heath编。Cambridge Library Collection—Mathematics。Cambridge University Press，2009。https://doi.org/10.1017/CBO9780511695124。',
'亚里士多德：《亚里士多德著作集》（Aristotelis opera）。Immanuelis Bekkeri、Olof Gigon、Hermann Bonitz编。Walter de Gruyter，1970。',
'亚里士多德：1152004155750“论生成与消灭”。载《亚里士多德全集》，Harold H Joachim译。Princeton University Press，2014。',
'亚里士多德：《解释篇》。H. P. Cook译。Loeb Classical Library。William Heinemann，1962。',
'亚里士多德：“物理学”。载《亚里士多德全集》，R. P. Hardie、R. K. Gaye译，第2卷，315—446。Princeton University Press，1984。',
'亚里士多德：《前分析篇》。H. Tredennick译。Loeb Classical Library。William Heinemann，1962。',
'亚里士多德：《修辞术》。J. H. Freese译。Loeb Classical Library。William Heinemann，1926。',
'亚里士多德：《形而上学》，第I—IX卷。H. Tredennick译。Loeb Classical Library。William Heinemann，1933。',
'Bächtold, Manuel：“捍卫马赫的原子观”。Journal for General Philosophy of Science / Zeitschrift für allgemeine Wissenschaftstheorie 41，第1期（2010）：1—19。ISSN：09254560、15728587。http://www.jstor.org/stable/20722524。',
'弗朗西斯·培根：《新工具》（Novum Organon）。J. Devey编。P. F. Collier & Son，1901。',
'弗朗西斯·培根：《新工具，或解释自然的正确指引》。第1卷。Library of Alexandria，1863。',
'阿兰·巴迪欧：《模型的概念：数学唯物主义认识论导论》。Z. L. Fraser、T. Tao译。re.press，2007。',
'Barrie, Peter、Paul Cockshott、George J. Milne、Paul Shaw：“高度并发机器的设计与验证”。Microprocessors and Microsystems 16，第3期（1992）：115—123。',
'Bartkus, James R.、M. Kabir Hassan：“伊本·赫勒敦与亚当·斯密：对劳动分工理论及现代经济思想的贡献”。载International Conference on Ibn Khaldun，Madrid，2006。',
'Bazhanov, Valentin：“复兴：S. A. Yanovskya的逻辑学道路”。History and Philosophy of Logic 22，第3期（2001）：129—133。',
'Bennett, Rachel R.、Ramin Golestanian：“衣藻趋光性的转向机制”。Journal of The Royal Society Interface 12，第104期（2015）：20141164。',
'John D. Bernal：“辩证唯物主义”。载《辩证唯物主义的诸方面》，Levy, Hyman、John MacMurray、Ralph Fox、Robert Page Arnott、John D. Bernal、Edgar F. Carritt编，89—122。Watts & Co.，1934。'
]
rows=[{'id':'dm-refs-title','kind':'chapter','source_blocks':rr(273,0),'supplied_translation_blocks':rr(153,29),'printed_pages':['264'],'en':'REFERENCES','zh':'参考文献','supplied_zh':extract(ZH,rr(153,29)),'status':'text_compared_layout_pending'}]
for i,(refs,zrefs,zh) in enumerate(zip(groups,oldrefs,translations),1):
    en=extract(EN,refs,True).replace('\u200b','')
    if i==1:en=en.replace('Formal -logic','Formal-logic').replace('-the- Soviet','-the-Soviet')
    row={'id':f'dm-ref-{i:03}','kind':'bibliography','source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['264'],'en':en,'zh':zh,'supplied_zh':extract(ZH,zrefs),'status':'text_compared_layout_pending','revision_reason':'按源书逐条核对书目信息，补译题名；作者、期刊和出版社保留可检索写法。'}
    if i==1:row['source_transcription_note']='移除URL中的零宽字符与排版换行空格；原始span保留。'
    if i==4:row['editor_note']='原书在篇名前印有数字串1152004155750，现成稿未保留；此处照录，不将其当作题名或出版日期。'
    if i==17:row['editor_note']='英文题名中的Chlamy- Domonas为原书写法；中文按衣藻译出。'
    rows.append(row)
save('refs01',12,rows,[],rr(273,0,18))
(W/'checkpoint_refs01.json').write_text(json.dumps({'next_source_pdf_page':274,'next_source_block':1,'next_supplied_pdf_page':154,'next_supplied_block':27,'next_reference':19,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
