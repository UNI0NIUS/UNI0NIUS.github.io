from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch10-{len(rows)+1:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(214,0,1),rr(112,0),'chapter',text='第10章 语言、自动机与意义',english='Chapter 10: LANGUAGE, AUTOMATA AND MEANING')
rows[-1]['source_transcription_note']='恢复章节标题阅读顺序。'
add(rr(214,2),rr(112,1),'heading',text='语言与意义')
add(rr(214,3),rr(112,2,3),text='长期以来，人们一直区分陈述的意义的两个方面：它的值，以及它所谈论的内容。这些区别可以称为指称与涵义、指谓与含蕴，以及外延与内涵。',reason='恢复reference/sense、denotation/connotation、extension/intension三组区分，避免旧译重复外延内涵与生硬内包。')
add(rr(214,4),rr(112,4),text='考虑对一个数的描述：')
add(rr(214,5),rr(112,4),'quote',text='比二多一')
add(rr(214,6),rr(112,5,6),text='它的外延意义来自将它求得一个值：三。另一种说法是，外延意义就是所有能在下列陈述中替换“那个数”、',reason='修复旧译句子破碎，保留替换槽位。')
add(rr(214,7),rr(112,6),'quote',text='那个数比二多一')
add(rr(214,8),rr(112,7),text='并保持陈述为真的东西。也就是说，我们把“那个数”当作变量，其唯一有效的值是“三”。')
add(rr(214,9),rr(112,8),text='现在考虑对一个数的描述：')
add(rr(214,10),rr(112,8),'quote',text='六的一半')
add(rr(214,11),rr(112,9,11),text='它的外延意义也是三。但这两个陈述的内涵意义很不一样：前者涉及计数，后者涉及除法。我们可以[[1]]用皮亚诺算术将它们形式化，并证明二者等价。于是，它们具有可替换同义性。也就是说，在关于数的形式表达式中，可以互换使用二者，而不改变包含它们的表达式的意义。')
add(rr(214,12),rr(112,12),text='现在假设克里斯会数数，却不会做除法。那么：')
add(rr(214,13),rr(112,12),'quote',text='克里斯知道三比二多一。')
add(rr(215,1),rr(112,13),text='这是真的。但我们不能将“比二多一”替换为“六的一半”：')
add(rr(215,2),rr(112,13),'quote',text='克里斯知道三是六的一半。')
add(rr(215,3),rr(112,14),text='同时还保持陈述为真。')
add(rr(215,4),rr(112,15),text='伯特兰·罗素试图分析并重新表述内涵性构造，使它们成为外延性的。[[2]]按照罗素的进路，我们可以写成：')
add(rr(215,5),rr(112,16),'quote',text='克里斯知道“有一个数比二多一”。')
add(rr(215,6),rr(112,17),text='以明确“知道”的语境。如果将引号中的短语换成一个表面上等价的表述：')
add(rr(215,7),rr(112,17,18),'quote',text='克里斯知道“有一个数是六的一半”。')
add(rr(215,8),rr(112,19),text='那么，就不能把“有一个数”替换为“三”而仍保持陈述为真。')
add(rr(215,9),rr(112,20,25),text='鲁道夫·卡尔纳普（1891—1970）是一位逻辑实证主义者，试图从实证主义科学中寻找事实，以供逻辑操作。起初，他认为一切陈述要么是外延性的，要么没有意义。在1928年的著作《世界的逻辑构造；哲学中的伪问题》[[3]]中，他提出一种全面的进路，否认任何不能以事实为基础的语言构造有意义。他尤其否认实在论（即唯物主义）或唯心主义有意义。也就是说，卡尔纳普认为知识建立在经验主义的验证上。尽管如此，他仍自称“物理主义者”，认为物理学示范了如何确立事实。',reason='realism译实在论，书名分号保留；不以冒号误成副标题。')
add(rr(215,10),rr(112,26,31),text='威拉德·奎因（1908—2000）在1953年的《从逻辑的观点看》[[4]]中批评逻辑实证主义。在《经验论的两个教条》（第20—46页）中，他首先否认分析真理与综合真理之间存在深刻区别：前者基于意义而不考虑事实，后者基于事实（第20页）。例如，可以把形式化算术内部数“三”的性质，与某人对数“三”的认识相比较；后者是一个被报告的事实。其次，奎因拒绝那种还原论，即只承认能重构为由事实组成的逻辑陈述的陈述有意义（第20页）。最终留下的是一种明确的实用主义。')
add(rr(215,11),rr(112,32,33),text='奎因特别关注能否用可替换性作为意义同义性的标准，探问替换在什么语境中正当，并指出替换必然改变陈述的形式（第56页）。他的结论同样是实用主义的：')
add(rr(215,12),rr(112,33)+rr(113,0),'quote',text='真正重要的是在相关方面相似……这是经验科学的一个典型问题。（第60页）')
nt={1:'但这里不这样做。',2:'B. Russell：“论指称”，Mind 14，第56期（1905）：479—493。',3:'R. Carnap：《世界的逻辑构造；哲学中的伪问题》，R. A. George英译（University of California Press，1967）。',4:'W. V.-O. Quine：《从逻辑的观点看：逻辑哲学论文集》（Harper Torchbook，1963）。'}
notes=[]
for p,b in [(269,3),(270,1)]:
    for n,refs in note_groups(rr(p,b)):
        if (p==269 and n not in [1,2,3]) or (p==270 and n!=4):continue
        notes.append({'id':f'dm-ch10-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':[str(p-9)],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch10a',10,rows,notes,rr(214,0,13)+rr(215,1,12))
(W/'checkpoint_ch10a.json').write_text(json.dumps({'next_source_pdf_page':215,'next_source_block':13,'next_supplied_pdf_page':113,'next_supplied_block':1,'next_unit':len(rows)+1,'next_note':5,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
