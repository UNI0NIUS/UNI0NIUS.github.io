from materialism_common import *

groups=[]
for b in EN[286]['blocks'][1:]:
    for j,l in enumerate(b['lines']):
        x=l['bbox'][0]
        if x<80 or 225<x<250:groups.append([])
        groups[-1].append([287,b['block'],j,j+1])
oldrefs=rr(173,26,43)+rr(174,0,23)+rr(174,25,43)+rr(175,0,10)+rr(175,12,19)
assert len(groups)==len(oldrefs)==80
fixes={
 'configuration space':('配置空间','位形空间'),
 'constructivism':('建构主义','构造主义'),
 'The Concept of Model (Badiou)':('《模型的概念》','《模型的概念》（巴迪欧）'),
 'Contingency and Recursivity (Hui)':('《偶然性与递归性》','《偶然性与递归性》（许煜）'),
 'Copenhagen interpretation of quantum theory':('哥本哈根诠释','量子理论的哥本哈根诠释'),
 'Cours de linguistique générale (Saussure)':('《普通语言学教程》','《普通语言学教程》（索绪尔）'),
 'Course in General Linguistics (Saussure)':('《普通语言学教程》','《普通语言学教程》（索绪尔）'),
 '‘Critique of Hegel’s Philosophy in General’ (Marx)':('《对黑格尔哲学的总体批判》','《对黑格尔哲学的总体批判》（马克思）'),
 'De Corpore (Hobbes)':('《论身体》','《论物体》（霍布斯）'),
 'De Rerum Natura (Lucretius Carus)':('《物性论》','《物性论》（卢克莱修）'),
 'Dialectical and Historical Materialism (Stalin)':('《辩证唯物主义与历史唯物主义》','《论辩证唯物主义和历史唯物主义》（斯大林）'),
 'dialectical method':('辩证法','辩证方法'),
 'Dialectics and Formal Logic (Guest)':('《辩证法与形式逻辑》','《辩证法与形式逻辑》（盖斯特）'),
 'Dialectics of Nature (Engels)':('《自然辩证法》','《自然辩证法》（恩格斯）'),
 'dialektikê':('dialektikē','dialektikê'),
 'Dietzgen, Joseph':('迪茨根','狄慈根'),
}
rows=[]
for i,(refs,zref) in enumerate(zip(groups,oldrefs),72):
    en=extract(EN,refs,True);old=extract(ZH,[zref]);zh=old
    m=re.search(r'\s+(\d[\d, ––-]*)$',en);assert m,en
    term=en[:m.start()].strip();locator=m[1]
    oldloc=re.search(r'(\d[\d, ––-]*)$',old);assert oldloc,old
    assert re.sub(r'\s','',oldloc[1])==re.sub(r'\s','',locator),(en,old)
    if term in fixes:
        a,b=fixes[term];assert a in zh,(term,zh);zh=zh.replace(a,b)
    row={'id':f'dm-index-{i:03}','kind':'index_entry','source_blocks':refs,'supplied_translation_blocks':[zref],'printed_pages':['278'],'en':en,'zh':zh,'supplied_zh':old,'index_term':term,'index_locators':locator,'index_level':0,'status':'text_compared_layout_pending'}
    if zh!=old:row['revision_reason']='修正术语并与正文统一，补回原索引的作者括注；逐项核对页码。'
    rows.append(row)
save('index02',13,rows,[],rr(287,1,19))
(W/'checkpoint_index02.json').write_text(json.dumps({'next_source_pdf_page':288,'next_supplied_pdf_page':175,'next_supplied_block':20,'next_index_entry':152,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
