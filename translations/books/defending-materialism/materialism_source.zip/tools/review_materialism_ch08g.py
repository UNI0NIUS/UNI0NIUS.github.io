from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch08-{len(rows)+110:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(190,1),rr(99,18,21),text='1931年，红色专家恩斯特·科尔曼（1892—1979）和索菲娅·亚诺夫斯卡娅（1896—1966）在同样发表于《在马克思主义旗帜下》的《黑格尔与数学》中，明确阐述了辩证唯物主义的立场。[[42]]他们反复引用《反杜林论》和不久前问世的《自然辩证法》，在批评黑格尔辩证法的同时，强调辩证唯物主义根植于黑格尔。',reason='修复注42拆号，恢复出版时间相对关系。')
add(rr(190,2),rr(99,22,24),text='科尔曼和亚诺夫斯卡娅概述并拒斥了上述逻辑学派：直觉主义依赖先验假定；逻辑主义把逻辑与数学统一起来，将理性规律等同于公理和定理；形式主义则脱离内容处理逻辑。他们还拒斥把数学视为物理学一部分的“机械论经验主义者”，并反对马赫将问题心理学化。总的说来：')
add(rr(190,3),rr(99,24,27),'quote',text='因此，这些哲学学派都只抓住现实的一个方面，没有任何一个能够理解数学与实践的联系及其发展规律。只有黑格尔给数学下了一个把握事物本质的定义；这个定义完全独立于黑格尔的观点，实际上是深刻唯物主义的。')
add(rr(190,4),rr(99,28),text='不过，从阶级立场看待数学，并不意味着拒斥数学：')
add(rr(190,5),rr(99,28,29),'quote',text='恰恰相反，它［资产阶级数学］必须经过重构，因为它虽然片面而歪曲，却仍客观地表现了物质世界。')
add(rr(190,6),rr(99,30),text='科尔曼和亚诺夫斯卡娅指出，试图把分析还原为算术，最终导致了')
add(rr(190,7),rr(99,30,31),'quote',text='集合论中那些众所周知的悖论，它们摧毁了专为这一目的建立起来的整个结构，不仅是数学的，而且是逻辑的（原文如此）。',reason='保留原文sic针对不完整语法的标注，不把它改为额外论断。')
add(rr(190,8),rr(99,32),text='因此，尽管理由截然不同，他们与直觉主义者一样，对康托尔的无限持怀疑态度。')
add(rr(190,9),rr(99,33,34),text='当时，亚诺夫斯卡娅正在翻译和编辑新近重新发现的马克思数学手稿；这些手稿于1933年出版。[[43]]马克思在讨论泰勒定理时写道：',reason='修复注43；rediscovered译重新发现。')
add(rr(190,10)+rr(191,1),rr(99,34,35)+rr(100,0,2),'quote',text='这种从普通代数出发、而且借助普通代数，跃入变量代数的飞跃，被当作既成事实；它没有得到证明，乍看之下还与通常代数的一切规律相矛盾。……换句话说，起始方程……不仅没有得到证明，而且实际上有意无意地假定了以变量替代常量，这公然违背代数的一切规律——因为代数，因而也包括代数二项式，只容许常量，而且只有两种常量：已知的和未知的。因此，从代数推导这个方程，似乎建立在欺骗之上。（第117页）',reason='恢复旧译漏掉的两处省略号，合并跨页引文，不改变作者所引马克思的判断。')
add(rr(191,2),rr(100,3,5),text='这仿佛表明，马克思只能接受变量作为实际存在的值的占位符，而不能接受它作为一般的值的占位符。这种思想混乱触及黑格尔对逻辑形式主义批评的核心：把逻辑的内容——这里是常量——抽象成变量，再以任意值替换这些变量，被视为不正当。上面提到的恩格斯关于变量和抽象的断言，很可能源自他与马克思的讨论。')
add(rr(191,3),rr(100,6,7),text='当然，只要明确说明这种抽象，对方程中的任意常量乃至公式作抽象，都是完全正当的。[[44]]然而，科尔曼和亚诺夫斯卡娅引用马克思时，并未进一步评论。',reason='补漏注44。')
add(rr(191,4),rr(100,8,10),text='1932年，柯尔莫哥洛夫探索了一条辩证唯物主义能够接受的直觉主义进路。在《论直觉主义逻辑的解释》[[45]]中，他将直觉主义逻辑重新表述为问题演算，并证明它在形式上等价于海廷对布劳威尔逻辑的形式化。柯尔莫哥洛夫巧妙地把焦点放在植根于现实的问题上，从而避开了对无内容形式的批评，以及对用变量概括常量的批评：',reason='修复注45拆号并归位，统一人名。')
add(rr(191,5),rr(100,10,11),'quote',text='直觉主义逻辑应由问题演算来取代，因为它的对象实际上不是理论命题，而是问题。（第328页）')
add(rr(191,6),rr(100,12),text='也就是说：')
add(rr(191,7),rr(100,12,13),'quote',text='在数学各个具体领域出现的一切情形中，都能使用“问题”和“问题的解”这两个概念，而不会引起误解。（第329页）')
add(rr(191,8),rr(100,14),text='这一障眼法，用对具体问题的抽象替代了对前提的抽象。',reason='旧译把替代方向颠倒；substitutes A for B是以A替代B。')
add(rr(191,9),rr(100,15,16),text='有趣的是，柯尔莫哥洛夫把其逻辑的规则称为“计算性的”（第334页）。把数学视为计算，是我们的唯物主义观念的核心。')
add(rr(191,10),rr(100,17,18),text='因此，直觉主义成为苏联构造逻辑学派的基础。具有讽刺意味的是，构造主义如今已成为编程语言理论与实践的一种核心进路。')
add(rr(191,11),rr(100,19),'heading',text='孟什维克化的唯心主义与英国马克思主义')
add(rr(191,12),rr(100,20,22),text='英国共产党（CPGB）成立于1920年。作为一个马克思列宁主义政党，该党明确与苏联共产党保持一致，并倡导辩证唯物主义世界观。它虽从未像其他西欧共产党那样拥有众多党员或取得选举成功，却在工会中有相当大的影响力。',reason='英文底本第二处党名缩写误作CPGM，英文照录，中文用该党避免引入另一组织。')
rows[-1]['editor_note']='本段英文第二次出现的CPGM，依上下文应为前述CPGB；英文保留底本。'
nt={42:'E. Kolman、S. Yanovskaya：“黑格尔与数学”，《在马克思主义旗帜下》，1931，https://www.marxists.org/reference/subject/philosophy/works/ru/kolman.htm 。',43:'K. Marx：《马克思数学手稿》（New Park Publications，1983）。',44:'这后来成为数理逻辑的一个关键特征，如今也是编程中广泛使用的技术。',45:'A. Kolmogorv［底本拼法］：“论直觉主义逻辑的解释”，载P. Mancosu编《从布劳威尔到希尔伯特：20世纪20年代的数学基础之争》（Oxford University Press，1998），第328—334页。'}
notes=[]
for n,refs in note_groups(rr(266,1)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch08-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['257'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch08g',8,rows,notes,rr(190,1,10)+rr(191,1,12))
(W/'checkpoint_ch08g.json').write_text(json.dumps({'next_source_pdf_page':192,'next_source_block':1,'next_supplied_pdf_page':100,'next_supplied_block':23,'next_unit':len(rows)+110,'next_note':46,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
