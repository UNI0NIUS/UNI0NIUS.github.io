from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch08-{len(rows)+131:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(192,1),rr(100,23,27),text='英国共产党常被视为一个相对缺乏文化修养的组织，比起理论，它更注重日常斗争。不过，该党拥有相当多今天所谓的公共知识分子。他们经常在广播和大众印刷媒体上出现，著作既由党的出版社出版，也由主流的非党派出版社出版。韦尔斯基的《可见的学院》[[46]]详细叙述了20世纪30年代的这一环境。我们尤其关注其中的数学家海曼·莱维（1889—1975）和大卫·盖斯特（1911—1938）。',reason='修复注46；milieu不是狭指学术圈，non-aligned指非党派。')
add(rr(192,2),rr(100,28,32),text='盖斯特于1938年在西班牙随国际纵队作战时牺牲，他似乎是对数学基础论争研究最深入的英国马克思主义者。1929年，他在《数学形式主义》[[47]]中指出，波兰逻辑学家已在罗素和怀特海的《数学原理》中发现矛盾。他还认为，希尔伯特希望从形式上证明数学相容性的愿望受到挫败，因为唯一的办法是“构造一组满足它们的思维对象”（第210页）。这归根结底取决于能否对有限整数作出最小限度的刻画；对希尔伯特和直觉主义者来说，这都是一个深刻的问题。',reason='补漏注47，consistency统一相容性。')
add(rr(192,3),rr(100,33)+rr(101,0,2),text='在1930年的《对数学命题的“理解”》[[48]]中，盖斯特以一个熟悉的理由批评排中律：同时考虑一个命题及其否定是没有意义的。他还说，数学命题与经验命题一样，可能被新证据推翻。相比之下，具体实例的性质可以通过执行过程来确立；他以尝试确定某个特定数是否为质数为例。这似乎与柯尔莫哥洛夫把逻辑规则视为计算性的观点相似。',reason='补漏注48，合并跨页段落。')
add(rr(192,4),rr(101,3,4),text='去世前不久，盖斯特似乎同情直觉主义。在评论E. T. 贝尔的《数学家传》[[49]]时，他把《数学原理》的改良主义与“直觉主义者的革命性挑战”[[50]]相对照：',reason='补漏注49、50，reformism译改良主义；去世前而非暗示病榻临终。')
add(rr(192,5),rr(101,4,5),'quote',text='这不正是辩证法的精神突破形式逻辑的坚硬外壳吗？过去，如此多的科学思想曾被囚禁在这层外壳之中！（第256页）')
add(rr(192,6),rr(101,6,7),text='在1931年伦敦国际科学技术史大会上，科尔曼阐述了关于逻辑的辩证唯物主义立场。他在《数学科学的当前危机及其重建的总纲》[[51]]中，考察了他所认为的数学当前存在的矛盾：',reason='补漏注51。')
add(rr(192,7),rr(101,7,10),'quote',text='数学的一切深刻矛盾——单一与多样之间、有限与无限之间、离散与连续之间、偶然与必然之间、抽象与具体之间、历史与逻辑之间的矛盾，以及理论与实践之间、数学本身与其逻辑基础之间的矛盾——实际上都是辩证矛盾。')
add(rr(193,1),rr(101,11),text='科尔曼虽然承认希尔伯特的进路有一定价值，却批评形式逻辑忽视了数的概念的历史必然性：')
add(rr(193,2),rr(101,11,13),'quote',text='至于希尔伯特的公理化方法，它确实有助于说明各个数学概念之间的逻辑联系，但由于它是事后的构造，同样无法正确描绘发展过程。',reason='不增译数学发展全貌，保留post factum事后之意。')
add(rr(193,3),rr(101,14),text='而且，与前面一样，科尔曼把逻辑原子论和直觉主义都斥为唯心主义：')
add(rr(193,4),rr(101,14,17),'quote',text='无论像逻辑主义者那样，把数学概念的世界视为僵化不动的共相的世界，还是像直觉主义者那样，把它视为自由生成的活动领域，都没有什么分别。……有限主义、元逻辑和数学原子论中最精巧的手法，无非表达了资产阶级数学家企图借形式逻辑的帷幕，把自己与物质及辩证法隔开的焦虑；这种做法将他们直接引向经院哲学的荒漠。',reason='恢复原文省略号，universals译共相。')
add(rr(193,5),rr(101,18,20),text='莱维和盖斯特都参加了苏联代表的会议。鲍里斯·赫森（1893—1936）在一篇关于牛顿的论文中，阐述了辩证唯物主义对更广范围的科学分析所持的立场。在为盖斯特所作的悼文《斗争中的数学家》[[52]]中，莱维说，听众似乎不知所措，但盖斯特发言支持赫森。在同一篇文章中，莱维明确指出，马克思主义内部有关政治和经济的争论，与以下斗争之间存在联系：',reason='补漏注52，统一莱维/盖斯特，消除旧译列维/格斯特混用。')
add(rr(193,6),rr(101,20,22),'quote',text='高度理论化和抽象性的斗争与困惑。在这方面，大卫能够发挥其十分宝贵的数理逻辑知识的作用。（第157页）')
add(rr(193,7),rr(101,23,25),text='此后，盖斯特似乎基本放弃了数学研究，转向更广泛的教育和马克思主义活动。他关于马克思主义哲学的授课笔记在他去世后以《辩证唯物主义教科书》[[53]]为题出版。在“辩证法与形式逻辑”这一短节中，盖斯特重申，形式逻辑——他称之为“常识的逻辑”（第68页）——建立在绝对的抽象之上，因而')
add(rr(193,8),rr(101,26),'quote',text='无法把握变化的内在过程，无法揭示其辩证性质。（第68页）')
add(rr(193,9),rr(101,27,29),text='要超越这一点，就需要辩证逻辑：试图进一步发展形式逻辑，会导致形而上学的思维。在这里，盖斯特援引恩格斯在《反杜林论》中将形式逻辑与初等数学、辩证逻辑与高等数学相联系的说法。正如我们将看到的，这一时期图灵的工作，恰恰为刻画“变化的内在过程”奠定了基础，进一步压缩了辩证法的空间。',reason='association不是比喻，改相联系。')
add(rr(194,1),rr(101,30,31),text='1934年，几位著名的英国共产党成员为《辩证唯物主义的各个方面》[[54]]撰稿。莱维在《一位科学工作者眼中的辩证唯物主义》[[55]]中概述了正统观点，却在结尾以亚里士多德式的方式限定了辩证法的范围：',reason='修复注54并补漏注55。')
add(rr(194,2),rr(101,32,34),'quote',text='所谓辩证法的规律……似乎对于科学工作者已经提出的细致分析方法，几乎没有或完全没有增益。……在某种意义上，不能指望它们增添什么，因为它们自称居于科学之上。……因此，对科学而言，它［辩证唯物主义］是一种解释的方法，而非研究的方法。（第30页）',reason='恢复底本三处省略号。')
add(rr(194,3),rr(101,35,36),text='在同一文集中，X射线晶体学家J. D. 伯纳尔（1901—1971）也试图将辩证法与科学区分开来，在《辩证唯物主义》[[56]]一文中呼应了莱维：',reason='修复注56并统一莱维。')
add(rr(194,4),rr(101,36,38),'quote',text='它［辩证唯物主义］并非对科学的批判，也不声称能取代实验方法，或取代对定律和理论的逻辑证明；但它确实以一种十分重要的方式补充科学：提供明确的方法，协调较大范围内的各专门科学，并为新的实验与发现指明方向。（第98页）')
nt={46:'G. Werskey：《可见的学院》（Allan Lane，1978）。',47:'D. Guest：“数学形式主义：1929”，载C. H. Guest编《大卫·盖斯特：一位为自由而战的科学家》（Lawrence and Wishart，1939），第207—210页。',48:'D. Guest：“对数学命题的‘理解’：1930”，载C. H. Guest编《大卫·盖斯特：一位为自由而战的科学家》（Lawrence and Wishart，1939），第211—213页。',49:'D. Guest：“评E. T. 贝尔《数学家传》”，Labour Monthly，1937年10月。',50:'对马克思主义者而言，“改良主义的”和“革命的”同样分别带有强烈的贬义和褒义。',51:'E. Kolman：“数学科学的当前危机及其重建的总纲”，载《十字路口的科学：苏联代表于1931年6月29日至7月3日伦敦国际科学技术史大会提交的论文》，1931，Frank Cass and Co.，https://www.marxists.org/subject/science/essays/colman3.htm 。',52:'H. Levy：“斗争中的数学家”，载C. H. Guest编《大卫·盖斯特：一位为自由而战的科学家》（Lawrence and Wishart，1939），第150—160页。',53:'D. Guest：《辩证唯物主义教科书》（Lawrence and Wishart，1939）。',54:'H. Levy、J. MacMurray、R. Fox、R. Page、Arnott J. D. Bernal、E. F. Carritt［作者列表标点按底本］：《辩证唯物主义的各个方面》（Watts and Co.，1934）。',55:'H. Levy：“一位科学工作者眼中的辩证唯物主义”，载H. Levy、J. MacMurray、R. Fox、R. Page Arnott、J. D. Bernal、E. F. Carritt编《辩证唯物主义的各个方面》（Watts and Co.，1934），第1—30页。',56:'J. D. Bernal：“辩证唯物主义”，载H. Levy、J. MacMurray、R. Fox、R. Page Arnott、J. D. Bernal、E. F. Carritt编《辩证唯物主义的各个方面》（Watts and Co.，1934），第89—122页。'}
notes=[]
for p in [266,267]:
    for n,refs in note_groups(rr(p,1)):
        if n not in nt:continue
        notes.append({'id':f'dm-ch08-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':[str(p-9)],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch08h',8,rows,notes,rr(192,1,7)+rr(193,1,9)+rr(194,1,4))
(W/'checkpoint_ch08h.json').write_text(json.dumps({'next_source_pdf_page':196,'next_source_block':0,'next_supplied_pdf_page':101,'next_supplied_block':39,'next_chapter':9,'next_note':1,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
