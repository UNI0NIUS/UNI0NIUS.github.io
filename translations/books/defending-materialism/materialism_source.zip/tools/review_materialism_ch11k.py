from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch11-{len(rows)+116:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add([[233,11,0,1]],rr(125,3),'heading',text='矛盾是自然界所固有的')
add([[233,11,1,6]],rr(125,4,6),text='辩证唯物主义的支持者说，他们所说的“矛盾”存在于现实世界中，而不只存在于逻辑陈述中。显然，他们使用这个词的含义，与它通常的含义有所不同。形式逻辑的矛盾——非（非x且x）；x或非x——取决于真值的性质。但斯大林或毛泽东所说的矛盾并非这个意思。斯大林这样写道：',reason='将下接斯大林引文另段保留；保留原文对逻辑式的称呼。')
rows[-1]['editor_note']='原书把所列两式称作“contradictions”。按通常的经典命题逻辑，两式分别表达非矛盾律与排中律，均非矛盾式；此处保留作者表述。'
add(rr(233,12),rr(125,6,10),'quote',text='与形而上学相反，辩证法认为，内在矛盾是自然界一切事物和现象所固有的，因为它们都有否定和肯定的方面，有过去和未来，有正在消亡的东西和正在发展的东西；而这些对立面之间的斗争，即新与旧、正在消亡的与正在诞生的、正在消失的与正在发展的东西之间的斗争，构成了发展过程的内部内容，构成了量变转化为质变的内部内容。[[28]]',reason='negative/positive在辩证法语境译否定/肯定，不赋予消极/积极的价值判断。')
add(rr(233,13),rr(125,11,12),text='所以，斯大林说矛盾，是以隐喻的方式谈论世界中的变化过程。但为什么承认变化就被认为是辩证法所特有的？',reason='删除旧译无根据的“非凡的”。')
add(rr(233,14),rr(125,13,14),text='事物有过去和未来，事物发展又消亡，这是人人都承认的。用“矛盾”这个术语来指称这一点，究竟增加了什么特殊成分？')
add(rr(234,1),rr(125,15,16),text='斯大林详细解释其含义时，诉诸的不是辩证法，而是马克思所谓的唯物主义历史理论。斯大林在这里称之为“研究社会现象的历史方法”。',reason='恢复正文与下接奴隶制引文的边界。')
add(rr(234,2),rr(125,16,17),'quote',text='在现代条件下，奴隶制会是无意义、愚蠢而不自然的。但在原始公社制度解体的条件下，奴隶制却是完全可以理解而且自然的现象，因为它代表着相对于原始公社制度的进步。')
add(rr(234,3),rr(125,17),'quote',text='……',reason='原书独立省略号保留，不将引文删节隐去。')
add(rr(234,4),rr(125,18),'quote',text='一切都取决于条件、时间和地点。')
add(rr(234,5),rr(125,19,20),'quote',text='显然，没有这种研究社会现象的历史方法，历史科学就不可能存在和发展；因为只有这种方法，才能使历史科学免于沦为偶然事件的杂乱集合和荒谬错误的堆积。[[29]]')
add(rr(234,6),rr(125,21,25),text='正如我们在第5.1节所述，亚当·斯密已经清楚地认识到，社会形式、生产关系及其相应的政治上层建筑是相继更替的。斯密并不觉得需要借助矛盾或辩证法来解释这一点。马克思和恩格斯在首次阐述历史唯物主义的《德意志意识形态》中，虽然从未提到辩证法，却确实经常使用矛盾这个术语。以下只是《德意志意识形态》中的几个例子，马克思和恩格斯在其中以后来成为正统“辩证唯物主义”的方式使用矛盾一词：',reason='恢复后接劳动分工引文的边界，不与作者叙述混排。')
add(rr(234,7),rr(125,25),'quote',text='分工意味着单个个人或单个家庭的利益与一切彼此交往的个人的共同利益之间的矛盾。')
add(rr(234,8),rr(125,26),'quote',text='……')
add(rr(234,9),rr(125,27,30),'quote',text='各个市民的生活条件，由于与现存关系以及由这些关系决定的劳动方式相矛盾，变成了他们所有人共有的、独立于每个个人的条件。市民在摆脱封建束缚的程度上创造了这些条件，同时又在受自身与既存封建制度的对立所决定的程度上，被这些条件所塑造。当各个城市开始联合时，这些共同条件便发展成阶级条件。相同的条件、相同的矛盾、相同的利益，必然在各地大体上产生相同的习俗。')
add(rr(234,10),rr(125,31),'quote',text='……')
add(rr(234,11)+rr(235,1),rr(126,0,2),'quote',text='生产力与交往形式之间的这种矛盾，正如我们所见，在过去的历史中曾多次发生，虽然并未危及其基础，却必然每次都以革命的形式爆发，同时呈现出各种附属形式，如全面的冲突、不同阶级之间的冲突、意识的矛盾、思想斗争等等，以及政治冲突等等。[[30]]',reason='接合跨页句，删除旧译重复的转折词。')
notes=[]
for n,refs,zh in [(28,[[272,3,7,8]],'斯大林，《论辩证唯物主义和历史唯物主义》。'),(29,[[272,3,8,9]],'斯大林，《论辩证唯物主义和历史唯物主义》。'),(30,[[272,3,9,10]],'卡尔·马克思、弗里德里希·恩格斯，《德意志意识形态》（Progress Publishers，1976）。')]:
    notes.append({'id':f'dm-ch11-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['263'],'en':extract(EN,refs,True),'zh':str(n)+'. '+zh,'status':'text_compared_layout_pending'})
save('ch11k',11,rows,notes,rr(233,11,14)+rr(234,1,11)+rr(235,1))
(W/'checkpoint_ch11k.json').write_text(json.dumps({'next_source_pdf_page':235,'next_source_block':2,'next_supplied_pdf_page':126,'next_supplied_block':3,'next_unit':len(rows)+116,'next_note':31,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
