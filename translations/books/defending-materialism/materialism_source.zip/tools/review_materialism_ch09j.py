from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch09-{len(rows)+156:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(210,9)+rr(211,1),rr(111,2,5),'quote',text='在执行构造过程时，我们常常碰到时间、空间和材料不足所造成的障碍。通常总能设法绕过这些障碍。然而，我们的构造能力确实有限，也没有理由假定，由这种限制引起的障碍总能消除。恰恰相反，现代物理学和宇宙学似乎表明，这些障碍原则上无法克服。[[67]]',reason='合并跨页引文，修复注67。')
add(rr(211,2),rr(111,6),text='不过，用亚里士多德式的表述来说，潜在可行性这一抽象')
add(rr(211,3),rr(111,6,8),'quote',text='使我们能够考虑任意长的构造过程和任意大的构造对象。它们的可行性是潜在的：如果有足够的空间、时间和材料，它们在实践中就是可行的。[[68]]')
add(rr(211,4),rr(111,9,10),text='马尔可夫明确把这种进路与基于集合论的经典数学相对照。后者允许实无限的抽象，[[69]]并以否定不存在来确立存在，其中“甚至可能不知道如何构造所需对象”。[[70]]')
add(rr(211,5),rr(111,11,12),text='马尔可夫的记号体系以重写符号序列的规则为基础，类似乔姆斯基后来对形式文法类别的刻画。一套这样的规则称为算法；马尔可夫将其特征概括为：')
add(rr(211,6),rr(111,12,13),'list_item',text='a) 规定精确，不留任意选择的余地，而且具有普遍可理解性——算法的确定性；')
add(rr(211,7),rr(111,14),'list_item',text='b) 可以从在给定范围内变化的初始数据出发——算法的通用性；')
add(rr(211,8),rr(111,15,16),'list_item',text='c) 算法以获得某种预期结果为目标，使用适当初始数据时，最终确实能够得到该结果——算法的得出结果性。[[71]]',reason='conclusiveness区别于a项definiteness，不重复译决定性/确定性。')
add(rr(211,9),rr(111,17),text='使用这一记号体系，马尔可夫通过归纳法系统地重构了皮亚诺算术的相当大一部分。')
add(rr(211,10),rr(111,18,19),text='马尔可夫认为，他的进路满足他所谓的丘奇论题，即算法模型的等价性。他还认为，图灵机“极具说服力”，因为')
add(rr(211,11),rr(111,19),'quote',text='在本质方面，图灵机的运行充分模拟了从事计算的数学家的行为，[[72]]')
add(rr(211,12),rr(111,20),text='即从一种思维状态转到另一种思维状态。',reason='此句属作者续述，和引文分开。')
add(rr(211,13),rr(111,21,23),text='这套记号旨在用于形式系统的实际实验。例如，“元算法”编程语言Refal[[73]]把马尔可夫规则纳入一个更常规的框架，用以辅助探索形式语义。然而，库什纳[[74]]指出，虽然马尔可夫的工作在西方已为人所知，记号的复杂性却妨碍了更广泛的采用。')
add(rr(211,14),rr(111,24,25),text='与直觉主义一样，接受构造主义对无限推理的限制，会抽掉许多重要的经典数学的基础。因此，人们也像直觉主义者那样，开展大量研究，试图在有限性基础上重建这些数学。')
add(rr(212,1),rr(111,26,28),text='具体说来，构造主义接受整数和有理数，却不接受必然涉及无限的实数。因此，把实数重新表述为构造函数，是至关重要的一步。构造主义的进路借鉴图灵与外尔的工作，用算法来定义实数：一个算法生成精度不断提高的有理数，而精度由另一个算法确定。正如沙宁所说：',reason='理清determined指精度，不误为有理数另由算法确定。')
add(rr(212,2),rr(111,28,30),'quote',text='自然科学和工程中对具体实数的实际使用，本质上基于这样一种可能性：从一个实数的个别表示中，提取出给出其一系列有理近似值的算法。[[75]]')
add(rr(212,3),rr(111,31),text='这明确承认，在实际应用中，由于测量有限，操纵物理现实时使用的是有理数。')
add(rr(212,4),rr(111,32,33),text='尽管马尔可夫采取唯物主义进路，他仍赞同这样一种观点：不可判定性结果限制的是数学，而不是人：')
add(rr(212,5),rr(111,33,34),'quote',text='因此，数学中（以及其他任何学问分支中）带有意向的研究事业，永远不会转移给机器；机器只能辅助人，而不能取代人。[[76]]',reason='conative侧重意向和努力，不窄化为好奇心；保留作者引文。')
nt={67:'Markov Jr、Nagorny：《算法理论》，第10页。',68:'Markov Jr、Nagorny：《算法理论》，第10页。',69:'Markov Jr、Nagorny：《算法理论》，第10页。',70:'Markov Jr、Nagorny：《算法理论》，第12页。',71:'Markov Jr：《算法理论》，第1页。',72:'Markov Jr、Nagorny：《算法理论》，第109页。',73:'V. F. Turchin：“一种元算法语言”，Kibernetika 4，第4期（1967）：45—54。',74:'B. A. Kushner：“A. A. 马尔可夫的构造数学”，The American Mathematical Monthly 113，第6期（2006）：562。',75:'Sanin：“构造实数与构造数空间”，第13页。',76:'Markov Jr：《算法理论》，第441页。'}
notes=[]
for n,refs in note_groups(rr(269,1)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch09-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['260'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch09j',9,rows,notes,rr(210,9)+rr(211,1,14)+rr(212,1,5))
(W/'checkpoint_ch09j.json').write_text(json.dumps({'next_source_pdf_page':214,'next_source_block':0,'next_supplied_pdf_page':112,'next_supplied_block':0,'next_chapter':10,'next_note':1,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
