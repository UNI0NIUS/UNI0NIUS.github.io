from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch03-{len(rows)+119:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(42,1),rr(18,2),'heading','定义 IV')
add(rr(42,2),rr(18,2),'quote',start='外力')
add(rr(42,3),rr(18,3))
add(rr(42,4),rr(18,4),'heading','定义 V')
add(rr(42,5),rr(18,4),'quote',start='向心力',fixes=[('趋向某一点的力','趋向作为中心的某一点的力')])
add(rr(42,6),rr(18,5,9))
add(rr(42,7),rr(18,10),'heading','定义 III')
add(rr(42,8),rr(18,10,11),'quote',start='vis insita',fixes=[('vis insita，','vis insita（内在力），')])
add(rr(42,9),rr(18,12))
en=extract(EN,rr(42,10)+rr(43,1),True).replace('f ma =',r'$f=ma$').replace('(mv)',r'($mv$)')
add(rr(42,10)+rr(43,1),rr(18,13,18),english=en,fixes=[('f=ma',r'$f=ma$'),('动量mv',r'动量 $mv$')])
add(rr(43,2),rr(18,19),'heading')
add(rr(43,3),rr(18,20,22))
add(rr(43,4),rr(18,23),'heading','时间')
add(rr(43,5),rr(18,23,25),'quote',start='绝对的',fixes=[('持续时间的一种可感知外部测量（无论准确与否）','借助运动对持续时间作出的一种可感知的外部度量（无论准确还是不均匀）')],reason='补回by the means of motion；保留unequable的不均匀含义。')
add(rr(43,6),rr(18,26,27))
en=extract(EN,rr(43,7),True).replace('t0 8 +',r'$t_0+8$').replace('time t0,',r'time $t_0$,')
add(rr(43,7),rr(18,28,30),english=en,fixes=[('t_0+8',r'$t_0+8$'),('t_0 ，',r'$t_0$，')])
add(rr(43,8),rr(18,31))
add(rr(43,9),rr(18,32))
en=extract(EN,rr(43,10,11),True).replace('y x = 2',r'$y=x^2$').replace('2x,',r'$2x$,').replace('y t = 4 9 [[2]] .',r'$y=4.9t^2$').replace('v t y = 9 8.',r'$v_y=9.8t$')
add(rr(43,10,11),rr(19,0,2),english=en,fixes=[('y=x^2',r'$y=x^2$'),('直线相对于','曲线相对于'),('导数2x',r'导数 $2x$'),('y=4.9t^2',r'$y=4.9t^2$'),('v_y=9.8t',r'$v_y=9.8t$')],reason='恢复下标与指数；抛物线不是直线，上标2不是原注。')
add(rr(43,12),rr(19,3))
add(rr(43,13)+rr(44,1),rr(19,4,5))
add(rr(44,2),rr(19,6,7),end='然后转换',fixes=[('恒星被月球掩星的时刻','月球掩恒星的时刻')])
add(rr(44,3),rr(19,7,10),start='然后转换',fixes=[('恒星时记录','恒星时[[14]]记录')],reason='恢复原注14。')
add(rr(44,4),rr(19,11),'heading','空间')
add(rr(44,5),rr(19,11,13),'quote',start='绝对空间',fixes=[('通常被误认为不动空间','通常被当作不动空间')],reason='vulgarly taken for不直接表达误认的判断。')
add(rr(44,6),rr(19,14,15),fixes=[('恒定运动参考系','匀速运动的参考系')])
add(rr(44,7),rr(19,16),end='我们从船实验')
add(rr(44,8),rr(19,16,17),'quote',start='我们从船实验')
add(rr(44,9),rr(19,18))
add(rr(44,10),rr(19,19),'heading','运动')
add(rr(44,11)+rr(45,1),rr(19,19,28),'quote',start='绝对运动')
rows[-1]['editor_note']='此段底本在物体也相对于船运动的分句中，仍只列地球与船的运动，表述有所脱落；后面的水手算例明确计入了水手相对于船的速度。译文保留底本而不擅补引文。'
add(rr(45,2),rr(19,29),end='但我们可以')
add(rr(45,3),rr(19,29,32),'quote',start='但我们可以')
add(rr(45,4),rr(19,33,34),'quote')
add(rr(45,5),rr(19,35))
add(rr(45,6)+rr(46,1),rr(20,0,2),fixes=[('实验证伪','实验否定')],reason='discredited不宜加强为形式上严格的证伪；底本实验名拼写另加校注。')
rows[-1]['editor_note']='本书英文将实验名拼作 Michaelson-Morely；中文按通常译名“迈克尔逊—莫雷”处理，英文照录。这里关于绝对空间和水桶实验的推论属于原作者论述。'
add(rr(46,2),rr(20,3))
add(rr(46,3),rr(20,4),'heading')
add(rr(46,4),rr(20,5,6),end='定律I：',fixes=[('浮体排斥定律','浮体排水定律'),('伽利略加速度定律','伽利略加速度定律[[15]]')],reason='displacement指排开液体，非排斥；恢复原注15。')
add(rr(46,5),rr(20,6),'quote',start='每个物体',text='每个物体都保持静止状态或沿直线匀速运动状态，除非施加于它的力迫使它改变这一状态。[[16]]',reason='恢复原注16及原书引文结构；中文底稿添加的定律编号不混入引文。')
add(rr(46,6),rr(20,7),'quote','运动量的改变始终与施加的驱动力成正比，并沿该力施加的直线方向发生。[[17]]',reason='此处motion指运动量；恢复原注17。')
add(rr(46,7),rr(20,8),'quote','对每个作用，总有一个大小相等、方向相反的反作用；或者说，两个物体彼此之间的相互作用总是大小相等、方向相反。')
add(rr(46,8),rr(20,9,11),'quote',fixes=[('恰如促进另一方前进。','恰如促进另一方前进。[[18]]')],reason='恢复原注18。')
add(rr(46,9),rr(20,12,13),end='当人手持')
add(rr(46,10),rr(20,13,14),'quote',start='当人手持',fixes=[('向上推力','向上推力［virtù impellente］'),('重力向下拉石头的力','重力向下拉石头的力量［facoltà］'),('持续施加这种力','持续施加这种力［virtù］')],reason='补回原引文中的意大利语术语。')
add(rr(46,11),rr(20,15,16))
add(rr(46,12),rr(20,17,19),end='受两个',fixes=[('他的文本不断穿插几何图示。','他的文本不断穿插几何图示，以说明其论证。')])
add(rr(47,1),rr(20,19,20),'quote','物体在两个力共同作用下，会在同一时间内描绘出平行四边形的对角线；这段时间正是两个力分别作用时，物体描绘出相应边所需的时间。',reason='two forces conjoined不是两个合力。')
add([],[],'figure','原书无编号插图：力的平行四边形合成示意。',english='Unnumbered diagram: parallelogram composition of forces.',reason='旧中文稿漏图。恢复原图；中英说明均为编者所加，非原书图注。')
rows[-1].update(image='assets/newton-parallelogram.png',source_image={'pdf_page':47,'block':2},printed_pages=['38'],image_labels_zh='A、B、C、D为原图顶点标记。',editor_note='此图在原书中没有编号和图注；此处说明为编者补充。')
add(rr(47,3),rr(20,21,22),'quote')
add(rr(47,4),rr(20,23),end='运动量')
add(rr(47,5),rr(20,23,24),'quote',start='运动量')
add(rr(47,6),rr(20,25,27),fixes=[('是mv',r'是 $mv$')])
add(rr(47,7),rr(20,28,30),fixes=[('排除向外作用和阻碍','排除外部作用和阻碍'),('因距离相互对称而相等','由于物体之间的相互距离而相等')],reason='outward actions此处是外部作用；reciprocal distances并未说距离对称，保留原作者不充分的表述并加校注。')
rows[-1]['editor_note']='底本此段将重心“保持不变”与系统匀速运动并列，又称相对运动“相等”，措辞不够严谨。译文照录作者论述；在无外力时应区分质心匀速运动、各物体速度与各自运动量，不能把这些量混为一谈。'
add(rr(47,8),rr(20,31,32)+rr(21,0),end='在给定空间内')
nt={14:'恒星日以恒星相对于地球的视旋转来衡量，比太阳日短约4分钟。',15:'“物体从静止开始作匀加速下落时，所经过的距离之比，等于通过这些距离所用时间间隔的平方之比。”定理II，命题2。'}
title='牛顿：《自然哲学的数学原理……安德鲁·莫特译……附牛顿〈世界体系〉；W. 埃默森对〈原理〉的简短评注与辩护；以及约翰·梅钦依据引力所论月球运动定律……（先生的序言）》'
nt.update({16:title+'，定律I。',17:title+'，定律II。',18:title+'，定律III。',19:title+'，推论III。'})
notes=[]
for n,refs in note_groups([[247,1],[247,2]]):
    if n not in nt:continue
    notes.append({'note_number':n,'source_blocks':refs,'en':re.sub(r'^\d+\s+','',extract(EN,refs,True)),'zh':nt[n],'status':'text_compared_layout_pending'})
    if n>=16:notes[-1]['editor_note']='底本书目题名末尾“(The Preface of Mr)”自身不完整，按原样保留。'
for n in notes:
    num=n['note_number'];n.update(id=f'dm-ch03-note-{num}',kind='note',printed_pages=list(dict.fromkeys(str(ref[0]-9) for ref in n['source_blocks'])))
    n['en']=str(num)+' '+n['en'];n['zh']=str(num)+'. '+n['zh']
expected=[[p,b['block']] for p in range(42,48) for b in EN[p-1]['blocks'] if b.get('lines') and b['block']>0]
save('ch03c',3,rows,notes,expected)
(W/'checkpoint_ch03c.json').write_text(json.dumps({'next_source_pdf_page':48,'next_source_block':1,'next_supplied_pdf_page':21,'next_supplied_block':0,'next_unit':len(rows)+119,'next_note':20,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
