from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch11-{len(rows)+30:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(225,1),rr(118,20,25),text='编码信息完全独立于任何人类的主观参与，无论这种参与来自作者还是读者。20世纪50年代遗传密码的发现，使这一点更加清楚。在这里，信息存在于DNA中。随着DNA测序仪的发展，这种分子密码可以打印成人能够阅读的形式：由ATGC四个字母构成的序列。香农的观点是，无论信息以分子形式高效地表示，还是以墨水和纸张上的文本这种冗余得多的形式表示，其信息量都相同。分子形式的信息既可以由现代测序仪“读取”，也可以由核糖体“读取”。受过训练的人能够阅读打印结果，并在一定程度上加以解释，这一事实与DNA中的信息无关。')
add(rr(225,2),rr(118,26,28),text='它并不是因为人能阅读才成为信息。人之所以能够阅读它，是因为它是信息。更一般地说，信息量不依赖于人赋予的意义。关系恰好相反：我们处理意义的能力依赖于客观存在的信息，包括神经系统外部和内部的信息。')
add(rr(225,3),rr(118,29,31)+rr(119,0),text='生物体会对环境作出反应。即使单细胞生物也能以有目的的方式作出反应。单细胞水生光合物种衣藻的个体能够向光源游动。[[7]]这种有目的的行为具有明显的进化优势：获得光能。但要做到这一点，细胞必须能够储存一种与外部环境状态相关联的内部状态。这里的环境状态就是光照方向；从几何学上说，它是三维空间中的一个向量。',reason='连接原文末尾不完整句，明确光照方向是待表征的环境状态。')
add(rr(225,4),rr(119,1,3),text=r'让我们考虑这种向量的一种可能的内部编码。只需为相互垂直的$x,y,z$轴各配上三个状态$(-1,0,+1)$，表示入射光向量背离该轴、与该轴成直角或朝向该轴。采用一种简单的编码方式，细胞就需要能够记录$3\times\log_2(3)=4.755$比特的信息。[[8]]',english=r'Let us consider a possible internal encoding of such a vector. It would suffice to associate three states $(-1,0,+1)$ to each of the mutually perpendicular $x,y,z$ axes, indicating whether the incident light vector is away from, at right angles to, or towards that axis. With a naive encoding, this would require the cell to be able to register $3\times\log_2(3)=4.755$ bits of information.[[8]]')
add(rr(225,5),rr(119,4,7),text='这4.755比特的“意义”是什么？显然，从某种意义上说，它意味着光源位于某个确定的大致方向。这种方向规定随后就能引导细胞运动。从信息论角度看，要使传感器具有意义，环境状态（光照方向）与趋光细胞的内部状态之间就必须存在互信息。[[9]]因此，这里的意义就是互信息。',reason='phototactic统一译为趋光；general direction译大致方向。')
add(rr(225,6),rr(119,8,10),text='本节考察了信息论的一个在哲学上令人震惊的推论：信息是客观的、物理的东西，完全独立于人类意识。无需强调，这具有深刻的唯物主义意蕴。互信息的形式定义，为文献[[10]]所捍卫的知识表征模型提供了科学基础。',reason='formal definition为形式定义，不是正式定义；补原句省略的文献指代。')
add(rr(225,7),rr(119,11),'heading',text='随机性')
add(rr(225,8),rr(119,12),text='本节将考察香农所发表成果的第二个令人惊讶的推论。')
notes=[]
def note(n,refs,zh,en=None):
    item={'id':f'dm-ch11-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in refs)),'en':en if en is not None else extract(EN,refs,True),'zh':str(n)+'. '+zh,'status':'text_compared_layout_pending'}
    if en is not None:item['source_transcription_note']='分数及互信息、条件熵公式依原PDF图像恢复；原始span保留。'
    notes.append(item)
note(7,[[270,3,28,30]],'Rachel R. Bennett与Ramin Golestanian：“衣藻趋光性的转向机制”，Journal of The Royal Society Interface 12，第104期（2015）：20141164。')
note(8,[[270,3,30,35],[270,4],[271,1,0,2]],r'实际上，正如Bennett和Golestanian所示，衣藻具有更高效的编码方式。它只有一个眼点，沿螺旋路径游动，同时绕自身轴线旋转。这使一个眼点能够以约60毫秒的采样间隔，对三个空间轴进行时分复用扫描。假定在所有可能朝向中，有$\frac{1}{6}$会激活眼点，那么根据香农公式，一个样本的平均信息量为0.65比特，因此眼点每秒提供约10比特的信息。',r'8 In fact, as Bennett and Golestanian show, Chlamydomonas has a more efficient encoding. It has a single eye spot and swims in a spiral path spinning on its axis as it does so. This enables the one eye spot to perform time-multiplexed scanning of the three spatial axes with a sampling interval of about 60 ms. Assuming that the eye spot activates for $\frac{1}{6}$ of possible orientations and using Shannon’s formula the mean information content of a sample is 0.65 bits so the eye spot provides about 10 bits per second of information.')
note(9,[[271,1,2,16],[271,2],[271,3]],r'两个随机变量$X,Y$之间的互信息记为$I(X;Y)=H(X)-H(X\mid Y)$，其中$H(X)$为$X$的信息熵，$H(X\mid Y)=\sum_{x,y}p(x,y)\log_2\frac{1}{p(x\mid y)}$为给定$Y$时$X$的条件熵。',r'9 Mutual information between two random variables $X,Y$ is denoted by $I(X;Y)=H(X)-H(X\mid Y)$ where $H(X)$ is the information entropy of $X$ and $H(X\mid Y)=\sum_{x,y}p(x,y)\log_2\frac{1}{p(x\mid y)}$ is the conditional entropy of $X$ given $Y$.')
note(10,[[271,4,0,1]],'列宁，《唯物主义和经验批判主义》。')
save('ch11c',11,rows,notes,rr(225,1,8))
(W/'checkpoint_ch11c.json').write_text(json.dumps({'next_source_pdf_page':226,'next_source_block':1,'next_supplied_pdf_page':119,'next_supplied_block':13,'next_unit':len(rows)+30,'next_note':11,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
