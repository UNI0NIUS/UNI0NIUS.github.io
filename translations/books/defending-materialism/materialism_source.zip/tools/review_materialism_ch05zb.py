from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch05-{len(rows)+331:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(127,5),[],'figure',text='图5.5 起初，八十个原子全在左侧。系统趋于较高熵的状态，左侧原子数围绕四十这一均值振荡，即约一半原子处于空间的左半部。这种熵涨落是汤姆森论证的一个依据。作者绘图。',reason='恢复旧稿遗漏原图与图注。')
rows[-1].update(image='assets/figure-5-5.png',source_image={'pdf_page':127,'block':4,'xref':746},image_labels_zh='图题：空间左半部的原子数；纵轴Number of atoms：原子数；横轴Time step：时间步。')
add(rr(127,1),rr(64,8,11),fixes=[('晶格气体','格子气')])
add(rr(127,2),rr(64,12,14),end='现在假设')
add(rr(127,3),rr(64,14,18),'quote',start='现在假设')
add(rr(128,1),rr(64,19,21))
add(rr(128,2),rr(64,22))
add(rr(128,3),rr(64,23,25),fixes=[('时间0 状态镜像。','时间0状态的镜像。[[122]]')],reason='补回旧译漏注122。')
add(rr(128,4),rr(64,26,27),fixes=[('从时间21 到时间0 的A 时段内','在通向时间0的A时段内')],reason='源文没有从时间21到0，旧译擅加21导致A时段位于错误时间区间。')
add(rr(128,5),rr(64,28,30),fixes=[('解释最终并不成立','解释并非最终的答案'),('可能性确实存在','确实很可能'),('可能性也必然存在','也必然很可能')],reason='not final不等于完全不成立，probable指很可能而非仅有可能。')
add(rr(128,8),[],'figure',text='图5.6 汤姆森所描述的有限系统的时间演化。时间0时，系统处于低熵状态，随后向熵增加的方向演化。时间10时，所有粒子的运动方向被逆转。系统于是演化回原来的低熵状态，并在时间20到达该状态。此后熵再次增加，但在微观层面沿着一条不同的路径演化。作者绘图。',reason='恢复旧稿遗漏原图及完整图注。')
rows[-1].update(image='assets/figure-5-6.png',source_image={'pdf_page':128,'block':7,'xref':751},image_labels_zh='纵轴Entropy：熵；横轴Time：时间；Inferred prehistory：推断的前史；All motions reverse at time 10：时间10时所有运动逆转；Returns to floor entropy at time 20：时间20时回到最低熵；Re randomises on different path：沿不同路径重新随机化。A、B、C、D标示四个时段。')
nt={121:'Thomson：“能量耗散的动力学理论”。',122:'这一状态是镜像，因为此时每个原子都沿着与其原始方向相反的方向运动。'}
notes=[]
for n,refs in note_groups(rr(258,1)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch05-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['249'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch05zb',5,rows,notes,rr(127,1,3)+rr(127,5)+rr(128,1,5)+rr(128,8))
(W/'checkpoint_ch05zb.json').write_text(json.dumps({'next_source_pdf_page':128,'next_source_block':6,'next_supplied_pdf_page':64,'next_supplied_block':31,'next_unit':len(rows)+331,'next_note':123,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
