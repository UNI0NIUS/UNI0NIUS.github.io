from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch05-{len(rows)+1:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(80,0,1),rr(37,23),'chapter',english='Chapter 5. HISTORICAL AND MECHANICAL MATERIALISTS')
add(rr(80,2),rr(37,24),'heading')
add(rr(80,3),rr(37,25,29))
add(rr(80,4),rr(37,30))
add(rr(80,5),rr(37,31,34),fixes=[('《家庭、私有制和国家的起源》，','《家庭、私有制和国家的起源》[[1]]，'),('直到1978 年才出版。','直到1978 年才出版。[[2]]')],reason='补回原注1、2。')
add(rr(80,6),rr(37,35),'heading')
add(rr(80,7),rr(38,0))
add(rr(80,8),rr(38,1,4),fixes=[('“野蛮”“蒙昧”','“蒙昧”“野蛮”')],reason='savagery与barbarism顺序被旧译颠倒。')
add(rr(81,1),rr(38,5,6))
add(rr(81,2),rr(38,7),end='人口极其',text='两人都认为，在生计方式尚无畜牧或农耕的人群中，国家不可能产生。',reason='旧译将lacks herding or farming译成以狩猎或农耕为生，漏掉否定并替换畜牧，改变国家产生条件。')
add(rr(81,3),rr(38,7,10),'quote',start='人口极其',fixes=[('做饭、织布、缝纫。','做饭、织布、缝纫。[[3]]')],reason='恢复原注3及引文格式。')
add(rr(81,4),rr(38,11),end='在一个以狩猎')
add(rr(81,5),rr(38,11,15),'quote',start='在一个以狩猎',fixes=[('对决议有重大影响。','对决议有重大影响。[[4]]'),('整个国家','整个民族共同体'),('国家是由不同村庄','这一共同体是由不同村庄')],reason='nation在国家形成论证中不宜直接译为国家；恢复原注4。')
add(rr(81,6),rr(38,16),end='在一个狩猎民族')
add(rr(81,7),rr(38,16,20),'quote',start='在一个狩猎民族')
add(rr(81,8)+rr(82,1),rr(38,21,22),'quote')
add(rr(82,2),rr(38,23,24))
add(rr(82,3),rr(38,25,27))
add(rr(82,4),rr(38,28,31),end='猎人的壮举')
add(rr(82,5),rr(38,30,36)+rr(39,0,1),'quote',start='猎人的壮举')
add(rr(82,6),rr(39,2,4))
add(rr(82,7)+rr(83,1),rr(39,5,8),end='居住在这样国家',fixes=[('设防城镇人口规模大于当地酋长统治区域——后者通常由几个小部落组成','设防城镇的人口比当地酋长所统治的聚落更多，通常由几个小部落组成')],reason='comprising several small tribes修饰设防城镇，旧译将修饰关系倒置。')
add(rr(83,2),rr(39,8,17),'quote',start='居住在这样国家')
add(rr(83,3),rr(39,18,19),'quote')
add(rr(83,4),rr(39,20,21),end='据称')
nt={1:'弗里德里希·恩格斯、Tristram Hunt：《家庭、私有制和国家的起源》（The Origin of the Family, Private Property and the State）（Penguin，2010）。',2:'顾名思义，这些是他担任格拉斯哥大学哲学教授时所讲授的课程。20世纪中叶，人们在John Anderson的笔记中发现了这些讲义的记录；Anderson曾是斯密的学生，后来也成为教授。',3:'恩格斯、Hunt：《家庭、私有制和国家的起源》，第IX章。',4:'亚当·斯密：《法理学讲义》（Lectures on Jurisprudence），《亚当·斯密著作与通信格拉斯哥版》，1978，第I部分第2节。',5:'斯密：《法理学讲义》，《亚当·斯密著作与通信格拉斯哥版》，第I部分第2节。',6:'“国家是阶级矛盾不可调和的产物和表现。国家是在阶级矛盾客观上不能调和的地方、时候和程度上产生的。反过来说，国家的存在证明阶级矛盾不可调和。”V. I. 列宁：《国家与革命》（State and Revolution）（Haymarket Books，2015），第1章第1部分。',7:'斯密：《法理学讲义》，《亚当·斯密著作与通信格拉斯哥版》，第I部分第2节。',8:'斯密：《法理学讲义》，《亚当·斯密著作与通信格拉斯哥版》，第I部分第3节。'}
notes=[]
for n,refs in note_groups([[252,3]]):
    if n not in nt:continue
    notes.append({'id':f'dm-ch05-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['243'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch05a',5,rows,notes,rr(80,0,8)+rr(81,1,8)+rr(82,1,7)+rr(83,1,4))
(W/'checkpoint_ch05a.json').write_text(json.dumps({'next_source_pdf_page':83,'next_source_block':5,'next_supplied_pdf_page':39,'next_supplied_block':21,'next_unit':len(rows)+1,'next_note':9,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
