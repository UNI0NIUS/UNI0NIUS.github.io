from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch07-{len(rows)+118:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(170,6),rr(88,0,1))
add(rr(170,7),rr(88,2,3))
add(rr(170,8),rr(88,4))
add(rr(170,9)+rr(171,1),rr(88,5,7))
add(rr(171,2),rr(88,8,9),text=r'尽管书名如此，布尔几乎没有讨论上文所说的三条思维规律。不过，他把“x且x=x”称为“思维的基本规律”（第49页），并由此提出矛盾律，即任何事物都不可能既是x又不是x。',english=extract(EN,rr(171,2),True).replace('x and x x =','x and x = x'),reason='恢复被提取错序的等号，and为逻辑合取。')
add(rr(171,3),rr(88,10,12))
add(rr(171,4),rr(88,13,15),fixes=[('一直延续到20 世纪','一直延续到20世纪相当长的一段时期')])
add(rr(171,5),rr(88,16),'heading')
add(rr(171,6),rr(88,17,18),text='德国数学家戈特洛布·弗雷格（1848—1925）把布尔的进路倒转过来，试图把算术、继而把数学建立在逻辑之上。支撑计算的数理逻辑，最终源自弗雷格的工作。',reason='turned on its head指倒转奠基关系，不是全面颠覆布尔理论。')
en=extract(EN,rr(171,7),True).replace('Begriffsschrift,32,33','Begriffsschrift,[[32]],[[33]]')
add(rr(171,7),rr(88,19),end='一种',english=en,text='弗雷格的《概念文字》[[32]]、[[33]]出版于1879年，其副标题是：',reason='补漏32/33，并分离副标题引文。')
add(rr(171,8),rr(88,19),'quote',start='一种')
add(rr(171,9),rr(88,20))
add(rr(171,10),rr(88,21,24),fixes=[('“主语”和“谓语”','“主项”和“谓项”'),('全称量化运算符','全称量词')])
add(rr(171,11),rr(88,25,27))
add(rr(172,1),rr(88,28))
add(rr(172,2),rr(88,29,30),'quote')
nt={30:'请注意，布尔没有使用真值表。不过，他在第76页实际上给出了否定的真值表。',31:'C. E. Shannon：“继电器与开关电路的符号分析”（A Symbolic Analysis of Relay and Switching Circuits），American Institute of Electrical Engineers Transactions，第57卷（1938），第713—723页。',32:'字面意思是“概念文字”。',33:'G. Frege：“概念文字：一种仿照算术语言构造的纯思维公式语言”（Begriffsschrift, a Formula Language, Modeled Upon that of Arithmetic, for Pure Thought），载《从弗雷格到哥德尔：数理逻辑文献集，1879—1931》（From Frege to Gödel: A Source Book in Mathematical Logic, 1879-1931），J. van Heijenoort编，S. Bauer-Mengelberg英译（Harvard University Press，1967）。',34:'G. Frege：《算术基础》（The Foundations of Arithemtic），J. L. Austin英译（Harper，1953）。',35:'G. Frege：《算术基本规律：体系的阐述》（The Basic Laws of Arithmetic: Exposition of the System），M. Furth英译（University of California Press，1964）。'}
notes=[]
for n,refs in note_groups(rr(264,1)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch07-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['255'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch07h',7,rows,notes,rr(170,6,9)+rr(171,1,11)+rr(172,1,2))
(W/'checkpoint_ch07h.json').write_text(json.dumps({'next_source_pdf_page':172,'next_source_block':3,'next_supplied_pdf_page':88,'next_supplied_block':31,'next_unit':len(rows)+118,'next_note':36,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
