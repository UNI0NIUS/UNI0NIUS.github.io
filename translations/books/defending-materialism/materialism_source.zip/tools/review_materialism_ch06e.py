from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch06-{len(rows)+65:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
en=extract(EN,rr(142,3),True).replace('volume vo ',r'volume $v_0$ ').replace('v v < 0',r'$v<v_0$')
add(rr(142,3),rr(71,24,26),end='从热力学理论',english=en,text=r'接着，他把玻尔兹曼的熵公式用于体积为$v_0$的气体中的分子，推导出当全部分子都处于子体积$v<v_0$内时的熵变公式；这基本上是上一章半个圆筒例子的推广。结果表明，气体熵变公式与他推导出的单色辐射熵变公式具有相同的函数形式。[[23]]他由此得出结论：',reason='将旧译错置于下段末的23注归位；functionally the same为函数形式相同。')
add(rr(142,4,7),rr(71,26,27),'quote',text=r'从热理论来看，低密度单色辐射（在维恩辐射公式的适用范围内）的行为，仿佛它由大小为$\frac{R\beta\nu}{N}$的独立能量量子组成。*',english=r'In terms of heat theory monochromatic radiation of low density (within the realm of validity of Wien’s radiation formula) behaves as if it consisted of independent energy quanta of the magnitude $\frac{R\beta\nu}{N}$. >8*',reason='据源图恢复分式与希腊字母，并保留星号原注标记。')
rows[-1]['editor_note']='底本公式后有“>8”异常字符，英文照录；中文保留句号和星号，不将异常字符解释为公式或注号。'
add(rr(142,11,17),[],'quote',english=r'* The modern notation for this is $h\nu$ for $h=$ Plank’s constant and $\nu$ frequency. He wrote $\frac{R\beta\nu}{N}$ but his $R,\beta,N\ \frac{n!}{r!(n-r)!}$ constants ensure $\frac{R\beta}{N}=h$.',text=r'〔原书星号页脚注〕* 这一量的现代记法是$h\nu$，其中$h$为普朗克常数，$\nu$为频率。他写成$\frac{R\beta\nu}{N}$，但他所用的常数$R,\beta,N$保证$\frac{R\beta}{N}=h$。底本在常数列表后另印有$\frac{n!}{r!(n-r)!}$。',reason='恢复旧译完全遗漏的星号页脚注；据源图逐项重建公式。')
rows[-1].update(original_note_marker='*',editor_note='底本在R、β、N后混入组合数分式n!/[r!(n−r)!]，与当前句意不相衔接。英文保留原位置，中文说明其原有位置，不将其改写为新的物理关系；Plank拼写亦照录英文。')
add(rr(142,8),rr(71,28,32))
add(rr(142,9),rr(71,33,35))
add(rr(142,10)+rr(143,1),rr(72,0,4))
add(rr(143,2),rr(72,5,6))
add(rr(143,3),rr(72,7,8),end='一个世纪前',fixes=[('停止电压','截止电压')])
add(rr(143,4),rr(72,8,11),start='一个世纪前',fixes=[('拍摄噪声','散粒噪声'),('现代技术使我们能够观察到光量子化现象。','现代技术使我们能够在手机上观察到光的量子化现象。')],reason='shot noise为散粒噪声；补回cell phones。')
add(rr(143,5),rr(72,12,14))
en=extract(EN,rr(143,6),True).replace('e mc = 2 formula.25',r'$e=mc^2$ formula.[[25]]')
add(rr(143,6),rr(72,15,19),end='贝希托尔德',english=en,text=r'他在1905年的最后两篇论文讨论了狭义相对论，[[24]]并推导出著名的$e=mc^2$公式。[[25]]他推导相对论时使用的论证与唯物主义问题只有间接联系，所以这里不作讨论。[[26]]物质与能量彼此等价的结论，既具有哲学意义，也具有巨大的实践意义。在哲学上，它削弱了把“能量论”当作唯物主义替代方案的可能性。[[27]]在历史上，它开启了原子能及其所带来的一切可能。如果说有什么让原子观念深入公众心中，那就是原子能。',reason='补回24—27注号并恢复质量能量公式；tangentially恢复间接关系。')
add(rr(143,7),rr(72,19,21),start='贝希托尔德',text='贝希托尔德[[28]]把马赫的原子观概括如下：“马赫的原子观可以归纳为五个主要观点：（a）原子不作为自在之物存在；（b）原子概念只是感觉复合体的思想符号；（c）原子论是一种没有成果的假说；（d）原子论是一种人为的假说；（e）原子论是一种没有充分依据的假说。”',reason='原注28归位；in themselves译出自在之物含义，统一感觉复合体。')
add(rr(143,8),rr(72,22,23))
nr={23:rr(260,11,16)+[[260,17,0,1]],24:[[260,17,1,2]],25:[[260,17,2,3]],26:[[260,17,3,5]],27:[[260,17,5,10]],28:[[260,17,10,13]]}
nt={23:r'$S-S_0=k\ln\left(\frac{v}{v_0}\right)^n$，其中$n$为气体分子的数量。这显然与他先前给出的电磁熵变方程具有相同的函数形式。',24:'Einstein：“论运动物体的电动力学”（On the Electrodynamics of Moving Bodies）。',25:'Einstein：“物体的惯性是否取决于其能量含量”（Does the Inertia of a Body Depend Upon its Energy-content）。',26:'尚未读过的读者或许会喜欢A. Einstein的《相对论》（Relativity）（Methuen/Company，1920）；他在书中为非专业读者作了说明。',27:'在非技术性论述中，能量概念长期带有神秘主义意味：vis viva（活力）呼应élan vital（生命冲力），又逐渐滑向神秘能量——参见Adrian Tait：“[一种]神秘而不可言说的力与能量”（[A] Mystic, Ineffable Force and Energy），Arthur Machen: Critical Essays，2021，第193页——或昆达里尼能量——参见Lilian Silburn：《昆达里尼：深处的能量》（Kundalini: The Energy of the Depths）（SUNY Press，1988）。不知为何，原子似乎并未对神秘主义边缘群体产生同样的吸引力。',28:'Manuel Bächtold：“为马赫的原子观辩护”（Saving Mach’s View on Atoms），Journal for General Philosophy of Science / Zeitschrift für allgemeine Wissenschaftstheorie，第41卷第1期（2010），第1—19页，ISSN：09254560、15728587，http://www.jstor.org/stable/20722524。'}
notes=[]
for n,refs in nr.items():
    en=extract(EN,refs,True)
    if n==23:en=r'23 $S-S_0=k\ln\left(\frac{v}{v_0}\right)^n$ where n is the number of gas molecules. This was clearly the same functional form as the equation for change in electromagnetic entropy he gave earlier.'
    notes.append({'id':f'dm-ch06-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['251'],'en':en,'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch06e',6,rows,notes,rr(142,3,17)+rr(143,1,8))
(W/'checkpoint_ch06e.json').write_text(json.dumps({'next_source_pdf_page':143,'next_source_block':9,'next_supplied_pdf_page':72,'next_supplied_block':24,'next_unit':len(rows)+65,'next_note':29,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
