from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch05-{len(rows)+137:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(100,4),rr(49,0))
add(rr(100,5),rr(49,1,2),'quote',text='正如如今已得到广泛承认的那样，这个出发点并不是源自恩格斯、又经斯威齐和米克等作者普及的正统解释所认为的那种简单商品生产社会——无论它是理想类型，还是更糟，是历史上实际存在过的社会。',reason='ideal-typical指理想类型，旧译理想—典型不明；明确as in所指的正统解释。')
add(rr(100,6),rr(49,3,5),end='如果我们回',fixes=[('迈克尔（Meikle）','米克尔（Meikle）'),('亚里士多德。马克思','亚里士多德。[[57]]马克思'),('等价形式','等价形式')],reason='恢复遗漏的原注57并修正Meikle译名。')
add(rr(100,7),rr(49,5,7),'quote',start='如果我们回')
add(rr(100,8),rr(49,8,9),'quote')
add(rr(100,9),rr(49,10),'quote')
add(rr(100,10),rr(49,11,13),'quote',fixes=[('质量上','质上'),('可比量','可通约的量'),('没有平等，交换就无法进行；没有可比性，平等也就无从谈起','没有相等就不能交换，没有可通约性就不能相等')],reason='qualitatively指质而非质量优劣；commensurability为可通约性，equality在数量关系中为相等。')
add(rr(101,1),rr(49,14,16),'quote',text='……'+extract(ZH,rr(49,14,16)).replace('可比性','可通约性').replace('质量上','质上'),reason='恢复原引文起首删节号，统一质上相等及可通约性。')
add(rr(101,2),rr(49,17,20),'quote',fixes=[('共同实质','共同实体')])
add(rr(101,3),rr(49,21,24),'quote',fixes=[('质量相等劳动','质上相等的劳动'),('作为一种普遍偏见固定下来','取得一种普遍成见的牢固性')],reason='equal quality指质的相同；popular prejudice保留成见含义，避免仅译偏见导致句意失真。')
add(rr(101,4),rr(49,25))
add(rr(101,5),rr(49,26),'list_item')
add(rr(101,6),rr(49,27),'list_item',fixes=[('古典雅典','古代雅典')])
add(rr(101,7),rr(49,28,29),'list_item')
add(rr(101,8),rr(49,30,34),end='易燃化石',fixes=[('共同实质','共同实体'),('燃烧的“燃素”理论','解释燃烧的“燃素”[[58]]理论')],reason='恢复遗漏原注58；明确燃素说解释的是燃烧现象。')
nt={57:'S. Meikle：《亚里士多德的经济思想》（Aristotle’s Economic Thought）（Oxford University Press，1997）。',58:'该理论把一种共同实体——燃素——设定为火的本质。这似乎能够解释各种观察结果，但后来被证明是错误的。'}
notes=[]
for n,refs in note_groups(rr(255,4)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch05-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['246'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch05k',5,rows,notes,rr(100,4,10)+rr(101,1,8))
(W/'checkpoint_ch05k.json').write_text(json.dumps({'next_source_pdf_page':102,'next_source_block':1,'next_supplied_pdf_page':49,'next_supplied_block':34,'next_unit':len(rows)+137,'next_note':59,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
