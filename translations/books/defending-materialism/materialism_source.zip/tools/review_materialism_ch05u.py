from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch05-{len(rows)+265:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(117,2),rr(59,17),'heading',text='新的原子论')
add(rr(117,3),rr(59,17),'quote',start='化学家',fixes=[('又一项新证明','一项项新证明'),('[[9]] [[8]]','[[98]]')])
add(rr(117,4),rr(59,18,20),fixes=[('应存在衍射现象，','应存在衍射现象，[[99]]')],reason='恢复漏注99。')
add(rr(117,5),rr(59,21),'heading')
add(rr(117,6),rr(59,22,24),end='他在研究',fixes=[('伊壁鸠鲁学派历史叙述中','伊壁鸠鲁学派的历史叙述中[[100]]')],reason='恢复漏注100。')
add(rr(117,7),rr(59,24,26),start='他在研究',fixes=[('不同气体在水中可溶解量实验过程中，','不同气体在水中可溶解量的实验过程中，[[101]]'),('规则晶格','规则网格')],reason='补注101；regular grid未断言晶体结构。')
add(rr(117,8),rr(59,27,29),end='如今，本研究')
add(rr(117,9),rr(59,29,31),'quote',start='如今，本研究',fixes=[('如今，本研究','本书'),('较小化合物粒子','较简单的复合粒子'),('[[10]] [[2]]','[[102]]')],reason='less compound是组成复杂程度较低而不是尺寸更小；now是论述转接词，不指当代。')
add(rr(117,10)+rr(118,1),rr(59,32,34),end='在把这一理论')
add(rr(118,2),rr(59,33,36),'quote',start='在把这一理论',fixes=[('[[10]] [[3]]','[[103]]')])
add(rr(118,3),rr(59,37,38))
nt={98:'Ludwig Boltzmann：《理论物理学与哲学问题：文选》（Theoretical Physics and Philosophical Problems: Selected Writings），第5卷（Springer Science & Business Media，2012），第14页。',99:'Newton：《自然哲学的数学原理……由Andrew Motte翻译……附牛顿的世界体系；W. Emerson对〈原理〉的简评与辩护；John Machin依据引力论述的月球运动定律……（先生的序言）》（The Mathematical Principles of Natural Philosophy . . . Translated . . . by Andrew Motte. To Which are Added Newton’s System of the World; A Short Comment on, and Defence of the Principia, by W. Emerson. With the Laws of the Moon’s Motion According to Gravity, by John Machin . . .(The Preface of Mr)），第8节，命题XLI。',100:'J. J. Brucker与W. Enfield：《哲学史：从最早时代到本世纪初；由William Enfield根据布鲁克的〈哲学批判史〉编写》（The History of Philosophy, from the Earliest Times to the Beginning of the Present Century; Drawn up from Brucker’s Historia Critica Philosophiæ: by William Enfield），《哲学史：从最早时代到本世纪初；由William Enfield根据布鲁克的〈哲学批判史〉编写》，第1卷（P. Wogan，1792），https://books.google.co.uk/books?id=ximMZcSJY8gC。',101:'John Dalton：“III. 论水和其他液体对气体的吸收”（III. On the Absorption of Gases by Water and Other Liquids），The Philosophical Magazine，第24卷第93期（1806），第15—24页。',102:'John Dalton：《化学哲学新体系》（A New System of Chemical Philosophy），第1卷（Bickerstaff，1808），第213页。',103:'Dalton：“III. 论水和其他液体对气体的吸收”，第73页。'}
notes=[]
for n,refs in note_groups(rr(257,1)):
    if n not in nt:continue
    note={'id':f'dm-ch05-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['248'],'en':extract(EN,refs,True).replace('\u200b','').replace('uk/ books','uk/books'),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'}
    if n==99:note['editor_note']='本注书目在底本中包含截断的(The Preface of Mr)，按原样保留，不推补缺失信息。'
    if n==100:note['editor_note']='本注底本重复列出书名，中文同样保留重复书目信息。'
    notes.append(note)
save('ch05u',5,rows,notes,rr(117,2,10)+rr(118,1,3))
(W/'checkpoint_ch05u.json').write_text(json.dumps({'next_source_pdf_page':118,'next_source_block':4,'next_supplied_pdf_page':60,'next_supplied_block':0,'next_unit':len(rows)+265,'next_note':104,'pending_table':'PDF118 blocks9-16 Table5.1 not yet restored','full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
