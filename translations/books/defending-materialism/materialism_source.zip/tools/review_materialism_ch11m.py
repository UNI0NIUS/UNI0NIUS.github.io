from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch11-{len(rows)+143:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(236,5),rr(126,33,36),'quote',text='辩证法内容的这一方面是否正确，必须由科学史来检验。辩证法的这一方面（例如在普列汉诺夫那里）通常没有得到足够注意：对立面的同一性被当作例子的总和［“例如，一粒种子”，“例如，原始共产主义”。恩格斯那里也是如此。但这是“为了普及……”］，而不是当作认识的规律（以及客观世界的规律）。',reason='按原书括号恢复引文内部层次，旧译错误闭合了方括号。')
texts=['1. 在数学中：＋与－。微分与积分。','2. 在力学中：作用与反作用。','3. 在物理学中：正电与负电。','4. 在化学中：原子的结合与解离。','5. 在社会科学中：阶级斗争。']
for i,t in enumerate(texts):add([[236,6,2*i,2*i+2]],rr(126,37) if i==0 else rr(127,i-1),'list_item',text=t)
en=extract(EN,rr(236,7),True).replace('33,34','[[33]][[34]]')
add(rr(236,7),rr(127,4,7),'quote',text='对立面的同一性（说它们的“统一性”也许更准确，尽管同一性与统一性这两个术语的区别在这里并不特别重要；在某种意义上，二者都正确），就是承认（发现）自然界（包括思维和社会）的一切现象和过程中存在着相互矛盾、相互排斥、相互对立的趋势。要认识世界的一切过程的“自己运动”、自发发展和实际生活，条件就是把这些过程作为对立面的统一来认识。[[33]][[34]]',english=en,reason='恢复两个相邻原注；self-movement与spontaneous development分别译出。')
rows[-1]['source_transcription_note']='依PDF236右下角上标33,34恢复两个注号，原引文英文保留。'
add(rr(236,8)+rr(237,1),rr(127,8,10),text='我们认为，列宁对这些例子的解释，以及毛泽东对这一解释的默许，具有误导性。为说明这一点，先把例子分组：（1）属于算术，即人类的一种技艺或技术；（2、3、4）属于自然科学；（5）属于社会科学。')
add(rr(237,2),rr(127,11,12),text=r'加法与减法、乘法与除法、微分与积分等，都是数学中互逆运算的例子。如果$\alpha,\beta$是互逆运算符，那么$((A\alpha B)\beta B)=A$；把$\alpha,\beta$称作相反的运算，是完全合理的。',english=r'Addition and subtraction, multiplication and division, differentiation and integration etc., are examples of inverse operators in maths. If $\alpha,\beta$ are inverse operators then $((A\alpha B)\beta B)=A$, and it is quite reasonable to call $\alpha,\beta$ opposite operations.',reason='恢复提取遗漏的希腊字母及公式；补旧译漏掉的“完全合理”判断。')
add(rr(237,3),rr(127,13,16),text='算术是一门技术性技艺。它涉及实物，如筹码、算珠和账簿中的符号。在20世纪30年代，俄国或中国的商业算术主要使用算盘。加2时，操作者把2颗算珠从右移到左；减2时，把2颗算珠从左移到右。先加后减之后，算珠就回到起初的状态。正是这种回到起始状态的性质，使加法与减法成为作用于状态的互逆运算。',reason='tokens在算术工具语境译筹码，不译代币；保留作者对算盘操作的概述。')
add(rr(237,4),rr(127,17,19),text=r'但若要声称对立统一具有普遍性，就会遇到问题。首先，很容易找出并非彼此互逆的运算符对。在逻辑中，与（$\wedge$）和或（$\vee$）作为两个基本运算符成对出现，但它们并不互逆：$((A\wedge B)\vee B)\ne A$。那么，为什么要声称相反的运算符是根本的呢？',english=r'But if one wants to claim that the unity of opposites is universal, then there are problems. For a start, it is easy to come up with pairs of operators that are not inverse of one another. In logic, AND ($\wedge$) is paired with OR ($\vee$) as the two basic operators, but these are not inverses: $((A\wedge B)\vee B)\ne A$. So why claim that opposite operators are fundamental?')
add(rr(237,5),rr(127,20,22),text='这难道不是挑选有利例子来支持论点吗？是的，声称对立统一是数学的根本，是武断的。的确，数学有互逆运算符，但也有其他重要的运算符。')
add(rr(237,6),rr(127,23),text='如果回到加法和减法使算盘或其他计算器恢复起始状态这一想法，情况会有所不同吗？')
add(rr(237,7),rr(127,24),text='使某物恢复起始状态，总是需要一对互逆运算吗？')
add(rr(237,8),rr(127,25,27),text='不。考虑把一个轮子旋转半圈的操作。执行两次，轮子便回到起始状态。算术中的类似操作是乘以－1。对一个数执行两次，就回到原来的数。因此，回到起点这一观念，同样不能证明对立统一的必然性。')
add(rr(237,9),rr(127,28,29),text='接下来三个例子——作用与反作用、正负电荷以及原子的结合与解离——确实有共同之处，但诉诸对立统一，只能部分说明这种共同之处，遗漏了最重要的东西。')
add(rr(237,10),rr(127,30),text='它们都是底层守恒定律的表达方式，或是这些定律的推论。',reason='underlying不是潜在；这里指基础层面的守恒定律。')
add(rr(237,11),rr(127,31,32),text='大小相等、方向相反的力源于动量守恒。例如，地球与月球彼此施加大小相等、方向相反的引力，使这一系统所受的合力为零。如果没有太阳从外部施加的引力，地月系统就会沿直线运动，保持动量守恒。')
notes=[]
for n,refs,zh in [(33,[[272,3,13,16]],'毛泽东只引用了第1至第5项。我们把前后段落也列出，以提供上下文，因为毛泽东在文中其他地方似乎隐含地依赖这一段。第1至第5项的明确编号是我们添加的，列宁原文中它们只是一个未编号的列表。'),(34,[[272,3,16,18]],'V. I. Lenin：“谈谈辩证法问题”，载《列宁全集》第38卷（Progress Publishers，1915）。')]:
    notes.append({'id':f'dm-ch11-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['263'],'en':extract(EN,refs,True),'zh':str(n)+'. '+zh,'status':'text_compared_layout_pending'})
save('ch11m',11,rows,notes,rr(236,5,8)+rr(237,1,11))
(W/'checkpoint_ch11m.json').write_text(json.dumps({'next_source_pdf_page':237,'next_source_block':12,'next_supplied_pdf_page':128,'next_supplied_block':0,'next_unit':len(rows)+143,'next_note':35,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
