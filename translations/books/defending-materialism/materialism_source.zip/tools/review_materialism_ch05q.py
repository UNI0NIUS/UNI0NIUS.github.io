from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch05-{len(rows)+217:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(110,1),rr(55,14),end='由于这种')
add(rr(110,2),rr(55,14,21),'quote',start='由于这种',fixes=[('只要在任何物种的个体与其与其他有机体及外部自然环境的无限复杂关系中，能带来任何程度益处','只要在某一物种的个体与其他生物及外部自然环境的无限复杂关系中，能给该个体带来任何程度的益处'),('因此，后代也将因此','后代也将因此'),('把生物适应于自身需求','使生物适合自身需求'),('[[7]] [[6]]','[[76]]')],reason='修正旧译重复主语、状语及使动语病，恢复原注76。')
add(rr(110,3),rr(55,22,25),fixes=[('相提并论','相互对照'),('[[7]] [[7]]','[[77]]')],reason='contrasted在此强调两理论的对比，不是等量齐观。')
add(rr(110,4),rr(55,26),end='关于变异',fixes=[('[[7]] [[8]]','[[78]]')])
add(rr(110,5),rr(55,26,31),'quote',start='关于变异',fixes=[('已受到影响。事实上','已受到影响。……事实上'),('“突变体”','“变异体”'),('[[7]] [[9]]','[[79]]')],reason='恢复引文中间删节号，sports与下一段译名统一。')
add(rr(110,6),rr(55,32,34))
add(rr(111,1),rr(55,35,36))
add(rr(111,2),rr(55,37,39)+rr(56,0,1),end='“没有一种')
add(rr(111,3),rr(56,1,3),'quote',start='“没有一种',text='举不出任何一种家养动物，它在所有国家都不出现垂耳；一些作者提出，垂耳是因为这些动物不常受到危险惊吓，导致耳部肌肉不用，这一看法似乎是可信的。[[80]]',reason='厘清否定与存在量词：每种家养动物都在某个国家有垂耳现象，不是所有国家一律如此。')
add(rr(111,4),rr(56,4,9),fixes=[('现代研究证实了这一经验观察结果，','这一经验观察结果得到了现代研究的证实，[[81]]'),('经过五十多年选择性育种','经过五十年的选择性育种'),('[[8]] [[2]]','[[82]]')],reason='补回遗漏81；Over fifty years在此指历经五十年，去除无依据的“多”。')
add(rr(111,5),rr(56,10,12))
add(rr(111,6),rr(56,13),end='“每个')
add(rr(111,7),rr(56,13,14),'quote',start='“每个',fixes=[('[[8]] [[3]]','[[83]]')])
nt={76:'Charles Darwin：《物种起源》（On the Origin of the Species）（Project Gutenberg电子书，2009），第3章。',77:'Charles Darwin：《人和动物的情感表达》（The Expression of the Emotions in Man and Animals）（Project Gutenberg电子书，1998）。',78:'Darwin：《物种起源》。',79:'Darwin：《物种起源》，第1章。',80:'Darwin：《物种起源》，第1章。',81:'Lyudmila N. Trut、I. Z. Plyusnina与I. N. Oskina：“狐狸驯化实验及狗演化中的争议问题”（An Experiment on fox Domestication and Debatable Issues of Evolution of the Dog），Russian Journal of Genetics，第40卷第6期（2004），第644—655页。',82:'Adam S. Wilkins、Richard W. Wrangham与W. Tecumseh Fitch：“哺乳动物的‘驯化综合征’：基于神经嵴细胞行为与遗传学的统一解释”（The “Domestication Syndrome” in Mammals: A Unified Explanation Based on Neural Crest Cell Behavior and Genetics），Genetics，第197卷第3期（2014），第795—808页。',83:'Darwin：《物种起源》，第3章。'}
notes=[]
for n,refs in note_groups(rr(256,1)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch05-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['247'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch05q',5,rows,notes,rr(110,1,6)+rr(111,1,7))
(W/'checkpoint_ch05q.json').write_text(json.dumps({'next_source_pdf_page':111,'next_source_block':8,'next_supplied_pdf_page':56,'next_supplied_block':15,'next_unit':len(rows)+217,'next_note':84,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
