from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch07-{len(rows)+54:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(165,8),rr(84,0,1))
add(rr(165,9),rr(84,2),end='他就会')
add(rr(165,10),rr(84,2,4),'quote',start='他就会',text='他就越会在不知不觉中形成一门与辩证法和修辞学完全不同的科学。因为一旦找到第一原理，那就不再是辩证法或修辞学，而是他已经掌握其原理的那门科学。（第31页）',reason='原文到达的是该科学的原理，而非推导出一门科学；保留the more递进。')
add(rr(165,11),rr(84,5,7))
add(rr(165,12),rr(84,8,12))
add(rr(166,1),rr(84,13),'heading')
add(rr(166,2),rr(84,14,15),end='数学也有',text='上文已提到，“三艺”中的逻辑有别于“四艺”中的算术、几何学和天文学这些数学科学。此外，亚里士多德在《形而上学》[[12]]中指出，数学具有层级：',reason='补漏注12，并从旧译合并段拆出引文。')
add(rr(166,3),rr(84,15,16),'quote',start='数学也有')
add(rr(166,4),rr(84,17),end='人们确实')
add(rr(166,5),rr(84,17,19),'quote',start='人们确实',fixes=[('首要的哲学','第一哲学')])
add(rr(166,6),rr(84,20,21),end='此外，他')
add(rr(166,7),rr(84,21,23),'quote',start='此外，他')
add(rr(166,8),rr(84,24,26),text='对柏拉图主义者而言，形式是抽象的理念，但仍具有实在性。[[13]]我们认为，数学对象通过其在符号系统中的物理表征而具有物质存在。例如，理念中的立方体无非就是数学立方体，而数学立方体本身是一种表征物理立方体的物质化构造。',reason='原注13归位；ideal不是理想化愿景，明确形式/理念与物理表征的对照。')
add(rr(166,9),rr(84,27),'heading')
add(rr(166,10),rr(84,28,29))
add(rr(166,11),rr(84,30,31))
nt={11:'Aristotle：《前分析篇》（Prior Analytics），H. Tredennick英译，洛布古典丛书（William Heinemann，1962）。',12:'Aristotle：《形而上学》，第I—IX卷（The Metaphysics, Books I–IX）。',13:'Plato：《理想国》（The Republic），P. Shorey英译，第1卷，洛布古典丛书（Harvard，1937）；Plato：《理想国》，P. Shorey英译，第2卷，洛布古典丛书（Harvard，1962）。',14:'R. Smith：“亚里士多德的逻辑”（Aristotle’s Logic），载Plato（Stanford Encyclopedia of Philosophy，2017），https://plato.stanford.edu/entries/aristotle-logic/#AriLogWorOrg 。'}
notes=[]
for n,refs in note_groups(rr(263,3)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch07-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['254'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch07d',7,rows,notes,rr(165,8,12)+rr(166,1,11))
(W/'checkpoint_ch07d.json').write_text(json.dumps({'next_source_pdf_page':166,'next_source_block':12,'next_supplied_pdf_page':84,'next_supplied_block':32,'next_unit':len(rows)+54,'next_note':15,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
