from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch03-{len(rows)+253:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(57,5),rr(25,36),'heading')
add(rr(57,6),rr(25,37)+rr(26,0,1),end='追求真理',fixes=[('《物理学制度》','《物理学基础》（Institutions Physiques）')],reason='书名Institutions在此非政治或社会制度，采用物理学基础并保留原名。')
add(rr(57,7),rr(26,1,2),'quote',start='追求真理')
add(rr(57,8),rr(26,3,4))
add(rr(57,9),rr(26,5,6),end='例如中世纪')
add(rr(57,10)+rr(58,1),rr(26,6,9),start='例如中世纪',end='因此，他们')
rows[-1]['editor_note']='此处原作者写heliocentrism（日心说），但紧接着引文说的是被哥白尼放弃的托勒密假说，二者不一致。正文保留原作者用词，不静默改为地心说。'
add(rr(58,2),rr(26,9,12),'quote',start='因此，他们')
add(rr(58,3),rr(26,13,15),'quote',fixes=[('[[4]] [[0]]','[[40]]')],reason='恢复PDF将两位数拆开的原注40。')
add(rr(58,4),rr(26,16))
add(rr(58,5,7),rr(26,17,19),'quote')
add(rr(58,8),rr(26,20,22))
add(rr(58,9),rr(26,23,25),fixes=[('连续微分函数','连续可微函数')],reason='此处指微积分所用函数的连续可微性质。')
add(rr(59,1),rr(26,26,27))
add(rr(59,2),rr(26,28,29),end='现在，由于')
add(rr(59,3),rr(26,28,29),'quote',start='现在，由于',fixes=[('[[4]] [[1]]','[[41]]')],reason='恢复原注41。')
add(rr(59,4),rr(26,30))
add(rr(59,5),rr(26,31))
add(rr(59,6),rr(26,32,33))
add(rr(59,7),[],'paragraph','请看下图。[[42]]',reason='恢复原图引导句及原注42。')
add([],[],'figure','摆的几何关系（原书无编号插图）。',english='Pendulum geometry (unnumbered diagram).',reason='恢复中文底稿遗漏的插图；说明由编者补充。')
rows[-1].update(image='assets/pendulum-energy.png',source_image={'pdf_page':59,'block':8},printed_pages=['50'],image_labels_zh='A、C：两个起始点；O：摆心；B：最低点；R：摆长；R/2：C点相对最低点的高度；D：辅助投影点。',editor_note='原书没有为此图另列图号和图注；上方原注42说明由作者绘制。')
add(rr(60,1),rr(26,34))
add(rr(60,2),rr(26,35)+rr(27,0))
add(rr(60,3),rr(27,1),end='又因',fixes=[('CD=R/2',r'$CD=R/2$')])
add(rr(60,4),rr(27,1,2),start='又因',text=r'此外，由于COB是等边三角形，我们知道 $CB=R$；又由于AOB是等腰直角三角形，所以 $AB=\sqrt2 R$。',english=r'Further, since COB is equilateral, we know $CB=R$, and since AOB is an isosceles right triangle, then $AB=\sqrt2 R$.',reason='等边三角形误作等边角，且需恢复根式。')
add(rr(60,5,8),rr(27,3),text=r'因此，两条弦之比为 $AB/CB=\sqrt2$，而下落高度之比为 $OB/CD=2$。',english=r'So we have the relation between chords $AB/CB=\sqrt2$, but that between heights of fall $OB/CD=2$.')
en=extract(EN,rr(60,9),True).replace('e v ≈ 2',r'$e\approx v^2$')
add(rr(60,9),rr(27,4,7),english=en,fixes=[(r'e\propto v^2',r'$e\approx v^2$'),('（杜·沙特莱的“活力”）','（杜·沙特莱的“活力”，forces vives）')],reason='按底本恢复约等号并保留法语术语。')
rows[-1]['editor_note']='底本写e≈v²，但本段文字谈动能与速度平方成正比。约等关系与比例关系含义不同；这里将底本公式与文字一并保留。'
add(rr(60,10),rr(27,8,9),end='我仅想')
add(rr(60,11),rr(27,9,11),'quote',start='我仅想')
add(rr(60,12),rr(27,12))
add(rr(60,13),rr(27,13),'equation',r'$f_1v_1=f_2v_2$',english=r'$f_1v_1=f_2v_2$')
add(rr(60,14,15),rr(27,14),text=r'但速度等于距离除以时间，即 $d/t$，因此，在固定时间间隔内有：',english=r'but velocity is distance over time $d/t$, so over a fixed time interval we have')
add(rr(60,16),rr(27,15),'equation',r'$f_1d_1=f_2d_2$',english=r'$f_1d_1=f_2d_2$')
add(rr(60,17),rr(27,16))
add(rr(61,1),rr(27,17))
add(rr(61,2),rr(27,18,19),end='活力或许',fixes=[('过度使用“力”一词','赋予“力”一词多重含义'),('正确指出力必须','正确指出这种“力”必须')],reason='overloads指术语兼具不同含义，非单纯使用过多；此处力是历史上的活力概念。')
add(rr(61,3),rr(27,19,22),'quote',start='活力或许',fixes=[('[[4]] [[3]]','[[43]]'),('无论他们随后对承认施加何种区分和修改，真理迫使他们承认，','无论他们随后对这一为真理之力所迫作出的承认加以何种区分和修饰，')],reason='修复旧译断句导致的逻辑混乱；恢复原注43。')
add(rr(61,4),rr(27,23),end='宇宙中运动')
add(rr(61,5),rr(27,23,24),'quote',start='宇宙中运动',fixes=[('[[4]] [[4]]','[[44]]')],reason='恢复原注44。')
add(rr(61,6),rr(27,25),end='但当把')
add(rr(61,7),rr(27,25,27),'quote',start='但当把',fixes=[('[[4]] [[5]]','[[45]]')],reason='恢复原注45。')
add(rr(61,8),rr(27,28,33),fixes=[('拉格朗日能推导行星轨道势能和动能','拉格朗日能用势能和动能表述支配行星轨道的定律')],reason='原文是用能量表述轨道定律，不是推导势能与动能本身。')
title='杜·沙特莱：《哲学与科学著作选》（Selected Philosophical and Scientific Writings）'
nt={36:'英译见埃米莉·杜·沙特莱：《哲学与科学著作选》（Selected Philosophical and Scientific Writings）（芝加哥大学出版社，2009）。',37:title+'，《物理学基础》，序言IV。',38:'Ruth Hagengruber：《莱布尼茨与牛顿之间的埃米莉·杜·沙特莱》（Emilie du Châtelet Between Leibniz and Newton）（Springer，2012）。',39:title+'，第132页。她反对植物灵魂的论证，显然也适用于其他灵魂变体和类似宗教解释：精神、自由意志、主体、性别认同等等。',40:title+'，第149页。',41:title+'，第166页。',42:'作者绘图。',43:title+'，第188页。',44:title+'，第199页。',45:title+'，第199页。'}
notes=[]
for n,refs in note_groups([[248,2]]):
    if n not in nt:continue
    notes.append({'id':f'dm-ch03-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['239'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
expected=rr(57,5,10)+[[p,b['block']] for p in range(58,62) for b in EN[p-1]['blocks'] if b.get('lines') and b['block']>0]
save('ch03f',3,rows,notes,expected)
(W/'checkpoint_ch03f.json').write_text(json.dumps({'next_source_pdf_page':62,'next_source_block':1,'next_supplied_pdf_page':28,'next_supplied_block':0,'next_unit':len(rows)+253,'next_note':46,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
