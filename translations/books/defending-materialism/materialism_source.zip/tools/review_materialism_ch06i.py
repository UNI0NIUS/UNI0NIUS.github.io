from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch06-{len(rows)+111:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(149,5)+rr(150,1),rr(75,28,34),end='尽管对应原理',fixes=[('[[4]] [[4]]','[[44]]'),('[[4]] [[5]]','[[45]]')])
add(rr(150,2),rr(75,34,37),'quote',start='尽管对应原理',fixes=[('静止态','定态'),('[[4]] [[6]]','[[46]]')],reason='stationary state为定态，并非静止状态；恢复引文与注号。')
add(rr(150,3),rr(75,38,40)+rr(76,0),end='不过')
add(rr(150,4),rr(76,0,1),start='不过',end='尽管由此')
add(rr(150,5),rr(76,1,3),'quote',start='尽管由此')
add(rr(150,6),rr(76,4,5),'quote',text='这一公设意味着放弃对原子过程作因果性的时空协调描述。事实上，我们通常对物理现象的描述，完全建立在这样一种观念上：可以观察相关现象而不对其造成可察觉的扰动。',reason='renunciation恢复放弃而非让步；co-ordination不误作坐标关系。')
add(rr(150,7),rr(76,6),'quote')
add(rr(150,8)+rr(151,1),rr(76,7,10),'quote',text='而量子公设意味着，任何对原子现象的观察，都涉及与观测装置之间不可忽略的相互作用。因此，既不能赋予现象、也不能赋予观测装置以通常物理意义上的独立实在性。毕竟，观测概念在某种意义上是任意的，因为它取决于哪些对象被纳入待观测的系统。当然，最终每一次观测都可以归结为我们的感觉知觉。[[47]]',reason='agency of observation指观测装置，不限于主观观察者；合并47。')
add(rr(151,2),rr(76,11,13),end='就光而言',fixes=[('观测媒介','观测装置')])
add(rr(151,3),rr(76,13,16),'quote',start='就光而言')
add(rr(151,4),rr(76,17,20),'quote',text='众所周知，这一表面矛盾一方面引起对叠加原理有效性的怀疑，另一方面引起对守恒定律有效性的怀疑；这些怀疑已被直接实验明确排除。这种情况似乎清楚地表明，不可能对光现象作因果性的时空描述。一方面，当我们试图根据量子公设追踪光的时空传播规律时，只能进行统计考量；另一方面，要使以作用量子为特征的单个光过程满足因果性要求，就必须放弃时空描述。[[48]]',reason='原文两方面各自的怀疑，并非两者之间的疑虑；统一量子公设，恢复48。')
add(rr(151,5),rr(76,21,22),fixes=[('[[4]] [[9]]','[[49]]')])
add(rr(151,6),rr(76,23,26),text='首先，他所说的叠加原理指什么？在当代关于量子计算等问题的讨论中，人们谈的是基矢态的叠加；但在20世纪20年代中期，物理学用这个术语指产生干涉的波的叠加。因此，他所说的叠加原理就是光学干涉。他提到的疑虑，即如何把干涉现象与爱因斯坦处理光子时涉及的守恒定律结合起来，正是他本人在玻尔、克拉默斯和斯莱特合著论文中表达的疑虑。[[50]]',reason='base states不译能量最低态意义的基态；作者人名列表不是书名；删除旧译在中残片并合并50。')
nt={44:'Niels Bohr：“I. 论原子和分子的构成”（I. On the Constitution of Atoms and Molecules），The London, Edinburgh, and Dublin Philosophical Magazine and Journal of Science，第26卷第151期（1913），第1—25页。',45:'Niels Bohr、Hendrik Anton Kramers与John Clarke Slater：“LXXVI. 辐射的量子理论”（LXXVI. The Quantum Theory of Radiation），The London, Edinburgh, and Dublin Philosophical Magazine and Journal of Science，第47卷第281期（1924），第785—802页。',46:'Bohr、Kramers与Slater：“LXXVI. 辐射的量子理论”（LXXVI. The Quantum Theory of Radiation）。',47:'Niels Bohr等：《量子公设与原子理论的近期发展》（The Quantum Postulate and the Recent Development of Atomic Theory），第3卷（英国：R. & R. Clarke, Limited印刷，1928）。',48:'Bohr等：《量子公设与原子理论的近期发展》（The Quantum Postulate and the Recent Development of Atomic Theory）。',49:'这里对他1928年论文的阐述参考了Howard和Camilleri的研究：“谁发明了‘哥本哈根诠释’？一项神话研究”（Who Invented the ‘Copenhagen Interpretation’? A Study in Mythology），Philosophy of Science，第71卷第5期（2004），第669—682页；“玻尔、海森堡及其对互补性的不同看法”（Bohr, Heisenberg and the Divergent Views of Complementarity），Studies In History and Philosophy of Science Part B: Studies In History and Philosophy of Modern Physics，第38卷第3期（2007），第514—528页。',50:'Bohr、Kramers与Slater：“LXXVI. 辐射的量子理论”（LXXVI. The Quantum Theory of Radiation）。'}
notes=[]
for n,refs in note_groups(rr(261,3)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch06-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['252'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch06i',6,rows,notes,rr(149,5)+rr(150,1,8)+rr(151,1,6))
(W/'checkpoint_ch06i.json').write_text(json.dumps({'next_source_pdf_page':151,'next_source_block':7,'next_supplied_pdf_page':76,'next_supplied_block':27,'next_unit':len(rows)+111,'next_note':51,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
