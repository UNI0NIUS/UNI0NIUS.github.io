from materialism_common import *

groups=[];pending=[]
for p in [6,7,8]:
    for b in EN[p-1]['blocks'][1:]:
        for j,l in enumerate(b['lines']):
            pending.append([p,b['block'],j,j+1])
            if l['bbox'][0]>350:groups.append(pending);pending=[]
assert not pending
titles='''插图目录
第1章 引言
概述
方法
各章
第2章 探索古希腊提供的概念材料及其影响的跨千年交流
虚空作为运动的前提
无中不能生有：一个至今有效的原则及其科学与哲学—本体论解释
原子论者
第3章 古典原子论
阿基米德
古代唯物主义者对原子论的批判
牛顿
黑格尔对牛顿的批判
杜·沙特莱
机械决定论
第4章 辩证法、唯物主义与变化：从伊壁鸠鲁经亚里士多德到马克思
黑格尔重新塑造辩证法之前的辩证法
Dialektikê、机械性与认知的物质性
根本运动与历史唯物主义，而非辩证唯物主义
苏联式辩证唯物主义的基础及其矛盾
第5章 历史唯物主义者与机械唯物主义者
斯密与恩格斯
国家源于私有财产
狄德罗的非人类中心主义唯物主义世界观
牛顿式的马克思
达尔文与目的论的终结
新的原子论
道尔顿
热、物质与时间
第6章 唯心主义的复兴与回应
对玻尔兹曼的反对
马赫主义
对马赫静电类比的批判
爱因斯坦驳倒马赫主义对原子的反对
哲学上的马赫主义与列宁的介入
量子理论中的唯心主义与唯物主义
第7章 逻辑与唯物主义
引言
逻辑概述
逻辑与辩证法
数学形式
三段论
亚里士多德之后
思维规律
逻辑运算与真值表
逻辑的数学化
弗雷格与数学基础
数与归纳
无限与无穷小
走向无限，并超越无限
第8章 逻辑与辩证唯物主义
黑格尔与逻辑
恩格斯与逻辑
狄慈根、辩证唯物主义与逻辑
罗素悖论与《数学原理》
希尔伯特纲领
元理论与逻辑学派
直觉主义
从布尔什维克革命到孟什维克化唯心主义
孟什维克化唯心主义与逻辑
孟什维克化唯心主义与英国马克思主义
第9章 逻辑危机与反形式主义的登峰造极
引言
哥德尔与完备性
图灵与终止性
丘奇—图灵论题
英国辩证唯物主义者的回应
孟什维克化唯心主义之后的苏联逻辑学
数字计算机
控制论
语言学
苏联逻辑学的复兴
斯大林论语言学
构造主义
第10章 语言、自动机与意义
语言与意义
模型论
巴迪欧、模型论与唯物主义
自动机
语言游戏
文法与自动机
结论
第11章 辩证唯物主义与机械论唯物主义
信息论与唯物主义
物理意义
随机性
幸运眷顾勇者
注释
参考文献
索引'''.splitlines()
assert len(titles)==len(groups),(len(titles),len(groups))
rows=[{'id':'dm-toc-title','kind':'chapter','source_blocks':rr(6,0),'supplied_translation_blocks':[],'printed_pages':['v'],'en':'CONTENTS','zh':'目录','supplied_zh':'','status':'text_compared_layout_pending'}]
for i,(refs,title) in enumerate(zip(groups,titles),1):
    en=extract(EN,refs,True).replace('\b','');locator=en.split()[-1]
    p,b,j,l=next(lines(EN,refs));level=0 if l['bbox'][0]<70 else 1
    rows.append({'id':f'dm-toc-{i:03}','kind':'toc_entry','source_blocks':refs,'supplied_translation_blocks':[],'printed_pages':[{6:'v',7:'vi',8:'vii'}[p]],'en':en,'zh':title+'　'+locator,'supplied_zh':'','toc_level':level,'toc_locator':locator,'status':'text_compared_layout_pending','revision_reason':'补译旧稿省略的目录，保留全部原目录条目、层级与页码。'})
save('front02',0,rows,[],rr(6,0,10)+rr(7,1,4)+rr(8,1,5))
