from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch08-{len(rows)+74:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(186,1),rr(96,32,33),text='这至今仍通常被称为Entscheidungsproblem，即判定问题。还有许多其他判定问题，例如两个公式是否等价；但能在有限步骤内证明性质，被视为关键。')
add(rr(186,2),rr(96,34),'heading',text='元理论与逻辑学派')
add(rr(186,3),rr(97,0,1),text='希尔伯特认为，数学抽象应当、也能够独立于任何应用内容而得到研究。但希尔伯特纲领要求数学本身也接受数学推理。也就是说，应当有以数学为内容的元数学，但目的仅在于确立公理的相容性。[[27]]')
add(rr(186,4),rr(97,2,3),text='数学用语言[[28]]来表达，其中有符号、句法和语义。因此，数学将成为自身的元语言，即一种谈论语言的语言。',reason='补漏注28，syntax译句法。')
add(rr(186,5),rr(97,4,6),text='在罗素悖论出现后的数十年中，形式逻辑形成了三个学派，反映出不同的回应。可以根据各派允许哪些数学实体，以及允许针对这些实体进行哪些数学推理，来刻画它们的特点；也就是说，要看它们认为元数学应当如何进行。[[29]]这归根结底取决于它们对无限的态度。',reason='补漏注29。')
add(rr(186,6),rr(97,7,8),text='以弗雷格和罗素为代表的逻辑主义者，既接受无限的数学实体，也接受康托尔式的无限推理。他们承认观念性的数学实体具有存在，因而是柏拉图主义者，也因此是唯心主义者。',reason='ideal entities译观念性实体，避免理想实体歧义。')
add(rr(186,7),rr(97,9,10),text='其次，以希尔伯特为代表的形式主义者，接受无限的数学实体作为研究对象，但力求只使用有限推理。他们不关心数学实体的存在地位。')
add(rr(186,8),rr(97,11,12),text='最后，直觉主义者采取了最激进的立场。他们以克罗内克为基础，诉诸数学直觉，在数学和元数学中都只接受有限构造。他们还拒斥排中律（LEM），即某事及其否定不可能同时为真。',reason='统一克罗内克译名，保留底本对排中律的误述并另注。')
rows[-1]['editor_note']='底本这里将排中律写成“某事及其否定不可能同时为真”；这实际上是矛盾律的表述。第7章列出的排中律是“任何事物必定或者存在，或者不存在”。正文保留底本措辞。'
add(rr(186,9),rr(97,13,14),text='这些学派的拥护者之间存在深刻的分歧，有时甚至相互谩骂。尽管如此，它们的形式系统实际上联系十分紧密。')
add(rr(186,10),rr(97,15),'heading',text='直觉主义')
add(rr(186,11),rr(97,16,18),text='对康托尔的一种回应是彻底拒斥非有限性方法，实际上也拒斥实数。因此，克罗内克在1886年主张，通过操作无限序列得到的特定结果，只有能够用整数算术重建、而“不超出有限序列的概念”时，才可以接受。[[30]]',reason='non-finitary不是非有限元；series此处用序列，修复注30拆成3与0。')
add(rr(187,1),rr(97,19,23),text='随后，吕伊岑·布劳威尔（1881—1966）的直觉主义致力于利用构造性的有限方法，从少数几个“直觉”概念出发重建形式逻辑。1908年，布劳威尔发表了对经典逻辑的批评，其中的主题在他后来的全部著作中反复出现。[[31]]首先，他认为，脱离数学的逻辑会导致无根据的结论。与形式主义者相反，布劳威尔认为逻辑应当以数学为基础，而数学本身则以观察和对基本真理的原初直觉为基础。不过，他也认为，即使独立于数学，三段论推理和归谬论证都是可接受的（第27、29页）。',reason='补漏注31，classical logic统一为经典逻辑。')
add(rr(187,2),rr(97,24,26),text='布劳威尔拒斥排中律（LEM），[[32]]即某事及其否定不可能同时为真（第29页及以下）。这意味着二者必有其一为真，不允许任何一方的地位不确定。同样，布劳威尔拒斥双重否定可以相互抵消，因为某事“并非不真”仍可能使其地位悬而未定。',reason='补漏注32，底本再次混述逻辑规律，照录并校注。')
rows[-1]['editor_note']='本段沿用上一处对排中律的误述，并由“不同时为真”转到“必有其一为真”。这两种表述不能等同；译文保留作者原有论述。'
add(rr(187,3),rr(97,27),text='布劳威尔进一步指出，排中律')
add(rr(187,4),rr(97,27,29),'quote',text='要求每个假设或者正确、或者不正确。用数学语言说，对于假定的系统之间以某种方式相互嵌合的每一种情形，要么能构造出其完成，要么能构造出因不可能而受阻的情形。因此，principium tertii exclusi［即排中律］是否有效的问题，等同于是否可能存在不可解数学问题的问题。（第42页）',reason='原文先作一般陈述再转数学，不把数学限定移到整句；保留拉丁术语。')
add(rr(187,5),rr(97,30,31)+rr(98,0),text='在有限情形中，他接受排中律，因为可以通过穷举来检验。只要无限情形能通过归纳构造出来，他也接受排中律在其中的应用。但是，布劳威尔反对从那些无法证明存在、却被假定存在的实体出发作论证。他尤其拒斥已完成的无限这一假定。',reason='completed infinities不用容易混淆完备性的“完备无限”。')
add(rr(187,6),rr(98,1,2),text='布劳威尔的“原初直觉”（ur-intuition）概念显然是唯心主义的；他在后来的著作中，例如1929年的《数学、科学与语言》[[33]]中，明确表现出了主观主义。')
add(rr(187,7),rr(98,3),'heading',text='从布尔什维克革命到孟什维克化的唯心主义')
add(rr(187,8),rr(98,4,6),text='20世纪头25年的灾难性事件夺去了数百万人的生命，又摧毁了数百万人的生活；要充分呈现这些事件而不显得轻描淡写，是不可能的。不过，从我们当前的视角看，1914年至1919年世界大战的关键结果，是苏联的建立。[[34]]这是第一个由明确奉行唯物主义的群众政党执政的国家。',reason='补漏注34，年份按底本保留。')
add(rr(187,9),rr(98,7,8),text='内战（1917—1923）之后，苏联把重心放在重建和立即改善人民生活上。一旦更广泛的国际革命已陷入停滞这一点变得明确，压倒一切的优先任务便是稳定和加强苏联。为了这一目标，也为了向共产主义未来迈进，科学被视为核心。')
nt={27:'D. Hilbert：“初等数论的奠基”，载W. Ewald编《从康德到希尔伯特：数学基础文献集》第2卷（Oxford University Press，1996），第1148—1157页。',28:'或者，也许是许多略有差别但联系紧密的语言。',29:'S. Kleene：《元数学导论》（North-Holland，1952）。',30:'L. Kronecker：“克罗内克1886年文献的脚注”，载W. Ewald编《从康德到希尔伯特：数学基础文献集》第2卷（Oxford University Press，1996），第947页。',31:'M. van Atten、G. Sundholm：“L. E. J. 布劳威尔《逻辑原则的不可靠性》：新译与导论”，History and Philosophy of Logic 38，第1期（2017），https://doi.org/10.1080/01445340.2016.1210986 。',32:'tertii exclusi［拉丁文，排除第三种情况］。',33:'L. Brouwer：“数学、科学与语言”，载P. Mancosu编《从布劳威尔到希尔伯特：20世纪20年代的数学基础之争》（Oxford University Press，1998），第45—53页。',34:'E. H. Carr：《苏俄史》（Macmillan，195078［底本年份如此］）。'}
notes=[]
for p in [265,266]:
    for n,refs in note_groups(rr(p,1)):
        if n not in nt:continue
        notes.append({'id':f'dm-ch08-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':[str(p-9)],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch08e',8,rows,notes,rr(186,1,11)+rr(187,1,9))
(W/'checkpoint_ch08e.json').write_text(json.dumps({'next_source_pdf_page':188,'next_source_block':1,'next_supplied_pdf_page':98,'next_supplied_block':9,'next_unit':len(rows)+74,'next_note':35,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
