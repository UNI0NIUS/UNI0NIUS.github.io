from materialism_common import *
groups=[]
for b in EN[282]['blocks'][1:]:
    for j,l in enumerate(b['lines']):
        if l['bbox'][0]<60:groups.append([])
        groups[-1].append([283,b['block'],j,j+1])
oldrefs=[rr(168,12,14),rr(168,15,16),rr(168,17),rr(168,18,19),rr(168,20,21),rr(168,22,23),rr(168,24,25),rr(168,26,27),rr(168,28),rr(169,0,1),rr(169,2,3),rr(169,4,5),rr(169,6,7),rr(169,8,9),rr(169,10),rr(169,11,13),rr(169,14),rr(169,15,16),rr(169,17,18),rr(169,19),rr(169,20,21)]
doi='https://doi.org/10.1521/siso.2019.83.1.37'
translations=[
'Benjamin Count Rumford：“关于摩擦所激发的热之来源的研究，作者为拉姆福德伯爵本杰明，F.R.S.M.R.I.A.”。Philosophical Transactions of the Royal Society of London（1798）：80—102。',
'伯特兰·罗素：“致弗雷格的信”。载《从弗雷格到哥德尔：数理逻辑文献集，1879—1931》，J. van Heijenoort编，124—125。Harvard University Press，1967。',
'伯特兰·罗素：“论指称”。Mind 14，第56期（1905）：479—493。',
'Lucio Russo：《被遗忘的革命：科学如何诞生于公元前300年，又为何不得不重生》。Springer Science & Business Media，2013。',
r'Ernest Rutherford：“物质对$\alpha$和$\beta$粒子的散射与原子结构”。Philosophical Magazine 92，第4期（2012）：379—398。',
'N. A. Sanin：“构造性实数与构造性数空间”。载Translations of Mathematical Monographs，E. Mendelson译，第21卷。American Mathematical Society，1968。',
'Sean Sayers：“马克思与目的论”。Science & Society 83，第1期（2019）：37—63。'+doi+'。电子版：'+doi+'。'+doi+'。',
'Moses Schönfinkel：“论数理逻辑的基本构件”。载《从弗雷格到哥德尔：数理逻辑文献集，1879—1931》，J. van Heijenoort编，357—366。Harvard University Press，1967。',
'Wilfrid Sellars：《科学、知觉与实在》。London：Routledge & Kegan Paul，1963，1—40。',
'Eugene Seneta：“20世纪30年代苏联的数学、宗教与马克思主义”。Historia Mathematica 31（2004）：337—367。',
'Anwar M. Shaikh：“劳动价值论的实证力量”。载《马克思主义经济学：重新评价》，R. Bellofiore编，第2卷，225—251。Macmillan，1998。',
'Claude Shannon：“通信的数学理论”。The Bell System Technical Journal 27（1948）：379—423及623—656。',
'Claude Shannon：“继电器与开关电路的符号分析”。American Institute of Electrical Engineers Transactions 57（1938）：713—723。',
'Claude Shannon：“信息的格论”。Transactions of the IRE Professional Group on Information Theory 1，第1期（1953）：105—107。',
'Helena Sheehan：《马克思主义与科学哲学：批判性读本》。Humanity Books，1985。',
'Guohua Shen、Kshitij Dwivedi、Kei Majima、Tomoyasu Horikawa、Yukiyasu Kamitani：“从人脑活动端到端地进行深度图像重建”。Frontiers in Computational Neuroscience 13（2019）：21。ISSN：1662-5188。https://doi.org/10.3389/fncom.2019.00021。https://www.frontiersin.org/article/10.3389/fncom.2019.00021。',
'Lilian Silburn：《昆达里尼：深处的能量》。SUNY Press，1988。',
'亚当·斯密：《法理学讲义》。格拉斯哥版《亚当·斯密著作与通信集》。1978。',
'Robin Smith：“亚里士多德的逻辑”。载Plato。Stanford Encyclopedia of Philosophy，2017。https://plato.stanford.edu/entries/aristotle-logic/#AriLogWorOrg。',
'约瑟夫·维萨里奥诺维奇·斯大林：《论辩证唯物主义和历史唯物主义》。Lawrence & Wishart，1943。',
'约瑟夫·维萨里奥诺维奇·斯大林：《马克思主义和语言学问题》。Foreign Languages Publishing House，1950。https://www.marxists.org/reference/archive/stalin/works/1950/jun/20.htm。'
]
assert len(groups)==len(oldrefs)==len(translations)==21
rows=[]
for i,(refs,zrefs,zh) in enumerate(zip(groups,oldrefs,translations),231):
    raw=extract(EN,refs,True);en=raw.replace('\u200b','').replace('α',r'$\alpha$').replace('β',r'$\beta$')
    for a,b in [('https:// doi','https://doi'),('doi.org /10','doi.org/10'),('2019 .00021','2019.00021'),('plato. stanford','plato.stanford'),('/\\#','/#'),('1950 /jun','1950/jun')]:en=en.replace(a,b)
    row={'id':f'dm-ref-{i:03}','kind':'bibliography','source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['274'],'en':en,'zh':zh,'supplied_zh':extract(ZH,zrefs),'status':'text_compared_layout_pending','revision_reason':'逐条核对书目信息并补译题名，补回旧稿省略的页码或网址。'}
    if en!=raw:row['source_transcription_note']='清理URL内排版空格和零宽字符、片段标识前的转义反斜线；希腊字母恢复数学字形。原始span保留。'
    if i==237:row['editor_note']='原书将同一DOI重复列出三次（其中一次标作eprint）；完整保留，不沿用旧稿的省略。'
    if i==239:row['revision_reason']='补回旧稿遗漏的1—40页码。'
    if i==246:row['revision_reason']='补回旧稿遗漏的Frontiers网址，两个链接均保留。'
    rows.append(row)
save('refs11',12,rows,[],rr(283,1,20))
(W/'checkpoint_refs11.json').write_text(json.dumps({'next_source_pdf_page':284,'next_source_block':1,'next_supplied_pdf_page':169,'next_supplied_block':22,'next_reference':252,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
