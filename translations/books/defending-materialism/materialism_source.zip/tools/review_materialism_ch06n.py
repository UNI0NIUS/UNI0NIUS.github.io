from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch06-{len(rows)+175:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
en=extract(EN,rr(158,5),True).replace('Bohm66,67','Bohm[[66]],[[67]]').replace('Everett.68,69','Everett.[[68]],[[69]]')
add(rr(158,5),rr(80,19),english=en,text='海森堡学派潜藏的主观主义引起了反对，最初的反对见相关研究，[[65]]后来则有玻姆[[66]]、[[67]]和埃弗雷特[[68]]、[[69]]提出的其他实在论解释。',reason='补全65—69，底本from后仅接注65，中文不臆填姓名。')
add(rr(158,6),rr(80,20))
add(rr(158,7),rr(80,21,22),end='在给定')
add(rr(158,8),rr(80,22,23),'quote',start='在给定',text='在给定统计规律的范围内，个体行为的无规律性，一般而言，与更广泛范围内起作用的更详细的个体规律并不矛盾。[[70]]',reason='旧译注66实应70；consistent with译相容，不是两种规律相同。')
add(rr(158,9),rr(80,24,28),end='量子关系式',fixes=[('德布罗意早期研究','德布罗意早期研究[[71]]')],reason='补漏注71。')
add(rr(158,10)+rr(159,1),rr(80,28,33),'quote',start='量子关系式',text=r'量子关系式“能量=h×频率”，使我们把一种周期现象与任何孤立的一份物质或能量联系起来。与这份物质绑定的观察者，会把它与一个由其内部能量、即“静止质量”确定的频率联系起来。对于一位观察者，若这份物质以速度$\beta c$匀速运动，他就会看到这个频率因洛伦兹—爱因斯坦时间变换而降低。我已经证明（巴黎科学院《报告》，9月10日及24日），只要假定波以速度$c/\beta$传播，静止观察者就会始终看到这种内部周期现象与一个波同相；该波的频率由运动物体全部能量所对应的量子关系确定。这种速度大于c的波不能携带能量。[[72]]',reason='合并72、恢复公式；steady motion为匀速运动。')
add(rr(159,2),rr(81,0,1))
add(rr(159,3),rr(81,2,3),'quote')
add(rr(159,4),rr(81,4,8),'quote',fixes=[('[[7]] [[3]]','[[73]]')])
add(rr(159,5),rr(81,9,13),fixes=[('[[7]] [[4]]','[[74]]'),('集合中粒子','系综中粒子')])
en=extract(EN,rr(159,6)+rr(160,1),True).replace('PWT76,77','PWT[[76]],[[77]]')
add(rr(159,6)+rr(160,1),rr(81,14,17),'quote',english=en,text='SQM中的客观概率[[75]]意味着，实验结果会呈现正确的频率。然而，反过来显然并不成立。测量结果的统计分布，并不意味着存在客观概率。例如，系统系综的初始状态具有适当的统计分布，再加上适当的演化规律，也能得到这些频率。我们无法确定地预测某个光子会在屏幕的什么位置落下，只是因为不知道单个系统的初始状态。PWT采用的就是这种方法。[[76]]、[[77]]',reason='旧译漏掉初始状态在系综中的分布，并把where误作何时；完整恢复75—77。')
add(rr(160,2),rr(81,18,22),fixes=[('多世界”现实主义','多世界”实在论')])
add(rr(160,3),rr(81,23,26))
nt={65:'Albert Einstein、Boris Podolsky与Nathan Rosen：“量子力学对物理实在的描述能否被认为是完备的？”（Can Quantum-mechanical Description of Physical Reality be Considered Complete?），Physical Review，第47卷第10期（1935），第777页。',66:'David Bohm：《现代物理学中的因果性与机遇》（Causality and Chance in Modern Physics）（Routledge，2004）。',67:'玻姆本人的论述见《现代物理学中的因果性与机遇》。详细的现代阐述还可参见Holland：《运动的量子理论：德布罗意—玻姆量子力学因果解释》（The Quantum Theory of Motion: An Account of the de Broglie-Bohm Causal Interpretation of Quantum Mechanics）；以及Bricmont：《理解量子力学》（Making Sense of Quantum Mechanics）和“量子力学史，或错误的喜剧”（History of Quantum Mechanics or the Comedy of Errors），arXiv预印本arXiv:1703.00294，2017。',68:'Hugh Everett：“量子力学的‘相对态’表述”（“Relative State” Formulation of Quantum Mechanics），The Many Worlds Interpretation of Quantum Mechanics，2015，第141—150页。',69:'随着量子计算的发展，埃弗雷特的解释日益流行。这个研究领域由支持埃弗雷特的Deutsch开创：“量子理论、丘奇—图灵原理与通用量子计算机”（Quantum Theory, the Church-Turing Principle and the Universal Quantum Computer），Proceedings of the Royal Society of London A，1985，第97—117页。他此后仍不断为这一解释辩护，参见D. Deutsch：《实在的结构》（The Fabric of Reality）（Penguin，2011）；David Deutsch：“实验检验的逻辑，特别是对埃弗雷特量子理论的检验”（The Logic of Experimental Tests, Particularly of Everettian Quantum Theory），Studies in History and Philosophy of Science Part B: Studies in History and Philosophy of Modern Physics，第55卷（2016），第24—33页。',70:'David Bohm：《整体性与隐缠序》（Wholeness and the Implicate Order）（Routledge，2002），第87页。',71:'Louis De Broglie：“波与量子”（Waves and Quanta），Nature，第112卷第2815期（1923），第540页。',72:'De Broglie：“波与量子”（Waves and Quanta）。',73:'De Broglie：“波与量子”（Waves and Quanta）。',74:'Antony Valentini：“信号局域性、不确定性与亚量子H定理。I”（Signal-locality, Uncertainty, and the Subquantum H-theorem. I），Physics Letters A，第156卷第1—2期（1991），第5—11页。',75:'标准量子力学（Standard Quantum Mechanics），即海森堡的观点。',76:'导引波理论（Pilot Wave Theory），即玻姆的观点。',77:'Philipp Roser：“德布罗意—玻姆导引波图景中的量子计算”（Quantum Computing in the de Broglie-Bohm Pilot-wave Picture），arXiv预印本arXiv:1012.4843，2010。'}
notes=[]
for n,refs in note_groups(rr(262,3))+note_groups(rr(263,1)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch06-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':[str(refs[0][0]-9)],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch06n',6,rows,notes,rr(158,5,10)+rr(159,1,6)+rr(160,1,3))
(W/'checkpoint_ch06n.json').write_text(json.dumps({'next_source_pdf_page':162,'next_source_block':0,'next_supplied_pdf_page':81,'next_supplied_block':27,'next_chapter':7,'next_note':1,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
