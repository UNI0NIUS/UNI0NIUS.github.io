from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch11-{len(rows)+50:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(227,1),rr(120,5),text='Caesar forte regebatur。凯撒受命运支配。那么，命运与规则有何不同？')
add(rr(227,2),rr(120,6,7),text='我们怎样通过观察，辨别某件事只是随机发生，还是遵循某种对我们而言可能并不明显的模式？')
add(rr(227,3),rr(120,8,9),text='以骰子为喻。给定一系列掷骰结果，我们如何判断骰子是公平的，还是存在某种可以据以稳妥下注的偏向？')
add(rr(227,4),rr(120,10),text='假定有一枚标着0至9的十面骰子，它给出如下序列：',reason='源书0.9依十面骰语境译作0至9；保留英文原样。')
add(rr(227,5),rr(120,11,12),'quote',text=extract(EN,rr(227,5),True),reason='数字序列逐项保留，包括原文末尾逗号。')
add(rr(227,6),rr(120,13),text='我们如何知道它是不是随机的？')
add(rr(227,7),rr(120,14),text='我们可以查看每个数字出现多少次。')
add(rr(227,8),rr(120,15,25),'table',text='数字出现次数',reason='依源PDF恢复两列表格，保留英文表头原拼写Occurences。')
rows[-1]['table']={'headers_en':['Digit','Occurences'],'headers_zh':['数字','出现次数'],'rows_en':[[str(i),str(n)] for i,n in enumerate([3,4,7,8,7,7,4,5,6,11])],'rows_zh':[[str(i),str(n)] for i,n in enumerate([3,4,7,8,7,7,4,5,6,11])]}
add(rr(227,9),rr(120,26,27),text='到这里，我们的骰子看起来似乎不容易掷出0，而容易掷出9。似乎只要押注不会出现0，长期来看就能赢。让我们试着生成更多数字，看这一点是否成立。')
add(rr(227,10),rr(120,28,29),text='图11.1表明，随着产生的数字越来越多，数列中0所占的百分比趋近10%，这正是我们对无偏骰子的预期。')
add(rr(227,11),rr(121,0,2),text='如果要更严格地检验随机性，我们可以考察成对的数字。也许0的出现频率是10%，但它仍可能在6之后比在7之后更容易出现。如果在足够大的样本中，我们发现每个数字的出现都不受前一个数字影响，就可以进一步考察三个数字、四个数字组成的组，以此类推。')
add(rr(227,12),rr(121,3,5),text='随着所考察的数字组长度增加，样本所需的数字数量会呈指数增长。如果需要44,000个数字才能使0所占的比例收敛到10%，那么可以预期，需要考察超过400,000个数字，这些0之前的数字为6的比例才会收敛到10%。对于三个数字的组合，就需要检查400万个数字，以此类推。')
add(rr(227,13),rr(121,6),text='我们试图探测的模式越长，证明随机性就越困难。可能存在的模式越微妙，就越不可能通过穷尽搜索将其找出。')
save('ch11e',11,rows,[],rr(227,1,13))
(W/'checkpoint_ch11e.json').write_text(json.dumps({'next_source_pdf_page':228,'next_source_block':1,'next_supplied_pdf_page':121,'next_supplied_block':7,'next_unit':len(rows)+50,'next_note':13,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
