from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch06-{len(rows)+78:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(143,9),rr(72,24),'heading')
add(rr(143,10)+rr(144,1),rr(72,25,27))
add(rr(144,2),rr(72,28),end='科学知识传播',text='与牛顿和莱布尼茨一样，[[29]]马赫强调科学思想中简洁性的优点。',reason='补漏注29，恢复独立引文前导句。')
add(rr(144,3),rr(72,28,32),'quote',start='科学知识传播')
add(rr(144,4),[],'quote',text='……',reason='恢复原引文省略号。')
add(rr(144,5),rr(72,33,34)+rr(73,0,2),'quote')
add(rr(144,6),rr(73,3,4),end='当我们',text='问题在于，这一节约原则与一种实质上属于个人主义或心理主义的观念纠缠在一起：信息的节约究竟发生于何处？这里把个体感知与科学这一社会活动混为一谈。',reason='information economy在此是信息/思想的节约，而非经济产业；恢复论述对象。')
add(rr(144,7)+rr(145,1),rr(73,4,12),'quote',start='当我们',text='当我们在思想中把一个物体从它运动于其中的可变环境中分离出来时，实际上是在我们的全部感觉之流中，抽出一组思想所关注的、比其他感觉相对更稳定的感觉。这组感觉并非绝对不变。它的成员时而出现，时而消失，或发生改变。它从不以完全相同的样态重现。然而，其恒定要素的总量与可变要素的总量相比，总是占如此大的比重，尤其是考虑到转变的连续性时更是如此，以至于就当前目的而言，前者通常似乎足以确定物体的同一性。但是，由于我们可以从这组感觉中分离出任何一个成员，而物体对我们来说仍不失为同一个，我们便容易相信：把所有成员都抽离之后，还会剩下某种额外的东西。于是，我们形成了一种有别于其属性的实体观念，即物自体观念，而把我们的感觉仅仅视为这个物自体的属性的符号或标志。然而，更妥当的说法应当是：物体或事物是感觉群的简明心理符号——这些符号并不存在于思想之外。[[31]]',reason='body在此指物体而非身体；统一感觉群和物自体，保留引文完整层次。')
add(rr(145,2),rr(73,13,15))
add(rr(145,3),rr(73,16),text='为什么说事物只是感觉群的心理符号、而这些符号并不存在于思想之外，会是更好的说法呢？',reason='旧译感官符号群混淆groups of sensations与symbols，按前引命题恢复。')
add(rr(145,4),rr(73,17),end='通过交流')
add(rr(145,5),rr(73,17,25),'quote',start='通过交流')
add(rr(145,6),rr(73,26,29),text='上述论述很好地认识到了信息的节约以及科学的集体性质。但在其他地方，我们看到的却是个人主义和心理学式的解释。马赫十分愿意承认科学通过集体努力而进步，那么过去就必定有真实的人提出了运动定律。确实存在一个真实的牛顿，马赫使用的正是他的运动定律。如果马赫能够接受其他科学家的实在性，为何又否认牛顿所解释其运动的那些行星天体的实在性？',reason='原文质疑的是行星天体实在性，旧译误写行星运动现实性；economy统一节约。')
add(rr(146,1),rr(73,30),end='当几何学家')
add(rr(146,2),rr(73,30,37),'quote',start='当几何学家',text='当几何学家想理解一条曲线的形状时，会先把它分解成微小的直线元素。但他完全清楚，这些元素只是暂时而任意的手段，用于分部分地理解他无法作为整体把握的对象。一旦找到曲线的规律，他就不再考虑这些元素。同样，物理科学若把自己创造的、可变而节约的工具——分子和原子——当作现象背后的实在，忘却其年长的姊妹哲学最近获得的智慧，以机械神话取代旧的泛灵论或形而上学图式，从而制造无穷无尽的假想问题，那就有失其本分。原子必须始终像数学函数一样，作为表征现象的工具。然而，随着智力在与研究对象接触中逐渐受到训练，物理科学将放弃以石子拼成马赛克的游戏，转而探寻现象的生命之流所流经的河床的边界和形态。它所追求的目标，是对事实最简单、最节约的抽象表达。',reason='原文此引文末无33注，去掉旧译误加的33；恢复older sister与economical含义。')
nr={29:[[260,17,13,14]],30:[[260,17,14,16]],31:[[260,17,16,17]],32:[[260,17,17,18]]}
nt={29:'见第[3.3.1]节。',30:'Ernst Mach：“通俗科学讲演”（Popular Scientific Lectures），“物理研究的节约性质”（The economical nature of physical inquiry）章（Open Court，1898）。',31:'Mach：“通俗科学讲演”（Popular Scientific Lectures）。',32:'Mach：“通俗科学讲演”（Popular Scientific Lectures）。'}
notes=[]
for n,refs in nr.items():notes.append({'id':f'dm-ch06-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['251'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch06f',6,rows,notes,rr(143,9,10)+rr(144,1,7)+rr(145,1,6)+rr(146,1,2))
(W/'checkpoint_ch06f.json').write_text(json.dumps({'next_source_pdf_page':146,'next_source_block':3,'next_supplied_pdf_page':73,'next_supplied_block':38,'next_unit':len(rows)+78,'next_note':33,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
