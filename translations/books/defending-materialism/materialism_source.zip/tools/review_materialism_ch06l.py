from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch06-{len(rows)+153:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(155,17),[],'figure',text='图6.7 左图表示垂直偏振光的振幅如何投影到一个相对原偏振轴旋转45°的偏振器的左、右两轴。表示初始振幅的垂直向量V，在新的参考系中投影为两个等长的分量向量A、B。右图为水平偏振光的相应情形。作者绘图。',reason='恢复原图与图注。')
rows[-1].update(image='assets/figure-6-7.png',source_image={'pdf_page':155,'block':16,'xref':959},image_labels_zh='左图标题：入射垂直偏振光在左右偏振轴上的投影；右图标题：入射水平偏振光在左右偏振轴上的投影。V/H：垂直/水平；L/R：左/右；A、B、C、D：图示分量。')
add(rr(155,4),rr(78,28,30),text=r'因此，图中标记为V的点，在水平—垂直坐标系中表示为$V=[0,1]_{HV}$，在左—右坐标系中的坐标为$[A,B]_{LR}$。同样，$H=[1,0]_{HV}=[D,C]_{LR}$。利用勾股定理，可以容易地求出A、B、C、D：',english=r'So, the point labelled V in the diagram has coordinates $V=[0,1]_{HV}$ in Horizontal Vertical system and coordinates $[A,B]_{LR}$ in the Left, Right system. Similarly, $H=[1,0]_{HV}=[D,C]_{LR}$. By Pythagoras theorem you can readily solve for A, B, C, D as',reason='恢复旧译遗漏的A/B/C/D坐标，去除重复和提前替换为结果的译文。')
f=r'V=[0,1]_{HV}=\left[\frac{1}{\sqrt{2}},\frac{1}{\sqrt{2}}\right]_{LR}'
add(rr(155,5,9),rr(78,31),text='$'+f+'$',english='$'+f+'$');rows[-1]['math_lines']=[f]
add(rr(155,10),rr(79,0))
f=r'H=[1,0]_{HV}=\left[\frac{-1}{\sqrt{2}},\frac{1}{\sqrt{2}}\right]_{LR}'
add(rr(155,11,15),rr(79,1),text='$'+f+'$',english='$'+f+'$');rows[-1]['math_lines']=[f]
add(rr(156,1),rr(79,2,3))
first=rr(156,2,4)+[[156,5,0,3]]
add(first,rr(79,4,7),'list_item',text=r'1. 把这些参考系看作实际的物理偏振器，它们能把初始光束分成电场相互垂直的两束分量光。光通过第一个分束器后，垂直偏振光束V以45°进入第二个分束器，分为L、R两束。若V的振幅为v，则L、R两束的振幅均为$v/\sqrt{2}$。光束亮度正比于电场振幅的平方，因此L、R两束的亮度各为V的一半。这些结论都来自前述基本几何论证。',english=r'1. Consider the frames of reference to be actual physical polariers capable of splitting an initial beam into two component beams whose electric fields are at right angles to one another. The light passes through a first beam splitter and the vertically polarized beam (V) enters a second one at 45° which splits it into L and R component beams. If the amplitude of the beam V is v then the amplitude of the L and R beams will be $v/\sqrt{2}$. Because the brightness of a beam is proportional to the square of the field amplitude, then L and R beams will be half as bright as the V beam. All of this follows from the basic geometric arguments given earlier.')
add([[156,5,3,4]]+rr(156,6),rr(79,8,9),'list_item')
add(rr(156,7),rr(79,10,13),text=r'描述量子比特和其他量子态时，物理学家用一种专门记号——狄拉克记号——表达前述几何关系。不熟悉它的人可能觉得有些奇怪，但基本原理很简单。在初始参考系中，我们用标准笛卡尔记号把垂直轴向量写成$[0,1]_{HV}$；他们则写成$0|H\rangle+1|V\rangle$。这依然只是把参考系中的坐标明确写出来的一种方式。$|\rangle$这种括号形式称为ket，即右矢。',english=r'In describing qubits and other quantum states, the physicists use a specialized notation, the Dirac notation, for the geometry that we described earlier. This can look a bit strange if you are unfamiliar with it, but the basic principle is simple. Where we used standard Cartesian notation for the initial frame of reference, writing the vertical axis vector as $[0,1]_{HV}$ they would write it as $0|H\rangle+1|V\rangle$, but this is still just an explicit way of writing down coordinates in a frame of reference. The bracketing construct $|\rangle$ is referred to as a ket.',reason='恢复狄拉克括号及态系数；ket译右矢。')
add(rr(156,8),rr(79,14,16),text=r'按量子力学的标准解释，一个量子比特以两个正交纯态之一发送，即$1|V\rangle+0|H\rangle$或$0|V\rangle+1|H\rangle$。记号$|H\rangle$表示一个带标签的态，这里的H代表水平偏振。如果旋转45°，并把这些纯态投影到由新偏振器形成的基矢态[[59]]上，把这些基矢态标为L、R，就得到：',english=r'In the standard account of QM what is happening when a qubit is sent in one of two orthogonal pure states $1|V\rangle+0|H\rangle$ or $0|V\rangle+1|H\rangle$. The notation $|H\rangle$ indicates a labelled state, H standing for horizontal polarization in this case. If we perform a 45° rotation and project these pure states onto the basis states[[59]] formed by the new polarizer which we will label L, R we get',reason='旧译错误断言两种纯态均为H；恢复标签说明和漏注59。')
f=r'0|H\rangle+1|V\rangle\rightarrow\frac{1}{\sqrt{2}}|L\rangle+\frac{1}{\sqrt{2}}|R\rangle'
add(rr(156,9),rr(79,17),text='$'+f+'$',english='$'+f+'$');rows[-1]['math_lines']=[f]
add(rr(156,10),rr(79,18))
add(rr(156,11),rr(79,19,21))
notes=[]
for n,refs in note_groups(rr(262,1)):
    if n!=59:continue
    notes.append({'id':'dm-ch06-note-59','kind':'note','note_number':59,'source_blocks':refs,'printed_pages':['253'],'en':extract(EN,refs,True),'zh':'59. 物理学使用“基矢态”（basis states）一词，指普通人所说的坐标系的轴。','status':'text_compared_layout_pending'})
import sys
sys.path.insert(0,str(R/'tools/python_libs'))
import fitz
d=fitz.open(json.loads((W/'source_manifest.json').read_text('utf8'))['path']);fitz.Pixmap(d,959).save(str(R/'Defending Materialism/output/assets/figure-6-7.png'))
save('ch06l',6,rows,notes,rr(155,4,15)+rr(155,17)+rr(156,1,11))
(W/'checkpoint_ch06l.json').write_text(json.dumps({'next_source_pdf_page':157,'next_source_block':1,'next_supplied_pdf_page':79,'next_supplied_block':22,'next_unit':len(rows)+153,'next_note':60,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
