from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch09-{len(rows)+133:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(208,10),rr(109,34),'heading',text='斯大林论语言学')
add(rr(208,11),rr(110,0,1),text='1950年，斯大林对马尔的批驳，预示着反形式主义立场公开逆转。正如洛伦兹[[52]]所述，斯大林密切关注精密科学的发展，虽支持李森科，却怀疑科学普遍具有阶级性：[[53]]',reason='修复注52、53，保留公开逆转语义。')
add(rr(208,12),rr(110,1,2),'quote',text='哈哈哈。那数学呢？达尔文主义呢？（第217页）')
add(rr(208,13)+rr(209,1),rr(110,3,5),text='《马克思主义和语言学问题》[[54]]于1950年发表在《真理报》，随后又有四次进一步澄清的交流。在最初的文章中，斯大林彻底拒斥马尔语言学的两项核心主张，认为语言既不是基础，也不是上层建筑，并且不具有阶级标记。这些批评也适用于沃洛希诺夫。',reason='合并跨页段，exchanges不强化为论战；修复注54。')
add(rr(209,2),rr(110,6,8),text='在后来答复克拉舍宁尼科娃时，斯大林承认语义学对语言学的重要性，同时批评马尔过分强调语义学。从上下文看，斯大林似乎再次批评马尔按说话者的阶级，赋予词语和表达不同的意义。他认为，这种差异很少，存在于个别词语中，而不在所有说话者共有的语法中。')
add(rr(209,3),rr(110,9),text='最重要的是，斯大林表明，以形式主义之名作为决定性批评的做法已经结束：')
add(rr(209,4),rr(110,9,10),'quote',text='N. Y. 马尔认为，语法是空洞的“形式”，把语法体系视为语言基础的人是形式主义者。这完全是愚蠢的。')
add(rr(209,5),rr(110,11),'quote',text='我认为，“形式主义”是“新学说”的作者们发明的，目的是便利他们与语言学对手的斗争。')
add(rr(209,6),rr(110,12,13),text='此后，苏联逻辑学蓬勃发展，尽管辩证法与逻辑关系的争论仍在继续。[[55]]十七年后，即1967年，科普宁[[56]]仍在援引恩格斯[[57]]来捍卫黑格尔的真理。',reason='修复注55—57。')
add(rr(209,7),rr(110,14,15),text='不过，1959年一份访苏美国计算机科学家的报告[[58]]表明，苏联逻辑与计算领域的进展给他们留下了深刻印象。他们指出：')
add(rr(209,8),rr(110,15,16),'quote',text='莫斯科、基辅和列宁格勒大学里，直接或间接与计算机有关的逻辑学家和数学家，显然比西欧或美国任何大学的都更多、更优秀。（第17页）')
add(rr(209,9),rr(110,17,18),text='他们还指出，除MIT以外，美国没有能够与莫斯科国立大学相比的“面向计算机”的逻辑教学项目（第17页），并警告说，苏联培养的')
add(rr(209,10),rr(110,18,19),'quote',text='合格的、面向计算机的数学家，而不只是计算机程序员，其人数可能很快超过美国。（第17页）')
add(rr(209,11),rr(110,20),'heading',text='构造主义')
add(rr(209,12),rr(110,21,22),text='苏联构造逻辑学派由小安德烈·马尔可夫[[59]]（1903—1979）创立。[[60]],[[61]]构造主义根植于直觉主义，却像柯尔莫哥洛夫的进路一样，具有唯物主义取向。',reason='补Jr.父子区别，统一马尔可夫、构造主义；修复59—61。')
add(rr(209,13)+rr(210,1),rr(110,23,26),text='直觉主义以唯心主义为基础，因此苏联逻辑学家接受它，似乎令人意外。不过，马尔可夫的合作者纳戈尔尼认为，在“解冻”之前，集合论尽管具有柏拉图主义根源，却被视为唯物主义而非唯心主义。[[62]]此外，范杜拉基斯[[63]]指出，一旦将布劳威尔直觉主义的逻辑框架与其哲学分开，前者就被认为与辩证唯物主义相容。正如沙宁在1962年所写：[[64]]',reason='合并跨页句，统一沙宁，修复62—64；英文Ngorny照录。')
add(rr(210,2),rr(110,26,27),'quote',text='越过直觉主义哲学的表层，人们在许多情况下能够发现：对于数学抽象形成过程和数学逻辑基础所涉及的根本问题，存在非常有价值的具体观察和深刻的具体分析。（第7页）')
add(rr(210,3),rr(110,28,30),text='马尔可夫的学生库什纳指出其构造主义的四个核心特征。[[65]]首先，研究对象是有限的，由有限的构造过程，从有限字母表出发，依照明确的算法形成规则生成。沙宁正确地把这一点视为构造主义取得成功的关键：')
add(rr(210,4),rr(110,30,31),'quote',text='以精确的算术算法概念丰富数学，为许多作者沿新方向开展富有成果的研究提供了起点。（第6页）')
add(rr(210,5),rr(110,32,34),text='其次，库什纳指出，构造主义与直觉主义一样，拒斥排中律和双重否定，存在性证明必须以构造为基础。第三，它接受潜无限而不接受实无限。最后，可计算性与算法相联系；它接受经经验验证的丘奇—图灵论题，即所有可计算性模型的等价性。')
add(rr(210,6),rr(110,35,36),text='与图灵一样，马尔可夫从作为纸笔物质过程的数学出发。例如，他考虑在构成书稿的纸上画出一排竖线。在讨论这些线条随后如何经印刷复制时，他指出：',reason='不是用笔画形成整本书稿，而是在书稿的纸上作图。')
add(rr(210,7),rr(110,36)+rr(111,0,1),'quote',text='这个构造对象［即原始图画］是由纸张和干墨水组成的物体，上面的图画则是这一构造对象的副本，由纸张和干的印刷油墨组成。它也是构造对象，因为制作副本可以被视为一种构造活动。[[66]]')
add(rr(210,8),rr(111,2),text='马尔可夫明确承认物质现实的限制：')
nt={52:'Lorentz：“1928至1953年苏联的数学与政治”，第217页。',53:'引自V. J. Birstein《知识的歪曲：苏联科学的真实故事》（Westview，2001），第249—251页。',54:'J. V. Stalin：《马克思主义和语言学问题》（莫斯科：Foreign Languages Publishing House，1950），https://www.marxists.org/reference/archive/stalin/works/1950/jun/20.htm 。',55:'Mathias：“逻辑与恐怖”。',56:'P. V. Kopnine：“辩证法与逻辑”，Diogenes 15，第60期（1967）：87—102。',57:'以及列宁。',58:'J. W. Carr III等：“访问苏联计算中心”，Communications of the ACM 2，第6期（1959）：8—20。',59:'A. A. Markov Jr：《算法理论》，第42卷（Trudy Mat. Institua im. Steklova，1954）。',60:'他是安德烈·马尔可夫（1856—1922）之子，后者以随机过程领域的奠基工作闻名。',61:'Markov：《算法理论》。',62:'N. M. Nagorny：“安德烈·马尔可夫与数学构造主义”，Logic, Methodology and Philosophy of Science IX（1994）：469。',63:'I. M. Vandoulakis：“论A. A. 马尔可夫对布劳威尔直觉主义的态度”，Philosophia Scientiæ 2015/1，第19-1期（2015）：第46段。',64:'N. A. Sanin：“构造实数与构造数空间”，载Translations of Mathematical Monographs，E. Mendelson英译，第21卷（American Mathematical Society，1968）。',65:'B. A. Kushner：“马尔可夫的构造分析：一位参与者的看法”，Theoretical Computer Science 219（1999）：268—269。',66:'A. A. Markov Jr、N. M. Nagorny：《算法理论》，M. Greendlinger英译（Kluwer Academic，1988），第1页。'}
notes=[]
for n,refs in note_groups(rr(269,1)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch09-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['260'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch09i',9,rows,notes,rr(208,10,13)+rr(209,1,13)+rr(210,1,8))
(W/'checkpoint_ch09i.json').write_text(json.dumps({'next_source_pdf_page':210,'next_source_block':9,'next_supplied_pdf_page':111,'next_supplied_block':2,'next_unit':len(rows)+133,'next_note':67,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
