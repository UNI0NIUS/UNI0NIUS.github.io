from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch11-{len(rows)+170:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(239,1),rr(128,21),text='毛泽东把科学方法与受德博林影响的教条主义者的方法相对照：')
add(rr(239,2),rr(128,21,24),'quote',text='我们的教条主义者是一群懒汉。他们拒绝对具体事物作任何艰苦的研究，把一般真理看作凭空产生的东西，把它们变成纯粹抽象、难以捉摸的公式，从而完全否定并颠倒人类认识真理的正常顺序。他们也不懂认识的两个过程——从特殊到一般，再从一般到特殊——之间的相互联系。他们根本不懂马克思主义的认识论。')
rows[-1]['zh']+='[[37]]'
add(rr(239,3),rr(128,25,30),text='要把更深刻的理解建立在对真实历史条件的具体分析之上，这在本书作者看来很有道理。以马克思的利润率下降规律为例。根据我们的经验，只有对英国从19世纪50年代到20世纪末的积累过程进行具体的统计分析，[[38]]才能深化对其机制的理解，并精确地用数学表述其动态行为。[[39]]如果我们只根据《资本论》的论述作推演，而没有实际历史统计数据的指引，就不大可能得出正确的动力学方程。没有那个方程、那条运动规律，就无法理解20世纪最后十年西方盈利能力部分恢复的有限性与矛盾性，也无法理解2000年以来中国与非洲资本回报率的不同趋势。',reason='unlikely不能译成绝不可能；contrasting不必强化为截然相反。')
add(rr(239,4),rr(128,31),text='毛泽东写道：')
add(rr(239,5),rr(128,31,34),'quote',text='任何重大事物的发展过程中，都有许多矛盾。例如，在条件极其复杂的中国资产阶级民主革命过程中，存在着中国社会一切被压迫阶级与帝国主义之间的矛盾，广大人民群众与封建主义之间的矛盾，无产阶级与资产阶级之间的矛盾，农民和城市小资产阶级与资产阶级之间的矛盾，各反动统治集团之间的矛盾，等等。[[40]]',reason='修复旧译将注40拆为4和0，恢复引文边界。')
add(rr(239,6),rr(129,0,1),text='这些矛盾具有鲜明的中国特殊性。但同样的多重矛盾话语，也提供了考察西方资本主义危机的一种方式；在这里，需要考虑：')
add(rr(239,7),rr(129,2),'list_item',text='劳动与资本之间的“矛盾”（阶级冲突），它体现为剩余价值率。')
add(rr(239,8),rr(129,3,4),'list_item',text='生产性劳动与非生产性劳动之间的“矛盾”。用于支付非生产性劳动工资的剩余价值份额越高，能够作为新增生产资料积累的剩余价值流量就越少。',reason='flow surplus value按流量理解，不误译为流动剩余价值。')
add(rr(240,1),rr(129,5),'list_item',text='资本与土地所有权之间的“矛盾”，它体现为剩余价值中用作地租的份额上升。')
add(rr(240,2),rr(129,6),'list_item',text='积累本身的矛盾效应：它通过提高资本与劳动之比，趋向于压低利润率。')
nt={37:'毛泽东，《矛盾论》，第321页。',38:'Paul Cockshott、Allin Cottrell、Greg Michaelson：“检验马克思：英国数据的一些新结果”，Capital & Class 19，第1期（1995）：103—130。',39:'Cockshott等，《经典经济物理学：古典政治经济学、热力学与信息论论集》；Allin Cottrell、Paul Cockshott：“人口与利润率下降”，Indian Development Review 4，第1期（2006）：39—59。',40:'毛泽东，《矛盾论》，第322页。'}
notes=[]
for n,refs in note_groups(rr(272,3)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch11-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['263'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch11o',11,rows,notes,rr(239,1,8)+rr(240,1,2))
(W/'checkpoint_ch11o.json').write_text(json.dumps({'next_source_pdf_page':240,'next_source_block':3,'next_supplied_pdf_page':129,'next_supplied_block':7,'next_unit':len(rows)+170,'next_note':41,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
