from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch11-{len(rows)+180:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(240,3),rr(129,7,8),text=r'毛泽东关于社会发展过程中多重矛盾的话语，为思考这些过程提供了框架。或许可以用数学方式表述这些过程，使“矛盾”成为数学项：$s^{\prime}=\frac{s}{v}$，$p=s-u-r$（利润＝剩余价值－非生产性劳动工资－地租）。',english=r'Mao’s language of multiple contradictions in the process of the development of a society provides a framework for thinking through these processes. One can perhaps formulate these in mathematical terms so that the ‘contradictions’ become mathematical terms $s^{\prime}=\frac{s}{v}$, $p=s-u-r$ (profit = surplus value - unproductive wages - rent).')
add(rr(240,4),rr(129,9),text='在其他情况下，可以用较为熟悉的动力学和微积分语言表达矛盾关系。考虑积累与利润率之间的矛盾关系。')
add(rr(240,5,6),rr(129,10),text=r'利润率，用$\pi$表示，由$\pi=\frac{p}{K}$给出，其中$p$的定义同前，$K$是资本存量。',english=r'The rate of profit, let us use $\pi$, is given by $\pi=\frac{p}{K}$ where $p$ as defined earlier, and $K$ is capital stock.')
add(rr(240,7,24),rr(129,11,16),text=r'资本存量相对于时间的变化率写作$\left(\frac{dK}{dt}\right)$，而它又由$\frac{dK}{dt}=\frac{A}{K}$给出，其中$A$为年度积累。将利润中用于净积累的份额记作$\alpha=\frac{A}{p}$。现在考察利润率相对于时间的变化率$\pi^{\prime}=\frac{d\pi}{dt}$，也就是说，利润率随时间趋于上升还是下降。由前面的方程显然可见，$\frac{d\pi^{\prime}}{d\alpha}<0$，即利润变化率对积累率的偏导数为负。高积累率导致利润率下降。这是一种负反馈或矛盾关系，在数学中用牛顿与莱布尼茨的微积分描述，在其他领域则用不同术语描述。注意，只要稍作深入分析，就会发现上面最初列表中的所有矛盾都涉及负的（小于0的）偏导数。剩余价值对工资的导数为负，利润对地租的导数为负，等等。',english=r'The rate of change of the capital stock with respect to time would be written $\left(\frac{dK}{dt}\right)$ and this in turn is given by $\frac{dK}{dt}=\frac{A}{K}$ where $A$ is annual accumulation. If we denote the share of profits going as net accumulation as $\alpha=\frac{A}{p}$. Now consider the rate of change of the rate of profit with respect to time $\pi^{\prime}=\frac{d\pi}{dt}$ that is to say whether the rate of profit tends to rise or fall over time. It is clear from the previous equations that $\frac{d\pi^{\prime}}{d\alpha}<0$ that is to say the partial derivative of the rate of change of profit with respect to the rate of accumulation is negative. A high rate of accumulation leads to a decrease in the rate of profit. This is a negative feedback or contradictory relationship, described using the calculus of Newton and Leibniz in mathematics or different terminologies in other fields. Note that all of the contradictions in the initial list above, when analysed slightly more closely, involve negative (<0) partial derivatives. The derivative of surplus value with respect to wages is negative. The derivative of profit with respect to rent is negative, etc.',reason='依原图恢复分式与希腊字母；原书dK/dt=A/K保留，不采用旧译擅改的dK/dt=A。')
rows[-1]['editor_note']='原书此处写作dK/dt=A/K。按文中K为资本存量、A为年度积累量的定义，A/K对应相对增长率，而dK/dt对应存量的变化率；此处可能存在记号或排印问题，本稿不作无声更正。原书以d表示导数而在文字中称其为偏导数，亦照录。'
add(rr(240,25),rr(129,17),text='事实上，如果用数字电路使逻辑机械化，逻辑否定与负偏导数之间的这种关系就会显现。')
add(rr(240,26),rr(129,18,23),text='在计算机设计中，用导线分别表示逻辑信号本身及其反相信号，是完全标准的做法。如果像恩格斯和列宁谈论唯物辩证法时那样作肤浅的类比，那么同时包含A与非A信号的电路，可以说包含了“矛盾”或“对立面的同一性”；而这些矛盾项确实通过负偏导数联系在一起。在图11.2中，非A信号的电压对A信号电压的偏导数为负。在物理系统中，负偏导数用来表示否定。逻辑是用来描述这些系统的一种抽象，无论系统是电路，还是使用记事本的人。因此，对于任何受负导数支配的物质过程，我们都可以隐喻地使用“否定”这一术语。',reason='true与complement指信号及反相形式，不是同一根导线同时传送真和假；identity统一译同一性。')
save('ch11p',11,rows,[],rr(240,3,26))
(W/'checkpoint_ch11p.json').write_text(json.dumps({'next_source_pdf_page':241,'next_source_block':1,'next_supplied_pdf_page':129,'next_supplied_block':24,'next_unit':len(rows)+180,'next_note':41,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
