from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch05-{len(rows)+245:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(113,10)+rr(114,1),rr(57,15,21),fixes=[('观察到进化、优化','观察到改进、提升'),('尽管存在进化','尽管存在改进')],reason='improvement不等同于evolution；本段正区分适应性改进和谱系层级。')
add(rr(114,2),rr(57,22,23))
add(rr(114,3),rr(57,24,26),text='回顾一下，斯密的序列是从狩猎社会到牧业社会，再到农业文明。恩格斯的序列是：蒙昧、野蛮、奴隶社会、封建主义、资本主义和共产主义。他对前两个术语的使用与摩根相同。[[90]]蒙昧大致对应于狩猎社会。野蛮则对应于从事园圃种植或畜牧、但尚未实行犁耕农业的经济形态。',reason='旧译再次颠倒savagery与barbarism，按全章术语恢复蒙昧/野蛮；补原注90。')
add(rr(114,4),rr(57,27,33),text='恩格斯的框架把社会发展同时看作谱系上的承续和进步。资本主义被视为比封建主义更先进，野蛮状态则比蒙昧状态更先进。现代人的敏感意识往往排斥“野蛮人”或“蒙昧人”等词，因为其中带有欧洲中心主义或中国中心主义的偏见，甚至可能接近种族主义。然而，从马克思主义视角来看，从事园圃种植和畜牧的野蛮社会，相较于仅依赖狩猎的社会，其进步性不可否认。同样，资本主义也被视为比封建主义更先进。这基于古尔德指出的同一标准：竞争能力。历史上，处于野蛮阶段的民族与处于蒙昧阶段的民族接触时，常常取代后者，占据其原有领土的大片区域。来自西非和安纳托利亚、拥有家畜和农业的人群迫使更早的狩猎采集社会退却，就体现了这一点。',reason='修复“将会发展”错字、蒙昧/野蛮术语混乱与modern sensitivity主体错译。')
add(rr(114,5),rr(58,0,1),fixes=[('“蛮族”','处于野蛮阶段的民族')])
add(rr(114,6),rr(58,2,4),fixes=[('“野蛮动物”','“无理性的动物”'),('那些看似具有人类特有特征，','那些看似为人类独有的特征，')],reason='brute在此与rational相对，不是社会阶段意义的野蛮。')
add(rr(114,7),rr(58,5,7),end='人们常说',fixes=[('使用投掷武器，','使用投掷武器，[[91]]'),('那些被认为独有人类特征','那些被认为是人类独有的特征')],reason='恢复漏注91和旧译语序。')
add(rr(114,8)+rr(115,1),rr(58,7,18),'quote',start='人们常说',fixes=[('第51—56 节','第51—56页'),('作为杠杆使用。布雷姆','作为杠杆使用。……布雷姆')],reason='原书引用中的s.为页码而非节号；恢复引文删节号，保留引文内37、38、40原编号。')
add(rr(115,2),rr(58,19),end='我认为')
add(rr(115,3),rr(58,19,21),'quote',start='我认为')
add(rr(115,4),rr(58,22,24),text='针对这属于拟人化的偏见，他提出相反的原则：只要我们拥有情感生活，我们之所以能够感受这些情绪，就只能是因为我们共有的哺乳动物遗产。情绪本身被视为身体的状态和姿态。他认为，情绪表达受对立原则支配：对立的情绪调动相反的肌肉群。',reason='恢复because of所指的原因，旧译误作拥有情感生活是感受情绪的原因。')
add(rr(115,5),rr(58,25,30),fixes=[('背部贴地','背部放平'),('既保持低调','既不引人注意')],reason='flatten back不等于贴地；inconspicuous指不易察觉，不是社交意义的低调。')
add(rr(115,6),rr(58,31,32),fixes=[('盖伦与赫布之间','盖伦与赫布[[92]]之间')],reason='补回旧译漏注92。')
nt={90:'Lewis H. Morgan：《古代社会》（Ancient Society）（Harvard University Press，2013）。',91:'Charles Darwin：《人类的由来及与性有关的选择》（The Descent of Man in Relation to Sex）（Murray，1871），第III章。',92:'Donald Olding Hebb：“行为的组织：神经心理学理论”（The Organization of Behavior; A Neuropsycholocigal Theory），A Wiley Book in Clinical Psychology，第62卷（1949），第78页。'}
notes=[]
for n,refs in note_groups(rr(256,1)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch05-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['247'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch05s',5,rows,notes,rr(113,10)+rr(114,1,8)+rr(115,1,6))
(W/'checkpoint_ch05s.json').write_text(json.dumps({'next_source_pdf_page':116,'next_source_block':1,'next_supplied_pdf_page':58,'next_supplied_block':33,'next_unit':len(rows)+245,'next_note':93,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
