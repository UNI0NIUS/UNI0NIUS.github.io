from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch07-{len(rows)+1:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(162,0,1),rr(81,27),'chapter',text='第7章 逻辑与唯物主义',english='Chapter 7: LOGIC AND MATERIALISM')
rows[-1]['source_transcription_note']='恢复章节标题阅读顺序。'
add(rr(162,2),rr(81,28),'heading',text='引言')
add(rr(162,3),rr(81,28),'quote',start='显然')
add(rr(162,4),rr(81,29,32))
add(rr(162,5),rr(81,33,34)+rr(82,0,1),text='这一唯一的例外就是辩证唯物主义，即19世纪末以来世界共产主义运动的哲学。正如采纳主流宗教的帝国曾向数十亿人传授这些宗教一样，直到1989年，前苏联和欧洲社会主义国家也曾向数十亿人教授辩证唯物主义；中国和现存社会主义国家则延续至今。辩证唯物主义的影响范围不容低估。例如，2021年圣公会有8500万领圣餐者，[[3]]明显少于拥有9500万党员的中国共产党。[[4]]',reason='归位圣公会人数来源注3，taught不增译灌输；保持原文历史数据。')
add(rr(162,6),rr(82,2,4))
add(rr(162,7),rr(82,5,8))
nt={1:'Aristotle：《形而上学》，第I—IX卷，H. Tredennick英译，洛布古典丛书（William Heinemann，1933），第161页。',2:'正如其官方格言所宣示的：“我们信仰上帝”（In God We Trust）。',3:'Wikipedia：“圣公宗”（Anglican Communion），载Wikipedia（Wikipedia，2021），https://en.wikipedia.org/wiki/Anglican_Communion 。',4:'Statista：“中国共产党”（Chinese Communist Party），载Topics（Statista，2021），https://www.statista.com/topics/1247/chinesecommunist-party/ 。',5:'D. Lecourt：《无产阶级科学？李森科事件》（Proletarian Science? The Case of Lysenko）（Verso，1977）。'}
notes=[]
for n,refs in note_groups(rr(263,3)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch07-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['254'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch07a',7,rows,notes,rr(162,0,7))
(W/'checkpoint_ch07a.json').write_text(json.dumps({'next_source_pdf_page':163,'next_source_block':1,'next_supplied_pdf_page':82,'next_supplied_block':9,'next_unit':len(rows)+1,'next_note':6,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
