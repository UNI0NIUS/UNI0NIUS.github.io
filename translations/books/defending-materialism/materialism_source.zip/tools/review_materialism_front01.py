from materialism_common import *

spec=[
(rr(2,0),'i','捍卫唯物主义','chapter'),
(rr(3,0),'ii','布卢姆斯伯里另有出版','heading'),
(rr(3,1),'ii','《反对马克思主义的战争》，托尼·麦肯纳\n\n《从马克思到黑格尔，再返回马克思》，维多利亚·法雷尔德、汉内斯·库赫编','paragraph'),
(rr(4,0),'iii','捍卫唯物主义','chapter'),
(rr(4,1,2),'iii','原子在科学与哲学中的坎坷历程','paragraph'),
(rr(4,3,4),'iii','卡塔琳娜·科洛佐娃、威廉·保罗·科克肖特、格雷格·迈克尔森','paragraph'),
(rr(5,0),'iv','布卢姆斯伯里学术出版','heading'),
(rr(5,1),'iv','Bloomsbury Publishing Plc\n英国伦敦贝德福德广场50号，WC1B 3DP\n美国纽约百老汇1385号，NY 10018\n爱尔兰都柏林2区厄尔斯福特台29号','paragraph'),
(rr(5,2,3),'iv','BLOOMSBURY、BLOOMSBURY ACADEMIC及戴安娜标志均为Bloomsbury Publishing Plc的商标。','paragraph'),
(rr(5,4),'iv','2025年首次在英国出版。','paragraph'),
(rr(5,5),'iv','版权所有 © 卡塔琳娜·科洛佐娃、威廉·保罗·科克肖特、格雷格·迈克尔森，2025年。','paragraph'),
(rr(5,6,7),'iv','卡塔琳娜·科洛佐娃、威廉·保罗·科克肖特和格雷格·迈克尔森已依据1988年《版权、外观设计和专利法》主张其作为本书作者的署名权。','paragraph'),
(rr(5,8,9),'iv','丛书设计：Charlotte Daniels。\n封面图：Kohl根据Barclay的画作制作的木刻，1888年。\n图片提供：INTERFOTO / Alamy Stock Photo。','paragraph'),
(rr(5,10,12),'iv','保留所有权利。未经出版者事先书面许可，不得以任何形式或手段，包括电子或机械方式，以及影印、录音或任何信息存储与检索系统，复制或传播本出版物的任何部分。','paragraph'),
(rr(5,13,16),'iv','Bloomsbury Publishing Plc对本书中提及或引用的任何第三方网站均无控制权，亦不承担责任。本书提供的所有网址在付印时均正确有效。若网址发生变更或网站停止存在，作者和出版者对由此造成的不便表示遗憾，但不对任何此类变化承担责任。','paragraph'),
(rr(5,17),'iv','英国图书馆提供本书的书目记录。','paragraph'),
(rr(5,18),'iv','美国国会图书馆提供本书的书目记录。','paragraph'),
(rr(5,19,20),'iv','ISBN：\n精装本：978-1-3504-4732-5\n电子PDF：978-1-3504-4734-9\n电子书：978-1-3504-4735-6','paragraph'),
(rr(5,21),'iv','排版：印度钦奈Deanta Global Publishing Services。','paragraph'),
(rr(5,22,23),'iv','如需进一步了解我们的作者和图书，请访问www.bloomsbury.com，并订阅我们的通讯。','paragraph'),
]
rows=[]
for i,(refs,page,zh,kind) in enumerate(spec,1):
    en=extract(EN,refs,True).replace('\u200b','')
    rows.append({'id':f'dm-front-{i:03}','kind':kind,'source_blocks':refs,'supplied_translation_blocks':[],'printed_pages':[page],'en':en,'zh':zh,'supplied_zh':'','status':'text_compared_layout_pending','revision_reason':'补译现成中文稿省略的前置材料；完整保留出版信息。'})
rows.insert(6,{'id':'dm-front-logo','kind':'publisher_mark','source_blocks':[],'supplied_translation_blocks':[],'printed_pages':['iii'],'en':'Bloomsbury','zh':'布卢姆斯伯里','supplied_zh':'','image':'assets/publisher_logo.png','source_image':{'pdf_page':4,'xref':6},'status':'text_compared_layout_pending'})
save('front01',0,rows,[],rr(2,0)+rr(3,0,1)+rr(4,0,4)+rr(5,0,23))
