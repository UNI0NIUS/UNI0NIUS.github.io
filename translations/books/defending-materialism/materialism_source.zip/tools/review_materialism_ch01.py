"""Explicit paragraph alignment and source-based corrections to supplied Chinese."""
from pathlib import Path
import json,re,unicodedata
from materialism_common import normzh
R=Path(__file__).resolve().parents[1];W=R/'Defending Materialism/work'
EN=json.loads((W/'source_pages.json').read_text('utf-8'))
ZH=json.loads((W/'supplied_translation_pages.json').read_text('utf-8'))
def block(pages,p,b):return next(x for x in pages[p-1]['blocks'] if x['block']==b)
def extract(pages,refs,english=False):
    result=[]
    for p,b in refs:
        lines=[]
        for line in block(pages,p,b)['lines']:
            spans=[]
            for s in line['spans']:
                text=s['text']
                if english and s['flags']&1 and text.isdigit():text='[['+text+']]'
                spans.append(text)
            lines.append(''.join(spans))
        result.append('\n'.join(lines))
    text='\n'.join(result)
    if english:
        text=text.replace('age-\nold','age-old').replace('Oxford-\neducated','Oxford-educated')
        return re.sub(r'\s+',' ',text).strip().lstrip('● ')
    text=normzh(text)
    return re.sub(r'\n+','',text).strip().lstrip('• ')
def rr(p,a,z=None):return [(p,b) for b in range(a,(z if z is not None else a)+1)]
rows=[]
def add(en,zh,kind='paragraph',replacement=None,reason=None):
    old=extract(ZH,zh) if zh else ''
    row={'id':f'dm-ch01-{len(rows)+1:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b in en)),'en':extract(EN,en,True),'supplied_zh':old,'zh':replacement if replacement is not None else old,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    rows.append(row)
add(rr(10,0,1),rr(1,2),'chapter','第1章 引言','恢复原书章标题结构。')
rows[-1]['en']='Chapter 1. INTRODUCTION'
add(rr(10,2),[],'heading','概述')
add(rr(10,3),rr(1,3,6),'quote','我们走出教堂后，站着谈了一会儿贝克莱主教的巧妙诡辩：他试图证明物质并不存在，宇宙中的一切都只是观念。我说，尽管我们确信他的学说不正确，却无法驳倒它。我永远不会忘记约翰逊那敏捷的回答：他用脚猛踢一块大石头，踢得自己都弹了回来，说：“我就这样反驳它。”——詹姆斯·博斯韦尔[[1]]','将概述标题与引文分开；补出 alacrity；恢复原注1。')
add(rr(10,4),rr(1,7,8),replacement='唯物主义与唯心主义是一切哲学的两极，二者的争论已持续了2500年。约250年前，詹姆斯·博斯韦尔与塞缪尔·约翰逊的上述对话，简明地概括了这种对立在哲学和社会层面的复杂性。',reason='twin poles 译为“两极”，避免“两个极端”的额外贬义。')
add(rr(10,5),rr(1,9,10))
add(rr(10,6),rr(1,11,12))
add(rr(10,7),rr(1,13,16),replacement='詹姆斯·博斯韦尔（1740—1795）是苏格兰人，在启蒙运动时期成年。他的信仰立场多变，从小受加尔文主义熏陶，也曾动过皈依天主教的念头。在爱丁堡大学，亚当·斯密曾给他授课；斯密的经济学对制造业的发展和马克思都有重大影响。博斯韦尔一向交游广泛，甚至曾与临终的伟大怀疑论哲学家大卫·休谟讨论来世是否可能存在，而休谟坚决否认这一观念。博斯韦尔有私人财产维持生活，尽管自我厌弃，仍过着放纵的生活；他最为人所知的身份是约翰逊的传记作者。',reason='补回 great sceptical philosopher；保留 if self-loathing 的让步关系；统一姓名。')
add(rr(10,8)+rr(11,1),rr(1,17,19),replacement='塞缪尔·约翰逊（1709—1784）是一位英国文人，以其权威的英语词典闻名。他言语直率，曾在牛津大学受教育，博览群书，是托利党人，也是圣公会信徒。因此，约翰逊的常识唯物主义竟能穿透那些令博斯韦尔如此困惑的诡辩，实在引人注目。',reason='Oxford-educated 仅指在牛津受教育，不能擅增“毕业”；合并跨页段落。')
add(rr(11,2),rr(1,20,21),replacement='我们的唯物主义同样以同外部现实的互动为基础，但它当然不像约翰逊的唯物主义那样迁就唯心主义。事实上，本书旨在捍卫原子论唯物主义和机械唯物主义，反对唯心主义的解释。',reason='atomistic and mechanical 同修饰 materialism，补全“原子论唯物主义”。')
add(rr(11,3),rr(1,22,23))
add(rr(11,4),rr(1,24,28))
add(rr(11,5),rr(1,29))
add(rr(11,6),rr(1,30,31),'list_item')
add(rr(11,7),rr(1,32)+rr(2,0),'list_item',replacement='逻辑的发展及其在多位思想家著作中与“辩证法”的关系。我们在这里探究其政治影响，以及意识形态如何影响科学沿唯物主义与唯心主义这一分界作出的认识论选择。',reason='恢复 the work of multiple thinkers 的修饰范围；合并跨页条目。')
add(rr(11,8),rr(2,1,4),'list_item')
add(rr(11,9),rr(2,5,6),'list_item',replacement='物理学、生物学以及对人类社会的反思中的时间性质；后一类反思主要见于哲学，也见于社会科学。对贯穿这些学科的时间观念作诠释学考察，能够为历史唯物主义提供一种新的理解，使之摆脱 diamat 的教条，即苏联所确立的辩证唯物主义的教条。',reason='恢复 nature of time 对各领域的共同修饰，避免将“对人类社会的反思”独立成并列主题。')
add(rr(11,10)+rr(12,1),rr(2,7,11))
add(rr(12,2),rr(2,12,18))
add(rr(12,3),rr(2,19,25),replacement='原子能开发出来以后，已没有人怀疑原子的真实存在，但在1900年前后，原子的实在性还广受质疑。我们追溯这场哲学争论的政治和理论背景。我们考察人们对于原子论的“机械论”世界观中所蕴含的“粗糙的物质性”（马克思，《资本论》第1卷第1章）的反感；这种物质性与一切存在所依据的任何“空灵本原”（ἀρχή）相对。随后我们论证，正是这种反感，使那些公认属于唯物主义的哲学和科学仍然留着一扇后门，其中也包括那些甚至不愿在唯心主义与唯物主义之间作出形而上学选择的学科。“空灵本原”这一隐喻指向从古希腊到当代数学和计算机科学的一系列观念。这既可能表现为一个悬而未决的问题，也可能表现为干脆坚持“一切都是语言，外部现实并不存在”——至少不是以一种应当被认真对待的方式存在；后结构主义反复念诵的口号便是一例。',reason='nesting in 修饰物质性，旧译误使“厌恶”根植于原子论；ethereal 此处译“空灵”而非物理以太。')
add(rr(12,4),rr(2,26),'heading')
# Supplied PDF merges these source paragraphs; use exact per-span character slices below.
add(rr(12,5),rr(2,27,29),replacement='我们对唯物主义的论述尽可能以一手资料为依据；原始材料不是英语时，则使用译本。我们基本上避免与那些阐释我们所引哲学家和科学家的人展开讨论。我们也基本上避免采用范围更广的历史叙述，除非找不到一手资料，或这些叙述提供了没有争议的概述。',reason='原译跨段拼接，按原文恢复独立段落；interpreters 指阐释者。')
add(rr(13,1),rr(2,29,31),replacement='我们承认自己的“西方”哲学取向，也承认未介入当代科学史领域的争论。我们希望为理解唯物主义带来一种新视角，引导读者像我们努力做到的那样，直接接触原始论证。如果有人指责我们无知或修正主义，那就由他们去吧。当然，我们乐于接受纠正，并进一步讨论自己的立场，所秉持的是达成共同理解的精神，而不是争胜计分的经院式论辩。',reason='按英文段落恢复边界与完整措辞。')
add(rr(13,2),rr(2,32,33),replacement='为了始终聚焦唯物主义在哲学和自然哲学中的发展，我们有意作出了一些省略。尤其是，我们不讨论那些“重大”的哲学问题：我们从哪里来？为什么在这里？为什么是这样？又将走向何方？',reason='恢复段落边界。')
add(rr(13,3),rr(2,33,36),replacement='除非其他世界观曾直接促进或阻碍唯物主义，我们不予讨论。尤其是，总体而言，我们很少谈及信仰或宗教。最后，我们也不讨论这里阐述的唯物主义所具有的道德、伦理、社会或直接政治后果。也许最重要的一项省略，是没有探讨意识的性质。我们对唯心主义的拒斥，必然使我们把意识视为物质系统的一种属性，无论这种系统是否属于人类。',reason='恢复原文独立段落，不与下段引文原则混排。')
add(rr(13,4),rr(2,36,37),replacement='请注意，引文均照原文逐字引用，不对其中诸如带有性别色彩的语言作出评论。斜体沿用原文。人物的生卒年往往直接取自维基百科。',reason='恢复引文说明独立段落。')
add(rr(13,5),rr(3,0),'heading')
add(rr(13,6),rr(3,1))
add(rr(13,7),rr(3,2),'heading','第2章 对古希腊所提供的概念材料及其开创的跨千年交流的语文学与哲学考察','补回 Philologico-philosophical examination。')
add(rr(13,8),rr(3,3,6),'list_item',replacement='我们指出希腊哲学中唯心主义与唯物主义之间张力的根基：这种张力历经数世纪仍然存在，其基础前提仍与古代确立的前提相同。亚里士多德和原子论者既试图使变化成为可思考的对象，又仍困在必须遵守埃利亚学派“无中不能生有”原则的要求之中。原子论者成功地表明，“虚空”或“虚无”是物质的一个方面，一切存在的本原都是物质性的——即不可分割的物质量，atomoi，也就是“不可切分者”；伊壁鸠鲁派的卢克莱修·卡鲁斯的著作尤其如此。',reason='补回不可分割的物质量、希腊术语及其释义。')
add(rr(13,9),rr(3,7),'heading')
add(rr(13,10)+rr(14,1),rr(3,8,9),'list_item')
add(rr(14,2),rr(3,10),'heading')
add(rr(14,3),rr(3,11,14),'list_item',replacement='我们重建辩证法作为一种本体论范畴在欧洲哲学中出现的过程，并将其与古代的起点区分开来：在古代，尤其在亚里士多德关于我们今天称为逻辑学的论著中，辩证法原本是一种方法或本体论范畴。我们在共产主义的 diamat 学说中所见的唯物辩证法，其起源可以追溯到黑格尔，却不能再上溯到更早的时代。马克思对这一术语的使用更接近亚里士多德，而非受黑格尔启发的 diamat。我们把辩证法和唯物主义视为马克思思想中的两个不同范畴，也在马克思的思想来源——原子论和黑格尔——中将二者区分开来。',reason='but not further in the past 被误译成“不能追溯到马克思本人”，现纠正；保留原文 method or ontology 的表述，不擅改作者。')
add(rr(14,4),rr(3,15),'heading')
add(rr(14,5),rr(3,16,21),'list_item',replacement='我们介绍应用于社会和生物变化的唯物主义。历史唯物主义被视为斯密与恩格斯各自独立作出的共同发现。马克思的《资本论》受到牛顿关于守恒定律，以及作用力与反作用力大小相等、方向相反的观念的影响。恩格斯将历史与生物学中目的论的消解归功于马克思和达尔文二人各自独立的贡献。我们把达尔文之前以人类为中心的目的论生物学解释，与达尔文提出的因果模式相对照。我们考察达尔文主义如何取消人与动物之间的截然区分，并考察人类的情感和行为特征如何像其生理特征一样，有着深厚的哺乳动物根源。原子论在19世纪初复兴。道尔顿等人的化学进展，使之成为化学研究的实际基础。这又为理解热、压力等现象奠定了基础；蒸汽革命正建立在对这些现象的理解之上，而这也促成了热力学关键概念的发展。',reason='补回 physiology，恢复热力学概念发展的因果次序。')
add(rr(14,6),rr(3,22),'heading')
add(rr(14,7),rr(3,23,27),'list_item')
add(rr(15,1),rr(3,28),'heading')
add(rr(15,2),rr(3,29,31),'list_item')
add(rr(15,3),rr(3,32),'heading')
add(rr(15,4),rr(3,33,35)+rr(4,0),'list_item',replacement='黑格尔对亚里士多德思想中辩证成分的强调，深刻塑造了19世纪及20世纪初马克思主义者对逻辑的态度。1925年恩格斯的《自然辩证法》出版后，苏联围绕辩证唯物主义内部形式主义（此时已与逻辑相联系）与辩证法之间的平衡，展开了激烈斗争。这导致一类被混同归并为“孟什维克化的唯心主义”的思想受到严厉谴责，也导致公式化的“diamat”的形成；直至斯大林去世，这种 diamat 一直规定着官方共产主义哲学的面貌。',reason='旧译把遭谴责的“孟什维克化的唯心主义”与形成的公式化 diamat 混为同一宾语，颠倒句法关系。')
add(rr(15,5),rr(4,1),'heading')
add(rr(15,6),rr(4,2,3),'list_item',replacement='20世纪初，逻辑学的进展使其能够将自身形式化，由此发现了其核心深处的悖论。与此同时，这些进展也为计算机的发展奠定了基础，并对我们如何将现实刻画为彼此建模的反映系统，产生了深远影响。',reason='补回 formalize itself 的自指意味；ref​​lective systems 译为“反映系统”。')
add(rr(15,7),rr(4,4),'heading')
add(rr(15,8),rr(4,5,6),'list_item')
add(rr(15,9),rr(4,7),'heading','第11章 辩证唯物主义与随机唯物主义','stochastic 误作“机械论”，纠正为“随机”。')
add(rr(15,10),rr(4,8,9),'list_item')
note={'id':'dm-ch01-note-1','kind':'note','note_number':1,'source_blocks':[[244,2]],'printed_pages':['235'],'en':extract(EN,[[244,2]],True),'zh':'1. J. 博斯韦尔：《塞缪尔·约翰逊传》（The Life of Samuel Johnson），第1卷（Everyman’s Libray，J,. M. Dent & Sons Ltd，1906），第292页。','editor_note':'底本中的 Libray 与 J,. 拼写、标点照录；未独立核验该引文所据版本。','status':'text_compared_layout_pending'}
packet={'packet':'ch01','chapter':'1','reading_order':10,'units':rows,'notes':[note],'full_book_complete':False,'layout_review':'pending','source_comparison':'English original PDF 10–15 and note on PDF 244; supplied Chinese PDF 1–4; explicit paragraph mapping'}
(W/'packets').mkdir(exist_ok=True)
(W/'packets/ch01.json').write_text(json.dumps(packet,ensure_ascii=False,indent=2),'utf-8')
expected={(p,b['block']) for p in range(10,16) for b in EN[p-1]['blocks'] if p==10 or b['block']!=0}
used=[tuple(r) for u in rows for r in u['source_blocks']]
assert set(used)==expected,(expected-set(used),set(used)-expected)
assert len(used)==len(set(used))
assert sum(u['en'].count('[[1]]') for u in rows)==1
assert sum(u['zh'].count('[[1]]') for u in rows)==1
audit={'scope':'Chapter 1 only','units':len(rows),'source_blocks':len(used),'source_block_coverage':'pass','notes':1,'explicit_revisions':sum('revision_reason' in u for u in rows),'layout':'pending','full_book_complete':False}
(W/'ch01_text_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps(audit,ensure_ascii=False))
