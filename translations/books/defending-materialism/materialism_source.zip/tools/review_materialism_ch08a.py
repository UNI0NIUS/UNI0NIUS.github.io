from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch08-{len(rows)+1:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(178,0,1),rr(92,12),'chapter',text='第8章 逻辑与辩证唯物主义',english='Chapter 8: LOGIC AND DIALECTICAL MATERIALISM')
rows[-1]['source_transcription_note']='恢复章节标题阅读顺序。'
add(rr(178,2),rr(92,13),'heading',text='黑格尔与逻辑')
add(rr(178,3),rr(92,13,15),'quote',text='……把三段论仅仅看作由三个判断构成，是一种形式主义观点；它忽视了各个规定之间的关系，而推理所涉及的恰恰只是这种关系。把各项之间的联系拆分为孤立的前提和与这些前提相区别的结论，完全是一种纯粹主观的反思：',reason='拆出节标题，terms译为各项，补全旧译虚词。')
add(rr(178,4),rr(92,16),'quote',text='所有人都会死。盖乌斯是人。因此盖乌斯会死。')
add(rr(178,5),rr(92,17,18),'quote',text='一听到这种推理被搬出来，人立刻就会感到厌倦。这种厌倦来自一种形式的徒劳：它通过彼此分离的命题制造出多样性的幻象，而这种幻象在事实本身中立即消解了。G. 黑格尔，《逻辑学》[[1]]')
add(rr(178,6),rr(92,19,20),text='格奥尔格·黑格尔（1770—1831）的唯心主义在欧洲哲学中占据核心地位。英国传统在复兴逻辑之前先与亚里士多德决裂；与之不同，辩证法处于黑格尔认识论的核心。',reason='删除旧译“无黑格尔”中的误字，恢复对比句。')
add(rr(178,7),rr(92,21,24),text='从亚里士多德的视角看，黑格尔著作《逻辑学》[[2]]的书名似乎有些奇怪。亚里士多德把辩证法与科学相对置，认为它是一种说服形式，而非自主理解世界如何运行的途径；他也把辩证法与三段论逻辑相对置，认为它是前提的来源，而非对这些前提进行推理的方法。尽管如此，黑格尔确实认为逻辑可以得到科学阐释，这一点仍有益处。')
add(rr(178,8),rr(92,25,27),text='黑格尔对把三段论的形式与其应用语境相分离的价值深表怀疑。也就是说，三段论本身并无意趣。其重要性在于它如何将特定前提（规定）与特定结论联系起来，而这些联系又依赖先前的推理来确立前提之间的关系。正如我们将看到的，这种态度是辩证唯物主义中反复出现的特征。',reason='of no interest不加强为绝无研究价值，补全句法。')
add(rr(178,9),rr(92,28,30),text='尽管如此，黑格尔确实系统地探讨了三段论的各种形式，[[3]]并借助辩证转化来考察它们之间的关系。不过，他除以普遍（U）、单称（S）或特称（P）来标记三段论中的项之外，并未采用其他形式记号；这比早先的做法更为简化。与前人一样，黑格尔运用了简洁的论证和例子。',reason='补旧译漏注3；terms指三段论的项。')
add(rr(179,1),rr(93,0,2),text='《逻辑学》的序言进一步阐明了黑格尔对三段论逻辑的态度。首先，他指出科学和常识已经取代形而上学，也取代了“逻辑教人如何思考”这一观念。尽管如此，逻辑仍被保留在诸科学之中，“大概是为了某种形式上的效用”，虽然“它的形式和内容在漫长的传承中始终未变”（第8页）。')
add(rr(179,2),rr(93,3,4),text='对黑格尔而言，思想蕴含于语言之中，语言的形式决定思想；在这方面，德语显然更胜一筹（！）（《第二版序言》，第12页）。而且，逻辑在人类境况中占据核心地位：',reason='拆出后续引文，恢复作者括注感叹号。')
add(rr(179,3),rr(93,4,7),'quote',text='逻辑对人来说是如此自然，甚至就是人的本性。但是，如果我们将自然本身，即物理领域，与精神领域相对置，那么就必须说：逻辑是贯穿人一切自然行为——感知、直观、欲求的方式，以及需要和冲动——的超自然要素；它由此使这些行为成为真正属人的东西，尽管还只是形式上属人的东西，使之成为表象和目的。（第12页）',reason='intuiting译直观，human不误作人性；拆分引文。')
add(rr(179,4),rr(93,8),text='在这里，他明确反对亚里士多德的立场：')
add(rr(179,5),rr(93,8,10),'quote',text='亚里士多德在同一语境中说：“人的本性在如此多的方面都处于束缚之中；但这门并非为任何效用而追求的科学，独自是自在自为地自由的，因而似乎并非人所能拥有。”（第14页，引用亚里士多德《形而上学》982b）',reason='in and for itself恢复哲学术语自在自为；分开作者与引文。')
add(rr(179,6),rr(93,11,13),text='黑格尔则认为，恰恰相反，逻辑关乎抽象思维，所以先教给年轻人，具体事务则留待以后。且不论黑格尔未能意识到这种教育是何等的特权，他在这里反映了“三艺”与“四艺”的区分，这种区分当时想必仍然通行。')
add(rr(179,7),rr(93,14,15),text='对黑格尔而言，逻辑的一大益处，是其普遍性使它能够发挥简约表达的作用。然而，脱离内容的逻辑无法达到真理，因此常识将其视为贫瘠无物而加以拒斥，也就不足为奇了：',reason='abbreviation译简约表达，避免旧译捷径误导；拆出引文。')
add(rr(179,8),rr(93,15,19),'quote',text='对于规定推理规则的公式而言——推理实际上是知性的一项主要功能——健全的常识忽视了这些公式在认识中有其位置、必须得到遵守，并且是理性思维必不可少的材料；无论这种忽视多么错误，常识同样正确地认识到：这些公式不加区分地既为谬误服务，也为诡辩服务；无论如何定义真理，就更高的真理，例如宗教真理而言，它们都毫无用处。总的说来，它们只涉及知识的正确性，而不涉及知识的真理性。（第18页）',reason='understanding译知性；原文主要功能指推理而非公式，恢复句法关系。')
add(rr(179,9),rr(93,20),text='在这里，黑格尔的立场令人想起霍布斯。')
nt={1:'G. Hegel：《逻辑学》，G. Di Giovanni英译（Cambridge University Press，2010），第592—593页。',2:'Hegel：《逻辑学》。',3:'在所引英译本中占30余页。'}
notes=[]
for n,refs in note_groups(rr(264,3)):
    notes.append({'id':f'dm-ch08-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['255'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch08a',8,rows,notes,rr(178,0,9)+rr(179,1,9))
(W/'checkpoint_ch08a.json').write_text(json.dumps({'next_source_pdf_page':180,'next_source_block':1,'next_supplied_pdf_page':93,'next_supplied_block':21,'next_unit':len(rows)+1,'next_note':4,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
