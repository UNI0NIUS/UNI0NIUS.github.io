from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch05-{len(rows)+38:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(85,5),rr(40,25),'heading')
add(rr(85,6)+rr(86,1),rr(40,26,32),end='但且看一枚蛋',fixes=[('动力唯物主义','运动唯物主义'),('无机物质向有机','惰性物质向有机'),('特定“热力学”论点，','特定“热力学”论点[[14]]，')],reason='统一kinetic术语；inert不是无机；恢复原注14。')
add(rr(86,2),rr(40,32,35),'quote',start='但且看一枚蛋')
add(rr(86,3),rr(40,36,38)+rr(41,0,1),end='你是否会像笛卡尔')
add(rr(86,4)+rr(87,1),rr(41,1,12),'quote',start='你是否会像笛卡尔')
rows[-1]['editor_note']='原注18之后重复了前面关于机器、组织及感觉产生的一段引文。已核对源PDF，确为底本重复，正文保留，不将其当作译稿误贴而删去。'
add(rr(87,2),rr(41,13,19),fixes=[('蛋白质分子','蛋白质物质'),('在21 世纪具备','具备'),('这绝非一个有争议的观点','这在21世纪绝非一个有争议的观点')],reason='in the twenty-first century限定争议性而非动物获得能力的时间；protein mass不是单个分子。')
add(rr(87,3),rr(41,20,23),end='人之所以是',fixes=[('物种存在','类存在'),('借用马克思的术语来说','借用马克思的术语来说[[23]]')],reason='Gattungswesen采用类存在，恢复原注23。')
add(rr(87,4)+rr(88,1),rr(41,23,34),'quote',start='人之所以是',fixes=[('“物种存在”','“类存在”'),('实际的、活生生的物种','实际的、活生生的类'),('无机自然领域就越显著','无机自然领域就越普遍')],reason='universal漏译为显著，恢复普遍性论证。')
add(rr(88,2),rr(41,35,42)+rr(42,0,2))
rows[-1]['editor_note']='底本中rganic漏首字母o，中文按organic译有机，英文保留原样。'
add(rr(88,3),rr(42,3,9),end='自然目的是',fixes=[('余辉','许煜'),('许辉','许煜'),('“目的”（causa finalis）','“目的因”（causa finalis）')],reason='统一人名，causa finalis为目的因。')
add(rr(88,4),rr(42,9,11),'quote',start='自然目的是',english=extract(EN,rr(88,4),True).replace('*A B C A → → → 27','*A→B→C→A[[27]]'),reason='恢复源图箭头顺序及原注27；保留原书星号。')
rows[-1]['zh']=rows[-1]['zh'].replace('A→B→C→A','*A→B→C→A')
url='https://www.marxists.org/reference/archive/diderot/1769/conversation.htm'
nt={14:'参见Jeremy L. England：“自我复制的统计物理学”（Statistical Physics of Self-replication），The Journal of Chemical Physics，第139卷，121923（2013），doi:10.1063/1.4818538。',15:'Denis Diderot，载D. Diderot与J. D’Alembert编：《科学、艺术与工艺百科全书》（Encyclopédie des arts et des métiers），35卷（Briasson，1751—1780；重印本，Stuttgart/Bad Cannstatt：Frommann，1966），第V卷第270页。在线有多个版本：Lexilogos、官方ARTFL项目及新的ENCRRE项目。',16:'Denis Diderot：“达朗贝尔与狄德罗的对话（1769）”（Conversation Between D’Alembert and Diderot），载Diderot, Interpreter of Nature，Jean Stewart与Jonathan Kemp译（International Publishers，1943），无页码，'+url+'（访问日期：2022年11月12日）。',17:'狄德罗：“达朗贝尔与狄德罗的对话（1769）”，'+url+'（访问日期：2022年12月18日）。',18:'狄德罗：“达朗贝尔与狄德罗的对话（1769）”，'+url+'（访问日期：2022年12月19日）。',19:'Robyn P. Araujo、Lance A. Liotta：“任意规模网络实现稳健完全适应的拓扑要求”（The Topological Requirements for Robust Perfect Adaptation in Networks of Any Size），Nature Communications，第9卷，1757（2018），https://doi.org/10.1038/s41467-018-04151-6。',20:'Helen De Cruz：“动物认知、物种不变论与数学实在论”（Animal Cognition, Species Invariantism and Mathematical Realism），载Advances in Experimental Philosophy，Andrew Aberdein与Matthew Inglis编（Bloomsbury Academic，2019），第39—62页。',21:'Elisabeth Brannon、Jessica Cantlon：“猴子与大学生的基础数学”（Basic Math in Monkeys and College Students），PLoS Biology，第5卷第12期（2007），e328，https://doi.org/10.1371/journal.pbio.0050328；Brian Butterworth：《鱼会计数吗？动物揭示我们独特数学心智的奥秘》（Can Fish Count?: What Animals Reveal about our Uniquely Mathematical Mind），Kindle版（Quercus，2022）。',22:'Peter Wolfendale：《理性的复仇》（The Revenge of Reason），Ray Brassier与Reza Negarestani作序（Urbanomic/Mono，2023）。',23:'卡尔·马克思：《1844年经济学哲学手稿：异化劳动》，Martin Milligan译（Progress Publishers，1959），Marxists Internet Archive，https://www.marxists.org/archive/marx/works/1844/manuscripts/labour.htm（访问日期：2022年12月26日）。',24:'马克思：《1844年经济学哲学手稿》，无页码。',25:'“在这个特定问题上，唯物主义与‘马赫主义’的区别在于：唯物主义完全符合自然科学，把物质看作第一性的，把意识、思想、感觉看作第二性的，因为在明确的形式下，感觉只同物质的较高形式（有机物质）相联系，而‘在物质结构的基础中’，只能推测存在着一种类似于感觉的能力。例如，著名德国科学家恩斯特·海克尔、英国生物学家劳埃德·摩根等人就作出了这种假设，更不用说前文提到的狄德罗的猜想了。”（引自V. I. 列宁：《全集：唯物主义和经验批判主义》，第14卷［Progress Publishers，1977］，第46页。）',26:'Katerina Kolozova：“非人性的人工制品：关于意指自动机及其物理支撑在幻想统一体中的唯物主义论述”（The Artifact of Non-Humanity: A Materialist Account of the Signifying Automaton and Its Physical Support in a Fantasized Unity），Philosophy Today，第65卷第2期（2021年春），第359—374页，doi:10.5840/philtoday2021420402n。',27:'许煜：《递归性与偶然性》（Recursivity and Contingency）（Rowman & Littlefield International，2019），第41页。'}
notes=[]
groups=[]
for n,refs in note_groups([[253,1]]):
    if extract(EN,refs,True).startswith('26 December 2022'):
        assert groups[-1][0]==23
        groups[-1][1].extend(refs)
    else:groups.append((n,refs))
for n,refs in groups:
    if n not in nt:continue
    en=extract(EN,refs,True).replace('\u200b','')
    for a,b in [('1769/ conversation','1769/conversation'),('www .marxists','www.marxists'),('pbio .0050328','pbio.0050328'),('https:// www','https://www')]:en=en.replace(a,b)
    notes.append({'id':f'dm-ch05-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['244'],'en':en,'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch05c',5,rows,notes,rr(85,5,6)+rr(86,1,4)+rr(87,1,4)+rr(88,1,4))
(W/'checkpoint_ch05c.json').write_text(json.dumps({'next_source_pdf_page':89,'next_source_block':1,'next_supplied_pdf_page':42,'next_supplied_block':12,'next_unit':len(rows)+38,'next_note':28,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
