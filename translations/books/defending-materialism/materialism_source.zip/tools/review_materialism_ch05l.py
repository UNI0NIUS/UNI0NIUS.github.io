from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch05-{len(rows)+152:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(102,1),rr(49,34,35),'quote',start='易燃化石',fixes=[('易燃化石','易燃矿物'),('[[5]] [[9]]','[[59]]')],reason='原注59明确fossils在此为从地下挖出的东西，包括煤和矿物油，并非现代生物化石。')
rows[-1]['editor_note']='本段及以下历史化学引文含phiogifton、confumed、diffolve、fix、finell等底本拼写，英文按原书照录；中文结合上下文及原注翻译，不将其当作现代术语。'
add(rr(102,2),rr(49,36)+rr(50,0),'quote')
add(rr(102,3),rr(50,1,2),'quote',text='燃素化的矾酸（挥发性矾酸[[60]]）经常从火山口喷出；其气味令人窒息而刺鼻。与燃素及热质的结合使它成为气态，但并不妨碍它与水结合。',reason='恢复旧译遗漏的主语及原注60；保持历史化学名称，现代对应物由原注说明。')
add(rr(102,4),rr(50,3,4),'quote',fixes=[('亚硝酸','硝酸'),('化石界','矿物界'),('更稳定的部分','较不易挥发的部分')],reason='结合原注61，不把历史nitrous acid机械等同于现代亚硝酸；fixed与挥发性相对。')
rows[-1]['editor_note']='此处及下文nitrous acid是引文所用旧称；原注61明确以现代发烟硝酸解释。底本folds、miore等拼写原样保留于英文。'
add(rr(102,5),rr(50,5,6),'quote',fixes=[('使其保持纯净','使其呈现这种无色状态')],reason='procure it so承接colourless，旧译误指纯净。')
rows[-1]['editor_note']='底本在attraction和so后留有星号，但本书此处没有相应星号注释；英文保留星号。'
add(rr(102,6),rr(50,7,8),'quote',fixes=[('亚硝酸若','硝酸[[61]]若'),('[[6]] [[2]]','[[62]]')],reason='恢复遗漏原注61，按该注处理历史酸名。')
add(rr(102,7),rr(50,9,13),fixes=[('可互换性','可交换性'),('黄金价格','以黄金表示的价格'),('共同物质','共同实体')],reason='exchangeability关乎交换，不是物件可互换；price in gold是以黄金表示的价格。')
add(rr(102,8),rr(50,14,15),fixes=[('共同物质','共同实体')])
add(rr(102,9),rr(50,16,17),fixes=[('共同实质','共同实体')])
nt={59:'18世纪的fossils一词源自拉丁语fossa（沟），指一切从地下挖出的东西。因此，他所谓的易燃矿物，指的是煤和矿物油。',60:r'即我们今天所谓的$\mathrm{SO_2}$。',61:r'现在称为发烟硝酸；斯特雷奇观察到的现象，是由溶解在酸中的$\mathrm{NO_2}$引起的。',62:'John Strachey：《关于不同土层与矿物层的观察》（Observations on the Different Strata of Earths and Minerals）（1730）。'}
notes=[]
for n,refs in note_groups(rr(255,4)):
    if n not in nt:continue
    en=extract(EN,refs,True).replace('SO2',r'$\mathrm{SO_2}$').replace('NO2',r'$\mathrm{NO_2}$')
    notes.append({'id':f'dm-ch05-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['246'],'en':en,'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch05l',5,rows,notes,rr(102,1,9))
(W/'checkpoint_ch05l.json').write_text(json.dumps({'next_source_pdf_page':102,'next_source_block':10,'next_supplied_pdf_page':50,'next_supplied_block':18,'next_unit':len(rows)+152,'next_note':63,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
