from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch06-{len(rows)+19:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(134,7)+rr(135,1),rr(68,24,28),'quote',text='1785年，库仑制造了他的扭秤，借此测量带电物体之间的斥力。假设有两个小球A、B，它们整体上带有相同的电荷。当两个球心相距一定距离r时，它们会相互施加某一斥力p。现在让另一小球C与B接触，使两者带上相等的电荷，然后在相同距离r处分别测量B与A、C与A之间的斥力。这两项斥力的和仍为p。因此，有某种东西保持了恒定。如果我们把这一效应归于某种物质，自然就会推断出它的恒定性。但这一说明的关键是电力p的可分性，而不是物质这一比喻。',reason='原文斥力符号为p而非旧译p_0；统一扭秤术语。')
add(rr(135,4),[],'figure',text='图6.1 马赫论证中使用的库仑扭秤。出自库仑1785年的文献。',reason='恢复旧译遗漏的原图和图注。')
rows[-1].update(image='assets/figure-6-1.png',source_image={'pdf_page':135,'block':3,'xref':823},image_labels_zh='原图字母为部件标号；Fig.为图号。')
en=extract(EN,rr(135,2)+rr(136,1),True).replace('q s 2/',r'$q^2/s$')
add(rr(135,2)+rr(136,1),rr(68,29,34),'quote',english=en,text=r'1838年，里斯制造了他的电气空气温度计（热电计）。这一仪器测量莱顿瓶放电产生的热量。该热量并不正比于按库仑的方法测得的瓶中电量；若以q表示这一电量、s表示电容，则热量正比于$q^2/s$，或者更简单地说，正比于带电瓶的能量。现在，若让莱顿瓶通过温度计完全放电，就能得到一定的热量W。但如果让放电通过温度计进入第二个瓶子，得到的热量就少于W。不过，再使两个瓶子通过空气温度计完全放电，就能得到余下的热量；此时，热量又正比于两个瓶子的能量。因此，在第一次不完全放电时，电的做功能力就损失了一部分。[[8]]',reason='据原图恢复q²/s，明确放电瓶与空气温度计关系。')
rows[-1]['editor_note']='英文底本将to印作tc，照录。'
add(rr(136,5),[],'figure',text='图6.2 马赫所描述的莱顿瓶实验。作者绘图。',reason='恢复旧译遗漏的原图和图注。')
rows[-1].update(image='assets/figure-6-2.png',source_image={'pdf_page':136,'block':4,'xref':834},image_labels_zh='Jar 1／Jar 2：莱顿瓶1／2；charge：充电；connect：连接；Riess electro thermometer：里斯电气温度计；First experiment／Second experiment：第一次／第二次实验；Time：时间；T1—T3为温度计标记。')
add(rr(136,2),rr(69,0,1),text='他接着论证说，库仑[[9]]实验先进行，只是历史上的偶然。如果先做的是莱顿瓶实验，那么测量电所用的量就会是电能，而不是电荷。',reason='补漏注9。')
add(rr(136,3)+rr(137,1),rr(69,2,4))
add(rr(137,2),rr(69,5,7),text='他认为，把电荷看作守恒量，与把热质看作守恒量，理由同样充分。静电学承认，同样数量的电荷，随其电势不同，可以对应不同的能量。同样，一定数量的热质也可能随其势的不同而包含不同的能量。因此，温度可以看作电压在热学中的对应量：电压表示电荷的势，而温度表示物体内热质的势。',reason='caloric均指热质而非热量；恢复论证所依赖的物质数量与能量区分。')
add(rr(137,3),rr(69,8),fixes=[('拒绝热量','拒绝热质')])
add(rr(137,4),rr(69,9))
add(rr(137,5),rr(69,10),'heading')
add(rr(137,6),rr(69,11,15),text='再看马赫如何结束他的第一个类比，即库仑类比：“如果我们把这一效应归于某种物质，自然就会推断出它的恒定性。但这一说明的关键是电力p的可分性，而不是物质这一比喻。”注意，他在这里留了退路。他甚至没有直言自己赞同电荷具有实体性。他把电荷概念称为一种比喻，说真实存在的是电力的可分性。这符合他总体上的工具主义科学观：科学研究的是仪器测量结果之间的关系，而非发现究竟是什么东西使仪表指针运动。',reason='明确what the things are的对象而非旧译增添的本质论表述。')
add(rr(137,7),rr(69,16))
add(rr(137,8),rr(69,17,19),text='第一步，实验者给一个小球充电（图6.1中标为d），然后将它放入扭秤。他利用扭秤顶部的刻度盘，读出该球对小球a施加的静电力。接着把小球d取出，让它与另一个小球b接触（库仑图中未画出b）。然后依次把d、b放入扭秤，分别从刻度盘上读出它们造成的偏转。',reason='恢复遗漏的小球d；dial为刻度盘，不是指针。')
add(rr(137,9),rr(69,20,23),text='把这个实验叫作对力的分割的测量，其实并不恰当，因为这里是在三个不同的时刻，分别进行了三次力的测量。真正展示力的分割，需要被分割的力同时作用，如图6.3所示。库仑观察到的是：似乎有某种东西能够在小球之间传递，使这些不同小球在不同时刻所能产生的力保持守恒。他据此推断，有某种东西——不妨称为电荷——被分配到了小球之间。',reason='something先保留为某种东西，避免提前添入物质判断；区分同时与先后测量。')
nt={8:'Mach：《能量守恒原理的历史与根源》（History and Root of the Principle of the Conservation of Energy），第45页。',9:'Charles Augustin Coulomb：“关于扭转力及金属丝弹性的理论和实验研究：此理论在工艺和各种物理实验中使用金属方面的应用；用于测量最微小力的各种扭秤的制造；关于弹性与内聚力定律的观察”（Recherches théoriques et expérimentales sur la force de torsion: & sur l’élasticité des fils de métal: application de cette théorie à l’emploi des métaux dans les arts & dans différentes expériences de physique: construction de différentes balances de torsion, pour mesurer les plus petits degrés de force: observations sur les loix de l’élasticité & de la coherence），1784。'}
notes=[]
for n,refs in note_groups(rr(259,3)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch06-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['250'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
import sys
sys.path.insert(0,str(R/'tools/python_libs'))
import fitz
d=fitz.open(json.loads((W/'source_manifest.json').read_text('utf8'))['path'])
for xref,name in [(823,'figure-6-1.png'),(834,'figure-6-2.png')]:
    fitz.Pixmap(d,xref).save(str(R/'Defending Materialism/output/assets'/name))
save('ch06b',6,rows,notes,rr(134,7)+rr(135,1,2)+rr(135,4)+rr(136,1,3)+rr(136,5)+rr(137,1,9))
(W/'checkpoint_ch06b.json').write_text(json.dumps({'next_source_pdf_page':138,'next_source_block':1,'next_supplied_pdf_page':69,'next_supplied_block':24,'next_unit':len(rows)+19,'next_note':10,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
