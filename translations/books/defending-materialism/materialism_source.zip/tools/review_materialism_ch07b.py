from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch07-{len(rows)+8:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(163,1),rr(82,9),'heading')
add(rr(163,2),rr(82,10,12))
add(rr(163,3),rr(82,13))
add(rr(163,4),rr(82,14),'list_item',text='构造用于推理的陈述，即文法或句法；')
add(rr(163,5),rr(82,15),'list_item')
add(rr(163,6),rr(82,16),'list_item',text='操作陈述，以确定其性质，通常是判断它们总为真或假、还是部分情形下为真或假，即通过证明或求值。',reason='去掉此处旧译误加的注7，原注7位于下一页前提真伪论述。')
add(rr(163,7),rr(82,17))
add(rr(163,8),rr(82,18,19))
add(rr(163,9),rr(82,20),text='三段论一般采用如下三项形式：')
for j,t in enumerate(['前提$_1$','前提$_2$','结论']):
    add([[163,10,j,j+1]],rr(82,20),'quote',text=t,english=['$premise_1$','$premise_2$','conclusion'][j],reason='保留三行推理式及前提编号。')
add(rr(163,11),rr(82,21),text='读作：给定前提$_1$和前提$_2$，可以得出结论。',english='and reads as: given $premise_1$ and $premise_2$, we can conclude conclusion.')
add(rr(163,12),rr(82,22,23))
for j,t in enumerate(['1. A','2. 如果A，那么B','3. B']):add([[163,13,j,j+1]],rr(82,24+j),'list_item',text=t)
add(rr(163,14),rr(82,27),text='当代逻辑的这一基本规则称为肯定前件式（Modus Ponens），即肯定的方法。例如：')
rows[-1]['editor_note']='底本拉丁词误印Modus Ponems，英文照录，中文用通行拼写Ponens。'
for j,t in enumerate(['1. 巴斯特是一只猫','2. 如果巴斯特是一只猫，那么巴斯特喜欢鱼','3. 所以巴斯特喜欢鱼']):add([[163,15,j,j+1]],rr(82,28+j),'list_item',text=t)
add(rr(163,16),rr(82,31))
notes=[]
for n,refs in note_groups(rr(263,3)):
    if n!=6:continue
    notes.append({'id':'dm-ch07-note-6','kind':'note','note_number':6,'source_blocks':refs,'printed_pages':['254'],'en':extract(EN,refs,True),'zh':'6. Cockshott、Mackenzie与Michaelson：《计算及其极限》（Computation and its Limits）。','status':'text_compared_layout_pending'})
save('ch07b',7,rows,notes,rr(163,1,16))
(W/'checkpoint_ch07b.json').write_text(json.dumps({'next_source_pdf_page':164,'next_source_block':1,'next_supplied_pdf_page':82,'next_supplied_block':32,'next_unit':len(rows)+8,'next_note':7,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
