from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch09-{len(rows)+117:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(207,3),rr(108,36),'heading',text='苏联逻辑学的复兴')
add(rr(207,4),rr(109,0,1),text='1945年美国引爆三枚原子弹，从根本上改变了苏联科学工作的优先次序，削弱了意识形态，尤其是反形式主义，在政策中的支配地位。')
add(rr(207,5),rr(109,2,8),text='1945年8月，苏联成立两个机构来管理原子弹研发。[[33]]（第131页）苏联第一个计算机项目于1946年在基辅启动，由谢尔盖·列别杰夫（1902—1974）领导，MESM于1950年投入运行。然而，维纳的著作[[34]]出版后，一场反控制论运动展开了，理由是控制论属于资本主义创新，旨在削弱工人阶级组织，最终完全取代工人，使他们陷于赤贫。[[35]]（第128页）这表明，这些意识形态家对马克思主义经济学，以及活劳动在资本主义剩余价值生产中的核心作用，了解甚少。在马克思的体系中，利润来自人的活动，而非机器。而且，正如乌斯丁[[36]]所述，苏联军方迅速采用控制论，并“将意识形态考虑放到一边”（第312页）。',reason='合并源段，注34归位书名指代后。')
add(rr(207,6),rr(109,9,12),text='尽管如此，计算机仍不得不被称为“数学机器”，以避开针对控制论的审查。[[37]]人们明确区分两者：用控制论模拟人类行为不可接受，而用计算机进行计算和自动化则可以。把计算机类比于人脑被视为“荒谬”。[[38]]（第142—143页）对唯物主义来说，这一立场似乎完全是一种倒退。如果人不只是机器，那么人的额外特性就必然来自非物质的属性。',reason='cybernetic scrutiny指针对控制论的审查，而非控制论自身实施审视。')
add(rr(207,7),rr(109,13,14),text='回到逻辑学，苏联教育中的变化来得很快。坎贝尔[[40]]引用的1946年苏共（布）中央委员会指令[[39]]指出，',reason='拆分引文，修复注40拆号。')
rows[-1]['zh']='回到逻辑学，苏联教育中的变化来得很快。1946年苏共（布）中央委员会的一项指令，[[39]]由坎贝尔[[40]]引述，指出'
add(rr(207,8),rr(109,14),'quote',text='中学不教授逻辑学和心理学，是很不恰当的。（第343页）')
add(rr(207,9),rr(109,15,17),text='并制定了开设这些课程的计划，配以资源。马蒂亚斯[[41]]因此叙述，切尔帕诺夫1918年版的《逻辑学教科书》于1946年重印，随后出版了斯特罗戈维奇的《逻辑学》、阿斯穆斯的一部新教科书，以及斯特罗戈维奇著作的又一版（第8页）。',reason='修复注41，承接前句。')
add(rr(207,10)+rr(208,1),rr(109,18,20),text='洛伦兹[[42]]指出，继李森科在遗传学上取得所谓成就之后，1948年曾有人推动苏联更广泛的科学工作系统地服从“科学具有阶级性”这一观念。然而，数学和物理学方面的计划被原子导弹项目负责人贝利亚叫停，因为“有影响力的物理学家向他解释，这可能损害这些项目”（第217—218页）。',reason='合并跨页句，修复注42并统一洛伦兹。')
add(rr(208,2),rr(109,21,22),text='1952年，坎贝尔[[43]]指出，苏联逻辑教育面临着如何调和“资产阶级”逻辑与辩证逻辑的问题。他概述奥斯马科夫[[44]],[[45]]1950年的一篇文章，认为其主张是：',reason='修复注43—45，分离引文。')
add(rr(208,3),rr(109,22,23),'quote',text='与世界观不同，思维逻辑是一种无阶级的现象。（第281页）')
add(rr(208,4),rr(109,24),text='此外，还有一句令人强烈联想到亚里士多德的表述：')
add(rr(208,5),rr(109,24,25),'quote',text='思维逻辑据以进行的概念，对客观现实反映得好或不好，取决于思考者的意识形态或世界观。（第282页）')
add(rr(208,6),rr(109,26,29),text='巴扎诺夫[[46]]和基拉科斯[[47]]叙述了亚诺夫斯卡娅如何成为苏联形式逻辑复兴的核心人物。1947年，她翻译了形式主义者希尔伯特和阿克曼的《理论逻辑纲要》，1948年又翻译了塔尔斯基的《逻辑与演绎科学方法论导论》。[[48]]1947年，亚诺夫斯卡娅主张，应当把“数理逻辑的方法论形式主义”与其背后的唯心主义哲学区分开来，因为[[49]]数理逻辑',reason='修复注46—49，统一数理逻辑并拆出引文。')
add(rr(208,7),rr(109,29,30),'quote',text='不仅可以被视为数学的逻辑，也可以被视为逻辑的数学，因为它在很大程度上是将数学方法应用于逻辑问题的结果。[[50]]')
add(rr(208,8),rr(109,31),text='这一论证回到布尔对逻辑的数学化，巧妙地倒转了元数学所宣称的目标。')
add(rr(208,9),rr(109,32,33),text='亚诺夫斯卡娅在此后的一生中始终推动形式逻辑的发展。她享有很高声望，从1959年起担任莫斯科国立大学数理逻辑教席，直至1966年去世。[[51]]',reason='Chair按教席译，不无据具体化为系主任；修复注51。')
nt={33:'Gerovitch：《从新话到控制论话语：苏联控制论史》。',34:'Wiener：《控制论，或动物和机器中的控制与通信》。',35:'Gerovitch：《从新话到控制论话语：苏联控制论史》。',36:'S. T. Usdin：《建设共产主义：两名美国人如何为斯大林从事间谍活动并创建苏联硅谷》（Yale，2005）。',37:'Gerovitch：《从新话到控制论话语：苏联控制论史》，第131页及以下。',38:'Gerovitch：《从新话到控制论话语：苏联控制论史》。',39:'苏共（布）中央委员会：“中学的逻辑学和心理学”，Soviet Studies 3，第3期（1952）：342—344。',40:'C. A. Campbell：“苏联的逻辑概念”，Soviet Studies 3，第3期（1952）：278—287。',41:'Mathias：“逻辑与恐怖”。',42:'Lorentz：“1928至1953年苏联的数学与政治”。',43:'Campbell：“苏联的逻辑概念”。',44:'苏联高等教育部社会科学教学管理机构的哲学部门负责人。',45:'I. I. Osmakov：“论思维逻辑与逻辑科学”，Voprosy Filosofii 3（1950）：309—317。',46:'V. Bazhanov：“复兴：S. A. 亚诺夫斯卡娅的逻辑学道路”，History and Philosophy of Logic 22，第3期（2001）：129—133。',47:'Kilakos：“索菲娅·A. 亚诺夫斯卡娅：苏联数理逻辑的马克思主义先驱”。',48:'Bazhanov：“复兴：S. A. 亚诺夫斯卡娅的逻辑学道路”，第132页。',49:'引自S. A. Yanovskya：“作为无穷小分析批评者的米歇尔·罗尔”（俄文），Trudy Instituta Istorija Estestvoznanija 1（1947）：327—346（引文见341页）。',50:'Kilakos：“索菲娅·A. 亚诺夫斯卡娅：苏联数理逻辑的马克思主义先驱”，第57页。',51:'Bazhanov：“复兴：S. A. 亚诺夫斯卡娅的逻辑学道路”，第132页。'}
notes=[]
for p in [268,269]:
    for n,refs in note_groups(rr(p,1)):
        if n not in nt:continue
        notes.append({'id':f'dm-ch09-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':[str(p-9)],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch09h',9,rows,notes,rr(207,3,10)+rr(208,1,9))
(W/'checkpoint_ch09h.json').write_text(json.dumps({'next_source_pdf_page':208,'next_source_block':10,'next_supplied_pdf_page':109,'next_supplied_block':34,'next_unit':len(rows)+117,'next_note':52,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
