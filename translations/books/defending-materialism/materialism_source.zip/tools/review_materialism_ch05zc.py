from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch05-{len(rows)+341:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(128,6)+rr(129,1),rr(64,31,33)+rr(65,0,1),fixes=[('格子气体','格子气'),('那么情况确实就是这样：所观察到景象','那么你确实会观察到这样的景象'),('一张看似随机图','一幅看似随机的图c'),('对图应用正向规则','对图c应用正向规则')],reason='恢复跨页断裂句及原文图c标记。')
add(rr(129,2),rr(65,2,3))
add(rr(129,3),rr(65,4,6),end='如果关于生命',fixes=[('封闭系统论点','封闭系统的论点')])
add(rr(129,4),rr(65,6,7),'quote',start='如果关于生命')
add(rr(129,5),rr(65,8))
add(rr(129,6),rr(65,9,10),end='关于热传导')
add(rr(129,7),rr(65,10,15),'quote',start='关于热传导',fixes=[('不透热清漆','不透热的漆层'),('能量散逸','能量耗散')],reason='统一dissipation术语为耗散。')
nt={123:'Thomson：“能量耗散的动力学理论”。',124:'Thomson：“能量耗散的动力学理论”。'}
notes=[]
for n,refs in note_groups(rr(258,1)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch05-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['249'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch05zc',5,rows,notes,rr(128,6)+rr(129,1,7))
(W/'checkpoint_ch05zc.json').write_text(json.dumps({'next_source_pdf_page':129,'next_source_block':8,'next_supplied_pdf_page':65,'next_supplied_block':16,'next_unit':len(rows)+341,'next_note':125,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
