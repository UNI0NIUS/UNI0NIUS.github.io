from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch10-{len(rows)+85:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(221,1),rr(116,0,2),text='能力最强的0型文法能够涵盖任何图灵完备计算。不过，它们不用于实际计算，因为通过界定符号序列的上下文来思考问题实在很困难；这些上下文可以任意庞大而复杂。人们转而使用编程语言：它们在严谨性上像形式系统，在表达力上像自然语言。')
add(rr(221,2),rr(116,3,6),text='使用编程语言，就要依据它所支持的抽象来思考，尤其要考虑变量能够表示哪类东西。在心理层面，这略去了计算的物理根基：计算在物理计算机中进行，操作符号编码的物理实例。因此，最终决定什么能够计算的，是现实的物理性质。对于涉及任意小的构造（如实数）或任意大的构造（如可无止境增长的数据库）的计算，这一点尤其重要。')
add(rr(221,3),rr(116,7,9),text='如果现实有限，我们最终就会耗尽可用于计算的物质。我们或许以为自己在一种拥有潜在无限资源的0型语言中编程，但实际上内存有界。而且，即使现实无限，谈论在有限时间内动用无限资源的有限计算，也没有意义。[[16]]')
add(rr(221,4),rr(116,10),'heading',text='结论')
add(rr(221,5),rr(116,11,14),text='我们对形式逻辑发展的叙述支撑着我们的唯物主义。与图灵一样，我们把数学视为植根于物理机器的机械活动；与巴迪欧一样，我们把建模与逻辑视为相互补充的实验活动；与维特根斯坦一样，我们认为意义产生于改变现实的互动；与马尔可夫一样，我们用建模为自动机的算法过程来刻画意义。')
add(rr(221,6),rr(116,15,17),text='依据丘奇—图灵论题，我们的唯物主义是还原论的。如果可计算性是理解现实的关键，而各种说明都能被证明具有等价的解释力，那么如何选择便是实用问题，而非原则问题。具体说来，我们拒绝柏拉图主义赋予纯数学的首要地位，却承认它在抽象方面的力量。')
add(rr(221,7),rr(116,18,19),text='我们的唯物主义根本上是科学的。我们拒绝黑格尔和马克思主义传统赋予辩证法的首要地位，但承认它在探究现实过程中揭示和解决矛盾的力量。')
add(rr(221,8),rr(116,20),text='我们的唯物主义也是有限主义的。与构造主义者一样，我们拒绝以实无限为基础的论证。',reason='统一有限主义、构造主义和实无限。')
notes=[]
for n,refs in note_groups(rr(270,1)):
    if n!=16:continue
    notes.append({'id':'dm-ch10-note-16','kind':'note','note_number':16,'source_blocks':refs,'printed_pages':['261'],'en':extract(EN,refs,True),'zh':'16. Cockshott、Mackenzie、Michaelson：《计算及其限度》。','status':'text_compared_layout_pending'})
save('ch10e',10,rows,notes,rr(221,1,8))
(W/'checkpoint_ch10e.json').write_text(json.dumps({'next_source_pdf_page':222,'next_source_block':0,'next_supplied_pdf_page':116,'next_supplied_block':21,'next_chapter':11,'next_note':1,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
