from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch05-{len(rows)+285:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(119,6)+rr(120,1),rr(60,20,24),fixes=[('仍基于“热量”（caloric）作为独立实体观念下进行','仍以热是一种称为“热质”（caloric）的独立实体这一观念为基础')],reason='caloric统一热质，修正旧译句法。')
add(rr(120,2),rr(60,25,27),end='如果蒸汽机',fixes=[('关键概念工具。','关键概念工具。[[105]]'),('出于工程效率必要性','出于提高工程效率的需要')],reason='补回漏注105。')
add(rr(120,3),rr(60,26,28),'quote',start='如果蒸汽机',fixes=[('热论的成就','热所取得的成就'),('[[10]] [[6]]','[[106]]')],reason='achievements of Heat指热通过蒸汽机完成的工作，不是热理论的成就。')
add(rr(120,4),rr(60,29,33),fixes=[('热仅存在于热体中较小粒子中','热仅在热体的较小粒子中发生膨胀'),('[[10]][[7]]','[[107]]')],reason='expanded被旧译漏译为存在，导致下一句“这种膨胀”失去对应。')
add(rr(120,5),rr(60,34))
add(rr(120,6),rr(60,35)+rr(61,0),end='当气体')
add(rr(120,7),rr(61,0,1),start='当气体',end='摩擦被')
add(rr(120,8),rr(61,1,2),start='摩擦被')
add(rr(120,9),rr(61,3,4))
add(rr(120,10),rr(61,5,6),end='最近，',fixes=[('鲁姆福德','伦福德'),('在炮管钻孔过程中实验','在镗削炮管时的经历'),('炮管在钻孔时','炮管在镗孔时')],reason='Rumford统一伦福德；boring是镗孔，experience是经历。')
add(rr(121,1),rr(61,6,8),'quote',start='最近，',fixes=[('大炮钻孔','大炮镗孔'),('在钻孔过程中','在镗孔过程中'),('钻头','镗刀')])
add(rr(121,2),rr(61,9,11),'quote',fixes=[('[[10]] [[8]]','[[108]]')])
add(rr(121,3),rr(61,12,15),end='上述机械操作',fixes=[('“无中生有”','“无中不能生有”'),('被铣削的大炮','被镗削的大炮'),('被铣床铣成粉末','被镗床磨成粉末'),('拉姆福德','伦福德')],reason='nothing from nothing被旧译为无中生有，否定意义完全反转；统一人名及机械加工术语。')
nt={105:'参见P. Cockshott等：《经典经济物理学：古典政治经济学、热力学与信息论论文集》（Classical Econophysics: Essays on Classical Political Economy, Thermodynamics and Information Theory）（Routledge，2008）的前几章。',106:'John Tyndall：《热作为运动的一种形式》（Heat Considered as a Mode of Motion）（D. Appleton/Company，1875），第xiii页。',107:'Tyndall：《热作为运动的一种形式》，第xiii页。',108:'Benjamin Count Rumford：“关于摩擦所激发的热的来源的研究，伦福德伯爵本杰明著，Frsmria”（An Inquiry Concerning the Source of the Heat Which is Excited by Friction. by Benjamin Count of Rumford, Frsmria），Philosophical Transactions of the Royal Society of London（1798），第80—102页。'}
notes=[]
for n,refs in note_groups(rr(257,1)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch05-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['248'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch05w',5,rows,notes,rr(119,6)+rr(120,1,10)+rr(121,1,3))
(W/'checkpoint_ch05w.json').write_text(json.dumps({'next_source_pdf_page':121,'next_source_block':4,'next_supplied_pdf_page':61,'next_supplied_block':15,'next_unit':len(rows)+285,'next_note':109,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
