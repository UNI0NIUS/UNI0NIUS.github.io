from materialism_common import *
groups=[]
for b in EN[278]['blocks'][1:]:
    for j,l in enumerate(b['lines']):
        if l['bbox'][0]<60:groups.append([])
        groups[-1].append([279,b['block'],j,j+1])
oldrefs=[rr(162,10),rr(162,11,12),rr(162,13,15),rr(162,16,17),rr(162,18,19),rr(162,20,21),rr(162,22,23),rr(162,24,25),rr(162,26),rr(162,27)+rr(163,0),rr(163,1,2),rr(163,3,4),rr(163,5),rr(163,6),rr(163,7,8),rr(163,9,10),rr(163,11),rr(163,12,13),rr(163,14),rr(163,15,18),rr(163,19,20),rr(163,21,22)]
translations=[
'Georg Hegel：《逻辑学》。G. Di Giovanni译。Cambridge University Press，2010。',
'Georg Wilhelm Fredrich Hegel：《格奥尔格·威廉·弗里德里希·黑格尔：逻辑学》。A. V. Miller译。Oxford University Press，1977。',
'Georg Wilhelm Friedrich Hegel：“关于行星轨道的哲学博士论文（1801），附1801年8月27日答辩的十二条论题”。Graduate Faculty Philosophy Journal 12，第1/2期（1987）：269—309。',
'Werner Heisenberg：“量子理论解释的发展”。Niels Bohr and the Development of Physics（1955）：12。',
'大卫·希尔伯特：“公理化思维”。载《从康德到希尔伯特：数学基础文献集》第2卷，W. Ewald编，1106—1115。Oxford University Press，1996。',
'大卫·希尔伯特：“论逻辑与算术的基础”。载《从弗雷格到哥德尔：数理逻辑文献集，1879—1931》，J. van Heijenoort编，129—138。Harvard University Press，1967。',
'大卫·希尔伯特：“初等数论的奠基”。载《从康德到希尔伯特：数学基础文献集》第2卷，W. Ewald编，1148—1157。Oxford University Press，1996。',
'托马斯·霍布斯：“论物体”。载《托马斯·霍布斯英文著作集》，W. Molesworth编。John Bohn，1839。',
'Andrew Hodges：《艾伦·图灵：谜》。Touchstone，1983。',
'Peter R. Holland：《运动的量子理论：德布罗意—玻姆量子力学因果解释述论》。Cambridge University Press，1995。',
'John E. Hopcroft、- Jeffrey E. Ullman：《形式语言及其与自动机的关系》。Addison-Wesley，1969。',
'Don Howard：“谁发明了‘哥本哈根解释’？一项神话研究”。Philosophy of Science 71，第5期（2004）：669—682。',
'Intel：《Intel64与IA-32架构软件开发者手册》。第2B卷。Intel，2021。',
'William S. Jevons：《逻辑学初级教程》。Macmillan & Co.，1903。',
'Ibn Khaldun、Franz Rosenthal、Nessim Joseph Dawood：《穆卡迪马：历史导论；三卷本》。1，43。Princeton University Press，1969。',
'Dimitris Kilakos：“索菲娅·A. 雅诺夫斯卡娅：苏联数理逻辑的马克思主义先驱”。International Journal of the Historiography of Science 6（2019）：49—64。',
'Stephen C. Kleene：《元数学导论》。North-Holland，1952。',
'Stephen C. Kleene：“自然数的一般递归函数”。Mathematische Annalen 112（1936）：727—742。',
'Stephen C. Kleene：“$\lambda$可定义性与递归性”。Duke Mathematical Journal 2，第2期（1936）：340—353。',
'Ernst Kolman：“数学科学当前的危机及其重建的总体纲要”。载《十字路口的科学：苏联代表在1931年6月29日至7月3日伦敦国际科学技术史大会上提交的论文》。Frank Cass / Co.，1931。https://www.marxists.org/subject/science/essays/colman3.htm。',
'Ernst Kolman、Sofya Yanovskaya：“黑格尔与数学”。Under the Banner of Marxism，1931。https://www.marxists.org/reference/subject/philosophy/works/ru/kolman.htm。',
'Andrey Kolmogorov：“论直觉主义逻辑的解释”。载《从布劳威尔到希尔伯特：20世纪20年代关于数学基础的论争》，P. Mancosu编，328—334。Oxford University Press，1998。'
]
assert len(groups)==len(oldrefs)==len(translations)==22
rows=[]
for i,(refs,zrefs,zh) in enumerate(zip(groups,oldrefs,translations),135):
    raw=extract(EN,refs,True);en=raw.replace('\u200b','').replace('marxists .org','marxists.org').replace('science/ essays','science/essays').replace('ru/ kolman','ru/kolman').replace('λ',r'$\lambda$')
    row={'id':f'dm-ref-{i:03}','kind':'bibliography','source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['270'],'en':en,'zh':zh,'supplied_zh':extract(ZH,zrefs),'status':'text_compared_layout_pending','revision_reason':'逐条核对完整书目信息并补译题名，源书异常与旧稿改动分别记录。'}
    if en!=raw:row['source_transcription_note']='URL移除排版换行空格/零宽字符；λ转LaTeX数学符号以保证字形。原始span保留。'
    if i==145:row['editor_note']='原书在Jeffrey E. Ullman姓名前印有短横线，此处保留；现成稿省去了该符号。'
    if i==149:row['editor_note']='原书题名后列作“1, 43”，现成稿仅保留第1卷；此处不省略43，也不擅自解释其含义。'
    rows.append(row)
save('refs07',12,rows,[],rr(279,1,19))
(W/'checkpoint_refs07.json').write_text(json.dumps({'next_source_pdf_page':280,'next_source_block':1,'next_supplied_pdf_page':163,'next_supplied_block':23,'next_reference':157,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
