from materialism_common import *
groups=[]
for b in EN[275]['blocks'][1:]:
    for j,l in enumerate(b['lines']):
        if l['bbox'][0]<62:groups.append([])
        groups[-1].append([276,b['block'],j,j+1])
oldrefs=[rr(157,25,26),rr(157,27,28),rr(158,0,3),rr(158,4),rr(158,5,6),rr(158,7),rr(158,8,9),rr(158,10),rr(158,11),rr(158,12),rr(158,13),rr(158,14,15),rr(158,16,17),rr(158,18,20),rr(158,21),rr(158,22,24),rr(158,25),rr(158,26,27)+rr(159,0),rr(159,1,2),rr(159,3,4),rr(159,5,6),rr(159,7),rr(159,8)]
translations=[
'Allin Cottrell、Paul Cockshott：“人口与利润率下降”。Indian Development Review 4，第1期（2006）：39—59。',
'Allin Cottrell、Paul Cockshott、Gregory John Michaelson、Ian P Wright、Victor Yakovenko：《经典经济物理学》。Routledge，2009。',
'Charles Augustin Coulomb：“关于扭转力与金属丝弹性的理论和实验研究：该理论在工艺中使用金属及各种物理实验中的应用；测量极微小力的各种扭秤的构造；关于弹性与内聚力规律的观察”。1784。',
'苏联共产党（布）中央委员会（CPSU(B) CC）：“中学中的逻辑学与心理学”。Soviet Studies 3，第3期（1952）：342—344。',
'Haskell Curry：《组合逻辑基础》（Grundlagen Der Kombinatorischen Logik）。F. Kamaraddine、J. Seldin译。College Publications，2017。',
'约翰·道尔顿：《化学哲学新体系》。第1卷。Bickerstaff，1808。',
'约翰·道尔顿：“III. 论水及其他液体对气体的吸收”。The Philosophical Magazine 24，第93期（1806）：15—24。',
'查尔斯·达尔文：《物种起源》。Project Gutenberg EBook，2009。',
'查尔斯·达尔文：《人类的由来与性之关系》。Murray，1871。',
'查尔斯·达尔文：《人和动物的表情》。Project Gutenberg EBook，1998。',
'路易·德布罗意：“波与量子”。Nature 112，第2815期（1923）：540。',
'费尔迪南·德·索绪尔：“普通语言学教程”。载《普通语言学教程》，C. Bally、A. Sechehaye编，W. Baskin译。The Philosophical Society，1959。',
'Adrian Desmond、James Moore：《达尔文的神圣事业：对奴隶制的憎恶如何塑造了达尔文的人类演化观》。HMH，2014。',
'David Deutch：“量子理论、丘奇—图灵原理与通用量子计算机”。Proceedings of the Royal Society: A, Mathematical, Physiscal and Engineering Sciences 400，第1818期（1985）：97—117。',
'David Deutch：《实在的结构》。Penguin，2011。',
'David Deutsch：“实验检验的逻辑，特别是埃弗里特量子理论的实验检验”。Studies in History and Philosophy of Science Part B: Studies in History and Philosophy of Modern Physics 55（2016）：24—33。',
'德尼·狄德罗等：《达朗贝尔与狄德罗的谈话》。Garnier-Flammarion，1965。',
'约瑟夫·狄慈根：《一个社会主义者在认识论领域的漫游》。M. Beer、T. Rothstein译。Social-Democratic Library，Hottingen-Zurich，1887。https://www.marxists.org/archive/dietzgen/1887/epistemology.htm。',
'约瑟夫·狄慈根：《逻辑书简，特别是民主的无产阶级逻辑》。E. Untermann译。Charles H. Kerr / Co，Chicago，1906。https://www.marxists.org/archive/dietzgen/1870s/letters-on-logic.htm。',
'约瑟夫·狄慈根：《哲学的积极成果》。E. Untermann译。Charles H. Kerr / Co，Chicago，1906。https://www.marxists.org/archive/dietzgen/1887/positive-outcome/index.htm。',
'Bradley Dowden：“芝诺悖论”。Internet Encyclopedia of Philosophy。https://iep.utm.edu/zenos-paradoxes/。',
'埃米莉·杜·夏特莱：《哲学与科学著作选》。University of Chicago Press，2009。',
'George Dyson：《图灵的大教堂：数字宇宙的起源》。Penguin，2012。'
]
assert len(groups)==len(oldrefs)==len(translations)==23
rows=[]
for i,(refs,zrefs,zh) in enumerate(zip(groups,oldrefs,translations),64):
    raw=extract(EN,refs,True);en=raw.replace('\u200b','')
    for a,b in [('https:// www','https://www'),('org/ archive','org/archive'),('archive/ dietzgen','archive/dietzgen'),('letters-on- logic','letters-on-logic'),('index. htm','index.htm'),('utm .edu','utm.edu'),('zenos- paradoxes','zenos-paradoxes')]:en=en.replace(a,b)
    row={'id':f'dm-ref-{i:03}','kind':'bibliography','source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['267'],'en':en,'zh':zh,'supplied_zh':extract(ZH,zrefs),'status':'text_compared_layout_pending','revision_reason':'核对完整书目并补译题名，保留原书作者/出版社拼写与日期。'}
    if en!=raw:row['source_transcription_note']='去掉URL中的零宽字符及排版换行空格，原始span保留；未验证网络可达性。'
    if i==77:row['editor_note']='原书作者姓拼作Deutch，期刊名称拼作Physiscal，现成稿改作Deutsch、Physical；此处按原书保留。'
    if i==78:row['editor_note']='原书此条作者姓拼作Deutch，下一条拼作Deutsch；分别照录。'
    rows.append(row)
save('refs04',12,rows,[],rr(276,1,17))
(W/'checkpoint_refs04.json').write_text(json.dumps({'next_source_pdf_page':277,'next_source_block':1,'next_supplied_pdf_page':159,'next_supplied_block':9,'next_reference':87,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
