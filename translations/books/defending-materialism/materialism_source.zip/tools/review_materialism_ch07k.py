from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch07-{len(rows)+162:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(175,1),rr(90,20,21))
rows[-1]['editor_note']='底本称无限集的基数不能是序数，照译；在通常集合论中基数可用初始序数表示，原文论述不应当作这一点的否定证明。'
add(rr(175,2),rr(90,22,23),fixes=[('连续的元素','相继的成员'),('具体化的描述','物质化的描述')])
add(rr(175,3),rr(90,24,25),fixes=[('数字的无限集合','数的无限集合'),('具象化系统','物质化系统')])
add(rr(175,4),rr(90,26,27))
eq=[f'{j}\\leftrightarrow {2*j}' for j in range(1,6)]
add(rr(175,5),rr(91,0,4),text='；'.join('$'+x+'$' for x in eq),english='; '.join('$'+x+'$' for x in eq),reason='据原图恢复五行一一对应。');rows[-1]['math_lines']=eq
add(rr(175,6),rr(91,5,7))
add(rr(175,7),rr(91,8,9),fixes=[('整数的连续比值','相继的整数比值')])
add(rr(175,8),rr(91,10,11),text=r'为了比较无限集合的性质，康托尔使用希伯来字母$\aleph$（aleph），配上相继的下标，以超限数表示这些集合的基数。因此，整数集的基数为$\aleph_0$（aleph零），所有可数集也是如此。',english=r'In order to compare properties of infinite sets, Cantor used the Hebrew symbol $\aleph$ (aleph) with successive subscripts to denote their cardinalities as transfinite numbers. Thus, the set of integers has cardinality $\aleph_0$ (aleph nought), as do all countable sets.')
rows[-1]['editor_note']='“所有可数集”均为ℵ₀是底本原述；通常术语下有限集也可数，此处实际讨论可数无限集。'
add(rr(175,9,10),rr(91,12,15),text=r'然而，康托尔借助对角线论证，试图证明实数不可枚举，因而不可数。首先，实数不能表示为两个整数之比，因此必定有无限多个小数位。每一个小数位都可以与整数一一对应，所以可用序数为其编号。假设我们能枚举实数，第i个实数$d^i$的各位数字便是$d^i_1,d^i_2,d^i_3$，依此类推，如表7.4所示。',english=r'However, using a diagonal argument, Cantor sought to demonstrate that the real numbers are not enumerable and, hence, not countable. First of all, a real number can’t be expressed as a ratio of two integers, so it must have an infinity of decimal digits. Each of those decimal digits can be put into one-to-one correspondence with the integers, so we can index them with ordinal numbers. Suppose we could enumerate the real numbers, so the digits of the ith real number $d^i$ were $d^i_1,d^i_2,d^i_3$ and so on, as in Table 7.4.',reason='依原图恢复上下标次序，旧译实数索引与位索引倒置。')
rows[-1]['editor_note']='这里再次沿用底本把实数与无理数混同的说法，未静默更改。'
add(rr(175,11,13)+rr(176,1,2),rr(91,16,19),text=r'可以构造一个新的实数$0.n^1n^2n^3n^4\ldots$，使其第一位$n^1$不同于第一个实数的第一位$d^1_1$，第二位$n^2$不同于第二个实数的第二位$d^2_2$，第三位$n^3$不同于第三个实数的第三位$d^3_3$，依此类推。这个新实数不可能在所枚举的序列中，所以实数必定多于$\aleph_0$，因而不可枚举。',english=r'We can make a new real number $0.n^1n^2n^3n^4\ldots$ where the first digit $n^1$ is different from the first digit of the first real $d^1_1$, the second digit $n^2$ is different from the second digit of the second real $d^2_2$, the third digit $n^3$ is different from the third digit of the third real $d^3_3$ and so on. This new real can’t be in the enumerated sequence, so there must be more real numbers than $\aleph_0$, so the reals are not enumerable.',reason='据原图恢复幂形索引，提取的[[1]]为指数非注号。')
add(rr(176,6,27),rr(91,20,25),'table',text='表7.4 对角线法',english=extract(EN,rr(176,6),True),reason='恢复原表四行及省略行；上下标据原图。')
tab=[]
for i in range(1,5):tab.append([str(i)+'.','0.']+[f'$d^{i}_{(4 if i==3 and j==3 else j)}$' for j in range(1,5)]+['…'])
tab.append(['…','','','','','',''])
rows[-1]['table']={'headers_en':['','','','','','',''],'headers_zh':['','','','','','',''],'rows_en':tab,'rows_zh':tab}
rows[-1]['editor_note']='底本第三行第三个数字位置印为d³₄，与第四个数字重复，按原图保留；对角线论证正文仍为d³₃。'
save('ch07k',7,rows,[],rr(175,1,13)+rr(176,1,2)+rr(176,6,27))
(W/'checkpoint_ch07k.json').write_text(json.dumps({'next_source_pdf_page':176,'next_source_block':3,'next_supplied_pdf_page':91,'next_supplied_block':26,'next_unit':len(rows)+162,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
