from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch07-{len(rows)+87:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(168,1),rr(85,24,26),text='法国是三段论推理的一个中心，巴黎大学尤其如此。17世纪中叶，曾就读索邦大学的阿尔诺和尼科尔发展了《波尔—罗亚尔逻辑》。[[18]]他们虽是神职人员，却信奉与主流天主教存在教义冲突的詹森主义，并深受笛卡尔影响。',reason='保留发展而非增译创立；标题译名统一。')
# Original marker follows the title, before the authors are named.
rows[-1]['zh']='法国是三段论推理的一个中心，巴黎大学尤其如此。17世纪中叶，《波尔—罗亚尔逻辑》[[18]]由曾就读索邦大学的阿尔诺和尼科尔发展而来。他们虽是神职人员，却信奉与主流天主教存在教义冲突的詹森主义，并深受笛卡尔影响。'
add(rr(168,2),rr(85,27,29),fixes=[('波尔·罗亚尔','波尔—罗亚尔'),('直至19 世纪中叶','一直延续到19世纪相当长的一段时期')],reason='well into nineteenth century没有指定中叶，不擅加日期。')
en=extract(EN,rr(168,3),True).replace('Organon,19,20','Organon,[[19]],[[20]]')
add(rr(168,3),rr(85,30,33)+rr(86,0,1),english=en,fixes=[('完全排除了三段论','完全否定了形式三段论'),('而非理性本身','而非推理的工具')],reason='formal限定及reason与persuasion对照恢复；规范原注19/20。')
add(rr(168,4),rr(86,2,5),fixes=[('《论身体》','《论物体》')],reason='De Corpore为论物体，非论身体。')
add(rr(168,5),rr(86,6,8))
add(rr(168,6),rr(86,9),'heading')
add(rr(168,7),rr(86,10,12),fixes=[('《思维定律》','《思维规律》')])
add(rr(168,8),rr(86,13))
for j,t in enumerate(['1. 同一律。凡是存在的，就是存在的。','2. 矛盾律。任何事物不可能既存在又不存在。','3. 排中律。任何事物必定或者存在，或者不存在。（第117页）']):add([[168,9,j,j+1]],rr(86,14+j),'list_item',text=t,reason='按原文存在/不存在对称表述排中律，非泛化的非此即彼。')
add(rr(169,1),rr(86,17,20))
add(rr(169,2),rr(86,21))
nt={18:'J. Buroker：“波尔—罗亚尔逻辑”（Port Royal Logic），载Stanford Encyclopedia of Philosophy（University of Stanford，2014），https://plato.stanford.edu/entries/port-royal-logic/ 。',19:'F. Bacon：《新工具》（Novum Organon），J. Devey编（P. F. Collier & Son，1901）。',20:'这一标题呼应亚里士多德的《工具论》（Organon）。',21:'T. Hobbes：“论物体”（De Corpore），载《托马斯·霍布斯英文著作集》（The English Works of Thomas Hobbes），W. Molesworth编（John Bohn，1839）。',22:'R. Whately：《逻辑要素》（Elements of Logic）（James Munroe & Company，1845）。',23:'Boole：《思维规律研究》（An Investigation into the Laws of Thought）。',24:'W. S. Jevons：《逻辑学初级教程》（Elementary Lessons in Logic）（Macmillan & Co.，1903）。',25:'不要与爱尔兰数学家William Rowan Hamilton混淆。',26:'W. Hamilton：《形而上学与逻辑讲义》（Lectures on Metaphysics and Logic），第1卷，H. L. Mansel与J. Veitch编（William Blackwood and Sons，1866）。'}
notes=[]
for n,refs in note_groups(rr(264,1)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch07-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['255'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch07f',7,rows,notes,rr(168,1,9)+rr(169,1,2))
(W/'checkpoint_ch07f.json').write_text(json.dumps({'next_source_pdf_page':169,'next_source_block':3,'next_supplied_pdf_page':86,'next_supplied_block':22,'next_unit':len(rows)+87,'next_note':27,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
