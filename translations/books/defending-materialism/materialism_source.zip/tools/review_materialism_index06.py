from materialism_common import *

groups=[]
for b in EN[290]['blocks'][1:]:
    for j,l in enumerate(b['lines']):
        x=l['bbox'][0]
        if x<80 or 225<x<250:groups.append([])
        groups[-1].append([291,b['block'],j,j+1])
def one(p,a,z):return [[[p,b]] for b in range(a,z+1)]
oldrefs=one(181,8,25)+one(181,27,43)+one(182,0,1)+one(182,3,33)+[rr(182,34,35)]+one(182,36,43)+one(183,0,0)
assert len(groups)==len(oldrefs),(len(groups),len(oldrefs))
fixes={
 'A New System of Chemical Philosophy (Dalton)':('《化学哲学新体系》','《化学哲学新体系》（道尔顿）'),
 '‘nothing comes from nothing’ principle':('“无中不能生有”','“无中不能生有”原则'),
 'Novum Organon (Bacon)':('《新工具》','《新工具》（培根）'),
 'On Contradiction (Mao)':('《论矛盾》','《矛盾论》（毛泽东）'),
 'On Generation and Corruption (325b12-325b33) (Aristotle)':('《论生成与毁灭》','《论生成与毁灭》（325b12—325b33，亚里士多德）'),
 'On Interpretation (Aristotle)':('《论解释》','《解释篇》（亚里士多德）'),
 'On the Equilibrium of Planes (Archimedes)':('《论平面的平衡》','《论平面的平衡》（阿基米德）'),
 'On the Interpretation of Intuitionist Logic (Kolmogorov)':('《论直觉主义逻辑的解释》','《论直觉主义逻辑的解释》（科尔莫戈罗夫）'),
 'On the principle of the excluded middle (Kolmogorov)':('《论排中律》','《论排中律》（科尔莫戈罗夫）'),
 'The Open Secret of the Real Abstraction (Toscano)':('《现实抽象的公开秘密》','《现实抽象的公开秘密》（托斯卡诺）'),
 'The Organon (Prior Analytics) (Aristotle)':('《工具论》（《前分析篇》）','《工具论》（《前分析篇》，亚里士多德）'),
 'Philosophical Investigations (Wittgenstein)':('《哲学研究》','《哲学研究》（维特根斯坦）'),
 'Philosophy and Non-Philosophy (Laruelle)':('《哲学与非哲学》','《哲学与非哲学》（拉鲁埃尔）'),
 'physikē':('自然','自然学'),
 'The Positive Outcome of Philosophy (Dietzgen)':('《哲学的积极成果》','《哲学的积极成果》（狄慈根）'),
 'The Present Crisis in the Mathematical Sciences and General Outlines for Their Reconstruction (Kolman)':('重建的总体纲要》','重建的总体纲要》（科尔曼）'),
 'Principia Mathenmatica (Russell and Whiteheads)':('《数学原理》','《数学原理》（罗素和怀特海）'),
 'principle of contradiction':('矛盾原理','矛盾律'),
}
rows=[];parents={}
for i,(refs,zrefs) in enumerate(zip(groups,oldrefs),393):
    en=extract(EN,refs,True);old=extract(ZH,zrefs);zh=old
    m=re.search(r'\s+(\d[\d, ––-]*)$',en);assert m,en
    term=en[:m.start()].strip();locator=m[1]
    oldloc=re.search(r'(\d[\d, ––-]*)$',old);assert oldloc,old
    assert re.sub(r'\s','',oldloc[1])==re.sub(r'\s','',locator),(en,old)
    if term in fixes:
        a,b=fixes[term];assert a in zh,(term,zh);zh=zh.replace(a,b)
    row={'id':f'dm-index-{i:03}','kind':'index_entry','source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['282'],'en':en,'zh':zh,'supplied_zh':old,'index_term':term,'index_locators':locator,'index_level':0,'status':'text_compared_layout_pending'}
    if term in ['Newton','Peano, Giuseppe']:parents[term]=row['id']
    if term in ['atomic motion','calculus','laws','mechanics']:
        row['index_level']=1;row['index_parent']=parents['Newton']
    if term=='arithmetic':row['index_level']=1;row['index_parent']=parents['Peano, Giuseppe']
    if zh!=old:row['revision_reason']='补回作者及文本位置括注、修正术语，逐项核对页码并恢复子项层级。'
    if term=='Principia Mathenmatica (Russell and Whiteheads)':row['editor_note']='Mathenmatica与Whiteheads为原索引拼写，英文栏保留原样。'
    rows.append(row)
save('index06',13,rows,[],rr(291,1,19))
(W/'checkpoint_index06.json').write_text(json.dumps({'next_source_pdf_page':292,'next_supplied_pdf_page':183,'next_supplied_block':1,'next_index_entry':393+len(rows),'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
