from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch09-{len(rows)+21:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(197,10)+rr(198,1),rr(103,9,10),text='在假定可以写出一个函数来判断公式是否为定理的前提下，哥德尔利用自指构造了一个令人想到罗素悖论的悖论。他展示了如何构造一个公式，设其哥德尔数为N，它实际上说：')
add(rr(198,2),rr(103,10,11),'quote',text='哥德尔数为N的公式不是定理。')
add(rr(198,3),rr(103,12,14),text='现在，如果这个公式是定理，它所断言的便是真的，因此它不可能是定理。而如果它不是定理，它所断言的便是假的，因此它必须是定理。也就是说，假定存在一个函数能够检查公式是否为定理，就会使系统不相容；去掉这一假定，则使系统不完备。',reason='保留底本论证不擅自改成另一个证明；相容性术语统一。')
rows[-1]['editor_note']='底本第二个条件句把“不是定理”直接推为“所断言的为假”，但前一引文恰说该公式不是定理。此处按原文保留这一推论，不能把这段概述视为严格证明。'
add(rr(198,4),rr(103,15,18),text='接受排中律（LEM）的逻辑学家一致认为，宁取相容性而非完备性，是最稳妥的做法。对于不完备的系统，会有一些公式，我们无法保证判定它们是否为定理。如果简单地将它们加入系统作为公理，就可能利用它们证明矛盾。然而，对于相容的系统，一旦证明一个公式是定理，就知道无法证明它的否定。',reason='contrary此处译否定而非容易混同逆命题的反命题。')
add(rr(198,5),rr(103,19),'heading',text='图灵与终止性')
add(rr(198,6),rr(103,20,21),text='五年后，艾伦·图灵（1912—1954）证明，希尔伯特纲领的第三项要求无法得到满足。[[3]]也就是说，不可能构造一种会终止的机械程序，来判定一个公式是否为定理。')
add(rr(198,7),rr(103,22,24),text='图灵的进路与上文讨论的数理逻辑学家很不一样。他没有使用诸如把谓词演算应用于集合论或数论而得到的形式系统，而是考察人们怎样用手工解决问题。他设想，一个人用铅笔和方格纸，在格子里逐个字母写下问题，然后来回处理，修改已有格子的内容，并写入新的格子。',reason='changing squares指改写格中内容，不是更换方格；统一数理逻辑。')
add(rr(198,8),rr(103,25,27),text='图灵把这一构想推广为现在所谓的图灵机（TM）。图灵机有一条由单元格组成的有限线性纸带，每个格子可以存放一个符号。有一个读写头，能够检查和修改格子；它位于“当前”格子的上方。例如，图9.1描绘了一台示意性的图灵机，纸带上逐个符号写着肯定前件式。',reason='抽象机器的tape译纸带，不限定为磁带；head能读写，译读写头。')
add(rr(198,9),rr(103,28,29),text='纸带可以向左或向右移动，每次移动一格。到达纸带任一端时，便添加新的空格。因此，纸带可以增长到任意长度，但在任何阶段，它总是有界的，即长度始终有限。')
add(rr(198,10),rr(103,30,31),text='图灵机通过反复检查和修改纸带来执行操作，每次处理一个格子。机器的行为倾向，即当前符号如何结合它此前的操作来决定下一步做什么，称为当前状态。')
notes=[]
for n,refs in note_groups(rr(267,3)):
    if n!=3:continue
    notes.append({'id':'dm-ch09-note-3','kind':'note','note_number':3,'source_blocks':refs,'printed_pages':['258'],'en':extract(EN,refs,True),'zh':'3. A. M. Turing：“论可计算数及其在判定问题上的应用”，Proceedings of the London Mathematical Society s2–42，第1期（1937）：230—265。','status':'text_compared_layout_pending'})
save('ch09b',9,rows,notes,rr(197,10)+rr(198,1,10))
(W/'checkpoint_ch09b.json').write_text(json.dumps({'next_source_pdf_page':199,'next_source_block':1,'next_supplied_pdf_page':103,'next_supplied_block':32,'next_unit':len(rows)+21,'next_note':4,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
