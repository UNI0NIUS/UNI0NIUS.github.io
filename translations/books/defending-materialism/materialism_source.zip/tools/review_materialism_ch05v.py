from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch05-{len(rows)+276:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(118,4),rr(60,0,3),fixes=[('[[10]] [[4]]','[[104]]')])
add(rr(118,5),rr(60,4,6),fixes=[('由基本粒子组成原子核','由基本粒子组成的核心')],reason='此处为道尔顿复合粒子的核心，避免与前句现代原子核直接等同。')
add(rr(118,6),rr(60,7))
add(rr(118,7,8),rr(60,8,9),'list_item')
add(rr(118,9,16),[],'table',text='表5.1 道尔顿对相对分子量的估算与今知数值的比较',english=extract(EN,rr(118,9),True),reason='恢复中文底稿遗漏的完整原表；各数值按源图照录。')
data=[[r'$\mathrm{H_2}$','Hydrogen','2.01594','1','1'],[r'$\mathrm{N_2}$','Azote','28.0134','13.89595','5'],[r'$\mathrm{O_2}$','Oxygen','31.9988','15.87289','7'],[r'$\mathrm{N_2O}$','Nitrous oxide','46.0055','22.82087','17'],[r'$\mathrm{NO}$','Nitrous gas','30.0061','14.88442','12'],[r'$\mathrm{CO_2}$','Carbonic acid','44.0098','21.83091','19'],[r'$\mathrm{NH_3}$','Amoniacal gas','17.03061','8.447975','6']]
rows[-1]['table']={'headers_en':['','Dalton’s name','Actual molecular weight','Ratio to hydrogen molecule','Dalton’s estimate'],'headers_zh':['','道尔顿的名称','实际分子量','与氢分子的比值','道尔顿估值'],'rows_en':data,'rows_zh':[[r[0],z]+r[2:] for r,z in zip(data,['氢','氮（Azote）','氧','一氧化二氮','亚硝气','碳酸气','氨气'])]}
rows[-1]['editor_note']='底本N₂O行的实际分子量印为46.0055，相对氢分子的比值为22.82087；两项与该行化学式之间存在疑点，此处逐项照录，未以推算值替换。Amoniacal亦为底本拼写。'
add(rr(119,8),[],'figure',text=r'图5.2 道尔顿表示元素原子的符号：[1]氢，[2]Azote（氮），[3]碳，[4]氧，[5]磷，[6]硫，[7]苦土（Magnesia），[8]石灰（钙）；以及若干化合物：[21]水，[22]氨，[23]一氧化二氮，[24]成油气（乙烯$\mathrm{C_2H_2}$），[25]碳氧化物（一氧化碳）。注意，他尚未认识到气态氢为$\mathrm{H_2}$，因此水等物质的组成显得古怪。取自John Dalton的《化学哲学新体系》。',english=extract(EN,rr(119,8),True).replace('C2H2',r'$\mathrm{C_2H_2}$').replace('H2,',r'$\mathrm{H_2}$,'),reason='恢复中文底稿遗漏的原图与完整图注，化学式按源图转写。')
rows[-1].update(image='assets/figure-5-2.png',source_image={'pdf_page':119,'block':7,'xref':701},image_labels_zh='ELEMENTS：元素；Simple：简单的；Binary：二元的；Plate 4：图版4。各编号对应图注中的原子及化合物。',editor_note='底本将Ethylene（乙烯）的化学式印作C₂H₂，此处保留原书式并提示，未静默改动；图中历史元素分类及图注Magnesia/Lime也按底本保留。')
add(rr(119,1,3),rr(60,10,15),'list_item',fixes=[('“热量”或“热能”氛围','热质或热的气层'),('热量被添加到原子中','热质被添加到原子中'),('“随着热量增加，热量氛围会膨胀”','“随着热量增加，热质气层会膨胀”')],reason='caloric是历史热质概念，不等于现代热能。')
add(rr(119,4),rr(60,16,18))
add(rr(119,5),rr(60,19),'heading')
notes=[]
for n,refs in note_groups(rr(257,1)):
    if n!=104:continue
    notes.append({'id':'dm-ch05-note-104','kind':'note','note_number':104,'source_blocks':refs,'printed_pages':['248'],'en':extract(EN,refs,True),'zh':'104. Dalton：“III. 论水和其他液体对气体的吸收”。','status':'text_compared_layout_pending'})
save('ch05v',5,rows,notes,rr(118,4,16)+rr(119,1,5)+rr(119,8))
(W/'checkpoint_ch05v.json').write_text(json.dumps({'next_source_pdf_page':119,'next_source_block':6,'next_supplied_pdf_page':60,'next_supplied_block':20,'next_unit':len(rows)+276,'next_note':105,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
