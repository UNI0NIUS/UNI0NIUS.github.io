from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch05-{len(rows)+182:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(105,6),rr(52,22),'heading',text='达尔文与目的论的终结')
add(rr(105,7),rr(52,22,24),'quote',start='顺便提一句',text=extract(ZH,rr(52,22,24)).split('达尔文与目的论的终结',1)[1]+'[[70]]',reason='恢复旧译遗漏原注70，分开标题与引文。')
add(rr(106,1),rr(52,25,27),'quote',fixes=[('自然科学基础。尽管','自然科学基础。……尽管'),('[[7]][[1]]','[[71]]')],reason='恢复源引文删节号及拆分注号71。')
add(rr(106,2),rr(52,28,31),fixes=[('他不仅回避把类人特质归因于动物，还提出','他并不回避把类似人类的特质归于动物，而且提出')],reason='Rather than shying away被旧译反转为回避，必须恢复否定方向。')
add(rr(106,3),rr(52,32,34))
add(rr(106,4),rr(53,0,2),fixes=[('是奴隶制坚定反对者，','是奴隶制的坚定反对者，[[72]]')],reason='补回原注72。')
add(rr(106,5),rr(53,3),'heading')
add(rr(106,6),rr(53,4,6))
add(rr(106,7),rr(53,7,8))
add(rr(106,8),rr(53,9,12),fixes=[('把赫顿、米勒和莱尔提出的“地质深时”理论与基督教视角相融合','普及了赫顿、米勒和莱尔的地质深时观，并将其与基督教视角相调和')],reason='补出popularized，并保持reconciled的调和含义。')
add(rr(106,9)+rr(107,1),rr(53,13,15))
add(rr(107,2),rr(53,16,18),fixes=[('坎布里亚纪（而非“坎布里亚”）','坎布里亚纪（Cumbrian，并非寒武纪Cambrian）')],reason='原文刻意区分Cumbrian/Cambrian，旧译同音转写使区别消失。')
rows[-1]['editor_note']='底本明确写Cumbrian (not Cambrian)，并在后文将其对应威尔士；中文保留底本这一区分与地理表述。'
add(rr(107,3),rr(53,19,23),fixes=[('CO_2',r'$\mathrm{CO_2}$')],english=extract(EN,rr(107,3),True).replace('CO2',r'$\mathrm{CO_2}$'))
add(rr(107,4),rr(53,24,25))
add(rr(107,5),rr(53,26,29),fixes=[('杰出的自然主义者','鲜明的自然主义者')],reason='pronounced表示鲜明/明确，不是杰出。')
add(rr(107,6),rr(53,30,33),fixes=[('氰化钾铁','亚铁氰化钾')],reason='ferro-cyanet of potash的化合物名称规范化。')
add(rr(107,7),rr(54,0),fixes=[('显然非常微小','据说非常微小'),('ascurus','ascuraus')],reason='apparently保留不确定性；拉丁式名称按底本拼写，不静默更改。')
add(rr(107,8),rr(54,1))
nt={70:'Karl Marx与Friedrich Engels：《马克思恩格斯全集》英文版（Marx-Engels Collected Works），第40卷（Progress Publishers），第441页。',71:'Karl Marx与Friedrich Engels：《马克思恩格斯全集》英文版（Marx-Engels Collected Works），第41卷（Progress Publishers），第246页。',72:'Adrian Desmond与James Moore：《达尔文的神圣事业：对奴隶制的憎恨如何塑造了达尔文的人类进化观》（Darwin’s Sacred Cause: How a Hatred of Slavery Shaped Darwin’s Views on Human Evolution）（HMH，2014）。'}
notes=[]
for n,refs in note_groups(rr(256,1)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch05-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['247'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch05o',5,rows,notes,rr(105,6,7)+rr(106,1,9)+rr(107,1,8))
(W/'checkpoint_ch05o.json').write_text(json.dumps({'next_source_pdf_page':107,'next_source_block':9,'next_supplied_pdf_page':54,'next_supplied_block':2,'next_unit':len(rows)+182,'next_note':73,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
