from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch11-{len(rows)+38:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(226,1),rr(119,13,14),text='香农表明，信息的公式在函数形式上与熵的公式完全相同。事实上，此后熵与信息这两个术语常被认为可以互换。',reason='functionally identical承接前文，统一为函数形式相同。')
add(rr(226,2),rr(119,15,18),text='但把信息等同于熵，似乎与人们通常把熵理解为无序或随机性的看法相矛盾。自然过程产生随机结果。风化岩面看起来粗糙而杂乱。经人手加工、刻上铭文的石头则立即可与自然物区分开来，恰恰因为它总体上相对平滑而有序。因此，记录人类信息似乎伴随着有序程度的增加[[11]]和随机性的减少。')
add(rr(226,3),rr(119,19),text='我们如何把这一点与香农将信息等同于熵、从而等同于无序的观点协调起来？')
add(rr(226,4),rr(119,20,21),text='当我们忽略传统人类记录的冗余性时，就会出现这一悖论。碑刻石匠希望文字清晰可读、醒目突出。为此，他们做了两件事：')
add(rr(226,5)+[[226,6,0,1]],rr(119,22),'list',text='1. 他们造出平整表面。这些表面不包含人类信息，却具有低熵和高度有序性。')
add([[226,6,1,2]]+rr(226,7),rr(119,23,24),'list',text='2. 随后，他们刻上字母，字母较大，刻痕较深，以抵御风化。这些字母确实包含信息，但表示信息的方式具有很高的冗余度。')
add(rr(226,8),rr(119,25,26),text='先创造低熵基底，再以冗余方式在其上记录信息：从印刷到微芯片制造，许多生产过程[[12]]都具有这种特征。')
add(rr(226,9),rr(119,27,29),text='前面已经看到，抛硬币的信息可以用文本冗余地记录，也可以用二进制数字高效地记录。文本即便存在错误，仍容易阅读。HEADS一词发生一个比特错误，可能变成譬如HECDS，但在上下文中依然可以理解。相反，在用来编码正反面的纯二进制流中，一个比特错误会不被察觉。')
add(rr(226,10),rr(119,30,32)+rr(120,0),text='实用而稳健的信息存储方式利用冗余和有序性，因而具有低熵。由此可见，在0和1出现频率相等的完全随机比特流中，能够编码最多的信息。这一点对图灵和香农研究的密码学具有实际意义。破译密码依赖于利用明文中的非随机性，这种非随机性以某种方式泄露为密文中的非随机性。与此相关，文件压缩技术（如.zip文件）会产生近似随机的比特串。',reason='order此处为有序性而非顺序；补足密文中非随机性的关系。')
add(rr(226,11),rr(120,1),text='但这引出一个新问题：我们所说的随机性是什么意思？')
add(rr(226,12),rr(120,2),'heading',text='幸运眷顾勇敢者（Audaces fortuna iuvat）')
add(rr(226,13),rr(120,3,4),text='“Alea jacta est”（骰子已经掷出），凯撒如是说；骰子一旦掷出，他便只能等待，看它如何落下。结果不可预知：凯旋、胜利，或是遇刺。',reason='补出拉丁语中文义并保留原文，维持骰子比喻。')
refs11=[[271,4,1,8]]+rr(271,5,11)+[[271,12,0,1]]
en11=r'11 This intuition is perhaps why some popular accounts refer to information as negative entropy (negentropy). This usage of the term stems from a misreading of Leon Brillouin, ‘The Negentropy Principle of Information’, Journal of Applied Physics 24, no. 9 (1953): 1152–63. What Brillouin did was introduce a new variable $N=-S$ as part of a generalization of the second law of thermodynamics: We may define the quantity N (negentropy) $N=-S,\Delta(N+I)\leq0$ (7b) The sum of negentropy plus information must always decrease. Negentropy corresponds to the ‘grade’ of energy in Kelvin’s principle of ‘degradation of energy’, Brillouin From this he was able to draw conclusions about the entropic effect of observations that obtain information: Any experiment by which an information is obtained about a physical system corresponds in average to an increase of entropy in the system or in its surroundings. This average increase is always larger than (or equal to) the amount of information obtained. Brillouin He was able to use this relation to demonstrate that Maxwell’s daemon was unfeasible.'
zh11=r'11. 这种直觉或许解释了为什么某些通俗论述将信息称为负熵（negentropy）。这一术语用法源于对Léon Brillouin论文“信息的负熵原理”的误读，见Journal of Applied Physics 24，第9期（1953）：1152—1163。Brillouin实际做的是引入一个新变量$N=-S$，作为推广热力学第二定律的一部分：“我们可以定义量N（负熵）：$N=-S,\Delta(N+I)\leq0$（7b）。负熵与信息之和必定始终减小。负熵对应于开尔文‘能量退化’原理中的能量‘品位’。”（Brillouin）由此，他得以就获取信息的观测所产生的熵效应作出结论：“凡是从一个物理系统获取信息的实验，平均而言都对应于该系统或其周围环境中熵的增加。这种平均增量始终大于（或等于）所获得的信息量。”（Brillouin）他能够利用这一关系证明麦克斯韦妖是不可行的。'
notes=[{'id':'dm-ch11-note-11','kind':'note','note_number':11,'source_blocks':refs11,'printed_pages':['262'],'en':en11,'zh':zh11,'source_transcription_note':'依PDF271图像恢复负熵公式与式号；引文及署名完整保留。','status':'text_compared_layout_pending'}, {'id':'dm-ch11-note-12','kind':'note','note_number':12,'source_blocks':[[271,12,1,4]],'printed_pages':['262'],'en':extract(EN,[[271,12,1,4]],True),'zh':'12. 关于资本主义工业中熵减少与信息增加交替过程的详细分析，见Cockshott等，《经典经济物理学：古典政治经济学、热力学与信息论论集》。','status':'text_compared_layout_pending'}]
save('ch11d',11,rows,notes,rr(226,1,13))
(W/'checkpoint_ch11d.json').write_text(json.dumps({'next_source_pdf_page':227,'next_source_block':1,'next_supplied_pdf_page':120,'next_supplied_block':5,'next_unit':len(rows)+38,'next_note':13,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
