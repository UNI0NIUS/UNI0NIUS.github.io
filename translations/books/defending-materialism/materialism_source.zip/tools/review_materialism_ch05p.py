from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch05-{len(rows)+200:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(107,9)+rr(108,1),rr(54,2,4),fixes=[('上帝是意愿让生命存在','上帝意欲让生命存在')])
add(rr(108,2),rr(54,5,7))
add(rr(108,3),rr(54,8,16),end='黑人种族',fixes=[('甲皮鱼','盾皮鱼'),('更高阶生命形式','更高等生命形式'),('适应欧洲人生活方式，还会适应他们的外貌','同化于欧洲人的生活方式，而且外貌也会趋同于欧洲人')],reason='placoderms为盾皮鱼；assimilate to appearance指外貌趋同，不是适应外貌。')
add(rr(108,4),rr(54,16,19),'quote',start='黑人种族',fixes=[('[[7]] [[3]]','[[73]]'),('社会地位更高','社会状态更高级')],reason='保留历史引文的价值判断，不将social state误限定为个人社会地位。')
add(rr(108,5),rr(54,20,22))
add(rr(108,6),rr(54,23,24),end='人类胎儿')
add(rr(108,7)+rr(109,1),rr(54,24,32),'quote',start='人类胎儿',fixes=[('[[7]] [[4]]','[[74]]'),('与那些在物种间延续的条件相反','与那些使物种向另一物种转变的条件相反'),('完全物种退化','完全的物种退化')],reason='carry on species to species指跨物种转变，不是物种间延续；恢复拆分注号。')
add(rr(109,2),rr(54,33,35))
add(rr(109,3),rr(54,36)+rr(55,0,2),end='马克思主义把',fixes=[('塞耶斯指出','塞耶斯[[75]]指出')],reason='补回遗漏原注75。')
add(rr(109,4),rr(55,2,4),'quote',start='马克思主义把',fixes=[('渐进模式','进步模式')],reason='progressive在此承接历史进步，不只是缓慢渐变。')
add(rr(109,5),rr(55,5,7))
add(rr(109,6),rr(55,8))
add(rr(109,7),rr(55,9),'list_item')
add(rr(109,8),rr(55,10),'list_item')
add(rr(109,9),rr(55,11),'list_item')
add(rr(109,10),rr(55,12),'list_item')
add(rr(109,11),rr(55,13),'list_item')
nt={73:'R. Chambers：《创世自然史遗迹》（Vestiges of the Natural History of Creation [by R. Chambers]）（John Churchill，Princes Street，Soho，1853），第217页，https://books.google.co.uk/books?id=qDoDAAAAQAAJ。',74:'Chambers：《创世自然史遗迹》，第219页。',75:'Sean Sayers：“马克思与目的论”（Marx and Teleology），Science & Society，第83卷第1期（2019），第37—63页，https://doi.org/10.1521/siso.2019.83.1.37；电子预印本：https://doi.org/10.1521/siso.2019.83.1.37；https://doi.org/10.1521/siso.2019.83.1.37。'}
notes=[]
for n,refs in note_groups(rr(256,1)):
    if n not in nt:continue
    en=extract(EN,refs,True).replace('\u200b','').replace('https:// doi','https://doi').replace('?id =','?id=')
    notes.append({'id':f'dm-ch05-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['247'],'en':en,'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch05p',5,rows,notes,rr(107,9)+rr(108,1,7)+rr(109,1,11))
(W/'checkpoint_ch05p.json').write_text(json.dumps({'next_source_pdf_page':110,'next_source_block':1,'next_supplied_pdf_page':55,'next_supplied_block':14,'next_unit':len(rows)+200,'next_note':76,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
