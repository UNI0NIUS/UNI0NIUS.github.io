from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch05-{len(rows)+170:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(104,1),rr(51,14,17),fixes=[("M-C-M'",r"$m-c-m'$"),("M<M'",r"$m<m'$"),('周转过程','循环过程')],reason='按原文保留本段小写m、c并统一数学排版。')
add(rr(104,2),rr(51,18,21),fixes=[('工作能力','劳动能力'),('工资商品劳动价值','工资购买的生活资料的劳动价值')])
add(rr(104,3),rr(51,22,24),fixes=[('工资应与维持工人生活所需劳动量相匹配','工资与维持工人生活所需劳动量相等'),('反比关系','反向关系')],reason='matched是理论判断，不是应当如此的规范要求；inverse relationship不必意味严格数学反比例。')
add(rr(104,4),rr(51,25))
add(rr(104,5,6),rr(51,26,27),fixes=[('从利润到剩余价值的概括','从利润推广到剩余价值')])
add(rr(104,7),rr(51,28,30),fixes=[('“C-M-C”',r'“$c-m-c$”'),('“M-C-M\'”',r"“$m-c-m'$”")])
add(rr(104,8),rr(51,31,34)+rr(52,0,2),fixes=[('共同实质','共同实体')])
add(rr(105,1),rr(52,3,5))
add(rr(105,2),rr(52,6,8),fixes=[('仍在捣鼓原型机，','仍在捣鼓原型机，[[69]]')],reason='补回旧译遗漏原注69。')
add(rr(105,3),rr(52,9,12))
rows[-1]['editor_note']='底本将此比率写为“消耗煤炭与运出煤炭之比”，随后称energy return on investment；本译保留其比率方向，不擅自倒置。'
add(rr(105,4),rr(52,13,16),fixes=[('“劳动”与“权力”','“功”与“功率”')],reason='work/power仍指前述物理概念，旧译劳动/权力破坏论证的衔接。')
add(rr(105,5),rr(52,17,21),fixes=[('社会学和工程学研究','社会研究和工程研究'),('自然科学和工程学','各门科学和工程学')],reason='social studies并未特指社会学；the sciences未限定自然科学。')
notes=[]
for n,refs in note_groups(rr(256,1)):
    if n!=69:continue
    notes.append({'id':'dm-ch05-note-69','kind':'note','note_number':69,'source_blocks':refs,'printed_pages':['247'],'en':extract(EN,refs,True),'zh':'69. 两人当时都受雇于格拉斯哥大学。','status':'text_compared_layout_pending'})
save('ch05n',5,rows,notes,rr(104,1,8)+rr(105,1,5))
(W/'checkpoint_ch05n.json').write_text(json.dumps({'next_source_pdf_page':105,'next_source_block':6,'next_supplied_pdf_page':52,'next_supplied_block':22,'next_unit':len(rows)+170,'next_note':70,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
