from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch10-{len(rows)+49:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(217,9),rr(113,34),'heading',text='巴迪欧、模型论与唯物主义')
add(rr(217,10),rr(113,35)+rr(114,0,1),text='阿兰·巴迪欧的《模型的概念》[[10]]以1968年的讲课为基础，试图调和形式逻辑与马克思主义唯物主义传统。他批评卡尔纳普和奎因，认为两种观点都区分经验“事实”与逻辑形式（第7页），并主张这实际上将形式科学与经验科学联结起来；也就是说，二者之间存在')
add(rr(217,11),rr(114,1,2),'quote',text='逻辑新实证主义与模型论之间的辩证共谋。（第19页）')
add(rr(218,1),rr(114,3,4),text='巴迪欧分析的一大长处在于，他把数学刻画为统一的物质实践，将形式规则系统与实际计算联系起来：')
add(rr(218,2),rr(114,4,5),'quote',text='有效程序这一哲学范畴——即可以通过一系列无歧义的书写操作明确计算出来的东西——真正处于一切数学认识论的中心。（第26页）',reason='scriptural强调书写的物质操作，不泛化成单纯符号。')
add(rr(218,3),rr(114,6),text='巴迪欧强调，虽然模型是为探索形式系统而构造的，')
add(rr(218,4),rr(114,6,7),'quote',text='模型是关于逻辑—数学系统区分能力的、可用数学构造的概念。[[11]]（第40页）',reason='恢复概念、区分能力与可构造性的修饰关系。')
add(rr(218,5),rr(114,8),text='反过来，模型也要接受实验研究：')
add(rr(218,6),rr(114,8,10),'quote',text='正因为形式装置本身是一种物质化的理论、一个数学结果，它才能进入数学知识的生产过程；在这一过程中，模型概念所指的不是一个等待形式化的外部，而是有待检验的数学材料。（第47页）')
add(rr(218,7),rr(114,11),text='巴迪欧进一步认为，形式系统实实在在是一台“数学生产机器”，并指出')
add(rr(218,8),rr(114,11,12),'quote',text='这些系统的理论与自动机或计算机器理论之间日益明显的亲缘关系，鲜明地说明了形式主义的实验使命。（第43页）',reason='vocation保留使命意味，不仅译实验性。')
add(rr(218,9),rr(114,13,14),text='如下文将讨论的，我们不只把自动机本身视为实验装置，还认为它为语义提供一种动态的物理基础，超越数学构造，无论这些构造如何物质化。')
add(rr(218,10),rr(114,15,17),text='巴迪欧在构造模型时优先考虑集合论和整数，却没有提到丘奇—图灵论题。这个论题意味着，所有图灵完备（TC）系统都可以相互充当形式模型：证明一个新系统图灵完备，恰恰要求能够在它与某个已知图灵完备系统之间进行翻译。既然计算机是物理的图灵完备系统，它们便使形式模型立足于实际现实。',reason='明确This指丘奇—图灵论题，不是未提及这一行为。')
add(rr(218,11),rr(114,18),'heading',text='自动机')
add(rr(218,12),rr(114,19,20),text='第9章介绍了图灵机，以及它有界但可以任意扩展的纸带。我们还看到，根据丘奇—图灵论题，图灵机是一切可能计算的模型。')
add(rr(218,13),rr(114,21,22),text='现在将探讨，限制图灵机纸带的性质如何改变它的计算性质。霍普克罗夫特和乌尔曼[[12]]对此有简明的论述。')
add(rr(219,1),rr(114,23,25),text='可以将图灵机纸带视为输入与输出的结合，同时也是存储器。初始纸带是输入，最终纸带是输出，图灵机能够任意检查、修改和扩展纸带。下面考虑通过改变纸带的性质，对图灵机行为施加的三类限制。')
add(rr(219,2),rr(114,26,28),text='首先，可以规定纸带不得扩展，即输出必须与输入一样大。这称为线性有界自动机（LBA），大致对应实际计算机。当然，计算机可以接收任意长度的流式输入，但任何时刻能保存在内存中的量都是有限的。实践中，我们仍把计算机当作图灵机，内存耗尽时就会抱怨。')
add(rr(219,3),rr(114,29,31),text='其次，可以给有限状态自动机（FSA）配一条能沿一个方向扩展的纸带。它像栈一样工作：可以在顶部添加（压入）或移除（弹出）项，但只能检查栈顶项。这称为下推自动机（PDA）。下推自动机并不是实际机器的常见形式，却是计算机程序初步句法分析软件的核心。')
add(rr(219,4),rr(114,32,34),text='第三，可以把对有限纸带的访问限定为只从头到尾检查，不得修改纸带或改变方向。因此，机器只能一路处理纸带，从一个状态转到另一个状态。如果不止一个旧状态都能进入同一个新状态，机器便不记得自身的计算历史。这类机器称为有限状态自动机（FSA）或摩尔机。')
add(rr(219,5),rr(115,0,1),text='还能够产生输出的有限状态自动机称为米利机。这相当于给摩尔机加上一条只有一个单元格的可写纸带。米利机广泛用于控制按固定动作序列运行的过程，例如一组交通信号灯或洗衣机的不同洗涤程序。',reason='统一术语，原文Mealey拼法保留于英文。')
nt={10:'A. Badiou：《模型的概念：数学唯物主义认识论导论》，Z. L. Fraser、T. Tao英译（re.press，2007）。',11:'原文为斜体。',12:'J. E. Hopcroft、J. E. Ullman：《形式语言及其与自动机的关系》（Addison-Wesley，1969）。'}
notes=[]
for n,refs in note_groups(rr(270,1)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch10-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['261'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch10c',10,rows,notes,rr(217,9,11)+rr(218,1,13)+rr(219,1,5))
(W/'checkpoint_ch10c.json').write_text(json.dumps({'next_source_pdf_page':219,'next_source_block':6,'next_supplied_pdf_page':115,'next_supplied_block':2,'next_unit':len(rows)+49,'next_note':13,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
