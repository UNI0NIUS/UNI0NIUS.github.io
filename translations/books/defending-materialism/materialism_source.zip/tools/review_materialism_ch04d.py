from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    s=s.replace('迪茨根','狄慈根').replace('《唯物主义与经验批判主义》','《唯物主义和经验批判主义》')
    row={'id':f'dm-ch04-{len(rows)+31:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(76,2),rr(35,39),'heading')
add(rr(76,3),rr(35,40,41)+rr(36,0,5),fixes=[('始终占据核心地位之后','始终占据核心地位之后[[27]]'),('官方党纲','官方党的学说')],reason='恢复原注27；party doctrine不是作为政治文献的党纲。')
add(rr(76,4)+rr(77,1),rr(36,6,13),end='贯穿所有马赫',fixes=[('《唯物主义与经验批判主义》中','《唯物主义与经验批判主义》[[28]]中'),('原始学说的重要补充。','原始学说的重要补充。[[29]]'),('在该标题中','在这部著作中')],reason='恢复原注28、29；title在此指著作而非书名文字。')
add(rr(77,2),rr(36,13,15),'quote',start='贯穿所有马赫',fixes=[('这个整个团体','这整个团体')])
add(rr(77,3),rr(36,16,17),fixes=[('而绝非——如果真要说的话——是','而很难说——即使勉强可以这样说——是')],reason='hardly if at all不能强化为毫无保留的绝非。')
add(rr(77,4),rr(36,18,19),end='马克思对“具体”',fixes=[('一种认识论，这种认识论','一种知识型（episteme），它')],reason='episteme与后文epistemology（认识论）区分。')
add(rr(77,5),rr(36,19,24),'quote',start='马克思对“具体”')
add(rr(77,6)+rr(78,1),rr(36,25,35),end='这种对“抽象”',fixes=[('最终的同一性','归根到底的同一性'),('“真实抽象”','“现实抽象”'),('“真实的尺度”','“实在的尺度”'),('“现实的语法”','“实在的句法”'),('综合理论中所呈现的那样。','综合理论中所呈现的那样。[[36]]')],reason='恢复原注36，统一real abstraction、syntax of the real等术语。')
add(rr(78,2),rr(36,35,39),'quote',start='这种对“抽象”',fixes=[('对黑格尔主义的倒退','倒退回黑格尔主义')])
add(rr(78,3),rr(36,40,41)+rr(37,0,4),fixes=[('伊连科夫和列宁所阐明','伊连科夫和列宁[[38]]所阐明'),('单向二元性','单边二元性')],reason='补原注38，统一拉鲁埃尔方法的单边术语。')
add(rr(78,4),rr(37,5,13),end='逻辑的拜物教')
add(rr(79,1),rr(37,13,14),'quote',start='逻辑的拜物教',fixes=[('[[4]] [[0]]','[[40]]')],reason='恢复被拆开的原注40。')
add(rr(79,2),rr(37,15,22),fixes=[('“遗传”意义上相互关联的','发生学意义上相互关联的[[41]]'),('任何形式的（普遍）“理性”','任何形式的（一般）“智力”'),('工资劳动','雇佣劳动'),('（想想投机经济）。','（想想投机经济）。[[42]]')],reason='genetic这里指发生学关系而非生物遗传；统一general intellect，恢复原注41、42。')
rows[-1]['editor_note']='本段底本确实写“使用价值与剩余价值”，并写M-M′取代M-C-M；这里按底本保留，不以通常的资本循环公式替换作者表述。'
nt={27:'鉴于苏联国家及其机构和执政党，以及通过它们发挥作用的共产国际，曾谨慎筛选并维护对马克思、恩格斯原著的一种特定解读，我们才敢称之为教条。这种解读主要依据列宁《唯物主义和经验批判主义》（初版于1909年）。',28:'弗拉基米尔·伊里奇·列宁：《全集》第14卷：《唯物主义和经验批判主义》（Progress Publishers，1977）。',29:'列宁：《唯物主义和经验批判主义》，第117—126页。',30:'列宁：《唯物主义和经验批判主义》，第341页。',31:'Evald Ilyenkov：《马克思〈资本论〉中抽象与具体的辩证法》（The Dialectics of the Abstract & the Concrete in Marx’s Capital），Sergei Kuzyakov译（Progress Publishers，1982），https://www.marxists.org/archive/ilyenkov/works/abstract/index.htm（访问日期：2022年2月27日），第1章，无页码。',32:'弗朗索瓦·拉鲁埃尔：《同一性理论》（Theory of Identities），Alyosha Edlebi译（哥伦比亚大学出版社，2016），第59、120、135—140页。',33:'拉鲁埃尔：《哲学与非哲学》，第22页及其他多处。',34:'维特根斯坦：《逻辑哲学论》，Frank P. Ramsey和Charles Kay Ogden译，2.1512；或：“施用于实在的尺度”，德文为Es ist wie ein Maßstab an die Wirklichkeit angelegt（2.1512）。',35:'弗朗索瓦·拉鲁埃尔：《非马克思主义导论》（Introduction to Non-Marxism），Anthony Paul Smith译（University of Minnesota Press-Univocal Publishing，2014）。',36:'Tony Burns：“约瑟夫·狄慈根与马克思主义史”（Joseph Dietzgen and the History of Marxism），Science & Society，第66卷第2期（2002），第202—227页。',37:'Ilyenkov：《马克思〈资本论〉中抽象与具体的辩证法》，第1章，无页码。',38:'列宁：《唯物主义和经验批判主义》，第45—46页；参见：“在这个特定问题上，唯物主义与‘马赫主义’的区别在于：唯物主义完全符合自然科学，把物质看作第一性的，把意识、思想、感觉看作第二性的，因为在明确的形式下，感觉只同物质的较高形式（有机物质）相联系，而‘在物质结构的基础中’，只能推测存在着一种类似于感觉的能力。”（第46页）',39:'Alberto Toscano：“现实抽象的公开秘密”（The Open Secret of Real Abstraction），Rethinking Marxism，第20卷第2期（2008），第282—287页。',40:'索恩-雷特尔致阿多诺的信，转引自Toscano：“现实抽象的公开秘密”，第281页。',41:'Toscano：“现实抽象的公开秘密”，引索恩-雷特尔致阿多诺的信：Alfred Sohn-Rethel、Theodor Adorno，Carteggio 1936/1969（manifestolibri，2000），第112页。',42:'卡尔·马克思：《资本论》第1卷第2篇第4章，I. Lasker译（Progress Publishers，1956），https://www.marxists.org/archive/marx/works/1885-c2/（访问日期：2022年5月12日）。'}
notes=[]
for n,refs in note_groups([[251,1],[252,1]]):
    if n not in nt:continue
    en=extract(EN,refs,True).replace('\u200b','').replace('archive/ ilyenkov','archive/ilyenkov')
    notes.append({'id':f'dm-ch04-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':list(dict.fromkeys(str(x[0]-9) for x in refs)),'en':en,'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
    if n==42:notes[-1]['editor_note']='底本文献写第1卷，但所列网址路径含1885-c2；这里保留书目信息及链接，不擅自更换。'
save('ch04d',4,rows,notes,rr(76,2,4)+rr(77,1,6)+rr(78,1,4)+rr(79,1,2))
(W/'checkpoint_ch04d.json').write_text(json.dumps({'next_source_pdf_page':80,'next_source_block':0,'next_supplied_pdf_page':37,'next_supplied_block':23,'next_chapter':5,'next_note':1,'chapter_4_text_compared':True,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
