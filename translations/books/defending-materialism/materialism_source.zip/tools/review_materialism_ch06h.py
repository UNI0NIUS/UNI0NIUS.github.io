from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch06-{len(rows)+104:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(148,3),rr(75,1,9),fixes=[('所有务实主义者','所有务实的人'),('贝克莱主教思想回声。','贝克莱主教思想的回声。[[38]]'),('法国大革命时期《百科全书》编纂者兼哲学家狄德罗','《百科全书》编纂者、法国大革命的哲学家狄德罗')],reason='补漏注38；pragmatic individuals不指哲学流派；不向Diderot描述添入时期判断。')
add(rr(148,4),rr(75,10,15),end='这意味着',fixes=[('只是半心半意','并不彻底')])
add(rr(149,7),[],'figure',text='图6.5 利用脑扫描，可以重建一个人正在看到的景象。A行：呈现给受试者的图像；B行：利用关于其脑活动的实时信息，由计算机重建的感知内容。取自Shen等人的研究。',reason='恢复旧译遗漏的彩图及完整图注。')
rows[-1].update(image='assets/figure-6-5.png',source_image={'pdf_page':149,'block':6,'xref':898},image_labels_zh='A：呈现图像；B：重建图像。')
add(rr(148,5)+rr(149,1),rr(75,15,19),'quote',start='这意味着',text='这意味着，在我们之外，独立于我们和我们的意识，存在着物质的运动，例如具有一定波长和速度的以太波；它们作用于视网膜，使人产生某种颜色的感觉。自然科学正是这样看待这个问题的。它用存在于人类视网膜之外、人体之外并独立于人的不同波长的光波，解释各种颜色的感觉。这就是唯物主义：物质作用于我们的感觉器官，产生感觉。感觉依赖于大脑、神经、视网膜等，即依赖于以一定方式组织起来的物质。物质的存在并不依赖于感觉。[[40]]',reason='合并被拆成4和0的注号40，修正旧译重复感觉某种颜色感觉；保留原引文以太术语。')
add(rr(149,2),rr(75,20),'heading')
add(rr(149,3),rr(75,21,25),end='因此',text='列宁写作时，物质的原子理论正处于革命性变革之中。同时，爱因斯坦提出光由量子化的光子组成，给经典物理学带来了矛盾：这似乎与有大量经验证据支持、已经确立的光的波动理论相冲突。随后，卢瑟福[[41]]通过薄金箔对β辐射的散射表明，此前被认为是实心的原子，实际上大部分是空隙，只有一个很小的原子核。同年，尼科尔森[[42]]提出，原子的大部分体积由电子轨道占据，而电子允许的角动量是普朗克常数h的倍数。',reason='补漏注41，合并42；底本仅称multiples，不额外添加整数。')
rows[-1]['editor_note']='底本确实写beta radiation，照译β辐射；未静默改成α粒子。'
add(rr(149,4),rr(75,25,27),'quote',text='因此，如果如索末菲所提出的那样，常数h在原子层面具有意义，那么当电子离开或返回时，原子的角动量或许只能以离散的量增加或减少。不难看出，这种观点比通常的解释更容易理解；后者被认为意味着能量本身具有原子式的构成。[[43]]',reason='恢复引文层级，统一索末菲译名并合并43注号。')
nt={38:'据Cercignani与Penrose的《路德维希·玻尔兹曼：相信原子的人》（Ludwig Boltzmann: The Man Who Trusted Atoms），玻尔兹曼采取了非常相近的立场，把对手视为贝克莱式唯心主义者：在玻尔兹曼看来，哲学的中心问题是存在与知识之间的关系，即gnoseology（英语译本[2]通常把这个词译为epistemology，尽管这在某种程度上缩小了其范围）。最能说明他在这一问题上态度的，是他在哲学意味最少、也最有趣的一篇文章中近乎随口说出的一句话；那篇文章记述了他1905年的“黄金国”之旅。这句话常被引用，出现在他描写加利福尼亚大学伯克利分校校园之后：“伯克利这个名字属于一位备受推崇的英国哲学家；人们甚至把人脑所孵化出的最大蠢事——否认物质世界存在的哲学唯心主义——的发明归功于他。”Cercignani与Penrose：《路德维希·玻尔兹曼：相信原子的人》，第170页。',39:'Guohua Shen等：“从人脑活动进行端到端深度图像重建”（End-to-End Deep Image Reconstruction From Human Brain Activity），Frontiers in Computational Neuroscience，第13卷（2019），21，ISSN：1662-5188，https://doi.org/10.3389/fncom.2019.00021 ，https://www.frontiersin.org/article/10.3389/fncom.2019.00021 。',40:'Lenin：《唯物主义和经验批判主义》（Materialism and Empirio-criticism），第55页。',41:'Ernest Rutherford：“物质对α和β粒子的散射与原子结构”（The Scattering of α and β Particles by Matter and the Structure of the Atom），Philosophical Magazine，第92卷第4期（2012），第379—398页。',42:'John William Nicholson：“太阳日冕的构成。IL”（The Constitution of the Solar Corona. IL），Monthly Notices of the Royal Astronomical Society，第72卷第8期（1912），第677—693页。',43:'Nicholson：“太阳日冕的构成。IL”（The Constitution of the Solar Corona. IL）。'}
notes=[{'id':'dm-ch06-note-38','kind':'note','note_number':38,'source_blocks':rr(261,1,2),'printed_pages':['252'],'en':extract(EN,rr(261,1,2),True),'zh':'38. '+nt[38],'status':'text_compared_layout_pending'}]
for n,refs in note_groups(rr(261,3)):
    if n not in range(39,44):continue
    notes.append({'id':f'dm-ch06-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['252'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
import sys
sys.path.insert(0,str(R/'tools/python_libs'))
import fitz
d=fitz.open(json.loads((W/'source_manifest.json').read_text('utf8'))['path']);fitz.Pixmap(d,898).save(str(R/'Defending Materialism/output/assets/figure-6-5.png'))
save('ch06h',6,rows,notes,rr(148,3,5)+rr(149,1,4)+rr(149,7))
(W/'checkpoint_ch06h.json').write_text(json.dumps({'next_source_pdf_page':149,'next_source_block':5,'next_supplied_pdf_page':75,'next_supplied_block':28,'next_unit':len(rows)+104,'next_note':44,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
