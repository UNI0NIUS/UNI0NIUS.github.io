from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch11-{len(rows)+63:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(228,13),[],'figure',text='图11.1 随着产生的数字越来越多，最初0出现得偏少的现象逐渐消失。作者绘图。',reason='旧中文稿遗漏图与图注，依据原书补全；图依源页视觉顺序置于正文前。')
rows[-1].update(image='assets/figure-11-1.jpeg',source_image={'pdf_page':228,'block':12,'xref':1526},image_labels_zh='% zeros：0所占的百分比；Number of digits seen：已观察的数字数量。')
add(rr(228,1),rr(121,7,8),text='因此，对先前问题的回答是否定的。一般而言，我们无法通过观察证明一个长数字序列，或一长串对自然的观测结果，是随机的。')
add(rr(228,2),rr(121,9,10),text='显然，迄今使用的数字序列实际上并不是通过投掷十面骰子产生的。掷44,000次骰子并不现实。')
add(rr(228,3),rr(121,11,13),text=r'我们本可以使用某种电子硬件产生真正的随机数。[[13]]实际上，我们确实使用了计算机生成的序列，但它并非真正随机。我们采用了$\pi$的连续数字作为来源。[[14]]然而，$\pi$的连续数字似乎完美地模仿了随机性。')
add(rr(228,4),rr(121,14,15),text='这便是现实的一个深刻悖论：circulus regitur forte——圆受偶然支配。圆是自然秩序最典型的范例，却由看似随机的东西支配。如今，规则与偶然的区别又在哪里？')
add(rr(228,5),rr(121,16),text='难道我们在作出重大决定以前，也应该请教占卜者、阅读《易经》吗？')
add(rr(228,6),rr(121,17,19),text='我们的科学定律大厦难道只是掩盖混沌的幻象？元数学家蔡廷[[15]]给出了一个答案：他基于计算机程序提出随机性的新定义。按照他的定义，随机数字序列就是不能由比它更短的计算机程序输出的序列。')
add(rr(228,7),rr(121,20,21),text=r'按照这一定义，$\pi$不是随机的。下面是Dik T. Winter编写的一段占160个字符的C程序，它能输出$\pi$的800个字符：')
code='int a=10000,b,c=2800,d,e,f[2801],g;main(){for(;b-c;)\n  f[b++]=a/5;\nfor(;d=0,g=c*2;c-=14,printf("%.4d",e+d/a),e=d%a)fo\n  r(b=c;d+=f[b]*a,\nf[b]=d%--g,d/=g--,--b;d*=b);}'
add(rr(228,8,10),rr(121,22,26),'code',text=code,english=code,reason='依原图恢复等宽代码行并移除提取时的零宽字符；保留源书for在行尾fo与下行r之间断开的排版。此为书中代码转录，不宣称可直接编译。')
rows[-1]['source_transcription_note']='依源PDF228代码图像恢复字符与五行布局；原版for词内换行保留。'
add(rr(228,11),rr(121,27),text=r'还有其他短程序，能够输出$\pi$的数百万位数字。')
nt={13:'自2018年以来，英特尔处理器支持RDRAND指令，该指令提供据称是真正的随机数。Intel，《Intel64和IA-32架构软件开发者手册》，第2B卷（Intel，2021）。',14:'我们从第三个数字开始，以免来源一目了然。',15:'Gregory J. Chaitin：“随机性与数学证明”，Scientific American 232，第5期（1975）：47—53。'}
notes=[]
for n,refs in note_groups(rr(271,12)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch11-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['262'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch11f',11,rows,notes,rr(228,1,11)+rr(228,13))
(W/'checkpoint_ch11f.json').write_text(json.dumps({'next_source_pdf_page':229,'next_source_block':1,'next_supplied_pdf_page':121,'next_supplied_block':28,'next_unit':len(rows)+63,'next_note':16,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
