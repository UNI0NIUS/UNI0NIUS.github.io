from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch07-{len(rows)+100:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(169,3),rr(86,22),'heading')
add(rr(169,4),rr(86,23,24))
add(rr(169,5),rr(86,25,27),text='如今，我们按照路德维希·维特根斯坦（1889—1951）所倡导的方法，用真值表赋予逻辑运算符精确的含义。[[27]]我们假定基本真值为真和假。核心运算包括：否定（非），把前提的真和假反转；合取（且），要求两个前提都为真；析取（或），要求至少一个前提为真，也允许两个都为真。见表7.1。')
add(rr(169,6),rr(86,28,29),fixes=[('包含析取','相容析取'),('排他析取','不相容析取')])
add(rr(169,7),rr(86,30))
add(rr(169,8),rr(86,31),'quote',text='X蕴含Y')
add(rr(169,9),rr(87,0))
add(rr(169,10),rr(87,1),'quote',text='非（X且非Y）')
add(rr(169,11),rr(87,2))
add(rr(169,12),rr(87,3,5))
vals=[['true','false','false','false','false','false','false','false'],['false','true','false','true','false','false','true','true'],['','','true','false','false','true','false','true'],['','','true','true','true','true','true','true']]
add(rr(169,13,15),rr(87,6,11),'table',text='表7.1 逻辑运算：否定、合取和相容析取',english=extract(EN,rr(169,13),True),reason='依据原图逐格恢复三组并列表，保留否定组末两行空格。')
rows[-1]['table']={'headers_en':['X','not X','X','Y','X and Y','X','Y','X or Y'],'headers_zh':['X','非X','X','Y','X且Y','X','Y','X或Y'],'rows_en':vals,'rows_zh':[[{'true':'真','false':'假','':''}[x] for x in r] for r in vals]}
vals=[['false','false','true','false','true'],['false','true','false','false','true'],['true','false','true','true','false'],['true','true','false','false','true']]
add(rr(170,10,11),rr(87,12,17),'table',text='表7.2 蕴含',english=extract(EN,rr(170,10),True),reason='依据原图恢复蕴含真值表。')
rows[-1]['table']={'headers_en':['X','Y','not Y','X and not Y','not (X and not Y)'],'headers_zh':['X','Y','非Y','X且非Y','非（X且非Y）'],'rows_en':vals,'rows_zh':[[{'true':'真','false':'假'}[x] for x in r] for r in vals]}
vals=[['0','1','0','0','0','0','0','0'],['1','0','0','1','0','0','1','1'],['','','1','0','0','1','0','1'],['','','1','1','1','1','1','1']]
add(rr(170,12,13),rr(87,18,23),'table',text='表7.3 以算术表示的逻辑运算：否定、合取和相容析取',english=extract(EN,rr(170,12),True),reason='按源图恢复0/1算术表；布尔加法1+1=1保留其逻辑语境。')
rows[-1]['table']={'headers_en':['x','1 − x','x','y','x × y','x','y','x + y'],'headers_zh':['x','1 − x','x','y','x × y','x','y','x + y'],'rows_en':vals,'rows_zh':vals}
add(rr(170,1),rr(87,24),'heading')
add(rr(170,2),rr(87,25,27),end='探究思维',fixes=[('《思维法则》','《思维规律》')])
add(rr(170,3),rr(87,27,28),'quote',start='探究思维')
add(rr(170,4),rr(87,29),end='一般推理',text='布尔认为，人类思维的规律确实是数学规律：',reason='quite literally在此强调确实，并非讨论字面词义。')
add(rr(170,5),rr(87,29,31),'quote',start='一般推理')
nt={27:'L. Wittgenstein：《逻辑哲学论》（Tractatus Logico-Philosophicus），D. F. Pears与B. F. McGuinness英译（Routledge and Kegan Paul，1961），第32—33页。',28:'W. Lenzen：“莱布尼茨：逻辑”（Leibniz: Logic），载Internet Encyclopedia of Philosophy（University of Tennessee at Martin，2017），https://iep.utm.edu/leib-log/ 。',29:'Boole：《思维规律研究》（An Investigation into the Laws of Thought）。'}
notes=[]
for n,refs in note_groups(rr(264,1)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch07-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['255'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch07g',7,rows,notes,rr(169,3,15)+rr(170,1,5)+rr(170,10,13))
(W/'checkpoint_ch07g.json').write_text(json.dumps({'next_source_pdf_page':170,'next_source_block':6,'next_supplied_pdf_page':88,'next_supplied_block':0,'next_unit':len(rows)+100,'next_note':30,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
