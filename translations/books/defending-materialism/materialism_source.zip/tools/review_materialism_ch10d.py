from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch10-{len(rows)+70:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(219,6),rr(115,2),'heading',text='语言游戏')
add(rr(219,7),rr(115,3,5),text='我们略去了两者的区别：检查符号序列是否具有所要求的结构，以及更广泛的计算。它们的联系在于，给定某种类型的文法，就有算法能够生成相应的检查机器。不过，确认结构与符号序列的意义如何相关，还不清楚。')
add(rr(219,8),rr(115,6,7),text='关键在于，机器检查序列时还做了什么。一旦把意义定位于物质化系统的状态变化中，就能以语言交流来阐明更广泛的互动。',reason='materialized恢复物质化，不仅是具体化。')
add(rr(219,9),rr(115,8,9),text='与卡尔纳普一样，维特根斯坦也退离了系统地阐述事态的总体性构想。在《逻辑哲学论》之后，他生前发表很少，后期工作通过身后出版的文集为人所知。')
add(rr(219,10)+rr(220,1),rr(115,10,12),text='在1953年出版的《哲学研究》[[13]]中，维特根斯坦探究语言游戏这一观念，以考察语言如何发挥作用。与其他游戏一样，语言游戏包含参与者依规则操作事物。游戏通过参与者遵循共同规则，轮流以说话和行动来互动而进行。',reason='合并跨页同段。')
add(rr(220,2),rr(115,13),text='例如：')
add(rr(220,3),rr(115,13,14),'quote',text='“我们来下一盘国际象棋吧”这个表达的涵义，与游戏的全部规则之间，是在哪里建立联系的？——在游戏的规则表中，在游戏的教学中，在日常下棋的实践中。（第80页）',reason='chess明确国际象棋，sense统一涵义。')
add(rr(220,4),rr(115,15,17),text='维特根斯坦将此与奥古斯丁的实指意义观相对置：意义基于名称与事物的联系，因此儿童通过他人指着事物并说出名称来学习语言。维特根斯坦则认为，儿童通过训练学习语言，这种训练包含说话，也就是互动（第2—4页）。')
add(rr(220,5),rr(115,18,21),text='他引入一个建筑工人与助手的语言游戏：工人喊出一个构件的名称，助手便递上该构件（第3页）。然后，他考虑工人询问助手有多少块石板的情形。助手回答“五块石板”，与工人说“五块石板”、期望助手递来五块石板，很不相同（第10页）。也就是说，即使广义理解命名，问题也不在给事物命名：同样的语言构造，在不同语境中有不同意义。',reason='builder不误作建筑师；slabs按建筑语境作石板。')
add(rr(220,6),rr(115,22),text='对维特根斯坦而言，我们在各种具体情境中参与众多小型语言游戏：')
add(rr(220,7),rr(115,22,23),'quote',text='我们没有意识到日常语言游戏的惊人多样性，因为语言的外衣使一切显得相同。（第224页）')
add(rr(220,8),rr(115,24,25),text='不过，语言游戏并非固定不变，而是在互动中发展；如果参与者行动不当，或者行动产生了未预见的后果，游戏便可能失灵。由于我们浸润于语言使用之中，这种情况可以得到解决：')
add(rr(220,9),rr(115,25,27),'quote',text='我们规定规则，规定一种游戏的技法，可是当我们遵循规则时，事情并不像我们假定的那样发展。于是，我们仿佛纠缠在自己的规则之中了。（第50页）')
add(rr(220,10),rr(115,28),'heading',text='文法与自动机')
add(rr(220,11),rr(115,29,33),text='诺姆·乔姆斯基[[14]]考察了不同类别的合式符号序列，而不直接关注其意义。他区分了四类文法，它们已被证明与上述自动机相对应。[[15]]即图灵机可以检查0型文法，线性有界自动机检查1型文法，下推自动机检查2型文法，有限状态自动机检查3型文法。这些类型因此构成一个层级，每一型所能定义的范围都比下一型更广，正如相应机器按计算能力排列一样。',reason='formal grammar统一文法，well-formed译合式；保留底本check表述。')
nt={13:'L. Wittgenstein：《哲学研究》，G. E. M. Anscombe英译（Blackwell，1958）。',14:'N. Chomsky：“论文法的某些形式性质”，Information and Control 2（1959）：137—167。',15:'Hopcroft、Ullman：《形式语言及其与自动机的关系》。'}
notes=[]
for n,refs in note_groups(rr(270,1)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch10-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['261'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch10d',10,rows,notes,rr(219,6,10)+rr(220,1,11))
(W/'checkpoint_ch10d.json').write_text(json.dumps({'next_source_pdf_page':221,'next_source_block':1,'next_supplied_pdf_page':116,'next_supplied_block':0,'next_unit':len(rows)+70,'next_note':16,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
