from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch07-{len(rows)+134:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(172,3),rr(88,31),'heading')
add(rr(172,4),rr(89,0,1),text='亚里士多德把三段论推理即演绎推理，与归纳推理区分开来；后者是在事物集合中识别模式。朱塞佩·皮亚诺（1858—1932）把它置于形式化基础之上，统一了数、集合和归纳的概念。',reason='旧译误把注36放此处，应归下一段。')
add(rr(172,5),rr(89,2,4),text='皮亚诺在1889年提出的方法，[[36]]基于一个很简单的相继数概念：从一开始，[[37]]反复加一。接着，与布尔和弗雷格相似，他把具有某种性质看作属于一个有明确特征的集合。然后，通过把数集合的成员看作一个序列并考察其共同性质，他定义了数集合上的归纳。',reason='successive numbers是相继数而非连续数；归位36/37。')
add(rr(172,6),rr(89,5,9))
add(rr(172,7),rr(89,10,11))
add(rr(172,8),rr(89,12),'heading',text='无限与无穷小')
add(rr(172,9),rr(89,13,14),end='无限、虚空',text='归纳似乎为无限制地计数提供了依据。那么，应如何刻画这种看似无限的情形？亚里士多德在《形而上学》[[38]]中区分了潜无限与实无限：',reason='补漏38，分离引文，统一潜无限/实无限。')
add(rr(172,10)+rr(173,1),rr(89,14,18),'quote',start='无限、虚空',text='无限、虚空和其他这类概念，被说成潜在地或现实地“存在”，其意义不同于大多数存在者，例如看见者、行走者或被看见者。在后面这些情形中，这种断言有时可以不加限定地为真，因为“被看见者有时因正在被看见而得名，有时因能够被看见而得名；但无限的潜在存在，并不意味着它将来会在现实中独立存在；它只有在认识中才可分离。”（第IX卷，第6部分，第447页）',reason='旧译把无限并不以潜在方式存在译成全面否定潜无限，漏掉in the sense限定；恢复其限定含义。')
rows[-1]['editor_note']='英文底本sometimes be truly made have含多余have，英文照录，中文按可理解的句意连接。'
add(rr(173,2),rr(89,19,22),end='由于分割过程',text='埃利亚的芝诺（公元前495—430年）提出了一些悖论，围绕事物可以无限地分割、因而分成无限多个部分这一可能性展开。[[39]]亚里士多德在《物理学》中详细讨论了这类悖论。在《形而上学》中，他用潜无限与实无限的区别质疑无限分割：')
add(rr(173,3),rr(89,21,22),'quote',start='由于分割过程',text='因为分割过程永不停止这一事实，使这种现实性以潜在方式存在，却不独立存在。（第IX卷，第6部分，第447页）')
nt={36:'G. Peano：“用新方法表述的算术原理”（The Principles of Arithemtic, Presented by a New Method），载《从弗雷格到哥德尔：数理逻辑文献集，1879—1931》（From Frege to Gödel: A Source Book in Mathematical Logic, 1879–1931），J. van Heijenoort编译（Harvard University Press，1967）。',37:'如今通常从零开始。',38:'Aristotle：《形而上学》，第I—IX卷（The Metaphysics, Books I-IX）。',39:'B. Dowden：“芝诺悖论”（Zeno’s Paradoxes），Internet Encyclopedia of Philosophy，https://iep.utm.edu/zenos-paradoxes/ 。'}
notes=[]
for n,refs in note_groups(rr(264,1)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch07-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['255'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch07i',7,rows,notes,rr(172,3,10)+rr(173,1,3))
(W/'checkpoint_ch07i.json').write_text(json.dumps({'next_source_pdf_page':173,'next_source_block':4,'next_supplied_pdf_page':89,'next_supplied_block':23,'next_unit':len(rows)+134,'next_note':40,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
