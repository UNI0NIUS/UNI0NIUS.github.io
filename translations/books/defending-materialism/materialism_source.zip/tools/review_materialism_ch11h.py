from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch11-{len(rows)+91:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(230,5),rr(122,31),'heading',text='自然界的量变导致质变')
add(rr(230,6),rr(122,32,35),text='量变导致质变这一观念，似乎因恩格斯的《自然辩证法》而广为流传。该书认为，在物理学中，我们研究物体的分子状态以及使分子活动起来的运动形式。每一种变化都是量向质的转化，[[22]]源自物体所固有的或传递给物体的运动的量变。物理常数标示着节点，在这些节点上，运动的增加或减少改变物体的状态，从而把量转化为质。',reason='修复旧译“节点点”等重复，保持原文间接引述形式。')
add(rr(230,7),rr(123,0,6),text='恩格斯在这里描述的，基本上就是我们现在所说的相变现象。他所举的液态与气态之间的变化，确实是相变的例子。不过，与物理学的术语相比，恩格斯谈论量与质时使用的术语含义模糊。物理学家会把相变定义为熵随温度的变化变得不连续的情形：在达到100摄氏度以前，每升高1摄氏度需要1,000卡热量；而从99摄氏度的水变成100摄氏度的蒸汽，则需要540,000卡，增幅巨大。水从表面蒸发时，每克消耗540卡热量。在没有外界热量输入时，水会冷却0.5°C。这只有在密闭容器中才是现实的，而沸点以下的蒸发速率与开尔文温度成正比。对于炉灶上的敞口锅，把1升水升高1摄氏度所需的热量输入，在达到100°C之前是非线性的；到了100°C，仍会发生阶跃式跃变。',reason='忠实转录原书数值、条件及物理论断，未用译者推导替换作者表述；卡为能量单位，不误作千卡。')
add(rr(230,8)+rr(231,1),rr(123,7,11),text='辩证唯物主义话语的问题在于，“量”和“质”这两个术语含糊不清，定义不明确。在熔化和沸腾的例子中，凭常识我们知道固、液、气三种相态之间存在质的区别。但若采用超临界锅炉，即在高于3,200 psi的压力下运行的锅炉，那么液态水与蒸汽就成为无法区分的相。人们可以用质的话语来包装这一现象，说在高于3,200 psi时，水与蒸汽之间没有质的区别；也可以更精确地说，在高于3,200 psi时，加热水不会造成熵的阶跃式跃变。',reason='quality此处是哲学范畴质，不是质量；跨页句完整接合。')
add(rr(231,2),rr(123,12),text='恩格斯语言的含糊，使他的论述出现了明显的错误。白炽灯这个例子完全错了。')
add(rr(231,3),rr(123,13,16),text='改变灯的供电电压，灯丝温度便逐渐升高。随着温度上升，不同波长的发光强度逐渐变化，光色从红、橙、黄趋向近乎白色。凡是使用过白炽灯调光器的人，都见过这种现象。这里没有明确的相变，也没有鲜明的阈值电压。发光二极管则有明确的阈值电压，低于它时不发光；超过该阈值之后，发出的光色也不改变。',reason='按上下文将原文admitted理解为发光，避免旧译“光通过”与发光二极管机理错位；英文保留原样。')
add(rr(231,4),rr(123,17,18),text='只有某些系统会发生相变，其他系统则连续变化。这个混乱的灯泡例子，似乎正是恩格斯术语含糊造成的。')
add(rr(231,5),rr(123,19,22),text='什么算作质变？什么算作量变？所谓量，他指的是整数，还是连续统？在他关于沸腾相关温度变化的正确例子中，量变沿一个连续尺度发生。他关于白炽灯泡的错误例子也一样。[[23]]电压是一种模拟变量，也就是连续变量。')
add(rr(231,6),rr(123,23),text='但在其他地方，恩格斯又希望把量理解为整数。',reason='下文从The sphere开始为独立引文，旧译粘连在本段之后。')
notes=[]
nt={22:'弗里德里希·恩格斯，《自然辩证法》（Wellred Books，1960），第2章。',23:'正如本书前文所述，灯泡等物体发出的黑体辐射所涉及的连续能级与离散能级问题，是爱因斯坦针对马赫学派确证原子论的关键。'}
for n,refs in note_groups(rr(272,1)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch11-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['263'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch11h',11,rows,notes,rr(230,5,8)+rr(231,1,6))
(W/'checkpoint_ch11h.json').write_text(json.dumps({'next_source_pdf_page':231,'next_source_block':7,'next_supplied_pdf_page':123,'next_supplied_block':23,'next_unit':len(rows)+91,'next_note':24,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
