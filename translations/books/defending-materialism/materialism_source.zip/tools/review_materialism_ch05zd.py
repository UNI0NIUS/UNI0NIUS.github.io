from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch05-{len(rows)+348:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(129,8),rr(65,16,19),fixes=[('类似可逆性论点，他在其中','类似的可逆性论点，[[127]]他在其中')],reason='补回遗漏原注127。')
add(rr(130,1),rr(65,20,22),fixes=[('当气体中两个分子（A 和B）在位置x 处发生碰撞时，每个分子到达位置概率在统计上是相互独立','当气体中两个分子（A和B）在位置$x$发生碰撞时，每个分子到达位置$x$的概率在统计上相互独立[[128]]'),('但在两个分子碰撞瞬间','但在两个分子刚刚碰撞之后')],reason='补原注128及第二个位置x；immediately after是碰撞之后，不是碰撞瞬间。')
add(rr(130,2),rr(65,23,25))
add(rr(130,3),rr(65,26))
eq=r'$P^2(x_1,\xi_1,x_2,\xi_2,t)=P^1(x_1,\xi_1,t)\times P^1(x_2,\xi_2,t)$'
tail=r'$\times P^1(x_2,\xi_2,t)$'
nt={125:'L. Boltzmann：Sitzungsberichte Akad. Wiss.，维也纳，II，第66卷，第275—370页；英译：Brush, S. G.（1966），《气体动理论》第2卷《不可逆过程》（Kinetic Theory: Vol. 2 Irreversible Processes）（Permagon Press，1872）。',126:r'更准确地说，他的原论文表明，具有函数形式$H\sim\int p\log p$的量，在系统随时间演化时趋于减小。该量为负，因为概率$p<1$，$\log p<0$。现在我们通常使用玻尔兹曼后来的表述$S=k\log$（N article states的数目），这是趋于增加的正熵。',127:'Loshmidt：“论计及重力时物体系统的热平衡状态”（Ueber den znstand des Warmegleichgewichtes eines Systems von Korpern mit Rucksicht auf die Schwerkraft），Wiener Berichte，第73卷（1876），第135页。',128:r'形式地，令$P^1(x,\xi,t)$为一个分子在时间$t$位于位置$x$、速度为$\xi$的概率函数；令$P^2(x_1,\xi_1,x_2,\xi_2,t)$表示分子1的位置和速度坐标为$x_1,\xi_1$，分子2的位置和速度为$x_2,\xi_2$的概率。玻尔兹曼的统计独立性假设为'+eq+' '+tail+'。'}
notes=[]
for n,refs in note_groups(rr(258,1)):
    if n not in nt:continue
    en=extract(EN,refs,True)
    if n==126:en=r'126 More precisely, his orginal paper showed that a quantity with functional form $H\sim\int p\log p$, which is negative since probability $p<1$, $\log p<0$ $H$ tends to decrease in the time evolution of a system. We now normally use Boltzmann’s later formulation $S=k\log$(number of N article states) which is positive entropy which tends to increase.'
    if n==128:en=r'128 Formally let $P^1(x,\xi,t)$ be the probability function for one molecule being in locality $x$ with velocity $\xi$ at time $t$ and let $P^2(x_1,\xi_1,x_2,\xi_2,t)$ denote the probability of molecule 1 having position and velocity coordinates $x_1,\xi_1$ and molecule 2 have position and velocity $x_2,\xi_2$. Boltzmann’s statistical independence assumption was that '+eq+' '+tail+'.'
    note={'id':f'dm-ch05-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['249'],'en':en,'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'}
    if n==126:note['editor_note']='底本熵公式括号内印作N article states，疑有缺字；这里保留该字样，不推补particle。H公式及不等号按源图恢复。'
    if n==128:note['editor_note']='底本独立性公式末尾另重复印有×P¹(x₂, ξ₂, t)。本译保留此重复项并标明，不将其静默删去。'
    notes.append(note)
save('ch05zd',5,rows,notes,rr(129,8)+rr(130,1,3))
(W/'checkpoint_ch05zd.json').write_text(json.dumps({'next_source_pdf_page':130,'next_source_block':4,'next_supplied_pdf_page':65,'next_supplied_block':27,'next_unit':len(rows)+348,'next_note':129,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
