from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch06-{len(rows)+124:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(151,7)+rr(152,1),rr(76,27,29),text='当他谈到试图追踪光的时空传播时，指的是求解麦克斯韦方程组，从而得到光波的振幅。但这个解只给出到达某处——例如照相底片上某一点——的光的振幅。电磁场振幅的平方给出到达该点的光子通量，但单个光子随机到达，服从泊松统计。因此，他说“我们只能进行统计考量”。[[51]]',reason='补回跨页漏译光波振幅，删除旧译残句并合并51。')
add(rr(152,2),rr(76,30,34),text=r'当他接着将这一点与“满足因果性要求”相对照时，指的仍是守恒定律，正如他1924年的论文中所说。经典物理学的整个因果结构都围绕能量和动量守恒建立。行星及其卫星遵循的时空路径，是使能量和动量守恒的路径。但他说，在量子力学中，如果要讨论能量守恒，就必须从麦克斯韦的光模型转向爱因斯坦的模型：我们所能说的，只是一个原子在时刻$t_0$发射一个光子，另一个原子在时刻$t_1$吸收这个光子。在这两个事件之间，无法为光子指定一条确定的路径。')
add(rr(152,3),rr(76,35)+rr(77,0,1),end='此外',fixes=[('[[5]] [[2]]','[[52]]')])
add(rr(152,4),rr(77,1,3),'quote',start='此外',fixes=[('[[5]] [[3]]','[[53]]'),('[[5]] [[4]]','[[54]]')])
add(rr(152,5),rr(77,4))
add(rr(152,6),rr(77,5,6))
add(rr(152,7),rr(77,7))
eq=r'\Delta t\Delta E=\Delta x\Delta I_x=\Delta y\Delta I_y=\Delta z\Delta I_z=h'
add(rr(152,8),rr(77,8),text='$'+eq+'$',english='$'+eq+'$',reason='据源图恢复全部Δ、下标及等号。')
rows[-1]['math_lines']=[eq]
add(rr(152,9),rr(77,9),text=r'其中$\Delta t$表示波包通过某一点的时间间隔。这给出了光子到达时刻的不确定性。',english=extract(EN,rr(152,9),True).replace('∆t',r'$\Delta t$'))
add(rr(152,10),rr(77,10,11),text=r'关系式$\Delta t\Delta E=h$来自爱因斯坦的结论：光子的能量与频率通过普朗克常数h成反比，使得$h=E\tau$，其中$\tau$是光波的振动周期。',english=r'The relation $\Delta t\Delta E=h$ comes from Einstein’s result that the energy and frequency of photons are inversely related by Plank’s constant h such that $h=E\tau$ where $\tau$ is the period of vibration of the light wave.',reason='据源图恢复关系式与周期τ；底本frequency成反比的错误不静默改。')
rows[-1]['editor_note']='底本称能量与frequency成反比；与同句h=Eτ相应的反比变量应为周期τ，频率与能量为正比关系。正文保留底本表述。'
add(rr(153,1),rr(77,12,14))
add(rr(153,2),rr(77,15),text=r'$\Delta x,\Delta y$分别是波包在x、y方向上的长度，其他方向依此类推。这给出了波包到达位置的空间不确定性。',english=r'$\Delta x,\Delta y$ is the length of the wave packed in the x, y directions, etc. This gives the spatial uncertainty about where it will arrive.')
add(rr(153,3),rr(77,16,18),text=r'$\Delta I_x$是x方向的动量范围，其他方向依此类推。因此，$\Delta x\Delta I_x=h$表达的就是后来所谓的海森堡不确定性原理。[[55]]玻尔从爱因斯坦的光子动量公式$I\lambda=h$推导出这一关系；这里的符号I表示动量。',english=r'$\Delta I_x$ is the range of momenta in the x direction, etc. So $\Delta x\Delta I_x=h$ expresses what was later known as Heisenberg’s uncertainty principle.[[55]] Bohr has derived this from Einstein’s formula for the momentum of photons $I\lambda=h$, where I in this notation means momentum.',reason='恢复动量下标、波长λ及漏注55。')
add(rr(153,4),rr(77,19,20))
add(rr(153,5),rr(77,21,26),fixes=[('[[5]] [[6]]','[[56]]'),('相应基态','相应基矢态'),('系统基态','系统基矢态')],reason='basis state与最低能量基态不同，统一基矢态；合并56。')
add(rr(153,6),rr(77,27,28),fixes=[('[[5]] [[7]]','[[57]]')])
add(rr(153,7),rr(77,29,30))
nt={51:'现代数码相机十分灵敏，在弱光下拍照时，可以看到光子随机到达产生的“散粒噪声”，表现为各像素之间不相关的斑点。',52:'玻尔似乎直到后来与爱因斯坦讨论时才考虑过这类例子。参见Jan Faye：“量子力学的哥本哈根诠释”（Copenhagen Interpretation of Quantum Mechanics），载《斯坦福哲学百科全书》（The Stanford Encyclopedia of Philosophy），2019年冬季版，Edward N. Zalta编（斯坦福大学形而上学研究实验室，2019）。',53:'$'+eq+'$',54:'Bohr等：《量子公设与原子理论的近期发展》（The Quantum Postulate and the Recent Development of Atomic Theory）。',55:'海森堡在前一年用另一种方法推导出了这一关系。他设想一个思想实验：用高频辐射照射电子，试图确定它的位置。要越精确地确定位置，所需光频率就越高。频率更高的光会扰动电子的运动，由此得到位置不确定性与动量不确定性之间的反比关系。玻尔直接从波的性质出发的推导更具一般性。',56:'Camilleri：“玻尔、海森堡及其对互补性的不同看法”（Bohr, Heisenberg and the Divergent Views of Complementarity）；Faye：“量子力学的哥本哈根诠释”（Copenhagen Interpretation of Quantum Mechanics）；Howard：“谁发明了‘哥本哈根诠释’？一项神话研究”（Who Invented the ‘Copenhagen Interpretation’? A Study in Mythology）。',57:'Sheng-Kai Liao等：“卫星到地面的量子密钥分发”（Satellite-to-ground Quantum Key Distribution），Nature，第549卷第7670期（2017），第43—47页。'}
notes=[]
for n,refs in note_groups(rr(261,3))+note_groups(rr(262,1)):
    if n not in nt:continue
    en=extract(EN,refs,True) if n!=53 else '53 $'+eq+'$'
    notes.append({'id':f'dm-ch06-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':[str(refs[0][0]-9)],'en':en,'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch06j',6,rows,notes,rr(151,7)+rr(152,1,10)+rr(153,1,7))
(W/'checkpoint_ch06j.json').write_text(json.dumps({'next_source_pdf_page':153,'next_source_block':8,'next_supplied_pdf_page':78,'next_supplied_block':0,'next_unit':len(rows)+124,'next_note':58,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
