from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch09-{len(rows)+1:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(196,0,2),rr(101,39),'chapter',text='第9章 逻辑危机与反形式主义的顶峰',english='Chapter 9: THE CRISIS IN LOGIC AND THE APOTHEOSIS OF ANTI-FORMALISM')
rows[-1]['source_transcription_note']='恢复标题阅读顺序。'
add(rr(196,3),rr(102,0),'heading',text='引言')
add(rr(196,4),rr(102,1),text='希尔伯特纲领可以简要概括为：试图确定罗素和怀特海在《数学原理》中使用的算术形式化是否')
add(rr(196,5),rr(102,2),'list_item',text='相容，即不可能证明一个公式及其否定都是定理；')
add(rr(196,6),rr(102,3),'list_item',text='完备，即没有不能被证明为定理的定理；')
rows[-1]['editor_note']='底本以“不能被证明的定理”说明不完备性；此处保留作者的用词，不将其静默改为“不可证的真命题”。'
add(rr(196,7),rr(102,4),'list_item',text='具有判定程序，即一种会终止的机械程序或算法，能够确定任意公式是否为定理。')
add(rr(196,8),rr(102,5,6),text='罗素悖论已经强烈暗示，数学不可能相容。随后，正如下文将要探讨的，哥德尔确立了数学不可能完备，而图灵确立了数学不可能拥有判定公式是否为定理的程序。',reason='统一相容性、完备性术语，保留底本概括。')
add(rr(196,9),rr(102,7),'heading',text='哥德尔与完备性')
add(rr(196,10),rr(102,8,10),text='元数学用数学来真正谈论数学自身；其关键在于找到公式的数学表示或编码，以便用其他公式来处理它们。第7章已说明，如何依照符号和句法来定义逻辑。如果给符号赋予数值，就能把一个公式转化为一个合成的数，再用算术将其分解回符号。',reason='composite number此处表达编码合成，不译复数；syntax统一句法。')
add(rr(196,11),rr(102,11,12),text='在1931年一篇开创性的论文中，库尔特·哥德尔（1906—1978）用数论谓词演算的编码，证明了它是不完备的，即存在不能被证明的定理。[[1]]克莱尼[[2]]作了详尽的论述。',reason='保留底本定理措辞，原注2归位作者名后。')
add(rr(196,12)+rr(197,1),rr(102,13,14),text='哥德尔没有采用简单的乘法技巧，而是给符号序列中的每个位置分配一个质数。然后，把每个质数提升到该位置上符号编码所指定的幂，再将这些质数的幂相乘，从而汇合各符号的编码。',reason='旧译幂次关系不清；位置决定质数，符号编码决定指数。')
add(rr(197,2),rr(102,15,16),text='例如，假定按表9.1给符号赋予编码。那么，肯定前件式三段论的公式为：')
rows[-1]['editor_note']='底本将Modus Ponens误拼为Modus Ponems；英文照录。'
add(rr(197,3),rr(102,17),'formula',text=r'$(a\land(a\Rightarrow b))\Rightarrow b$',english=r'$(a\land(a\Rightarrow b))\Rightarrow b$')
rows[-1]['math_lines']=[r'(a\land(a\Rightarrow b))\Rightarrow b']
add(rr(197,4),rr(102,18),text='也就是“a，以及a蕴含b，蕴含b”，转化为：')
add(rr(197,5),[],'formula',text=r'$8\quad10\quad4\quad8\quad10\quad7\quad11\quad9\quad9\quad7\quad11$',english=r'$8\quad10\quad4\quad8\quad10\quad7\quad11\quad9\quad9\quad7\quad11$',reason='补旧译遗漏的中间编码序列。')
rows[-1]['math_lines']=[r'8\quad10\quad4\quad8\quad10\quad7\quad11\quad9\quad9\quad7\quad11']
add(rr(197,6),[],text='这可以编码为：',reason='补旧译遗漏的公式引导句。')
formula=r'2^8*3^{10}*5^4*7^8*11^{10}*13^7*17^{11}*19^9*23^9*29^7*31^{11}'
add(rr(197,7),rr(102,19),'formula',text='$'+formula+'$',english='$'+formula+'$',reason='依源图恢复各质数的幂，采用全宽公式。')
rows[-1]['math_lines']=[formula]
add(rr(197,8),rr(102,20,22),text='这一方法适用于任意数量的符号和任意长度的序列。解码要用到一种称为质因数分解的技术，它可以求出一个数中所有质因数的指数。当然，这种编码会得到难以想象的大数，但哥德尔本来就不打算直接处理这些数。')
add(rr(197,11,12),rr(102,23,32)+rr(103,0,4),'table',text='表9.1 符号编码',english=extract(EN,rr(197,11),True),reason='逐格对照原图，恢复两列无表头的原表，不沿用旧译新增表头。')
rows[-1]['table']={'headers_en':['',''],'headers_zh':['',''],'rows_en':[['T (true)','1'],['F (false)','2'],['=','3'],[r'$\land$ (and)','4'],[r'$\lor$ (or)','5'],[r'$\neg$ (not)','6'],[r'$\Rightarrow$ (implies)','7'],['(','8'],[')','9'],['a','10'],['b','11'],['c','12'],['…','']], 'rows_zh':[['T（真）','1'],['F（假）','2'],['=','3'],[r'$\land$（且）','4'],[r'$\lor$（或）','5'],[r'$\neg$（非）','6'],[r'$\Rightarrow$（蕴含）','7'],['(','8'],[')','9'],['a','10'],['b','11'],['c','12'],['…','']]}
add(rr(197,9),rr(103,5,8),text='哥德尔想要编码的是证明，即一系列公式，其中每个公式要么是公理或定理，要么由公理或定理应用推理规则而得。他展示了如何构造函数来拆解这些哥德尔数，不仅检查其形式是否合乎规则，也检查它们是否对应于有效证明的公式。这可以用来确定一个公式序列是否构成证明，但与检查任意公式是否存在证明，是两回事。')
nt={1:'K. Gödel：“论《数学原理》及相关系统中的形式不可判定命题”，载J. van Heĳenoort编《从弗雷格到哥德尔：数理逻辑文献集，1879—1931》（Harvard University Press，1967），第596—616页。',2:'Kleene：《元数学导论》。'}
notes=[]
for n,refs in note_groups(rr(267,3)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch09-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['258'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch09a',9,rows,notes,rr(196,0,12)+rr(197,1,9)+rr(197,11,12))
(W/'checkpoint_ch09a.json').write_text(json.dumps({'next_source_pdf_page':197,'next_source_block':10,'next_supplied_pdf_page':103,'next_supplied_block':9,'next_unit':len(rows)+1,'next_note':3,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
