from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch05-{len(rows)+298:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(121,4),rr(61,15),'quote',start='上述机械操作')
add(rr(121,5),rr(61,16),'quote',fixes=[('钻头','镗刀')])
add(rr(121,6),rr(61,17,18),'quote',fixes=[('潜热和热量理论','潜热和热质理论')])
add(rr(121,7),rr(61,19,21),'quote',fixes=[('59^{\\circ}F',r'$59^{\circ}\mathrm{F}$'),('[[10]] [[9]]','[[109]]'),('从所有外观来看','从观察结果来看')])
add(rr(121,8),rr(61,22,24),end='在探讨这一课题',fixes=[('钻机上马所施加动力','驱动镗床的马所做的功')],reason='work是机械功，不是动力；保持热功关系论证。')
add(rr(122,1),rr(61,24,27),'quote',start='在探讨这一课题',fixes=[('任何绝热体或物体系统','任何隔离的物体或物体系统'),('能够无碍持续提供东西','能够无限持续提供的东西'),('若非“运动”','若非“运动”（MOTION）')],reason='insulated不直接强化为绝热；保留原文强调的大写MOTION。')
add(rr(122,2),rr(61,28,30),fixes=[('工资商品','工资购买的生活资料'),('工作与能量物理等价','功与能量物理等价')])
add(rr(122,3),rr(61,31,37)+rr(62,0),'quote',fixes=[('迈耶','迈尔')],reason='同段Julius Robert Mayer/J.R.Mayer统一译迈尔。')
add(rr(122,4),rr(62,1,3))
add(rr(122,5),rr(62,4,5),fixes=[('超出了马克思和恩格斯对其所处时代力学认知范围','似乎超出了马克思和恩格斯对其所处时代力学的认知范围')],reason='seem to have known保留作者判断的不确定性。')
add(rr(122,6),rr(62,6,7),fixes=[('与劳动之间','与功之间')],reason='work在接下来的热力学与信息论讨论中指物理功。')
nt={109:'Rumford：“关于摩擦所激发的热的来源的研究，伦福德伯爵本杰明著，Frsmria”。',110:'Rumford；斜体及大写均为原文所有。',111:'Paul Burkett与John Bellamy Foster：“马克思政治经济学批判中的物质变换、能量与熵：超越波多林斯基神话”（Metabolism, Energy, and Entropy in Marx’s Critique of Political Economy: Beyond the Podolinsky Myth），Theory and Society，第35卷第1期（2006），第109—156页，ISSN：03042421、15737853，http://www.jstor.org/stable/4501746。',112:r'廷德尔指出，在$0^{\circ}\mathrm{C}$时，氧分子的运动速度为每秒1,514英尺。',113:'Engels：《自然辩证法》，第243—256页。',114:'关于这两个问题，H. Price的《时间之箭与阿基米德之点：时间物理学的新方向》（Time’s Arrow and Archimedes’ Point: New Directions for the Physics of Time）（Oxford University Press，USA，1997）给出了深入而出色的唯物主义论述。本章以下内容主要借鉴他的著作，以及Carlo Cercignani与Roger Penrose的《路德维希·玻尔兹曼：相信原子的人》（Ludwig Boltzmann: The Man Who Trusted Atoms）（Oxford University Press，1998）。'}
notes=[]
for n,refs in note_groups(rr(257,1)):
    if n not in nt:continue
    en=extract(EN,refs,True).replace('\u200b','')
    if n==112:en=en.replace('0\uf06fC',r'$0^{\circ}\mathrm{C}$')
    notes.append({'id':f'dm-ch05-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['248'],'en':en,'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch05x',5,rows,notes,rr(121,4,8)+rr(122,1,6))
(W/'checkpoint_ch05x.json').write_text(json.dumps({'next_source_pdf_page':123,'next_source_block':1,'next_supplied_pdf_page':62,'next_supplied_block':8,'next_unit':len(rows)+298,'next_note':115,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
