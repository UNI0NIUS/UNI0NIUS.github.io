from materialism_common import *

groups=[]
for b in EN[289]['blocks'][1:]:
    for j,l in enumerate(b['lines']):
        x=l['bbox'][0]
        if x<80 or 225<x<250:groups.append([])
        groups[-1].append([290,b['block'],j,j+1])
def one(p,a,z):return [[[p,b]] for b in range(a,z+1)]
oldrefs=one(179,16,17)+[rr(179,18,19)]+one(179,20,27)+[rr(179,28,29)]+one(179,30,36)+[rr(179,37,38)]+one(179,40,43)+one(180,0,3)+[rr(180,4,5)]+one(180,6,20)+[rr(180,21,22)]+one(180,23,43)+one(181,0,2)+one(181,4,7)
assert len(groups)==len(oldrefs),(len(groups),len(oldrefs))
fixes={
 'Letters on Logic Especially Democratic-Proletarian Logic (Dietzgen)':('逻辑》','逻辑》（狄慈根）'),
 'Levy, Hyman':('莱维','列维'),
 'The logical structure of the world; pseudoproblems in philosophy (Carnap)':('《世界的逻辑结构：哲学中的伪问题》','《世界的逻辑构造；哲学中的伪问题》（卡尔纳普）'),
 'Logic of Empirical Theories (Przelecki)':('《经验理论的逻辑》','《经验理论的逻辑》（普热文茨基）'),
 'logikê':('logikē','logikê'),
 'Ludwig Feuerbach and the End of Classical German Philosophy (Engels)':('终结》','终结》（恩格斯）'),
 'Markov, Andrey':('马尔科夫','马尔可夫'),
 'Marxism and Problems of Linguistics (Stalin)':('《马克思主义与语言学问题》','《马克思主义与语言学问题》（斯大林）'),
 'Marxism and the Philosophy of Language (Vološinov)':('《马克思主义与语言哲学》','《马克思主义与语言哲学》（沃洛希诺夫）'),
 'The Marxist Philosophy and the Sciences (Haldane)':('《马克思主义哲学与科学》','《马克思主义哲学与科学》（霍尔丹）'),
 'Materialism and Empirio-criticism (Lenin)':('《唯物主义与经验批判主义》','《唯物主义和经验批判主义》（列宁）'),
 'mathematical logic':('数学逻辑','数理逻辑'),
 'The Mathematician in the Struggle (Levy)':('《斗争中的数学家》','《斗争中的数学家》（列维）'),
 'Meaning and Necessity: A Study in Semantics and Modal Logic (Carnap)':('研究》','研究》（卡尔纳普）'),
 'mechanism/mechanical':('机制/机械的','机械论/机械的'),
 'Men of Mathematics (Bell)':('《数学家传》','《数学家传》（贝尔）'),
 'model theory':('模型论','模型论'),
}
rows=[]
for i,(refs,zrefs) in enumerate(zip(groups,oldrefs),320):
    en=extract(EN,refs,True);old=extract(ZH,zrefs);zh=old
    m=re.search(r'\s+(\d[\d, ––-]*)$',en);assert m,en
    term=en[:m.start()].strip();locator=m[1]
    oldloc=re.search(r'(\d[\d, ––-]*)$',old);assert oldloc,old
    assert re.sub(r'\s','',oldloc[1])==re.sub(r'\s','',locator),(en,old)
    if term in fixes:
        a,b=fixes[term];assert a in zh,(term,zh);zh=zh.replace(a,b)
    row={'id':f'dm-index-{i:03}','kind':'index_entry','source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['281'],'en':en,'zh':zh,'supplied_zh':old,'index_term':term,'index_locators':locator,'index_level':0,'status':'text_compared_layout_pending'}
    if zh!=old:row['revision_reason']='补回作者括注、统一术语，逐项核对跨行条目和原索引页码。'
    if term in ['Mealey machine','Michaelson-Morely experiment']:row['editor_note']='英文拼写按原索引保留。'
    rows.append(row)
save('index05',13,rows,[],rr(290,1,23))
(W/'checkpoint_index05.json').write_text(json.dumps({'next_source_pdf_page':291,'next_supplied_pdf_page':181,'next_supplied_block':8,'next_index_entry':320+len(rows),'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
