from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch04-{len(rows)+23:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(74,1,2),rr(34,25),'heading')
add(rr(74,3),rr(34,26,31),end='在马克思博士论文',fixes=[('动力唯物主义','运动唯物主义（kinetic materialism）')],reason='此处kinetic强调运动，不是动能这个特定物理量。')
add(rr(74,4),rr(34,31,36),'quote',start='在马克思博士论文',text='马克思的运动理论，在其博士论文和《伊壁鸠鲁笔记》这些最早的著作中表现得最为鲜明和集中。早在阅读黑格尔之前，马克思就已经通过古代原子论展开对宗教的批判，并形成一种新的唯物主义理论。接触黑格尔之后，马克思在博士论文中同时批判了对古代原子论的反动现代主义解释和启蒙主义解释、唯物主义、唯心主义的自由理论、宗教，以及黑格尔的自然哲学。因此，马克思在博士论文中提出的运动理论和唯物主义，不仅仅是黑格尔思想的残余；这是他第一次尝试发展一种唯物主义的、以运动为基础的辩证法理论。（Nail，第20—21页）[[19]]',reason='原文并列批判对象被旧译全部纳入“所受的解释”，改变句法范围；kinetic不译动能论。')
add(rr(74,5),rr(34,37,41)+rr(35,0,4),end='存在与本质之间',fixes=[('动力唯物主义','运动唯物主义'),('“现实抽象”概念。','“现实抽象”概念。[[20]]')],reason='统一术语并补原注20。')
add(rr(74,6)+rr(75,1),rr(35,4,6),'quote',start='存在与本质之间')
add(rr(75,2),rr(35,7,13),end='其中一位')
add(rr(75,3),rr(35,13,21),'quote',start='其中一位',fixes=[('那些将现象视为真实的哲学家和教条主义者','那位将现象视为真实的哲学家和教条主义者'),('而他们那种解释方法','而他的解释方法')],reason='此处单数指伊壁鸠鲁，不能变成一类哲学家的复数。')
add(rr(75,4)+rr(76,1),rr(35,22,38),fixes=[('根本谬误之处。','根本谬误之处。[[23]]'),('模棱两可性','两义混淆'),('“现实抽象”的概念为例。','“现实抽象”的概念为例。[[26]]'),('大陆或“偶然”的永恒递归','偶然者（底本作 continent）或“偶然”的永恒递归'),('升华（das Aufgehobene）','扬弃（das Aufgehobene）')],reason='补原注23、26；continent按本段chance语境识别为疑似contingent笔误而非大陆，另加校注；Aufgehobene按黑格尔术语处理。')
rows[-1]['editor_note']='英文底本末句作continent，按语境疑为contingent（偶然者），中文加括注注明底本用词。底本以sublimation对应das Aufgehobene，中文按其黑格尔语境译“扬弃”；此处不是地理上的大陆或精神分析的升华。'
nt={19:'Thomas Nail：《运动中的马克思》（Marx in Motion）（Oxford University Press，Kindle版，2020），第20—21页。',20:'Alfred Sohn-Rethel：《脑力劳动与体力劳动：认识论批判》（Intellectual and Manual Labor: Critique of Epistemology）（伦敦：Macmillan，1978）。',21:'卡尔·马克思：“德谟克利特的自然哲学和伊壁鸠鲁的自然哲学的差别”，《马克思恩格斯全集》英文版第1卷（莫斯科：Progress Publishers，1975），无页码，引自Karl Marx Internet Archive，https://www.marxists.org/archive/marx/works/1841/dr-theses/index.htm（访问日期：2021年11月21日）。在线版本无页码（s.p.）；引文出自博士论文第二部分第三章。',22:'马克思：博士论文，无页码：“德谟克利特的自然哲学和伊壁鸠鲁的自然哲学的同一性所引起的困难”。',23:'拉鲁埃尔：《哲学与非哲学》，第51—53、227、228页。',24:'拉鲁埃尔：《哲学与非哲学》，第10页。',25:'拉鲁埃尔：《哲学与非哲学》，第12—13、20、24—29页及其他多处。',26:'Sohn-Rethel：《脑力劳动与体力劳动》，第13—35页。'}
notes=[]
for n,refs in note_groups([[251,1]]):
    if n not in nt:continue
    en=extract(EN,refs,True).replace('\u200b','').replace('archive/ marx','archive/marx')
    notes.append({'id':f'dm-ch04-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['242'],'en':en,'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch04c',4,rows,notes,rr(74,1,6)+rr(75,1,4)+rr(76,1))
(W/'checkpoint_ch04c.json').write_text(json.dumps({'next_source_pdf_page':76,'next_source_block':2,'next_supplied_pdf_page':35,'next_supplied_block':39,'next_unit':len(rows)+23,'next_note':27,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
