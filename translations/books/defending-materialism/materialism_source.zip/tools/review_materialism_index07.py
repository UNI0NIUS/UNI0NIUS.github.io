from materialism_common import *

groups=[]
for p in [292,293]:
    for b in EN[p-1]['blocks'][1:]:
        for j,l in enumerate(b['lines']):
            x=l['bbox'][0]
            if x<80 or 225<x<250:groups.append([])
            groups[-1].append([p,b['block'],j,j+1])
def one(p,a,z):return [[[p,b]] for b in range(a,z+1)]
oldrefs=one(183,1,10)+one(183,12,20)+one(183,22,43)+one(184,0,5)+one(184,7,43)+one(185,0,2)+one(185,4,32)+one(185,34,41)+one(185,43,43)+one(186,0,11)+one(186,13,24)+one(186,26,26)+one(186,28,29)
assert len(groups)==len(oldrefs),(len(groups),len(oldrefs))
fixes={
 'Przelecki, Marian':('普热莱茨基','普热文茨基'),
 'Revolt Against Formalism in the Soviet Union (Friedmann)':('《苏联反对形式主义的起义》','《苏联对形式主义的反抗》（弗里德曼）'),
 'The rigin of the Family Private Property and the State (Engels)':('《家庭、私有制和国家的起源》','《家庭、私有制和国家的起源》（恩格斯）'),
 'satisfaction problem (SAT)':('满足问题','可满足性问题'),
 'savagery maps':('野蛮状态图','蒙昧状态分布图'),
 'A Scientific Worker Looks at Dialectical Materialism (Levy)':('《一位科学工作者眼中的辩证唯物主义》','《一位科学工作者眼中的辩证唯物主义》（列维）'),
 'Socialism: Utopian and Scientific (Engels)':('《社会主义：空想与科学》','《社会主义从空想到科学的发展》（恩格斯）'),
 'A Text Book On Dialectical Materialism (Guest)':('《辩证唯物主义教科书》','《辩证唯物主义教科书》（盖斯特）'),
 'Toward Radical Metaphysics of Socialism (Kolozova)':('《迈向社会主义的激进形而上学》','《迈向社会主义的激进形而上学》（科洛佐娃）'),
 'Tractatus Logico-Philosophicus (Wittgenstein)':('《逻辑哲学论》','《逻辑哲学论》（维特根斯坦）'),
 'Two Dogmas of Empiricism (Quine)':('《经验主义的两个教条》','《经验主义的两个教条》（奎因）'),
 'The ‘Understanding’ of the Propositions of Mathematics (Guest)':('《对数学命题的“理解”》','《对数学命题的“理解”》（盖斯特）'),
 'Under the Banner of Marxism (Kolman and Yanovskaya)':('《在马克思主义的旗帜下》','《在马克思主义的旗帜下》（科尔曼和亚诺夫斯卡娅）'),
 'Vestiges of the Natural History of Creation (Chambers)':('《创世自然史遗迹》','《创世自然史遗迹》（钱伯斯）'),
 'The Visible College (Werskey)':('《可见学院》','《可见的学院》（韦尔斯基）'),
}
rows=[];parent=None
for i,(refs,zrefs) in enumerate(zip(groups,oldrefs),471):
    en=extract(EN,refs,True);old=extract(ZH,zrefs);zh=old
    m=re.search(r'\s+(\d[\d, ––-]*)$',en);assert m,en
    term=en[:m.start()].strip();locator=m[1]
    oldloc=re.search(r'(\d[\d, ––-]*)$',old);assert oldloc,old
    if term=='A Text Book On Dialectical Materialism (Guest)':
        assert locator=='84' and oldloc[1]=='184';zh=zh[:oldloc.start()]+'84'
    else:assert re.sub(r'\s','',oldloc[1])==re.sub(r'\s','',locator),(en,old)
    if term in fixes:
        a,b=fixes[term];assert a in zh,(term,zh);zh=zh.replace(a,b)
    row={'id':f'dm-index-{i:03}','kind':'index_entry','source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':[str(refs[0][0]-9)],'en':en,'zh':zh,'supplied_zh':old,'index_term':term,'index_locators':locator,'index_level':0,'status':'text_compared_layout_pending'}
    if term=='Ptolemy':parent=row['id']
    if term=='hypothesis':row['index_level']=1;row['index_parent']=parent
    if zh!=old:row['revision_reason']='补回书名作者括注、修正术语并核对原索引页码。'
    if term=='A Text Book On Dialectical Materialism (Guest)':row['editor_note']='原索引列84，旧译改为184；本版保留原书页码84，疑似原索引漏字，不静默修正。'
    if term=='The rigin of the Family Private Property and the State (Engels)':row['editor_note']='原索引rigin缺首字母，英文栏保留源书拼写。'
    rows.append(row)
save('index07',13,rows,[],rr(292,1,14)+rr(293,1,15))
(W/'checkpoint_index07.json').write_text(json.dumps({'index_text_complete':True,'index_entries':470+len(rows),'next_section':'front_matter','full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
