from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch05-{len(rows)+352:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(130,4),rr(65,27,35)+rr(66,0,3),'quote',fixes=[('这种不可能状态','这种不大可能的状态'),('相对短暂“永恒”时间','相对短暂的漫长年代'),('状态概率既可能增加，也可能减少','状态概率增加与减少同样频繁')],reason='improbable不是不可能，eons不是永恒，as often as表达频率相同而非两者皆可能。')
rows[-1]['editor_note']='底本本引文包含without without与to to重复，以及太阳距离20 million miles的原述；英文照录，中文不重复语词，距离按原述保留。'
add(rr(130,5),rr(66,4,6),fixes=[('第一个备选方案。','第一个备选方案。[[130]]')],reason='补回漏注130。')
add(rr(131,1),rr(66,7,11),fixes=[('没有特定方向','没有优先方向')])
add(rr(131,2),rr(66,12,13))
add(rr(131,3),rr(66,14,15))
nt={129:'Ludwig Boltzmann：“答策梅洛关于热理论的评论”（Reply to Zermelo’s Remarks on the Theory of Heat），载《气体动理论：经典论文选集及历史评注》（The Kinetic Theory Of Gases: An Anthology of Classic Papers with Historical Commentary）（World Scientific，2003），第412—419页。',130:'关于回归与不可逆性争论涉及的问题，可参见Jean Bricmont：“混沌的科学还是科学中的混沌？”（Science of Chaos or Chaos in Science?），arXiv预印本chao-dyn/9603009，1996。',131:'相关讨论参见Rüdiger Vaas：“时间之前的时间：当代宇宙学中的宇宙分类，以及如何避免世界开端与永恒的二律背反”（Time before Time-Classifications of Universes in Contemporary Cosmology, and How to Avoid the Antinomy of the Beginning and Eternity of the World），arXiv预印本physics/0408111，2004。',132:'Steven Frautschi：“膨胀宇宙中的熵”（Entropy in an Expanding Universe），Science，第217卷第4560期（1982），第593—599页。'}
notes=[]
for n,refs in note_groups(rr(258,1)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch05-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['249'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch05ze',5,rows,notes,rr(130,4,5)+rr(131,1,3))
(W/'checkpoint_ch05ze.json').write_text(json.dumps({'next_source_pdf_page':131,'next_source_block':4,'next_supplied_pdf_page':66,'next_supplied_block':16,'next_unit':len(rows)+352,'next_note':133,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
