from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch05-{len(rows)+123:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(98,4),rr(47,33,36),'figure',text='图5.1 以维多利亚时期的一个经济周期说明马克思的资本积累一般规律。该规律描述了一个循环过程：相对充分就业的时期（1881—1883年）使工资得以上涨。资本家的应对是投资于节省劳动的机器（1882—1885年）。这使工人加入劳动后备军，并导致工资下降（1883—1887年）。在这一较低工资水平上，资本家再次雇佣更多工人，工资开始上涨，循环重新开始。这样的周期通常略短于十年。作者绘图。',reason='恢复原图及旧译图注遗漏的维多利亚经济周期说明。')
rows[-1].update(image='assets/figure-5-1.png',source_image={'pdf_page':98,'block':3,'xref':638},image_labels_zh='Marxian cycle of accumulation：马克思式积累周期；实线rate of change of money wage：货币工资变化率；点线reserve army of labour：劳动后备军；虚线fixed capital accumulation as a percent of profit：固定资本积累占利润的百分比；横轴数字为年份。')
add(rr(98,1),rr(47,37)+rr(48,0,4),fixes=[('C\\to M\\to C',r'$C\to M\to C$'),("M\\to C\\to M'",r"$M\to C\to M'$"),('先进共产主义','高级共产主义')],english=extract(EN,rr(98,1),True).replace('C M C → →',r'$C\to M\to C$').replace('M C M',r"$M\to C\to M'$"))
add(rr(98,2)+rr(99,1),rr(48,5,12),'quote',fixes=[('社会秩序','社会制度'),('社会经济形成过程','社会经济形态演进过程'),('[[5]] [[1]]','[[51]]')])
add(rr(99,2),rr(48,13),'heading',text='修辞与发现的区别')
add(rr(99,3),rr(48,14,16),fixes=[('[[5]] [[2]]','[[52]]')])
rows[-1]['editor_note']='底本句末given by后未写作者姓名而直接接原注52；译文保留省略形式，由原注标明所引文献。'
add(rr(99,4),rr(48,17,21),end='正如他',fixes=[('1840 年代','1840年代')])
add(rr(99,5),rr(48,21,23),'quote',start='正如他',fixes=[('[[5]] [[3]]','[[53]]')])
add(rr(99,6),rr(48,24,26),fixes=[('根本没有提到异化劳动。','根本没有提到异化劳动。[[54]]'),('Athan Hussain','Athar Hussain'),('[[5]] [[5]]','[[55]]')],reason='补回遗漏原注54，恢复原文人名Athar拼写。')
add(rr(99,7),rr(48,27),end='从这个意义')
add(rr(99,8),rr(48,27,29),'quote',start='从这个意义')
add(rr(99,9),rr(48,30,32),end='它通过',text='在《资本论》第一卷的英译本中，alienation一词只以亚当·斯密所用的旧苏格兰法律含义出现，即财产的出售或赠与。卖掉房屋，就是将它让渡出去（alienate）。这就是该词在《资本论》中的含义。例如，以下几段引自该书：[[56]]',reason='区分alienation的法律意义“让渡”与哲学意义“异化”，补回原注56。')
add(rr(100,1),rr(48,32,33),'quote',start='它通过',fixes=[('商品的一般异化','商品的普遍让渡')],reason='本段所论为出售/让渡，旧译“一般异化”抹去了作者着力辨析的词义。')
add(rr(100,2),rr(48,34),'quote')
add(rr(100,3),rr(48,35,37),fixes=[('《经济学手稿》（EPM）','《1844年经济学哲学手稿》（EPM）')])
nt={51:'Karl Marx、Salomea W. Ryazanskaya与Maurice Dobb：《政治经济学批判》（A Contribution to the Critique of Political Economy）（Progress Publishers，1978），序言。',52:'Guido Starosta：“商品形式与辩证方法：论马克思在《资本论》第一章中的叙述结构”（The Commodity-form and the Dialectical Method: On the Structure of Marx’s Exposition in Chapter 1 of Capital），Science & Society，第72卷第3期（2008），第295—318页。',53:'Starosta：“商品形式与辩证方法：论马克思在《资本论》第一章中的叙述结构”，第298页。',54:'卡尔·马克思：“阿道夫·瓦格纳边注”（Notes on Adolph Wagner），Texts on Method（1975），第201页。',55:'Diane Elson：《价值：资本主义中劳动的表现》（Value: The Representation of Labour in Capitalism）（Verso Books，2016），重印本。',56:'马克思：《资本论》，第3章。'}
notes=[]
for n,refs in note_groups([[255,4,4,15]]):
    notes.append({'id':f'dm-ch05-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['246'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch05j',5,rows,notes,rr(98,1,2)+rr(98,4)+rr(99,1,9)+rr(100,1,3))
(W/'checkpoint_ch05j.json').write_text(json.dumps({'next_source_pdf_page':100,'next_source_block':4,'next_supplied_pdf_page':49,'next_supplied_block':0,'next_unit':len(rows)+123,'next_note':57,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
