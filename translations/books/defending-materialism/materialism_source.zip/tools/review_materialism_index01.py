from materialism_common import *

groups=[]
for b in EN[285]['blocks'][1:]:
    for j,l in enumerate(b['lines']):
        x=l['bbox'][0]
        if x<80 or 225<x<250:groups.append([])
        groups[-1].append([286,b['block'],j,j+1])
oldrefs=rr(171,25,26)+rr(172,0,30)+rr(172,32,43)+rr(173,0,25)
assert len(groups)==len(oldrefs)==71
rows=[{'id':'dm-index-title','kind':'chapter','source_blocks':rr(286,0),'supplied_translation_blocks':rr(171,22),'printed_pages':['277'],'en':'INDEX','zh':'索引','supplied_zh':'索引','status':'text_compared_layout_pending'}]
fixes={
 'All-Union Communist Party':('全联盟共产党','全联盟共产党'),
 'Anti-Dühring (Engels)':('《反杜林论》','《反杜林论》（恩格斯）'),
 'aporia':('悖论','疑难'),
 'Aspects of Dialectical Materialism (Levy)':('《辩证唯物主义的各个方面》','《辩证唯物主义的各个方面》（列维）'),
 'atomos':('原子','不可分者（原子）'),
 'Axiomatic Thought (Hilbert)':('《公理化思维》','《公理化思维》（希尔伯特）'),
 'barbarism maps':('蒙昧状态图','野蛮状态分布图'),
 'Basic Laws of Arithmetic (Frege)':('《算术基本定律》','《算术基本定律》（弗雷格）'),
 'Begriffsschrift (Frege)':('《概念文字》','《概念文字》（弗雷格）'),
 'caloric':('热量','热质'),
}
for i,(refs,zref) in enumerate(zip(groups,oldrefs),1):
    en=extract(EN,refs,True);old=extract(ZH,[zref]);zh=old
    # Index locators are checked against the original, not inferred from output pages.
    m=re.search(r'\s+(\d[\d, ––-]*)$',en);assert m,en
    term=en[:m.start()].strip();locator=m[1]
    oldloc=re.search(r'(\d[\d, ––-]*)$',old);assert oldloc,old
    assert re.sub(r'\s','',oldloc[1])==re.sub(r'\s','',locator),(en,old)
    if term in fixes:
        a,b=fixes[term];zh=zh.replace(a,b)
    row={'id':f'dm-index-{i:03}','kind':'index_entry','source_blocks':refs,'supplied_translation_blocks':[zref],'printed_pages':['277'],'en':en,'zh':zh,'supplied_zh':old,'index_term':term,'index_locators':locator,'index_level':0,'status':'text_compared_layout_pending'}
    if term=='model of the atom':
        row['index_level']=1;row['index_parent']='dm-index-047'
        row['editor_note']='原书此项为Bohr, Niels条目下的子项；中文保留“玻尔原子模型”便于独立检索。'
    if zh!=old:row['revision_reason']='修正术语或补回原索引的作者括注；逐项核对页码。'
    rows.append(row)
save('index01',13,rows,[],rr(286,0,13))
(W/'checkpoint_index01.json').write_text(json.dumps({'next_source_pdf_page':287,'next_supplied_pdf_page':173,'next_supplied_block':26,'next_index_entry':72,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
