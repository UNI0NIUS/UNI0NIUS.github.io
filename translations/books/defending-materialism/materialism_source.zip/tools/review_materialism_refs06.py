from materialism_common import *
groups=[]
for b in EN[277]['blocks'][1:]:
    for j,l in enumerate(b['lines']):
        if b['block']==1 and j<2:continue
        if l['bbox'][0]<62:groups.append([])
        groups[-1].append([278,b['block'],j,j+1])
oldrefs=[rr(160,28,29),rr(161,0,1),rr(161,2),rr(161,3,4),rr(161,5,6),rr(161,7,8),rr(161,9,10),rr(161,11),rr(161,12),rr(161,13,14),rr(161,15),rr(161,16,18),rr(161,19,20),rr(161,21),rr(161,22,23),rr(161,24,25),rr(161,26,27),rr(162,0),rr(162,1,2),rr(162,3),rr(162,4,5),rr(162,6,7),rr(162,8,9)]
translations=[
'戈特洛布·弗雷格：“致罗素的信”。载《从弗雷格到哥德尔：数理逻辑文献集，1879—1931》，J. van Heijenoort编，126—128。Harvard University Press，1967。',
'戈特洛布·弗雷格：《算术的基本规律：系统的阐述》。M. Furth译。University of California Press，1964。',
'戈特洛布·弗雷格：《算术基础》。J. L. Austin译。Harper，1953。',
'Georges Friedmann：“苏联对形式主义的反抗”。Science & Society 2，第3期（1938）：300—321。',
'Uriel B. Frisch、Brosl Hasslacher、Yves Pomeau：“用于纳维—斯托克斯方程的格气自动机”。Physical Review Letters 56（1986）：1505—1508。',
'Galen、Arthur John Brock：《盖伦论自然能力，附英译》。W. Heinemann，1916。',
'伽利略·伽利莱：《关于两大世界体系的对话》（1632）。Robert C. Kuhmann，2006。http://www.kuhmann.com/starstuff/DialogueConcerningtheTwoChiefWorldSystems.pdf。',
'伽利略·伽利莱：《关于两门新科学的对话》。Dover，1914。',
'Gao, Shan：“引力是熵力吗？”Entropy 13，第5期（2011）：936—948。',
'Ian P. Gent、Ewan MacIntyre、Patrick Prosser、Toby Walsh：“CSP相变中的尺度效应”。载International Conference on Principles and Practice of Constraint Programming，70—87。Springer，1995。',
'Slava Gerovitch：《从新话到控制论话语：苏联控制论史》。MIT，2002。',
'库尔特·哥德尔：“论《数学原理》及相关系统中形式上不可判定的命题”。载《从弗雷格到哥德尔：数理逻辑文献集，1879—1931》，J. van Heijenoort编，596—616。Harvard University Press，1967。',
'Stephen Jay Gould：《熊猫的拇指：对自然史的进一步思考》。W.W. Norton & Company，2010。',
'David Guest：《辩证唯物主义教科书》。Lawrence & Wishart，1939。',
'David Guest：“数学形式主义：1929”。载《大卫·盖斯特：一位科学家为自由而战》，C. H. Guest编，207—210。Lawrence & Wishart，1939。',
'David Guest：“评E. T. Bell《数学家们》，载《劳动月刊》，1937年10月”。载《大卫·盖斯特：一位科学家为自由而战》，C. H. Guest编，252—256。Lawrence & Wishart，1939。',
'David Guest：“对数学命题的‘理解’：1930”。载《大卫·盖斯特：一位科学家为自由而战》，C. H. Guest编，211—213。Lawrence & Wishart，1939。',
'Ruth Hagengruber：《莱布尼茨与牛顿之间的埃米莉·杜·夏特莱》。Springer，2012。',
'John B. S. Haldane：“序言”。载《自然辩证法》。USSR，1939。https://www.marxists.org/archive/marx/works/1883/don/preface.htm。',
'John B. S. Haldane：《马克思主义哲学与科学》。George Allen & Unwin Ltd，1938。',
'William Hamilton：《形而上学与逻辑学讲演录》。第1卷。H. L. Mansel、J. Veitch编。William Blackwood / Sons，1866。',
'Jozef Hanc、Slavomir Tuleja、Martina Hancova：“对称性与守恒定律：诺特定理的推论”。American Journal of Physics 72，第4期（2004）：428—435。',
'Donald Olding Hebb：“行为的组织：一种神经心理学理论”。A Wiley Book in Clinical Psychology 62（1949）：78。'
]
assert len(groups)==len(oldrefs)==len(translations)==23
rows=[]
for i,(refs,zrefs,zh) in enumerate(zip(groups,oldrefs,translations),112):
    raw=extract(EN,refs,True);en=raw.replace('\u200b','').replace('oChi efWo','oChiefWo').replace('org /archive/ marx','org/archive/marx')
    row={'id':f'dm-ref-{i:03}','kind':'bibliography','source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['269'],'en':en,'zh':zh,'supplied_zh':extract(ZH,zrefs),'status':'text_compared_layout_pending','revision_reason':'逐条核对并补译题名，保留完整编者译者和出版信息。'}
    if en!=raw:row['source_transcription_note']='去除零宽字符及URL内换行空格；原始span保留。'
    if i==114:row['editor_note']='原书英文题名拼作The Foundations of Arithemtic，中文按《算术基础》译出，英文保留原拼写。'
    if i in (126,127,128):row['editor_note']='原书文集题名末词拼作Freedon，英文照录，中文按自由译出。'
    if i==134:row['editor_note']='原书题名中拼作Neuropsycholocigal，英文照录；中文译神经心理学。'
    rows.append(row)
save('refs06',12,rows,[],[[278,1,2,3]]+rr(278,2,19))
(W/'checkpoint_refs06.json').write_text(json.dumps({'next_source_pdf_page':279,'next_source_block':1,'next_supplied_pdf_page':162,'next_supplied_block':10,'next_reference':135,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
