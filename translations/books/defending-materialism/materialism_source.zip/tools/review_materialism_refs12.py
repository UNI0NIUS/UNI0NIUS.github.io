from materialism_common import *

groups=[]
for p in [284,285]:
    for b in EN[p-1]['blocks'][1:]:
        for j,l in enumerate(b['lines']):
            if l['bbox'][0]<(62 if p==284 else 60):groups.append([])
            groups[-1].append([p,b['block'],j,j+1])
oldrefs=[rr(169,22,23),rr(169,24,25),rr(169,26),rr(169,27)+rr(170,0),rr(170,1,2),rr(170,3),rr(170,4),rr(170,5,6),rr(170,7),rr(170,8),rr(170,9),rr(170,10,11),rr(170,12),rr(170,13,14),rr(170,15,16),rr(170,17,18),rr(170,19,21),rr(170,22,23),rr(170,24,25),rr(170,26,27),rr(171,0,1),rr(171,2,3),rr(171,4),rr(171,5),rr(171,6),rr(171,7),rr(171,8,9),rr(171,10),rr(171,11,12),rr(171,13,15),rr(171,16),rr(171,17,18),rr(171,19),rr(171,20,21)]
translations=[
'Guido Starosta：“商品形式与辩证方法：论马克思在《资本论》第一章中的叙述结构”。Science & Society 72，第3期（2008）：295—318。',
'Statista：“中国共产党”。载Topics。Statista，2021。https://www.statista.com/topics/1247/chinese-communist-party/。',
'John Strachey：《关于不同土层与矿物层的观察》。1730。',
'Adrian Tait：“[一种]神秘、不可言说的力量与能量”。《阿瑟·梅钦：批评论文集》，2021，193。\n\nJohn R Taylor等：《经典力学》。University Science Books，2005。',
'William Thomson：“能量耗散的动力学理论”。Proceedings of the Royal Society of Edinburgh 8（1875）：325—334。',
'Mary Tiles：《集合论哲学：康托尔乐园的历史导论》。Dover，1989。',
'Sebastiano Timpanaro：《论唯物主义》。Routledge，2003。',
'Lyudmila N. Trut、I. Z. Plyusnina、I. N. Oskina：“狐狸驯化实验与犬进化中的争议问题”。Russian Journal of Genetics 40，第6期（2004）：644—655。',
'Peter Turchin、Sergey A. Nefedov：“长期周期”。载《长期周期》。Princeton University Press，2009。',
'Valentin F. Turchin：“一种元算法语言”。Kibernetika 4，第4期（1967）：45—54。',
r'艾伦·M. 图灵：“可计算性与$\lambda$可定义性”。Journal of Symbolic Logic 2（1937）：153—164。',
'艾伦·M. 图灵：“论可计算数及其在判定问题上的应用”。Proceedings of the London Mathematical Society s2–42，第1期（1937）：230—265。',
'John Tyndall：《作为一种运动形式的热》。D. Appleton / Company，1875。',
'Steven T. Usdin：《构建共产主义：两名美国人如何为斯大林从事间谍活动并创建苏联硅谷》。Yale University Press，2005。',
'Rüdiger Vaas：“时间之前的时间——当代宇宙学中的宇宙分类，以及如何避免世界开端与永恒的二律背反”。arXiv预印本physics/0408111，2004。',
'Antony Valentini：“信号局域性、不确定性与亚量子H定理，I”。Physics Letters A 156，第1—2期（1991）：5—11。',
'Mark van Atten、Goran. Sundholm：“L. E. J. 布劳威尔的《逻辑原则的不可靠性》：附导言的新译本”。History and Philosophy of Logic 38，第1期（2017）。https://doi.org/10.1080/01445340.2016.1210986。',
'Ioannis M. Vandoulakis：“论A. A. 马尔可夫对布劳威尔直觉主义的态度”。Philosophia Scientiæ 19-1（2015）：143—158。',
'Erik Verlinde：“论引力的起源与牛顿定律”。Journal of High Energy Physics 2011，第4期（2011）：1—27。',
'Valentin N. Vološinov：《马克思主义与语言哲学》。L. Matejka、I. R. Tutunik译。Seminar Press，1986。',
'约翰·冯·诺伊曼：《关于EDVAC的报告初稿》。宾夕法尼亚大学莫尔电气工程学院，1945。http://web.mit.edu/STS.035/www/PDFs/edvac.pdf。',
'Alexander Vucinich：“苏联的数学与辩证法：斯大林之前的时期”。Historia Mathematics 26（1999）：107—124。',
'Alister G. D. Watson：“数学及其基础”。Mind 47，第188期（1938）：440—451。',
'Harry K. Wells：《西格蒙德·弗洛伊德：巴甫洛夫学派的批判》。International Publishers，1960。',
'Gary Werskey：《可见的学院》。Allan Lane，1978。',
'Richard Whately：《逻辑原理》。James Munroe & Company，1845。',
'Alfred N. Whitehead、伯特兰·罗素：《数学原理》。Cambridge University Press，1910、1912、1913。',
'Norbert Wiener：《控制论，或关于在动物和机器中控制与通信的科学》。MIT Press，1948。',
'Wikipedia：“圣公宗”。载Wikipedia。Wikipedia，2021。https://en.wikipedia.org/wiki/Anglican_Communion。',
'Adam S. Wilkins、Richard W. Wrangham、W. Tecumseh Fitch：“哺乳动物的‘驯化综合征’：基于神经嵴细胞行为与遗传学的统一解释”。Genetics 197，第3期（2014）：795—808。',
'路德维希·维特根斯坦：《哲学研究》。G. E. M. Anscombe译。Blackwell，1958。',
'路德维希·维特根斯坦：《逻辑哲学论》。D. F. Pears、B. F. McGuinness译。Routledge/Kegan Paul，1961。',
'Peter Wolfendale：《面向对象的哲学：本体的新衣》。第1卷。MIT Press，2019。',
'David Zachariah：《在瑞典检验劳动价值论》。2004。http://reality.gn.apc.org/econ/DZ_article1.pdf。'
]
assert len(groups)==len(oldrefs)==len(translations)==34
rows=[]
for i,(refs,zrefs,zh) in enumerate(zip(groups,oldrefs,translations),252):
    raw=extract(EN,refs,True);en=raw.replace('\u200b','').replace('λ',r'$\lambda$')
    for a,b in [('topics/ 1247','topics/1247'),('/ PDFs/','/PDFs/'),('wikipedia .org','wikipedia.org'),('apc .org','apc.org')]:en=en.replace(a,b)
    if i==255:en=en.replace('193. Taylor','193.\n\nTaylor')
    row={'id':f'dm-ref-{i:03}','kind':'bibliography','source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':[str(refs[0][0]-9)],'en':en,'zh':zh,'supplied_zh':extract(ZH,zrefs),'status':'text_compared_layout_pending','revision_reason':'逐条核对作者、题名、出版信息及链接；补译旧稿中仅保留英文的题名。'}
    if en!=raw:row['source_transcription_note']='清理网址排版空格及零宽字符，希腊字母恢复数学字形；同一源行包含两条书目时增加段落分隔。'
    if i==255:row['bibliography_entry_count']=2
    if i==263:row['editor_note']='英文题名中的Entscheidungsprob-Lem为源书写法，未随旧译静默改写。'
    if i==268:row['editor_note']='作者名Goran. Sundholm的标点与拼写按源书保留。'
    rows.append(row)
save('refs12',12,rows,[],rr(284,1,19)+rr(285,1,9))
(W/'checkpoint_refs12.json').write_text(json.dumps({'next_source_pdf_page':286,'next_supplied_pdf_page':171,'next_supplied_block':22,'next_section':'index','full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
