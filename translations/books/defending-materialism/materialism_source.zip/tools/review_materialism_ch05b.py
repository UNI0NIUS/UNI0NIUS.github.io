from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch05-{len(rows)+26:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(83,5)+rr(84,1),rr(39,21,25),'quote',start='据称')
add(rr(84,2),rr(39,26,32),'quote',fixes=[('氏族、宗族或部落','氏族、胞族或部落'),('认可了这种假定','认可了这种僭越')],reason='phratry在此为胞族；presumption指贵族对特权的僭取，不是理论假设。')
add(rr(84,3),rr(39,33,34))
add(rr(84,4),rr(39,35,36))
add(rr(84,5),rr(39,37,38)+rr(40,0))
add(rr(84,6),rr(40,1,2))
add(rr(84,7),rr(40,3,4),end='我们现在要说明')
add(rr(84,8),rr(40,4,5),'quote',start='我们现在要说明')
add(rr(84,9)+rr(85,1),rr(40,6,10),fixes=[('绝对君主制','专制君主制')])
add(rr(85,2),rr(40,11,17),end='所有亚洲政权')
add(rr(85,3),rr(40,17,18),'quote',start='所有亚洲政权')
add(rr(85,4),rr(40,19,24),fixes=[('《法学讲义》','《法理学讲义》')],reason='统一同书名称。')
nt={9:'恩格斯、Hunt：《家庭、私有制和国家的起源》，第V章。',10:'斯密：《法理学讲义》，《亚当·斯密著作与通信格拉斯哥版》，第I部分第6节。',11:'值得注意的是，同一过程也在美利坚帝国发生。其公民逐渐不再喜欢战争的艰辛，因此从20世纪80年代开始，它越来越多地雇用阿富汗人和阿拉伯人作战；本·拉登后来让他的追随者转而攻击昔日支付报酬的雇主。若能以历史为鉴，类似事情不会是最后一次发生。',12:'Ibn Khaldun、Franz Rosenthal、Nessim Joseph Dawood：《历史绪论：历史学导论，三卷本》（The Muqaddimah: An Introduction to History; in Three Volumes）（普林斯顿大学出版社，1969），第1卷第43页。',13:'Bartkus和Hassan（“伊本·赫勒敦与亚当·斯密：对劳动分工理论及现代经济思想的贡献”，Ibn Khaldun and Adam Smith: Contributions to the Theory of the Division of Labor and Modern Economic Thought）推测，斯密的思想源自赫勒敦，牛顿则抄用了后来失传的阿基米德著作。'}
notes=[]
for n,refs in note_groups([[252,3]]):
    if n not in nt:continue
    notes.append({'id':f'dm-ch05-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['243'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch05b',5,rows,notes,rr(83,5)+rr(84,1,9)+rr(85,1,4))
(W/'checkpoint_ch05b.json').write_text(json.dumps({'next_source_pdf_page':85,'next_source_block':5,'next_supplied_pdf_page':40,'next_supplied_block':25,'next_unit':len(rows)+26,'next_note':14,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
