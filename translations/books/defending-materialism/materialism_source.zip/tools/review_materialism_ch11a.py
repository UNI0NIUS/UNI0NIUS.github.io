from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch11-{len(rows)+1:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(222,0,1),rr(116,21),'chapter',text='第11章 辩证唯物主义与机械论唯物主义',english='Chapter 11: DIALECTICAL VERSUS MECHANIST MATERIALISMS')
rows[-1]['source_transcription_note']='恢复标题阅读顺序。'
add(rr(222,2),rr(116,22),'heading',text='信息论与唯物主义')
add(rr(222,3),rr(116,23,28),text='20世纪中叶以来，信息技术改变了我们与世界的互动方式，信息论也使科学与哲学发生根本转变。这些进展鲜明地表明，认识中最根本的变化，往往可以源于实践要求。19世纪，革新了我们对时间、秩序和生命的理解的热力学，来自蒸汽机工程师的实际需要。我们已经提到，20世纪30年代末，克劳德·香农认识到布尔代数为理解开关电路提供了形式体系。当时，他在美国电报电话公司贝尔工作。他使用布尔代数，是为了使自动电话交换机的设计合理化。随后，布尔代数逐渐成为支撑数字电路的框架；这些电路用于20世纪40年代和50年代新兴的计算机技术。')
add(rr(222,4),rr(116,29,30)+rr(117,0,3),text='香农的贡献并未止于此。他接着创立了现代信息论。如今已很平常的观念——信息可以用比特客观计量——来自他为贝尔写的一篇技术论文。[[1]]电报工程师在实践中必须估算不同信息传输方式的容量：普通电报线、使用频分复用的电缆、无线电链路等。为此，需要共同的计量单位。这类似于约一个半世纪前瓦特面临的问题：如何量化不同动力形式所提供的功。当时的办法是定义一匹标准马的功率。对20世纪中叶已经习惯于取值为[0,1]的布尔逻辑的工程师而言，信息的自然单位就是比特。',reason='区分work与power：功与功率；恢复standard horse原意。')
add(rr(222,5),rr(117,4,6),text='如果他仅仅务实地采用二进制数字，即同时代工程师已熟悉的东西，其工作的影响就会有限。它之所以具有革命性，是因为他没有止步于布尔，而是进一步用概率论来定义比特。[[2]]他不只说比特是0或1，而将其定义为区分两个等概率结果所用的信息量。')
add(rr(223,1),rr(117,7,9),text='假设纽约的爱丽丝抛一枚公平硬币三次。波士顿的鲍勃知道，每次正面和反面出现的概率相等，却不知道爱丽丝哪次抛出了正面，哪次抛出了反面。如果爱丽丝用电传机向鲍勃传送结果序列，那么无论她采用什么编码，无论是')
for j,t in enumerate(['HEADS（正面）','HEADS（正面）','TAILS（反面）']):
    add([[223,2,j,j+1]],rr(117,9),'quote',text=t,reason='按源图保留三个独立电传行；保留英文字符以对应105位计算。')
add(rr(223,3),rr(117,10,13),text='还是HHT或110，按香农的理论，她都只向鲍勃发送了3比特信息。如果采用20世纪40年代使用的5位二进制博多码，第一种逐词拼出的方式就需要105个二进制位。[[3]]若用HHT，则发送15个二进制位；若在线路上发送原始二进制数据，就只用3个二进制位。')
add(rr(223,4),rr(117,14,15),text='因此，对香农而言，信息与数据不同。数据编码信息的效率可能很低。第一个英语文本例子的效率，仅为最紧凑编码的三十五分之一。',reason='避免旧译低三十五倍的数量表达歧义。')
add(rr(223,5),rr(117,16),text='目前我们只考虑了典型的公平硬币。如果硬币很不公平呢？')
add([[223,6,0,1]],rr(117,17),text='如果你的随机数发生器有偏呢？')
add([[223,6,1,2]],rr(117,18),text='如果硬币有四分之三的概率正面朝上呢？')
add([[223,6,2,9]],rr(117,19,21),text='那么显然，每次传送一条“正面”消息，发送的信息都必定少于公平硬币的情形。看到一长串抛掷结果后，鲍勃能估计正面的先验概率。如果要猜下一条消息，他每次都会猜正面，这样猜对的比例就会超过50%。因此，现在每条“正面”消息携带的信息都比以前少，不到1比特。')
add(rr(223,7),rr(117,22,23),text=r'香农提出了一个公式，计算这种有偏符号流的信息量。假设长数据流有$n$种可能的不同符号，第$i$种符号出现的概率为$p_i$，则每个数据符号的平均信息量为',english=r'Shannon came up with a formula for the information content of such biased streams of symbols. Suppose we have a long data stream with $n$ possible distinct symbols, such that the $i$th symbol occurs in our stream with probability $p_i$, then the average information content per data symbol is given by')
formula=r'H=-\sum_{i=1}^{n}p_i\log_2(p_i)'
add(rr(223,8,14),rr(117,24),'formula',text='$'+formula+'$',english='$'+formula+'$',reason='依源图恢复求和号、上下限、负号及对数底数。')
rows[-1]['math_lines']=[formula]
add([[223,15,0,5]],rr(117,25),text=r'负号保证得到正的结果，因为这些概率都小于1，因此$\log_2(p_i)<0$。',english=r'The minus sign is there to ensure we get a positive result since the probabilities are all <1.and hence $\log_2(p_i)<0$.',reason='依原图恢复损坏的不等式，不把旧译额外条件当成原文。')
add([[223,15,5,10]],rr(117,26,28),text='所有不同符号等概率出现时，这一公式达到最大值。但人类语言不是这样，书面文本中字母的出现频率很不均匀。按香农的说法，这意味着书面文本即使在最基本的字符层面，也有效率不足或冗余。')
nt={1:'Shannon：“通信的数学理论”。',2:'费希尔在此前十年已经尝试用概率定义信息：Ronald Aylmer Fisher，“不确定推理逻辑中的概率、似然与信息量”，Proceedings of the Royal Society of London. Series A, Containing Papers of a Mathematical and Physical Character 146，第856期（1934）：1—8；但香农的处理更为一般，影响也更持久。',3:r'每个单词5个字符，加上行末的回车与换行字符，每词便有$(5+2)\times5=35$个二进制位，再乘以3个单词。'}
notes=[]
for n,refs in note_groups(rr(270,3)):
    if n not in nt:continue
    en=extract(EN,refs,True)
    if n==3:en=r'3 Five characters per word, plus carriage return and line feed characters at the end of lines so $(5+2)\times5=35$ binary digits per word, × three words.'
    notes.append({'id':f'dm-ch11-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['261'],'en':en,'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
notes[-1]['source_transcription_note']='注3公式依据源PDF270图像恢复，原始span保留。'
save('ch11a',11,rows,notes,rr(222,0,5)+rr(223,1,15))
(W/'checkpoint_ch11a.json').write_text(json.dumps({'next_source_pdf_page':224,'next_source_block':1,'next_supplied_pdf_page':117,'next_supplied_block':29,'next_unit':len(rows)+1,'next_note':4,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
