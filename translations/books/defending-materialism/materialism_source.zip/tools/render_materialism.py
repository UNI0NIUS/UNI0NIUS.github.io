"""Build cumulative reading copies from explicitly reviewed canonical packets."""
from materialism_common import *
from itertools import groupby
import subprocess,sys
O=R/'Defending Materialism/output';O.mkdir(exist_ok=True)
raw_packets=sorted((json.loads(p.read_text('utf8')) for p in sorted((W/'packets').glob('*.json'))),key=lambda d:d['reading_order'])
bychapter={}
for p in raw_packets:
    ch=p['chapter']
    if ch not in bychapter:bychapter[ch]={'chapter':ch,'units':[],'notes':[]}
    bychapter[ch]['units'].extend(p['units']);bychapter[ch]['notes'].extend(p['notes'])
packets=list(bychapter.values())
for p in packets:
    assert len({u['id'] for u in p['units']})==len(p['units'])
    assert len({n['note_number'] for n in p['notes']})==len(p['notes'])
def plain(s):
    return ''.join({'∝':r'\ensuremath{\propto}','\\':r'\textbackslash{}','&':r'\&','%':r'\%','$':r'\$','#':r'\#','_':r'\_','{':r'\{','}':r'\}','~':r'\textasciitilde{}','^':r'\textasciicircum{}'}.get(c,c) for c in s)
def esc(s,ch,anchor=False):
    out=[];last=0
    for m in re.finditer(r'\[\[(\d+)\]\]|\$[^$]+\$|(?:https?|ttps)://[^\s。；，（）\u4e00-\u9fff]+',s):
        out.append(plain(s[last:m.start()]));n=m[1]
        if n is None:
            if m[0].startswith('$'):out.append(m[0])
            else:
                url=m[0].rstrip('.,;)');out.append(r'\url{'+url.replace('\u200b','')+'}'+plain(m[0][len(url):]))
            last=m.end();continue
        out.append((r'\hypertarget{ref-'+ch+'-'+n+'}{}' if anchor else '')+r'\hyperlink{note-'+ch+'-'+n+r'}{\textsuperscript{'+n+'}}');last=m.end()
    out.append(plain(s[last:]));return ''.join(out)
def english(u,ch,anchor=False):
    # Locate italic source spans in canonical text; never replace canonical wording.
    runs=[];raw=[]
    for p,b,j,l in lines(EN,u['source_blocks']):
        for s in l['spans']:
            if s['flags']&1:continue
            text=s['text'];style='i' if s['flags']&2 else ''
            if raw and raw[-1][0]==style:raw[-1]=(style,raw[-1][1]+text)
            else:raw.append((style,text))
        if raw:raw[-1]=(raw[-1][0],raw[-1][1]+' ')
    protected=[(m.start(),m.end()) for m in re.finditer(r'\$[^$]+\$|(?:https?|ttps)://[^\s]+',u['en'])]
    for style,s in raw:
        if style!='i':continue
        term=re.sub(r'\s+',' ',s).strip()
        if term and term in u['en']:
            for m in re.finditer(r'(?<!\w)'+re.escape(term)+r'(?!\w)',u['en']):
                if not any(m.start()<b and m.end()>a for a,b in protected):runs.append((m.start(),m.end()))
    runs=sorted(set(runs));out=[];last=0
    for a,b in runs:
        if a<last:continue
        out.extend([esc(u['en'][last:a],ch,anchor),r'\emph{'+esc(u['en'][a:b],ch,anchor)+'}']);last=b
    out.append(esc(u['en'][last:],ch,anchor));return ''.join(out)
PRE=r'''\documentclass[10pt,a4paper,twoside]{article}
\usepackage{fontspec,xeCJK}
\setmainfont{Times New Roman}
\setCJKmainfont[AutoFakeBold=2,AutoFakeSlant=.2]{SimSun}
\setCJKmonofont{SimSun}
\usepackage[a4paper,inner=20mm,outer=25mm,top=21mm,bottom=23mm,marginparwidth=15mm,marginparsep=3mm]{geometry}
\usepackage{xcolor,paracol,fancyhdr,hyperref,graphicx,needspace,xurl,amsmath,tabularx,booktabs}
\hypersetup{unicode=true,hidelinks,pdftitle={Defending Materialism - reviewed working edition}}
\setlength{\parindent}{1em}\setlength{\parskip}{5pt}\setlength{\columnsep}{8mm}\setlength{\emergencystretch}{3em}
\tolerance=2000\widowpenalty=10000\clubpenalty=10000
\pagestyle{fancy}\fancyhf{}\fancyhead[LE,RO]{\small Defending Materialism}
\fancyhead[LO,RE]{\small RUNNING}\fancyfoot[C]{\thepage}\setlength{\headheight}{14pt}
\newcommand{\sourcepage}[1]{\marginpar{\raggedleft\scriptsize\color{gray}p.\ #1}}
\twosided[pm]\marginparthreshold{0}
\begin{document}
'''
def render(bi):
    out=[PRE.replace('RUNNING','中英逐段对照校对稿' if bi else 'English working edition')]
    if (O/'assets/source_cover.png').exists():out.append(r'\thispagestyle{empty}\begin{center}\includegraphics[width=\textwidth,height=.94\textheight,keepaspectratio]{assets/source_cover.png}\end{center}\clearpage')
    out.append(r'\begin{center}{\Large\bfseries '+('捍卫唯物主义' if bi else 'Defending Materialism')+r'}\par\medskip')
    out.append(r'The Uneasy History of the Atom in Science and Philosophy\par\medskip Katarina Kolozova, William Paul Cockshott, Greg Michaelson\end{center}')
    scope='、'.join(p['chapter'] for p in packets if 1<=int(p['chapter'])<=11)
    notice=f'分批校对稿，目前收录第{scope}章及对应原注，全书尚未完成。中文以用户所供现成译稿为底稿，对照英文逐段修订。左栏中文，右栏英文；页边为原书印刷页码。各章原注完整置于章末，注号可跳转并返回；校注与原注明确区分。' if bi else f'Working edition: chapters {scope} and their endnotes only. The whole book is not complete. Margin labels preserve original printed page numbers. Source paragraphs continue across page boundaries; endnotes retain complete source text.'
    notice=notice.replace('章及对应原注','章中已校对的部分及其对应原注').replace('各章原注完整置于章末','已校段落对应的原注置于章末').replace('chapters '+scope+' and their endnotes only','reviewed portions of chapters '+scope+' and corresponding endnotes only')
    if any(int(p['chapter'])>11 for p in packets):notice+=(' 另收录已校的参考文献及索引部分；索引中的数字沿用原书页码。' if bi else ' Reviewed back matter is also included; index locators refer to the original book pagination.')
    if '--full-text' in sys.argv:
        notice=('全书中英对照校对版。中文以用户提供的现成译稿为底稿，对照英文逐段修订，并补齐前置材料、原注、图表、参考文献及索引。左栏中文，右栏英文；页边及目录、索引中的数字沿用原书页码。原注置于对应章末，注号可跳转并返回；校注明确区分原书疑点与译文修订。' if bi else 'Complete English reading edition, including front matter, eleven chapters, endnotes, figures, references and index. Margin labels, contents and index locators preserve original pagination. Endnotes are relocated to the corresponding chapter ends with linked references. Source anomalies are retained; this edition does not silently correct the original text.')
    out.append(r'\noindent '+plain(notice)+r'\par\bigskip')
    for packet in packets:
        ch=packet['chapter'];opened=False;lastpage=None
        def close():
            nonlocal opened
            if opened:out.append(r'\end{paracol}');opened=False
        def start():
            nonlocal opened
            if bi and not opened:out.append(r'\begin{paracol}{2}');opened=True
        for u in packet['units']:
            kind=u['kind'];zh=esc(u['zh'],ch,True);en=english(u,ch,not bi)
            label='--'.join(dict.fromkeys([u['printed_pages'][0],u['printed_pages'][-1]]))
            marker=r'\sourcepage{'+label+'}' if label!=lastpage else ''
            out.append('% UNIT '+u['id'])
            if kind in ['chapter','heading']:
                close()
                if kind=='chapter':out.extend([r'\clearpage',r'\pdfbookmark[0]{'+plain(u['zh'] if bi else u['en'])+'}{'+u['id']+'}'])
                else:out.append(r'\needspace{6\baselineskip}')
                cmd=r'\section*' if kind=='chapter' else r'\subsection*'
                out.append(cmd+'{'+(zh+r'\\[4pt]{\normalsize '+en+'}' if bi else en)+'}');continue
            lastpage=label
            if kind=='publisher_mark':
                close();out.append(r'\begin{center}\includegraphics[width=.45\textwidth]{'+u['image']+r'}\end{center}');continue
            if kind=='code':
                close()
                out.append(r'\leavevmode{}'+marker)
                out.extend([r'\begin{quote}\small\ttfamily\raggedright',r'\par '.join(plain(line) for line in u['en'].splitlines()),r'\end{quote}'])
                continue
            if kind=='table':
                close();t=u['table']
                out.append(r'\leavevmode{}'+marker)
                for lang in (['zh','en'] if bi else ['en']):
                    if u['en'].startswith('Table '):out.append(r'\noindent '+esc(u[lang],ch)+r'\par')
                    weights=t.get('column_weights',[1]*len(t['headers_'+lang]))
                    assert len(weights)==len(t['headers_'+lang]) and abs(sum(weights)-len(weights))<.001
                    spec='@{}'+''.join(r'>{\hsize='+str(w)+r'\hsize\linewidth=\hsize\raggedright\arraybackslash}X' for w in weights)+'@{}'
                    out.append(r'\begin{center}\footnotesize\setlength{\tabcolsep}{3pt}\begin{tabularx}{\textwidth}{'+spec+r'}\toprule')
                    out.append(' & '.join(esc(x,ch) for x in t['headers_'+lang])+r'\\\midrule')
                    for cells in t['rows_'+lang]:out.append(' & '.join(esc(x,ch) for x in cells)+r'\\')
                    out.append(r'\bottomrule\end{tabularx}\end{center}')
                if bi and u.get('editor_note'):out.append(r'{\footnotesize 校注：'+esc(u['editor_note'],ch)+r'\par}')
                continue
            if u.get('math_lines'):
                close();out.append(r'\leavevmode{}'+marker+r'\[\begin{aligned}'+r'\\'.join(u['math_lines'])+r'\end{aligned}\]');continue
            if kind=='figure':
                close();out.extend([r'\begin{center}\begin{minipage}{\textwidth}\centering',r'\includegraphics[width=.84\textwidth,height=.42\textheight,keepaspectratio]{'+u['image']+'}',r'\par\smallskip {\small '+(zh+r'\par\smallskip ' if bi else '')+en+r'\par}'])
                if bi and u.get('image_labels_zh'):out.append(r'{\footnotesize '+plain(u['image_labels_zh'])+r'\par}')
                if bi and u.get('editor_note'):out.append(r'{\footnotesize 校注：'+plain(u['editor_note'])+r'\par}')
                out.append(r'\end{minipage}\end{center}');continue
            if kind=='toc_entry' and u['en'].startswith('Chapter '):
                close();out.append(r'\needspace{7\baselineskip}')
            start()
            if u.get('editor_note'):zh+=r'\par\nopagebreak[4]{\footnotesize\color{black!65}〔校注：'+esc(u['editor_note'],ch)+r'〕\par}'
            if kind=='list_item':
                if not re.match(r'^\s*(?:\d+|[a-zA-Z])[.)、]',u['zh']):zh=r'\textbullet\ '+zh
                if not re.match(r'^\s*(?:\d+|[a-zA-Z])[.)、]',u['en']):en=r'\textbullet\ '+en
            if kind=='quote':zh=r'{\small '+zh+'}';en=r'{\small '+en+'}'
            if kind=='index_entry' and u.get('index_level',0):
                zh=r'\hspace*{1em}'+zh;en=r'\hspace*{1em}'+en
            if kind=='toc_entry':
                if u.get('toc_level',0):zh=r'\hspace*{1em}'+zh;en=r'\hspace*{1em}'+en
                elif u['en'].startswith('Chapter '):zh=r'{\bfseries '+zh+'}';en=r'{\bfseries '+en+'}'
            if bi:out.extend([r'\leavevmode{}'+marker+zh+r'\par',r'\switchcolumn',en+r'\par',r'\switchcolumn*'])
            else:out.append(r'\leavevmode{}'+marker+en+r'\par')
        close()
        if not packet['notes']:continue
        out.extend([r'\clearpage',r'\section*{'+('第'+ch+'章原注 / ' if bi else '')+'Chapter '+ch+' Notes}'])
        for u in packet['notes']:
            start();num=str(u['note_number']);anchor=r'\hypertarget{note-'+ch+'-'+num+r'}{}\hyperlink{ref-'+ch+'-'+num+r'}{\textsuperscript{$\uparrow$}}'
            en=english(u,ch);zh=esc(u['zh'],ch)
            if u.get('editor_note'):zh+=r'\par\nopagebreak[4]{\footnotesize\color{black!65}〔校注：'+esc(u['editor_note'],ch)+r'〕\par}'
            label='--'.join(dict.fromkeys([u['printed_pages'][0],u['printed_pages'][-1]]))
            if bi:out.extend([r'\leavevmode{}\sourcepage{'+label+'}'+anchor+zh+r'\par',r'\switchcolumn',en+r'\par',r'\switchcolumn*'])
            else:out.append(r'\leavevmode{}\sourcepage{'+label+'}'+anchor+en+r'\par')
        close()
    out.append(r'\end{document}');return '\n'.join(out)
for kind,bi in [('bilingual',True),('en',False)]:
    (O/f'materialism_{kind}.tex').write_text(render(bi),'utf8')
md=['# 捍卫唯物主义','分批校对稿；全书未完成。']
if '--full-text' in sys.argv:md[1]='全书中文校对版。保留原书页码、完整原注、图表、参考文献及索引；源书疑点另列校注。'
if (O/'assets/source_cover.png').exists():md.append('![原书封面](assets/source_cover.png)')
for p in packets:
    ch=p['chapter']
    for u in p['units']:
        s=re.sub(r'\[\[(\d+)\]\]',lambda m:f'[^ch{ch}-{m[1]}]',u['zh'])
        md+=['<!-- '+u['id']+' -->','〔原书第'+'—'.join(dict.fromkeys([u['printed_pages'][0],u['printed_pages'][-1]]))+'页〕',('# ' if u['kind']=='chapter' else '## ' if u['kind']=='heading' else '> ' if u['kind']=='quote' else '- ' if u['kind']=='list_item' else '')+s]
        if u['kind']=='code':md[-1]='```c\n'+u['en']+'\n```'
        if u.get('image'):
            md.append('!['+u['zh']+']('+u['image']+')')
            if u.get('image_labels_zh'):md.append(u['image_labels_zh'])
        if u.get('table'):
            t=u['table'];md[-1]=(u['zh']+'\n\n' if u['en'].startswith('Table ') else '')+'| '+' | '.join(t['headers_zh'])+' |\n| '+' | '.join(['---']*len(t['headers_zh']))+' |\n'+'\n'.join('| '+' | '.join(r)+' |' for r in t['rows_zh'])
        if u.get('editor_note'):md.append('> 校注：'+u['editor_note'])
    for n in p['notes']:md.append(f'[^ch{ch}-{n["note_number"]}]: '+n['zh'])
(O/'materialism_zh.md').write_text('\n\n'.join(md)+'\n','utf8')
if '--compile' in sys.argv:
    for k in ['bilingual','en']:
        for i in [1,2]:
            p=subprocess.run(['C:/texlive/2025/bin/windows/xelatex.exe','-interaction=nonstopmode','-halt-on-error',f'materialism_{k}.tex'],cwd=O,capture_output=True)
            (W/f'compile_{k}_{i}.log').write_bytes(p.stdout+p.stderr)
            if p.returncode:print(p.stdout.decode('utf8',errors='replace')[-4000:]);raise SystemExit(p.returncode)
        print(k,'compiled')
