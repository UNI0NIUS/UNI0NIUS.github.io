from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch06-{len(rows)+93:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(146,3),rr(73,38,40)+rr(74,0,5))
add(rr(146,4),rr(74,6,9),fixes=[('熵原子理论、光光子理论','关于熵的原子理论、关于光的光子理论'),('概括了客观因果机制','把握了客观的因果机制')])
add(rr(147,1),rr(74,10,12))
rows[-1]['editor_note']='底本attaching Machism按上下文应为attacking；英文照录，中文按批判译。'
add(rr(147,2),rr(74,13,14))
add(rr(147,3),rr(74,15,17),fixes=[('感觉群体简明心理符号','感觉群的简明心理符号')])
add(rr(147,4),rr(74,18,19),fixes=[('感觉群体心理或概念符号','感觉群的心理或概念符号')])
add(rr(147,5),rr(74,20,21),end='老调重弹',fixes=[('自然科学','物理科学')])
add(rr(147,6),rr(74,21,26),'quote',start='老调重弹',text='老调重弹了，最可敬的教授！这完全是在重复贝克莱的话：物质是一个赤裸的抽象符号。但实际上，赤裸的正是恩斯特·马赫，因为，如果他不承认“可感内容”是独立于我们而存在的客观实在，那么剩下的就只有一个“赤裸的抽象的”我，一个必定要大写并用斜体标出的我，等同于“那架发疯的钢琴，它以为自己是世上唯一存在的东西”[[36]]。如果我们的感觉的“可感内容”不是外部世界，那么就只剩下这个沉湎于空洞“哲学”幻想的赤裸的我。这是一种愚蠢而徒劳的消遣！',reason='恢复原注36在钢琴引文后的准确位置；删除旧译重复残片并统一客观实在、可感内容。')
add(rr(147,7),rr(74,27),end='物理学家')
add(rr(147,8)+rr(148,1),rr(74,27,36),'quote',start='物理学家',fixes=[('必要经济本能','必要的节约本能'),('简明而经济符号','简明而节约的符号')])
add(rr(148,2),rr(74,37)+rr(75,0),text='因此，在马赫看来，钠原子只是一组感觉印象的符号。归根结底，既不存在钠原子，也不存在任何原子；它们只是我们用来赋予感觉印象以一致性的观念。',reason='no atoms in general否认原子存在而非否认原子概念，旧译改变论点。')
nr={33:[[260,17,18,19]],34:[[260,17,19,20]],35:[[260,17,20,21]],36:[[260,17,21,22]]+rr(260,18),37:rr(260,19)}
nt={33:'V. I. Lenin：《唯物主义和经验批判主义》（Materialism and Empirio-criticism）（International Publishers，1908）。',34:'正式职称为苏联人民委员会主席。',35:'Mach：“通俗科学讲演”（Popular Scientific Lectures）。',36:'这里列宁引用的是18世纪唯物主义者狄德罗：为了让我的体系具备充分的说服力，还请注意，它同样面临贝克莱针对物体的存在所提出的那个不可克服的困难。有一刻，有感觉的羽管键琴陷入狂乱，以为它是世界上唯一的羽管键琴，宇宙的一切和声都发生在它之中。Denis Diderot等：《达朗贝尔与狄德罗的对话》（Entretien entre d’Alembert et Diderot）（Garnier-Flammarion，1965）。',37:'Mach：“通俗科学讲演”（Popular Scientific Lectures）。'}
notes=[]
for n,refs in nr.items():notes.append({'id':f'dm-ch06-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['251'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch06g',6,rows,notes,rr(146,3,4)+rr(147,1,8)+rr(148,1,2))
(W/'checkpoint_ch06g.json').write_text(json.dumps({'next_source_pdf_page':148,'next_source_block':3,'next_supplied_pdf_page':75,'next_supplied_block':1,'next_unit':len(rows)+93,'next_note':38,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
