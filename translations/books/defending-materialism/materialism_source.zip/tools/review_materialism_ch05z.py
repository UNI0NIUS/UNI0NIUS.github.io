from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch05-{len(rows)+318:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(124,5),rr(63,2,7),fixes=[('汤姆孙','汤姆森'),('速度均常数','速率均为常数'),('量化或简化','量子化，或减少其数量'),('晶格气体模型','格子气模型')],reason='统一Thomson译名；这里上下左右方向变化但速率不变，degrees of freedom指自由度数量。')
rows[-1]['editor_note']='本段底本拼作Thompson，前后文作Thomson；中文按同一人物统一为汤姆森，英文保留底本拼写。'
add(rr(124,6),rr(63,8,11),fixes=[('空气动力学计算机模拟。','空气动力学计算机模拟。[[118]]'),('晶格','格子'),('直角格子','直角格子')],reason='补漏注118并统一lattice术语。')
add(rr(124,7),rr(63,12,14),fixes=[('晶格气体模型','格子气模型'),('专用计算机。','专用计算机。[[119]]'),('恒定速度','恒定速率'),('汤姆森','汤姆森')],reason='补漏注119；constant velocities在该模型中保持速率而改变方向。')
add(rr(124,8),rr(63,15),fixes=[('晶格','格子')])
add(rr(124,9)+rr(125,1),rr(63,16,18))
add(rr(125,2),rr(63,19,21),fixes=[('晶格态','格子状态'),('围绕40 左右呈现噪声振荡','在40附近不规则地振荡')])
add(rr(125,3),rr(63,22,23),fixes=[('晶格气体','格子气'),('晶格','格子')])
nt={118:'U. B. Frisch、B. Hasslacher与Y. Pomeau：“纳维–斯托克斯方程的格子气自动机”（Lattice Gas Automata for the Navier Stokes Equation），Physical Review Letters，第56卷（1986），第1505—1508页。',119:'Peter Barrie等：“高度并发机器的设计与验证”（Design and Verification of a Highly Concurrent Machine），Microprocessors and Microsystems，第16卷第3期（1992），第115—123页；George J. Milne与William P. Cockshott：《物理过程模拟的方法与装置》（Method and Apparatus for Simulation of a Physical Process），美国专利5,485,599，1996年。'}
notes=[]
for n,refs in note_groups(rr(258,1)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch05-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['249'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch05z',5,rows,notes,rr(124,5,9)+rr(125,1,3))
(W/'checkpoint_ch05z.json').write_text(json.dumps({'next_source_pdf_page':125,'next_source_block':4,'next_supplied_pdf_page':63,'next_supplied_block':24,'next_unit':len(rows)+318,'next_note':120,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
