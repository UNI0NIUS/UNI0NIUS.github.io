"""Account for every extracted source line, including relocated note headings."""
from materialism_common import *
from collections import defaultdict

used=defaultdict(list)
packets=[json.loads(p.read_text('utf8')) for p in (W/'packets').glob('*.json')]
for packet in packets:
    for u in packet['units']+packet['notes']:
        for p,b,j,l in lines(EN,u['source_blocks']):used[p,b,j].append(u['id'])
excluded=[];missing=[]
note_heads={(244,0,0):'NOTES',(244,1,0):'Chapter 1',(244,3,0):'Chapter 2',(246,2,0):'Chapter 3',(249,2,0):'Chapter 4',(252,2,0):'Chapter 5',(259,2,0):'Chapter 6',(263,2,0):'Chapter 7',(264,2,0):'Chapter 8',(267,2,0):'Chapter 9',(269,2,0):'Chapter 10',(270,2,0):'Chapter 11'}
for p,page in enumerate(EN,1):
    for b in page['blocks']:
        for j,l in enumerate(b['lines']):
            key=(p,b['block'],j)
            if key in used:continue
            text=''.join(s['text'] for s in l['spans'])
            row={'source_line':key,'text':text}
            if b['block']==0 and l['bbox'][1]<45:
                row['reason']='running header/page number, replaced by output running header and original-page markers';excluded.append(row)
            elif key in note_heads and text==note_heads[key]:
                row['reason']='notes relocated to chapter ends with generated chapter-note headings';excluded.append(row)
            else:missing.append(row)
duplicates={str(k):v for k,v in used.items() if len(v)>1}
allowed={(254,2,0):['dm-ch05-note-36','dm-ch05-note-37']}
unexpected={str(k):v for k,v in used.items() if len(v)>1 and sorted(v)!=sorted(allowed.get(k,[]))}
result={'source_text_lines':len(used)+len(excluded)+len(missing),'covered_lines':len(used),'excluded':excluded,'missing':missing,'shared_source_lines':duplicates,'shared_line_explanation':'EN254 block2 line0 contains the end of note36 and the label37; each note preserves only its own text.','unexpected_duplicate_lines':unexpected,'coverage':'pass' if not missing and not unexpected else 'fail','scope_limit':'Text line accounting only; does not prove semantic accuracy, complete image preservation, or layout quality.','full_book_complete':False}
(W/'whole_source_coverage_audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf8')
print(json.dumps({k:v for k,v in result.items() if k not in ['excluded','shared_source_lines']},ensure_ascii=False))
assert not missing and not unexpected
