from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch05-{len(rows)+230:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(111,8)+rr(112,1),rr(56,15,19),fixes=[('[[8]] [[4]]','[[84]]')])
add(rr(112,2),rr(56,20,21),end='只要稍微')
add(rr(112,3),rr(56,21,24),'quote',start='只要稍微',fixes=[('数万个锋利楔子','一万个锋利楔子'),('[[8]] [[5]]','[[85]]')],reason='ten thousand照原文数量译为一万；引文与前段叙述分开。')
add(rr(112,4),rr(56,25,29),end='既然对人类',fixes=[('大黄蜂','熊蜂')],reason='bumblebee统一为熊蜂，旧译同段混用黄蜂与熊蜂。')
add(rr(112,5),rr(56,29,32),'quote',start='既然对人类',fixes=[('[[8]] [[6]]','[[86]]')])
add(rr(112,6),rr(56,33,34),end='可以说')
add(rr(112,7)+rr(113,1),rr(56,34,38),'quote',start='可以说',fixes=[('而那时，我们对久远地质时代洞察——即便如此不完善——我们只能看到','而到那时，我们对久远地质时代的洞察仍如此不完善，以至于只能看到'),('[[8]] [[7]]','[[87]]')],reason='恢复so imperfect ... that的程度—结果结构，消除旧译断裂句。')
add(rr(113,2),rr(56,39,40))
add(rr(113,3),rr(57,0))
add(rr(113,4),rr(57,1),fixes=[('始祖马','始马')],reason='Eohippus与下一段统一为始马。')
add(rr(113,5),rr(57,2))
add(rr(113,6),rr(57,3,4))
add(rr(113,7),rr(57,5,6),end='没有任何')
add(rr(113,8),rr(57,6,10),'quote',start='没有任何',fixes=[('[[8]] [[8]]','[[88]]')])
add(rr(113,9),rr(57,11,14),fixes=[('[[8]] [[9]]','[[89]]'),('欧洲野兔','欧洲兔'),('已达到危害农作物程度','已泛滥成灾'),('被放归欧洲袋鼠','被放养到欧洲的小袋鼠')],reason='rabbit不应与hare野兔混同，wallaby是小袋鼠；pestilential未限定损害农作物。')
nt={84:'Darwin：《物种起源》，第3章。',85:'Darwin：《物种起源》，第3章。',86:'Darwin：《物种起源》，第4章。',87:'Darwin：《物种起源》，第4章。',88:'Darwin：《物种起源》，第4章。',89:'Stephen Jay Gould：《熊猫的拇指：自然史再思考》（The Panda’s Thumb: More Reflections in Natural History）（W. W. Norton & Company，2010），第28章。'}
notes=[]
for n,refs in note_groups(rr(256,1)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch05-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['247'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch05r',5,rows,notes,rr(111,8)+rr(112,1,7)+rr(113,1,9))
(W/'checkpoint_ch05r.json').write_text(json.dumps({'next_source_pdf_page':113,'next_source_block':10,'next_supplied_pdf_page':57,'next_supplied_block':15,'next_unit':len(rows)+230,'next_note':90,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
