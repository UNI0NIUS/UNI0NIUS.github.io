from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch08-{len(rows)+19:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(180,1),rr(93,21,22),text='黑格尔认为，形式与内容的分离是一种幻象。他在《导言》中进一步详述了这一立场。辩证唯物主义拒斥形式主义，即脱离内容独立研究逻辑的根源，便在于此。')
add(rr(180,2),rr(93,23),'heading',text='恩格斯与逻辑')
add(rr(180,3),rr(93,24,28),text='卡尔·马克思（1818—1883）和弗里德里希·恩格斯（1820—1895）的革命世界观以科学唯物主义为前提。马克思几乎没有论述辩证法或三段论逻辑。相比之下，恩格斯在晚期著作中多次提及逻辑。在1877年的《反杜林论》[[4]]中，他有力地断言：逻辑在与辩证法的结合中处于从属地位。首先，他重申亚里士多德的立场：一门科学一旦充分专门化，就会独立于任何范围更广的认识论。三段论逻辑——现在称为形式逻辑——以及辩证法，作为思维规律，独立于哲学：',reason='补漏注4，拆出引文。')
add(rr(180,4),rr(93,28,29),'quote',text='在以往全部哲学中，还独立存在着的，就是关于思维及其规律的科学——形式逻辑和辩证法。其余一切都归入关于自然和历史的实证科学。（第40页）')
add(rr(180,5),rr(93,30,31),text='这一表述在1880年的《社会主义从空想到科学的发展》[[5]]中得到重复，并在1886年的《路德维希·费尔巴哈和德国古典哲学的终结》[[6]]中再次重申。',reason='补漏注5、6并统一中文书名；拆出下段。')
add(rr(180,6),rr(93,31,34),text='回到《反杜林论》，恩格斯指出，数学必须从逻辑中借用公理，而这些公理是“最贫乏的思想内容的表达”（第60页）。他沿袭黑格尔的观点说，仅靠逻辑公理“收效甚微”，要取得进展就必须借助几何学（第61页）。他的主要批评是，杜林强调纯数学独立于经验，却不承认它是从现实中抽象出来的（第61页）。',reason='abstraction from reality指从现实抽象而来，旧译“脱离现实抽象性”改变了论点。')
add(rr(180,7),rr(93,35),text='恩格斯说，辩证法比形式逻辑更有力：')
add(rr(180,8),rr(93,35,36)+rr(94,0),'quote',text='就连形式逻辑也首先是一种获得新结果、从已知推进到未知的方法；辩证法也是如此，而且更为显著。此外，由于辩证法突破了形式逻辑的狭隘视野，它包含着一种更全面的世界观的萌芽。（第186页）')
add(rr(180,9),rr(94,1,2),text='此外，形式逻辑只对初等数学具有意义。在高等数学中，乃至一切新科学中，都需要辩证法才能取得进展：',reason='拆分作者引导句与长引文。')
add(rr(180,10)+rr(181,1),rr(94,2,6),'quote',text='初等数学，即常量的数学，至少总体上是在形式逻辑的范围内活动的；变量的数学，其最重要的部分是微积分，本质上无非是辩证法在数学关系中的应用。在这里，与这一方法在新研究领域中的多种应用相比，单纯的证明问题显然退居次要地位。但是，几乎所有高等数学的证明，从微分学最初的证明起，从初等数学的立场看，严格说来都是错误的。当人们像这里一样，试图用形式逻辑来证明在辩证法领域中获得的结果时，这就是必然的。（第186—187页）',reason='合并跨页引文，保留原文对数学证明的判断，不代作者改写。')
add(rr(181,2),rr(94,7,8),text='然而，他把形式逻辑描述为涉及常量而非变量，这表明他存在根本性的误解。马克思对数学也持这种看法，下文将会谈到。恩格斯还流露出一种奇特的对数学的蔑视：')
add(rr(181,3),rr(94,8,9),'quote',text='然而，数学家的抽象要求远不是现实世界必须遵守的规律。（第75页）')
add(rr(181,4),rr(94,10,11),text='最后，在他身后出版的《自然辩证法》[[7]]中，恩格斯重谈这些主题。他再次认为，辩证逻辑优于形式逻辑，因为它把分析与推理结合起来：',reason='补漏注7，恢复再次之意。')
add(rr(181,5),rr(94,11,14),'quote',text='辩证逻辑与旧的、纯形式的逻辑不同：它不像后者那样，满足于列举思维的运动形式，即各种判断形式和结论形式，并把它们毫无联系地并列起来。相反，它使这些形式彼此推导出来，使一种形式从属于另一种形式，而不是把它们置于同等地位；它从较低的形式发展出较高的形式。（第296页）')
add(rr(181,6),rr(94,15,16),text='恩格斯承认，尽管自然科学和历史科学不断发展，形式逻辑仍有一种本质性的、可以认识的特性。尽管如此，他又一次坚决拒斥数学抽象：')
add(rr(181,7),rr(94,16,18),'quote',text='他们［数学家和自然科学家］指责黑格尔所做的事，即把抽象推到极端，他们自己却在大得多的规模上这样做。他们忘记了，全部所谓纯数学都涉及抽象，严格说来，它的一切量都是想象的；而一切抽象一旦推到极端，就会转化为无稽之谈，或转化为自身的对立面。（第359页）',reason='恢复旧译错字“对其立面”；imaginary不误作复数中的虚数。')
nt={4:'F. Engels：《反杜林论》（莫斯科：Foreign Languages Publishing House，1954）。',5:'F. Engels：“社会主义从空想到科学的发展”，载《马克思恩格斯选集》第II卷（莫斯科：Foreign Languages Publishing House，1951）。',6:'F. Engels：“路德维希·费尔巴哈和德国古典哲学的终结”，载《马克思恩格斯选集》第II卷（莫斯科：Foreign Languages Publishing House，1951）。',7:'F. Engels：《自然辩证法》（莫斯科：Foreign Languages Publishing House，1954）。'}
notes=[]
for n,refs in note_groups(rr(265,1)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch08-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['256'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch08b',8,rows,notes,rr(180,1,10)+rr(181,1,7))
(W/'checkpoint_ch08b.json').write_text(json.dumps({'next_source_pdf_page':181,'next_source_block':8,'next_supplied_pdf_page':94,'next_supplied_block':19,'next_unit':len(rows)+19,'next_note':8,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
