from materialism_common import *

groups=[];pending=[]
for j,l in enumerate(block(EN,9,1)['lines']):
    pending.append([9,1,j,j+1])
    if l['bbox'][0]>350:groups.append(pending);pending=[]
titles='''阿基米德证明，单位圆柱的体积等于单位圆锥与单位半球的体积之和
具有本轮轨迹的物体，其轨道在x轴上的投影是余弦曲线之和
经过2007至2016年采样的世界石油价格／运量数据点的连续曲线
轨道半径与周期的关系
用维多利亚时代的一个经济周期说明马克思的资本积累一般规律
道尔顿表示元素原子的符号记法
矩形二维格子气系统演化规则示意
尺寸为5 16的气体格子
初始时，全部80个原子都在左侧
汤姆森描述的有限系统随时间的演化
马赫论证所使用的库仑扭秤
马赫描述的莱顿瓶实验
实际分力装置示意图
以现代电路图表示马赫描述的莱顿瓶实验
利用脑部扫描可以重建一个人正在看到的图像
光通过偏振器后，可以形成垂直偏振光束
左图显示，垂直偏振光的振幅如何投影到与原偏振轴成45°的偏振器的左、右轴上
通过面积求和进行积分
图灵机
随着生成的数字越来越多，最初不利于零的偏差逐渐消失
左：计算机芯片中的标准元件CMOS反相器。右：反相器的逻辑符号'''.splitlines()
assert len(titles)==len(groups)==21 and not pending
rows=[{'id':'dm-lof-title','kind':'chapter','source_blocks':rr(9,0),'supplied_translation_blocks':[],'printed_pages':['viii'],'en':'FIGURES','zh':'插图目录','supplied_zh':'','status':'text_compared_layout_pending'}]
for i,(refs,title) in enumerate(zip(groups,titles),1):
    en=extract(EN,refs,True);num=en.split()[0];locator=en.split()[-1]
    row={'id':f'dm-lof-{i:03}','kind':'toc_entry','source_blocks':refs,'supplied_translation_blocks':[],'printed_pages':['viii'],'en':en,'zh':num+' '+title+'　'+locator,'supplied_zh':'','toc_level':0,'toc_locator':locator,'figure_number':num,'status':'text_compared_layout_pending','revision_reason':'补译旧稿省略的插图目录，保留全部图号、标题和原书页码。'}
    if num=='5.4':row['editor_note']='原插图目录尺寸写作“5 16”，与正文图注不同；此处按目录原文保留。'
    if num=='3.4':row['editor_note']='原插图目录英文semi-redius拼写按原样保留。'
    rows.append(row)
save('front03',0,rows,[],rr(9,0,1))
