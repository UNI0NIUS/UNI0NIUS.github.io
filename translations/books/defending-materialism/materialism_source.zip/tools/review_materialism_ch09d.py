from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch09-{len(rows)+44:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(200,1),rr(104,22,23),text='这一结果来自图灵在考察生成实数的图灵机时，使用康托尔对角线法作出的更详尽论证。虽然上文批评了对角线法这一整个观念，认为它涉及已完成的无限，但这并不使停机问题核心的悖论失效。',reason='completed infinities统一为已完成的无限，不作完备无限。')
add(rr(200,2),rr(104,24),'heading',text='丘奇—图灵论题')
add(rr(200,3),rr(104,25,26),text='在哥德尔和图灵开展工作的同时，人们还探索了其他几种元数学形式体系。斯蒂芬·克莱尼（1909—1994）沿着传统路线发展出递归函数论，将皮亚诺归纳法反转为一种定义数或集合上的函数的形式。[[4]]')
add(rr(200,4),rr(104,27,29),text='相比之下，摩西·舍恩芬克尔（1888—1942）早在1924年就发展了组合逻辑。[[5]]哈斯克尔·柯里（1900—1982）于1929年加以完善，[[6]]由此引出了阿隆佐·丘奇（1903—1995）自1932年起关于λ演算的极有影响力的工作。[[7]]',reason='补原文全名Moses，统一术语。')
add(rr(200,5),rr(104,30,32),text='对辩证唯物主义的拥护者而言，这些系统似乎尤其成问题。舍恩芬克尔和柯里的组合逻辑由算子构成；算子的性质通过它们如何消去或复制其他算子、从而与之相互作用来定义。丘奇的λ演算则是纯粹抽象的，其规则通过代入来组合抽象。二者都不涉及具体的值。')
add(rr(200,6),rr(105,0,3),text='不过，这些系统有一个关键性质：它们都能够表示逻辑和算术，因此都能把握希尔伯特纲领核心的定理与证明概念。这就是丘奇—图灵论题的根源：所有对数进行计算的系统都在如下意义上等价，即任一系统都能翻译成其他任一系统。换言之，没有什么能在一个系统中表达，却不能在其他系统中表达。',reason='保留作者对论题的概括，不自行增加范围限定。')
add(rr(200,7),rr(105,4,6),text='递归函数论、λ演算和图灵机在提出后不久，就被证明相互等价。[[8]]后来，人们证明它们与冯·诺伊曼机，即一般化的数字计算机等价，因而与任意编程语言等价。模拟计算和量子计算[[9]]的形式化也被证明满足丘奇—图灵论题。')
add(rr(200,8),rr(105,7,10),text='请注意，这是一个推测性的论题，而不是能够证明的理论。我们不知道可能有多少种不同的等价系统。不过，它是可证伪的：某个新系统仍可能被证明具有不同于当前已知系统的性质，因而无法相互翻译。也就是说，丘奇—图灵论题可以作为经验性的常规科学的一部分接受实验研究。事实上，我们将在后文论证，它对于更广泛地理解现实具有核心意义。',reason='thesis统一论题，不在同段混用命题。')
add(rr(200,9),rr(105,11,13),text='从根本上说，所有这些系统都能够实现计算。这在图灵机中十分明确：机器处理纸带上的数据。对于组合子和λ演算，指令与数据没有明显的区分，规则作用于公式，直到公式无法再简化。')
add(rr(201,1),rr(105,14,16),text='图灵机与其他形式体系的根本区别就在这里。一组图灵机指令是建造实际机器的蓝图；这种机器能像数字计算机一样，自主地处理其数据。相反，其他形式系统需要人或解释装置来执行规则。我们认为，这是支持图灵机在阐述唯物主义时具有首要地位的有力论据，后文还会讨论。')
add(rr(201,2),rr(105,17),'heading',text='英国辩证唯物主义者的回应')
add(rr(201,3),rr(105,18,19),text='对辩证唯物主义者来说，哥德尔和图灵的成果进一步证明了没有辩证法的逻辑所具有的局限。共产主义数学家阿利斯特·沃森（1908—1982）[[11]]在1938年的文章中[[10]]认为，一切悖论',reason='拆出引文，保留作者与年代。')
# Keep source note order in the aligned prose.
rows[-1]['zh']='对辩证唯物主义者来说，哥德尔和图灵的成果进一步证明了没有辩证法的逻辑所具有的局限。1938年，[[10]]共产主义数学家阿利斯特·沃森（1908—1982）[[11]]撰文认为，一切悖论'
add(rr(201,4),rr(105,19,20),'quote',text='不过以这样或那样的方式表达了那种众所周知的困难：当我们试图把一个无限过程看作已经完成时，就会出现这种困难。（第450页）')
add(rr(201,5),rr(105,21,23),text='沃森指的是亚里士多德对潜无限与实无限的区分。我们同意沃森：假定实无限存在，会使康托尔对角线法之类的方法成问题。不过，如果沃森把图灵机的纸带认作已完成的无限，那就错了。无论如何，图灵关于停机问题不可判定的结果，可以不依靠对角线法来确立。',reason='统一潜无限、实无限和纸带；保留原文假设语气。')
add(rr(201,6),rr(105,24),text='沃森对元数学的怀疑十分清楚：')
add(rr(201,7),rr(105,24,25),'quote',text='在数学基础这一领域，试图为抽象看待的数学论证辩护或加以否定的种种尝试，造成了大量混乱；人们付出极其巨大的劳动，才摆脱这些混乱。（第451页）',reason='恢复已经付出劳动的时态，不作泛指需要努力。')
add(rr(201,8),rr(105,26,28),text='他没有直接运用辩证唯物主义对形式逻辑的批判。不过，他在这段话的脚注中说，自己所反对的是戴德金的主张：数学基础不需要提及“可测量的量”。这令人想到马克思主义者对不从已知量导出的变量所持的反对意见。')
add(rr(201,9),rr(105,29),text='1938年，进化生物学家J. B. S. 霍尔丹（1892—1964）在《马克思主义哲学与科学》[[12]]中指出：')
add(rr(201,10),rr(105,29,32),'quote',text='总体上，我们可以认为，马克思主义者对那些抱负更大的逻辑理论颇为怀疑。例如，只要能够作出足够清晰的分类，罗素和怀特海在《数学原理》中的体系无疑就是真的，或大体是真的。')
nt={4:'S. C. Kleene：“自然数的一般递归函数”，Mathematische Annalen 112（1936）：727—742。',5:'M. Schönfinkel：“论数理逻辑的构造块”，载J. van Heĳenoort编《从弗雷格到哥德尔：数理逻辑文献集，1879—1931》（Harvard University Press，1967），第357—366页。',6:'H. Curry：《组合逻辑基础》（Grundlagen Der Kombinatorischen Logik），F. Kamaraddine、J. Seldin英译（College Publications，2017）。',7:'A. Church：“逻辑基础的一组公设”，Annals of Mathematics，第2系列，33，第2期（1932）：346—366。',8:'S. J. Kleene［姓名首字母按底本］：“λ可定义性与递归性”，Duke Mathematical Journal 2，第2期（1936）：340—353；A. M. Turing：“可计算性与λ可定义性”，Journal of Symbolic Logic 2（1937）：153—164。',9:'D. Deutch［底本拼法］：“量子理论、丘奇—图灵原理与通用量子计算机”，Proceedings of the Royal Society: A, Mathematical, Physiscal and Engineering Sciences 400，第1818期（1985）：97—117。',10:'A. G. D. Watson：“数学及其基础”，Mind 47，第188期（1938）：440—451。',11:'沃森曾把图灵介绍给路德维希·维特根斯坦，并曾被指称为苏联间谍：https://en.wikipedia.org/wiki/Alister_Watson 。',12:'J. B. S. Haldane：《马克思主义哲学与科学》（George Allen and Unwin Ltd，1938）。'}
notes=[]
for n,refs in note_groups(rr(267,3)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch09-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['258'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch09d',9,rows,notes,rr(200,1,9)+rr(201,1,10))
(W/'checkpoint_ch09d.json').write_text(json.dumps({'next_source_pdf_page':201,'next_source_block':11,'next_supplied_pdf_page':105,'next_supplied_block':33,'next_unit':len(rows)+44,'next_note':13,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
