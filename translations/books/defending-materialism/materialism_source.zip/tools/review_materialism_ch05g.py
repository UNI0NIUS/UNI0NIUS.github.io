from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch05-{len(rows)+87:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(93,4),rr(44,30,32),end='另一个',fixes=[('共同物质','共同实体')])
add(rr(93,5),rr(44,32,34)+rr(45,0,3),'quote',start='另一个',fixes=[('[[4]] [[3]]','[[43]]'),('这些力量','这些力'),('某种力量','某一种力')],reason='恢复拆开的原注43；引文forces沿用历史物理术语“力”。')
add(rr(93,6),rr(45,4),text='从交换中必定有一种共同实体保持守恒这一推论出发，马克思立即把这一实体认定为劳动。',reason='conserved译守恒，substance与上文统一译实体。')
add(rr(93,7),rr(45,4,7),'quote',start='这种共同',fixes=[('完全脱离使用价值','完全抽去使用价值')],reason='abstraction from指在交换关系中抽去使用价值，不是商品完全失去使用价值。')
add(rr(93,8,9),rr(45,8),'quote',text=extract(ZH,rr(45,8))+'……',reason='恢复源书单独成行的省略号，标明原引文删节。')
add(rr(94,1),rr(45,9,13),'quote',text='随着产品本身有用性质的消失，体现在产品中的各种劳动的有用性质及其具体形式也被撇开了；剩下的只有它们所共有的东西；它们全都还原为同一种劳动，即抽象的人类劳动。现在让我们考察这些产品各自的残余：每一种产品中都留下同样的无形的实在，不过是同质人类劳动的凝结，是不管以何种方式耗费的人类劳动力的凝结。这些东西现在仅仅表明，在它们的生产中耗费了人类劳动力，其中凝结了人类劳动。作为这种共同社会实体的结晶来考察，它们就是——价值。',reason='修正旧译“人类劳动力的消耗用于了”的语病，保留抽象劳动、劳动力及其耗费的概念区别。')
add(rr(94,2),rr(45,14,21),fixes=[('劳动是恒定量','劳动是守恒量'),('[[4]] [[4]]','[[44]]'),('[[4]] [[5]]','[[45]]'),('不言自明的真理','已经确立的真理'),('具有守恒实质','具有守恒实体')],reason='conserved quantity是守恒量；established truth不等于不言自明，避免强化作者论断；恢复原注44—45。')
nt={43:'恩格斯致马克思，1858年7月14日。',44:'A. M. Shaikh：“劳动价值论的实证力量”（The Empirical Strength of the Labour Theory of Value），载《马克思主义经济学：重新评价》（Marxian Economics: A Reappraisal），R. Bellofiore编，第2卷（Macmillan，1998），第225—251页；P. Petrovic：“生产价格对劳动价值的偏离：一些方法论与实证证据”（The Deviation of Production Prices from Labour Values: Some Methodolog and Empirical Evidence），Cambridge Journal of Economics，第11卷（1987），第197—210页；David Zachariah：《检验瑞典的劳动价值论》（Testing the Labor Theory of Value in Sweden）（2004），http://reality.gn.apc.org/econ/DZ_article1.pdf；W. Paul Cockshott与Allin F. Cottrell：“劳动时间与其他价值基础的比较：研究札记”（Labour Time Versus Alternative Value Bases: A Research Note），Cambridge Journal of Economics，第21卷第4期（1997），第545—549页；W. Paul Cockshott与Allin Cottrell：“价格与劳动价值之间的稳健相关性：评论”（Robust Correlations Between Prices and Labour Values: A Comment），Cambridge Journal of Economics，第29卷第2期（2005），第309—316页。',45:'该书第十一章包含了跨越多个世纪的大量价格统计数据。'}
notes=[]
for n,refs in note_groups([[254,2,11,24]]):
    notes.append({'id':f'dm-ch05-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['245'],'en':extract(EN,refs,True).replace('\u200b',''),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch05g',5,rows,notes,rr(93,4,9)+rr(94,1,2))
(W/'checkpoint_ch05g.json').write_text(json.dumps({'next_source_pdf_page':94,'next_source_block':3,'next_supplied_pdf_page':45,'next_supplied_block':22,'next_unit':len(rows)+87,'next_note':46,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
