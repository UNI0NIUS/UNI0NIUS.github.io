from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch10-{len(rows)+26:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(215,13),rr(113,1),text='对奎因来说，形式系统以变量标记抽象的位置，因此：')
add(rr(216,1),rr(113,1,2),'quote',text='被假定为一个实体，简而言之，就是被看作变量的值。（第13页）')
add(rr(216,2),rr(113,3),text='于是：')
add(rr(216,3),rr(113,3,4),'quote',text='一个理论所承诺的，正是且仅是这样的实体：为使该理论中的断言为真，理论的约束变量必须能够指称它们。（第13—14页）')
add(rr(216,4),rr(113,5,6),text='这是一种令人欣慰的宽容立场。它不仅容许在逻辑系统中操作事实，也容许操作系统能够正当操作的任何东西。')
add(rr(216,5),rr(113,7),'heading',text='模型论')
add(rr(216,6),rr(113,8,9),text='在1921年的《逻辑哲学论》[[5]]中，维特根斯坦主张，应当用事态来理解世界，即事物——他称之为对象——的配置。他断言：')
add(rr(216,7),rr(113,9),'quote',text='4.1 命题表现事态的存在与不存在。')
add(rr(216,8),rr(113,10),'quote',text='4.11 真命题的总和就是整个自然科学（或自然科学的全部体系）。（第25页）')
add(rr(216,9),rr(113,11),text='维特根斯坦还把命题的涵义界定为：')
add(rr(216,10),rr(113,11,12),'quote',text='4.2 ……与事态存在和不存在的可能性相符合或不相符合。（第30页）',reason='统一states of affairs为事态，sense译涵义。')
add(rr(216,11),rr(113,13),text='他随后提议用真值表来考察这些可能性（第30页），并已论证：')
add(rr(216,12),rr(113,13,14),'quote',text='4.25 如果一个基本命题为真，则该事态存在；如果一个基本命题为假，则该事态不存在。')
add(rr(216,13),rr(113,15,16),text='卡尔纳普深受维特根斯坦事态概念的影响，在1947年的《意义与必然性：语义学与模态逻辑研究》[[6]]中，通过状态描述这一观念，系统地形式化了外延意义概念：')
add(rr(216,14),rr(113,16,18),'quote',text='有且仅有一个状态描述，描述宇宙的实际状态；它包含所有真的原子句，以及那些假的原子句的否定。因此，它只包含真句子，我们便称之为真状态描述。任何形式的句子为真，当且仅当它在真状态描述中成立。（第10页）')
add(rr(217,1),rr(113,19,20),text='请注意，维特根斯坦谈的是确定某一事态是否存在，这相对于已知内容而言；卡尔纳普却断言，可以描述“宇宙的实际状态”。')
add(rr(217,2),rr(113,21,22),text='卡尔纳普随后系统地构建一种形式对象语言，通过代入状态描述中的值来表达外延意义。内涵性陈述则用一种受约束的自然元语言[[7]]作出，以便译成对象语言，再对照状态描述加以验证。')
add(rr(217,3),rr(113,23),text='到1961年，卡尔纳普已不再认为')
add(rr(217,4),rr(113,23),'quote',text='关于事物的一切陈述，都能翻译为关于感觉材料的陈述。[[8]]')
add(rr(217,5),rr(113,24),text='此外，他现在对内涵性陈述能够多严格地转化为外延性陈述，也持谨慎态度：')
add(rr(217,6),rr(113,24,26),'quote',text='因此，我后来提出一个较弱的版本，主张每个非外延性陈述都能翻译为外延性语言中逻辑等价的陈述。这一论题似乎适用于迄今已知的一切非外延性陈述的例子，但尚未得到证明；我们只能把它作为一个猜想提出。（第ix页）',reason='底本pix是罗马页码p ix，恢复页码标注。')
add(rr(217,7),rr(113,27,28),text='不过，维特根斯坦和卡尔纳普的工作构成了模型论的基础，而模型论如今支撑着编程语言的语义。卡尔纳普的工作也继续得到发展，例如马里安·普热莱茨基的《经验理论的逻辑》。[[9]]',reason='补旧译第二句的谓语。')
add(rr(217,8),rr(113,29,33),text='对普热莱茨基而言，模型是用集合论形式化的事态或状态描述。他把模型限定于他所称的具有谓词性质的物理对象。他认为，这不足以成为物理学这类科学的基础，需要加入实数及关系、函数等高阶逻辑构造，尽管他本人并未作这种扩展（第104页）。由于科学不断发展，他还提出，可以通过截取一个“横截面”来刻画一门学科的现状，从而确定其中确定的分析知识与不确定的综合知识之间不断变化的平衡（第105—106页）。')
nt={5:'Wittgenstein：《逻辑哲学论》。',6:'R. Carnap：《意义与必然性：语义学与模态逻辑研究》（University of Chicago Press，1947）。',7:'是英语，而非黑格尔偏爱的德语。',8:'Carnap：《世界的逻辑构造；哲学中的伪问题》，第viii页。',9:'M. Przelecki：《经验理论的逻辑》（Routledge and Kegan Paul，1969）。'}
notes=[]
for n,refs in note_groups(rr(270,1)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch10-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['261'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch10b',10,rows,notes,rr(215,13)+rr(216,1,14)+rr(217,1,8))
(W/'checkpoint_ch10b.json').write_text(json.dumps({'next_source_pdf_page':217,'next_source_block':9,'next_supplied_pdf_page':113,'next_supplied_block':34,'next_unit':len(rows)+26,'next_note':10,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
