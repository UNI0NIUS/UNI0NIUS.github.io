from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch07-{len(rows)+144:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(173,4),rr(89,23,24),text='牛顿和莱布尼茨的微积分提出了尖锐的可分性问题。[[40]]具体而言，积分涉及在相邻取值的差异趋于零时，对函数值进行求和。请看图7.1，其中画出了某个函数y=f(x)的曲线。',reason='补漏40，successive不是连续函数限定。')
add(rr(173,5),rr(89,25),text=r'可以把曲线下的区域分成宽度为dx、高度为$f(x_i)$的矩形，再将面积相加，以近似曲线下的面积：')
f=r'f(0)*dx+f(x_1)*dx+f(x_2)*dx+\cdots+f(x_i)*dx\cdots'
add(rr(173,6),rr(89,26),text='$'+f+'$',english='$'+f+'$',reason='恢复原书下标与乘号，保留末尾省略形式。');rows[-1]['math_lines']=[f]
add(rr(173,7),rr(89,27,28))
add(rr(173,9),[],'figure',text='图7.1 通过面积求和进行积分。作者绘图。',reason='恢复旧译遗漏的原图及图注。')
rows[-1].update(image='assets/figure-7-1.png',source_image={'pdf_page':173,'block':8,'xref':1201},image_labels_zh='x、y：坐标轴；dx：矩形宽度；f(xᵢ)：矩形高度；f(x)：函数曲线。')
add(rr(174,1),rr(89,29))
add(rr(174,2),rr(89,30,32))
rows[-1]['editor_note']='“有无限多个值，则它们之间的差为零”为底本论述，照译；并非据此将任意两个不同实数的差视为零。'
add(rr(174,3),rr(90,0,3),fixes=[('实际存在的无穷大','实无限')])
add(rr(174,4),rr(90,4),'heading')
add(rr(174,5),rr(90,5,6),fixes=[('[[4]] [[1]]','[[41]]')])
add(rr(174,6),rr(90,7,8))
add(rr(174,7),rr(90,9),text=r'$10/3\Longrightarrow3.3333333333\ldots$',english=r'$10/3\Longrightarrow3.3333333333\ldots$')
add(rr(174,8),rr(90,10,11),text=r'不能表示成两个整数之比的数称为实数。例子有$\pi$和e。这些数也有无限展开式，但以计算它们的公式来表示，例如对有理数级数求和。',reason='保留原作者术语错误，并明确校注。')
rows[-1]['editor_note']='底本将不能表示成两个整数之比的数称为real numbers（实数），通常数学术语应为irrational numbers（无理数）；正文照录原述。'
add(rr(174,9),rr(90,12,13))
add(rr(174,10),rr(90,14))
add(rr(174,11),rr(90,15),text=r'$\{2,4,6,8,10\}$',english=r'$\{2,4,6,8,10\}$')
add(rr(174,12),rr(90,16),text=r'空集为$\{\}$。',english=r'The empty set is $\{\}$.')
add(rr(174,13),rr(90,17,19))
nt={40:'M. Tiles：《集合论哲学：康托尔乐园的历史导论》（The Philosophy of Set Theory: An Historic Introduction to Cantor’s Paradise）（Dover，1989）。',41:'Tiles：《集合论哲学》（The Philosophy of Set Theory）。'}
notes=[]
for n,refs in note_groups(rr(264,1)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch07-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['255'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
import sys
sys.path.insert(0,str(R/'tools/python_libs'))
import fitz
d=fitz.open(json.loads((W/'source_manifest.json').read_text('utf8'))['path']);fitz.Pixmap(d,1201).save(str(R/'Defending Materialism/output/assets/figure-7-1.png'))
save('ch07j',7,rows,notes,rr(173,4,7)+rr(173,9)+rr(174,1,13))
(W/'checkpoint_ch07j.json').write_text(json.dumps({'next_source_pdf_page':175,'next_source_block':1,'next_supplied_pdf_page':90,'next_supplied_block':20,'next_unit':len(rows)+144,'next_note':42,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
