from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch07-{len(rows)+30:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(164,1),rr(82,32))
for j,(p,b,t) in enumerate([(82,33,'1. 巴斯特是一位战斗女神'),(82,34,'2. 如果巴斯特是一位战斗女神，那么巴斯特保卫国王'),(83,0,'3. 所以巴斯特保卫国王')]):add([[164,2,j,j+1]],rr(p,b),'list_item',text=t,reason='warrior goddess保留女神限定，逐项恢复推理例。')
add(rr(164,3),rr(83,1))
for b,t in [(4,'没有女神；'),(5,'有女神，但没有战斗女神；'),(6,'有战斗女神，但巴斯特不是其中之一；'),(7,'巴斯特是一位战斗女神，但没有国王；'),(8,'巴斯特是一位战斗女神，但她不保卫国王；'),(9,'等等。')]:add(rr(164,b),rr(83,b-2),'list_item',text=t)
add(rr(164,10),rr(83,8,9),text='但如果我们承认“巴斯特是一位战斗女神”为真，并承认“如果巴斯特是一位战斗女神，那么她保卫国王”为真，那么显然，“巴斯特保卫国王”就是一个无可置疑的结论。',reason='accept truth是承认命题为真，不是笼统接受真值。')
add(rr(164,11),rr(83,10,11),text='也就是说，一般而言，只要假定A以及“A蕴含B”都成立，就没有人会质疑推导出B。任何争论都针对前提，而非推导；前提的真或假最终是在逻辑之外确定的。[[7]]',reason='归位旧译错放在163页的原注7；argument此处指争论。')
add(rr(164,12),rr(83,12,13),fixes=[('命名为“逻辑演算”。','命名为“逻辑演算”。[[8]]')],reason='补漏注8。')
add(rr(164,13),rr(83,14,15))
add(rr(164,14),rr(83,16,18))
add(rr(164,15),rr(83,19,20))
add(rr(164,16)+rr(165,1),rr(83,21,23),fixes=[('更深层的理想现实','更深层的观念实在')],reason='ideal reality在此不是理想现实。')
add(rr(165,2),rr(83,24),'heading')
add(rr(165,3),rr(83,25,26))
add(rr(165,4),rr(83,27,28))
add(rr(165,5),rr(83,29,31),end='因此，修辞学',text='亚里士多德指出，修辞学和辩证法都使用三段论推理和归纳推理。基于辩证三段论的推理，必须把所有步骤明确表述出来；但修辞三段论，即省略三段论，可以省略步骤。此外，辩证归纳以发现模式为基础，修辞归纳则以具体例子为基础。总的来说：')
add(rr(165,6),rr(83,31,32),'quote',start='因此，修辞学')
add(rr(165,7),rr(83,33))
nt={7:'不过，也可能通过中间的逻辑论证来确定。',8:'G. Boole：《思维规律研究》（An Investigation into the Laws of Thought）（Walton & Maberly，1854）。',9:'后文将进一步探讨这与辩证唯物主义的关系；但请注意，把同一词语的位置互换、分别用作形容词或名词，是有意义的。',10:'Aristotle：《修辞学》（The Art of Rhetoric），J. H. Freese英译，洛布古典丛书（William Heinemann，1926）。'}
notes=[]
for n,refs in note_groups(rr(263,3)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch07-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['254'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch07c',7,rows,notes,rr(164,1,16)+rr(165,1,7))
(W/'checkpoint_ch07c.json').write_text(json.dumps({'next_source_pdf_page':165,'next_source_block':8,'next_supplied_pdf_page':84,'next_supplied_block':0,'next_unit':len(rows)+30,'next_note':11,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
