from materialism_common import *
import zipfile,hashlib
O=R/'Defending Materialism/output'
for p in O.glob('*.md'):p.write_text(p.read_text('utf8'),encoding='utf8',newline='\n')
files=list((R/'tools').glob('*materialism*.py'))+list((R/'tools').glob('*materialism*.cjs'))
files+=list((W/'packets').glob('*.json'))
files+=[W/name for name in ['source_pages.json','source_manifest.json','supplied_translation_pages.json','whole_source_coverage_audit.json','image_coverage_audit.json','index_coverage_audit.json','references_coverage_audit.json','editorial_final_pass.json','site_math_audit.json','site_browser_audit.json','site_export_check.json'] if (W/name).exists()]
files+=list(W.glob('*_text_audit.json'))+list(W.glob('compile_*_2.log'))
files+=[O/name for name in ['materialism_bilingual.tex','materialism_en.tex','materialism_zh.md','glossary.md','review.md','README.md']]
files+=list((O/'assets').glob('*'))
archive=O/'materialism_source.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    z.writestr('README.md',(O/'README.md').read_text('utf8'))
    for p in sorted(set(files)):z.write(p,p.relative_to(R).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    count=len(z.namelist())
manifest={}
for name in ['materialism_bilingual.pdf','materialism_en.pdf','materialism_zh.md','glossary.md','review.md','materialism_source.zip']:
    p=O/name;manifest[name]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(O/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),'utf8')
print('Archive files:',count,'; downloads:',len(manifest))
