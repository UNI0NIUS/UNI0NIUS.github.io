from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch11-{len(rows)+73:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(229,1),rr(121,28),'heading',text='苏联辩证唯物主义')
add(rr(229,2),rr(121,29,30)+rr(122,0,1),text='辩证唯物主义由狄慈根创立，他在思想上影响了德国社会民主党；这一哲学后来成为共产主义的官方哲学，由德国社会民主党传承而来。然而，这一传统与物质世界的随机性基础是否相容，是值得怀疑的。19世纪的唯物主义者，如玻尔兹曼，曾经苦苦思索：在由偶然性和热力学定律支配的世界中，如何理解有方向性的变化？我们又该如何在历史语境中理解同一个悖论？',reason='修正旧译主语串联错误：成为官方哲学的是辩证唯物主义，不是狄慈根本人；统一姓名。')
add(rr(229,3),rr(122,2),text='苏联的“辩证唯物主义”（Diamat）学说，在多大程度上与本书迄今所阐述的唯物主义相容？')
add(rr(229,4),rr(122,3),text='长期被奉为正统权威的斯大林提出了[[16]]唯物辩证法的以下四项原则：',reason='materialist dialectics应译唯物辩证法，不是辩证唯物主义。')
items=['1. 自然界是相互联系和相互决定的','2. 自然界处于持续运动和变化的状态','3. 自然界的量变导致质变','4. 矛盾是自然界所固有的']
for i,s in enumerate(items):add([[229,5,i,i+1]],rr(122,4+i),'list_item',text=s)
add(rr(229,6),rr(122,8),text='我们将依次考察这些原则。')
add(rr(229,7),rr(122,9),'heading',text='自然界是相互联系和相互决定的',reason='旧译将小标题与引文并入同一行，恢复边界。')
add(rr(229,8),rr(122,9,11),'quote',text='与形而上学相反，辩证法并不把自然界看作事物和现象的偶然聚集，仿佛它们彼此毫无联系、相互孤立、相互独立；而把自然界看作一个相互联系的完整整体，其中事物和现象彼此有机联系、相互依存、相互决定。[[17]]')
add(rr(229,9),rr(122,12,17),text='这一论述立即引人注意的一点，是它完全属于正统力学。在两次世界大战之间，苏联的“机械论者”与德博林派曾展开激烈争论。[[18]]但斯大林在20世纪30年代对辩证唯物主义的阐述所说的、自然界通过超距作用力体现的决定关系和联系，正是经典力学和量子力学的共同基础。在量子力学中，情况也相同，正如我们在[sec:qcrypt]节对量子密码学的论述所示。物理学家玻姆[[19]]将其称为实在的“隐含序”。因此，断言自然界具有决定性并相互联系，并非辩证法所特有的东西。辩证唯物主义若持这一观点，那是因为它忠实地追随了力学。',reason='保留作者对决定论与超距作用的论断，不替作者改写；恢复implicate order为隐含序。')
rows[-1]['editor_note']='原书此处的交叉引用未解析，印作“Section [sec:qcrypt]”；本稿保留该标记。'
add(rr(229,10),rr(122,18),'heading',text='自然界处于持续运动和变化的状态',reason='恢复与下接引文的边界。')
add(rr(229,11),rr(122,18,20),'quote',text='与形而上学相反，辩证法认为，自然界并非处于静止不动、停滞不变的状态，而是处于持续运动和变化、持续更新和发展的状态；其中总有某些事物在产生和发展，也总有某些事物在瓦解和消亡。[[20]]')
add(rr(230,1),rr(122,21,23),text='运动是任何力学动力学理论的基础。一切统计力学也建立在这样一幅图景之上。通过斯密、恩格斯和达尔文，这幅图景被扩展到社会和生物学领域。确实，自古代原子论者以来，所有唯物主义者都主张自然界中存在持续的运动和变化。',reason='旧译将下段卢克莱修引文混入正文，恢复原书分段。')
add(rr(230,2),rr(122,23,25),'quote',text='太阳运行许多年之后，手指上的戒指因佩戴而在内侧变薄，檐下滴水在石头上凿出凹穴，弯曲的铁犁铧在田间不知不觉地磨损；我们看见石铺街道被众人的脚步磨平，城门旁的青铜雕像也显出右手的消瘦，那是无数过路人向它致意时触摸的结果。')
add(rr(230,3),rr(122,26,27),'quote',text='因此，我们看到这些东西因这样磨损而变小；但在任何给定时刻究竟有哪些物体离去，视觉的本性却严严实实地阻止我们看见。',reason='保留原子论引文中bodies的物体含义，不泛化为事物消失。')
add(rr(230,4),rr(122,28,30),'quote',text='最后，时间和自然一点一点地给事物添加物体，迫使它们按适当尺度生长，无论怎样用力观看，眼睛也看不见这些物体；同样，无论事物因年岁而衰老腐败，还是悬于海上的岩石被啃啮般的咸水浪沫侵蚀，你都看不见它们在任何给定时刻失去了什么。因此，自然是通过看不见的物体来运作的。[[21]]')
nt={16:'约瑟夫·维萨里奥诺维奇·斯大林，《论辩证唯物主义和历史唯物主义》（Lawrence & Wishart，1943）。',17:'斯大林，《论辩证唯物主义和历史唯物主义》，第4页。',18:'参见Emery：“辩证法与机械论：关于科学方法的一场共产主义论争”；本书前面的章节曾提及此文。',19:'玻姆，《整体性与隐含序》。',20:'斯大林，《论辩证唯物主义和历史唯物主义》，第5页。',21:'Titus Lucretius Carus，《卢克莱修全集》（Delphi Classics，2015），H. A. J. Munro译。'}
notes=[]
for n,refs in note_groups(rr(271,12)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch11-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['262'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch11g',11,rows,notes,rr(229,1,11)+rr(230,1,4))
(W/'checkpoint_ch11g.json').write_text(json.dumps({'next_source_pdf_page':230,'next_source_block':5,'next_supplied_pdf_page':122,'next_supplied_block':31,'next_unit':len(rows)+73,'next_note':22,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
