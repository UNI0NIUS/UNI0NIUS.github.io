from materialism_common import *
import sys
sys.path.insert(0,str(R/'tools/python_libs'))
import fitz

O=R/'Defending Materialism/output'
doc=fitz.open(json.loads((W/'source_manifest.json').read_text('utf8'))['path'])
images=[u for p in (W/'packets').glob('*.json') for u in json.loads(p.read_text('utf8'))['units'] if u.get('image')]
records=[]
for p,page in enumerate(doc,1):
    for im in page.get_image_info(xrefs=True):
        if p==1:
            asset='assets/source_cover.png';ident='original-cover'
        else:
            matches=[u for u in images if u['source_image']['pdf_page']==p and u['source_image'].get('xref',im['xref'])==im['xref']]
            assert len(matches)==1,(p,im['xref'],matches)
            asset=matches[0]['image'];ident=matches[0]['id']
        assert (O/asset).is_file(),asset
        records.append({'page':p,'xref':im['xref'],'unit':ident,'asset':asset})
assert len(records)==25
(W/'image_coverage_audit.json').write_text(json.dumps({'source_image_occurrences':len(records),'status':'pass','records':records,'scope_limit':'Verifies source-image mapping and asset existence; visual readability is reviewed separately.'},ensure_ascii=False,indent=2),'utf8')
print('All 25 source images mapped to preserved assets.')
