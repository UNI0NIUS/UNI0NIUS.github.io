from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch09-{len(rows)+105:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(206,1),rr(108,9,12),text='索绪尔特别关心符号如何将能指——进行指示的东西——与所指——被指示的东西，即概念或观念——结合起来。他倾向于用“符号”（sign）而非“象征”（symbol）这个词，因为符号是任意的，象征则根据其所暗示的内容来选定（第68页）。请注意，索绪尔主要关心系统中符号之间的关系，而不是语义本身；他认为意义的改变涉及“所指与能指之间关系的转移”（第75页）。')
add(rr(206,2),rr(108,13),text='最后，索绪尔暗示了语言活动与计算之间的关系，第10章将予讨论：')
add(rr(206,3),rr(108,13,15),'quote',text='语言的机制由接续各项的相互作用构成，类似机器的运转：其中的部件尽管排列在一个维度上，却具有彼此作用的功能。（第128页）',reason='successive terms不是连续术语；拆出引文。')
add(rr(206,4),rr(108,16,19),text='苏联语言学家瓦连京·沃洛希诺夫（1895—1936）试图在1929年的《马克思主义与语言哲学》[[29]]中，发展一种研究语言的辩证方法。沃洛希诺夫把洪堡学派[[30]]的个人主义主观主义与索绪尔的抽象客观主义相对置（第48页）。他拒斥索绪尔的抽象，把语言认定为完全社会性的东西，即由相互交往的说话者产生的（第98页）。因此，沃洛希诺夫将主题，即语义，视为理解的核心（第99页及以下）。',reason='semantics在此译语义而非作为学科的语义学。')
add(rr(206,5),rr(108,20,21),text='对沃洛希诺夫而言，语言是厘清马克思主义中基础与上层建筑关系问题的关键；基础即物质条件，上层建筑即社会形式（第18页及以下）。意识形态由基础决定，而词语在基础与上层建筑之间起中介作用。')
add(rr(206,6),rr(108,22,24),text='沃洛希诺夫认为，物化于言语中的语言具有首要地位。主题承载意识形态，符号具有“社会多重重音性”（第23页）。词语的评价性重音由表达性语调决定（第103页）。语调及其解释方式也反映说话者与听者的阶级取向。因此，“符号成为阶级斗争的场所”（第23页），在这里：')
add(rr(206,7),rr(108,24,26),'quote',text='统治阶级力图赋予意识形态符号一种超阶级的、永恒的性质，消灭符号内部社会价值判断之间的斗争，或者把这种斗争压入内部，使符号只有单一重音。（第23页）',reason='uniaccentual与multiaccentuality对照，统一重音而不在此改称语调。')
add(rr(206,8),rr(108,27,29),text='沃洛希诺夫赞同地引用同时代的尼古拉·马尔（1864—1934），断言“语言学是语文学的产物”。二人都批评传统语文学把话语当作脱离动态言语交往的独白来研究（第72页），但都认为可以在物质文化的背景中追溯语言的起源。',reason='philology统一语文学，与上文衔接。')
add(rr(206,9),rr(108,30,31),text='不过，与沃洛希诺夫不同，马尔认为不存在无阶级的语言。马泰卡[[31]]将沃洛希诺夫失势归因于这一分歧（第173页）。')
add(rr(206,10),rr(108,32),text='马尔也拒斥形式逻辑，认为它以阶级为基础：')
add(rr(207,1),rr(108,32,34),'quote',text='形式逻辑是阶级思维的产物，它连同创造它的阶级，被无产阶级的辩证唯物主义思维一扫而去；在这种思维中，思想取得了凌驾于语言之上的地位。（转引自马蒂亚斯[[32]]）')
add(rr(207,2),rr(108,35),text='直到1950年，马尔一直是苏联最受推崇的语言学家。')
nt={29:'V. N. Vološinov：《马克思主义与语言哲学》，L. Matejka、I. R. Tutunik英译（Seminar Press，1986）。',30:'此处不再进一步讨论。',31:'L. Matejka：“附录1：论俄国最早的符号学导论”，载《马克思主义与语言哲学》（Seminar Press，1986）。',32:'Mathias：“逻辑与恐怖”，第7页。'}
notes=[]
for n,refs in note_groups(rr(268,1)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch09-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['259'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch09g',9,rows,notes,rr(206,1,10)+rr(207,1,2))
(W/'checkpoint_ch09g.json').write_text(json.dumps({'next_source_pdf_page':207,'next_source_block':3,'next_supplied_pdf_page':108,'next_supplied_block':36,'next_unit':len(rows)+105,'next_note':33,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
