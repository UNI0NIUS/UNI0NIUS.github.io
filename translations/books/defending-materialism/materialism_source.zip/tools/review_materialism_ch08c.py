from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch08-{len(rows)+35:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(181,8),rr(94,19,20),text='在《自然辩证法》的笔记中，恩格斯区分了可以通过“物质直观”来证明的数学运算，以及只能通过演绎来证明的逻辑推演：',reason='material contemplation译物质直观，避免误作思辨；拆开引文。')
add(rr(181,9)+rr(182,1),rr(94,20,22),'quote',text='计算的理性——计算机器！——一种奇特的混淆：把数学运算与纯粹逻辑运算混在一起。数学运算可以作物质性的演示和证明，因为它们以直接的、即使是抽象的物质直观为基础；纯粹逻辑运算则只能通过演绎来证明，因而不可能具有数学运算所具有的确实性——而其中又有多少是错误的！积分机；参见安德鲁斯的演讲，《自然》，9月7日，76.317。[[8]],[[9]]',reason='合并跨页引文，补旧译漏掉的“奇特的混淆”和“证明”；positive certainty不是积极确定性，日期页码简写照录。')
add(rr(182,2),rr(94,23,24),text='无限的本性也曾是恩格斯和杜林共同关心的问题。康托尔曾颇不耐烦地驳斥杜林关于无限的论述。[[10]]恩格斯也长篇批评了杜林的无限概念。不过，恩格斯把可数性与计数混淆了：')
add(rr(182,3),rr(94,24,26),'quote',text='可是，“已经数过的无限数列”这个矛盾又该如何解释呢？只要杜林先生为我们表演一下把它数完的巧妙把戏，我们就能够更仔细地考察这个问题了。[[11]]')
add(rr(182,4),rr(94,27),'heading',text='狄慈根、辩证唯物主义与逻辑')
add(rr(182,5),rr(94,28,31),text='约瑟夫·狄慈根（1828—1888）在1848年德国革命期间结识马克思，后来成为他的朋友。狄慈根自学成才，恩格斯在《路德维希·费尔巴哈和德国古典哲学的终结》中肯定他独立发现了唯物辩证法。请留意“唯物辩证法”这一表述。它听起来像是一种以唯物主义为基础的辩证法，但这不排除唯物主义也能为其他分析方式提供基础。因此，我们可以承认一种非辩证的唯物主义科学。',reason='采用通行译名狄慈根；self-educated修饰狄慈根而非恩格斯。')
add(rr(182,6),rr(94,32,33),text='伯恩斯[[12]]认为，狄慈根阅读恩格斯关于费尔巴哈的论述后，在1887年的《一个社会主义者在认识论领域的漫游》[[13]]中创用了“辩证唯物主义”一词。[[14]]这个看似琐碎的细节，凸显了这些概念的含义是多么游移不定。',reason='补漏注12、13；厘清作者、书名与阅读对象。')
add(rr(182,7),rr(94,34,36),text='“辩证唯物主义”听起来像是一种以辩证法为基础的唯物主义，也就是不承认其他分析形式的唯物主义。正如我们将看到的，在后来的马克思主义哲学中，辩证法与科学越来越被混为一谈，二者能够彼此分离的说法也遭到争辩。不明确宣称自己具有辩证性质的科学唯物主义，则被称为机械唯物主义。')
add(rr(182,8),rr(94,37,38),text='狄慈根在最成熟的著作《哲学的积极成果》[[15]]中，把形式逻辑的前提与从这些前提作出的推演混淆了。他又把批评前提与批评推演混淆起来：')
add(rr(182,9),rr(94,38,39)+rr(95,0),'quote',text='他据以推断狗一般具有警觉性的前提，是由传统传下来的，并凭信念得到接受。但它有事实根据吗？难道不会有一些狗缺少警觉性吗？即便所有推演都很严密，我们的巴哥犬难道不可能很不可靠吗？（XIII）',reason='拆出跨页引文，faith不增译为盲目。')
add(rr(182,10),rr(95,1,2),text='狄慈根接着引用培根（以及笛卡尔）对三段论逻辑的拒斥。与黑格尔一样，这里需要的是逻辑与辩证法的一种新综合。')
add(rr(183,1),rr(95,3,6),text='狄慈根的长处在于明确揭示了辩证法的阶级视角，尤其是在较早写给儿子的书信集《逻辑书简，特别是民主的无产阶级的逻辑》[[16]]中。在这里，他批评阶级（即资产阶级）逻辑通过强调差异，将剥削合理化为自然现象。这使狄慈根把形式逻辑与阶级逻辑联系起来，因为形式逻辑把前提当作事物彼此分离的方面，并据此推理。不过，他以一种明确的先验论证，拒斥了第二条思维规律，即矛盾表明前提无效。',reason='补虚词并保持作者对第二条思维规律的表述。')
add(rr(183,2),rr(95,7),text='狄慈根呼应黑格尔的观点，对逻辑学家不屑一顾，因为他们将逻辑与其内容割裂开来：')
add(rr(183,3),rr(95,7,11),'quote',text='形式逻辑学家既无知又狡黠。他们坚持用传统方式讨论知性或思维，仿佛它们是孤立的东西，却无视逻辑研究的对象与经验世界之间的必然联系。这种相互联系会引向对真理与谬误、意义与无意义、神与偶像的说明，而这对教授们来说很不合时宜。因此，这个不受欢迎的问题被移交给神秘的部门——形而上学和宗教——好让这些官方智慧的尊贵支柱继续为统治阶级效劳。（第四封信）')
add(rr(183,4),rr(95,12,13),text='在《逻辑书简》的开头部分，狄慈根用陶工的类比来拒斥形式逻辑，认为思想不能与行动分离，形式也不能与内容分离。在这里，他似乎忘记了马克思在《资本论》第一卷中的著名论断。[[17]]')
add(rr(183,5),rr(95,14),'quote',text='但是，最蹩脚的建筑师与最灵巧的蜜蜂之间的区别在于：建筑师在现实中建造之前，已经在想象中建成了他的建筑。（第174页）',reason='独立引文，保持原文比较。')
add(rr(183,6),rr(95,15,16),text='狄慈根熟悉亚里士多德的三段论逻辑，合理地批评它无法充分把握事物多方面的属性。然而，他援引自己的革命原则，在后来的《哲学的积极成果》中说：')
add(rr(183,7),rr(95,16,18),'quote',text='哲学家们应当放弃试图用三段论证明任何事物的老嗜好。如今，一个论点并非靠言辞，而是靠事实、靠行动来证实。各门科学已充分具备所需的条件，因此“理解的可能性”得到了无可置疑的证明。（XIII）',reason='保留底本罗马数字定位，不擅加“第十三章”。')
add(rr(183,8),rr(95,19,21),text='虽然狄慈根已不再属于马克思主义主流经典，但在布尔什维克革命之前，他曾有很大影响。安东·潘涅库克在1902年《脑力劳动的本质》《逻辑书简》和《哲学的积极成果》合订本的导言中写道：')
add(rr(183,9),rr(95,20,21),'quote',text='深入研究狄慈根的哲学著作，是理解马克思和恩格斯基本著作的重要而不可或缺的辅助。[[18]]',reason='拆分作者说明和引文，保留注18。')
nt={8:'感谢Slava Gerovitch提供这一文献；间接引自S. Gerovitch《从新话到控制论话语：苏联控制论史》（MIT，2002），第48页，该处据Yanovskaya。',9:'F. Engels：“《反杜林论》的准备材料”，载《马克思恩格斯全集》第25卷（Lawrence & Wishart，1987）。',10:'G. Cantor：“一般流形论的基础：关于无限理论的数学—哲学研究”，载W. Ewald编《从康德到希尔伯特：数学基础文献集》第II卷（Clarendon Press，1996），第878—920页。',11:'Engels：《反杜林论》，第74页。',12:'T. Burns：“约瑟夫·狄慈根与马克思主义史”，Science and Society 66，第2期（2002）：202—227。',13:'J. Dietzgen：《一个社会主义者在认识论领域的漫游》，M. Beer、T. Rothstein英译（Hottingen-Zurich：Social-Democratic Library，1887），https://www.marxists.org/archive/dietzgen/1887/epistemology.htm 。',14:'感谢Ken Macleod向我推荐伯恩斯的研究。',15:'J. Dietzgen：《哲学的积极成果》，E. Untermann英译（Chicago：Charles H. Kerr and Co，1906），https://www.marxists.org/archive/dietzgen/1887/positive-outcome/index.htm 。',16:'J. Dietzgen：《逻辑书简，特别是民主的无产阶级的逻辑》，E. Untermann英译（Chicago：Charles H. Kerr and Co，1906），https://www.marxists.org/archive/dietzgen/1870s/letters-on-logic.htm 。',17:'K. Marx：《资本论》第I卷，S. Moore、E. Aveling英译（Lawrence & Wishart，1970）。',18:'Dietzgen：《哲学的积极成果》，第7页及以下。'}
notes=[]
for n,refs in note_groups(rr(265,1)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch08-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['256'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch08c',8,rows,notes,rr(181,8,9)+rr(182,1,10)+rr(183,1,9))
(W/'checkpoint_ch08c.json').write_text(json.dumps({'next_source_pdf_page':184,'next_source_block':1,'next_supplied_pdf_page':95,'next_supplied_block':22,'next_unit':len(rows)+35,'next_note':19,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
