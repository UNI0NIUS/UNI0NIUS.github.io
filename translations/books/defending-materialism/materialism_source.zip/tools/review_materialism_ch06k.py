from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch06-{len(rows)+141:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(153,8),rr(78,0,1))
add(rr(153,9)+rr(154,1),rr(78,2,4),fixes=[('垂直偏振光子为1','垂直偏振光子记为1'),('水平偏振光子为0','水平偏振光子记为0')])
add(rr(154,9),[],'figure',text='图6.6 光通过偏振片后，可以形成垂直偏振光束。若再通过相对第一片旋转45°的第二片偏振片，就得到偏振方向为45°、光子数减半的光束。作者绘图。',reason='恢复原图、图注与图内标签。')
rows[-1].update(image='assets/figure-6-6.png',source_image={'pdf_page':154,'block':8,'xref':941},image_labels_zh='unpolarised：非偏振光；Vertically polarised：垂直偏振；45deg：45°；Half of photons pass：一半光子通过。')
add(rr(154,2),rr(78,5))
add(rr(154,3),rr(78,6,7),fixes=[('＋','+')])
add(rr(154,4),rr(78,8,9),'table',text='爱丽丝的发送序列与编码偏振片。',reason='据源图恢复被旧译删错的偏振符号串，逐位保留。')
rows[-1]['table']={'headers_en':['Sequence','Meaning'],'headers_zh':['序列','含义'],'rows_en':[['1001011001','Bit stream Alice tries to send'],['xx+x++x++x','Encoding polarizer she used']],'rows_zh':[['1001011001','爱丽丝尝试发送的比特流'],['xx+x++x++x','她使用的编码偏振片']]}
add(rr(154,5),rr(78,10,13))
add(rr(154,6),rr(78,14,17),'table',text='爱丽丝的发送设置与鲍勃的接收设置和结果。',reason='恢复全部十位序列及随机位星号；旧译丢失多个x、+及*。')
rows[-1]['table']={'headers_en':['Sequence','Meaning'],'headers_zh':['序列','含义'],'rows_en':[['1001011001','Bit stream Alice tries to send'],['xx+x++x++x','Encoding polarizer she used'],['xx++x+++xx',"Bob’s polarizer settings"],['101**1*0*1','What Bob recieves, * indicates random 1 or 0']],'rows_zh':[['1001011001','爱丽丝尝试发送的比特流'],['xx+x++x++x','她使用的编码偏振片'],['xx++x+++xx','鲍勃的偏振片设置'],['101**1*0*1','鲍勃收到的结果；*表示随机的1或0']]}
rows[-1]['editor_note']='底本接收串第三位为1，而该位发送比特为0、双方偏振设置均为+，与正文匹配时正确读取的规则不符。保留原串，未静默改成100**1*0*1。'
add(rr(154,7),rr(78,18,20))
add(rr(155,1),rr(78,21))
add(rr(155,2),rr(78,22,25),text='以偏振光为例的好处，是可以借助一个只需经典欧几里得几何便能理解的简单情境，引入冯·诺伊曼用于奠定量子理论数学基础的线性代数。[[58]]请看图6.7。图中有两个参考系：H、V轴，即水平轴和垂直轴；另一个参考系的轴标为L、R，意为左与右。L、R轴相对H、V轴旋转了45°。我们假定L、R、H、V都是等长向量，并且不失一般性地假定长度为1。',reason='修复旧译插入破折号残句；without loss of generality译不失一般性而非为保持一般性；合并58注。')
add(rr(155,3),rr(78,26,27))
notes=[]
for n,refs in note_groups(rr(262,1)):
    if n!=58:continue
    notes.append({'id':'dm-ch06-note-58','kind':'note','note_number':58,'source_blocks':refs,'printed_pages':['253'],'en':extract(EN,refs,True),'zh':'58. J. von Neumann：《量子力学的数学基础》（Mathematical Foundations of Quantum Mechanics），R. T. Beyer据1931年德文版译为英文（Princeton University Press，1955）。','status':'text_compared_layout_pending'})
import sys
sys.path.insert(0,str(R/'tools/python_libs'))
import fitz
d=fitz.open(json.loads((W/'source_manifest.json').read_text('utf8'))['path']);fitz.Pixmap(d,941).save(str(R/'Defending Materialism/output/assets/figure-6-6.png'))
save('ch06k',6,rows,notes,rr(153,8,9)+rr(154,1,7)+rr(154,9)+rr(155,1,3))
(W/'checkpoint_ch06k.json').write_text(json.dumps({'next_source_pdf_page':155,'next_source_block':4,'next_supplied_pdf_page':78,'next_supplied_block':28,'next_unit':len(rows)+141,'next_note':59,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
