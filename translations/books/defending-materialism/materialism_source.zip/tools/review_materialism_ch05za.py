from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch05-{len(rows)+325:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(125,18),[],'figure',text='图5.3 矩形二维格子气系统的演化规则。每个灰色矩形代表一条规则，指示入射与出射分子的配置，并保持物质、能量和动量守恒。作者绘图。',reason='恢复中文底稿漏图及图注。')
rows[-1].update(image='assets/figure-5-3.png',source_image={'pdf_page':125,'block':17,'xref':736},image_labels_zh='每个灰框中双箭头左侧为入射配置，右侧为出射配置；细箭头表示粒子运动方向。')
add(rr(125,4,8),rr(63,24,26),text=r'由于气体中有八十个原子，平均每个格子节点有一个原子离开。因此，每条出射路径有$\frac{1}{4}$的概率被离开的原子占据，有$\frac{3}{4}$的概率为空。显然，如果以原子数相对于格点数来衡量的气体总压力更高或更低，这些概率就会不同。',english=r'Since there are eighty atoms in the gas, on average there is one atom leaving each lattice node. Each exit path thus has a $\frac{1}{4}$ chance of being occupied by a departing atom and a $\frac{3}{4}$ chance of being empty. Obviously, these chances would be different if the overall pressure of the gas, in terms of atoms to grid positions, was higher or lower.',reason='根据源图恢复分数并修复旧译断裂句。')
add(rr(125,9,16)+rr(126,1),rr(63,27,31)+rr(64,0,3),text=r'网格右半部有160条不同的出射路径。因此，右半部任何位置都没有原子的概率必定为$\left(\frac{3}{4}\right)^{160}$，约为$1.022\times10^{-20}$，即$1/100{,}000{,}000{,}000{,}000{,}000{,}000$。假设你有我们在20世纪90年代制造的那种物理装置，每秒能更新格子气两千万次，那么你必须让它运行大约150,000年，才有较大的机会使所有气体分子同时回到左半部。这还只是原子数极少的情形。汤姆森的例子假定了多得多的分子——8,000,000,000,000个，而且这些分子的运动自由度大得多。它们可以向任何方向运动，速率可以连续变化。在这样的例子中，所有分子最终聚集在同一侧的概率如此之小，以至于在我们如今估算的整个宇宙存续时间内也不会发生。[[120]]如果暗能量确实存在，相空间因而不断膨胀，那么即使宇宙具有无限的年龄，也不会出现回归。',english=r'There are 160 different exit paths on the right-hand side of the grid. The probability of there being no atoms anywhere on the right-hand side must therefore be $\left(\frac{3}{4}\right)^{160}$ which is about $1.022\times10^{-20}$ or $1/100{,}000{,}000{,}000{,}000{,}000{,}000$. Suppose you had the physical apparatus we built in the 1990s that could update a lattice gas twenty million times a second, then you would have to run it for around 150,000 years to have a good chance of the gas molecules all returning simultaneously to '+extract(EN,rr(126,1),True),reason='按源图恢复指数、分数，补漏注120；原作者概率模型与时间估值照录。')
add(rr(126,5),[],'figure',text='图5.4 尺寸为5×165的气体格子。泪滴形状表示运动方向。格子气最初处于低熵配置：所有原子都在左侧，且只具有四种可能原子动量状态中的两种。经过1,000个时间步，原子均匀分布。作者绘图。',reason='恢复旧稿漏图、完整图注，尺寸按原书照录。')
rows[-1].update(image='assets/figure-5-4.png',source_image={'pdf_page':126,'block':4,'xref':741},image_labels_zh='（a）初始状态；（b）经过1,000个时间步后的状态。',editor_note='底本图注明写5×165，与正文80个格点的说明不一致；图注尺寸保留原书，未擅改。')
add(rr(126,2),rr(64,4,5))
add(rr(126,3),rr(64,6,7))
notes=[]
for n,refs in note_groups(rr(258,1)):
    if n!=120:continue
    en=extract(EN,refs,True)
    en=en.replace('2[[10]][[23]]',r'$2^{10^{23}}$').replace('2 gm of H2',r'2 gm of $\mathrm{H_2}$').replace('2N',r'$2^N$').replace('t 0 2 10 [[9]] .',r'$t=0.2\times10^{-9}$')
    en=en.split('but even if')[0]+r'but even if we let T . be the mean time between atomic collisions with $t=0.2\times10^{-9}$ seconds, the exponential term is so great that the issue of the time constant becomes practically irrelevant.'
    notes.append({'id':'dm-ch05-note-120','kind':'note','note_number':120,'source_blocks':refs,'printed_pages':['249'],'en':en,'zh':r'120. Jean Bricmont：《理解统计力学》（Making Sense of Statistical Mechanics）（Springer，2022），第8章，估计装有2克$\mathrm{H_2}$的圆柱体达到所有分子都在容器一半中的状态，所需时间为$2^{10^{23}}$量级。这是$2^N$，其中$N$为阿伏伽德罗常数，即每摩尔气体的分子数。他没有给出表达式的时间常数。更准确地说，应对某个$T$写成$2^{10^{23}}T$；但即使令$T$为原子碰撞之间的平均时间，取$t=0.2\times10^{-9}$秒，指数项仍大到使时间常数问题在实践中无关紧要。','status':'text_compared_layout_pending','source_transcription_note':'指数与负号据原注258页图像恢复。'})
save('ch05za',5,rows,notes,rr(125,4,16)+rr(125,18)+rr(126,1,3)+rr(126,5))
(W/'checkpoint_ch05za.json').write_text(json.dumps({'next_source_pdf_page':127,'next_source_block':1,'next_supplied_pdf_page':64,'next_supplied_block':8,'next_unit':len(rows)+325,'next_note':121,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
