from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch09-{len(rows)+83:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(204,1),rr(107,3,7),text='冯·诺伊曼在1925年的博士研究中从事集合论，并于20世纪30年代初与哥德尔交流不完备性结果。他深受图灵关于通用图灵机的思想影响：数据与指令共用同一存储器。他把这一现在称为冯·诺伊曼架构的设计，纳入影响深远的《EDVAC报告初稿》。[[24]][[25]]这份报告自由流传，影响了世界各地早期数字计算机的发展。到世纪中叶，已有许多公司开发和销售冯·诺伊曼架构的计算机，尤其是在美国和英国。',english=extract(EN,rr(204,1),True).replace('[[2425]]','[[24]][[25]]'),reason='旧译将incompleteness误作完备性，改不完备性；拆开粘连注24/25。')
rows[-1]['source_transcription_note']='原PDF上标24、25相邻，恢复为两条注号；原始span保留。'
add(rr(204,2),rr(107,8,10),text='因此，尽管辩证唯物主义者和西欧哲学家都把希尔伯特纲领的失败视为对数学能力范围的限制，这一纲领仍产生了深远而持久的影响。此外，数理逻辑学家在20世纪30年代发展的形式体系，尤其是递归函数论和λ演算，长期以来一直是实用编程语言语义和设计的基础。')
add(rr(204,3),rr(107,11),'heading',text='控制论')
add(rr(204,4),rr(107,12,15),text='控制论研究“动物和机器中的控制与通信”，是二战后与计算机发展并行的一个重要研究领域。诺伯特·维纳（1894—1964）影响深远的著作[[26]]阐述了其关键原理，借助信息论、统计力学和巴甫洛夫的行为心理学，说明机器如何通过反馈来学习，并根据观察到的结果优化活动。')
add(rr(204,5),rr(107,16,19),text='与图灵一样，维纳的工作以对人类行为的抽象为基础，但侧重神经系统层面，而非高级认知。他观察到，在需要不断预测未来行为的活动中，例如操纵航行器或追踪移动目标，反馈对调节活动十分重要，而且这种调节是自主进行的（第6—8页）。维纳也承认数理逻辑对控制论的强大影响。他指出，无论对形式主义者还是直觉主义者而言：',reason='拆出引文；craft不限定飞行器。')
add(rr(204,6),rr(107,19,20),'quote',text='数理逻辑理论的发展，受到的约束与限制计算机器性能的约束属于同一种类。正如下文将看到的，甚至康托尔悖论和罗素悖论也可以这样解释。（第13页）')
add(rr(204,7),rr(107,21,22),text='也就是说，维纳认为，这些悖论限制的是一般的人类推理，而不只是数学，因为大脑就是机器。他引用图灵写道：')
add(rr(204,8),rr(107,22,23),'quote',text='逻辑研究必须归结为逻辑机器的研究，无论它是神经性的还是机械性的，都必须包括它所有不可消除的局限和缺陷。（第125页）')
add(rr(205,1),rr(107,24),text='然而，维纳认为信息既不是物质，也不是能量。因此，我们强烈反对他的如下主张：')
add(rr(205,2),rr(107,25),'quote',text='任何不承认这一点的唯物主义，在今天都不可能生存。（第132页）')
add(rr(205,3),rr(107,26),text='因为信息必须具有物质载体。')
add(rr(205,4),rr(107,27),text='维纳充分意识到控制论和计算的社会影响。他认为：')
add(rr(205,5),rr(107,27,28),'quote',text='现代工业革命……必定使人脑贬值，至少在那些较简单、较例行的决策方面如此。（第27页）')
add(rr(205,6),rr(107,29,30),text='然而，正如格罗维奇[[27]]所述，意识形态上对控制论的反对，成为苏联计算机发展的重大障碍。要说明这一点，我们需要作一个看似偏离主题的转折，考察苏联关于语言学的思想。')
add(rr(205,7),rr(107,31),'heading',text='语言学')
add(rr(205,8),rr(107,32,33),text='在19世纪的大部分时间里，语文学主导语言学研究。它通过识别不同语言词语中的共同词根，来追溯语言的起源。这些研究中的许多，因着意确立当代民族群体在历史上的先在地位而受到扭曲。',reason='philology统一语文学，区别一般语言学，不仅限于语源学。')
add(rr(205,9),rr(108,0,1),text='现代语言学由费迪南·德·索绪尔（1857—1913）奠基。他身后出版的《普通语言学教程》[[28]]于1916年问世。索绪尔区分语言（langue）与言语（parole）：',reason='统一通行书名，拆分引文。')
add(rr(205,10),rr(108,1,2),'quote',text='把（1）社会性的与个人性的分开；（2）本质的与附属的、多少带有偶然性的分开。（第14页）')
add(rr(205,11),rr(108,3,4),text='索绪尔进一步区分了两种情况：同时代的人使用相对不变的语言；以及随着使用者和用法改变，语言如何在时间中发生变化：')
add(rr(205,12),rr(108,4,5),'quote',text='凡与我们这门科学的静态方面有关的，都是共时的；凡与演变有关的，都是历时的。同样，共时性和历时性分别指语言的某种状态和某个演变阶段。（第81页）')
add(rr(205,13),rr(108,6,7),text='与语文学家不同，索绪尔认为，历时研究对于理解语言用处不大。他把语言学视为范围更广的符号学的一个组成部分：',reason='旧译“与语言学家不同”抹掉学科区别，改语文学家。')
add(rr(205,14),rr(108,7,8),'quote',text='可以设想一门研究符号在社会中生活的科学；它应是社会心理学的一部分，因而也是普通心理学的一部分。我将称之为符号学（semiology，来自希腊语sēmeîon，意为“符号”）。（第16页）')
nt={24:'电子离散变量自动计算机（Electronic Discrete Variable Automatic Computer）。',25:'J. Von Neumann：《EDVAC报告初稿》（宾夕法尼亚大学穆尔电气工程学院，1945），http://web.mit.edu/STS.035/www/PDFs/edvac.pdf 。',26:'Wiener：《控制论，或动物和机器中的控制与通信》（MIT Press，1948）。',27:'Gerovitch：《从新话到控制论话语：苏联控制论史》。',28:'F. de Saussure：“普通语言学教程”，载C. Bally、A. Sechehaye编《普通语言学教程》，W. Baskin英译（The Philosophical Society，1959）。'}
notes=[]
for n,refs in note_groups(rr(268,1)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch09-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['259'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch09f',9,rows,notes,rr(204,1,8)+rr(205,1,14))
(W/'checkpoint_ch09f.json').write_text(json.dumps({'next_source_pdf_page':206,'next_source_block':1,'next_supplied_pdf_page':108,'next_supplied_block':9,'next_unit':len(rows)+83,'next_note':29,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
