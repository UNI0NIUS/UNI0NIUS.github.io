from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch11-{len(rows)+132:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(235,2),rr(126,3,5),text='1932年，《德意志意识形态》出版，引入了“矛盾”这一术语。斯大林在1938年撰写自己的文本时，想必已熟悉这个术语。“阶级矛盾”是较晚才进入正统马克思主义的说法，首次出现在布哈林1925年著作《历史唯物主义》的英文版中。在毛泽东的辩证法中，这种意义上的矛盾成为核心。',reason='保留作者关于术语出现年代的论断，不替作者补写历史限定。')
add(rr(235,3),rr(126,6),'heading',text='毛泽东对辩证法的阐述')
add(rr(235,4),rr(126,7,9),text='毛泽东的《矛盾论》[[31]]是迄今出版的最具影响力的辩证法著作。它的影响有两个方面。首先，中国的庞大规模使它得以大量印行，拥有数千万读者。但这之所以可能，正是因为以其作者为领导的中国共产党人，把以《矛盾论》为基础的政治战略付诸实践，取得胜利并建立了中华人民共和国。',reason='书名恢复为《矛盾论》，great size不只限于领土面积。')
add(rr(235,5),rr(126,10,11),text='这篇文章比斯大林的《论辩证唯物主义和历史唯物主义》早一年问世；阅读它，必须兼顾当时苏联正在进行的争论和中国革命战争的背景。',reason='Chinese Revolutionary War译中国革命战争，保留原作者命名。')
add(rr(235,6),rr(126,12),text='前言将这篇文章定位为对受黑格尔影响的德博林学派的批判：',reason='恢复下接直接引文的段落边界。')
add(rr(235,7),rr(126,12,15),'quote',text='近年来，苏联哲学界对德博林学派唯心主义的批判，引起了我们的极大兴趣。德博林的唯心主义在中国共产党内产生了很坏的影响，不能说我们党内的教条主义思想与该学派的研究方法毫无关系。因此，我们当前研究哲学，应当以根除教条主义思想为主要目标。')
add(rr(235,8),rr(126,16,19),text='毛泽东与斯大林一样，认为辩证唯物主义世界观同对时间与变化的解释相联系。他把自己所称的形而上学或庸俗进化论的时间观，与马克思主义观点相对照。他说，庸俗进化论者承认变化，却只承认三种形式：增加、减少和循环重复。从上下文看，他所说的庸俗进化论显然不是达尔文理论，而是对社会演化的简单化观念：')
add(rr(235,9)+rr(236,1),rr(126,19,23),'quote',text='形而上学者认为，宇宙中各种事物及其一切特征，自产生之初就一直如此。此后的一切变化，都只是量的增加或减少。他们主张，一种事物只能作为同一种事物不断重复自身，不能变成别的事物。在他们看来，资本主义剥削、资本主义竞争、资本主义社会的个人主义意识形态等等，都可以在古代奴隶社会，甚至在原始社会中找到，而且会永远不变地存在下去。他们把社会发展的原因归于社会外部的因素，例如地理和气候。',reason='修正旧译跨页重复“社会等”，保持长引文完整。')
add(rr(236,2),rr(126,24,26),text='当今这种庸俗进化论观点的例子，或许可以在图尔钦的著作中找到。[[32]]他的著作虽然包含丰富的历史内容，并承认阶级冲突，却确实用数千年来基本不变的动力机制来阐述问题。图尔钦理论的关键遗漏，是马克思所说的生产力的发展，以及这种发展如何制约社会的生产关系。')
add(rr(236,3),rr(126,27,29),text='毛泽东认为，社会通过内部冲突发展，而非由外部原因推动。他认为，中国的发展将取决于国内的阶级斗争，即工人、农民和爱国资本家同地主、买办资本家之间的斗争。从印度和中国此后的经济与社会发展轨迹来看，这一观点被证明是正确的。')
add(rr(236,4),rr(126,30,33),text='他讨论了矛盾的普遍性和特殊性。前者概括恩格斯与列宁的概念，后者则是这篇小册子的重点，分析中国革命中的具体矛盾。他批评教条主义，并突出列举了一些矛盾普遍性的例子；这些例子并不比恩格斯和斯大林的更有说服力。不过，他确实提出了一些值得更多关注的例子。他引用了列宁列出的一组例子，用来说明矛盾的普遍性。',reason='下段“辩证法这一方面”开始的列宁引文与作者叙述分开。')
notes=[]
for n,refs,zh in [(31,[[272,3,10,11]],'毛泽东，《矛盾论》，载《毛泽东选集》第1卷（1937）。'),(32,[[272,3,11,13]],'Peter Turchin、Sergey A. Nefedov：“长期周期”，载《长期周期》（Princeton University Press，2009）。')]:
    notes.append({'id':f'dm-ch11-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['263'],'en':extract(EN,refs,True),'zh':str(n)+'. '+zh,'status':'text_compared_layout_pending'})
save('ch11l',11,rows,notes,rr(235,2,9)+rr(236,1,4))
(W/'checkpoint_ch11l.json').write_text(json.dumps({'next_source_pdf_page':236,'next_source_block':5,'next_supplied_pdf_page':126,'next_supplied_block':33,'next_unit':len(rows)+132,'next_note':33,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
