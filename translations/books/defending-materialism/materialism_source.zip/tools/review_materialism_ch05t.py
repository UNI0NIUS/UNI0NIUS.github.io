from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch05-{len(rows)+258:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(116,1),rr(58,33),end='经验表')
add(rr(116,2),rr(58,33,36),'quote',start='经验表',fixes=[('[[9]] [[3]]','[[93]]')])
add(rr(116,3),rr(58,37,38)+rr(59,0,2),end='现代心',fixes=[('但在当时，盖伦的“气”','但在盖伦所处的时代，他的“气”')],reason='in its own day指盖伦理论诞生的时代，旧译当时可能误指达尔文时代。')
add(rr(116,4),rr(59,2,6),'quote',start='现代心理学',fixes=[('工作假设。我们迄今','工作假设。……我们迄今'),('[[9]] [[4]]','[[94]]')],reason='补回源引文中间删节号。')
add(rr(116,5),rr(59,7,9),end='“自我”',fixes=[('[[9]] [[5]]','[[95]]')])
add(rr(116,6),rr(59,9,14),'quote',start='“自我”',fixes=[('通过武力或诡计相互制衡','凭力量或诡计彼此压倒'),('只要其任何问题尚未解决','只要它仍有这么多问题尚未解决'),('[[9]] [[6]]','[[96]]')],reason='overcoming不是相互制衡；so many不等于任何一个，旧译强化了条件。')
add(rr(117,1),rr(59,15,16),fixes=[('生命论','活力论'),('[[9]] [[7]]','[[97]]')],reason='vitalism全书统一为活力论。')
nt={93:'Darwin：《人和动物的情感表达》。',94:'Hebb：“行为的组织：神经心理学理论”（The Organization of Behavior; A Neuropsycholocigal Theory）。',95:'关于这一分歧，参见Harry K. Wells：《西格蒙德·弗洛伊德：巴甫洛夫学派的批判》（Sigmund Freud, a Pavlovian Critique）（International Publishers，1960）。',96:'Hebb：“行为的组织：神经心理学理论”（The Organization of Behavior; A Neuropsycholocigal Theory）。',97:'Sebastiano Timpanaro：《论唯物主义》（On Materialism）（Routledge，2003）。'}
notes=[]
for p in [256,257]:
    for n,refs in note_groups(rr(p,1)):
        if n not in nt:continue
        notes.append({'id':f'dm-ch05-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':[str(p-9)],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch05t',5,rows,notes,rr(116,1,6)+rr(117,1))
(W/'checkpoint_ch05t.json').write_text(json.dumps({'next_source_pdf_page':117,'next_source_block':2,'next_supplied_pdf_page':59,'next_supplied_block':17,'next_unit':len(rows)+258,'next_note':98,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
