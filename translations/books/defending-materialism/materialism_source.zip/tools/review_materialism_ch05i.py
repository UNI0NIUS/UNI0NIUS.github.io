from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch05-{len(rows)+109:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(96,1),rr(46,19,21))
add(rr(96,2),rr(46,22,23),fixes=[('[[4]] [[8]]','[[48]]')])
add(rr(96,3),rr(46,24,27),fixes=[('指示图','示功图')],reason='indicator diagram在蒸汽机工程中译示功图。')
add(rr(96,4),rr(46,28,30),fixes=[('指示图','示功图')])
add(rr(96,5),rr(46,31)+rr(47,0,1),fixes=[('蒸汽动力磨坊','蒸汽动力工厂'),('工作能力','劳动能力'),('所完成的工作','所完成的劳动')],reason='mill在工业背景下不应狭义译作磨坊；保留劳动力与实际劳动的区别。')
add(rr(96,6),rr(47,2,4),fixes=[('10\\times60\\times60\\times550=19,800,000',r'$10\times60\times60\times550=19{,}800{,}000$'),('煤炭提升工作','煤炭提升功'),('实际完成的工作','实际所做的功')],english=extract(EN,rr(96,6),True).replace('10 60 60 550 19 800 000 , ,',r'$10\times60\times60\times550=19{,}800{,}000$'))
add(rr(96,7),rr(47,5,10),end='因此，工作日',fixes=[('从马克思把劳动、所做工作引入作为价值实质的那一刻起，他就把它等同于劳动力消耗——即工作能力。','从马克思把劳动，即所做的功，引入为价值实体的那一刻起，他就把它等同于劳动力——劳动能力——的耗费。'),("M\\to C\\to M'",r"$M\to C\to M'$"),('所需口粮','所需生活资料'),('没有必要在六小时后让工人下班','不受任何必须在六小时后让工人下班的强制')],english=extract(EN,rr(96,7),True).replace('M C M .',r"$M\to C\to M'$."),reason='原译破折号误将工作能力解释为消耗；sustenance不限于口粮，no compulsion指无强制要求而非没有必要。')
add(rr(97,1),rr(47,10,12),'quote',start='因此，工作日')
add(rr(97,2),rr(47,13,18),'quote',fixes=[('[[4]] [[9]]','[[49]]')])
add(rr(97,3),rr(47,19,21))
add(rr(97,4),rr(47,22,23),'list_item')
add(rr(97,5),rr(47,24,26),'list_item',fixes=[('工资商品','工资购买的生活资料')],reason='wage goods意为劳动者以工资购买的消费品。')
add(rr(97,6),rr(47,27,29),'list_item',text='类似于牛顿的轨道力学，马克思表述了一个维持资本对劳动支配的循环过程（见图5.1，该图根据Cockshott、Cottrell与Michaelson计算的数据绘制[[50]]）。他把这称为资本积累的一般规律。这是支配资本主义社会的运动规律。',reason='formulates指表述规律而非制定过程，恢复原注50。')
add(rr(97,7),rr(47,30,32))
nt={48:r'使用国际单位制，所做的功等于发动机施加的力乘以该力作用的距离，因此单位为牛顿·米。但力等于质量乘以加速度，所以这换算为（千克·米/秒$^2$）·米，与动能$\frac{1}{2}mv^2$具有相同量纲。',49:'马克思：《资本论》，第162页。',50:'W. Paul Cockshott、A. Cottrell与G. J. Michaelson：《用投入产出表检验劳动价值论》（Testing Labour Value Theory with Input/output Tables）（斯特拉斯克莱德大学计算机科学系，1993）。'}
notes=[]
groups=[(48,[[255,1,16,19]]+rr(255,2,3))]+[(n,refs) for n,refs in note_groups([[255,4,0,4]])]
for n,refs in groups:
    en=extract(EN,refs,True)
    if n==48:en=r'48 Using SI units, work done is force applied by the engine times distance it was applied thus Newton Metres. But force is mass times acceleration, so this translates to (Kilogram Meter/Second$^2$) Metres, which has the same dimensions as kinetic energy $\frac{1}{2}mv^2$.'
    notes.append({'id':f'dm-ch05-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['246'],'en':en,'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch05i',5,rows,notes,rr(96,1,7)+rr(97,1,7))
(W/'checkpoint_ch05i.json').write_text(json.dumps({'next_source_pdf_page':98,'next_source_block':1,'next_supplied_pdf_page':47,'next_supplied_block':37,'next_unit':len(rows)+109,'next_note':51,'pending_figure':'PDF98 Figure5.1; supplied Chinese PDF47 blocks33-36','full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
