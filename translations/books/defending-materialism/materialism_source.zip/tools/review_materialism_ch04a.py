from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch04-{len(rows)+1:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(68,0,2),rr(31,9),'chapter',english='Chapter 4. DIALECTICS, MATERIALISM, CHANGE FROM EPICURUS TO MARX VIA ARISTOTLE')
add(rr(68,3),rr(31,10),'heading',text='黑格尔重新构造之前的辩证法',reason='reinvention比重新诠释更强调重新构造。')
add(rr(68,4),rr(31,11,18),fixes=[('众所周知，','想必这是一个广为人知的事实：'),('《修辞学》中所说','《修辞学》[[1]]中所说'),('必然特征。','必然特征。[[2]]'),('结论——任何','结论——[[3]]任何'),('称之为technē——','称之为technē——[[4]]')],reason='恢复原注1—4及presumably的语气。')
add(rr(68,5),rr(31,19,23))
add(rr(68,6)+rr(69,1),rr(31,24,32),fixes=[('观念。因此，','观念。[[5]]因此，')],reason='恢复原注5。')
add(rr(69,2),rr(32,0,4),fixes=[('彼此独立且互不关联','彼此区分、相互处于单边关系之中[[6]]')],reason='unilateral不是互不关联，而是拉鲁埃尔方法论的单边关系；原注6作专门说明。')
add(rr(69,3),rr(32,5),'heading')
en=extract(EN,rr(69,4)+rr(70,1),True).replace('συλλογισμ όν','συλλογισμόν')
add(rr(69,4)+rr(70,1),rr(32,6,18),english=en,fixes=[('Maßstab 极为相似。','Maßstab（尺度）极为相似。[[7]]'),('ὥσπερ καὶἐπὶτῆς διαλεκτικῆς συλλογισµόν τε καὶφαινόµενον συλλογισµόν','ὥσπερ καὶ ἐπὶ τῆς διαλεκτικῆς συλλογισμόν τε καὶ φαινόμενον συλλογισμόν'),('《修辞学》1:1），或译','《修辞学》1:1）[[8]]，或译')],reason='补原注7、8，恢复希腊语分词空格与μ字母，接合跨页单词。')
add(rr(70,2),rr(32,19,22),end='因此，存在')
add(rr(70,3),rr(32,22,29),'quote',start='因此，存在',fixes=[('λαβεῖν τοῦσυλλογίσασθαι δυναµένου','λαβεῖν τοῦ συλλογίσασθαι δυναμένου'),('理解人类品性及其各种表现形式','理解人类品性与善的各种形式')],reason='旧译漏掉goodness；恢复希腊语原字形与空格。')
add(rr(70,4),rr(32,30,31),end='因此，很明显')
add(rr(70,5)+rr(71,1),rr(32,31,39),'quote',start='因此，很明显',fixes=[('而“辩证家”则，其重点不在于道德目的，而在于其能力','而称他为“辩证家”，依据的不是他的道德目的，而是他的能力')],reason='修复句法，保持moral purpose与faculty的区分。')
nt={
1:'亚里士多德：《修辞学》（Ars Rhetorica），W. D. Ross编（Clarendon Press，1959），1:1。',
2:'Matthewe Duncombe、Catarina Dutilh Novaes：“亚里士多德及其传统中的辩证法与逻辑”（Dialectic and Logic in Aristotle and his Tradition），History and Philosophy of Logic，第37卷第1期（2015），第1—8页。',
3:'亚里士多德：《修辞学》，W. Rhys Roberts译（Bexar County, TX：Bibliotech Press，2012），引自Internet Classics Archive，http://classics.mit.edu/Aristotle/rhetoric.1.i.html（访问日期：2021年11月27日），第1卷第1部分。',
4:'下文将更详细地讨论这里的区分，并提供英文译文及原文引证。',
5:'出自马克思博士论文关于矛盾、形式的对象化和关系的对象化的论述：“原子通过性质获得了一种与其概念相矛盾的存在；它被设定为不同于自身本质的、外化了的存在。伊壁鸠鲁主要关心的正是这一矛盾。因此，他一旦设定一种属性，从而得出原子的物质本性的后果，就同时与之相对地设定一些规定，这些规定又在该属性自身范围内破坏它，转而使原子的概念得到确认。因此，他以使各种属性自相矛盾的方式规定它们。相反，德谟克利特从不联系原子本身来考察属性，也不把其中固有的概念与存在之间的矛盾对象化。”引自卡尔·马克思：《德谟克利特的自然哲学和伊壁鸠鲁的自然哲学的差别》，《马克思恩格斯全集》英文版第1卷（Progress Publishers，1975），无页码，引自Karl Marx Internet Archive，https://www.marxists.org/archive/marx/works/1841/dr-theses/index.htm（访问日期：2021年11月27日）。',
6:'这里我们采用弗朗索瓦·拉鲁埃尔阐发的单边化（unilateralization）或双重分析（dualysis）方法。它以拆解哲学“世界”为前提：哲学按定义设定实在，并把这一设定当作实在本身。这涉及歧义（amphibology）与“决断主义”的问题。拉鲁埃尔在许多著作中将其问题化，尤其在《哲学与非哲学》（Philosophy and Non-philosophy），Taylor Adkins译（明尼苏达大学出版社，2013）的开篇数章中作了更细致的讨论。',
7:'路德维希·维特根斯坦：《逻辑哲学论》（Tractatus Logico-Philosophicus）（Kegan Paul, Trench, Trubner & Co., Ltd.，1922），Gutenberg Project（访问日期：2021年11月27日），2.150、2.511、2.1512及其他多处。',
8:'亚里士多德：《修辞学》（Ars Rhetorica），1:1，第14节，http://www.perseus.tufts.edu/hopper/text?doc=Perseus%3Atext%3A1999.01.0059%3Abook%3D1%3Achapter%3D1%3Asection%3D14（访问日期：2021年11月27日）。',
9:'W. Rhys Roberts的译文引自MIT的Internet Classics Archive，http://classics.mit.edu/Aristotle/rhetoric.1.i.html（访问日期：2021年11月27日）。'}
notes=[]
for n,refs in note_groups([[249,3],[250,1]]):
    if not n or n>11:continue
    en=extract(EN,refs,True).replace('\u200b','')
    for a,b in [('hopper/ text','hopper/text'),('Aristotle/ rhetoric','Aristotle/rhetoric'),('archive/ marx','archive/marx'),('tufts .edu','tufts.edu'),('1999 .01','1999.01'),('1 %3Asection','1%3Asection')]:en=en.replace(a,b)
    if n==10:
        greek=en.split('it reads:')[1].split('The source in Greek is:')[0].strip()
        nt[n]='引文出自W. Rhys Roberts的译本；其希腊原文为：'+greek+' 希腊文出处：亚里士多德《修辞学》（Ars Rhetorica），引自Perseus Tufts网络文献库，http://www.perseus.tufts.edu/hopper/text?doc=Perseus%3Atext%3A1999.01.0059（访问日期：2021年11月21日），1:2，第7节。'
    if n==11:
        greek=en.split('it reads:')[1].split('The source in Greek is:')[0].strip()
        nt[n]='引文出自W. Rhys Roberts的译本，引自MIT的Internet Classics Archive，http://classics.mit.edu/Aristotle/rhetoric.1.i.html（访问日期：2021年11月21日）；其希腊原文为：'+greek+' 希腊文出处：亚里士多德《修辞学》（Ars Rhetorica），引自Perseus Tufts网络文献库，http://www.perseus.tufts.edu/hopper/text?doc=Perseus%3Atext%3A1999.01.0059（访问日期：2021年11月21日），1:1，第14节。'
    notes.append({'id':f'dm-ch04-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':list(dict.fromkeys(str(x[0]-9) for x in refs)),'en':en,'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
expected=rr(68,0,6)+rr(69,1,4)+rr(70,1,5)+rr(71,1)
save('ch04a',4,rows,notes,expected)
(W/'checkpoint_ch04a.json').write_text(json.dumps({'next_source_pdf_page':71,'next_source_block':2,'next_supplied_pdf_page':32,'next_supplied_block':40,'next_unit':len(rows)+1,'next_note':12,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
