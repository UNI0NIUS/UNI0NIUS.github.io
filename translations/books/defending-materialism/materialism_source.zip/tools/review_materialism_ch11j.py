from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch11-{len(rows)+109:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(232,9)+rr(233,1),rr(124,22,23),text=r'在符号逻辑中，有一个所谓的可满足性问题（SAT）。给定一个定义在$n$个布尔变量$v_1,\ldots,v_n$上的布尔代数公式$F$，问题要求找出一种变量真值赋值，使$F$为真。',english=r'In symbolic logic, there is something called the satisfaction problem (SAT). The problem takes some formula $F$ in Boolean algebra defined over $n$ Boolean variables $v_1,\ldots,v_n$ and seeks to find an assignment of truth values to the variables such that $F$ is true.',reason='恢复跨页变量下标；SAT统一为可满足性问题。')
add(rr(233,2),rr(124,24),text=r'$F$通常以合取范式给出，例如：')
formula=r'F(v_1,v_2,v_3,v_4)=(v_1+v_2+\neg v_3)\cdot(v_3+\neg v_1+v_4)'
add(rr(233,3),rr(124,25),'equation',text='$'+formula+'$',english='$'+formula+'$')
rows[-1]['math_lines']=[formula]
add(rr(233,4),rr(124,26,27),text=r'人们观察到，找到这样的变量赋值往往很容易，但有时又十分困难；在极端情况下，需要尝试给$n$个变量赋予真或假的全部$2^n$种不同方案。',english=r'It has been observed that it is often very easy to find such an assignment of variables, but at other times it becomes very hard, requiring in the limiting case that one tries all $2^n$ possible distinct assignments of true or false to the $n$ variables.')
add(rr(233,5),rr(124,28),text=r'对于另一些$F$，却很容易证明不存在任何能使$F$为真的变量赋值。')
add(rr(233,6),rr(124,29,31),text=r'进一步研究表明，从容易满足到难以满足、再到容易证明不可满足的变化，发生在一个被称为相变的临界点。[[26]]这一领域的实验工作为相变这一用语提供了依据：它表明，$F$存在一个约束程度的度量[[27]]$m$，随着$m$增大，问题难度先急剧上升，随后下降。为什么这类似于相变？',reason='旧译漏掉注27，恢复其在约束程度度量之后的位置。')
add(rr(233,7,10),rr(125,0,2),text=r'它与水沸腾有什么共同之处？二者相似，是因为约束水平$m$相当于温度$T$，而难度（用计算运行时间衡量）相当于$\frac{dH}{dT}$，即熵对温度的导数。显然，在水转化为蒸汽的相变中，$\frac{dH}{dT}$出现尖峰，类似于$F$的难度随着$m$增大而出现尖峰。',english=r'What does it have in common with water boiling? They are similar because the constraint level $m$ acts as an analogue for temperature $T$, and the hardness (measured as computational run time) is analogous to $\frac{dH}{dT}$ the derivative of entropy with respect to temperature. Obviously, in the water-to-steam phase, transition $\frac{dH}{dT}$ spikes analogous to the way that the hardness of $F$ spikes as $m$ increases.',reason='恢复两处导数公式；hardness统一为问题难度，不译硬度。')
notes=[]
for n,refs,zh in [(26,[[272,3,0,4]],'Ian P. Gent等：“CSP相变中的尺度效应”，载International Conference on Principles and Practice of Constraint Programming（Springer，1995），70—87；P. Prosser：“二元约束满足问题中相变的实证研究”，Artificial Intelligence 81，第1—2期（1996）：81—109。'),(27,[[272,3,4,7]],r'假设$F$的每个求和项包含3个变量（3SAT），那么约束程度的一个度量，可以是$F$中求和项的数量与变量数$n$的比值。')]:
    notes.append({'id':f'dm-ch11-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['263'],'en':extract(EN,refs,True),'zh':str(n)+'. '+zh,'status':'text_compared_layout_pending'})
save('ch11j',11,rows,notes,rr(232,9)+rr(233,1,10))
(W/'checkpoint_ch11j.json').write_text(json.dumps({'next_source_pdf_page':233,'next_source_block':11,'next_supplied_pdf_page':125,'next_supplied_block':3,'next_unit':len(rows)+109,'next_note':28,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
