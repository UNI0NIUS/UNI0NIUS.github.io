from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch03-{len(rows)+214:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(52,12),rr(23,16),'heading')
add(rr(52,13),rr(23,17))
add(rr(52,14,15),rr(23,18,20),text=r'显然，物体的速度 $v$ 与轨道半径成正比，与轨道周期成反比。如果在 $t_0$ 时刻，物体的速度向量为 $[0,v]$，那么四分之一圈之后，在 $t_{90}$ 时刻，它的速度将为 $[-v,0]$。它在X方向的全部初速度都已被抵消。转动周期越长，这一减速过程越缓慢。因此，向心加速度与半径成正比，与轨道周期的平方成反比。',english=r'Clearly, the velocity $v$ of the body is proportional to the radius of the orbit and inversely proportional to period of the orbit. If at time $t_0$ the body has velocity vector $[0,v]$, then at time $t_{90}$ a quarter rotation later its velocity will be $[-v,0]$. Its entire initial velocity in the X direction has been cancelled. The longer the period of rotation, the more gradual this deceleration will be. So the centripetal acceleration is directly proportional to radius and inversely proportional to the square of the orbital period.')
rows[-1]['editor_note']='底本所列初速度[0,v]的X分量本来为零；按通常坐标约定，被抵消的是初始Y分量。这里保留底本X方向的表述并指出不一致。'
add(rr(52,16),rr(23,21),'equation',r'$A_c\propto r/p^2$',english=r'$A_c\propto r/p^2$')
add(rr(52,17),rr(23,22))
add(rr(52,18,19),rr(23,23))
add(rr(52,20),rr(23,24),'equation',r'$A_g\propto 1/r$',english=r'$A_g\propto 1/r$')
add(rr(52,21,22),rr(24,0,1))
add(rr(53,1,2),rr(24,2),'equation',r'$A_g\propto 1/r^2$',english=r'$A_g\propto 1/r^2$')
add(rr(53,3,4),rr(24,3,4))
add(rr(53,5,6),rr(24,5),'equation',r'$A_g\propto 1/r^3$',english=r'$A_g\propto 1/r^3$')
add(rr(53,7),rr(24,6),text=r'如果引力加速度就是向心加速度，则有 $A_c=A_g$。当引力与距离成反比时，就有：',english=r'If gravitational acceleration is the centripetal acceleration, we have $A_c=A_g$. In the case of gravity being inversely proportional to distance, we then have')
add(rr(53,8,10),rr(24,7),'equation',r'$1/r\propto r/p^2$',english=r'$1/r\propto r/p^2$')
add(rr(53,11),rr(24,8,9),fixes=[('几乎完美。火星','几乎完美。离心率数据见表3.2。火星')],reason='补回漏掉的表3.2交叉引用。')
add(rr(53,12),rr(24,10),text=r'因此可得 $p^2\propto r^2$，以及 $p\propto r$。我们可以为三种定律列出类似关系表（表3.1）。',english=r'So it follows that $p^2\propto r^2$ and $p\propto r$. We can construct a table of similar relations for the three laws (Table 3.1).',reason='旧译误改为平方反比情形的r³及r^(3/2)，但此处仍在推导一次反比情形。')
add(rr(53,13),rr(24,11,12))
add(rr(53,16),[],'figure','图3.4 轨道半径与周期的关系。作者绘图。',reason='恢复旧译遗漏图及图注。')
rows[-1].update(image='assets/figure-3-4.png',source_image={'pdf_page':53,'block':15},image_labels_zh='纵轴：轨道周期（地球日）；横轴：半长轴（天文单位）；Actual data：实际数据；Power -1/-2/-3 law：-1/-2/-3次幂定律。',editor_note='原图注semi-redius疑为semi-radius误拼；图中横轴明确标为半长轴。英文保留底本。')
add(rr(54,16,27),[],'table','表3.1 牛顿考虑的三种引力定律，以及它们对轨道周期与轨道半径关系的预测。',english='Table 3.1 The Three Gravity Laws Considered by Newton and Their Predicted Relations of Orbital Period to Orbital Radius',reason='旧中文稿遗漏全表，按源PDF恢复。')
rows[-1]['table']={'headers_en':['Power law','Centripental acceleration','Gravity acceleration','Period law',''],'headers_zh':['幂次','向心加速度','引力加速度','周期定律',''],'rows_en':[[r'$-1$',r'$A_c\propto 1/p^2$',r'$A_g\propto 1/r$',r'$p^2\propto r^2$',r'$p\propto r$'],[r'$-2$',r'$A_c\propto 1/p^2$',r'$A_g\propto 1/r^2$',r'$p^2\propto r^3$',r'$p\propto\sqrt{r^3}$'],[r'$-3$',r'$A_c\propto 1/p^2$',r'$A_g\propto 1/r^3$',r'$p^2\propto r^4$',r'$p\propto r^2$']]}
rows[-1]['table']['rows_zh']=rows[-1]['table']['rows_en']
rows[-1]['editor_note']='原表向心加速度栏合并三行，写作A_c∝1/p²，漏掉前文随半径变化的因子r。这里保留其公式，并在每行重复展示以便阅读；正文给出的关系为A_c∝r/p²。'
add(rr(54,4,15),[],'table','表3.2 太阳系实际轨道数据与牛顿所考虑的三种可能引力定律的预测比较。',english='Table 3.2 Actual Orbital Data from the Solar System Compared with the Predictions of the Three Possible Gravity Laws Considered by Newton',reason='旧中文稿遗漏全表，按原表恢复各项数据。')
data=[['Venus','225','0.72','264','224','138','0.01'],['Earth','365','1.00','365','365','365','0.02'],['Mars','867','1.52','556','687','1292','0.09'],['Jupiter','4331','5.22','1906','4355','51960','0.05'],['Saturn','10747','9.11','3324','10032','275723','0.05'],['Neptune','59800','30.18','11016','60518','10033936','0.01']]
rows[-1]['table']={'headers_en':['Power law','Actual period','Radius',r'Period predicted if $A_g\propto 1/r$',r'Period predicted if $A_g\propto 1/r^2$',r'Period predicted if $A_g\propto 1/r^3$','Eccentricity'],'headers_zh':['幂律','实际周期','半径',r'$A_g\propto 1/r$预测周期',r'$A_g\propto 1/r^2$预测周期',r'$A_g\propto 1/r^3$预测周期','离心率'],'rows_en':data,'rows_zh':[[z]+r[1:] for z,r in zip(['金星','地球','火星','木星','土星','海王星'],data)]}
rows[-1]['editor_note']='数据照录底本：火星实际周期在本表为867，前表为687；立方反比栏的数值近似按365r³而非表3.1给出的365r²计算。其他半径及周期数据未在译文中自行替换。本表首列表头原作Power law，实际列出行星。'
add(rr(53,14)+rr(54,0),rr(24,13,14))
add(rr(54,1),rr(24,15,16),'quote')
add(rr(54,2),rr(24,17,19))
add(rr(54,3)+rr(55,1),rr(24,20,22))
add(rr(55,2),rr(24,23,24))
add(rr(55,3),rr(24,25,26))
add(rr(55,4),rr(24,27,28),end='最后，我们')
add(rr(55,5),rr(24,28,29),'quote',start='最后，我们')
add(rr(55,6),rr(24,30),end='他的论证如下')
add(rr(55,7),rr(24,30,31)+rr(25,0,2),start='他的论证如下',fixes=[('巨大体积','巨大的规模'),('力量和能量','力与力量')],reason='power在哲学转述中不是已定义的能量物理量。')
add(rr(55,8)+rr(56,1),rr(25,3,8),fixes=[('体现在恩格斯、路德维希·费尔巴哈和《反杜林论》中','体现在恩格斯的《路德维希·费尔巴哈》和《反杜林论》中')],reason='两者是恩格斯著作，旧译将作者、书名误列成三项。')
add(rr(56,2),rr(25,9,14))
add(rr(56,3),rr(25,15,16),end='原子所经历')
add(rr(56,4),rr(25,16,21),'quote',start='原子所经历',fixes=[('力可被抽象，可设想作为物质本身','可以抽去力，从而设想物质本身')],reason='abstracted在此指抽离该属性，不是把力概念抽象化。')
add(rr(56,5),rr(25,22,25),fixes=[('空间导数较低','空间导数的阶数相对较低')],reason='low spatial derivatives指低阶空间导数，不单是数值较小。')
add(rr(56,6),rr(25,26,27),end='构成世界的')
add(rr(57,1),rr(25,27,29),'quote',start='构成世界的',fixes=[('因此不同点力方向不同','因此，只有不同点的力才在方向上有所不同')],reason='恢复only限制条件。')
add(rr(57,2),rr(25,30,32))
add(rr(57,3),rr(25,33,34))
add(rr(57,4),rr(25,35))
title='黑格尔：“关于行星轨道的哲学论文（1801），附1801年8月27日答辩的十二条论题”'
nt={27:title+'，第285页。',28:title+'，第285页。',29:title+'，第290页。',30:title+'，第296页。',31:'弗拉基米尔·伊里奇·列宁：《马克思主义的三个来源和三个组成部分》，第1卷（外文出版社，1977）。',32:title+'，第294页。',33:'A. 埃默里：“辩证法与机械论：一场关于科学方法的共产主义论争”（Dialectics versus Mechanics. A Communist Debate on Scientific Method），Philosophy of Science，第2卷第1期（1935），第9—38页。',34:'“外力是施加于物体以改变其状态的一种作用，无论该状态是静止，还是沿直线匀速向前运动。”',35:'埃默里：“辩证法与机械论：一场关于科学方法的共产主义论争”。'}
notes=[]
for n,refs in note_groups([[248,2]]):
    if n not in nt:continue
    notes.append({'id':f'dm-ch03-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['239'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
expected=rr(52,12,22)+[[p,b['block']] for p in range(53,57) for b in EN[p-1]['blocks'] if b.get('lines') and (p==54 or b['block']>0)]+rr(57,1,4)
save('ch03e',3,rows,notes,expected)
(W/'checkpoint_ch03e.json').write_text(json.dumps({'next_source_pdf_page':57,'next_source_block':5,'next_supplied_pdf_page':25,'next_supplied_block':36,'next_unit':len(rows)+214,'next_note':36,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
