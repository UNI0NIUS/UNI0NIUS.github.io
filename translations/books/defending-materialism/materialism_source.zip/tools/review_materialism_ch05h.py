from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch05-{len(rows)+94:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(94,3),rr(45,22))
add(rr(94,4),rr(45,23),text=r'$C_1\to M\to C_2$',english=r'$C_1\to M\to C_2$')
add(rr(94,5),rr(45,24,26),text=r'卖方起初持有商品1（$C_1$），将其换成等值的货币$M$，再用这笔货币购买一定量的商品2（$C_2$）。由于交换是一种等价关系，因而具有传递性，起点和终点的价值就相同，即$C_1\equiv C_2$。一切看起来都公平而妥当，直到马克思指出：资本家所做的并不是这样。他们的活动采取如下形式：',english=extract(EN,rr(94,5),True).replace('(C1)',r'($C_1$)').replace('( C2 )',r'($C_2$)').replace('C C 1 2 ≡',r'$C_1\equiv C_2$'))
add(rr(94,6),rr(45,27),text=r"$M\to C\to M'$",english=r"$M\to C\to M'$")
add(rr(94,7,8),rr(45,28,29),text=r"其中，最终的货币量大于起初的货币量：$M'>M$。差额$S=M'-M$就是马克思所说的资本家的剩余价值。显然，$M\to C\to M'$违反了商品交换的等价性质。",english=r"Where the final quantity of money is greater than what he starts out with: $M'>M$. The difference $S=M'-M$ is what Marx calls the capitalist’s surplus value. It is evident that $M\to C\to M'$ violates the equivalence property of commodity exchange.")
add(rr(94,9)+rr(95,1),rr(45,30,31),fixes=[('[[4]] [[6]]','[[46]]')])
add(rr(95,2),rr(45,32,34)+rr(46,0,3),fixes=[('初始M','初始货币$M$'),('不变资本c 和可变资本v','不变资本$c$和可变资本$v$'),('M=c+v',r'$M=c+v$')],english=extract(EN,rr(95,2),True).replace('M c v .',r'$M=c+v$.'))
add(rr(95,3),rr(46,4),end='这不会')
add(rr(95,4),rr(46,4,6),'quote',start='这不会',fixes=[('[[4]] [[7]]','[[47]]')])
add(rr(95,5),rr(46,7),fixes=[('“力量”“工作”和“能量”','“功率”“功”和“能量”')],reason='此处以物理学power/work/energy类比劳动力与劳动，不能泛译力量、工作。')
add(rr(95,6),rr(46,8,9),fixes=[('“力量”与“工作”','“功率”与“功”')],reason='承接下一节机械工程的功率/功区别。')
add(rr(95,7),rr(46,10))
add(rr(95,8),rr(46,11),'heading',text='功与功率',reason='Work and power在此是物理量，与劳动/劳动力形成类比。')
add(rr(95,9),rr(46,12,14))
add(rr(95,10),rr(46,15,18),fixes=[('继任者李嘉图','继承者李嘉图')])
nt={46:'这里使用的是源自20世纪物理学的术语。埃米·诺特在“变分问题的不变量”（Invariant Variation Problems），Transport Theory and Statistical Physics，第1卷第3期（1971），第186—207页（原作发表于1918年）中证明，经典物理学的守恒定律可以视为自然规律在时间和空间中具有对称性的结果。例如，动量守恒源于物理规律在空间中处处相同这一事实，即位移对称性。可以证明，时间的均匀性蕴含能量守恒。相关解释可参见Jozef Hanc、Slavomir Tuleja与Martina Hancova：“对称性与守恒定律：诺特定理的推论”（Symmetries and Conservation Laws: Consequences of Noether’s Theorem），American Journal of Physics，第72卷第4期（2004），第428—435页。她的工作最初适用于受拉格朗日最小作用量原理支配的系统，这些系统体现了经典力学的决定论唯物主义。此后，它已成为物理学其他领域的一种基础方法。我们在Allin F Cottrell等人的《经典经济物理学》（Classical Econophysics）（Routledge，2009），第11章和第5章，以及Paul Cockshott的“对称性与交换关系”（Symmetries and Exchange Relations），Política y cultura，第23期（2005），第279—304页中，探讨了商品交换所定义的度量空间中的对称性与马克思的价值守恒规律之间的关系。',47:'马克思：《资本论》，第152页。'}
notes=[]
for n,refs in [(46,[[254,2,24,26],[255,1,0,15]]),(47,[[255,1,15,16]])]:
    note={'id':f'dm-ch05-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['245','246'] if n==46 else ['246'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'}
    if n==46:note['editor_note']='底本连续两次出现Emmy，并将Chapter误印为Chaper；英文照录，中文按语义整理。'
    notes.append(note)
save('ch05h',5,rows,notes,rr(94,3,9)+rr(95,1,10))
(W/'checkpoint_ch05h.json').write_text(json.dumps({'next_source_pdf_page':96,'next_source_block':1,'next_supplied_pdf_page':46,'next_supplied_block':19,'next_unit':len(rows)+94,'next_note':48,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
