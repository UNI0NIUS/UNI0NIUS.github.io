from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch11-{len(rows)+161:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(237,12)+rr(238,1),rr(128,0,2),text=r'正电与负电涉及另一条基本守恒定律，即电荷守恒。带有＋6电荷的碳14原子核发生$\beta$衰变时，会形成一个带有＋7电荷的氮14原子核，同时产生一个$\beta$粒子，也就是一个带负电的电子。净电荷仍为＋6。电荷守恒意味着，在所有这类核转变中，总净电荷保持不变。')
add(rr(238,2),rr(128,3),text='化学反应中原子的结合与解离，也表达了一种守恒关系：在化学过程中，每种元素的原子总数保持不变。')
add(rr(238,3),rr(128,4,6),text='列宁的这三个例子都是守恒过程，并不能证明对立统一这一辩证法原理。它们的共同性质源于卢克莱修的格言：“无中不能生有。”尽管苏联辩证唯物主义批评力学，却正是力学世界观表达了列宁这些例子背后的守恒定律。')
add(rr(238,4),rr(128,7,9),text='最后一个例子是阶级冲突。但它也涉及守恒约束，因为在任何社会中，有限的劳动力和有限的工作时间，都意味着剩余劳动增加会使必要劳动减少。这在工人与雇主之间造成不可调和的阶级冲突：资本家阶级占有的劳动每增加一分，可用于满足工人阶级需要的劳动就相应减少一分。')
add(rr(238,5),rr(128,10,11),text='守恒定律恰恰来源于那备受鄙视的力学。源自力学的思维方式，运用守恒原理解释世界如何运作。在第5.3节，我们论证过，马克思揭示资本主义社会“运动规律”的志向，也属于这一思想脉络。')
add(rr(238,6),rr(128,12,14),text='毛泽东在《矛盾论》中引用恩格斯和列宁时，只是在向正统敷衍地表示认同。他的创新来自对矛盾特殊性的处理。在这里，他运用了一套全新的概念术语及其含义，把辩证法的语言转化为军事和政治战略的工具。',reason='恢复书名《矛盾论》，保留作者对引述动机的评价。')
add(rr(238,7),rr(128,15),text='毛泽东主张，不同科学的区别在于它们所研究的矛盾的特殊性。他对科学方法作了如下描述：',reason='与下接直接引文分开。')
add(rr(238,8),rr(128,15,17),'quote',text='这就是认识的两个过程：一个是从特殊到一般，另一个是从一般到特殊。因此，认识总是循环往复地进行，而且只要严格遵循科学方法，每一个循环都会把人类知识提高一步，使之日益深刻。[[35]]')
add(rr(238,9),rr(128,18,20),text='只要把术语从力换成矛盾，这一循环过程就与牛顿在《自然哲学的数学原理》导言中所说的完全一致：“哲学的一切困难似乎都在于此——从运动现象探究自然界的力，然后由这些力论证其他现象。”[[36]]毛泽东是在用矛盾的术语描述牛顿的科学方法。',reason='修复旧译把注36拆为注3、注6的问题。')
notes=[]
nt={35:'毛泽东，《矛盾论》，第321页。',36:'“Omnis enim Philosophiæ difficultas in eo versari videtur, ut a Phænomenis motuum investigemus vires Naturæ, deinde ab his viribus demonstremus phænomena reliqua”。〔译：哲学的一切困难似乎都在于此：从运动现象探究自然界的力，然后由这些力论证其他现象。〕'}
for n,refs in note_groups(rr(272,3)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch11-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['263'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch11n',11,rows,notes,rr(237,12)+rr(238,1,9))
(W/'checkpoint_ch11n.json').write_text(json.dumps({'next_source_pdf_page':239,'next_source_block':1,'next_supplied_pdf_page':128,'next_supplied_block':21,'next_unit':len(rows)+161,'next_note':37,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
