from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch03-{len(rows)+294:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(62,1),rr(28,0),'heading')
add(rr(62,2),rr(28,1),fixes=[('效能因','动力因')])
add(rr(62,3),rr(28,2,3),fixes=[('效能因','动力因')])
rows[-1]['editor_note']='原书将静电力与磁力的发现说成19世纪末；本章前文已谈古代琥珀和磁石现象，二者存在明显年代不一致，译文照录底本。'
add(rr(62,4),rr(28,4,5),english=extract(EN,rr(62,4),True).replace('Forces t0',r'Forces $t_0$'),fixes=[('效能因','动力因'),('力t_0',r'$t_0$ 时刻的力')],reason='统一efficient cause术语，并恢复时刻下标。')
add(rr(62,5),rr(28,6,8),fixes=[('有效因','动力因'),('力学公式','力学表述')])
add(rr(62,6),rr(28,9,12))
add(rr(62,7),rr(28,13,14))
add(rr(62,8),rr(28,15,17),fixes=[('可证明','可证明[[46]]')],reason='恢复原注46。')
add(rr(62,9)+rr(63,1),rr(28,18,20),fixes=[('精确数学定义至少不明显。','其精确数学定义至少可以说并非显而易见。[[47]]')],reason='恢复原注47。')
en=extract(EN,rr(63,2),True).replace('y ax b 2',r'$y=ax^2+b$').replace('x y ,',r'$x,y$')
add(rr(63,2),rr(28,21,23),english=en,fixes=[('y=ax^2+b',r'$y=ax^2+b$')])
add(rr(63,3),rr(28,24,25),fixes=[('配置空间','位形空间')])
en=extract(EN,rr(63,4),True).replace(' x y z , , ,',r'$\dot{x},\dot{y},\dot{z}$,').replace('x y z , ,',r'$x,y,z$')
add(rr(63,4),rr(28,26,28),english=en,fixes=[(r'\dot{x},\dot{y},\dot{z}',r'$\dot{x},\dot{y},\dot{z}$'),('配置空间','位形空间')],reason='恢复速度上点；configuration space统一为位形空间。')
rows[-1]['editor_note']='作者这里把位置与速度合在一起称为configuration space（位形空间）。通常位形空间只包含位置类广义坐标；位置与速度合成的状态空间与之有别。下文沿用作者术语，并保留这一辨析。'
add(rr(63,5),rr(29,0))
en=extract(EN,rr(63,6),True).replace('x y z x y zn 1 1 1 1 1 , , , , ....   ',r'$x_1,y_1,z_1,\dot{x}_1,\dot{y}_1,\ldots\dot{z}_n$').replace('x y ,',r'$x,y$')
add(rr(63,6),rr(29,1,5),english=en,fixes=[(r'x_1,y_1,z_1,\dot{x}_1,\dot{y}_1,\dots \dot{z}_n',r'$x_1,y_1,z_1,\dot{x}_1,\dot{y}_1,\dots\dot{z}_n$'),('建造欧几里得相似性更大的建筑','建造与图纸保持欧几里得相似关系的更大尺度建筑')],reason='原文指尺度放大且形状相似，不是相似性更大。')
add(rr(63,7),rr(29,6,8),fixes=[('欧几里得技术可得类似结果','欧几里得方法可以得到模拟式结果')],reason='analogue指模拟式而非类似，与下文代数和数字计算相对照。')
add(rr(64,1),rr(29,9,10),fixes=[('月球绕地球运动的物理纸模型','在地球上制作的、关于月球运动的实体纸面模型')],reason='on Earth在此描述纸面模型所处环境，不是删改轨道信息。')
add(rr(64,2),rr(29,11,14),fixes=[('新城地图。','新城地图。[[48]]'),('需要启蒙感性','这需要启蒙运动所培育的感受方式')],reason='恢复原注48，改善sensibility译法。')
add(rr(64,3),rr(29,15,17))
en=extract(EN,rr(64,4),True).replace('x y z x y x y zn 1 1 1 1 1 2 2 , , , , , … …',r'$x_1,y_1,z_1,\dot{x}_1,\dot{y}_1,\ldots x_2,y_2,\ldots\dot{z}_n$').replace('x1',r'$x_1$').replace('y2',r'$y_2$').replace('zn',r'$\dot{z}_n$')
add(rr(64,4),rr(29,18,22),english=en,text=r'南北维度与东西维度之所以不同，在于二者的独立性。沿一个轴运动，不会使我沿另一个轴向前。两个维度就是我沿街漫步时的自由度。拉格朗日方程中的变量 $x_1,y_1,z_1,\dot{x}_1,\dot{y}_1,\ldots x_2,y_2,\ldots\dot{z}_n$，也是多粒子系统的独立自由度。其中 $x_1$ 表示第一个粒子在x方向的位置，$y_2$ 表示第二个粒子在y方向的位置，而 $\dot{z}_n$ 表示第n个粒子在z方向的运动。所有这些量都可以独立变化，因此，在一种抽象的比喻意义上，它们就是维度。所以，位形空间中的一个点，就是所有粒子的位置和速度的一种特定组合；位形空间中的一条轨迹，必定是这些点的序列。')
add(rr(64,5),rr(29,23,25),fixes=[('配置空间','位形空间')])
add(rr(64,6),rr(29,26))
add(rr(64,7),rr(29,27,28),fixes=[('配置空间','位形空间'),('最小作用路径','最小作用量路径')])
add(rr(64,8)+rr(65,1),rr(29,29,30)+rr(30,0,1),fixes=[('500 千吨爆炸','当量为500千吨的爆炸'),('数千公寓','数千栋公寓楼')])
add(rr(65,2),rr(30,2,6),fixes=[('最小作用路径','最小作用量路径'),('該市','该市'),('在返回小行星带途中逃离最近太阳距离','在返回小行星带途中离开近日点')],reason='closest solar approach指近日点，原译距离表述不通。')
rows[-1]['editor_note']='底本将“西方低空”与“日出方向”并列，方向表述存在矛盾；译文保留两者，不擅自替作者改写。'
add(rr(65,3),rr(30,7,8),fixes=[('无预警坠落。','无预警坠落。[[49]]')],reason='恢复原注49。')
add(rr(65,4),rr(30,9))
add(rr(65,5),rr(30,10,13))
rows[-1]['editor_note']='本段风险概率、时间范围、当量和任务名称／年份均为原书陈述，按底本保留，未作为当前NASA风险评估或任务记录重新核验。'
add(rr(65,6),rr(30,14,15))
add(rr(65,7),rr(30,16,17))
add(rr(65,8),rr(30,18,19))
add(rr(66,1),rr(30,20,22))
add(rr(66,2),rr(30,23,24))
rows[-1]['editor_note']='原书把functionals解释为“变换其他函数的函数”，这里按原文翻译。严格数学用法中，泛函通常是把函数映射到标量的映射；把函数映射到函数通常称算子。'
add(rr(66,3),rr(30,25))
add(rr(66,4),rr(30,26),text='此时，可以把算法运算从欧拉的代数式重写，切换到我们在学校学到的、作为笔算乘法和加法的原初算法（algorithismes）。[[50]]运用这些熟悉的方法，人们以十进制算术进行详细计算。',reason='long multiplication误作长除法；恢复原注50及原语。')
add(rr(66,5),rr(30,27))
add(rr(66,6),rr(30,28)+rr(31,0))
add(rr(66,7),rr(31,1),fixes=[('旧式人类计算机','过去从事计算工作的人')])
add(rr(66,8),rr(31,2,4))
add(rr(66,9),rr(31,5,6),fixes=[('验证模拟系统本体论现实','验证了被模拟系统在本体论上的实在性')],reason='simulated systems指被模拟的对象，并非模拟程序本身。')
add(rr(66,10),rr(31,7,8),fixes=[('随时间演化的局部物理过程','在计算进行时随时间演化的、发生于具体地点的物理过程')])
nt={46:'证明参见John R. Taylor等：《经典力学》（Classical Mechanics）（University Science Books，2005），第217页。',47:r'作用量定义为 $S=\int\mathcal{L}\,dt$，其中 $\mathcal{L}$ 为拉格朗日量，表示动能与势能之差。详细论述参见Taylor等：《经典力学》，第6、7、13章。',48:'例如参见2015年6月6日“La ciudad como reivindicación identitaria: el caso de la New Town de Edimburgo”（作为身份认同诉求的城市：爱丁堡新城案例），https://urban-networks.blogspot.com/2015/06/la-ciudad-como-reivindicacion.html。',49:'Kord Ernstson等：“基姆高陨石坑散布区：德国巴伐利亚东南部全新世大型撞击事件的证据”（The Chiemgau Crater Strewn Field: Evidence of a Holocene Large Impact Event in Southeast Bavaria, Germany），Journal of Siberian Federal University. Engineering & Technologies，第1卷第3期（2010），第72—103页；Barbara Rappenglück等：“法埃顿之坠落：一个希腊—罗马地质神话保存了巴伐利亚（德国东南部）陨石撞击的记忆”（The Fall of Phaethon: A Greco-Roman Geomyth Preserves the Memory of a Meteorite Impact in Bavaria (South-East Germany)），Antiquity，第84卷第324期（2010），第428—439页。',50:'这些算法以花剌子密（al-Khwārizmī）命名，他的算术方法通过斐波那契的《算盘书》（Liber Abaci）传入欧洲。'}
notes=[]
for n,refs in note_groups([[248,2],[249,1]]):
    if n not in nt:continue
    en=extract(EN,refs,True).replace('\u200b','').replace('ciudad -como','ciudad-como')
    if n==47:en=r'47 Action is defined as $S=\int\mathcal{L}\,dt$ where $\mathcal{L}$. the Lagrangian, stands for the difference between kinetic and potential energy. For a detailed treatment, see see Taylor et al., Classical Mechanics, chap. 6, 7, 13.'
    notes.append({'id':f'dm-ch03-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':list(dict.fromkeys(str(x[0]-9) for x in refs)),'en':en,'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
expected=[[p,b['block']] for p in range(62,68) for b in EN[p-1]['blocks'] if b.get('lines') and b['block']>0]
save('ch03g',3,rows,notes,expected)
(W/'checkpoint_ch03g.json').write_text(json.dumps({'next_source_pdf_page':68,'next_source_block':0,'next_supplied_pdf_page':31,'next_supplied_block':9,'next_chapter':4,'next_note':1,'chapter_3_text_compared':True,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
