from materialism_common import *

groups=[]
for b in EN[288]['blocks'][1:]:
    for j,l in enumerate(b['lines']):
        x=l['bbox'][0]
        if x<80 or 225<x<250:groups.append([])
        groups[-1].append([289,b['block'],j,j+1])
oldrefs=rr(177,16,31)+rr(177,33,43)+rr(178,0,11)+rr(178,13,26)+rr(178,28,43)+rr(179,0,15)
assert len(groups)==len(oldrefs)==85
fixes={
 'Historical Materialism (Bukharin)':('《历史唯物主义》','《历史唯物主义》（布哈林）'),
 'Hui, Yuk':('余辉','许煜'),
 'ideality':('理想性','观念性'),
 'inclusive disjunction':('包含析取','相容析取'),
 'Introduction to logic and the methodology of deductive sciences (Tarski)':('《逻辑导论与演绎科学的方法论》','《逻辑与演绎科学方法论导论》（塔尔斯基）'),
 'Introduction to Non-Marxism (Laruelle)':('《非马克思主义导论》','《非马克思主义导论》（拉鲁埃尔）'),
 'kenosis':('虚化','自我虚空化'),
 'kets':('态矢量','右矢（ket）'),
 'Kolmogorov, Andrei':('Kolmogorov, Andrey','Kolmogorov, Andrei'),
 'Laws of Thought':('《思维规律》','思维规律'),
}
rows=[]
for i,(refs,zref) in enumerate(zip(groups,oldrefs),235):
    en=extract(EN,refs,True);old=extract(ZH,[zref]);zh=old
    m=re.search(r'\s+(\d[\d, ––-]*)$',en);assert m,en
    term=en[:m.start()].strip();locator=m[1]
    oldloc=re.search(r'(\d[\d, ––-]*)$',old);assert oldloc,old
    assert re.sub(r'\s','',oldloc[1])==re.sub(r'\s','',locator),(en,old)
    if term in fixes:
        a,b=fixes[term];assert a in zh,(term,zh);zh=zh.replace(a,b)
    row={'id':f'dm-index-{i:03}','kind':'index_entry','source_blocks':refs,'supplied_translation_blocks':[zref],'printed_pages':['280'],'en':en,'zh':zh,'supplied_zh':old,'index_term':term,'index_locators':locator,'index_level':0,'status':'text_compared_layout_pending'}
    if zh!=old:row['revision_reason']='修正人名或术语，补回书目作者括注，逐项核对原索引页码。'
    if term=='IN abstract dynamics':row['editor_note']='原索引条目开头的IN按原样保留。'
    rows.append(row)
save('index04',13,rows,[],rr(289,1,15))
(W/'checkpoint_index04.json').write_text(json.dumps({'next_source_pdf_page':290,'next_supplied_pdf_page':179,'next_supplied_block':16,'next_index_entry':320,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
