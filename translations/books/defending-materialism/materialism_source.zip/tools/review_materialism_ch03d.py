from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch03-{len(rows)+174:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(48,1),rr(21,0,1),'quote',start='在给定空间内')
add(rr(48,2),rr(21,2),'quote')
add(rr(48,3),rr(21,3,5))
add(rr(48,4),rr(21,6,7),end='根据前两条')
add(rr(48,5),rr(21,7,10),'quote',start='根据前两条',fixes=[('因此产生相等速度','因此产生相等的速度增量')],reason='此处equal velocities指相等时间内产生的速度增量。')
add(rr(48,6),rr(21,11,12),english=extract(EN,rr(48,6),True).replace('v at =',r'$v=at$').replace('d t ≈ 2',r'$d\approx t^2$'),text=r'这里的关系是 $v=at$ 和 $d\approx t^2$。随后，他叙述了自己用充作摆锤的钢球相互碰撞所进行的实际实验，以验证这些关系，并仔细计入空气阻力的影响。',reason='数学式按底本恢复；底本用约等号而非比例号，另作说明。')
rows[-1]['editor_note']='底本此处印作d≈t²，但前文文字说距离与时间平方成正比；比例关系通常写为d∝t²。'
add(rr(48,7),rr(21,13),'heading')
add(rr(48,8),rr(21,14,15))
add(rr(49,1),rr(21,16),'quote')
add(rr(49,2),rr(21,17,18),'quote',fixes=[('3/2 次方成正比','3/2 次方成正比[[23]]'),('平方根成反比','平方根成反比[[24]]')],reason='恢复原注23、24。')
add(rr(49,3),rr(21,19,20),'quote',text=r'一般说来，如果周期与半径 $R$ 的任意幂 $R^n$ 成正比，因而速度与半径的幂 $R^{n-1}$ 成反比，那么向心力就与半径的幂 $R^{2n-1}$ 成反比；反之亦然。[[25]]',english=r'And universally, if the periodic time is as any power $R^n$ of the radius $R$, and therefore the velocity reciprocally as the power $R^{n-1}$ of the radius, the centripetal force will be reciprocally as the power $R^{2n-1}$ of the radius; and the contrary.[[25]]',reason='恢复指数和原注25，避免将指数中的1当作注号。')
add(rr(49,4),rr(21,21,22))
add(rr(49,5,11),rr(21,23,28),'quote',fixes=[('以太阳为半径','以连接太阳与行星的线段为向径'),('以地球中心为半径','以连接地球中心与月球的线段为向径')],reason='太阳与地心不是半径，radi i drawn to指连接相应中心的向径。')
add(rr(49,12),rr(21,29,30),end='迄今把天体',fixes=[('受平方反比力作用作直线运动','受平方反比力作用而偏离直线运动')],reason='底本drawn of rectilinear motion疑为drawn off；结合轨道语境译为偏离直线，旧译意思相反。')
rows[-1]['editor_note']='底本作drawn of rectilinear motion，疑漏一个f；中文依本段轨道论证译为“偏离直线运动”，英文保留底本。'
add(rr(49,13),rr(21,30,31),'quote',start='迄今把天体')
add(rr(49,14)+rr(50,1),rr(21,32,34),fixes=[('无论被吸引物体是哪个','无论物体被吸向哪一个天体')],reason='towards which指吸引的目标，非被吸引物体。')
add(rr(50,2),rr(21,35))
for enb,zhb in [(3,0),(4,1),(5,2),(6,3)]:add(rr(50,enb),rr(22,zhb),'list_item')
add(rr(50,7),rr(22,4,5))
add(rr(50,8),rr(22,6),'heading')
add(rr(50,9),rr(22,7,8),fixes=[('流体动力','流体动力学中的力')])
add(rr(50,10),rr(22,9,12))
add(rr(50,11),rr(22,13))
add(rr(50,12),rr(22,14),'heading')
add(rr(50,13),rr(22,15,17),end='事实上，')
en=r'Indeed, the law which he gave (ie that the areas measured by the vector radii of the bodies in circular motion are proportional to the times) he would have been able to transmute into the form (species) of a physical law (ie that gravity is in proportion (in ratione) to the area belonging to equal sectors); and since the total surfaces of the circles $A$ and $a$ stand in the same ratio as the squares of their radii $R$ and $r$, we know that $1/A:1/a$ is equivalent to $r^2/R^2$. Since $1/A$ and $1/a$ express the quantity of motion, and, if you wish, the quantity of the centripetal force, he could have said that the force of gravitation or centripetal force stands in inverse ratio to the radii, or distances.[[26]]'
add(rr(51,1),rr(22,17,20),'quote',text=r'事实上，他所给出的定律（即作圆周运动的物体的向径所量出的面积与时间成正比），本可以被他转化为物理定律的形式（species）（即引力与相等扇形所属的面积成比例〔in ratione〕）；由于圆 $A$ 和 $a$ 的总面积之比，等于其半径 $R$ 和 $r$ 的平方之比，我们知道 $1/A:1/a$ 等同于 $r^2/R^2$。既然 $1/A$ 和 $1/a$ 表示运动量，若愿意也可表示向心力的量，他就可以说，引力或向心力与半径或距离成反比。[[26]]',english=en,reason='恢复原文括注species与in ratione，以及完整数学符号。')
add(rr(51,2),rr(22,21,23),fixes=[('开普勒定律并未说行星在相等时间扫过相等面积','开普勒定律并未说不同行星在相等时间扫过相等面积')],reason='补清不同星体之间的比较范围，避免否定等面积定律本身。')
add(rr(51,3,4),rr(22,24,27),'table','行星 | 半径（天文单位，半长轴） | 周期 | 每日面积（平方天文单位）\n金星 | 0.723 | 225 | 0.0202\n地球 | 1 | 365 | 0.0172\n火星 | 1.524 | 687 | 0.0139',reason='恢复独立表结构，保留原书数据，不静默改算。')
rows[-1]['table']={'headers_en':['Planet','Radius in AU (semi major axis)','Period','Area per day square AU'],'headers_zh':['行星','半径（天文单位，半长轴）','周期','每日面积（平方天文单位）'],'rows_en':[['Venus','0.723','225','0.0202'],['Earth','1','365','0.0172'],['Mars','1.524','687','0.0139']],'rows_zh':[['金星','0.723','225','0.0202'],['地球','1','365','0.0172'],['火星','1.524','687','0.0139']]}
rows[-1]['editor_note']='表格及“越远每日面积越小”的叙述均按底本保留。但以表内半径与周期作圆轨道近似，日扫面积πr²/T约为0.00730、0.00861、0.01062平方天文单位，与原表不符，且随半径增大而增大。原表数值更接近每日路程2πr/T；这不等同于扫过面积。'
add(rr(51,5),rr(22,28))
add(rr(51,6),rr(22,29,30),text=r'牛顿计算了形式为 $f=mMG/r^n$、其中 $n=1,2,3$ 的引力定律下开普勒轨道的性质，发现三种情形均能相容，但所预测的速度不同。',english=r'Newton worked out the properties of Keplerian orbits with gravitational laws of the form $f=mMG/r^n$ for $n=1,2,3$ and finds that all three are consistent, but that the predicted velocities differ.',reason='consistent在这里并非与观测一致；下一段才用观测区分。')
add(rr(51,7),rr(22,31,32))
add(rr(51,8),rr(23,0,1),fixes=[('速度v',r'速度 $v$'),('必须2v',r'必须为 $2v$')])
add(rr(51,9,14),rr(23,2,8),text=r'设卫星质量为 $m$，则在A点的动能为 $0.5mv^2$，在P点为 $2mv^2$。假设牛顿引力成立，地球质量为 $M$，P与A之间的势能差为 $\int_1^2 mMG/r^2\,dr=mMG/2$。换言之，这是引力对径向距离变化的积分；力对距离的积分具有能量的量纲。因此，能量守恒要求 $1.5mv^2=mMG/2$，于是 $v=\sqrt{MG/3}$。',english=r'Let the satellite have mass $m$; then kinetic energy at point A is $0.5mv^2$, and at point P, it is $2mv^2$. The difference in potential energy between P and A, assuming Newtonian gravity and mass of Earth $M$, will be $\int_1^2 mMG/r^2\,dr=mMG/2$. In other words this is the integral over the change in radial distance with respect to gravitational force, and an integral of force with distance is of dimension energy. The conservation of energy then requires us to have $1.5mv^2=mMG/2$, so $v=\sqrt{MG/3}$.',reason='恢复OCR损坏的积分、根式，补回旧译漏掉的积分含义及量纲说明。')
add(rr(52,1),rr(23,9))
add(rr(52,2,9),rr(23,10,13),text=r'在这一情况下，将A点的新速度记为 $v_1$，于是P点的速度为 $2v_1$。此时动能之差为 $1.5mv_1^2$，它必须等于另一种力定律下的引力势能差（加速度 $\propto 1/r$），因此 $\int_1^2 mMG/r\,dr=mMG\log(2)$，我们仍可解出速度：$v_1=\sqrt{MG\log(2)/1.5}$。',english=r'Call the new velocity at A in this case $v_1$, and the velocity at P is now $2v_1$. The kinetic energies now differ by $1.5mv_1^2$, which now has to equal the difference in gravitational potential under a different force law (acceleration $\propto 1/r$) so that $\int_1^2 mMG/r\,dr=mMG\log(2)$ we can again solve for velocity such that $v_1=\sqrt{MG\log(2)/1.5}$.',reason='恢复全部积分、下标和根式，不将幂指数当注号。')
add(rr(52,10),rr(23,14),text=r'由于 $\log(2)\ne\frac12$，在新的引力定律下，速度将会不同。',english=r'Since $\log(2)\ne\frac12$, it follows that velocities will differ with the new gravity law.')
add(rr(52,11),rr(23,15))
title='牛顿：《自然哲学的数学原理……安德鲁·莫特译……附牛顿〈世界体系〉；W. 埃默森对〈原理〉的简短评注与辩护；以及约翰·梅钦依据引力所论月球运动定律……（先生的序言）》'
nt={20:title+'，推论V。',21:'相对于不具有某种运动的事物而言，以及在一切同等分享该运动的事物之间，该运动不起作用，就仿佛不存在一样。因此，一艘满载货物的船驶离威尼斯，途经科孚、克里特、塞浦路斯，前往阿勒颇。威尼斯、科孚、克里特等地静止不动，不随船运动；但对于船上装载的袋子、箱子和包裹，以及船本身而言，从威尼斯到叙利亚的运动等于没有运动，丝毫不会改变它们彼此之间的关系。原因就在于，这一运动为它们所共有，它们全都同等地分享这一运动。伽利略·伽利莱：《关于两大世界体系的对话》（1632）（Robert C. Kuhmann，2006），第41页，http://www.kuhmann.com/starstuff/DialogueConcerningtheTwoChiefWorldSystems.pdf。对于一个简单的可动物体，只能有一种、而不能有更多的运动天然适合它；其他运动，它只能偶然地、通过参与而具有。因此，当一个人沿船甲板行走时，他自身的运动是步行，而把他带到港口的运动则是他所参与的运动；因为若不是船通过自身运动将他带到那里，他单靠步行永远无法抵达。伽利莱：《关于两大世界体系的对话》，第45页。',22:title+'，第183页。',23:r'sesquiduplicate ratio 意为 $r^{2.5}$。',24:r'这意味着平方根之比：$r_1:r_2$ 的 subduplicate ratio 为 $\sqrt{r_1}:\sqrt{r_2}$；所以，若原比为18:16，subduplicate ratio 就是9:4。',25:title+'，命题IV，定理IV。',26:'格奥尔格·威廉·弗里德里希·黑格尔：“关于行星轨道的哲学论文（1801），附1801年8月27日答辩的十二条论题”（Philosophical Dissertation on the Orbits of the Planets (1801), Preceded by the 12 Theses Defended on August 27, 1801），Graduate Faculty Philosophy Journal，第12卷第1/2期（1987），第282—283页。'}
notes=[]
for n,refs in note_groups([[247,1],[247,2],[248,1],[248,2]]):
    if n not in nt:continue
    en=extract(EN,refs,True).replace('\u200b','').replace('starstuf f','starstuff').replace('Concerning the','Concerningthe')
    en=en.replace('Dialogue Concerningthe Two Chief','Dialogue Concerning the Two Chief')
    if n==23:en=r'23 Sesquiduplicate ratio means $r^{2.5}$.'
    if n==24:en=r'24 Th. is means in the ratio of the square roots, the subduplicate ratio of $r_1:r_2=\sqrt{r_1}:\sqrt{r_2}$ so if the ratio were 18:16, the. subduplicate ratio would be 9:4.'
    note={'id':f'dm-ch03-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':list(dict.fromkeys(str(x[0]-9) for x in refs)),'en':en,'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'}
    if n==23:note['editor_note']='底本确实印为r的2.5次方；但正文所述周期—半径关系对应3/2次方，即1.5次方。此处保留原注并指出不一致。'
    if n==24:note['editor_note']='底本18:16开平方后的比写成9:4，计算有误；正确为√18:√16，即3√2:4。公式中的等号和正文两处异常句点均为底本所有。'
    if n in (20,22,25):note['editor_note']='底本书目题名末尾“(The Preface of Mr)”自身不完整，按原样保留。'
    notes.append(note)
expected=[[p,b['block']] for p in range(48,52) for b in EN[p-1]['blocks'] if b.get('lines') and b['block']>0]+rr(52,1,11)
save('ch03d',3,rows,notes,expected)
(W/'checkpoint_ch03d.json').write_text(json.dumps({'next_source_pdf_page':52,'next_source_block':12,'next_supplied_pdf_page':23,'next_supplied_block':16,'next_unit':len(rows)+174,'next_note':27,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
