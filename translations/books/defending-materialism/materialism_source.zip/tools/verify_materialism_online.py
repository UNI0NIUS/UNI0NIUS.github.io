from materialism_common import *
import urllib.request,hashlib,time
S=R/'github-sync';base='https://uni0nius.github.io/'
opener=urllib.request.build_opener(urllib.request.ProxyHandler({'https':'http://127.0.0.1:7897'}))
def get(url):
    with opener.open(base+url+'?verify='+str(int(time.time())),timeout=60) as response:return response.read()
book=json.loads((S/'translations/books/defending-materialism/book-metadata.json').read_text('utf8'))
catalog=get('translations-data.js').decode('utf8');prefix='window.TRANSLATIONS = '
data=json.loads(catalog[len(prefix):].strip().rstrip(';'))
live=next(b for b in data['books'] if b['id']==book['id']);assert live==book
checks=[]
for c in book['chapters']:
    content=get(c['dataUrl']);expected=(S/c['dataUrl']).read_bytes();assert json.loads(content)==json.loads(expected),c['id'];checks.append(c['dataUrl'])
for entry in book['downloads']:
    content=get(entry['url']);assert hashlib.sha256(content).hexdigest()==entry['sha256'],entry['url'];assert len(content)==entry['bytes'];checks.append(entry['url'])
for name in ['bilingual-reader.js','translations.js','translations.css','vendor/katex/katex.min.js','vendor/katex/katex.min.css']:
    assert get(name).replace(b'\r\n',b'\n')==(S/name).read_bytes().replace(b'\r\n',b'\n'),name;checks.append(name)
report={'status':'pass','url':base+'translations/book.html?id='+book['id'],'sections':len(book['chapters']),'downloads':len(book['downloads']),'checked':checks,'checked_at_epoch':time.time(),'content_and_hashes':'match'}
(W/'online_files_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8');print(json.dumps(report,ensure_ascii=False))
