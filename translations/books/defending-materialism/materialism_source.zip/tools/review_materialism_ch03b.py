from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch03-{len(rows)+59:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='公式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(35,6),rr(14,30),'heading')
add(rr(35,7),rr(14,31,32))
add(rr(35,8),rr(15,0,4),fixes=[('鲁索推测','鲁索[[9]]推测')],reason='恢复原注9。')
add(rr(35,9),rr(15,5),'heading')
add(rr(35,10),rr(15,6),end='我们提供')
add(rr(35,11),rr(15,6,7),'quote',start='我们提供')
add(rr(36,1),rr(15,8,9))
add(rr(36,2),rr(15,10,11))
add(rr(36,3),rr(15,12),'heading','规则 I')
add(rr(36,4),rr(15,12),'quote',start='对于自然事物')
rows[-1]['editor_note']='本书英文底本此处作 time，语义不通；中文按上下文采用“真实”，英文仍照录 time，未将校正混入底本文字。'
add(rr(36,5),rr(15,13,14),'quote')
add(rr(36,6),rr(15,15,16),fixes=[('Keep It Simple, Stupid','Keep It Simple, Stupid（笨蛋，保持简单）')])
add(rr(36,7),rr(15,17,18),end='因此，让我们')
add(rr(36,8),rr(15,18,20),'quote',start='因此，让我们',fixes=[('占星术','地占术（geomancy）'),('几何直线','几何曲线'),('这条直线','这条曲线')],reason='geomancy不是占星术；此处geometric line不限于直线，否则无法穿过任意点列。')
add(rr(36,9),rr(15,21,23),'quote',fixes=[('性质和效果极其显著且广泛分布的直线','性质与效果极其显著且影响广泛的曲线')],reason='延续上段曲线含义；widespread不指曲线在空间广泛分布。')
add(rr(36,10),rr(15,24),text='莱布尼茨打算用何种具体方法，构造一条穿过所有随机点的光滑曲线，并未说明。在18世纪，或许会用如下多项式来拟合这些点：',reason='补回所有随机点与拟合对象，原句跨公式续接。')
add(rr(36,11),rr(15,25),'equation',r'$a+bx+cx^2+dx^3+ex^4+\cdots$',english=r'$a+bx+cx^2+dx^3+ex^4+\cdots$')
add(rr(37,1),rr(15,26),reason='首句to the points在前一单元中文中承接；原文保留。')
add(rr(37,2),rr(15,27),fixes=[('最简单例子','最明显的例子')],reason='most obvious不是最简单。')
add(rr(37,3),rr(15,28,30))
add(rr(37,4),rr(15,31)+rr(16,0,1),fixes=[('一个周期上还有一个本轮旋转','一个均轮上还有一个本轮旋转'),('与牛顿相比多出两倍冗余','所需参数数量是牛顿模型的两倍，形成冗余')],reason='cycle在此是均轮，不是时间周期；避免把twofold误成总量三倍。')
add(rr(37,5)+rr(38,1),rr(16,2,6),fixes=[('傅里叶分析相同。','傅里叶分析相同。[[12]]')],reason='连接跨页完整段落并恢复原注12。')
add(rr(37,7),[],'figure','图3.2 具有本轮运动路径的物体，其轨道在x轴上的投影是余弦曲线之和。本轮直径为0.2，转速是大圆的两倍。右图绘出余弦曲线及其和。作者绘图。',reason='恢复旧中文稿遗漏的原图及完整图注。')
rows[-1].update(image='assets/figure-3-2.png',source_image={'pdf_page':37,'block':6},image_labels_zh='cos θ：余弦 θ；0.2 cos 2θ：0.2倍的余弦 2θ；sum：两者之和。坐标数字及θ沿用原图。')
add(rr(38,2),rr(16,7,8))
add(rr(38,3),rr(16,9))
formula=r'$p=136\cos(2+\theta)+27.7\cos(2+2\theta)+39.5\cos(2+3\theta)+19.6\cos(2+4\theta)+62\cos(2+5\theta)+52\cos(2+6\theta)+50.1\cos(2+7\theta)+37\cos(2+8\theta)+70.5\cos(2+9\theta)+19\cos(2+10\theta)$'
add(rr(38,4,7),rr(16,10,13),'equation',formula,english=formula,reason='源PDF多行公式OCR损坏，按原图逐项恢复系数、加号与角变量。')
rows[-1]['math_lines']=[r'p={}&136\cos(2+\theta)+27.7\cos(2+2\theta)+39.5\cos(2+3\theta)',r'&+19.6\cos(2+4\theta)+62\cos(2+5\theta)',r'&+52\cos(2+6\theta)+50.1\cos(2+7\theta)',r'&+37\cos(2+8\theta)+70.5\cos(2+9\theta)+19\cos(2+10\theta)']
add(rr(38,8)+rr(39,1),rr(16,14,15),text=r'其中 $\theta=\pi(q-80)/10$，$p$ 是油价，$q$ 是销量。这正是莱布尼茨所说的情形：“我认为，完全可能找到一条几何曲线，其运动恒定且均匀，遵循某种规则，使这条曲线按照手写下这些点的顺序依次穿过所有点。”',english=r'with $\theta=\pi(q-80)/10$, where $p$ is the price of oil and $q$ the quantity sold, does what Leibniz described when he said: ‘I maintain that it is possible to find a geometric line whose motion is constant and uniform, following a certain rule, such that this line passes through all the points in the same order in which the hand jotted them down’.',reason='恢复公式并纠正geometric line误作直线。')
add(rr(38,10),[],'figure','图3.3 一条连续曲线，穿过代表2007年至2016年间所采集的世界石油价格／出货量数据的各点。此曲线用托勒密天文学所用的本轮方法生成。作者绘图。',reason='恢复旧中文稿遗漏的原图及完整图注。')
rows[-1].update(image='assets/figure-3-3.png',source_image={'pdf_page':38,'block':9},image_labels_zh='$ per barrel：美元／桶；Quantity million barrels a day：每日数量（百万桶）；World oil price：世界石油价格；cosine series：余弦级数。')
add(rr(39,2),rr(16,16,17))
add(rr(39,3),rr(16,18),'heading','规则 II')
add(rr(39,4),rr(16,18),'quote',start='因此，')
add(rr(39,5),rr(16,19),'quote')
add(rr(39,6),rr(16,20,21),fixes=[('但原则仍被接受','但这些例子与这一原则仍被接受')],reason='补回both the examples and the principle。')
add(rr(39,7),rr(16,22,24),fixes=[('因此被放逐出雅典','因这一不敬神的说法被放逐出雅典')],reason='恢复impiety所表达的指控性质。')
add(rr(39,8),rr(16,25),'heading','规则 III')
add(rr(39,9),rr(16,25,26),'quote',start='那些')
add(rr(39,10),rr(16,27)+rr(17,0))
add(rr(39,11),rr(17,1),'heading','规则 IV')
add(rr(39,12)+rr(40,1),rr(17,1,2),'quote',start='在实验哲学中')
add(rr(40,2),rr(17,3),'quote')
add(rr(40,3),rr(17,4,5))
add(rr(40,4),rr(17,6,7))
add(rr(40,5),rr(17,8))
add(rr(40,6),rr(17,9),'heading')
add(rr(40,7),rr(17,10,12))
add(rr(40,8),rr(17,13),end='描绘直线')
add(rr(40,9),rr(17,13,14),'quote',start='描绘直线',fixes=[('描绘直线','描绘直[[13]]线')],reason='恢复原注13，注释解释right在此作straight。')
add(rr(40,10),rr(17,15,17),end='因此几何学建立')
add(rr(40,11),rr(17,16,19),'quote',start='因此几何学建立')
add(rr(41,1),rr(17,20),text='这门科学研究的是物质物体的运动。他将借助几何学，分析运动及引起运动的力。接下来，他定义了自己以几何方式处理物质与运动时将要使用的术语。',reason='补全末句限定语，明确force与motion关系。')
add(rr(41,2),rr(17,21),'heading')
add(rr(41,3),rr(17,22),'heading','定义 I')
add(rr(41,4),rr(17,22),'quote',start='物质的量')
add(rr(41,5),rr(17,23,26),'quote')
add(rr(41,6),rr(17,27),fixes=[('深远','具有重要意义')])
add(rr(41,7,9),rr(17,28,30),'quote',fixes=[('假设的光以太','假设的光以太（luminiferous ether）')])
add(rr(41,10),rr(17,31),'heading','定义 II')
add(rr(41,11),rr(17,31),'quote',start='运动量')
add(rr(41,12),rr(17,32),'quote',fixes=[('速度加倍时，运动量四倍','在这一质量加倍的物体中，速度也加倍时，运动量为四倍')],reason='澄清twice velocity仍以加倍质量为前提，避免读作单独速度加倍使动量四倍。')
en=extract(EN,rr(41,13),True).replace('p mv = .',r'$p=mv$.')
add(rr(41,13),rr(18,0,1),english=en,fixes=[('p = mv',r'$p=mv$')])
nt={9:'鲁索：《被遗忘的革命：科学如何诞生于公元前300年，又为何必须重新诞生》。',10:'艾萨克·牛顿：《自然哲学的数学原理……安德鲁·莫特译……附牛顿〈世界体系〉；W. 埃默森对〈原理〉的简短评注与辩护；以及约翰·梅钦依据引力所论月球运动定律……（先生的序言）》（1848）。',11:'G. W. 莱布尼茨：《形而上学论》，1686年，http://www.earlymoderntexts.com/assets/pdfs/leibniz1686d.pdf。',12:'鲁索在《被遗忘的革命：科学如何诞生于公元前300年，又为何必须重新诞生》中，解释了托勒密天文学与傅里叶分解之间的相似性。',13:'我们现在会用 straight（直的）这个词。'}
notes=[]
for n,refs in note_groups([[246,3],[247,1],[247,2]]):
    if n not in nt:continue
    en=re.sub(r'^\d+\s+','',extract(EN,refs,True)).replace('\u200b','').replace('com/ assets','com/assets')
    notes.append({'note_number':n,'source_blocks':refs,'en':en,'zh':nt[n],'status':'text_compared_layout_pending'})
    if n==10:notes[-1]['editor_note']='底本书目题名末尾“(The Preface of Mr)”自身不完整；按原样保留，不擅自补人名。'
for n in notes:
    num=n['note_number'];n.update(id=f'dm-ch03-note-{num}',kind='note',printed_pages=list(dict.fromkeys(str(ref[0]-9) for ref in n['source_blocks'])))
    n['en']=str(num)+' '+n['en'];n['zh']=str(num)+'. '+n['zh']
expected=rr(35,6,11)+[[p,b['block']] for p in range(36,42) for b in EN[p-1]['blocks'] if b.get('lines') and b['block']>0]
save('ch03b',3,rows,notes,expected)
(W/'checkpoint_ch03b.json').write_text(json.dumps({'next_source_pdf_page':42,'next_source_block':1,'next_supplied_pdf_page':18,'next_supplied_block':2,'next_unit':len(rows)+59,'next_note':14,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
