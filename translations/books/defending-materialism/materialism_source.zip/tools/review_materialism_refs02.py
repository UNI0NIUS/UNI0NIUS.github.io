from materialism_common import *
groups=[]
for b in EN[273]['blocks'][1:]:
    for j,l in enumerate(b['lines']):
        if l['bbox'][0]<62:groups.append([])
        groups[-1].append([274,b['block'],j,j+1])
assert len(groups)==22
oldrefs=[rr(154,27),rr(155,0),rr(155,3,5),rr(155,1,2),rr(155,6,7),rr(155,8,10),rr(155,11,12),rr(155,13,14),rr(155,15),rr(155,16,17),rr(155,18,19),rr(155,20),rr(155,21),rr(155,22),rr(155,23,24),rr(155,25),rr(155,26)+rr(156,0),rr(156,1,3),rr(156,4,6),rr(156,7),rr(156,8,9),rr(156,10,12)]
translations=[
'大卫·玻姆：《现代物理学中的因果性与偶然性》。Routledge，2004。',
'大卫·玻姆：《整体性与隐含序》。Routledge，2002。',
'Niels Bohr、Hendrik Anton Kramers、John Clarke Slater：“LXXVI. 辐射的量子理论”。The London, Edinburgh, and Dublin Philosophical Magazine and Journal of Science 47，第281期（1924）：785—802。',
'尼尔斯·玻尔：“I. 论原子和分子的构造”。The London, Edinburgh, and Dublin Philosophical Magazine and Journal of Science 26，第151期（1913）：1—25。',
'尼尔斯·玻尔等：《量子公设与原子理论的近期发展》。第3卷。由R. & R. Clarke, Limited在英国印刷，1928。',
'路德维希·玻尔兹曼：“答策梅洛对热理论的评论”。载《气体动理论：附历史评论的经典论文选》，Stephen G. Brush编，412—419。World Scientific，2003。',
'路德维希·玻尔兹曼：“Sitzungsberichte Akad. Wiss., Vienna, II, 66：275—370；英译：Brush, SG（1966），《动理论》第2卷：不可逆过程”。Permagon Press，1872。',
'路德维希·玻尔兹曼：《理论物理学与哲学问题：文选》。第5卷。Springer Science & Business Media，2012。',
'乔治·布尔：《思维规律研究》。Walton & Maberly，1854。',
'James Boswell：《塞缪尔·约翰逊传》。第I卷。Everyman’s Libray。J. M. Dent & Sons Ltd，1906。\n\nRosi Braidotti、Maria Hlavajova：《后人类术语集》。Bloomsbury Publishing，2018。',
'Jean Bricmont：“量子力学史，还是错误的喜剧？”arXiv预印本arXiv:1703.00294，2017。',
'Jean Bricmont：《理解量子力学》。第37卷。Springer，2016。',
'Jean Bricmont：《理解统计力学》。Springer，2022。',
'Jean Bricmont：“混沌科学，还是科学中的混乱？”arXiv预印本chao-dyn/9603009，1996。',
'Léon Brillouin：“信息的负熵原理”。Journal of Applied Physics 24，第9期（1953）：1152—1163。',
'Jacob Bronowski：《人类的攀升》。Random House，2011。',
'Luitzen Brouwer：“数学、科学与语言”。载《从布劳威尔到希尔伯特：20世纪20年代关于数学基础的论争》，P. Mancosu编，45—53。Oxford University Press，1998。',
'Johann Jacob Brucker、William Enfield编：《哲学史：从最早时期到本世纪初；据布鲁克尔〈哲学批判史〉编写，威廉·恩菲尔德著》。《哲学史：从最早时期到本世纪初；据布鲁克尔〈哲学批判史〉编写，威廉·恩菲尔德著》，第1卷。P. Wogan，1792。https://books.google.co.uk/books?id=ximMZcSJY8gC。',
'Paul Burkett、John Bellamy Foster：“马克思政治经济学批判中的代谢、能量与熵：超越波多林斯基神话”。Theory and Society 35，第1期（2006）：109—156。ISSN：03042421、15737853。http://www.jstor.org/stable/4501746。',
'Tony Burns：“约瑟夫·狄慈根与马克思主义史”。Science and Society 66，第2期（2002）：202—227。',
'Jill Buroker：“波尔—罗亚尔逻辑”。载Stanford Encyclopedia of Philosophy。University of Stanford，2014。https://plato.stanford.edu/entries/port-royal-logic/。',
'Kristian Camilleri：“玻尔、海森堡与互补性的不同观点”。Studies In History and Philosophy of Science Part B: Studies in History and Philosophy of Modern Physics 38，第3期（2007）：514—528。'
]
assert len(groups)==len(translations)==len(oldrefs)
rows=[]
for i,(refs,zrefs,zh) in enumerate(zip(groups,oldrefs,translations),19):
    en=extract(EN,refs,True).replace('\u200b','').replace('google.co .uk','google.co.uk')
    row={'id':f'dm-ref-{i:03}','kind':'bibliography','source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['265'],'en':en,'zh':zh,'supplied_zh':extract(ZH,zrefs),'status':'text_compared_layout_pending','revision_reason':'逐条核对出版信息并补译题名；按原书顺序排列。'}
    if i==25:row['editor_note']='该条原书将原论文、英译说明及出版信息并列为一条，且出版社写作Permagon Press；照录原书，不以猜测补正。'
    if i==28:
        row['en']=en.replace(' Braidotti,','\n\nBraidotti,')
        row['bibliography_entry_count']=2
        row['revision_reason']='原书同一行接入Braidotti条目，按两条书目分段；保留源行整体引用，避免重复覆盖。'
    if i==36:row['editor_note']='原书重复印出同一长题名；本稿保留重复，现成译稿曾省去第二次。'
    rows.append(row)
save('refs02',12,rows,[],rr(274,1,17))
(W/'checkpoint_refs02.json').write_text(json.dumps({'next_source_pdf_page':275,'next_source_block':1,'next_supplied_pdf_page':156,'next_supplied_block':13,'next_reference':41,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
