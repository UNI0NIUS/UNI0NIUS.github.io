from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch06-{len(rows)+1:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(132,0,1),rr(66,30),'chapter',text='第6章 唯心主义的复兴与回应',english='Chapter 6: IDEALIST REPRISE AND RESPONSES')
rows[-1]['source_transcription_note']='恢复源页分栏标题的正常阅读顺序。'
add(rr(132,2),rr(67,0),'heading')
add(rr(132,3),rr(67,1,2))
add(rr(132,4),rr(67,3,4))
add(rr(132,5),rr(67,5,7),end='我不知道',text='尽管如今玻尔兹曼的原子论已完全没有争议，但在他生前却远非如此。许多欧洲大陆的著名物理学家都对原子的存在深表怀疑。例如，庞加莱把玻尔兹曼、汤姆森和麦克斯韦提出的关于热的原子论解释称为“英国[[1]]动理论”，并怀疑它能否解释熵增定律。',reason='kinetic theory译作动理论而非动能理论；补漏注1，统一汤姆森译名。')
add(rr(132,6),rr(67,7,12),'quote',start='我不知道',text='我不知道是否有人指出过，英国的这些动理论能够摆脱这一矛盾。按照这些理论，世界最初趋向于一种状态，并长久停留其中而不发生明显变化；这与经验相符。但如果不违背上述定理，世界就不会永远保持这种状态；它只会停留极其漫长的时间，分子越多，这段时间就越长。这种状态并非宇宙的最终死亡，而是一种沉睡，宇宙将在百万乘百万个世纪之后从中苏醒。按照这种理论，要看到热从冷物体传向热物体，并不需要麦克斯韦妖那样敏锐的视力、智慧和灵巧；稍有耐心便足够了。[[2]]',reason='分离误并入前段的引文；恢复acute vision及millions of millions含义。')
en=extract(EN,rr(132,7)+rr(133,1),True).replace('δt',r'$\delta_t$').replace('',r'$\epsilon$').replace('space t $\epsilon$',r'space $\delta_{t+\epsilon}$')
add(rr(132,7)+rr(133,1),rr(67,13,22),english=en,text=r'庞加莱对原子论的反对建立在严格的数学异议之上。这些异议源于抽象的拉格朗日力学或哈密顿力学，而非哲学或本体论。实质上，他利用刘维尔定理，把汤姆森在前引段落中给出的启发式解释转化为形式化的数学论证。由此可以证明：在时刻$t$，取$6N$维相空间内的一个微小体积$\delta_t$，使其沿最小作用量路径演化一个很短的时间$\epsilon$，它就会映射到相空间中的一个新区域$\delta_{t+\epsilon}$，而体积保持不变。因此，他认为，若从处于某一低熵状态的封闭系统出发，即从只占相空间中可能位置的一小部分的某个$\delta_t$出发，最后总会落到一个等体积的区域。也就是说，所得相空间体积同样不大可能出现。策梅洛也提出了类似论证。这些论证依赖于一个看似必然的结论：任何按确定性规律运行的有限粒子系统都会发生回归。对格子气例子那样简单且规模较小的模型，这一点当然成立；但如果宇宙无限——这实质上是汤姆森的观点——或者即使体积不大的气体，其回归也需要漫长得多的时间，以至于我们不妨把系统视为无限——这是玻尔兹曼的回应——那么这一论证便不能成立。',reason='修正最小作用量被误作映射主体、equally improbable漏译不大可能及较长时间弱化；据源图恢复相空间下标。')
add(rr(133,2),rr(67,23,25),'quote',fixes=[('泽尔梅洛','策梅洛'),('必须驳斥气体理论假设','必须摒弃气体理论的假设')])
add(rr(133,3),rr(67,26,28),fixes=[('复现论证','回归论证')])
add(rr(133,4),rr(67,29,32),text=r'我们此前[[4]]在讨论弗雷德金假设的可逆计算机[[5]]时谈过这个问题；在某种意义上，这些计算机是庞加莱论证的一种变体。用我们稍后将讨论的现代信息论来说，假定粒子位置具有任意精度，就意味着系统包含无限的信息，从而在相空间中占据零体积。由于熵以相空间体积的对数来定义，而$\log(0)$没有定义，策梅洛／庞加莱回归悖论的概念设定本身就使熵的概念失去了意义。',reason='补回漏注4、5，恢复log公式，统一策梅洛和回归术语。')
add(rr(133,5),rr(67,33,35),fixes=[('英国动能理论','英国动理论'),('晶格模型','格子模型'),('不符合物理本质','不符合物理实际')])
add(rr(133,6),rr(67,36),'heading')
add(rr(133,7)+rr(134,1),rr(68,0,4),fixes=[('哲学系主任','哲学教授席位')],reason='Chair of Philosophy指教授席位，不是哲学系主任。')
add(rr(134,2),rr(68,5,11),'quote',fixes=[('这最终导致了他自杀。','这促使他自杀。[[6]]')],reason='恢复引文层级和漏注6；该引文中的归因均为原文所述。')
add(rr(134,3),rr(68,12,17),fixes=[('“热量”（caloric）','“热质”（caloric）'),('“热量说”','“热质说”')])
add(rr(134,4),rr(68,18,19),text='人们本以为，这一切在19世纪中叶就已解决，但他在一部著作[[7]]（初版于1872年）中，给出了他认为热的机械理论缺乏依据的理由。',reason='恢复仅由注号指代的著作，补注7；原文未在正文写出书名。')
add(rr(134,5),rr(68,20,22),fixes=[('热量说','热质说'),('拉姆福德','伦福德'),('汤姆孙','汤姆森')])
add(rr(134,6),rr(68,23),text='他以电现象作类比。')
nt={1:'汤姆森和麦克斯韦是苏格兰人，玻尔兹曼是奥地利人。',2:'Henri Poincaré：“机制与经验”（Mechanism and Experience），载《气体动理论：经典论文选集及历史评注》（The Kinetic Theory Of Gases: An Anthology of Classic Papers with Historical Commentary）（World Scientific，2003），第377—381页。',3:'Boltzmann：“答策梅洛关于热理论的评论”（Reply to Zermelo’s Remarks on the Theory of Heat）。',4:'Paul Cockshott、Lewis M. Mackenzie与Gregory Michaelson：《计算及其极限》（Computation and its Limits）（Oxford University Press，2012），第117—120页。',5:'E. Fredkin与T. Toffoli：“保守逻辑”（Conservative Logic），International Journal of Theoretical Physics，第21卷第3期（1982），第219—253页。',6:'S. Rajasekar与N. Athavan：“路德维希·爱德华·玻尔兹曼”（Ludwig Edward Boltzmann），arXiv预印本physics/0609047，2006。',7:'Ernst Mach：《能量守恒原理的历史与根源》（History and Root of the Principle of the Conservation of Energy）（Open Court Publishing Company，1910）。'}
notes=[]
for n,refs in note_groups(rr(259,3)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch06-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['250'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch06a',6,rows,notes,rr(132,0,7)+rr(133,1,7)+rr(134,1,6))
(W/'checkpoint_ch06a.json').write_text(json.dumps({'next_source_pdf_page':134,'next_source_block':7,'next_supplied_pdf_page':68,'next_supplied_block':24,'next_unit':len(rows)+1,'next_note':8,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
