from materialism_common import *
groups=[[[281,20,1,2],[281,21]]]
for b in EN[281]['blocks'][1:]:
    for j,l in enumerate(b['lines']):
        if l['bbox'][0]<62:groups.append([])
        groups[-1].append([282,b['block'],j,j+1])
oldrefs=[rr(166,25,27),rr(167,0,1),rr(167,2,3),rr(167,4),rr(167,5,7),rr(167,8,9),rr(167,10,11),rr(167,12,13),rr(167,14,15),rr(167,16),rr(167,17),rr(167,18,19),rr(167,20,21),rr(167,22,23),rr(167,24),rr(167,25,26),rr(167,27),rr(168,0,1),rr(168,2,4),rr(168,5,6),rr(168,7,8),rr(168,9),rr(168,10,11)]
translations=[
'艾萨克·牛顿：《自然哲学的数学原理……由安德鲁·莫特译……附牛顿〈宇宙体系〉；W. Emerson对〈原理〉的简评与辩护；并附John Machin依据引力论述的月球运动规律……（某先生的序言）》。1848。',
'John William Nicholson：“日冕的构造。IL”。Monthly Notices of the Royal Astronomical Society 72，第8期（1912）：677—693。',
'Emmy Noether：“不变变分问题”。Transport Theory and Statistical Physics 1，第3期（1971）：186—207。',
'I. I. Osmakov：“论思维的逻辑与逻辑科学”。Voprosy Filosofii 3（1950）：309—317。',
'Giuseppe Peano：“用新方法表述的算术原理”。载《从弗雷格到哥德尔：数理逻辑文献集，1879—1931》，J. van Heijenoort编译。Harvard University Press，1967。',
'Jean Perrin：“布朗运动与分子的实在性”。Annales de chimie et de physique 18（1909）：1—114。',
'Pavle Petrovic：“生产价格对劳动价值的偏离：一些方法论与实证证据”。Cambridge Journal of Economics 11（1987）：197—210。',
'Alexander Philipov：《苏联的逻辑与辩证法》。Research Program on the U.S.S.R，Varengian Press，1952。',
'柏拉图：《斐多篇》，C. J. Rowe编订并评注。Christopher J. Rowe编。Cambridge University Press，1992。',
'柏拉图：《理想国》。P. Shorey译，第1卷。Loeb Classical Library。Harvard，1937。',
'柏拉图：《理想国》。P. Shorey译，第2卷。Loeb Classical Library。Harvard，1962。',
'Henri Poincaré：“机械论与经验”。载《气体动理论：附历史评论的经典论文选》，377—381。World Scientific，2003。',
'Huw Price：《时间之箭与阿基米德点：时间物理学的新方向》。Oxford University Press，1997。',
'Patrick Prosser：“二元约束满足问题中相变的实证研究”。Artificial Intelligence 81，第1—2期（1996）：81—109。',
'Marian Przelecki：《经验理论的逻辑》。Routledge and Kegan Paul，1969。',
'C. E. Quin：“盖伦之后神经系统功能中的灵魂与普纽玛”。Journal of the Royal Society of Medicine 87，第7期（1994）：393—395。ISSN：0141-0768。https://europepmc.org/articles/PMC1294649。',
'Willard. V.-O. Quine：《从逻辑的观点看：逻辑哲学论文集》。Harper Torchbook，1963。',
'Shanmuganathan Rajasekar、Nadarajah Athavan：“路德维希·爱德华·玻尔兹曼”。arXiv预印本physics/0609047，2006。',
'Barbara Rappenglück、Michael A. Rappenglück、Kord Ernstson、Werner Mayer、Andreas Neumair、Dirk Sudhaus、Ioannis Liritzis：“法厄同的坠落：希腊—罗马地质神话保存了巴伐利亚（德国东南部）一次陨石撞击的记忆”。Antiquity 84，第324期（2010）：428—439。',
'大卫·李嘉图：“政治经济学及赋税原理”。载《大卫·李嘉图著作和通信集》，P. Sraffa编，第1卷。Cambridge University Press，1951。',
'Philipp Roser：“德布罗意—玻姆导波图景中的量子计算”。arXiv预印本arXiv:1012.4843，2010。',
'W. David Ross编：《亚里士多德物理学》Clarendon Press。Oxford University Press，1950。',
'J. Barkley Rosser：“熵与经济物理学”。The European Physical Journal Special Topics 225，第17期（2016）：3091—3104。'
]
assert len(groups)==len(oldrefs)==len(translations)==23
rows=[]
for i,(refs,zrefs,zh) in enumerate(zip(groups,oldrefs,translations),208):
    raw=extract(EN,refs,True);en=raw.replace('europepmc. org','europepmc.org')
    row={'id':f'dm-ref-{i:03}','kind':'bibliography','source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in refs)),'en':en,'zh':zh,'supplied_zh':extract(ZH,zrefs),'status':'text_compared_layout_pending','revision_reason':'逐条核对完整题名和出版信息，补译并保持原书顺序。'}
    if en!=raw:row['source_transcription_note']='去除URL域名内排版空格；原始span保留。'
    if i==208:row['editor_note']='原书长题名以省略号及残缺的“The Preface of Mr”结尾；本稿照录，不补造缺失姓名。'
    if i==212:row['editor_note']='原书英文题名拼作Arithemtic，英文照录，中文译算术。'
    if i==214:row['editor_note']='原书英文题名写Methodolog，英文照录，中文按方法论译出。'
    if i==229:row['editor_note']='原书将Clarendon Press直接接在拉丁题名之后，随后又列Oxford University Press；本稿保留两者。'
    rows.append(row)
save('refs10',12,rows,[],[[281,20,1,2],[281,21]]+rr(282,1,19))
(W/'checkpoint_refs10.json').write_text(json.dumps({'next_source_pdf_page':283,'next_source_block':1,'next_supplied_pdf_page':168,'next_supplied_block':12,'next_reference':231,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
