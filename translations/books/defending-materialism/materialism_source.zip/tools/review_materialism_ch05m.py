from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch05-{len(rows)+161:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(102,10)+rr(103,1),rr(50,18,22),fixes=[('[[6]] [[3]]','[[63]]'),('在这种情况下，马克思关于资本主义运动的定律就仅仅是','若是那种情况，马克思关于资本主义运动的定律就只会是')],reason='保留would的假设语气，避免把末句误译为作者对现实情况的直接判断。')
rows[-1]['editor_note']='底本在陈述劳动相关性更强之后，紧接In that case ... would ...，其指代与段内次序存在歧义。中文保留假设语气；未调换原句顺序或删去该句。'
add(rr(103,2),rr(50,23,24),fixes=[('[[6]] [[4]]','[[64]]'),('[[6]] [[5]]','[[65]]'),('——后者曾','——他们曾')],reason='who在传统的先驱语境中不应只限定为最后一个李嘉图。')
add(rr(103,3),rr(50,25,27),fixes=[('它缺乏现代科学严谨性标准','它未达到现代科学的严谨性标准')])
add(rr(103,4),rr(50,28,30),fixes=[('全名为','题为')])
add(rr(103,5),rr(50,31,32),fixes=[('便会引发争议','问题便出现了')],reason='issue arises不特指发生争议。')
add(rr(103,6),rr(51,0,1),fixes=[('[[6]] [[6]]','[[66]]')])
add(rr(103,7),rr(51,2,4))
add(rr(103,8),rr(51,5,7),fixes=[('传统研究方法','常规研究方法')])
add(rr(103,9),rr(51,8,13),fixes=[('[[6]] [[7]]','[[67]]'),('[[6]] [[8]]','[[68]]'),('蒸汽汽化潜热','汽化潜热')])
nt={63:'参见Emmanuel Farjoun与Moshe Machover：《混沌的规律：政治经济学的概率方法》（Laws of Chaos, a Probabilistic Approach to Political Economy）（Verso，1983）；E. Farjoun：“以什么生产商品？”（Production of Commodities by Means of What?），载《李嘉图、马克思、斯拉法》（Ricardo, Marx, Sraffa），E. Mandel编（Cambridge University Press，1984）。',64:'Khaldun、Rosenthal与Dawood：《历史绪论》（The Muqaddimah: An Introduction to History; in Three Volumes），第1卷。',65:'David Ricardo：“政治经济学及赋税原理”（Principles of Political Economy and Taxation），载《李嘉图著作与通信集》（The Works and Correspondence of David Ricardo），P. Sraffa编，第1卷（Cambridge University Press，1951）。',66:'“我看得远，是因为我站在巨人的肩膀上。”——牛顿。',67:'Friedrich Engels：《自然辩证法》（Dialectics of Nature）（Progress Publishers，1974）。',68:'关于这段历史，可阅读Cardwell的《从瓦特到克劳修斯：工业时代早期热力学的兴起》（From Watt to Clausius: The Rise of Thermodynamics in the Early Industrial Age）。'}
notes=[]
for p,b in [(255,4),(256,1)]:
    for n,refs in note_groups(rr(p,b)):
        if n not in nt:continue
        notes.append({'id':f'dm-ch05-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':[str(p-9)],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch05m',5,rows,notes,rr(102,10)+rr(103,1,9))
(W/'checkpoint_ch05m.json').write_text(json.dumps({'next_source_pdf_page':104,'next_source_block':1,'next_supplied_pdf_page':51,'next_supplied_block':14,'next_unit':len(rows)+161,'next_note':69,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
