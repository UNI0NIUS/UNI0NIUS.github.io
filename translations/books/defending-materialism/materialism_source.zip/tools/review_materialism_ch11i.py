from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch11-{len(rows)+100:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
en=extract(EN,rr(231,7),True).replace('N O 2',r'$\mathrm{N_2O}$').replace('N2O5',r'$\mathrm{N_2O_5}$').replace('N0, N2O3, NO2',r'$\mathrm{N0}$, $\mathrm{N_2O_3}$, $\mathrm{NO_2}$')
add(rr(231,7),rr(123,23,30),'quote',text=r'然而，黑格尔所发现的自然规律取得最重要胜利的领域，是化学。化学可以称为研究物体因数量组成改变而发生质变的科学。黑格尔本人已经知道这一点。以氧为例：如果三个原子而非通常的两个原子结合成一个分子，就得到臭氧，一种在气味和反应上都与普通氧大不相同的物体。又如，氧可以按不同的比例与氮或硫结合，每一种比例都产生在质上不同于其他任何一种的物质！笑气（一氧化氮，$\mathrm{N_2O}$）与硝酸酐（五氧化二氮，$\mathrm{N_2O_5}$）多么不同！前者是气体，后者在常温下是固态结晶物质。然而，二者在组成上的全部区别，仅在于后者含氧量是前者的五倍；二者之间还有另外三种氮的氧化物（$\mathrm{N0}$、$\mathrm{N_2O_3}$、$\mathrm{NO_2}$），每一种在质上都与前两种及彼此不同。[[24]]',english=en,reason='恢复化学式；保留原书引文对笑气的名称误写及N0字形，以校注说明。')
rows[-1]['editor_note']='原书将笑气N₂O称作“nitrogen monoxide”（一氧化氮）；N₂O的通常中文名称为一氧化二氮。后列第一式原书印作“N0”（末位为数字零），依上下文应为NO。正文保留原书写法。'
add(rr(232,1),rr(123,31),text='于是，我们竟有了一条由黑格尔发现的“自然规律”！')
add(rr(232,2),rr(123,32,33)+rr(124,0,3),text='得了吧，弗雷德。你要找的名字是道尔顿，约翰·道尔顿，而不是黑格尔。被引为这条“规律”出处的黑格尔《逻辑学》出版于1812年；道尔顿的《化学哲学新体系》早在四年前，即1808年，就已问世。这充其量是黑格尔事后把他人的发现说成自己的发现，就像1801年他声称自己对牛顿万有引力定律有更高明的证明一样。我们在第3.4节已经指出，黑格尔这些关于独创性的主张是不连贯的胡言乱语。这里也是如此。化合物中各组成元素的原子必须以自然数之比存在，这是道尔顿原子理论不可分割的一部分。恩格斯援引黑格尔，在水沸腾时的相变与这些数值比例之间作类比，其不连贯程度与黑格尔关于引力的论证如出一辙。',reason='保留原文对恩格斯的直接揶揄及论战语气，不改写为中性转述。')
en=extract(EN,rr(232,3),True).replace('N O 1 275 .',r'$\mathrm{N}_{1.275}\mathrm{O}$').replace('between NO and N2O',r'between $\mathrm{NO}$ and $\mathrm{N_2O}$')
add(rr(232,3),rr(124,4,8),text=r'水沸腾的情形中，有一个连续的模拟尺度，即温度；在这一尺度的某些点上发生相变，其标志是另一个模拟尺度，即熵，出现不连续。在化学的情形中，并不存在连续的模拟尺度。逐渐增加氮，并不会使化合物突然改变。在$\mathrm{NO}$与$\mathrm{N_2O}$之间，不可能有$\mathrm{N}_{1.275}\mathrm{O}$这样的化合物。每种原子的数量都必须是整数。这是原子在化学上不可分的结果。因此，这里并非渐进的量变导致突发的质变，而是存在一组离散的化合物，每种都含有离散数量的原子。',english=en,reason='analogue scale不是类比尺度；补回旧译遗漏的NO与N2O之间这一限定。')
add(rr(232,4),rr(124,9,11),text='“量转化为质”这条“规律”具有强烈的政治吸引力。关于量变导致质变的说法，可以被理解为一种隐喻：对工人阶级的剥削在量上加重，最终导致突然爆发的暴力革命。把革命比作紧张局势沸腾后溢出的结果，早在19世纪就已有这种用法。[[25]]')
add(rr(232,5),rr(124,12,15),text='这条所谓量转化为质的普遍规律，与许多唯心主义哲学一样，建立在肤浅的类比和双关之上。作为普遍规律，它对预测毫无用处。事实上，即使对于革命，这种类比是否说得通也值得怀疑。在苏联的革命图像中，群众团结为有组织的队列，向红色未来行进，或聚集在正在演讲的列宁面前。革命发生于熵减之时，也就是群众获得秩序和方向、不再漫无目的地运动之时。')
add(rr(232,6),rr(124,16,17),text='有人可能反驳，相变这个概念有时也颇具隐喻性。如果我们嘲笑黑格尔式的量变质变观念，又为什么允许科学家谈论其他相变？')
add(rr(232,7),rr(124,18,19),text='这种反驳不能成立，因为在科学文献中使用相变一词，就应当证明：当一个变量连续变化时，另一个类似于熵的变量发生了不连续变化。')
add(rr(232,8),rr(124,20,21),text='让我们举一个使用相变这一术语的非物理学例子，说明这一术语的应用必须满足严格的理论约束。')
notes=[]
for n,refs,zh in [(24,[[272,1,4,5]],'恩格斯，《自然辩证法》，第2章。'),(25,[[272,1,5,7],[272,2]],'例如，Charles Merivale的《帝国时期罗马人史》（Longmans，1851）中写道：“但在这个时代，实施这种不义行径不可能不受惩罚。战争的因素正在整个半岛酝酿；成千上万破产的人突然被抛入那动荡不定、心怀不满的人群中，这群人只缺少这一成分，就会在新的革命中沸腾爆发。”（第223页）')]:
    notes.append({'id':f'dm-ch11-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['263'],'en':extract(EN,refs,True),'zh':str(n)+'. '+zh,'status':'text_compared_layout_pending'})
save('ch11i',11,rows,notes,rr(231,7)+rr(232,1,8))
(W/'checkpoint_ch11i.json').write_text(json.dumps({'next_source_pdf_page':232,'next_source_block':9,'next_supplied_pdf_page':124,'next_supplied_block':22,'next_unit':len(rows)+100,'next_note':26,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
