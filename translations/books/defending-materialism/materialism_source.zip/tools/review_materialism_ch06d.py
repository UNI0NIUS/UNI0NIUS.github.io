from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch06-{len(rows)+55:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
en=extract(EN,rr(140,13)+rr(141,1),True).replace('6 × 10[[23]]',r'$6\times10^{23}$').replace('7.15×10[[23]]',r'$7.15\times10^{23}$')
add(rr(140,13)+rr(141,1),rr(70,36,37)+rr(71,0,2),english=en,text=r'论文[a]表明，微粒的布朗运动可以根据分子动理论作出定量预测，由此奠定了基础。[[17]]在题为“悬浮粒子的平均位移公式：测定原子实际大小的新方法”的一节中，他说明：若假定阿伏伽德罗常数为$6\times10^{23}$，那么直径为1微米的小球在水分子随机撞击下，预计每分钟会移动约6微米。反过来，若通过实验精确测量这些小球的运动，就能更精确地估计阿伏伽德罗常数。这一预测很快在实验中得到验证，[[18]]并在这一过程中将阿伏伽德罗常数的估计值修正为$7.15\times10^{23}$。',reason='恢复两个10的23次方，避免指数误作注号；原文by后仅有注18，没有擅补作者姓名。')
rows[-1]['editor_note']='底本“in experiments by”后没有作者姓名，直接接注18；该注列Jean Perrin。中文按句意连接，英文保留原貌。'
add(rr(141,2),rr(71,3,5),text='仅凭这篇论文，就足以彻底驳倒马赫派反对原子、分子及热的动理论的论点。但若考察爱因斯坦在那个夏天接连发表的整组论文，就能看到一个逐渐展开的主题：捍卫关于实在的微粒观，反对与之争论、受到马赫及其支持者青睐的能量论学派。',reason='kinetic theory统一动理论；corpuscular view of reality为关于实在的微粒观，非现实粒子观。')
add(rr(141,3),rr(71,6),end='光波动理论',text='爱因斯坦[[19]]论证了为什么应把光看作微粒。他在开篇写道：')
add(rr(141,4),rr(71,6,9),'quote',start='光波动理论')
add(rr(141,5),rr(71,10,13),'quote')
add(rr(141,6),rr(71,14))
add(rr(141,7),rr(71,15,17))
add(rr(141,8),rr(71,18,21),end='该方程表明',text=r'到这里，他阐述的仍是当时公认的光发射理论。然而，他证明这一理论的预测偏离了实验结果。考虑频率越来越高的辐射时，理论所预测的腔内辐射能会趋于无穷大。他推导出一个方程，说明体积为$v_0$的腔内单色光的熵应是多少，以及当光的全部能量集中到腔内某个子体积$v$中时，这个熵会怎样变化。[[21]]对此，他指出：',english=extract(EN,rr(141,8),True).replace('v0',r'$v_0$'),reason='旧译误添熵符号S且漏掉腔体积v0；恢复体积下标并分离下段引文。')
add(rr(142,1),rr(71,20,22),'quote',start='该方程表明')
add(rr(142,2),rr(71,23))
nr={17:[[260,1,0,3]],18:[[260,1,3,4]],19:[[260,1,4,6]],20:[[260,1,6,8]],21:[[260,1,8,9]]+rr(260,2,9)+[[260,10,0,5]],22:[[260,10,5,7]]}
nt={17:'关于该论文及其意义的概述，参见Debashish Chowdhury：“爱因斯坦布朗运动理论一百年：从花粉粒到蛋白质列车——1”（100 Years of Einstein’s Theory of Brownian Motion: From Pollen Grains to Protein Trains—1），Resonance，第10卷第9期（2005），第63—78页。',18:'Jean Perrin：“布朗运动与分子实在性”（Mouvement brownien et réalité moléculaire），1909。',19:'Einstein：“关于光的发射和转化的一种启发式观点”（Concerning an Heuristic Point of View Toward the Emission and Transformation of Light）。',20:'A. Einstein：“关于光的发射和转化的一种启发式观点”（Concerning an Heuristic Point of View Toward the Emission and Transformation of Light），American Journal of Physics，第33卷第5期（1965），第367页。',21:r'例如，全部电磁能恰好集中于腔的一半。他的方程为$S-S_0=k\ln\left(\frac{v}{v_0}\right)^{\frac{E}{h\nu}}$，其中$S,S_0$分别为最终和初始的熵，$v,v_0$分别为最终和初始的体积，$k,h$分别为玻尔兹曼常数和普朗克常数，$\nu$为频率，$E$为能量。',22:'Einstein：“关于光的发射和转化的一种启发式观点”（Concerning an Heuristic Point of View Toward the Emission and Transformation of Light）。'}
notes=[]
for n,refs in nr.items():
    en=extract(EN,refs,True)
    if n==21:en=r'21 An example would be if all the electromagnetic energy happened to be concentrated in one half of the cavity. His equation says $S-S_0=k\ln\left(\frac{v}{v_0}\right)^{\frac{E}{h\nu}}$ where $S,S_0$ are the. final and initial entropies, $v,v_0$ final and. initial volumes, $k,h$ the. Boltzmann and Plank constants, $\nu$ . requency and $E$ . energy.'
    notes.append({'id':f'dm-ch06-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['251'],'en':en,'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
    if n==21:notes[-1]['editor_note']='公式据源图恢复。底本Plank及requency等拼写和多余句点在英文中照录，中文按符号含义翻译。'
save('ch06d',6,rows,notes,rr(140,13)+rr(141,1,8)+rr(142,1,2))
(W/'checkpoint_ch06d.json').write_text(json.dumps({'next_source_pdf_page':142,'next_source_block':3,'next_supplied_pdf_page':71,'next_supplied_block':24,'next_unit':len(rows)+55,'next_note':23,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
