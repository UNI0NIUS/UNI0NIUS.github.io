from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch09-{len(rows)+31:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(199,1),rr(103,32),text='图灵机由一组各含五个组成部分的指令控制，称为五元组。每条指令规定：',reason='五元组指每条指令，不是整个指令集。')
add(rr(199,2),rr(104,0),'list_item',text=r'$\mathrm{state}_{\mathrm{old}}$：如果机器处于这一旧状态，',english=r'$\mathrm{state}_{\mathrm{old}}$: if the machine is in this old state,')
add(rr(199,3),rr(104,1),'list_item',text=r'$\mathrm{symbol}_{\mathrm{old}}$：且读写头下是这一旧符号，',english=r'$\mathrm{symbol}_{\mathrm{old}}$: and this old symbol is under the head,')
add(rr(199,4),rr(104,2),'list_item',text=r'$\mathrm{state}_{\mathrm{new}}$：则切换到这一新状态，',english=r'$\mathrm{state}_{\mathrm{new}}$: then change to this new state,')
add(rr(199,5),rr(104,3),'list_item',text=r'$\mathrm{symbol}_{\mathrm{new}}$：把读写头下格子的内容改为这一新符号，',english=r'$\mathrm{symbol}_{\mathrm{new}}$: change the cell under the head to this new symbol,')
add(rr(199,6),rr(104,4),'list_item',text='direction：沿这一方向移动纸带一格，即向左或向右，或者停机。')
add(rr(199,7),rr(104,5,7),text=r'机器的指令设置在控制单元中。控制单元反复寻找一条指令，其$\mathrm{state}_{\mathrm{old}}$和$\mathrm{symbol}_{\mathrm{old}}$与当前状态及读写头下的符号相匹配，然后执行它。若不存在这样的指令，计算就失败。利用查找、修改和复制符号序列这些基本操作，可以构造复杂的图灵机。',english=r'The machine is set up with the instructions in a control unit. This repeatedly looks for an instruction whose $\mathrm{state}_{\mathrm{old}}$ and $\mathrm{symbol}_{\mathrm{old}}$ match the current state and symbol under the head, which is then carried out. If there is no such instruction, the computation fails. Elaborate TMs may be constructed from the basic operations of searching for, changing and copying sequences of symbols.',reason='恢复下标，统一纸带术语。')
add(rr(199,8),rr(104,8,10),text='图灵的关键洞见是，图灵机的纸带可以存放任何符号序列，包括一组图灵机指令的符号序列。事实上，可以构造一台通用图灵机（UTM），配以适当的数据，逐个符号执行存放在其纸带上的任意图灵机。')
add(rr(199,9),rr(104,11,13),text='面对任意图灵机究竟是否会终止这一问题，图灵构造了如下悖论。假设纸带上存放一台“待测试”图灵机的符号及其数据。再假设我们能够构造一台“停机判定”图灵机，它检查纸带：如果待测试机在其数据上停机，就以一个状态停下；如果待测试机在其数据上不停机，就以另一个状态停下。',reason='原文stop适用于两个分支，旧译停留状态不明确；用停机判定机区别被测试机器。')
add(rr(199,10),rr(104,14,16),text='写出一台不停机的图灵机很容易。它从一个空格开始，写入0，然后向右移动一格。若右边没有格子，就增加一个。实际上，这台图灵机会永远“循环”，使纸带向无限延伸，却永远达不到无限。',reason='without ever reaching it指达不到无限，旧译永不到纸带尽头错误。')
add(rr(199,11),rr(104,17,18),text='我们可以修改这台停机判定机：如果待测试机在其数据上不停机，它就以一个状态停下；如果待测试机在其数据上停机，它就执行那条循环指令。')
add(rr(199,12),rr(104,19,21),text='假设把修改后的停机判定机应用于它自身及某条纸带。如果它处理自身时不停机，那么它就会停机；如果它处理自身时停机，那么它就进入循环，不再停机。图灵得出结论：不可能构造一台图灵机来判断任意图灵机是否停机；也就是说，图灵机的停机问题不可判定。')
add(rr(199,14),[],'figure',text='图9.1 图灵机。作者绘图。',reason='补旧译遗漏的原图与图注。')
rows[-1].update(image='assets/figure-9-1.jpeg',source_image={'pdf_page':199,'block':13,'xref':1398},image_labels_zh='cell：单元格；head：读写头；tape：纸带。')
save('ch09c',9,rows,[],rr(199,1,12)+rr(199,14))
(W/'checkpoint_ch09c.json').write_text(json.dumps({'next_source_pdf_page':200,'next_source_block':1,'next_supplied_pdf_page':104,'next_supplied_block':22,'next_unit':len(rows)+31,'next_note':4,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
