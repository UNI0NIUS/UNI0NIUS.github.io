from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch08-{len(rows)+94:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(188,1),rr(98,9,11),text='战争和移民造成专家短缺，因此起初只要能确保忠诚，国家就无法对剩余的非共产党知识界的意识形态正确性要求过高。与此同时，在共产党领导下不断扩大的教育体系，持续培养出新一代“红色专家”——科学家和工程师。他们明确致力于苏联的目标，却必然要与革命前的一辈人共同工作。')
add(rr(188,2),rr(98,12,13),text='数学发挥了核心作用；这一时期，莫斯科和列宁格勒发展出两个世界级数学中心。纯数学研究虽在继续，但重点在于应用数学。总体上，形式逻辑并不突出。')
add(rr(188,3),rr(98,14,15),text='然而，形式逻辑的地位依然存在争议，甚至在布尔什维克内部围绕苏联发展方向的两极分化中也是如此。例如，1921年，列宁[[35]]在讨论托洛茨基的工会提案时，批评布哈林忽视辩证逻辑。[[36]]',reason='补旧译漏注35，保留注36。')
add(rr(188,4),rr(98,16,19),text='1924年列宁去世后，布尔什维克不同派别之间的斗争变得尖锐。这些斗争以新经济政策（NEP）为背景：新经济政策违背社会主义的愿望，引入相当大的市场成分，试图在战时共产主义这一务实的指令经济所带来的困境之后，加快经济恢复。过度简化地说，“左”派主张迅速从新经济政策转向计划经济，“右”派则主张较慢的转变。这些斗争还与争夺地位、清算旧账深深交织在一起。',reason='command economy译指令经济，与下文planned economy区分；保留作者“过度简化”的限定。')
add(rr(188,5),rr(98,20,23),text='正如海伦娜·希恩[[37]]系统考察的那样，科学与哲学的关系在意识形态和实践两个层面，都成为这些争论的重要组成部分。由此形成两种立场。一方质疑辩证法与科学的相关性，符合亚里士多德传统：成熟的科学独立于其辩证法根源而自主发展。反对者把这一立场称为机械论，认为它源于马克思和恩格斯曾反对的机械唯物主义。另一方则重新强调辩证法，似乎符合汲取黑格尔思想的马克思主义主流传统。',reason='补漏注37。')
add(rr(188,6),rr(98,24,27),text='起初，科学话语内部的意识形态斗争针对的是“右”倾，它在论战措辞中被称为孟什维克倾向。在这里，德波林领导的辩证法派在与机械论派的斗争中占了上风。在数学领域，这导致形式逻辑受到越来越强烈的拒斥。辩证法派的优势没有维持多久。在随后反对“左”倾的斗争中，对辩证法的过度依赖被称为唯心主义。正如弗里德曼后来在那篇标题颇能说明问题的《苏联反对形式主义的反叛》[[38]]中所写：',reason='合并同一原文段落，统一德波林；telling titled的评价补回。')
add(rr(188,7),rr(98,27,29),'quote',text='但是，机械论的批评者被热情冲昏头脑，走向了另一个极端——唯心主义。这就需要党的理论家所说的“两条战线上的斗争”。显然，在这里也是实践中的失误引起了对理论问题的注意。（第307页）',reason='idealism改唯心主义，旧译理想主义错。')
add(rr(189,1),rr(98,30,31),text='然而，这一倾向的失败并没有使逻辑得到恢复。相反，两种立场都被混同为孟什维克化的唯心主义，苏联的形式逻辑日益停滞，直到20世纪50年代初。')
add(rr(189,2),rr(98,32),'heading',text='孟什维克化的唯心主义与逻辑')
add(rr(189,3),rr(99,0,1),text='杰出的数学家安德烈·柯尔莫哥洛夫（1903—1987）是新一代红色专家的代表。他1925年的论文《论排中律》[[39]]批评了形式主义和直觉主义，但也表明，经典逻辑与直觉主义逻辑可以在直觉主义框架内得到调和。',reason='统一通行译名柯尔莫哥洛夫；注39归位论文名后。')
add(rr(189,4),rr(99,2,3),text='布劳威尔曾主张，用排中律和超限前提来确立有限性结果是不正当的。柯尔莫哥洛夫证明，即使不诉诸这二者，这类有限性结果仍然成立。')
add(rr(189,5),rr(99,4,5),text='柯尔莫哥洛夫与直觉主义者一样，认为在没有其他证据时，相互矛盾的项应被视为未定。他也与直觉主义者一样，质疑超限前提是否有意义，即使它们能够用来得到有限性结果。',reason='terms此处为项，不译术语。')
add(rr(189,6),rr(99,6,7),text='柯尔莫哥洛夫把形式主义描述为不对前提的选择作出承诺，听起来与亚里士多德的辩证法相近。他指出，可以把对立项之一增加为公理来解决矛盾，并观察到，从形式主义的角度看：')
add(rr(189,7),rr(99,7,8),'quote',text='因此，从每一对相互矛盾的公式中选出一个作为新公理，只需考虑是否方便。（第417页）')
add(rr(189,8),rr(99,9,11),text='此外，形式主义逻辑不赋予公理任何意义，而直觉主义则以“表达给予我们的事实”的公理为基础（第417页）。这是黑格尔的、也是辩证唯物主义的立场，即一种统一的、有内容的逻辑。然而，柯尔莫哥洛夫仍将“数理逻辑”视为数学中一个独立的组成部分。在这里，他并未采取一种明确带有派别立场的哲学姿态，而是采取数学的立场。',reason='补旧译漏掉的与数学立场的对比；mathematical logic统一数理逻辑。')
add(rr(189,9),rr(99,12,17),text='然而，正如武西尼奇[[40]]所考察的，就在同一年，即1925年，苏联的意识形态家在哲学期刊《在马克思主义旗帜下》明确攻击支撑康托尔成果的唯心主义。武西尼奇指出，当时没有人试图寻找一种唯物主义的替代方案来取代康托尔的理论（第117—118页）；虽然希尔伯特受到的关注较少，辩证逻辑却被置于形式逻辑的对立面（第118—119页）。不过，这些攻击针对康托尔的集合论，而非苏联数学家（第122页）。曾属列宁格勒学派的数学家G. G. 洛伦兹[[41]]指出，同一时期，基辅的一个代数学派在乌克兰共产党指示下被关闭，其学者分散到其他中心。',reason='修复拆开的注40、41并归位；避免旧译让康托尔理论成为唯物主义理论。')
nt={35:'V. I. Lenin：“再论工会、目前局势及托洛茨基和布哈林的错误”，载《列宁全集》英文第1版，Y. Sdobnikov译，第32卷（莫斯科：Progress Publishers，1965），第70—107页，https://www.marxists.org/archive/lenin/works/1921/jan/25.htm 。',36:'很难想象当今的国家元首会在工会问题的辩论中讨论逻辑的地位，更不用说是在内战期间了。',37:'H. Sheehan：《马克思主义与科学哲学：批判读本》（Humanity Books，1985）。',38:'G. Friedmann：“苏联反对形式主义的反叛”，Science & Society 2，第3期（1938）：300—321。',39:'A. Kolmogorov：“论排中律”，载van Heĳenoort编《从弗雷格到哥德尔》，第414—437页。',40:'A. Vucinich：“苏联的数学与辩证法：斯大林以前的时期”，Historia Mathematics 26（1999）：107—124。',41:'G. G. Lorentz：“1928至1953年苏联的数学与政治”，Journal of Approximation Theory 116（2002）：169—223。'}
notes=[]
for n,refs in note_groups(rr(266,1)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch08-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['257'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
for n in notes:
    if n['note_number']==35:
        n['en']=n['en'].replace('https:// www','https://www')
        n['source_transcription_note']='移除源PDF网址在https://后换行产生的空格；原始span保存不变。'
save('ch08f',8,rows,notes,rr(188,1,7)+rr(189,1,9))
(W/'checkpoint_ch08f.json').write_text(json.dumps({'next_source_pdf_page':190,'next_source_block':1,'next_supplied_pdf_page':99,'next_supplied_block':18,'next_unit':len(rows)+94,'next_note':42,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
