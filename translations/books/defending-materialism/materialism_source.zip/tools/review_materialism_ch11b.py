from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch11-{len(rows)+20:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(224,1),rr(117,29,30),text='香农将符号的信息量与其原始编码区分开来，这在密码学[[4]]和数据压缩中有实际用途。每当观看数字电视或收听MP3音轨时，你都在不知不觉中依赖香农的信息论。')
add(rr(224,2),rr(118,0,1),text='但从唯物主义的角度看，这个公式最引人注目之处，在于它的信息公式在函数形式上与玻尔兹曼的熵公式相同。[[5]]',reason='functionally指函数形式，不是功能相同；原注说明离散求和与连续积分区别。')
add(rr(224,3),rr(118,2),text='这表明，在深层意义上，信息与熵是同一回事。从哲学角度看，这令人震惊。')
add(rr(224,4),rr(118,3),'heading',text='物理意义')
add(rr(224,5),rr(118,4,6),text='此前，哲学并未费心定义信息，但这个词的通常用法与人所能理解的信息紧密相连。在这种背景下，认为信息是物理的，而且与物理学的原子层面相联系，认为可以完全撇开信息的意义、纯粹进行统计分析，都是违反直觉的。',reason='原句衔接欠顺，依段落对比整理；旧译误为人类可理解性导致信息被视为物理实体，倒置了论证。')
add(rr(224,6),rr(118,7,8),text='人们可能天真地以为，诸如印刷文本之类的数据，只因读者能够主观地赋予其意义，才包含信息。反过来，也可能认为，这种意义及其信息源自原作者的主观意图。')
add(rr(224,7),rr(118,9),text='对于当代文本，这似乎说得通。但难以理解的信息呢？')
add(rr(224,8),rr(118,10),text='在发现罗塞塔石碑以前，象形文字文本中的信息又如何呢？')
add(rr(224,9),rr(118,11,14),text='罗塞塔石碑发现前的数百年间，这些埃及文本对所有人都没有意义。发现石碑后，它们便能够被阅读。不可回避的结论是：数百年来，信息一直客观存在于文本中，存在于纸莎草纸上墨迹的空间配置中。1799年后，人们能够理解埃及文本，是因为文本客观地包含信息，即使其信息编码曾经无法破译。香农坚称，信息必须与其编码表示区分开来。',reason='保留作者对发现与解读时间的概括，不静默改写历史叙述。')
add(rr(224,10),rr(118,15,19),'quote',text='要定义实际信息这一概念，请考虑如下情形。假设一个信息源在产生譬如英文文本。文本可以翻译或编码为许多其他形式，例如摩尔斯电码，并且能够解码恢复原文。就大多数通信目的而言，这些形式同样有效，可以认为包含相同信息。给定任意一种编码形式，都能得到其他任何形式，尽管这当然可能需要复杂的计算。因此，我们将一个随机过程的实际信息，定义为所有能够通过可逆编码操作从原过程得到的随机过程所共有的东西。[[6]]',reason='保留完整香农引文；original指原随机过程，不擅改成原始信息。')
nt={4:'德国“Fish”编码系统用来加密博多码的随机数并非完全均匀，再加上德语字母频率不等，使第一台数字计算机Colossus能够破解这些编码消息：B. Jack Copeland，《Colossus：布莱切利园破译计算机的秘密》（Oxford University Press，2010）。香农在战时曾与图灵合作研究密码学：Andrew Hodges，《艾伦·图灵：谜》（Touchstone，1983）；图灵十分熟悉Colossus的进路。',5:'区别仅在于使用离散空间的求和，而非连续空间的积分。',6:'Claude Shannon：“信息的格论”，Transactions of the IRE Professional Group on Information Theory 1，第1期（1953）：105—107。'}
notes=[]
for n,refs in note_groups(rr(270,3)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch11-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['261'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch11b',11,rows,notes,rr(224,1,10))
(W/'checkpoint_ch11b.json').write_text(json.dumps({'next_source_pdf_page':225,'next_source_block':1,'next_supplied_pdf_page':118,'next_supplied_block':20,'next_unit':len(rows)+20,'next_note':7,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
