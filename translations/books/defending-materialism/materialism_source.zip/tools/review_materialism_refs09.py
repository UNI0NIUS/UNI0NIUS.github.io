from materialism_common import *
groups=[]
for b in EN[280]['blocks'][1:]:
    for j,l in enumerate(b['lines']):
        if b['block']>20 or (b['block']==20 and j>0):continue
        if l['bbox'][0]<60 or (b['block'],j)==(4,0):groups.append([])
        groups[-1].append([281,b['block'],j,j+1])
oldrefs=[rr(165,11,12),rr(165,13,14),rr(165,15),rr(165,16),rr(165,17),rr(165,18,19),rr(165,20),rr(165,21),rr(165,22),rr(165,23),rr(165,24),rr(165,25),rr(166,0,1),rr(166,2),rr(166,3,4),rr(166,5,6),rr(166,7,8),rr(166,9,10),rr(166,11,12),rr(166,13),rr(166,14),rr(166,15),rr(166,16,17),rr(166,18,19),rr(166,20),rr(166,21,22),rr(166,23,24)]
translations=[
'恩斯特·马赫：《能量守恒原理的历史与根源》。Open Court Publishing Company，1910。',
'恩斯特·马赫：《通俗科学讲演》，“物理研究的经济性质”章。Open Court，1898。',
'毛泽东：《矛盾论》。载《毛泽东选集》第1卷，1937。',
'J. Marenbon编：《剑桥波爱修斯指南》。Cambridge University Press，2009。',
'Andrey A. Markov Jr：《算法理论》。第42卷。Trudy Mat. Institua im. Steklova，1954。',
'Andrey A. Markov J、N. M. Nagorny：《算法理论》。M. Greendlinger译。Kluwer Academic，1988。',
'卡尔·马克思：《资本论》第1卷。Marxist Internet Archive在线版本。Progress Publishers，1954。',
'卡尔·马克思：《资本论》第1卷。S. Moore、E. Aveling译。Lawrence & Wishart，1970。',
'卡尔·马克思：《卡尔·马克思数学手稿》。New Park Publications，1983。',
'卡尔·马克思：“阿道夫·瓦格纳评注”。Texts on Method（1975）：201。',
'卡尔·马克思、弗里德里希·恩格斯：《马克思恩格斯全集》第40卷。Progress Publishers，1983。',
'卡尔·马克思、弗里德里希·恩格斯：《马克思恩格斯全集》第41卷。Progress Publishers，1985。',
'卡尔·马克思、弗里德里希·恩格斯：《1844年经济学哲学手稿与共产党宣言》。Prometheus Books，2009。',
'卡尔·马克思、弗里德里希·恩格斯：《德意志意识形态》。Progress Publishers，1976。',
'Karl Marx、Friedrich Engels、W. Lough：《关于费尔巴哈的提纲 路德维希·费尔巴哈和德国古典哲学的终结》。1845。',
'Karl Marx、Salomea W. Ryazanskaya、Maurice Dobb：《政治经济学批判》。Progress Publishers，1978。',
'Ladislav Matejka：“附录1：论俄国最早的符号学导论”。载《马克思主义与语言哲学》。Seminar Press，1986。',
'Adrian R. D. Mathias：“逻辑与恐怖”。Perne Club, Peterhouse College, University of Cambridge，1987。https://www.dpmms.cam.ac.uk/~ardm/stalin.pdf。',
'James Clerk Maxwell：“IV. 论气体的动力学理论”。Philosophical Transactions of the Royal Society of London，第157期（1867）：49—88。',
'James Clerk Maxwell：《热理论》。London，1875。',
'Scott Meikle：《亚里士多德的经济思想》。Oxford University Press，1997。',
'Charles Merivale：《帝国时期罗马人史》。Longmans，1851。',
'Greg Michaelson：“编程范式、图灵完备性与计算思维”。The Art, Science, and Engineering of Programming 4，第3期（2020）：第4篇。https://arxiv.org/abs/2002.06178。',
'George J. Milne、William P. Cockshott：《物理过程仿真的方法与装置》。美国专利5,485,599，1996。',
'Lewis H. Morgan：《古代社会》。Harvard University Press，2013。',
'Nikolai M. Nagorny：“安德里·马尔可夫与数学构造主义”。Logic, Methodology and Philosophy of Science IX（1994）：467—479。',
'John von Neumann：《量子力学的数学基础》。RT Beyer据1931年德文版译为英文。Princeton University Press，1955。'
]
assert len(groups)==len(oldrefs)==len(translations)==27
rows=[]
for i,(refs,zrefs,zh) in enumerate(zip(groups,oldrefs,translations),181):
    raw=extract(EN,refs,True);en=raw.replace('\u200b','')
    row={'id':f'dm-ref-{i:03}','kind':'bibliography','source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['272'],'en':en,'zh':zh,'supplied_zh':extract(ZH,zrefs),'status':'text_compared_layout_pending','revision_reason':'完整校对作者、题名、版本和出版信息；同名不同版本分别保留。'}
    if en!=raw:row['source_transcription_note']='去掉URL零宽字符，原始span保留。'
    if i==184:row['revision_reason']='原书缩进将Marenbon条目排在毛泽东条目之后，按独立书目恢复。'
    if i==186:row['editor_note']='原书本条写Markov J，前条写Markov Jr；分别照录。'
    if i==195:row['editor_note']='原书将两个题名连续排印，未加冒号；此处保留并列形式。'
    rows.append(row)
save('refs09',12,rows,[],rr(281,1,19)+[[281,20,0,1]])
(W/'checkpoint_refs09.json').write_text(json.dumps({'next_source_pdf_page':281,'next_source_block':20,'next_source_line':1,'next_supplied_pdf_page':166,'next_supplied_block':25,'next_reference':208,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
