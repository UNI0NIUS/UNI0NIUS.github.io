from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch09-{len(rows)+63:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(201,11)+rr(202,1),rr(105,33,34),text='也就是说，这一逻辑系统的真假取决于能否建立按类排列的具体“存在物”“关系”和“命题”，从中再抽象出更多的类。不过，霍尔丹怀疑是否可能建立这样的本体论：',reason='合并跨页句，拆出引文；further classes不擅加更高级。')
add(rr(202,2),rr(105,34,35)+rr(106,0),'quote',text='很可能，人们过分强调了某些逻辑系统；这些系统只适用于具有某些高度抽象性质的材料，而现实世界所体现的这些性质，远比逻辑学家愿意相信的更少见、更不完整。')
add(rr(202,3),rr(106,1,2),text='1939年，霍尔丹在《自然辩证法》英译本序言[[13]]中，谈及数学家声称已消除了恩格斯六十年前指出的数学矛盾时写道：',reason='旧译容易将恩格斯所指出的对象误认作消除矛盾，明确指数学矛盾。')
add(rr(202,4),rr(106,2,4),'quote',text='实际上，他们只是把矛盾推到了后台，矛盾仍然存在于数理逻辑领域。不仅从一组公理及其应用规则推导全部数学的每一次努力都失败了，而且哥德尔还证明，这些努力必定失败。')
add(rr(202,5),rr(106,5,6),text='这忽略了关键一点：哥德尔的结果虽然限定了能够证明什么，却没有告诉我们如何确立单个公式的性质。事实上，基于公理系统的自动化技术，正越来越多地适用于现实世界中的重要问题，例如数字计算机设计。')
add(rr(202,6),rr(106,7,8),text='与沃森一样，霍尔丹没有直接使用辩证唯物主义的语言。不过，与他评论哥德尔结果时一样，他暗示逻辑不足以把握具体现实，而这需要辩证法。')
add(rr(202,7),rr(106,9),'heading',text='孟什维克化的唯心主义之后的苏联逻辑学')
add(rr(202,8),rr(106,10,14),text='20世纪30年代以来苏联数学的命运已有广泛记述，尽管并非总是冷静客观的，例如武西尼奇、[[14]]洛伦兹、[[15]]塞内塔[[16]]和库塔特拉泽[[17]]的著作。马蒂亚斯那篇标题耸动的《逻辑与恐怖》[[18]]讨论了1950年以前的苏联逻辑学。阿内利斯[[19]]批评马蒂亚斯依赖菲利波夫[[20]]的“论战性且有偏见的叙述”。不过，马蒂亚斯仍引用了当时出版物中一些颇能说明问题的文字，虽然出处标注不充分：',reason='不把论文称一本书，保留作者对标题的评价；拆出引文。')
add(rr(202,9),rr(106,14,15),'quote',text='形式逻辑始终是占统治地位的剥削阶级手中最可靠的武器。是宗教和蒙昧主义的堡垒。（引自1934年一部关于辩证唯物主义和历史唯物主义的著作）',reason='保留底本分句及来源表述，不无据指定书名。')
add(rr(202,10),rr(106,16,17),'quote',text='形式逻辑的规律与辩证逻辑的规律相对立。形式逻辑是空洞、贫乏、抽象的，因为它所建立的规律和范畴不符合客观现实。（《简明哲学词典》，1940）（第7页）')
add(rr(203,1),rr(106,18),text='其中还包括1936年的《苏联大百科全书》（1936）：')
add(rr(203,2),rr(106,18,19),'quote',text='形式逻辑是一种形而上学的思维形式……是人类知识发展的最低阶段，被作为最高思维形式的辩证法所取代。')
add(rr(203,3),rr(106,20),'quote',text='正如我们所见，形式逻辑并非包含在辩证法中，而是被辩证法取代、驳斥和克服。')
add(rr(203,4),rr(106,20,22),'quote',text='……全联盟共产党（VKP(b)）内的反列宁主义偏向。形式逻辑思维是孟什维主义的一个特征，列宁曾经多次指出；他对孟什维克的三段论和诡辩的形式逻辑推演，进行了毁灭性的辩证批判。（第7页）')
add(rr(203,5),rr(106,23,25),text='虽然逻辑学的广泛研究受到限制，柯尔莫哥洛夫、亚诺夫斯卡娅等“红色专家”仍能研究和教授逻辑，并接触西方研究。例如，亚诺夫斯卡娅于1936年开始在莫斯科国立大学教授数理逻辑，1943年获任数理逻辑研讨班主任。[[21]]')
add(rr(203,6),rr(106,26,27),text='第二次世界大战后，逻辑学在苏联的地位得到恢复，尽管围绕它与辩证法的关系仍有持续的激烈争论，下文将予讨论。')
add(rr(203,7),rr(106,28),'heading',text='数字计算机')
add(rr(203,8),rr(106,29,30),text='数字计算机的发展很可能被证明是20世纪的关键进展。可以肯定，没有它们，21世纪初的生活几乎难以想象。计算机史同样已有详尽记述。这里将非常简要地关注其中几个突出方面。')
add(rr(203,9),rr(106,31,35),text='第二次世界大战造成空前的大规模残酷杀戮与贫困，也加速了现代计算机的发展。[[22]]哈佛Mark 1由霍华德·艾肯（1900—1973）于1937年设计，IBM以自动顺序控制计算器（ASCC）的名称建造，于1944年首次运行。它是机电式的，能存储数据，却不能存储程序。[[23]]指令编码在穿孔纸带上，控制线性排列的操作序列。循环程序靠重复纸带实现，分支靠更换纸带实现。约翰·冯·诺伊曼（1903—1957）曾用Mark 1为研制最初原子弹的曼哈顿计划进行计算。',reason='统一艾肯译名，原文atomic bombs复数不缩成第一颗。')
add(rr(203,10),rr(107,0,2),text='电子数字积分计算机（ENIAC）是最早的全电子通用计算机之一，于1945年完成。它比哈佛Mark 1快得多，通过将部件按适当配置插接起来进行编程。ENIAC的用途包括为最初的氢弹进行计算。',reason='保持氢弹复数含义，不缩成第一颗。')
nt={13:'J. B. S. Haldane：“序言”，载《自然辩证法》，苏联，1939，https://www.marxists.org/archive/marx/works/1883/don/preface.htm 。',14:'Vucinich：“苏联的数学与辩证法：斯大林以前的时期”。',15:'Lorentz：“1928至1953年苏联的数学与政治”。',16:'E. Seneta：“20世纪30年代苏联的数学、宗教与马克思主义”，Historia Mathematica 31（2004）：337—367。',17:'S. S. Kutateladze：“俄国数学的悲剧”，Siberian Electronic Mathematical Reports 9（2011）：A85—A100，https://arxiv.org/abs/math/0702632 。',18:'A. R. D. Mathias：“逻辑与恐怖”，剑桥大学彼得学院Perne Club，1987，https://www.dpmms.cam.ac.uk/~ardm/stalin.pdf 。',19:'I. H. Anellis：“苏联的形式逻辑与辩证唯物主义：评Fania Cavaliere《苏联的形式逻辑：1946—1965年的论争年代》及A. R. D. Mathias《逻辑与恐怖》”，Modern Logic 4，第2期（1994）：210—218，https://projecteuclid.org/journals/review-of-modern-logic/volume-4/issue-2/Formal-logic-and-dialecticalmaterialism-in-the-Soviet-Union/rml/1204835224.full 。',20:'A. Philipov：《苏联的逻辑与辩证法》（Research Program on the U.S.S.R，Varengian Press，1952）。',21:'D. Kilakos：“索菲娅·A. 亚诺夫斯卡娅：苏联数理逻辑的马克思主义先驱”，International Journal of the Historiography of Science 6（2019）：52。',22:'G. Dyson：《图灵的大教堂：数字宇宙的起源》（Penguin，2012）。',23:'程序存储器与数据存储器分离的设计，至今仍称为哈佛架构。'}
notes=[]
for p,b in [(267,3),(268,1)]:
    for n,refs in note_groups(rr(p,b)):
        if n not in nt:continue
        notes.append({'id':f'dm-ch09-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':[str(p-9)],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch09e',9,rows,notes,rr(201,11)+rr(202,1,10)+rr(203,1,10))
(W/'checkpoint_ch09e.json').write_text(json.dumps({'next_source_pdf_page':204,'next_source_block':1,'next_supplied_pdf_page':107,'next_supplied_block':3,'next_unit':len(rows)+63,'next_note':24,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
