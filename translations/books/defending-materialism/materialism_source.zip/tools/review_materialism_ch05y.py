from materialism_common import *
rows=[]
def add(en,zh,kind='paragraph',text=None,reason=None,start=None,end=None,english=None,fixes=()):
    old=extract(ZH,zh) if zh else '';s=old
    if start:s=s[s.index(start):]
    if end:s=s[:s.index(end)]
    if text is not None:s=text
    for a,b in fixes:
        assert a in s,a;s=s.replace(a,b)
    row={'id':f'dm-ch05-{len(rows)+309:03}','kind':kind,'source_blocks':en,'supplied_translation_blocks':zh,'printed_pages':list(dict.fromkeys(str(p-9) for p,b,*_ in en)),'en':english if english is not None else extract(EN,en,True),'supplied_zh':old,'zh':s,'status':'text_compared_layout_pending'}
    if reason:row['revision_reason']=reason
    if english is not None:row['source_transcription_note']='数学式依源PDF图像恢复；原始span保存于source_pages.json。'
    rows.append(row)
add(rr(123,1),rr(62,8,10))
add(rr(123,2),rr(62,11,15),end='在抽象动力学',fixes=[('加以批判。','加以批判。[[115]]')],reason='补旧译漏注115。')
add(rr(123,3),rr(62,15,17),'quote',start='在抽象动力学',fixes=[('当t 变为-t 时','当$t$变为$-t$时')])
add(rr(123,4),rr(62,18,22),'quote')
add(rr(123,5),rr(62,23,26))
rows[-1]['editor_note']='底本写closed systems（封闭系统）的熵不减；此处保留原措辞。该说法没有在此句中明示隔离条件，不将原书措辞静默改为isolated systems。'
add(rr(123,6)+rr(124,1),rr(62,27,29),fixes=[('源于生产实践需求。','源于生产实践需求。[[117]]')],reason='补回原注117。')
add(rr(124,2),rr(62,30))
add(rr(124,3),rr(62,31,33),fixes=[('左侧均匀受热，右侧均匀受冷','左侧温度均匀而较热，右侧温度均匀而较冷')],reason='结合随后整体绝热并趋于等温的过程，明确描述初始冷热状态而非持续两端加热冷却。')
add(rr(124,4),rr(62,34,35)+rr(63,0,1),fixes=[('带小孔半透膜','带小孔的可透过隔板')],reason='permeable barrier并未表示选择性半透膜。')
nt={115:'本书第3.3.3.0.1节。',116:'William Thomson：“能量耗散的动力学理论”（The Kinetic Theory of the Dissipation of Energy），Proceedings of the Royal Society of Edinburgh，第8卷（1875），第325—334页。',117:'相关论述参见Cardwell：《从瓦特到克劳修斯：工业时代早期热力学的兴起》。'}
notes=[]
for n,refs in note_groups(rr(257,1)):
    if n not in nt:continue
    notes.append({'id':f'dm-ch05-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'printed_pages':['248'],'en':extract(EN,refs,True),'zh':str(n)+'. '+nt[n],'status':'text_compared_layout_pending'})
save('ch05y',5,rows,notes,rr(123,1,6)+rr(124,1,4))
(W/'checkpoint_ch05y.json').write_text(json.dumps({'next_source_pdf_page':124,'next_source_block':5,'next_supplied_pdf_page':63,'next_supplied_block':2,'next_unit':len(rows)+309,'next_note':118,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
