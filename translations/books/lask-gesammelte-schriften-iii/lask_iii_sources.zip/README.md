# Gesammelte Schriften. III — reviewed reading editions

Emil Lask; edited by Eugen Herrigel. Tübingen: J. C. B. Mohr (Paul Siebeck), 1924.
Chinese translation and proofreading: Xiaoyang Hao, with AI assistance.

The reading editions include the original facsimile, front matter, original table
of contents, main text and review bibliography, printed pages 1–294. The combined
indexes of volumes I–III and publisher advertisement are outside this edition's
scope. The supplied source PDF is preserved for reference; handwriting is not
silently transcribed. Original typographical uncertainties are explained in
separate reading notes. See edition_supplements.json and the review evidence.

## Contents and maintenance

- work/translation/translation_units.jsonl: preserved Qoder draft.
- work/review/translation_units.jsonl: canonical bilingual reviewed text.
- work/review/revisions_*.json: changes and their reasons.
- work/review/ocr/: cached targeted OCR text/data and facsimile image.
- work/review/reading_groups.json: lossless reading groups and original notes.
- work/review/render_model.json: shared presentation model.
- output/reviewed/: three PDFs, two Markdown files, TeX and image assets, web JSON.
- MANIFEST.json: SHA-256 for each packaged file.

Edit canonical data first; review changes and update its acceptance hash before
regeneration. Do not rerun historical draft batch generators over the reviewed
data. The current frozen hash is enforced by the builders. Generation commands:

    python work/review/build_reading_groups.py
    python work/review/build_digital_editions.py
    python work/review/build_reading_editions.py --compile

Requires Python 3.10+, XeLaTeX (TeX Live), Times New Roman and SimSun. The PDF
read-back checker additionally requires PyMuPDF. Font substitution can change
pagination and must be reviewed. Existing TeX files compile from output/reviewed
using xelatex twice. The book's original page references remain distinct from
new PDF pagination. Markdown image paths are relative to its assets directory.

Web JSON targets the existing homepage bilingual reader. The web DOM checker
requires that website checkout and is supplied as validation evidence, not as
a standalone website. Browser visual checks complement structural checks.
