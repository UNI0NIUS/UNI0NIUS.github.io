"""Render the shared reviewed model; use --sample before the complete build."""
import json,collections,re,subprocess,sys,hashlib,shutil
from pathlib import Path
from render_model import make_model,splitlines,plain,U
R=Path(__file__).resolve().parent; B=R.parent.parent; O=B/'output/reviewed'
O.mkdir(parents=True,exist_ok=True)
MODEL=make_model()
TOC={x['id']:x for x in MODEL['toc']['entries'] if x['id']}
PRE=(R/'reading_preamble.tex').read_text(encoding='utf8')

def esc(s):
    return ''.join({'\\':r'\textbackslash{}','&':r'\&','%':r'\%','$':r'\$','#':r'\#','_':r'\_','{':r'\{','}':r'\}','~':r'\textasciitilde{}','^':r'\textasciicircum{}'}.get(c,c) for c in str(s))

SCOPE_ZH='本阅读版收录原书手稿影印、扉页及版权页、目录、正文和书评书目（原书第1—294页）；未收三卷合编的人名及主题索引、出版广告和数字化封面。页边“S.”标记为原书印刷页码，页底数字为本阅读版页码。目录页码指向本版相应章节；双语版的原页标沿中文栏定位。原注保留底本页内编号，置于各小节末；中文原注附德文原文。校读说明另列，并与原注区分。手稿影印按原图保留，未另行猜写转录。'
SCOPE_DE='Diese Leseausgabe enthält das Faksimile, Titel- und Copyrightseite, Inhaltsverzeichnis, Haupttext und Rezensionsbibliographie (Originalseiten 1–294). Die gemeinsamen Namen- und Sachregister der drei Bände, die Verlagsanzeige und das Digitalisierungsdeckblatt sind nicht enthalten. Die Randangaben „S.“ bezeichnen Originalseiten, die Fußzahlen Seiten dieser Ausgabe. Das Inhaltsverzeichnis verweist auf die Kapitel dieser Ausgabe. In der Parallelausgabe folgen die Originalseitenmarken der chinesischen Spalte. Originalanmerkungen stehen mit ihren ursprünglichen seitenweisen Nummern am Ende des jeweiligen Abschnitts; Lesarthinweise sind gesondert ausgewiesen. Das Faksimile wird ohne zusätzliche Transkription wiedergegeben.'

def walk(blocks):
    for b in blocks:
        if b['kind']=='brace':yield from walk(b['children'])
        else:yield b

def select_sample():
    ranges=[(4,15),(128,132),(176,186),(200,201),(217,218),(280,281),(300,308),(459,489),(853,854),(964,965),(1103,1104),(1236,1240)]
    def picked(b):return any(any(lo<=U[c]['order']<=hi for lo,hi in ranges) for z in walk([b]) for c in z['components'])
    blocks=[b for b in MODEL['blocks'] if picked(b)]
    refs={t['id'] for b in walk(blocks) for lang in ['zh','de'] for t in b[lang] if t['type']=='note_ref'}
    while True:
        more={t['id'] for n in MODEL['notes'] if n['id'] in refs for lang in ['zh','de'] for t in n[lang] if t['type']=='note_ref'}
        if more<=refs:break
        refs|=more
    return blocks,[n for n in MODEL['notes'] if n['id'] in refs]

class Renderer:
    def __init__(self,mode,blocks,notes,sample=False):
        self.mode=mode;self.bi=mode=='bilingual';self.blocks=blocks;self.notes=notes;self.sample=sample;self.opened=False;self.out=[]
    def tokens(self,ts,lang,pages=True,anchors=True):
        out=[]
        for t in ts:
            k=t['type']
            if k=='text':out.append(esc(t['text']))
            elif k=='break':out.append(r'\par ')
            elif k=='linebreak':out.append(r'\newline ')
            elif k=='page':
                if pages and not(self.bi and lang=='de'):out.append(r'\sourcepage{'+esc(t['page'])+'}')
            elif k=='anchor':
                if anchors:out.append(r'\hypertarget{'+t['id']+'}{}')
            elif k=='note_ref':
                nid=t['id'];label=t['label'] or ('编者说明' if lang=='zh' else 'Hrsg.')
                prefix=r'\hypertarget{ref-'+lang+'-'+nid+'}{}' if anchors else ''
                out.append(prefix+r'\hyperlink{note-'+nid+r'}{\textsuperscript{'+esc(label)+'}}')
            else:raise ValueError(t)
        return ''.join(out)
    def close(self):
        if self.opened:self.out.append(r'\end{paracol}');self.opened=False
    def pair(self,zh,de):
        if self.bi:
            if not self.opened:self.out.append(r'\begin{paracol}{2}');self.opened=True
            self.out.extend([zh+r'\par',r'\switchcolumn',de+r'\par',r'\switchcolumn*'])
        else:self.out.append((zh if self.mode=='zh' else de)+r'\par')
    def block(self,b,lang,boxed=False):
        if b['kind']=='brace':
            children=b['children'];marks=[t for c in children for t in c[lang] if t['type']=='page']
            content='\n'.join(self.block(c,lang,True)+r'\par' for c in children)
            # A measured brace scales to the actual content height; the label wraps.
            return self.tokens(marks,lang)+r'\begingroup\setlength{\parskip}{3pt}\noindent\setbox0=\vbox{\hsize=.65\linewidth '+content+r'}\setlength{\outlineheight}{\dimexpr\ht0+\dp0\relax}\hbox to\linewidth{\vcentered{\box0}\hspace{.01\linewidth}\vcentered{\resizebox{.025\linewidth}{\outlineheight}{\(\}\)}}\hfill\vcentered{\begin{minipage}{.27\linewidth}\raggedright '+esc(b['label_'+lang])+r'\end{minipage}}}\par\endgroup'
        ts=b[lang];prefix=''
        if b['meta'].get('section_break_before'):prefix=r'\smallskip\noindent\rule{.18\linewidth}{.3pt}\par '
        if b.get('line_levels') is not None:
            return prefix+r'\begingroup\setlength{\parskip}{2pt}'+''.join(r'\noindent\hangindent='+str(.9*level)+r'em\hspace*{'+str(.9*level)+r'em}'+self.tokens(line,lang,not boxed)+r'\par ' for level,line in zip(b['line_levels'],splitlines(ts)))+r'\endgroup'
        value=self.tokens(ts,lang,not boxed)
        if b['meta'].get('quotation_group'):value=r'\begingroup\leftskip=1em\rightskip=1em\noindent '+value+r'\par\endgroup'
        return prefix+value
    def endnotes(self,section):
        self.close()
        for editorial in [False,True]:
            ns=[n for n in self.notes if n['section']==section and n['editorial']==editorial]
            if not ns:continue
            title=('校读说明 / Hinweise zur Lesart' if editorial else '原注 / Anmerkungen')
            self.out.append(r'\needspace{6\baselineskip}\subsection*{'+title+'}')
            for n in ns:
                rendered={};nid=n['id'];page='–'.join(n['printed_pages']);label=n['label'] or ('校读' if editorial else '编者说明')
                for lang in ['zh','de']:
                    mark=label if lang=='zh' or n['label'] else ('Lesart' if editorial else 'Hrsg.')
                    target=r'\hypertarget{note-'+nid+'}{}' if lang==('de' if self.mode=='de' else 'zh') else ''
                    rendered[lang]=target+r'{\small [S. '+esc(page)+'] '+r'\textsuperscript{'+esc(mark)+'} '+self.tokens(n[lang],lang,False)+r'~\hyperlink{ref-'+lang+'-'+nid+r'}{\textsuperscript{↑}}}'
                if self.mode=='zh' and not editorial:rendered['zh']+=r'\par{\small 原文：'+self.tokens(n['de'],'de',False,False)+'}'
                self.pair(rendered['zh'],rendered['de'])
            self.close()
    def heading(self,b):
        self.close();level=b['meta'].get('level',3)
        if level==0:self.out.append(r'\clearpage')
        self.out.append(r'\needspace{7\baselineskip}')
        # Anchors, notes and margin marks stay outside heading arguments.
        for lang in (['zh','de'] if self.bi else [self.mode]):
            self.out.append(self.tokens([t for t in b[lang] if t['type']=='anchor'],lang))
        parts=b['meta'].get('heading_parts') or [{'level':level,'zh':plain(b['zh']),'de':plain(b['de'])}]
        for part in parts:
            cmd=['section','subsection','subsubsection','paragraph','subparagraph'][min(part['level'],4)]
            value=esc(part['de'] if self.mode=='de' else part['zh'])
            if self.bi:value+=r'\\{\normalsize '+esc(part['de'])+'}'
            self.out.append('\\'+cmd+'*{'+value+'}')
        if b['id'] in TOC:
            e=TOC[b['id']];cmd=['section','subsection','subsubsection','paragraph','subparagraph'][min(e['level'],4)]
            title=e['title_de'] if self.mode=='de' else e['title_zh']
            if self.bi:title+=' / '+e['title_de']
            self.out.append(r'\addcontentsline{toc}{'+cmd+'}{'+esc(title)+'}')
        for lang in (['zh','de'] if self.bi else [self.mode]):
            self.out.append(self.tokens([t for t in b[lang] if t['type'] in ['page','note_ref']],lang))
    def render(self):
        geometry=('a4paper,inner=20mm,outer=23mm,top=21mm,bottom=23mm' if self.bi or self.mode=='de' else 'a4paper,margin=25mm')+',marginparwidth=16mm,marginparsep=3mm'
        pre=PRE.replace('SIZE','10pt' if self.bi or self.mode=='de' else '11pt').replace('GEOMETRY',geometry)
        pre=pre.replace(r'\begin{document}',r'\newlength{\outlineheight}\newcommand{\vcentered}[1]{\raisebox{-.5\height}{#1}}'+'\n'+r'\begin{document}')
        self.out=[pre,r'\begin{titlepage}\centering\vspace*{25mm}{\Huge 拉斯克文集：第三卷\par}\bigskip{\Large Gesammelte Schriften III\par}\vspace{15mm}{\Large 埃米尔·拉斯克 / Emil Lask\par}\bigskip 欧根·赫里格尔 编 / Herausgegeben von Eugen Herrigel\par\vfill',esc({'zh':'中文校订版','de':'Deutsche Leseausgabe','bilingual':'中德逐段对照版'}[self.mode]),r'\par\bigskip 1924 · Tübingen · J. C. B. Mohr (Paul Siebeck)\par\end{titlepage}']
        if self.sample:self.out.append(r'\noindent 排版验证样本 / Satzprobe\par')
        self.pair(esc(SCOPE_ZH),esc(SCOPE_DE));self.close();self.out.append(r'\clearpage')
        f=MODEL['supplements']['facsimile'];(O/'assets').mkdir(exist_ok=True);shutil.copyfile(R/f['image'],O/'assets/facsimile.png');image='assets/facsimile.png'
        self.out.append(r'\begin{center}\includegraphics[width=.94\textwidth,height=.78\textheight,keepaspectratio]{'+image+r'}\end{center}')
        self.pair(esc(f['caption_zh']),esc(f['caption_de']));self.close();self.out.append(r'\clearpage')
        fronts=[b for b in self.blocks if b['section']=='front-matter']
        for b in fronts:self.pair(self.block(b,'zh'),self.block(b,'de'))
        self.close();self.out.append(r'\clearpage\tableofcontents')
        self.pair('原目录另列人名索引（原书第295页）与主题索引（原书第299页）；本阅读版未收。','Das Originalverzeichnis nennt außerdem Namenregister (S. 295) und Sachregister (S. 299); beide sind hier nicht enthalten.')
        self.close();section=None
        for b in self.blocks:
            if b['section']=='front-matter':continue
            if section is not None and section!=b['section']:self.endnotes(section)
            section=b['section']
            if b['kind']=='heading':self.heading(b)
            else:self.pair(self.block(b,'zh'),self.block(b,'de'))
        if section:self.endnotes(section)
        self.close();self.out.append(r'\end{document}')
        return '\n'.join(self.out)+'\n'

def main():
    sample='--sample' in sys.argv
    blocks,notes=select_sample() if sample else (MODEL['blocks'],MODEL['notes'])
    modes=['zh','de','bilingual']
    if '--mode' in sys.argv:modes=[sys.argv[sys.argv.index('--mode')+1]]
    for mode in modes:
        stem='lask_iii_'+mode+('_sample' if sample else '')
        (O/(stem+'.tex')).write_text(Renderer(mode,blocks,notes,sample).render(),encoding='utf8')
        if '--compile' in sys.argv:
            for i in [1,2]:
                p=subprocess.run([shutil.which('xelatex') or 'C:/texlive/2025/bin/windows/xelatex.exe','-interaction=nonstopmode','-halt-on-error',stem+'.tex'],cwd=O,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
                (R/(stem+f'_compile_{i}.log')).write_bytes(p.stdout)
                if p.returncode:print(p.stdout.decode('utf8',errors='replace')[-2200:]);raise SystemExit(p.returncode)
        print(mode, 'sample' if sample else 'full',len(blocks),'blocks',len(notes),'notes',flush=True)
    (R/('sample_build_manifest.json' if sample else 'edition_build_manifest.json')).write_text(json.dumps({'canonical_sha256':MODEL['canonical_sha256'],'modes':modes,'blocks':len(blocks),'notes':len(notes),'status':'compiled_pending_visual_acceptance' if '--compile' in sys.argv else 'tex_generated'},ensure_ascii=False,indent=2)+'\n',encoding='utf8')

if __name__=='__main__':main()
