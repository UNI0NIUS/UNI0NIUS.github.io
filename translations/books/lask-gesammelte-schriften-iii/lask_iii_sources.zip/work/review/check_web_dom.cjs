'use strict';
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');
const R=__dirname,root=path.resolve(R,'../../../..'),site=path.join(root,'homepage-union');
class Node {
 constructor(tag,text=''){this.tag=tag;this.text=text;this.children=[];this.attrs={};this.dataset={};this.style={};this.classList={add:()=>{}};}
 append(...xs){this.children.push(...xs.map(x=>typeof x==='string'?new Node('#text',x):x));}
 setAttribute(k,v){this.attrs[k]=v;}
 get textContent(){return this.text+this.children.map(x=>x.textContent).join('');}
}
const el=(tag,text,cls)=>{let n=new Node(tag,text||'');n.className=cls||'';return n;};
const ctx={window:{},document:{createTextNode:t=>new Node('#text',t),createElement:t=>new Node(t),createElementNS:(_,t)=>new Node(t)},el,safeUrl:u=>u};
vm.createContext(ctx);vm.runInContext(fs.readFileSync(path.join(site,'bilingual-reader.js'),'utf8'),ctx);
function all(n){return [n,...n.children.flatMap(all)];}
const norm=s=>s.normalize('NFKC').replace(/[^\p{L}\p{N}]/gu,'').toLowerCase();
function strings(ts){if(typeof ts==='string')return [ts];return (ts||[]).flatMap(t=>typeof t==='string'?[t]:[...strings(t.children),...strings(t.label),...(t.rows||[]).flatMap(row=>row.flatMap(strings))]);}
const files=fs.readdirSync(path.resolve(R,'../../output/reviewed/webdata')).filter(n=>n.endsWith('.json')&&n!=='book-metadata.json');
let cases=0,links=0,fragments=0;
for(const file of files){
 const chapter=JSON.parse(fs.readFileSync(path.resolve(R,'../../output/reviewed/webdata',file),'utf8'));
 for(const mode of ['zh','en','parallel']){
  const tree=ctx.window.renderParallelBook.content(chapter,mode),nodes=all(tree),ids=nodes.map(n=>n.id).filter(Boolean),set=new Set(ids);assert.equal(ids.length,set.size,`${file} ${mode}: duplicate ID`);
  for(const n of nodes){if(n.href?.startsWith('#')){assert(set.has(n.href.slice(1)),`${file} ${mode}: broken ${n.href}`);links++;}}
  const text=norm(tree.textContent);
  for(const lang of mode==='parallel'?['zh','en']:[mode]){
   for(const row of chapter.body)for(const s of strings(row[lang])){assert(text.includes(norm(s)),`${file} ${mode}: missing body text ${s.slice(0,50)}`);fragments++;}
   for(const [id,note] of Object.entries(chapter.notes)){
    assert(set.has(`note-${lang}-${id}`),`${file} ${mode}: undisplayed ${id}`);
    for(const s of strings(note[lang])){assert(text.includes(norm(s)),`${file} ${mode}: missing note ${id}`);fragments++;}
   }
  }
  cases++;
 }
}
// Existing first-volume content must still render its ordinary notes unchanged.
const oldDir=path.join(site,'translations/books/lask-gesammelte-schriften-i');
let regressions=0;
for(const name of ['platon.json','fichte-einleitung.json','geleitwort.json']){
 const f=path.join(oldDir,name);if(!fs.existsSync(f))continue;const c=JSON.parse(fs.readFileSync(f,'utf8'));const tree=ctx.window.renderParallelBook.content(c,'parallel');assert(tree.children.length>1);regressions++;
}
fs.writeFileSync(path.join(R,'web_dom_check.json'),JSON.stringify({status:'passed',chapters:files.length,cases,links,text_fragments:fragments,existing_book_regressions:regressions,limitations:'DOM rendering checks do not replace browser visual checks.'},null,2)+'\n');
console.log(JSON.stringify({cases,links,fragments,regressions}));
