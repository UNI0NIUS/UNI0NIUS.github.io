"""Read back actual PDF text, anchors and links; report bounded discrepancies."""
import json,re,unicodedata,collections,hashlib
from pathlib import Path
import pymupdf
from render_model import make_model
R=Path(__file__).resolve().parent;O=R.parent.parent/'output/reviewed';M=make_model()
def walk(bs):
    for b in bs:
        if b['kind']=='brace':yield from walk(b['children'])
        else:yield b
def norm(s):return ''.join(c for c in unicodedata.normalize('NFKC',s) if c.isalnum()).lower()
report={'canonical_sha256':M['canonical_sha256'],'normalization':'NFKC, lowercase, alphanumeric only; omit headers/footers, marginal page labels and superscript reference marks; inspect every text run independently','pdfs':{}}
for mode in ['zh','de','bilingual']:
    f=O/f'lask_iii_{mode}.pdf';doc=pymupdf.open(f);dest=doc.resolve_names();langs=['zh','de'] if mode=='bilingual' else [mode]
    streams={l:[] for l in langs};raw=[]
    for page in doc:
        raw.append(page.get_text())
        for block in page.get_text('dict')['blocks']:
            for line in block.get('lines',[]):
                for span in line['spans']:
                    x0,y0,x1,y1=span['bbox']
                    if y0<48 or y1>800 or span['size']<8.4:continue
                    if mode=='bilingual':lang='zh' if (x0+x1)/2<page.rect.width/2 else 'de'
                    else:lang=mode
                    streams[lang].append(span['text'])
    streams={k:norm(''.join(v)) for k,v in streams.items()};alltext=norm(''.join(raw));fail=[];checked=0;anchors=[]
    for b in list(walk(M['blocks']))+M['notes']:
        for lang in langs:
            for t in b[lang]:
                if t['type']=='anchor':anchors.append(t['id'])
                if t['type']!='text':continue
                if b.get('meta',{}).get('heading_parts'):
                    for part in b['meta']['heading_parts']:
                        s=norm(part[lang]);checked+=1
                        if s not in streams[lang] and s not in alltext:fail.append({'id':b['id'],'lang':lang,'length':len(s),'text':part[lang]})
                    continue
                s=norm(t['text'])
                if not s:continue
                checked+=1
                if s not in streams[lang] and s not in alltext:
                    fail.append({'id':b['id'],'lang':lang,'length':len(s),'text':t['text']})
    links=[l for page in doc for l in page.get_links()];badlinks=[l for l in links if l.get('kind')==pymupdf.LINK_GOTO and not 0<=l.get('page',-1)<len(doc)]
    missinganchors=sorted(set(anchors)-dest.keys())
    warnings=re.findall(r'Missing character:[^\n]+|Overfull[^\n]+',f.with_suffix('.log').read_text(encoding='utf8',errors='replace'))
    v={'pages':len(doc),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'text_runs_checked':checked,'discrepancies':fail,'missing_anchors':missinganchors,'links':len(links),'bad_links':badlinks,'layout_warnings':warnings}
    report['pdfs'][mode]=v
    print(mode,len(doc),'runs',checked,'discrepancies',len(fail),'missinganchors',len(missinganchors),'badlinks',len(badlinks),'warnings',len(warnings))
    for e in fail[:6]:print(e['id'],e['lang'],e['length'],repr(e['text'][:90]))
(R/'pdf_text_readback.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
