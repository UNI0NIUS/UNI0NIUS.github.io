"""One lossless reading representation for PDFs, Markdown and the existing website."""
import json,hashlib,re,collections
from pathlib import Path
R=Path(__file__).resolve().parent
raw=(R/'translation_units.jsonl').read_bytes();sha=hashlib.sha256(raw).hexdigest()
U=[json.loads(s) for s in raw.decode('utf-8').splitlines()];by={u['id']:u for u in U}
audit=json.loads((R/'consolidated_review_check.json').read_text(encoding='utf-8'))
assert audit['canonical_sha256']==sha and audit['status']=='canonical_text_review_passed_output_acceptance_pending'
meta_keys=['level','parent_heading_id','original_toc_level','in_original_toc','include_in_original_toc','heading_parts','outline_group','outline_level','outline_line_levels','brace_group','brace_label_de','brace_label_zh','brace_label_source_unit_id','brace_end_line','section_break_before','quotation_group','original_editor_notice','editorial_notes']
unnumbered=collections.defaultdict(list)
for u in U:
    if u.get('note_placement')=='unnumbered_page_note':unnumbered[u['anchor_unit_id']].append(u)
def note_runs(u,lang):
    s=u.get('translation','') if lang=='zh' else u.get('heading_de',u.get('source_text',''))
    spans=[]
    for nid in u.get('note_refs',[]):
        n=by[nid];num=str(n['original_note_number']);occ=n.get('anchor_marker_occurrence',1)
        matches=list(re.finditer(r'(?<!\d)'+re.escape(num)+r'[)）]',s));assert len(matches)>=occ,(u['id'],lang,nid)
        m=matches[occ-1];spans.append((m.start(),m.end(),n))
    spans.sort(key=lambda x:x[0]);out=[];pos=0
    for start,end,n in spans:
        assert start>=pos,(u['id'],lang,'overlapping_note_markers')
        if start>pos:out.append({'type':'text','text':s[pos:start]})
        out.append({'type':'note_ref','note_id':n['id'],'original_number':str(n['original_note_number']),'original_marker_text':s[start:end]});pos=end
    if pos<len(s):out.append({'type':'text','text':s[pos:]})
    for n in unnumbered.get(u['id'],[]):out.append({'type':'note_ref','note_id':n['id'],'original_number':None,'label':'编者说明' if lang=='zh' else 'Hrsg.','unnumbered':True,'original_marker_text':''})
    rebuilt=''.join(v['text'] if v['type']=='text' else v['original_marker_text'] for v in out)
    assert rebuilt==s
    return out
def component(u,first=False):
    return {'unit_id':u['id'],'order':u['order'],'printed_pages':u['printed_pages'],'source_refs':u['source_refs'],'page_start':u['printed_pages'][0] if u['printed_pages'] else None,'join_separator_de':u.get('join_separator',' ') if not first else '', 'join_separator_zh':'','de_runs':note_runs(u,'de'),'zh_runs':note_runs(u,'zh'),'meta':{k:u[k] for k in meta_keys if k in u}}
groups=[];notes=[];excluded=[];components=[]
for u in U:
    if u['kind']=='blank' or u['id']=='front-toc':
        excluded.append({'id':u['id'],'reason':u.get('excluded_source_reason','original_toc_generated_from_structure' if u['id']=='front-toc' else 'source_blank_or_classified_nonbody'),'source_refs':u['source_refs']});continue
    if u['kind']=='note':
        if u.get('note_continuation_of'):continue
        ns=[u]+[by[nid] for nid in u.get('continuation_ids',[])]
        for n in ns[1:]:assert n.get('note_continuation_of')==u['id']
        notes.append({'id':u['id'],'body_unit_id':u['anchor_unit_id'],'section':by[u['anchor_unit_id']]['section'],'original_number':str(u['original_note_number']) if 'original_note_number' in u else None,'unnumbered':u.get('note_placement')=='unnumbered_page_note','components':[component(n,i==0) for i,n in enumerate(ns)]})
        continue
    c=component(u,not u.get('join_previous'));components.append(u['id'])
    if u.get('join_previous'):
        assert groups and u.get('reading_group')==groups[-1].get('reading_group'),u['id']
        groups[-1]['components'].append(c)
    else:groups.append({'id':u['id'],'kind':u['kind'],'section':u['section'],'reading_group':u.get('reading_group'),'meta':c['meta'],'components':[c]})
allids=components+[c['unit_id'] for n in notes for c in n['components']]+[e['id'] for e in excluded]
assert len(allids)==len(set(allids))==len(U)
refs={lang:collections.Counter(v['note_id'] for g in groups for c in g['components'] for v in c[lang+'_runs'] if v['type']=='note_ref') for lang in ['zh','de']}
for lang in refs:assert set(refs[lang])=={n['id'] for n in notes} and set(refs[lang].values())=={1}
def plain(cs,lang):
    return ''.join((c['join_separator_'+lang] if i else '')+''.join(v['text'] if v['type']=='text' else v['original_marker_text'] for v in c[lang+'_runs']) for i,c in enumerate(cs))
special={}
for g in groups:
    if len(g['components'])>1:special[g['id']]={'components':[c['unit_id'] for c in g['components']],'source_page_markers_de':re.findall(r'⟦p\.[^⟧]+⟧',plain(g['components'],'de')),'source_page_markers_zh':re.findall(r'⟦p\.[^⟧]+⟧',plain(g['components'],'zh'))}
out={'canonical_sha256':sha,'groups':groups,'notes':notes,'excluded':excluded,'toc':json.loads((R/'original_toc.json').read_text(encoding='utf-8')),'supplements':json.loads((R/'edition_supplements.json').read_text(encoding='utf-8'))}
(R/'reading_groups.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
check={'canonical_sha256':sha,'groups':len(groups),'body_components':len(components),'notes':len(notes),'note_components':sum(len(n['components']) for n in notes),'excluded_or_generated_structural_units':len(excluded),'all_unit_ids_accounted_once':True,'unique_note_references_per_language':len(refs['de']),'unnumbered_notes':[n['id'] for n in notes if n['unnumbered']],'continuations':special,'status':'lossless_common_reading_data_validated_rendering_pending'}
(R/'reading_groups_check.json').write_text(json.dumps(check,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in check.items() if k!='continuations'},ensure_ascii=False))
