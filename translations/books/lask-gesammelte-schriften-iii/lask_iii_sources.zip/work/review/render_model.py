"""Shared presentation model. Reading order, note links and outline grouping are format-neutral."""
import json,re,hashlib,copy
from pathlib import Path
from reader_notes import NOTES
R=Path(__file__).resolve().parent;B=R.parent.parent;O=B/'output/reviewed'
D=json.loads((R/'reading_groups.json').read_text(encoding='utf-8'))
assert D['canonical_sha256']==hashlib.sha256((R/'translation_units.jsonl').read_bytes()).hexdigest()
U={u['id']:u for u in map(json.loads,(R/'translation_units.jsonl').read_text(encoding='utf-8').splitlines())}
def tokenize(s):
    return [{'type':'page','page':p[3:-1]} if p.startswith('⟦p.') else {'type':'break'} if p=='\n\n' else {'type':'linebreak'} if p=='\n' else {'type':'text','text':p} for p in re.split(r'(⟦p\.[^⟧]+⟧|\n\n|\n)',s) if p]
def component_tokens(c,lang,state=None,editorial=True):
    result=[{'type':'anchor','id':lang+'-'+c['unit_id']}]
    page=c['page_start'];runs=c[lang+'_runs'];firsttext=next((r['text'] for r in runs if r['type']=='text'),'')
    if state is not None and page and state.get(lang)!=page and not firsttext.startswith('⟦p.'+page+'⟧'):
        result.append({'type':'page','page':page});state[lang]=page
    for r in runs:
        if r['type']=='text':result+=tokenize(r['text'])
        else:result.append({'type':'note_ref','id':r['note_id'],'label':r.get('label',r.get('original_number')),'original_number':r.get('original_number'),'unnumbered':r.get('unnumbered',False)})
    if state is not None:
        marks=[t['page'] for t in result if t['type']=='page']
        if marks:state[lang]=marks[-1]
    if editorial and c['order'] in NOTES:result.append({'type':'note_ref','id':'reading-note-'+c['unit_id'],'label':'校读' if lang=='zh' else 'Lesart','editorial':True})
    return result
def combined(cs,lang,state=None,editorial=True):
    out=[]
    for i,c in enumerate(cs):
        if i and c['join_separator_'+lang]:out.append({'type':'text','text':c['join_separator_'+lang]})
        out+=component_tokens(c,lang,state,editorial)
    return out
def splitlines(tokens):
    lines=[[]]
    for t in tokens:
        if t['type']=='linebreak':lines.append([])
        else:lines[-1].append(t)
    return lines
def plain(tokens,refs=False,pages=False):
    return ''.join(t['text'] if t['type']=='text' else '\n\n' if t['type']=='break' else '\n' if t['type']=='linebreak' else '⟦p.'+t['page']+'⟧' if t['type']=='page' and pages else t['label'] if t['type']=='note_ref' and refs else '' for t in tokens)
def make_model():
    state={};blocks=[];notes=[]
    for g in D['groups']:
        m=copy.deepcopy(g['meta']);b={'id':g['id'],'kind':g['kind'],'section':g['section'],'meta':m,'components':[c['unit_id'] for c in g['components']]}
        for lang in ['zh','de']:b[lang]=combined(g['components'],lang,state)
        if m.get('outline_group'):
            levels=[]
            for i,c in enumerate(g['components']):
                ls=c['meta'].get('outline_line_levels',[c['meta'].get('outline_level',0)])
                levels+=ls if i==0 else ls[1:]
            for lang in ['zh','de']:
                ls=splitlines(b[lang]);assert len(ls)==len(levels),(g['id'],lang,len(ls),levels)
            b['line_levels']=levels
        if any('brace_end_line' in c['meta'] for c in g['components']):b['brace_end_line']=next(c['meta']['brace_end_line'] for c in g['components'] if 'brace_end_line' in c['meta'])
        blocks.append(b)
    for n in D['notes']:
        note={'id':n['id'],'section':n['section'],'body_unit_id':n['body_unit_id'],'label':n['original_number'],'unnumbered':n['unnumbered'],'editorial':False,'printed_pages':list(dict.fromkeys(p for c in n['components'] for p in c['printed_pages'])),'components':[c['unit_id'] for c in n['components']]}
        for lang in ['zh','de']:note[lang]=combined(n['components'],lang,None,True)
        notes.append(note)
    for g in D['groups']+D['notes']:
        for c in g['components']:
            if c['order'] not in NOTES:continue
            z,d=NOTES[c['order']];notes.append({'id':'reading-note-'+c['unit_id'],'section':g['section'],'body_unit_id':c['unit_id'],'label':None,'unnumbered':True,'editorial':True,'printed_pages':c['printed_pages'],'components':[],'zh':tokenize(z),'de':tokenize(d)})
    notes.sort(key=lambda n: U[n['body_unit_id']]['order'])
    # Group right-brace outlines; the tail of477 lies outside its brace.
    grouped=[];i=0
    while i<len(blocks):
        b=blocks[i];key=b['meta'].get('brace_group')
        if not key:grouped.append(b);i+=1;continue
        children=[];tail=None;label=(b['meta'].get('brace_label_zh'),b['meta'].get('brace_label_de'))
        while i<len(blocks) and blocks[i]['meta'].get('brace_group')==key:
            child=copy.deepcopy(blocks[i]);i+=1
            if 'brace_end_line' in child:
                end=child['brace_end_line'];tail=copy.deepcopy(child);tail['id']+='-after-brace';tail['components']=[]
                for lang in ['zh','de']:
                    lines=splitlines(child[lang]);child[lang]=sum(([{'type':'linebreak'}]+x if j else x for j,x in enumerate(lines[:end+1])),[]);tail[lang]=sum(([{'type':'linebreak'}]+x if j else x for j,x in enumerate(lines[end+1:])),[])
                child['line_levels']=child['line_levels'][:end+1];tail['line_levels']=tail['line_levels'][end+1:];tail['meta'].pop('brace_group',None)
            children.append(child)
        assert all(label),key
        grouped.append({'id':key,'kind':'brace','section':b['section'],'meta':{},'children':children,'label_zh':label[0],'label_de':label[1]})
        if tail:grouped.append(tail)
    return {'canonical_sha256':D['canonical_sha256'],'blocks':grouped,'notes':notes,'toc':D['toc'],'supplements':D['supplements']}
if __name__=='__main__':
    m=make_model();(R/'render_model.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'blocks':len(m['blocks']),'original_notes':sum(not n['editorial'] for n in m['notes']),'reader_notes':sum(n['editorial'] for n in m['notes']),'braces':sum(b['kind']=='brace' for b in m['blocks'])}))
