"""Markdown and site JSON from the same model used by the PDFs."""
import json,html,collections,shutil,re,hashlib
from pathlib import Path
from render_model import make_model,splitlines,plain,U
from build_reading_editions import SCOPE_ZH,SCOPE_DE
R=Path(__file__).resolve().parent;O=R.parent.parent/'output/reviewed';W=O/'webdata';W.mkdir(parents=True,exist_ok=True)
M=make_model();BASE='translations/books/lask-gesammelte-schriften-iii/'
NOTES={n['id']:n for n in M['notes']}
ASSETS=O/'assets';ASSETS.mkdir(exist_ok=True)
shutil.copyfile(R/M['supplements']['facsimile']['image'],ASSETS/'facsimile.png')
(ASSETS/'brace.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 12 100" preserveAspectRatio="none"><path d="M1 1 C10 1 2 49 11 50 C2 51 10 99 1 99" fill="none" stroke="currentColor" stroke-width="1" vector-effect="non-scaling-stroke"/></svg>',encoding='utf8')

def web_tokens(ts,lang,uid,copy=False):
    out=[];key='en' if lang=='de' else 'zh'
    for i,t in enumerate(ts):
        k=t['type']
        if k=='text':out.append(t['text'])
        elif k=='anchor':
            if not copy:out.append({'type':'anchor','id':t['id'].replace('de-','en-',1) if lang=='de' else t['id']})
        elif k=='page':out.append({'type':'page','page':t['page'],'id':key+'-'+uid+'-p'+str(i)})
        elif k=='note_ref':
            if not copy:out.append({'type':'note','id':t['id'],'label':t['label'] or ('编者说明' if lang=='zh' else 'Hrsg.')})
        else:out.append({'type':k})
    return out

def web_block(b,lang):
    if b['kind']=='brace':return [{'type':'brace','children':sum((web_block(c,lang) for c in b['children']),[]),'label':[b['label_'+lang]]}]
    ts=b[lang];out=[]
    if b['meta'].get('section_break_before'):out.append({'type':'block','kind':'section-break','children':['—']})
    if b.get('line_levels') is not None:
        return out+[{'type':'block','kind':'outline-line','level':level,'children':web_tokens(line,lang,b['id']+'-l'+str(i))} for i,(line,level) in enumerate(zip(splitlines(ts),b['line_levels']))]
    if b['kind']=='heading':
        anchors=web_tokens([t for t in ts if t['type']=='anchor'],lang,b['id'])
        parts=b['meta'].get('heading_parts') or [{'level':b['meta'].get('level',3),lang:plain(ts)}]
        return anchors+[{'type':'block','kind':'heading','level':min(6,p['level']+2),'children':[p[lang]]} for p in parts]+web_tokens([t for t in ts if t['type'] in ['page','note_ref']],lang,b['id'])
    content=web_tokens(ts,lang,b['id'])
    return out+([{'type':'block','kind':'quote','children':content}] if b['meta'].get('quotation_group') else content)

def md_tokens(ts,lang,copy=False):
    out=[]
    for t in ts:
        k=t['type']
        if k=='text':out.append(html.escape(t['text'],quote=False).replace('*',r'\*').replace('_',r'\_'))
        elif k=='anchor':
            if not copy:out.append('<a id="'+t['id']+'"></a>')
        elif k=='page':out.append('〔p. '+t['page']+'〕')
        elif k=='break':out.append('\n\n')
        elif k=='linebreak':out.append('<br/>\n')
        elif k=='note_ref':
            if not copy:out.append('[^'+t['id']+']')
    return ''.join(out)

def md_block(b,lang):
    if b['kind']=='brace':
        ls=[]
        for c in b['children']:
            for level,line in zip(c.get('line_levels',[0]),splitlines(c[lang])):
                ls.append('&emsp;'*level+md_tokens(line,lang))
        return '<table><tr><td>'+'<br/>'.join(ls)+'</td><td><img src="assets/brace.svg" width="12" height="'+str(22*len(ls))+'" alt="}"/></td><td>'+html.escape(b['label_'+lang])+'</td></tr></table>'
    out='\n---\n\n' if b['meta'].get('section_break_before') else ''
    if b['kind']=='heading':
        anchors=md_tokens([t for t in b[lang] if t['type']=='anchor'],lang)
        parts=b['meta'].get('heading_parts') or [{'level':b['meta'].get('level',3),lang:plain(b[lang])}]
        return anchors+'\n\n'+'\n\n'.join('#'*min(6,p['level']+2)+' '+p[lang] for p in parts)+md_tokens([t for t in b[lang] if t['type'] in ['page','note_ref']],lang)
    if b.get('line_levels') is not None:return out+'<br/>\n'.join('&emsp;'*level+md_tokens(line,lang) for level,line in zip(b['line_levels'],splitlines(b[lang])))
    text=md_tokens(b[lang],lang)
    if b['meta'].get('quotation_group'):text='\n'.join('> '+line for line in text.splitlines())
    return out+text

def build_markdown():
    f=M['supplements']['facsimile']
    for lang in ['zh','de']:
        title='拉斯克文集：第三卷' if lang=='zh' else 'Gesammelte Schriften. III'
        out=['# '+title,'Emil Lask / 埃米尔·拉斯克 · Eugen Herrigel / 欧根·赫里格尔 编 · 1924',SCOPE_ZH if lang=='zh' else SCOPE_DE,'![手稿影印 / Faksimile](assets/facsimile.png)',f['caption_'+lang],'## 目录 / Inhalt']
        out+=['  '*e.get('level',0)+'- '+('['+e['title_'+lang]+'](#'+lang+'-'+e['id']+')' if e['id'] else e['title_'+lang]+('（未收）' if lang=='zh' else ' (nicht enthalten)')) for e in M['toc']['entries']]
        out += [md_block(b,lang) for b in M['blocks']]
        for editorial in [False,True]:
            out.append('## '+('校读说明 / Hinweise zur Lesart' if editorial else '原注 / Anmerkungen'))
            for n in M['notes']:
                if n['editorial']!=editorial:continue
                label=n['label'] or ('校读' if editorial else '编者说明') if lang=='zh' else n['label'] or ('Lesart' if editorial else 'Hrsg.')
                text='[S. '+'–'.join(n['printed_pages'])+'] '+str(label)+'：'+md_tokens(n[lang],lang)
                if lang=='zh' and not editorial:text+='\n\n原文：'+md_tokens(n['de'],'de',True)
                out.append('[^'+n['id']+']: '+text.replace('\n','\n    '))
        (O/f'lask_iii_{lang}.md').write_text('\n'.join(line.rstrip() for line in '\n\n'.join(out).splitlines())+'\n',encoding='utf8')

def build_web():
    secs=collections.OrderedDict()
    for b in M['blocks']:
        sec=secs.setdefault(b['section'],{'id':b['section'],'body':[],'notes':{},'sourceLanguage':'de','sourceLanguageLabel':'Deutsch'})
        first=b['children'][0] if b['kind']=='brace' else b
        page=next((t['page'] for t in first['zh'] if t['type']=='page'),'')
        sec['body'].append({'id':b['id'],'type':'paragraph','page':page,'zh':web_block(b,'zh'),'en':web_block(b,'de')})
    f=M['supplements']['facsimile'];front=secs['front-matter']
    front['body'].insert(0,{'id':'edition-scope','type':'paragraph','zh':[SCOPE_ZH],'en':[SCOPE_DE]})
    front['body'].insert(1,{'id':'front-facsimile','type':'figure','src':BASE+'facsimile.png','zh':[f['caption_zh']],'en':[f['caption_de']]})
    tocrows={lang:[] for lang in ['zh','de']}
    for e in M['toc']['entries']:
        for lang in tocrows:
            title=e['title_'+lang];content=[title]
            if e['id']:
                sec=U[e['id']]['section'];content=[{'type':'link','url':'translations/book.html?id=lask-gesammelte-schriften-iii&chapter='+sec+'&view='+('en' if lang=='de' else 'zh')+'#'+e['id'],'children':[title]}]
            else:content=[title+('（未收）' if lang=='zh' else ' (nicht enthalten)')]
            tocrows[lang].append({'type':'block','kind':'outline-line','level':e.get('level',0),'children':content})
    front['body'].append({'id':'front-original-toc','type':'paragraph','page':'III–IV','zh':[{'type':'block','kind':'heading','level':2,'children':['目录']}]+tocrows['zh'],'en':[{'type':'block','kind':'heading','level':2,'children':['Inhalt']}]+tocrows['de']})
    for n in M['notes']:
        note={'number':str(n['label']) if n['label'] else ('校读 / Lesart' if n['editorial'] else '编者说明 / Hrsg.'),'sourcePrintedPage':'–'.join(n['printed_pages'])}
        for lang,key in [('zh','zh'),('de','en')]:
            note[key]=['[S. '+note['sourcePrintedPage']+'] ']+web_tokens(n[lang],lang,n['id'])
        if not n['editorial']:note['zh'] += [{'type':'break'},'原文：']+web_tokens(n['de'],'de',n['id']+'-original',True)
        secs[n['section']]['notes'][n['id']]=note
    meta={'id':'lask-gesammelte-schriften-iii','title':'拉斯克文集：第三卷','originalTitle':'Gesammelte Schriften. III','author':'Emil Lask','authorZh':'埃米尔·拉斯克','language':'zh-CN','languagePair':'Deutsch / 中文','structured':True,'bilingual':True,'views':['zh','en','parallel'],'sourceLanguage':'de','sourceLanguageLabel':'Deutsch','tags':['哲学 Philosophy'],'editionNotice':'据1924年图宾根J. C. B. Mohr版校订。收录正文第1—294页及书前材料，未收三卷合编索引及广告。原页码、原注、提纲层级与手稿影印保留；中文原注附德文原文，校读说明另列。','chapters':[],'downloads':[]}
    for sec in secs.values():
        heading=next((b for b in M['blocks'] if b['section']==sec['id'] and b['kind']=='heading'),None)
        sec['title']=plain(heading['zh']) if heading else '书前材料'
        sec['originalTitle']=plain(heading['de']) if heading else 'Vorsatz'
        entry={'id':sec['id'],'title':sec['title'],'originalTitle':sec['originalTitle'],'dataUrl':BASE+sec['id']+'.json'}
        parent=heading and heading['meta'].get('parent_heading_id')
        if parent and U[parent]['section']!=sec['id']:entry['parentId']=U[parent]['section']
        meta['chapters'].append(entry)
        (W/(sec['id']+'.json')).write_text(json.dumps(sec,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    shutil.copyfile(ASSETS/'facsimile.png',W/'facsimile.png')
    (W/'book-metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    return secs

if __name__=='__main__':
    build_markdown();secs=build_web()
    (R/'render_model.json').write_text(json.dumps(M,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    (R/'digital_build_manifest.json').write_text(json.dumps({'canonical_sha256':M['canonical_sha256'],'sections':len(secs),'notes':len(NOTES),'status':'generated_pending_render_and_link_checks'},indent=2)+'\n',encoding='utf8')
    print('Generated 2 Markdown files,',len(secs),'web chapters,',len(NOTES),'notes')
