# Gesammelte Schriften. I 校订阅读成果源码

底本：Emil Lask, Gesammelte Schriften, I. Band, herausgegeben von Eugen
Herrigel, Tübingen: J. C. B. Mohr (Paul Siebeck), 1923。
依据用户提供底本制作，按用户明确授权发布本次翻译成果；非出版社官方译本。
本包不授予原书或第三方材料新的许可，也不宣称译文或OCR绝无错误。
原始扫描PDF由工作区保留，未装入本源码包。规范稿source_refs保留页序和原始行文本，
revisions文件保留修订前后文本。图像证据的哈希记录供核对；原图留存工作区。

## 复现

保留本包目录结构。Python 3运行核心生成器，不要运行历史初稿批次生成器。
直接从已校阅读数据生成：

    python work/review/build_reading_editions.py --compile
    python work/review/build_markdown_editions.py
    python work/review/build_web_edition.py

PDF需要XeLaTeX及ctex、fontspec、paracol等TeX依赖，字体Times New Roman、SimSun。
字体未随包分发；更换字体会改变分页，须重新验收。PDF文本检查另需PyMuPDF。
输出位于output/reviewed。三版分别为中文、德文、中德逐段对照。
中文原注附德文原文，保留书目原题名；页标是底本印刷页码，不是输出页序。

若修改规范数据，应顺序运行build_note_registry、integrate_chinese_notes、
locate_german_markers、integrate_german_notes、clean_german_residuals、
normalize_german_reading、group_reading_paragraphs（均为work/review下.py文件），
再生成成果。原注锚点绑定译文哈希；修改带注正文须重新核实锚点，不能跳过断言。
规范原文保留原始OCR，已核实的阅读修正在german_reading_normalizations.json中。

## 验收范围

各章语义首轮及集中术语、引页、来源和疑点原页核验已记录；
consolidated_review_check.json说明范围与限制。阅读版仍可能存在未识别的OCR错误。
打包、上传和线上验收是独立状态，工作区最新交付记录为准。
