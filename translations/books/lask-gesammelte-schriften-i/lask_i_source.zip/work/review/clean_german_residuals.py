"""Remove twelve visually verified footer markers from the derived reading runs."""
import hashlib, json
from pathlib import Path
R=Path(__file__).resolve().parent
p=R/'reading_projection_bilingual.json'
d=json.loads(p.read_text(encoding='utf8'))
pages={
 'fichte-einleitung-p0016':43, 'fichte-t1-k1-c-p0013':82,
 'fichte-t1-k2-p0007':94, 'fichte-t2-a1-k3-p0005':133,
 'fichte-t3-k1-p0011':229, 'fichte-t3-k3-p0011':248,
 'fichte-t3-k3-p0016':254, 'fichte-t3-k4-p0008':276,
 'fichte-t3-k4-p0010':278, 'fichte-t3-k4-p0018':288,
 'fichte-t3-k4-p0029':299, 'fichte-t3-k4-p0032':301,
}
edits=[]
for u in d['units']:
 uid=u['unit_id']
 if uid not in pages:continue
 old,new=' i)',''
 if uid=='fichte-t3-k4-p0010':old=' * i)'
 if uid=='fichte-t3-k4-p0018':old,new=', i)','.'
 before=''.join(v['text'] for v in u['de_runs'] if v['type']=='text')
 assert before.count(old)==1,uid
 changed=0
 for i,v in enumerate(u['de_runs']):
  if v['type']=='text' and old in v['text']:
   edits.append(dict(unit_id=uid,run=i,start=v['text'].index(old),removed=old,replacement=new,
    pdf_page=pages[uid],evidence='ocr/residual_markers_'+str((list(pages).index(uid)//4)+1)+'.png',
    reason='Original page has no second body reference; footnote label was imported by OCR. PDF278 also has stray star; PDF288 sentence ends with period.'))
   v['text']=v['text'].replace(old,new);changed+=1
 assert changed==1
 after=''.join(v['text'] for v in u['de_runs'] if v['type']=='text')
 assert after==before.replace(old,new)
assert len(edits)==12
for lang in ['de','zh']:
 refs=[v['note_id'] for u in d['units'] for v in u[lang+'_runs'] if v['type']=='note_ref']
 assert len(refs)==len(set(refs))==495
d['german_residual_cleanup']=edits
d['status']='Bilingual references integrated and twelve residual footer markers visually verified and removed; layout and consolidated review pending'
(R/'reading_projection.json').write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
evidence={}
for page in pages.values():
 for suffix in ['png','reocr.txt']:
  f=R/'ocr'/f'page{page:03}.{suffix}'
  evidence[str(f.relative_to(R))]=hashlib.sha256(f.read_bytes()).hexdigest()
(R/'german_residual_cleanup_check.json').write_text(json.dumps(dict(canonical_sha256=d['canonical_sha256'],
 input_projection_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),edits=edits,evidence_sha256=evidence,
 verification='Twelve original-page crops visually inspected; existing targeted OCR results reused; exact text replacement and both reference-ID sets validated.',
 scope='Body reference tokens only; unrelated German OCR spelling and page-boundary word joining remain for consolidated review.'),ensure_ascii=False,indent=2),encoding='utf8')
print('12 verified footer-marker removals; 495 references per language; source unchanged.')
