"""Read back PDF text and named note destinations; report rather than hide gaps."""
import hashlib,json,re,unicodedata
from pathlib import Path
from note_display import note_display
import pymupdf as fitz
R=Path(__file__).resolve().parent;O=R.parent.parent/'output/reviewed'
D=json.loads((R/'reading_groups.json').read_text(encoding='utf8'))
def norm(s):
 s=re.sub(r'⟦p\.[^⟧]+⟧','',s)
 return ''.join(c for c in unicodedata.normalize('NFKC',s).lower() if c.isalnum())
U={u['id']:u for u in map(json.loads,(R/'translation_units.jsonl').read_text(encoding='utf8').splitlines())}
report={}
for mode in ['zh','de','bilingual']:
 p=O/f'lask_i_{mode}.pdf';doc=fitz.open(p);names=doc.resolve_names()
 text={lang:[] for lang in ['zh','de','all']}
 for page in doc:
  for b in page.get_text('dict')['blocks']:
   for line in b.get('lines',[]):
    for s in line['spans']:
     if s['bbox'][1]<50 or s['bbox'][3]>page.rect.height-45 or s['size']<8.1:continue
     for lang in text:
      if mode=='bilingual' and ((lang=='zh' and s['bbox'][0]>page.rect.width/2) or (lang=='de' and s['bbox'][0]<page.rect.width/2)):continue
      text[lang].append(s['text'])
 pools={lang:norm(''.join(parts)) for lang,parts in text.items()}
 items=[]
 for g in D['groups']:
  if g['kind']=='blank':continue
  for lang in (['zh','de'] if mode=='bilingual' else [mode]):
   for c in g['components']:
    for j,v in enumerate(c[lang+'_runs']):
     if v['type']=='text':items.append((c['unit_id']+':'+str(j),lang,v['text'],g['kind']))
 for n in D['notes']:
  for lang in (['zh','de'] if mode in ['zh','bilingual'] else ['de']):
   items.append((n['note_id'],lang,n['translation'] if lang=='zh' else note_display(n,U)[1],'note'))
 missing=[];checked=0
 for uid,lang,s,kind in items:
  s=norm(s)
  if not s:continue
  # Overlapping windows detect local omissions without requiring paragraph order
  # across columns. Short strings are checked whole, but not treated as unique IDs.
  windows=[s] if len(s)<=70 else [s[i:i+70] for i in range(0,len(s)-69,50)]+[s[-70:]]
  for w in windows:
   checked+=1
   if w not in pools['all' if kind=='heading' else lang]:missing.append(dict(id=uid,language=lang,kind=kind,text=w))
 expected={n['note_id'] for n in D['notes']}
 absent=[n for n in expected if 'note-'+n not in names]
 for lang in (['zh','de'] if mode=='bilingual' else [mode]):
  absent += ['ref-'+lang+'-'+n for n in expected if 'ref-'+lang+'-'+n not in names]
 report[mode]=dict(pdf_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),pages=len(doc),checked_windows=checked,
 missing_windows=missing,missing_note_destinations=absent,
 scope='Alphanumeric normalized overlapping 70-character text windows, ignoring small superscript reference/page labels and header/footer; named destinations checked separately. This does not verify punctuation or visual reading order.')
 print(mode,'windows',checked,'unmatched',len(missing),'missing note targets',len(absent))
(R/'pdf_text_readback_check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
