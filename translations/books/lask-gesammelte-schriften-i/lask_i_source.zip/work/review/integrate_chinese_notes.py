"""Create lossless Chinese reading runs from reviewed anchors; source data stays immutable."""
import collections, hashlib, json, re
from pathlib import Path
R=Path(__file__).resolve().parent
p=R/'translation_units.jsonl'
h=hashlib.sha256(p.read_bytes()).hexdigest()
u=list(map(json.loads,p.read_text(encoding='utf8').splitlines()));d={x['id']:x for x in u}
reg=json.loads((R/'note_registry.json').read_text(encoding='utf8'))
assert reg['canonical_sha256']==h and reg['reviewed_anchor_count']==495
bybody=collections.defaultdict(list)
for n in reg['notes']:bybody[n['anchor']['body_unit_id']].append(n)
projected=[];edits=[];refs=[]
for x in u:
 if x['kind']=='note':continue
 text=x['translation'];events=[]
 for n in bybody[x['id']]:
  a=n['anchor'];phrase=a['translation_after'];assert text.count(phrase)==1
  end=text.index(phrase)+len(phrase);skip=0
  # Only reviewed residual note digits immediately at a confirmed reference position.
  if x['id'].startswith('fichte-t3-k4-p'):
   m=re.match(r'(?:[1-6]\s*)+）',text[end:])
   if m:
    skip=len(m[0]);edits.append(dict(unit_id=x['id'],start=end,removed=m[0],note_id=n['note_id']))
  events.append((end,skip,n))
 events.sort(key=lambda v:v[0]);runs=[];last=0
 for end,skip,n in events:
  assert end>=last
  if end>last:runs.append(dict(type='text',text=text[last:end]))
  runs.append(dict(type='note_ref',note_id=n['note_id'],original_number=n['anchor']['original_note_number'],source_pdf_page=n['source_pdf_page']))
  refs.append(n['note_id']);last=end+skip
 if last<len(text):runs.append(dict(type='text',text=text[last:]))
 cleaned=''.join(z['text'] for z in runs if z['type']=='text')
 expected=text
 for e in sorted((e for e in edits if e['unit_id']==x['id']),key=lambda e:e['start'],reverse=True):expected=expected[:e['start']]+expected[e['start']+len(e['removed']):]
 assert cleaned==expected
 projected.append(dict(unit_id=x['id'],kind=x['kind'],section=x['section'],continuation_of=x.get('continuation_of'),zh_runs=runs))
notes=[]
for n in reg['notes']:
 ids=[n['note_id']]+n['continuation_ids']
 notes.append(dict(note_id=n['note_id'],original_number=n['anchor']['original_note_number'],source_pdf_page=n['source_pdf_page'],body_unit_id=n['anchor']['body_unit_id'],component_ids=ids,translation=' '.join(d[i]['translation'] for i in ids),source_text=' '.join(d[i]['source_text'] for i in ids)))
assert len(refs)==len(set(refs))==len(notes)==495
out=dict(canonical_sha256=h,status='Chinese reference integration validated; German integration and rendering pending',units=projected,notes=notes,display_cleanup=edits)
(R/'reading_projection_zh.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
print('Chinese references:',len(refs),'notes:',len(notes),'residual markers removed:',len(edits),'continuation fragments merged:',sum(len(n['component_ids'])-1 for n in notes))
