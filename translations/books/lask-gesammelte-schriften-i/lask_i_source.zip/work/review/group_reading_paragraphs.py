"""Group verified cross-page continuations without dropping source component IDs."""
import copy,hashlib,json
from pathlib import Path
R=Path(__file__).resolve().parent
p=R/'translation_units.jsonl';h=hashlib.sha256(p.read_bytes()).hexdigest()
canonical={u['id']:u for u in map(json.loads,p.read_text(encoding='utf8').splitlines())}
d=json.loads((R/'reading_projection_normalized.json').read_text(encoding='utf8'))
assert d['canonical_sha256']==h
groups=[];byid={};components=[]
for u in d['units']:
 uid=u['unit_id'];parent=u['continuation_of']
 component=copy.deepcopy(u)
 component['reading_role']=canonical[uid].get('reading_role','content')
 if parent:
  assert parent in byid,(uid,parent)
  target=byid[parent]
  assert groups[-1] is target,(uid,'non-adjacent continuation')
  assert target['section']==u['section']
  target['components'].append(component);byid[uid]=target
 else:
  target=dict(id=uid,kind=u['kind'],section=u['section'],components=[component])
  groups.append(target);byid[uid]=target
 components.append(uid)
assert len(components)==len(set(components))==len(d['units'])
for lang in ['zh','de']:
 before=[u[lang+'_runs'] for u in d['units']]
 after=[u[lang+'_runs'] for g in groups for u in g['components']]
 assert before==after
 refs=[r['note_id'] for runs in after for r in runs if r['type']=='note_ref']
 assert len(refs)==len(set(refs))==495
out=dict(canonical_sha256=h,status='Verified paragraph grouping; renderers must keep component anchors and inline source-page markers',
 groups=groups,notes=d['notes'],input_projection='reading_projection_normalized.json')
(R/'reading_groups.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
check=dict(canonical_sha256=h,component_count=len(components),group_count=len(groups),
 merged_groups=[dict(id=g['id'],components=[c['unit_id'] for c in g['components']]) for g in groups if len(g['components'])>1],
 validation='Exact ordered run equality in both languages; all original component IDs and 495 note references per language preserved',
 remaining='German within-paragraph word joining and rendered typography')
(R/'reading_group_check.json').write_text(json.dumps(check,ensure_ascii=False,indent=2),encoding='utf8')
print(len(components),'components ->',len(groups),'reading groups;',len(check['merged_groups']),'verified merged paragraphs')
