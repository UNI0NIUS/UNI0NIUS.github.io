"""Apply explicit reviewed source-display corrections, preserving source evidence."""
import hashlib,json,re
from pathlib import Path
R=Path(__file__).resolve().parent
p=R/'reading_projection.json';d=json.loads(p.read_text(encoding='utf8'))
rules=json.loads((R/'german_reading_normalizations.json').read_text(encoding='utf8'))
units={u['unit_id']:u for u in d['units']};notes={n['note_id']:n for n in d['notes']};edits=[]
for rule in rules['rules']:
 old,new=rule['old'],rule['new'];nid=rule['unit_id']
 is_note=rule.get('target')=='note'
 if is_note:
  runs=[{'text':notes[nid]['source_text']}]
 else:
  u=units[nid];runs=[v for v in u['de_runs'] if v['type']=='text']
 assert sum(v['text'].count(old) for v in runs)==rule.get('expected_count',1),rule
 assert re.findall(r'⟦p\.[^⟧]+⟧',old)==re.findall(r'⟦p\.[^⟧]+⟧',new),rule
 for run in runs:
  if old in run['text']:
   edits.append(dict(rule,start=run['text'].index(old)))
   run['text']=run['text'].replace(old,new)
 if is_note:notes[nid]['source_text']=runs[0]['text']
for lang in ['zh','de']:
 refs=[v['note_id'] for u in d['units'] for v in u[lang+'_runs'] if v['type']=='note_ref']
 assert len(refs)==len(set(refs))==495
d['german_reading_normalizations']=edits
d['status']='Bilingual references and reviewed page-boundary corrections integrated; final text and rendering checks pending'
(R/'reading_projection_normalized.json').write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
(R/'german_reading_normalization_check.json').write_text(json.dumps(dict(canonical_sha256=d['canonical_sha256'],
 projection_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),
 rules_sha256=hashlib.sha256((R/'german_reading_normalizations.json').read_bytes()).hexdigest(),
 applied_count=len(edits),validation='Every old phrase occurs exactly its reviewed expected_count; all page-token sequences preserved; 495 note references in each language preserved',
 scope=rules['scope'],retained_exception=rules['retained_exception']),ensure_ascii=False,indent=2),encoding='utf8')
print(len(edits),'explicit German display corrections applied; note and page references preserved')
