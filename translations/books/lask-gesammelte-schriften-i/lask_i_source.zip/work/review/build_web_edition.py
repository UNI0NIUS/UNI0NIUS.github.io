"""Export local review JSON using the existing site's bilingual reader schema."""
import collections,hashlib,json,re
from pathlib import Path
from note_display import note_display
R=Path(__file__).resolve().parent;O=R.parent.parent/'output/reviewed/webdata'
O.mkdir(parents=True,exist_ok=True)
D=json.loads((R/'reading_groups.json').read_text(encoding='utf8'))
U={u['id']:u for u in map(json.loads,(R/'translation_units.jsonl').read_text(encoding='utf8').splitlines())}
assert D['canonical_sha256']==hashlib.sha256((R/'translation_units.jsonl').read_bytes()).hexdigest()
base='translations/books/lask-gesammelte-schriften-i/'
sections=collections.OrderedDict();note_refs=collections.Counter();component_ids=[]
def tokens(s,uid,language):
 out=[];i=0
 for p in re.split(r'(⟦p\.[^⟧]+⟧|\n\n|\n)',s):
  if not p:continue
  if p.startswith('⟦p.'):
   out.append(dict(type='page',page=p[3:-1],id=f'{language}-{uid}-page-{i}'));i+=1
  elif p=='\n\n':out.append(dict(type='break'))
  elif p=='\n':out.append(dict(type='linebreak'))
  else:out.append(p)
 return out
for g in D['groups']:
 if g['kind']=='blank':continue
 section=sections.setdefault(g['section'],dict(id=g['section'],body=[],notes={},sourceLanguage='de',sourceLanguageLabel='Deutsch'))
 row=dict(id=g['id'],type='heading' if g['kind']=='heading' else 'paragraph',page=U[g['id']].get('page_label',''))
 for lang,key in [('zh','zh'),('de','en')]:
  row[key]=[]
  for j,c in enumerate(g['components']):
   if lang=='zh':component_ids.append(c['unit_id'])
   if j and lang=='de':row[key].append(' ')
   row[key].append(dict(type='anchor',id=key+'-'+c['unit_id']))
   for k,run in enumerate(c[lang+'_runs']):
    if run['type']=='text':row[key]+=tokens(run['text'],c['unit_id']+f'-r{k}',key)
    else:
     row[key].append(dict(type='note',id=run['note_id'],label=str(run['original_number'])))
     note_refs[(key,run['note_id'])]+=1
 section['body'].append(row)
for n in D['notes']:
 page,source,removed=note_display(n,U)
 sec=next(s for s in sections.values() if any(row['id']==next(g['id'] for g in D['groups'] if any(c['unit_id']==n['body_unit_id'] for c in g['components'])) for row in s['body']))
 sec['notes'][n['note_id']]=dict(number=str(n['original_number']),sourcePdfPage=n['source_pdf_page'],
  sourcePrintedPage=page,
  zh=['[原书第'+page+'页] ']+tokens(n['translation'],n['note_id'],'zh')+[dict(type='break'),'原文：']+tokens(source,n['note_id']+'-original','zh'),
  en=['[S. '+page+'] ']+tokens(source,n['note_id'],'en'))
meta=dict(id='lask-gesammelte-schriften-i',title='拉斯克文集：第一卷',originalTitle='Gesammelte Schriften. I',
 author='Emil Lask',authorZh='埃米尔·拉斯克',language='zh-CN',languagePair='Deutsch / 中文',
 structured=True,bilingual=True,views=['zh','en','parallel'],sourceLanguage='de',sourceLanguageLabel='Deutsch',
 editionNotice='据1923年图宾根J. C. B. Mohr版校订。原页码随文保留，原注保留页内编号；中文原注附德文原文。',
 chapters=[],downloads=[])
for sec in sections.values():
 first=next((row for row in sec['body'] if row['type']=='heading'),sec['body'][0])
 def title(lang):return ' '.join(t for t in first[lang] if isinstance(t,str)).replace('\n',' ')
 sec['title']=title('zh') if first['type']=='heading' else ('书前材料' if sec['id']=='front-matter' else '附属材料')
 sec['originalTitle']=title('en') if first['type']=='heading' else ('Vorsatz' if sec['id']=='front-matter' else 'Anhang')
 (O/(sec['id']+'.json')).write_text(json.dumps(sec,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
 meta['chapters'].append(dict(id=sec['id'],title=sec['title'],originalTitle=sec['originalTitle'],dataUrl=base+sec['id']+'.json'))
toc=json.loads((R/'original_toc.json').read_text(encoding='utf8'))['entries']
parents={U[t['unit_id']]['section']:U[t['parent_unit_id']]['section'] if t['parent_unit_id'] else None for t in toc}
for chapter in meta['chapters']:
 parent=parents.get(chapter['id'])
 if chapter['id'].startswith('rechtsphil-lit-'):parent='rechtsphil-lit'
 if parent:chapter['parentId']=parent
assert len(note_refs)==990 and set(note_refs.values())=={1}
assert sum(len(s['notes']) for s in sections.values())==495
assert len(component_ids)==len(set(component_ids))
(O/'book-metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
(R/'web_export_check.json').write_text(json.dumps(dict(canonical_sha256=D['canonical_sha256'],sections=len(sections),rows=sum(len(s['body']) for s in sections.values()),components=len(component_ids),independent_notes=495,unique_references_per_language=495,
 status='Local JSON exported; existing reader schema used; browser rendering and text/anchor verification pending',
 files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in O.glob('*.json')}),ensure_ascii=False,indent=2),encoding='utf8')
print('Exported',len(sections),'sections,495 notes,990 language references; site unchanged.')
