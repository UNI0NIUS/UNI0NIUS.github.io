"""Export editable reading editions from the same groups as PDF and web."""
import hashlib,json,re
from pathlib import Path
from note_display import note_display
R=Path(__file__).resolve().parent
O=R.parent.parent/'output/reviewed'
D=json.loads((R/'reading_groups.json').read_text(encoding='utf8'))
U={u['id']:u for u in map(json.loads,(R/'translation_units.jsonl').read_text(encoding='utf8').splitlines())}
assert D['canonical_sha256']==hashlib.sha256((R/'translation_units.jsonl').read_bytes()).hexdigest()
levels={e['unit_id']:e['level'] for e in json.loads((R/'original_toc.json').read_text(encoding='utf8'))['entries']}
report={}
for lang in ['zh','de']:
    out=['# 文集第一卷 / Gesammelte Schriften. I',
         'Emil Lask · Herausgegeben von Eugen Herrigel · Tübingen: J. C. B. Mohr, 1923.',
         '校订版。原页码以 ⟦p.…⟧ 标记；原注使用稳定引用标识，注内保留原页码与页内编号。']
    refs=[];components=[]
    for g in D['groups']:
        if g['kind']=='blank':continue
        parts=[]
        for i,c in enumerate(g['components']):
            components.append(c['unit_id'])
            parts.append('<a id="'+lang+'-'+c['unit_id']+'"></a>')
            if i and lang=='de':parts.append(' ')
            for run in c[lang+'_runs']:
                if run['type']=='text':parts.append(run['text'])
                else:
                    refs.append(run['note_id'])
                    parts.append('[^'+run['note_id']+']')
        value=''.join(parts)
        if g['kind']=='heading':value='#'*min(levels.get(g['id'],3)+2,6)+' '+value.replace('\n',' ')
        out.append(value)
    out.append('## 原注 / Anmerkungen')
    for n in D['notes']:
        page,source,_=note_display(n,U)
        label='[原书第'+page+'页，注'+str(n['original_number'])+'] ' if lang=='zh' else '[S. '+page+', Anm. '+str(n['original_number'])+'] '
        body=label+(n['translation']+'\n\n原文：'+source if lang=='zh' else source)
        out.append('[^'+n['note_id']+']: '+body.replace('\n','\n    '))
    result='\n\n'.join(out)+'\n'
    assert len(refs)==len(set(refs))==495
    assert set(refs)=={n['note_id'] for n in D['notes']}
    assert len(components)==len(set(components))==592
    p=O/f'lask_i_{lang}.md';p.write_text(result,encoding='utf8')
    report[lang]=dict(sha256=hashlib.sha256(p.read_bytes()).hexdigest(),components=len(components),references=len(refs),definitions=len(D['notes']))
(R/'markdown_export_check.json').write_text(json.dumps(dict(canonical_sha256=D['canonical_sha256'],status='Review editions exported; stable components and footnote set verified',editions=report),ensure_ascii=False,indent=2),encoding='utf8')
print('Chinese/German review Markdown exported: 592 components and 495 notes each')
