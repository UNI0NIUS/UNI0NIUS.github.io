"""Project reviewed German references without mutating the canonical source.

Source-line locations were reviewed in note_anchors_*.json. Explicit choices
below disambiguate ordinary parentheses, adjacent references and OCR debris.
Residual unreferenced OCR tokens are audited separately before rendering.
"""
import collections, hashlib, json
from pathlib import Path
R = Path(__file__).resolve().parent
raw = (R/'translation_units.jsonl').read_bytes()
h = hashlib.sha256(raw).hexdigest()
units = {u['id']: u for u in map(json.loads, raw.decode('utf8').splitlines())}
c = json.loads((R/'german_marker_candidates.json').read_text(encoding='utf8'))
out = json.loads((R/'reading_projection_zh.json').read_text(encoding='utf8'))
assert c['canonical_sha256'] == out['canonical_sha256'] == h
# Candidate index, or 'combine' for a single reference corrupted into two tokens.
choices = {
 'fichte-einleitung-n0008':0, 'fichte-einleitung-n0009':1,
 'fichte-einleitung-n0027':0, 'fichte-einleitung-n0028':1,
 'fichte-t1-k1-c-n0015':'combine', 'fichte-t1-k1-c-n0024':1,
 'fichte-t1-k2-n0019':'combine', 'fichte-t1-k2-n0028':0,
 'fichte-t2-a1-n0002':'combine',
 'fichte-t2-a1-k1-n0016':0, 'fichte-t2-a1-k1-n0017':1,
 'fichte-t2-a1-k3-n0009':'combine',
 'fichte-t2-a1-k5-n0007':0, 'fichte-t2-a1-k5-n0008':1,
 'fichte-t2-a2-k3-n0002':0, 'fichte-t2-a2-k3-n0003':1,
 'fichte-t2-a3-k1-n0026':1, 'fichte-t2-a3-k2-n0010':1,
 'fichte-t2-a3-k3-n0023':'combine', 'fichte-t3-k2-n0007':1,
 'fichte-t3-k4-n0020':0, 'fichte-t3-k4-n0023':0,
}
# A corrected canonical word or an already removed OCR footer prevents matching
# the complete raw line. Match an exact unique canonical phrase instead.
manual = {
 'fichte-t1-k1-a-n0010':('»Fall« 4)', '4)'),
 'fichte-t1-k1-c-n0018':('zugleich aprioristischen und konkreten Denkens1)', '1)'),
 'fichte-t2-a1-k2-n0003':('die Idee liegt in unendlich ferner Zeit1)', '1)'),
 'fichte-t3-k2-n0003':('die des Gliedes umfängt und bestätigt1)', '1)'),
 'fichte-t2-a1-k3-n0001':('Der analytisch-systematische Standpunkt', ''),
 'rechtsphil-lit-jur-n0001':('Zur Methodologie der Jurisprudenz', ''),
}
bybody = collections.defaultdict(list)
resolved = []
for e in c['entries']:
 nid = e['note_id']; text = units[e['body_unit_id']]['source_text']
 cs = e['candidates']
 if nid in manual:
  phrase, marker = manual[nid]
  assert text.count(phrase) == 1, nid
  end = text.index(phrase)+len(phrase); start = end-len(marker)
  method = 'explicit_canonical_phrase_after_prior_source_correction'
 elif len(cs) == 1:
  start, end = cs[0]['start'], cs[0]['end']
  method = 'unique_marker_on_reviewed_source_line'
 else:
  choice = choices[nid]
  if choice == 'combine': start, end = cs[0]['start'], cs[-1]['end']
  else: start, end = cs[choice]['start'], cs[choice]['end']
  method = 'explicit_disambiguation_on_reviewed_source_line'
 record = dict(note_id=nid, unit_id=e['body_unit_id'], start=start, end=end,
               removed=text[start:end], original_number=e['original_number'],
               source_pdf_page=e['pdf_page'], source_line=e['source_line'], method=method)
 bybody[e['body_unit_id']].append(record); resolved.append(record)
refs = []
for u in out['units']:
 text = units[u['unit_id']]['source_text']; runs = []; last = 0
 events = sorted(bybody[u['unit_id']], key=lambda v:v['start'])
 for e in events:
  assert e['start'] >= last, (u['unit_id'], e)
  if e['start'] > last: runs.append(dict(type='text',text=text[last:e['start']]))
  runs.append(dict(type='note_ref',note_id=e['note_id'],original_number=e['original_number'],source_pdf_page=e['source_pdf_page']))
  refs.append(e['note_id']); last=e['end']
 if last < len(text): runs.append(dict(type='text',text=text[last:]))
 expected = text
 for e in reversed(events): expected=expected[:e['start']]+expected[e['end']:]
 assert ''.join(r['text'] for r in runs if r['type']=='text') == expected
 u['de_runs'] = runs
assert len(refs) == len(set(refs)) == 495
assert set(refs) == {n['note_id'] for n in out['notes']}
out['german_reference_edits'] = resolved
out['status'] = '495 references integrated in each language; residual German OCR cleanup and rendering pending'
(R/'reading_projection_bilingual.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
(R/'german_reference_integration_check.json').write_text(json.dumps(dict(canonical_sha256=h,reference_count=495,
 explicit_choices=choices,manual_phrases=manual,edits=resolved,
 validation='unique references, note-ID equality, non-overlapping edits, exact character retention outside recorded spans',
 remaining='unreferenced OCR debris and final rendering'),ensure_ascii=False,indent=2),encoding='utf8')
print('German and Chinese references: 495 each; canonical unchanged; residual OCR audit pending.')
