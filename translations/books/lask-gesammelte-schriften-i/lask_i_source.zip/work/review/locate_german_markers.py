"""Propose German marker spans from already reviewed source lines; never changes canonical text."""
import json,re,hashlib,collections
from pathlib import Path
R=Path(__file__).resolve().parent
units={u['id']:u for u in map(json.loads,(R/'translation_units.jsonl').read_text(encoding='utf8').splitlines())}
reg=json.loads((R/'note_registry.json').read_text(encoding='utf8'))
assert reg['canonical_sha256']==hashlib.sha256((R/'translation_units.jsonl').read_bytes()).hexdigest()
def norm(s):
 skip=set()
 for m in re.finditer(r'⟦p\.[^⟧]+⟧',s):skip.update(range(m.start(),m.end()))
 indexes=[i for i,c in enumerate(s) if i not in skip and not c.isspace() and c not in '-\u00ad']
 return ''.join(s[i] for i in indexes),indexes
pattern=re.compile(r'(?:\d[\d\s*]*|[ilrxzIJTsS?*^»])\)')
out=[]
for n in reg['notes']:
 a=n['anchor'];b=units[a['body_unit_id']];line=a['source_line_text'];text=b['source_text'];nt,ix=norm(text);nl,il=norm(line)
 matches=list(re.finditer(re.escape(nl),nt)) if nl else []
 markers=list(pattern.finditer(line));candidates=[]
 if len(matches)==1:
  base=matches[0].start()
  for m in markers:
   positions=[j for j,k in enumerate(il) if m.start()<=k<m.end()]
   if positions:
    start=ix[base+positions[0]];end=ix[base+positions[-1]]+1
    candidates.append(dict(start=start,end=end,marker=text[start:end],context=text[max(0,start-65):min(len(text),end+45)]))
 out.append(dict(note_id=n['note_id'],body_unit_id=b['id'],pdf_page=a['pdf_page'],source_line=a['source_line'],original_number=a['original_note_number'],source_line_text=line,candidates=candidates,status='candidate_requires_review' if candidates else 'manual_alignment_required'))
(R/'german_marker_candidates.json').write_text(json.dumps(dict(canonical_sha256=reg['canonical_sha256'],entries=out),ensure_ascii=False,indent=2),encoding='utf8')
print(dict(collections.Counter(len(x['candidates']) for x in out)))
# Full candidate details remain in JSON; keep console output encoding-independent.
