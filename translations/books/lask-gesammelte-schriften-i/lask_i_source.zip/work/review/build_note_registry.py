"""Assemble reviewed anchors and explicitly unreviewed notes from current data."""
import collections,hashlib,json
from pathlib import Path
r=Path(__file__).resolve().parent
u=list(map(json.loads,(r/'translation_units.jsonl').read_text(encoding='utf8').splitlines()))
d={x['id']:x for x in u};anchors={}
for p in sorted(r.glob('note_anchors_*.json')):
    for a in json.loads(p.read_text(encoding='utf8'))['anchors']:
        assert a['note_id'] not in anchors,('duplicate mapping',a['note_id'])
        b=d[a['body_unit_id']]
        assert hashlib.sha256(b['translation'].encode()).hexdigest()==a['body_translation_sha256'],('stale translation selector',a['note_id'])
        assert b['translation'].count(a['translation_after'])==1
        assert any(z.get('pdf_page')==a['pdf_page'] and z.get('line')==a['source_line'] for z in b['source_refs'])
        anchors[a['note_id']]=dict(a,evidence_file=p.name)
notes=[];continuations=collections.defaultdict(list)
for x in u:
    if x['kind']=='note' and x.get('note_role')=='continuation_fragment':
        assert x['continuation_of'] in d
        continuations[x['continuation_of']].append(x['id'])
for x in u:
    if x['kind']!='note' or x.get('note_role')=='continuation_fragment':continue
    a=anchors.get(x['id']);notes.append(dict(note_id=x['id'],section=x['section'],
        source_pdf_page=x.get('start_pdf_page',x['source_refs'][0]['pdf_page']),
        continuation_ids=continuations[x['id']],anchor=a,
        status='anchor_reviewed_rendering_pending' if a else 'anchor_pending'))
assert len(notes)==495
assert set(anchors)<=set(x['note_id'] for x in notes)
pending=collections.Counter(x['section'] for x in notes if not x['anchor'])
out=dict(canonical_sha256=hashlib.sha256((r/'translation_units.jsonl').read_bytes()).hexdigest(),
    independent_note_count=len(notes),continuation_fragment_count=sum(map(len,continuations.values())),
    reviewed_anchor_count=len(anchors),pending_by_section=dict(pending),notes=notes,
    limitation='This registry checks selector freshness and data consistency, not remaining semantic correspondence, source-marker cleanup, or rendered hyperlinks.')
(r/'note_registry.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
print('Independent notes:',len(notes),'reviewed anchors:',len(anchors),'pending:',sum(pending.values()))
print('Next pending sections:',list(pending.items())[:5])
