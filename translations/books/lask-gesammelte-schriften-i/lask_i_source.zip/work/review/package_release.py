"""Package only the current reproducible reading sources and explicit evidence."""
import hashlib, json, zipfile
from pathlib import Path

R = Path(__file__).resolve().parent
B = R.parent.parent
O = B / 'output/reviewed'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
scripts = ['build_note_registry.py', 'integrate_chinese_notes.py',
           'locate_german_markers.py', 'integrate_german_notes.py',
           'clean_german_residuals.py', 'normalize_german_reading.py',
           'group_reading_paragraphs.py', 'build_reading_editions.py',
           'build_markdown_editions.py', 'build_web_edition.py',
           'note_display.py', 'check_pdf_text.py', 'package_release.py']
data = ['translation_units.jsonl', 'reading_groups.json', 'original_toc.json',
        'german_reading_normalizations.json', 'consolidated_review_check.json',
        'revision_consistency_check.json', 'source_content_coverage_check.json',
        'citation_range_check.json', 'pdf_text_readback_check.json',
        'final_pdf_geometry_check.json', 'context_final_source_check.json',
        'character_review_check.json', 'within_page_complete_check.json']
files = [R/n for n in scripts + data]
files += sorted(R.glob('note_anchors_*.json'))
files += sorted(R.glob('revisions_*.json'))
files += sorted((R/'spacing_20261025').glob('*_proposals.json'))
files += sorted((R/'spacing_20261025').glob('*_proposals_evidence.json'))
files += sorted((R/'spacing_20261025').glob('*_check.json'))
files += [R/'spacing_20261025'/'residual_boundary_audit.json',
          R/'german_reading_normalization_check.json']
files += sorted(O.glob('lask_i_*.tex'))
files += sorted(O.glob('lask_i_*.md'))
files += sorted((O/'webdata').glob('*.json'))
readme = '''# Gesammelte Schriften. I 校订阅读成果源码

底本：Emil Lask, Gesammelte Schriften, I. Band, herausgegeben von Eugen
Herrigel, Tübingen: J. C. B. Mohr (Paul Siebeck), 1923。
依据用户提供底本制作，按用户明确授权发布本次翻译成果；非出版社官方译本。
本包不授予原书或第三方材料新的许可，也不宣称译文或OCR绝无错误。
原始扫描PDF由工作区保留，未装入本源码包。规范稿source_refs保留页序和原始行文本，
revisions文件保留修订前后文本。图像证据的哈希记录供核对；原图留存工作区。

## 复现

保留本包目录结构。Python 3运行核心生成器，不要运行历史初稿批次生成器。
直接从已校阅读数据生成：

    python work/review/build_reading_editions.py --compile
    python work/review/build_markdown_editions.py
    python work/review/build_web_edition.py

PDF需要XeLaTeX及ctex、fontspec、paracol等TeX依赖，字体Times New Roman、SimSun。
字体未随包分发；更换字体会改变分页，须重新验收。PDF文本检查另需PyMuPDF。
输出位于output/reviewed。三版分别为中文、德文、中德逐段对照。
中文原注附德文原文，保留书目原题名；页标是底本印刷页码，不是输出页序。

若修改规范数据，应顺序运行build_note_registry、integrate_chinese_notes、
locate_german_markers、integrate_german_notes、clean_german_residuals、
normalize_german_reading、group_reading_paragraphs（均为work/review下.py文件），
再生成成果。原注锚点绑定译文哈希；修改带注正文须重新核实锚点，不能跳过断言。
规范原文保留原始OCR，已核实的阅读修正在german_reading_normalizations.json中。
spacing_20261025保留本次全书字距、断词及粘连专项的候选、原页定位、
核查结论与图像哈希；候选可能被否决或调整，实际生效内容以规则文件为准。

## 验收范围

各章语义首轮及集中术语、引页、来源和疑点原页核验已记录；
consolidated_review_check.json说明范围与限制。阅读版仍可能存在未识别的OCR错误。
打包、上传和线上验收是独立状态，工作区最新交付记录为准。
'''
(O/'README-source.md').write_text(readme, encoding='utf8')
files.append(O/'README-source.md')
manifest = {p.relative_to(B).as_posix(): {'bytes':p.stat().st_size,'sha256':sha(p)}
            for p in files}
target = O/'lask_i_source.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in files:
        info=zipfile.ZipInfo(p.relative_to(B).as_posix(), (2026,10,23,0,0,0))
        info.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(info,p.read_bytes())
    z.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2))
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    for name,record in manifest.items():
        assert hashlib.sha256(z.read(name)).hexdigest()==record['sha256']
        assert not name.startswith('/') and '..' not in Path(name).parts
(R/'source_package_check.json').write_text(json.dumps(dict(file=target.name,
    bytes=target.stat().st_size,sha256=sha(target),members=len(manifest)+1,
    validation='All members fully read and hashes matched; relative safe paths',
    canonical_sha256=sha(R/'translation_units.jsonl')),indent=2),encoding='utf8')
print('Validated source package:',target.name,len(manifest)+1,'members')
