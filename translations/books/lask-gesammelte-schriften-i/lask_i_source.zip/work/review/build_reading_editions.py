"""Generate review editions from one reviewed bilingual reading data set.

Typography follows Yikarak Yapmak's accepted Chinese edition and the existing
philosophy parallel template. Never imports or executes historical builders.
"""
import collections,hashlib,json,re,subprocess,sys
from pathlib import Path
from note_display import note_display
R=Path(__file__).resolve().parent
B=R.parent.parent
O=B/'output'/'reviewed';O.mkdir(parents=True,exist_ok=True)
D=json.loads((R/'reading_groups.json').read_text(encoding='utf8'))
assert D['canonical_sha256']==hashlib.sha256((R/'translation_units.jsonl').read_bytes()).hexdigest()
U={u['id']:u for u in map(json.loads,(R/'translation_units.jsonl').read_text(encoding='utf8').splitlines())}
TOC=json.loads((R/'original_toc.json').read_text(encoding='utf8'))['entries']
levels={x['unit_id']:x['level'] for x in TOC}
notes={n['note_id']:n for n in D['notes']}
bodygroups={c['unit_id']:g for g in D['groups'] for c in g['components']}
bysection=collections.defaultdict(list)
for n in D['notes']:bysection[bodygroups[n['body_unit_id']]['section']].append(n)

def esc(s):
 return ''.join({'\\':r'\textbackslash{}','&':r'\&','%':r'\%','$':r'\$','#':r'\#','_':r'\_','{':r'\{','}':r'\}','~':r'\textasciitilde{}','^':r'\textasciicircum{}'}.get(c,c) for c in s)

def text(s):
 parts=re.split(r'(⟦p\.[^⟧]+⟧)',s)
 return ''.join((r'\sourcepage{'+esc(p[3:-1])+'}') if p.startswith('⟦p.') else esc(p).replace('\n\n',r'\par ').replace('\n',r'\newline ') for p in parts)

def runs(values,lang):
 out=[]
 for v in values:
  if v['type']=='text':out.append(text(v['text']))
  elif v['type']=='note_ref':
   nid=v['note_id'];number=str(v['original_number'])
   out.append(r'\hypertarget{ref-'+lang+'-'+nid+r'}{}\hyperlink{note-'+nid+r'}{\textsuperscript{'+esc(number)+'}}')
  else:raise ValueError(v)
 return ''.join(out)

def grouptext(g,lang):
 out=[]
 for i,c in enumerate(g['components']):
  # Component anchors remain inside a single paragraph for cross-page fragments.
  if i and lang=='de':out.append(' ')
  label=U[c['unit_id']].get('page_label')
  value=runs(c[lang+'_runs'],lang)
  if label and label!=lastpage[lang] and not value.startswith(r'\sourcepage{'+esc(label)+'}'):
   value=r'\sourcepage{'+esc(label)+'}'+value
  marks=re.findall(r'\\sourcepage\{([^}]+)\}',value)
  if marks:lastpage[lang]=marks[-1]
  if current_mode=='bilingual' and lang=='de':value=re.sub(r'\\sourcepage\{[^}]+\}','',value)
  out.append(r'\hypertarget{'+lang+'-'+c['unit_id']+'}{}'+value)
 return ''.join(out)

PRE=r'''\documentclass[SIZE,a4paper,twoside]{article}
\usepackage{fontspec,xeCJK}
\setmainfont{Times New Roman}
\setCJKmainfont[AutoFakeBold=2,AutoFakeSlant=.2]{SimSun}
\usepackage[GEOMETRY]{geometry}
\usepackage{xcolor,paracol,fancyhdr,hyperref,needspace,xurl,amsmath}
\hypersetup{unicode=true,hidelinks,pdftitle={Gesammelte Schriften I / 拉斯克文集：第一卷},pdfauthor={Emil Lask}}
\setlength{\parindent}{1em}\setlength{\parskip}{5pt}\setlength{\columnsep}{8mm}\setlength{\emergencystretch}{3em}
\tolerance=2000\widowpenalty=10000\clubpenalty=10000
\pagestyle{fancy}\fancyhf{}\fancyhead[LE,RO]{\small Gesammelte Schriften I}
\fancyhead[LO,RE]{\small Emil Lask}\fancyfoot[C]{\thepage}\setlength{\headheight}{14pt}
\DeclareRobustCommand{\sourcepage}[1]{\marginpar{\raggedleft\fontsize{8}{10}\selectfont\color{black!65}S.\ #1}}
\twosided[pm]\marginparthreshold{0}
\setcounter{tocdepth}{4}\setcounter{secnumdepth}{-1}
\makeatletter
\renewcommand\paragraph{\@startsection{paragraph}{4}{\z@}{3.25ex plus 1ex minus .2ex}{1.5ex plus .2ex}{\normalfont\normalsize\bfseries}}
\renewcommand\subparagraph{\@startsection{subparagraph}{5}{\z@}{3.25ex plus 1ex minus .2ex}{1.5ex plus .2ex}{\normalfont\normalsize\bfseries}}
\makeatother
\renewcommand{\contentsname}{目录 / Inhalt}
\begin{document}
'''

def render(mode):
 global lastpage,current_mode
 lastpage={'zh':None,'de':None};current_mode=mode
 bi=mode=='bilingual';langs=['zh','de'] if bi else [mode]
 geometry='a4paper,inner=20mm,outer=23mm,top=21mm,bottom=23mm' if bi or mode=='de' else 'a4paper,margin=25mm'
 geometry+=',marginparwidth=16mm,marginparsep=3mm'
 out=[PRE.replace('SIZE','10pt' if bi or mode=='de' else '11pt').replace('GEOMETRY',geometry)]
 out += [r'\begin{titlepage}\centering\vspace*{25mm}{\Huge 拉斯克文集：第一卷\par}\bigskip{\Large Gesammelte Schriften I\par}\vspace{15mm}{\Large 埃米尔·拉斯克 / Emil Lask\par}\bigskip 欧根·赫里格尔 编 / Herausgegeben von Eugen Herrigel\par\vfill',
  text({'zh':'中文校订版','de':'Deutsche Leseausgabe','bilingual':'中德逐段对照版'}[mode]),
  r'\par\bigskip 依据1923年图宾根J. C. B. Mohr版\par\end{titlepage}',
  r'\noindent 页边“S.”标记为原书印刷页码（含罗马数字前置页），页底数字为本阅读版页码；双语版页标沿中文栏定位，跨页原段连续阅读。原注保留底本页内编号，置于各小节末，并支持跳转与返回。中文单语版原注附德文原文，保留原题名以便检索。\par\clearpage\tableofcontents\clearpage']
 opened=False
 def close():
  nonlocal opened
  if opened:out.append(r'\end{paracol}');opened=False
 def pair(zh,de,small=False):
  nonlocal opened
  if bi:
   if not opened:out.append(r'\begin{paracol}{2}');opened=True
   if small:zh=r'{\small '+zh+'}';de=r'{\small '+de+'}'
   out.extend([zh+r'\par',r'\switchcolumn',de+r'\par',r'\switchcolumn*'])
  else:out.append((zh if mode=='zh' else de)+r'\par')
 def endnotes(section):
  close()
  ns=bysection.get(section,[])
  if not ns:return
  out.append(r'\needspace{6\baselineskip}\subsection*{原注 / Anmerkungen}')
  for n in ns:
   nid=n['note_id'];number=str(n['original_number'])
   page,source,removed=note_display(n,U)
   target=r'\hypertarget{note-'+nid+'}{}'
   mark=r'{\small ['+esc(page)+']} '+r'\textsuperscript{'+esc(number)+'} '
   zh=target+mark+text(n['translation'])+r'~\hyperlink{ref-zh-'+nid+r'}{\textsuperscript{↑}}'
   de=(target if mode=='de' else '')+mark+text(source)+r'~\hyperlink{ref-de-'+nid+r'}{\textsuperscript{↑}}'
   if mode=='zh':zh+=r'\par{\small 原文：'+text(source)+'}'
   pair(zh,de,True)
  close()
 section=None
 for g in D['groups']:
  if section is not None and section!=g['section']:endnotes(section)
  section=g['section']
  if g['kind']=='blank':continue
  if g['section']=='back-matter':
   close();out.append(r'\clearpage\section*{出版附录 / Verlagsanzeige}')
  zh=grouptext(g,'zh');de=grouptext(g,'de')
  if g['kind']=='heading':
   zh=zh.replace(r'\par ',r'\\ ');de=de.replace(r'\par ',r'\\ ')
   close();level=levels.get(g['id'],3)
   if level==0:out.append(r'\clearpage')
   out.append(r'\needspace{7\baselineskip}')
   title=' '.join(v['text'] for c in g['components'] for v in c[('de' if mode=='de' else 'zh')+'_runs'] if v['type']=='text').replace('\n',' ')
   command=['section','subsection','subsubsection','paragraph','subparagraph'][min(level,4)]
   out.append('\\'+command+'['+esc(title)+']{'+(zh+r'\\{\normalsize '+de+'}' if bi else (zh if mode=='zh' else de))+'}')
  else:pair(zh,de,g['kind']=='editorial_note')
 if section:endnotes(section)
 close();out.append(r'\end{document}')
 return '\n'.join(out)

for mode in ['zh','de','bilingual']:
 (O/f'lask_i_{mode}.tex').write_text(render(mode),encoding='utf8')
manifest=dict(canonical_sha256=D['canonical_sha256'],reading_groups_sha256=hashlib.sha256((R/'reading_groups.json').read_bytes()).hexdigest(),
 status='Review TeX generated; compilation and visual acceptance pending',groups=len(D['groups']),notes=len(notes),
 templates={'zh':'Yıkarak Yapmak/work/build_print.py (A4 11pt Times New Roman/SimSun,25mm margins)',
 'bilingual':'tools/render_philosophy.py (A4 10pt,inner20/outer23/top21/bottom23mm,8mm column gap,paracol)'},
 adaptations=['Original printed pages shown in outer margins; bilingual labels follow Chinese column; chapter opening labels restored from canonical page_label','Chinese note text followed by German original for searchable original titles','Original TOC levels reused; headings retain independent note links'])
(R/'edition_build_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
print('Generated zh/de/bilingual review TeX')
if '--compile' in sys.argv:
 for mode in ['zh','de','bilingual']:
  for n in [1,2]:
   p=subprocess.run(['xelatex','-interaction=nonstopmode','-halt-on-error',f'lask_i_{mode}.tex'],cwd=O,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
   (R/f'compile_{mode}_{n}.log').write_bytes(p.stdout)
   if p.returncode:
    print(p.stdout.decode('utf8',errors='replace')[-2000:]);raise SystemExit(p.returncode)
  print(mode,'compiled',flush=True)
