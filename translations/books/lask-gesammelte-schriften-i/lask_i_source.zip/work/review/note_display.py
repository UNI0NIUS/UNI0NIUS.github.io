"""Reading-only note labels; canonical OCR and evidence remain unchanged."""
import re

def note_display(note, units):
    unit = units[note['note_id']]
    match = re.match(r'^\s*(\d+|[iIl!xrz])\)\s*', note['source_text'])
    assert match, note['note_id']
    raw = match[1]
    number = int(raw) if raw.isdigit() else (2 if raw == 'z' else 1)
    assert number == int(note['original_number']), (note['note_id'], raw)
    pages = unit.get('printed_pages', [])
    assert pages, note['note_id']
    return str(pages[0]), note['source_text'][match.end():], match[0]
