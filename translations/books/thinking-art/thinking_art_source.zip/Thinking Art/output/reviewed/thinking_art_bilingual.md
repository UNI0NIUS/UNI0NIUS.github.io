# 思考艺术：唯物主义、劳动、形式

中英逐段对照校订阅读版

校订阅读版 · 2026-10-21。依2020年CRMEP Books底本逐项校对817个单元，含298条原注。未收入原索引（PDF第231—234页），未复制原书17个含图片源页的图像，保留文字与图片来源说明。源页定位均指PDF文件页序，不是原书印刷页码。作者简介及“目前”等表述沿用原书出版时点。编者说明与原注分列。底本许可为CC BY-NC-ND 4.0；原著及图片权利归原权利人。

# 出版与丛书信息

<a id="fm-copyright-01-zh"></a>
2020年由 CRMEP Books 出版，欧洲现代哲学研究中心，金斯顿大学彭林路校区，泰晤士河畔金斯顿，KT1 2EE，伦敦，英国，www.kingston.ac.uk/crmep

<a id="fm-copyright-01-en"></a>
Published in 2020 by CRMEP Books Centre for Research in Modern European Philosophy Penrhyn Road campus, Kingston University, Kingston upon Thames, kt1 2ee, London, UK www.kingston.ac.uk/crmep

<a id="fm-copyright-02-zh"></a>
ISBN 978-1-9993337-4-4（平装）ISBN 978-1-9993337-5-1（电子书）

<a id="fm-copyright-02-en"></a>
isbn 978-1-9993337-4-4 (pbk) isbn 978-1-9993337-5-1 (ebook)

<a id="fm-copyright-03-zh"></a>
本作品电子版依据知识共享署名—非商业性使用—禁止演绎 4.0 国际许可协议（CC-BY-NC-ND）授权。详情请访问 creativecommons.org。

<a id="fm-copyright-03-en"></a>
The electronic version of this work is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License (CC-BYNC-ND). For more information, please visit creativecommons.org.

<a id="fm-copyright-04-zh"></a>
本书各位贡献者依据《1988年版权、设计和专利法》主张其被认定为本作品作者的权利。

<a id="fm-copyright-04-en"></a>
The right of the contributors to be identified as authors of this work has been asserted by them in accordance with the Copyright, Designs and Patents Act, 1988

<a id="fm-copyright-05-zh"></a>
由 illuminati（Grosmont）以 Calluna 字体设计并排版。封面设计：illuminati 的 Lucy Morton。印刷：Short Run Press Ltd（埃克塞特）。

<a id="fm-copyright-05-en"></a>
Designed and typeset in Calluna by illuminati, Grosmont Cover design by Lucy Morton at illuminati Printed by Short Run Press Ltd (Exeter)

<a id="fm-copyright-06-zh"></a>
本书的编目记录可由大英图书馆获取。

<a id="fm-copyright-06-en"></a>
A catalogue record for this book is available from the British Library

<a id="fm-series-01-zh"></a>
## **CRMEP Books**

<a id="fm-series-01-en"></a>
## **CRMEP Books**

<a id="fm-series-02-zh"></a>
CRMEP Books 是伦敦金斯顿大学欧洲现代哲学研究中心的出版品牌。它目前出版两个系列的开放获取电子出版物，均源自该中心组织的研究活动，并以小印量平装本形式印行。**丛书主编** 彼得·奥斯本，伦敦金斯顿大学欧洲现代哲学研究中心主任。

<a id="fm-series-02-en"></a>
CRMEP Books is the imprint of the Centre for Research in Modern European Philosophy, Kingston University London. It currently publishes two series of open access electronic publications derived from research events organized by the Centre, which are also available in short-run paperback editions. **Series editor**  Peter Osborne, Director, Centre for Research in Modern European Philosophy, Kingston University London

<a id="fm-series-03-zh"></a>
**图书** **第1卷** ***Capitalism: Concept, Idea, Image – Aspects of Marx’s Capital Today***，彼得·奥斯本、Éric Alliez、Eric-John Russell 编，2019年，256页。贡献者：Éric Alliez、Étienne Balibar、Tithi Bhattacharya、Boris Buden、Sara. R. Farris、John Kraniauskas、Elena Louisa Lange、Maurizio Lazzarato、Antonio Negri、Peter Osborne、Eric-John Russell、Gayatri Chakravorty Spivak、Keston Sutherland **第2卷** ***Thinking Art: Materialisms, Labours, Forms***，彼得·奥斯本编，2020年。*即出* **第3卷** ***Critique of Strategic Reason***，彼得·奥斯本、Éric Alliez、Howard Caygill 编，2021年。

<a id="fm-series-03-en"></a>
**Books** **Volume 1**  ***Capitalism: Concept, Idea, Image – Aspects of Marx’s Capital*** ***Today***, ed. Peter Osborne, Éric Alliez and Eric-John Russell, 2019, 256 pp. Contributors Éric Alliez, Étienne Balibar, Tithi Bhattacharya, Boris Buden, Sara. R. Farris, John Kraniauskas, Elena Louisa Lange, Maurizio Lazzarato, Antonio Negri, Peter Osborne, Eric-John Russell, Gayatri Chakravorty Spivak, Keston Sutherland **Volume 2**  ***Thinking Art: Materialisms, Labours, Forms***, ed. Peter Osborne, 2020. *Forthcoming* **Volume 3**  ***Critique of Strategic Reason***, ed. Peter Osborne, Éric Alliez and Howard Caygill, 2021.

<a id="fm-series-04-zh"></a>
**小册子** **吉莉安·罗斯纪念讲座** 由 Tom Vaswani 家庭教育信托慷慨资助 **第1册** Rebecca Comay，*Deadlines (literally)*，2020年，32页。*即出* **第2册** Donatella di Cesare，*The Political Vocation of Philosophy*，2021年。**www.kingston.ac.uk/crmep**

<a id="fm-series-04-en"></a>
**Pamphlets** **The Gillian Rose Memorial Lectures** Generously supported by the Tom Vaswani Family Education Trust **Pamphlet 1**  Rebecca Comay, *Deadlines (literally)*, 2020, 32 pp. *Forthcoming* **Pamphlet 2**  Donatella di Cesare, *The Political Vocation of Philosophy*, 2021. **www.kingston.ac.uk/crmep**

# 序言

<a id="preface-h-zh"></a>
## **序言**

<a id="preface-h-en"></a>
## **Preface**

<a id="preface-p001-zh"></a>
欧洲现代哲学研究中心（CRMEP）根据其组织的活动编成了这第二卷文集；本卷各篇文章源自2020年2月29日在伦敦当代艺术学院（ICA）举行的‘思考艺术’会议，当时正值新冠疫情封锁前夕。<a id="ref-zh-preface-1"></a>[1](#note-zh-preface-1) 与以往一样，我们的设想是汇集一批研究取向多样的国内外演讲者，呈现他们正在进行的研究的一部分，以此勾勒当前研究的一个截面：这些研究涉及一系列相关学科内部及跨学科的议题，哲学与一般理论问题在其中都至关重要。本书涉及数字人文、诗学、美术、艺术史、性别研究、哲学本身、视觉文化与后殖民研究。在此，哲学取其较宽泛的意义，被设想为一种跨学科媒介：通过它，可以把各项具体研究的一般理论层面联系起来，并激发对这些层面的批判性反思。唯物主义、艺术与劳动、形式的不稳定性、社会生态与灾难预感这四重主题星丛——从当下的以太中摘取——既连接又区隔了各项发言。

<a id="preface-p001-en"></a>
The contributions to this second volume of essays derived from events organized by the Centre for Research in Modern European Philosophy (CRMEP) have their source in the conference ‘Thinking Art’, held at the Institute for Contemporary Arts (ICA) London on 29 February 2020, immediately prior to the Covid-19 lockdown.<a id="ref-en-preface-1"></a>[1](#note-en-preface-1) As previously, the idea was to assemble an eclectic range of national and international speakers to present parts of their ongoing research, in order to provide a snapshot of current work on topics in which philosophical and general-theoretical issues are at stake within and across a range of related disciplines. Here this includes digital humanities, poetics, fine art, art history, gender studies, philosophy itself, visual culture and postcolonial studies. In its broader sense, philosophy is conceived here as a transdisciplinary medium through which connections may be made between, and critical reflection provoked about, the general-theoretical aspects of concrete investigations. The fourfold thematic constellation of materialisms, art and labour, instabilities of form, and social ecologies and intimations of catastrophe – plucked from the ether of the present – functioned both to connect and to hold apart the various presentations.

<a id="preface-p002-zh"></a>
这一次的统一性构想，在于重提 ICA 过去的一个说法——‘思考艺术’<a id="ref-zh-preface-2"></a>[2](#note-zh-preface-2)——并非为了返回那个时代，而是为了衡量当下与它之间的距离；这种距离体现于当前的关注与忧虑之中。当时正值1990年代初，对哲学与艺术关系的追问，在很大程度上仍由观念艺术的批判遗产与政治遗产，以及这些遗产留给学院艺术研究的种种反美学议程所驱动。在英国，所调动的理论资源主要是德国批判理论、法国差异哲学（包括拉康精神分析）与女性主义艺术史。论战的背景是：人们试图超越传统美学，延续1960年代和1970年代批判运动的势头。当时，传统美学正主要以现象学的形式复兴，借助的是1980年代由德国新表现主义引领的所谓‘绘画回归’。<a id="ref-zh-preface-3"></a>[3](#note-zh-preface-3) 交锋的界线清晰分明。

<a id="preface-p002-en"></a>
The unifying conceit, on this occasion, lay in repeating a trope from the ICA’s past – ‘Thinking Art’<a id="ref-en-preface-2"></a>[2](#note-en-preface-2) – not in order to return to that time, but rather to take the measure of the present’s distance from it, registered in current preoccupations and concerns. Back then, at the outset of the 1990s, interrogation of the relationship between philosophy and art was still largely driven by the critical and political legacies of conceptual art, and the various anti-aesthetic agendas they bequeathed to academic study of art. The theoretical resources deployed, in the UK, were largely those of German critical theory, French philosophies of difference (including Lacanian psychoanalysis) and feminist art history. The polemical context was the attempt to maintain the momentum of the critical movements of the 1960s and 1970s beyond a traditional aesthetics which was being revived at that time, mainly in phenomenological forms, on the back of the so-called ‘return to painting’ of the 1980s, spearheaded by German neo-expressionism.<a id="ref-en-preface-3"></a>[3](#note-en-preface-3) The lines of engagement were clearly drawn.

<a id="preface-p003-zh"></a>
然而，在接下来的十年里，这些界线很快变得模糊：后现象学的法国“情动”哲学以一种将哲学激进主义主张与艺术上的保守主义、隐秘的政治浪漫主义相结合的方式，进入了“美学”所腾出的概念空间。<a id="ref-zh-preface-4"></a>[4](#note-zh-preface-4)

<a id="preface-p003-en"></a>
In the decade that followed, however, those lines quickly became blurred, as post-phenomenological French philosophies of ‘affect’ moved into the conceptual space vacated by ‘aesthetic’, in a manner that combined claims to philosophical radicalism with an artistic conservatism and covert political romanticism.<a id="ref-en-preface-4"></a>[4](#note-en-preface-4)

<a id="preface-p004-zh"></a>
与此同时，新形式的文化管理通过一波波意识形态浪潮，将1980年代的批判倾向收编、学院化，并限制在强加给大学的新文化工业形式之内（其中包括将艺术院校并入大学）；这些浪潮的新自由主义力量仍在不断积聚。<a id="ref-zh-preface-5"></a>[5](#note-zh-preface-5) 随着曾滋养这些倾向的支持性政治文化衰落，那些致力于在*概念*、*政治*与*批判*之间进行三角定位的艺术实践，在市场日益占据主导地位所伴随的制度变迁面前退却了；这些变迁不仅涉及博物馆、画廊及其他艺术空间被整合进娱乐产业，也涉及艺术教育机构本身。对文化工业的批判性构想，被‘创意产业’这一肯定性的、治理性的概念所取代。在新的大学艺术院校里，人们认为，要实现被改称为客户的学生所预期的职业抱负，几乎无需艺术理论反思，甚至无需更为直接的艺术史知识。正是在这一点上，右翼对艺术与人文学科‘精英主义’的攻击，为‘市场民主’提供了最有效的政治论据——此时距离左翼民粹主义版本的同一批判开始改变这些学科本身，已经过去了三十年；这一过程被右翼讥为‘拉低水准’（dumbing down）。

<a id="preface-p004-en"></a>
At the same time, new forms of cultural management appropriated, academicized and contained the critical tendencies of the 1980s within the new cultural-industrial forms imposed on universities (including the incorporation of the art schools), in a series of ideological waves, the neoliberal force of which continues to build.<a id="ref-en-preface-5"></a>[5](#note-en-preface-5) With the decline of the supportive political cultures from which they had arisen, art practices concerned to triangulate relations between *concept*, *politics* and *critique* retreated in the face of institutional developments associated with the growing primacy of markets, involving not only the integration of museums, galleries and other kinds of art spaces into the entertainment industries, but the institutions of art education themselves. Critical conceptions of the culture industry were displaced by affirmative, governmental concepts of ‘creative industries’. In the new university art schools, little art-theoretical reflection, or even more straightforward forms of art-historical knowledge, were judged necessary for the projected vocational aspirations of students redesignated as clients. This was the point at which right-wing attacks on the ‘elitism’ of the arts and humanities provided ‘market democracy’ with its most effective political argument – three decades after the left-populist version of that critique had begun to transform those disciplines themselves, in a process derided by the Right as ‘dumbing down’.

<a id="preface-p005-zh"></a>
今天，为英语世界艺术界奠定思想基调的哲学辩论，主要涉及所谓的‘新’唯物主义——尤其是‘活力’唯物主义与‘思辨’唯物主义；劳动不断变化且不稳定的性质；社会关系与技术的去物质化效应对形式范畴稳定性的冲击；以及生态危机、后殖民性与人类世。本书的四个部分以各种批判性的方式分别处理这些主题的变体。把各篇文章统一起来的，不是某种特定理论立场，而是一种关切：维持对艺术及其相关话语的思考，这种思考对所有企图把新的生态自然主义与活力论当作停止从社会角度思考艺术的托词的做法保持怀疑。在艺术语境中，回避社会性思考无法不变成一种新美学主义——无论其理论模式为何，也无论其声称的政治意图为何。

<a id="preface-p005-en"></a>
Today, the philosophical debates that set the intellectual tone of the anglophone artworld largely concern so-called ‘new’ – especially ‘vital’ and ‘speculative’ – materialisms; the changing and precarious character of labour; the dematerializing effects of social relations and technologies on the destabilization of formal categories; and ecological crisis, postcoloniality and the Anthropocene. The four sections of this book take up variants of these themes, respectively, in variously critical ways. What unifies the essays is not any particular theoretical stance, but a concern to maintain a thinking of art and its related discourses that is sceptical of all attempts to use the new eco-naturalisms and vitalisms as an alibi for stopping thinking about art socially. In an art context, the flight from thinking socially cannot avoid becoming a neo-aestheticism – whatever its theoretical modalities and purported political intent.

<a id="preface-p006-zh"></a>
三十年前，上一本与本卷同名的文集在导论开篇提出了这样一个问题：‘艺术究竟是否需要哲学，哲学究竟是否需要艺术？如果需要，是以何种方式？’这个问题当时没有得到回答，今天仍然一如既往地开放而充满争议；在艺术与哲学双方，它引发焦虑的可能性也与当时同样大，甚至更大。人们或许会想，这更是继续追问它的理由。

<a id="preface-p006-en"></a>
The question that opened the Introduction to the previous collection of essays with the same title as this one, thirty years ago – ‘In what way, if any, does art need philosophy, or philosophy art?’ – unanswered then, remains as open and contested today as it ever was; and equally, if not more likely to provoke anxiety, on both sides. All the more reason, one might think, for continuing to ask it.

## 原注

<a id="preface-n001-zh"></a><a id="note-zh-preface-1"></a>
[1] Klara Kemp-Welch 与 Christian Nyampeta 未能出席会议，但慷慨地允许其作品在此发表。 [返回](#ref-zh-preface-1)

<a id="preface-n001-en"></a><a id="note-en-preface-1"></a>
[1] Klara Kemp-Welch and Christian Nyampeta were unable to attend the conference, but have generously made their work available here. [返回](#ref-en-preface-1)

<a id="preface-n002-zh"></a><a id="note-zh-preface-2"></a>
[2] 参见 Andrew Benjamin 与 Peter Osborne 编，*Thinking Art: Beyond Traditional Aesthetics*，London: Institute of Contemporary Arts (ICA), 1991——这是 ICA 哲学论坛的首部出版物；该论坛于前一年由其时任演讲项目主任 Linda Brandon 创立。 [返回](#ref-zh-preface-2)

<a id="preface-n002-en"></a><a id="note-en-preface-2"></a>
[2] See Andrew Benjamin and Peter Osborne, eds, *Thinking Art: Beyond Traditional* *Aesthetics*, London: Institute of Contemporary Arts (ICA), 1991 – the inaugural publication of the ICA’s Philosophical Forum, set up the previous year by its then Director of Talks, Linda Brandon. [返回](#ref-en-preface-2)

<a id="preface-n003-zh"></a><a id="note-zh-preface-3"></a>
[3] 在英国，具有标志性的展览是1981年在皇家艺术学院举办的 *A New Spirit in Painting*。该展艺术家的作品今年在白教堂画廊以 *The Return of the Spirit in Painting* 重新汇集，并同场举办姊妹展 *Radical Figures: Painting in the New Millennium*。这一对展览究竟揭示了绘画（作为绘画）持久的“激进性”，还是仅仅重申其周期性“回归”日益加深的保守政治功能，仍是一个悬而未决的问题。 [返回](#ref-zh-preface-3)

<a id="preface-n003-en"></a><a id="note-en-preface-3"></a>
[3] In the UK, the emblematic exhibition was *A New Spirit in Painting* at the Royal Academy of Arts in 1981. Work by artists from that show have been reassembled this year, at the Whitechapel Gallery, in *The Return of the Spirit in Painting*, alongside a companion exhibition, *Radical Figures: Painting in the New Millennium*. Whether this pair of shows reveals the enduring ‘radicalism’ of painting (qua painting) or merely reaffirms the deepening conservative political function of its cyclical ‘returns’ is a moot point. [返回](#ref-en-preface-3)

<a id="preface-n004-zh"></a><a id="note-zh-preface-4"></a>
[4] 这一运动的节奏受到翻译时间颇为偶然的安排的多重决定。利奥塔1974年的《力比多经济学》（*Libidinal Economy*）于1993年首次以英文出版；德勒兹1981年的《弗兰西斯·培根：感觉的逻辑》（*Francis Bacon: The Logic of Sensation*，这些文本中影响最大的一部）于2003年出版。与此同时，利奥塔1971年更具哲学分量的著作《话语，图形》（*Discourse, Figure*）直到2019年才译成英文。 [返回](#ref-zh-preface-4)

<a id="preface-n004-en"></a><a id="note-en-preface-4"></a>
[4] The rhythm of this movement was overdetermined by the somewhat haphazard temporality of translation. Lyotard’s 1974 *Libidinal Economy* first appeared in English in 1993; Deleuze’s 1981 *Francis Bacon: The Logic of Sensation* (the most influential of these texts) in 2003. Meanwhile, Lyotard’s more philosophically significant work of 1971, *Discourse, Figure,* was not translated into English until 2019. [返回](#ref-en-preface-4)

编者说明：原文作2019年，译文照录。《话语，图形》的英译本已于2011年问世；《Parrhesia》2011年第12期刊载英译节选时明确说明了这一点。明尼苏达大学出版社现有产品页标注的2019年10月22日是该页所列平装版的出版日期。 https://parrhesiajournal.org/parrhesia12/parrhesia12_lyotard.pdf https://www.upress.umn.edu/9780816645664/discourse-figure/

<a id="preface-n005-zh"></a><a id="note-zh-preface-5"></a>
[5] 例如，柏林艺术学院（Hochschule der Künste Berlin）于2001年成为大学；伦敦艺术大学（University of the Arts London）于2003–2004年间由伦敦大部分艺术院校合并而成。 [返回](#ref-zh-preface-5)

<a id="preface-n005-en"></a><a id="note-en-preface-5"></a>
[5] The Hochschule der Künste Berlin became a university in 2001, for example; University of the Arts London was formed in 2003–4 out of the bulk of the London arts’ colleges. [返回](#ref-en-preface-5)

# 致谢

<a id="ack-h-zh"></a>
## **致谢**

<a id="ack-h-en"></a>
## **Acknowledgements**

<a id="ack-p001-zh"></a>
我要感谢 Richard Birkett 于2018年发起伦敦当代艺术学院与 CRMEP 之间重启的合作，这次合作促成了本书所源自的会议；也要感谢 ICA 策展人 Nydia Swaby 与 Sara Sassanelli，她们接手此事，并以如此从容的态度将其推进至完成。

<a id="ack-p001-en"></a>
I would like to thank Richard Birkett for initiating the renewed collaboration between the ICA London and CRMEP in 2018, which led to the conference from which this book derives; and the ICA curators Nydia Swaby and Sara Sassanelli, for taking it on and seeing it through to completion with such equanimity.

<a id="ack-p002-zh"></a>
彼得·奥斯本，2020年6月

<a id="ack-p002-en"></a>
PETER OSBORNE, june 2020

# 第一部　唯物主义

<a id="part1-title-zh"></a>
## **唯物主义**

<a id="part1-title-en"></a>
## MATERIALISMS

## 第1章　数字唯物主义：六只手、机器辅助、怒不可遏

<a id="ch01-title-zh"></a>
## 数字唯物主义：六只手、机器辅助、怒不可遏

<a id="ch01-title-en"></a>
## Digital materialism: six-handed, machine-assisted, furious

<a id="ch01-author-zh"></a>
卡罗琳·巴塞特

<a id="ch01-author-en"></a>
CAROLINE BASSETT

<a id="ch01-q001-zh"></a>
> 环顾四周，然后径直切入。

<a id="ch01-q001-en"></a>
> Take a look around, then cut through.

<a id="ch01-a001-zh"></a>
埃莱娜·西苏<a id="ref-zh-ch01-1"></a>[1](#note-zh-ch01-1)

<a id="ch01-a001-en"></a>
Hélène Cixous<a id="ref-en-ch01-1"></a>[1](#note-en-ch01-1)

<a id="ch01-p001-zh"></a>
新媒介唯物主义是数字媒介研究的一种模式，它宣称自己更接近事物的“真相”，并拒斥其他取径，认为它们是再现性的、只关心图像与扭曲——因而离这种现实或真相更远。这一判断建立在一种预设之上：物质——在此即计算与数字技术的具体材料及其所促成之物——正是事情的核心。与这一研究优先项相一致的是对媒介特定的“怪异物质性”的探索，或以明确的后批判立场思考信息系统的动态。下面没有什么可被揭示，没有超越性之物，也几乎没有在先之物来限定已经到来或将要到来的一切。

<a id="ch01-p001-en"></a>
New media materialism is a mode of digital media studies that declares itself closer to the ‘truth’ of things, and that rejects other approaches as representational, as interested in the image and distortions – and therefore further from this reality or truth. This judgement is founded on a presumption that matter – in this case, the specific materials of computational and digital technologies and what they enable – is at the very heart of the matter. Consonant with this research priority are explorations of the ‘weird materialities’ of the medium-specific, or considerations of the dynamics of information systems that are determinedly post-critical. There is nothing underneath to be revealed, nothing beyond, and almost nothing before to condition what has come, or what will come after.

<a id="ch01-p002-zh"></a>
这一图景需要被炸开，以服务于作为政治计划的技术女性主义——该计划处理性别不公，这种不公以特定方式被经验，并与其他歧视相交织；或者更系统地说，它被理解为始终已经与其他形式的不平等——尤其是种族、阶级、性与健全主义的不平等——纠缠在一起。

<a id="ch01-p002-en"></a>
This vision needs exploding, in the interests of technological feminism as a political project that addresses gender injustices, experienced in particular ways as they intersect with other discriminations, or, to put this more systematically, understood as always already entangled with other forms of inequality – those of race, class, sexuality, ableism, notably.

<a id="ch01-p003-zh"></a>
这一图景也需要被探索，因为即便新媒介唯物主义有问题，它也回应了一个时刻，满足了一种需要——一种与新兴技术形式接触和相遇的需求；这种需求不断逼问：我们所说的活动或能动性（人类使用者的、机器的、二者互动的）意味着什么，以及我们所说的赋予生命或活力（animation）、活性、智能、智能生命又意味着什么。

<a id="ch01-p003-en"></a>
This vision also needs exploring, because even if new media materialism is problematic it responds to a moment, addressing a need – a demand for engagement and encounter with emerging forms of technology – that insistently provokes questions not only about what we mean by activity or agency (that of human users, that of machines, their interactions) but also what we mean by animation, liveness, intelligence, intelligent life.

<a id="ch01-p004-zh"></a>
本文既是对新唯物主义媒介研究的具体考察，也探讨对更广阔局势的一次较早回应——《愤怒》（*Furious*），一部合著的专著兼手册，它要求重新思考对数字的物质研究，并坚持这种重新思考可以是批判性的。<a id="ref-zh-ch01-2"></a>[2](#note-zh-ch01-2) 它承认新唯物主义对数字媒介研究的吸引力，承认在计算无处不在的当代处境中寻找批判立足点之难，也承认纯粹再现性分析的问题。我们也是唯物主义者，但不是“新唯物主义”意义上的唯物主义者——尤其是因为，我们不承认新唯物主义者所坚持的物质分析与历史唯物主义分析之间的绝对断裂。

<a id="ch01-p004-en"></a>
This essay at once constitutes a specific investigation of new materialist media studies and explores an earlier response to the broader conjuncture, *Furious*, a jointly authored monograph/ manual demanding a reconsideration of material studies of the digital and insisting that such a reconsideration can be critical.<a id="ref-en-ch01-2"></a>[2](#note-en-ch01-2) It recognizes the appeal of new materialism for digital media studies, the difficulty of finding a critical perch in the contemporary situation of pervasive computation, and problems with purely representational analysis. We are also materialists, although not ‘new materialism’ materialists – not least because we do not recognize the absolute cleavage between material analysis and historically materialist analysis that new materialisms insist upon.

<a id="ch01-p005-zh"></a>
《愤怒》部分地通过捍卫具身性来回应新唯物主义的主张：把理性理解为具身的、充满激情的、情动的，同时也是逻辑推理的事情。此外，它用具身性（身体的物质性）来思考信息学的物质性。这样做当然使它归于一个在这方面积累了深厚经验的传统：数十年来，女性主义一直在思考技术、认识论与本体论，以及它们与在特定世界秩序中生成的（以不同方式可获得的）可能性之间的关系。而且，它始终关注实例化过程的溢出、杂乱与不完整。正如埃莱娜·西苏1975年对女性所说：“在一次或多或少有意识的计算结束时，她找到的不是她的总和，而是她的差异。”<a id="ref-zh-ch01-3"></a>[3](#note-zh-ch01-3)

<a id="ch01-p005-en"></a>
*Furious* responds to the claims of new materialism, in part, through a defence of embodiment; understanding rationality as embodied, passionate, affective, as well as a matter of logical ratiocination. Moreover it uses embodiment (the materiality of bodies) to think about the materiality of informatics. Doing so, of course, it attaches itself to an expert tradition: feminism has thought about technology, epistemology and ontology and/in relation to the (differently available) possibilities of becoming in a particular world order for decades now. Moreover, it has always been interested in instantiation as excessive and untidy, as incomplete. As Hélène Cixous put it in a 1975 address to women, ‘At the end of a more or less conscious computation, she finds not her sum but her differences.’<a id="ref-en-ch01-3"></a>[3](#note-en-ch01-3)

<a id="ch01-p006-zh"></a>
***论清单***  
新唯物主义、数字技术与活力论之间关系的政治是什么？这种关系如今为何重要？这样提出问题已经作出一种预设，或已优先选择某种探究模式。这预设了*存在*一种有待探索的关系，而且其意义是政治的。有些人也许更愿意谈论物质、数字与生命，并只通过逗号的“温柔纽结”把它们连接起来。<a id="ref-zh-ch01-4"></a>[4](#note-zh-ch01-4) 这或许会产生一种被清除了那些恼人的“额外”主义（例如女性主义）的联系——许多新唯物主义觉得，这些主义会把*事情*搞砸。

<a id="ch01-p006-en"></a>
***Of lists***  
What are the politics of the relationship between new materialism, digital technologies and vitalism? How does this relationship matter now? To frame the question this way is already to make an assumption, or to prioritize a particular mode of investigation. It is to presume that there *is* a relationship to be explored, and that its significance is political. Some might prefer to talk of the material, the digital and the vital, and to join them only through the ‘gentle knot’ of the comma.<a id="ref-en-ch01-4"></a>[4](#note-en-ch01-4) This might produce a connection purged of those irritating ‘extra’ isms (feminism, for instance) that are felt by many new materialisms to screw *things* up.

<a id="ch01-p007-zh"></a>
无论这些联系以何种方式建立（此中关系重大），关于唯物主义、活力与数字或计算的问题，在当前局势中都具有特殊的力量。<a id="ref-zh-ch01-5"></a>[5](#note-zh-ch01-5) 一般意义上的数字发展，尤其是人工智能的发展，使一些长期存在的通俗联想甚至等同关系重新凸显：机器的活泼性与有机或人类“生命”本身的思考之间的联想；人类能动性与机器能动性之间的联想；以及媒介自我构成即讯息的能力（麦克卢汉令人难忘地把灯泡理解为一种媒介技术）与常常也被理解为“无内容”的活力论之间的联想。<a id="ref-zh-ch01-6"></a>[6](#note-zh-ch01-6)

<a id="ch01-p007-en"></a>
Whichever way these connections are made (much hangs on that) questions concerning materialisms, vitality and the digital or computational arise with a particular force in the current conjuncture.<a id="ref-en-ch01-5"></a>[5](#note-en-ch01-5) Digital developments in general and in AI in particular give revived salience to long-standing popular associations or even equivalences: between the liveliness of machines and considerations of organic or human ‘life’ itself; between human and the machinic agency; and between the capacity of the medium to constitute itself as the message (McLuhan memorably understood the light bulb as a medium technology) and vitalism which is often also understood as ‘without content’.<a id="ref-en-ch01-6"></a>[6](#note-en-ch01-6)

<a id="ch01-p008-zh"></a>
这些联想如何被理解、其意义可能是什么，是当前数字研究关注的重点，也在公共文化中大量出现——例如作为媒介艺术、在辩论中、在小说中。这一话语作为一个整体，有一个特征：倾向于把实际与预测相融合，把技术未来的想象与现有可能性相融合。这种倾向在更专业的领域中也可见，并可能在那里产生一个起确证作用的（短）回路。例如，社交媒体系统的机器学习系统中所实例化的人工智能算法，也许可以成为在现有计算系统中识别出某种机器活力论的依据。它们的真实存在随后被当作证据，证明关于不久将出现之物、真正的智能或奇点的预测是可靠的；在某些情形中，这采取觉醒的人工生命的形式。我们不妨把这种兴起称为后人类活力论的一种形式。

<a id="ch01-p008-en"></a>
How these associations are understood and what their significance might be preoccupy current digital scholarship, and figure largely in public culture – as media art, in debates, in fiction, for instance. A feature of this discourse taken as a whole is its tendency to fuse the actual with the predicted; imaginaries of technological futures with extant possibilities. This tendency is also in evidence in more specialist registers where it may produce a validatory (short) circuit. The AI algorithms instantiated in machine learning systems in social media systems, for instance, might be grounds for the identification of a kind of machinic vitalism in extant computational systems. Their real existence is then taken as evidence of the reliability of predictions of what will soon arise, true intelligence, or Singularity, in some cases taking the form of awakening artificial life. Let us call this rising a form of post-human vitalism.

<a id="ch01-p009-zh"></a>
这种发展究竟可能带来善还是恶，在那些最自信地预测其到来的人中间意见分歧。一些奇点论的信奉者对未来生命的新形式明显充满热情；另一些人则宿命般地确信奇点将至，但对它所开启的未来（人类）存在前景更为悲观。<a id="ref-zh-ch01-7"></a>[7](#note-zh-ch01-7)

<a id="ch01-p009-en"></a>
Whether such a development would be likely to be for good or ill divides opinions among those who most confidently predict its coming. Some Singularity adherents are markedly enthusiastic about emerging forms of future life; others, fatalistically sure of the advent of Singularity, are more pessimistic about the prospects for future (human) being it opens up.<a id="ref-en-ch01-7"></a>[7](#note-en-ch01-7)

<a id="ch01-p010-zh"></a>
***论愤怒***  
对“这一切”，对当前局势的样貌、感受、运作和秩序，另一种回应是愤怒。这正是我想开始的地方。我主张，愤怒是对科技产业的发展优先项与轨迹的一种正当回应——这些优先项与轨迹在多个领域以各种尺度运作；愤怒也是对这些轨迹如何被塑造和决定、对其想象所许诺之物的正当回应。这种愤怒之所以正当，是因为现在和将来都有东西正在被损害、削减、破坏和夺走。一个关键问题是缺乏抱负，缺乏对一切超出市场所赋予价值之物的恰当*关怀*，即便这些事物仍被束缚在市场的限制性逻辑之中。

<a id="ch01-p010-en"></a>
***Of fury***  
A different response to ‘all this’, to the current conjuncture as it looks, as it feels, as it operates and as it orders, is fury. And that is where I want to begin. I assert that fury is a justifiable response to development priorities and trajectories of the tech industries as these operate at various scales across multiple fields; a justifiable response to the ways in which these trajectories are shaped and determined, and to what their imaginaries promise. It is a fury that is justified because of what is being damaged, curtailed, undermined and taken away, now and for the future. A key problem is a lack of ambition, a lack of proper *care* for all that which exceeds the value it is given by the market, even as it is bound up within its constraining logics.

<a id="ch01-p011-zh"></a>
此外，我主张，那些把对活力的援引与关于物质性数字物具有先在外在规定性的断言（本体论上的优先性主张）捆绑在一起，并把二者（至少可以肯定，未能将二者与这种许诺分开）附会于数字技术发展即社会进步（更多计算、更多生命）这一未经检验的善的许诺的理论化，正面临产生一种构形的危险：这种构形与上述轨迹捆绑、为其张目，并最终*帮助实现*它们。而不是，比如，开辟各种可能性，以创造和部署智能技术来重新思考可能性的视域和欲望的塑形。我感兴趣的是这种反意识形态构形的意识形态分量，以及它所产生或认可的物质操作与影响，二者相互纠缠。

<a id="ch01-p011-en"></a>
Further, I argue, theorizations that bind up invocations of vitality with assertions of the prior external determination of material digital things (ontological claims for priority) and attach both (or, certainly, fail to detach them) to the promise of digital advance as progress (more computation, more life), as an unexamined good, are in danger of producing a formation bound up with, underscoring and ultimately *helping to deliver* these kinds of trajectories. This rather than, for instance, opening up possibilities for creating and deploying intelligent technologies to rethink the horizons of the possible, and the shaping of desire. I am interested in both the ideological heft of this kind of anti-ideological formation and in the material operations and impacts it produces or endorses, these being entangled.

<a id="ch01-p012-zh"></a>
如果愤怒作为回应显得过于强烈，那么请想想人工智能解决主义在环境危机中的援引；想想把太空探索当作对行星毁灭的回应，或某种通过冷冻保存进入医学上先进的未来时间并重获生命的许诺。在这类解决方案中，总还有另一个空间，总还有另一个时间。或者想想为老年人设计的服务机器人所提供的“友谊套餐”。这里，可替换的机器人被用来交换那个具体的他者——我的朋友，那个人。这种交换的支撑是机器人作为“几乎真的活着”之物的吸引力。这个机器人能成为我的朋友吗？如果你头脑已不如从前，如果你（或为你提供服务的英国国民医疗服务体系，NHS）负担不起“人类”照护，它就能。这里的问题不在于特定任务本身的自动化，也不在于机器不断扩大的能动性，而在于这类（反）社会契约的许诺所包含的替代性造假——以及它对*定价*的依赖。

<a id="ch01-p012-en"></a>
If fury seems too strong as a response, consider the invocation of AI solutionism in relation to environmental crisis; space exploration as a response to planetary devastation, or the promise of renewed life in some cryogenically accessed and medically advanced future time. There’s always another space, always another time, to be had in these kinds of solutions. Or consider the ‘friendship packages’ offered by service robots designed for old people. Fungible robotics are here being offered in exchange for the specific other, my friend, that person. This an exchange underpinned by the appeal of the robot as the almost really alive. Can this robot be my friend? It can if your mind is not what it was and if you (your NHS) cannot afford ‘human’ care. The issue here is not the automation of particular tasks per se, nor the expanding agency of machines, but the substitutional fakery entailed in the promise of this kind of (anti-) social contract – and its reliance on *pricing*.

<a id="ch01-p013-zh"></a>
这些是残酷的例子。这里援引它们，是为了强调这些问题多么具有政治性，并追问它们*如何*具有政治性——这两者并不完全相同。我希望它们指向这样的方式：生命的许诺、奇点人工智能的完满生命，或在更世俗的领域中被归于特定计算活动形式（机器学习、涌现能动性、机器人人格）的准活力论，能够与计算资本主义及其骇人听闻的不平等的结构相协调，甚至能够*促成*这种结构。人工友谊在字面上就是矛盾。另一种关系是可能的。

<a id="ch01-p013-en"></a>
These are brutal examples. They are invoked here to insist on how political these issues are, and to ask *how* they are political, which is not quite the same thing. I hope they gesture toward ways in which the promise of life, the full life of Singular AI or, in more mundane spheres, the quasi-vitalism ascribed to particular forms of computational activity (machine learning, emergent agency, robotic personality) can align with, indeed can *contribute* to, the structuring of computational capitalism with its obscene inequalities. Artificial friendship is a contradiction in terms. Another relationship is possible.

<a id="ch01-p014-zh"></a>
***强制性的（计算）资本主义？***  
居于机器人技术核心（或者说头部）的人工智能技术当然属于数字技术，而高端人工智能项目与想象可以被理解为马克·费舍尔令人难忘地称为资本主义现实主义的更大场景中的一个异域（但同样不真实）时刻。<a id="ref-zh-ch01-8"></a>[8](#note-zh-ch01-8) 如今，这场景以我们熟悉的方式采取计算形式，包括机器学习、大数据、平台资本主义、无处不在的审查，以及日常生活和工作中的进一步自动化。埃伦·梅克辛斯·伍德曾断言，当市场无法逃避时，资本主义就变得“强制性”了；作为其变体，计算资本主义也可以这样说。<a id="ref-zh-ch01-9"></a>[9](#note-zh-ch01-9) 鉴于其全球触及范围和无孔不入的尺度化——从身体内部及远小于身体的尺度，一直到卫星——我们无法像某些人建议的那样简单地*选择*“逃离信息域”。<a id="ref-zh-ch01-10"></a>[10](#note-zh-ch01-10) 反计算——有选择地拒斥计算，而非拒斥它所表述的社会关系——并不构成批判性技术政治的基础，因为这两个范畴无法被拆开，或者说拆开就会损害双方。然而，回应圈地处境并非不可能，即便它很可能轻易显得不切实际。毕竟，费舍尔关于资本主义现实主义的要点是：它制造出不可避免性的表象——并把这种表象投射到未来。

<a id="ch01-p014-en"></a>
***Compulsory (computational) capitalism?***  
The AI technologies at the heart of robotics (or at the head of them) are of course digital technologies, and high-end AI projects and imaginaries can be understood as an exotic (but just as unreal) moment in the larger scene of what Mark Fisher memorably called capitalist realism,<a id="ref-en-ch01-8"></a>[8](#note-en-ch01-8) now taking on computational form in ways we are familiar with. These ways include machine learning, big data, platform capitalism, pervasive censorship, further automation in the everyday and at work. Ellen Meiksins Wood claimed capitalism became ‘compulsory’ when the market could not be escaped; we might say the same for computational capitalism as a variant of this.<a id="ref-en-ch01-9"></a>[9](#note-en-ch01-9) We cannot simply *choose* to ‘escape the infosphere’, as some suggest, given its global reach and its pervasive scaling – from the interior of the body and far below that scale, right up to the satellite.<a id="ref-en-ch01-10"></a>[10](#note-en-ch01-10) Anti-computing, a selective rejection of the computational rather than the social relations it articulates, does not provide the basis for a critical technical politics, because the two categories cannot be unbound, or not without damage to each side. Responding to the situation of enclosure, however, is not impossible, even if it may all too easily appear to be unrealistic. Fisher’s point about capitalist realism, after all, was that it produces the appearance of inevitability – and projects that into the future.

<a id="ch01-p015-zh"></a>
眼下感到愤怒的一个理由是：如果市场的视域能被超越，技术的未来本可以有所不同——例如，关怀可以被重新校准，智能机器与人类之间的互动可以被更有创造性、更有成效、更少还原地探索，或者太空不被视为一个普遍市场。这个论点更难成立，因为计算正以某些方式来到我们面前，正被*给予*我们。

<a id="ch01-p015-en"></a>
One reason to be furious right now is that the technological future could be different if the horizon of the market could be exceeded – so that care, for instance, was recalibrated, or so that interactions between intelligent machines and humans could be more creatively, fruitfully and less reductively explored, or so that space was not viewed as a universal market. This case is the harder to make because of ways in which the computational is coming to us, is being *given* to us.

<a id="ch01-p016-zh"></a>
我在此尤其关心的是，关于技术媒介的物质特定性构成当代生命形式（数字存在、人工存在、赛博格存在）之基础的主张，与关于人工生命、人工能动性或活力的主张，如何相互支持。它们由此发挥遮蔽作用，遮蔽能动性形式与行动模式之间、活动与自主性之间的一系列区分或连接。这些区分、它们的维持或消解，都需要被追问。在某些形式中，这种区分的抹除有助于生产一种可感的物质“现实”（一种现实主义），这种现实可能无法被争辩（因为它以本体论为基础），而只能被修改或调制（在此意义上属于“后”批判）。源于本体论的不可争辩之物，应区别于强制性之物：如前所述，后者通过社会关系被安排为一种技术—社会秩序，而这种秩序可以被拒绝。

<a id="ch01-p016-en"></a>
What I am concerned about in particular here are the ways in which claims made about the material specificity of technical media as that which underpins contemporary forms of life (digital being, artificial being, cyborg being) and claims about artificial life or agency or vitality come to support each other. They thereby function to obfuscate a series of distinctions or conjunctions between forms of agency and modes of action, and between activity and autonomy. These distinctions, their maintenance or dissolution, demand interrogation. In some forms their elision contributes to producing a felt material ‘reality’ (a realism) that may not be contested (in that it is based on ontology) but only modified or modulated (and is in this sense ‘post’-critique). The non-contestable, which derives from the ontological, is to be distinguished from the compulsory, as that which, to recap, is ordered through social relations, as a techno-social order, which may be refused.

<a id="ch01-p017-zh"></a>
这里或许有益的做法是承认：智能机器与人工生命或能动性之间的联系，在这个时代正被重新建立，但它们同样是长期存在的。20世纪初以来电影及其他领域中的机器人诡异感的兴起就表明了这一点。《大都会》（*Metropolis*）会是明显的例子。然而，这些联系以不同方式被处理，并采取新形式——这或许是必要的，因为一方面，这种联系似乎要求被建立（机器的活泼性指向它们的能动性），另一方面，它又包含一种令人不适的结合。试想，计算常常因其*绝对无误*、因其公正、中立、被动、因其能运算数字而受到重视。当程序明显未能按计划运行时，批评往往集中在自动过程未能足够自动或足够人工。人类偏见混入了算法。关切在于人类对新机器“灵魂”的腐蚀：在这一尺度的一端，是由大众媒介训练数据生产出来的“纳粹”机器人；在另一端，是学者们根深蒂固的*理论化*倾向。

<a id="ch01-p017-en"></a>
It is perhaps salutary here to recognize that connections between intelligent machines and artificial life or agency, which are being made afresh in this era, are also long-standing. The rise of the robotic uncanny in films and elsewhere from the early twentieth century points to this. *Metropolis* would be the obvious example. However, these connections are worked through in different ways and take new forms – this being necessary perhaps because if, on the one hand, the link seems to demand to be made – the liveliness of machines points to their agency – on the other it entails an uncomfortable joining. Consider that the computational is often valued for being *dead right*, for being impartial, neutral, passive, for running the numbers. Criticism when the programme conspicuously fails to run as planned often focuses on the failure of an automatic process to be automatic or artificial enough. Human bias got into the algorithm. The concern is with the human corruption of the ‘soul’ of the new machine: at one end of this scale, mass media training data-producing ‘Nazi’ robots’; on the other, academics’ inveterate tendency to *theorize*.

<a id="ch01-p018-zh"></a>
或者以奇点话语为例，它是一个更普遍构形的提喻，有助于凸显这里产生的张力。奇点科学当然赞同对可计算之物的偏好，并在评估该领域的物质发展时聚焦于此——例如，如果一台计算机每分钟的计算次数超过某个特定数目，它可能做什么。另一方面，它又容纳一种大规模的、多半未经审视的活力论。因此，在奇点辩论中，活力生命与绝对工具主义的悖论被放大了。在更世俗的语境中，它也在另一个层面运作。我在此指的是类似话语的普遍流通：一种充满张力或悖论性的等同——它说生命被编码，所以算法代码就是生命。我们*就是*我们的虚拟自我吗？这个问题经常被提出。

<a id="ch01-p018-en"></a>
Or take Singularity discourse, a synecdoche for a more general formation, and useful to press home the tensions arising here. Singularity science certainly subscribes to the preference for the calculable and is focused on this when assessing material developments in this field – developments such as what a computer may do if it surpasses a particular number of calculations a minute, let’s say. On the other hand, it entertains a mostly unexamined vitalism operating on a grand scale. The paradox of vital life and absolute instrumentalism is thus writ large in Singularity debates. It is also found operating in a different register in more mundane contexts. I am pointing here to the general circulation of a similar discourse of tensioned or paradoxical equivalence – the one that says life is coded, and so algorithmic code is life. *Are* we our virtual selves? This question is routinely asked.

<a id="ch01-p019-zh"></a>
***数字唯物主义***  
一个较少被提出、出现在更具理论性的语域中的问题是：这种等同或混同，究竟是通过一种还原或抽象模式（借助基于系统论的控制论叙述，把机器与人的行动化约为系统性抽象）构成的，还是通过一种新的或复兴的后人类（或反人类）活力论构成的？事实上，这两种取径往往相互逆转。十年前，斯科特·拉什指出，数字媒介系统的兴起带来了一种活力论的复兴，它理解的不是“以生命看待媒介，而是以媒介看待生命”，从而产生了“信息是活的”这类说法。<a id="ref-zh-ch01-11"></a>[11](#note-zh-ch01-11) 这并不完全是活力唯物主义，而是数字唯物（主义），它意味着对一种活力物质的描述。拉什认为，这种复兴（他称之为新活力论的兴起——我们或可称之为数字活力论）之所以发生，“是因为内容本身，乃至生命本身，已被卷入金融、信息和媒介的全球流动”。他由此论证，这种活力论形式植根于一种媒介或信息启发法。如果我们接受——*与麦克卢汉相反*——新媒介的主导内容就是媒介本身，这一说法或许更有说服力。再媒介化理论迷恋旧媒介的形式，接受一种固定而实则偶然的内容/媒介硬性区分，并表现出一种有问题的媒介序列感，因而被过分强调了。

<a id="ch01-p019-en"></a>
***Digital materialism(s)***  
A question asked less often, figuring in more theoretical registers, is whether this equivalence or conflation is constituted through a mode of reduction or abstraction (via a cybernetic account based on systems analysis in which machine and human actions are rendered into systemic abstraction) or by way of a new or revived form of post-human (or anti-human) vitalism. The two approaches in fact tend to reverse into each other. A decade ago Scott Lash noted that the rise of digital media systems produced the revival of a form of vitalism that understood not ‘media in terms of life, but life in terms of media’, producing talk of ‘information is alive’.<a id="ref-en-ch01-11"></a>[11](#note-en-ch01-11) This is not quite a vital materialism, but digital material(ism) as entailing the description of a vital material. Lash suggested that this revival (the rise of what he terms a neo-vitalism – which we might term a digital vitalism) occurred ‘because content itself and indeed life itself is swept up in the global flows of finance, information and media’. He thus argues that this form of vitalism has its roots in a media or information heuristic. This might be the more persuasive if we accept – *pace* McLuhan – that the dominant content of new media is the medium itself. Remediation theory, with its obsession with the forms of old media, and which accepts as fixed a hard content/medium division that is contingent, and that also exhibits a problematic sense of medium seriality, is overplayed.

<a id="ch01-p020-zh"></a>
***从媒介到物质***  
对数字媒介之*物质*的不同理解，如何导致对*活力*与*数字*之间关系的不同刻画？具体而言，各种采取强新唯物主义取径的媒介理论，如何回应来自硅谷的讯息？这讯息在其产品中被表述，在其话语中显而易见：关于进步的讯息，关于更多的讯息——更多技术、更多活动、更多能动性、更多控制、更多*生命*。这一讯息与计算实例化相抵触：对于那些生活在其强制性基础之内的大多数人（对我们所有人而言则以有差异的方式），这些实例化往往产生上述一切的反面。我的回答是：只要这些叙述接受而非质疑某种特定意义上的物质进步的优先性，并因此也预先决定了对活力论（这种活力论是从一种对自身并不好奇的媒介启发法中得到定型的）的回应，它们就没有提供充分的回应。从一种不认同新唯物主义、反而质疑其预设的女性主义视角来思考，或由此出发，是探索为何如此的一条途径。

<a id="ch01-p020-en"></a>
***From media to material***  
How do different understandings of the *material* of digital media give rise to different characterizations of the relationship *between* the vital and the digital? Specifically, how do various forms of medium theory adopting strong new materialist approaches respond to the message from the Silicon Valley, articulated in its products and evident in its discourse: the message about progress, about more – more technology, more activity, more agency, more control, more *life*? This is a message that is at odds with computational instantiations that often work to produce the opposite of all of that for the many (differentially for all of us) living within its compulsory grounds. My answer is that in so far as these accounts accept rather than question the priority of a particular sense of material advance, and therefore also precondition a response to vitalism (which is permed out from a media heuristic that is not curious about itself) they do not offer an adequate response. Thinking through, or working from, a feminist perspective that is not aligned to new materialism but rather questions its assumptions is one way to explore why not.

<a id="ch01-p021-zh"></a>
但这并不完全是*我的*答案。而且，愤怒的并非只有我一人。

<a id="ch01-p021-en"></a>
But this is not *my* answer entirely. And I am not the only one who is furious.

<a id="ch01-p022-zh"></a>
凯特·奥赖尔登、萨拉·肯伯和我出版了《愤怒》，这是一项六只手、机器辅助的技术女性主义制作，主张以其他方式思考数字唯物主义，以及它与真实、想象、象征、活力、人类和机器问题的关系。《愤怒》试图生成一种与新唯物主义总体决裂的数字唯物主义形式，尽管它同情并珍视新唯物主义某些代表人物的修复性工作。它主张，一种继续重视批判的女性主义可以指出，为何需要新取径来应对计算发展——这些发展进一步模糊了有意义的能动性形式与谁或什么可以拥有能动性、可以成为行动者之间的区分；它还主张，女性主义认识论可以提示生成这些取径的方式。与罗西·布拉伊多蒂和一种肯定式女性主义相反，我们断言这种女性主义模式仍有继续的可能，尽管我们也认识到，必须重新思考它可以如何、在何处进行，它可能处于什么情境，以及它如何被*构成*或*装配*。

<a id="ch01-p022-en"></a>
Kate O’Riordan, Sarah Kember and I published *Furious* as a six-handed, machine-assisted, techno-feminist production, arguing for other ways to think about digital materialism and/ in its relationship to questions of the real, the imaginary, the symbolic, the vital, the human and the machine. *Furious* seeks to generate a form of digital materialism that breaks with new materialism(s) in general, even while it is sympathetic to, and values the restorative work of, some of its exponents. It argues that a feminism that continues to value critique can point to why new approaches are needed to grapple with computational developments that blur still further divisions between meaningful forms of agency and who or what may hold agency, or be an agent, and that feminist epistemologies can suggest way to generate them. Contra Rosi Braidotti and a feminism of affirmation we assert the continuing possibility of this mode of feminism, although we also recognize the necessity of rethinking how and where it might be undertaken, what its possible situation might be, and how it might be *composed* or *assembled*.

<a id="ch01-p023-zh"></a>
在遵循《愤怒》论证的程度上，这篇文章根本不属于我。它属于我们，至少是六只手——而且所有这些手都被增强了。

<a id="ch01-p023-en"></a>
To the extent that it follows the arguments of *Furious*, this essay is not mine at all. It is ours, a six-hander at least – and all of those hands are augmented.

<a id="ch01-p024-zh"></a>
那么，其他人在哪里？数字媒介艺术家黑特·史德耶尔曾在伦敦 ICA 做过一场表演讲座，核心是一颗并不在那里的子弹，尽管它不断通过手势被召唤出来。<a id="ref-zh-ch01-12"></a>[12](#note-zh-ch01-12) 讲座为那颗子弹留出了空间。人们感受到它幽灵般的存在——尽管它无法发射。撰写本文时，我意识到一种结构性的缺席：我缺少合著者们那有力的骨架。本文是对同样在 ICA 所作演讲的展开，部分带有回顾性质。如果我现在援引她们，不仅是为了支撑我的立场或增强我的火力，也不仅是为了引用伦理。这是因为《愤怒》试图通过一个写作过程，也通过产生一项成果，来回应关于女性主义与数字唯物主义的问题——这是它自身与再现性探究模式保持一定距离的方式之一。<a id="ref-zh-ch01-13"></a>[13](#note-zh-ch01-13)

<a id="ch01-p024-en"></a>
So where are the others? The digital media artist Hito Steyerl once gave a performance lecture at the ICA in London centred on a bullet that wasn’t there, although it was constantly invoked through gesture.<a id="ref-en-ch01-12"></a>[12](#note-en-ch01-12) A space in the talk was reserved for the bullet. Its spectral presence was felt – although it couldn’t fire. Writing this essay, an elaboration of a talk also given at the ICA, in part a retrospective, I too am aware of a structuring absence: I am missing the virtuous armature of my co-writers. If I now invoke them, this is not only with the aim of shoring up my position or amplifying my firepower; nor is it done only in the interest of citational ethics. It is because *Furious* set out to respond to questions about feminism and digital materialism(s) through a writing process, as well as by producing an output – this was one of the ways it was itself at some distance from the representational mode of inquiry.<a id="ref-en-ch01-13"></a>[13](#note-en-ch01-13)

<a id="ch01-p025-zh"></a>
《愤怒》通过生产一个写作之体，探索了一个数字写作之体可以*是*什么：于是是一种双重化的具身，它把自己定位在一个日益普遍（强制性）的媒介系统之内，却不认为自己完全由其在其中的位置所定义。*与乔安娜·德鲁克相反*——她宣称个体声音的终结、它向网络的消散，以及写作与代码的混淆<a id="ref-zh-ch01-14"></a>[14](#note-zh-ch01-14)——我们主张一个身体，一个被增强的身体，属于我们。我们的技术延伸与我们连续，但它们并未占有我们。也许最简单的说法是（我会回到这一点，因为它涉及人类与物的差异性能动性问题）：我们主张了作者身份。

<a id="ch01-p025-en"></a>
*Furious* explored what a digital writing body can *be* by producing a body of writing: a redoubled embodiment, then, and one that located itself within an increasingly pervasive (compulsory) media system but did not see itself as entirely defined by its place there. *Pace* Joanna Drucker, who declares the end of the individual voice, its dispersal into networks, and the confusion of writing and code,<a id="ref-en-ch01-14"></a>[14](#note-en-ch01-14) we claimed a body, an augmented body, that was ours. Our technical extensions were continuous with us, but they did not claim us. Perhaps the simplest way to put this – and one that I will come back to since it relates to questions of differential agency, that of humans and that of things – is that we claimed authorship.

<a id="ch01-p026-zh"></a>
《愤怒》是一项关于作者身份的试验：不仅通过探索所创作之物（一个作品体）来理解作者身份，也通过考虑什么/谁在*创作*：那些写作之手、那些技术义肢，以及它们与写作之手之间由技术所促成却并不对等的关系，以及其他生产、流通、分配过程。它试图成为瓦尔特·本雅明在一次对作者身份与政治意图的独特探索中所定义的“操作性的”<a id="ref-zh-ch01-15"></a>[15](#note-zh-ch01-15)——其关键在于政治“倾向”与文学“倾向”之间的某种对应。《愤怒》与此相连，因为它采取的形式挤压出它所表达的希望，而在两种情况下，挤压与表达都意在*政治*。我在此把“操作化”理解为一种物质或文学的表达，并且——现在跟随弗兰科·莫雷蒂而非本雅明，进入数字领域——意味着新概念的建构。<a id="ref-zh-ch01-16"></a>[16](#note-zh-ch01-16)

<a id="ch01-p026-en"></a>
*Furious* was an experiment in authorship when the latter is construed not only by exploring what is authored (a body of work) but also by considering what/who *authors*: those writing hands, those technical prostheses and/in their afforded but non-equal relation, those other processes of production, circulation, distribution. It sought to be what Walter Benjamin, in a peculiar exploration of authorship and political intent, once defined as ‘operational’<a id="ref-en-ch01-15"></a>[15](#note-en-ch01-15) – the key to this being a certain correspondence between a political and literary ‘tendency’. *Furious* connects to this in the sense that the form it takes extrudes the hope it expresses, and in both cases the extrusion and the expression are meant *politically.* I take operationalization here to imply a material or literary articulation and also, now following Franco Moretti rather than Benjamin, and moving onto digital terrain, to entail the construction of new concepts.<a id="ref-en-ch01-16"></a>[16](#note-en-ch01-16)

<a id="ch01-p027-zh"></a>
其中之一是激进的交叉性。《愤怒》以把计算资本主义置于（被误称的）人类世语境中开始并结束；人类世被视为与所有人类与非人类的未来可能性相连，并被视为本质上在与处境、位置、排斥、歧视和暴力的差异的关系中被经验。这是确认需要阐明一种交叉性模式的起点：这种交叉性始于但不停止于人类的交叉；它在探索人类与非人类之间边界的同时，打开了“人类”范畴。这借鉴但也决裂于卡伦·巴拉德新唯物主义意义上的“内行动”（intra-activity），后者是理解能动性的一种方式。它承认这样一种意图的价值：把否则可能通过话语被援引之物物质化——在人格形成的叙述中，更广泛地说，在关于能动性或在世界中行动与回应之能力的叙述中。但它反对内行动将一切开创性之物（一切要紧之物）如此彻底地奠基于不可预视<a id="ref-zh-ch01-17"></a>[17](#note-zh-ch01-17)的相遇之中。说得绕口一点，一种以“内交叉”（intra-sectional）为基础的推定性政治，可以让物质本身比从前更要紧（巴拉德的要求是它应该如此）<a id="ref-zh-ch01-18"></a>[18](#note-zh-ch01-18)，但随之而来的问题是，如何解释被带入交叉点的东西，那先在的经验、状况或历史。所有这些因素都有助于说明*为什么*交叉性政治被认为是必要的，为什么它的重要性继续得到证明。

<a id="ch01-p027-en"></a>
One of these is a radical intersectionality. *Furious* begins and ends by locating computational capitalism within the contexts of the (misnamed) Anthropocene; the latter being taken as continuous with all human and non-human future possibilities, and as essentially experienced in relation to difference in situation, position, exclusion, discrimination and violence. This is the starting point for the identification of the need to elaborate a mode of intersectionality that begins with but does not stop at human crossings; that opens up the category ‘human’ even as it simultaneously explores the boundaries between human and non-human. This draws on, but also breaks with, Karen Barad’s new materialist sense of intra-activity as a way to understand the agential. It recognizes the intention of materializing what might otherwise be invoked through discourse, in accounts of the formation of personhood and more broadly in accounts of agency or the capacity to act and respond in the world as valuable. But it is at odds with the degree to which intra-activity founds all that is inaugural (all that matters) in the unprevisible<a id="ref-en-ch01-17"></a>[17](#note-en-ch01-17) encounter. To put it tongue-twistily, a putative politics based on the intra-sectional could allow matter itself to matter more than it mattered before (Barad’s demand being that it should),<a id="ref-en-ch01-18"></a>[18](#note-en-ch01-18) but the problem that then arises is how to account for that which is brought to the intersection, that pre-existing experience, or condition, or history. All these factors contribute to *why* an intersectional politics is found necessary, to why its importance continues to be demonstrated.

<a id="ch01-p028-zh"></a>
因此，认识到需要把交叉性重新物质化，以回应人类世所逼出的迫切要求，我们并不寻求发展一种“内交叉”叙述，而是要建立一种激进的交叉性形式。它扩展能动性，承认行动者的多样性，承认假定所有行动者（归根结底）都只是替人类行事的代理者（掌控的幻想）是徒劳的，但仍然断言（后）人类存在的独特性——作为一种活着的存在形式，它与异质活力的预设形成对照（无论这种活力是稀薄还是浓厚地分布）——并坚持具体人类行动的独特性。它使批判成为可能。

<a id="ch01-p028-en"></a>
So, recognizing a need to re-materialize intersectionality in relation to the demands made urgent by the Anthropocene, we did not seek to develop an intra-sectional account but rather to build a radical form of intersectionality. This expands agency, recognizes a diversity of agents, acknowledges the futility of assuming all are (in the last analysis) agents of the human (the fantasy of mastery), but asserts nonetheless the distinctiveness of (post-) human being, as a form (of) being alive which stands in contradistinction to the presumption of a heterogenous vitality – whether this is spread thin or thick – and insists on the distinctiveness of specifically human actions. It enables critique.

<a id="ch01-p029-zh"></a>
***愤怒的笑声？***  
它也允许笑声。事实上，它部分地通过笑声运作。如果《愤怒》主张建构一种激进的交叉性政治，作为对数字状况的回应，它也试图在自己的取径中把这种政治中可能重要的某些要素付诸操作。具体而言，《愤怒》援引了埃莱娜·西苏，她宣称弑神者美杜莎的笑声是一种女性主义武器，是女性主义同时肯定*与*批判、主张理性*与*瓦解一种排他性理性主张的方式——这种理性通过排除许多要紧之物（包括要紧的身体）来运作。笑声让写作得以放开喉咙、变得过度，也可能是一种拒绝/混淆/化解物质性与其意义之间所立区分的途径。它也是一种断言或探索写作与代码之间区分的方式，即便一方不断通过另一方被表达。于是，笑声是我们的操作符之一。它可以扰乱自然化的主张与预设，包括那些通常区分理性与情动、观念与物质、自然与文化的预设。此外，笑声可以促成一种论辩模式，这种模式不以深思熟虑为唯一依据（当然不至于意味着通过调制总能达成和解），同时也立足于对抗。笑声揭穿愚蠢——按照帕特里克·克罗根的定义（他尤其关心数字实现的愚蠢），愚蠢就是未能追问我们如何被治理。<a id="ref-zh-ch01-19"></a>[19](#note-zh-ch01-19)

<a id="ch01-p029-en"></a>
***Furious laughter?***  
It also allows for laughter. Indeed it in part works through it. If *Furious* advocates the construction of a radical intersectional politics as a response to the digital condition, it also sought to make operational in its own approaches some of the elements that might be important in that politics. Specifically, *Furious* invoked Hélène Cixous, who declared the laughter of the god-slayer Medusa a feminist weapon, a way for feminism to at once affirm *and* critique, claim rationality *and* undermine the exclusionary claims of a rationality that works by excluding much that matters – including bodies that matter. Laughter allows writing to become full-throated, to be excessive, and may be a means through which to refuse/confuse/defuse divisions erected between materiality and its meaning. It is also a means through which to assert or explore distinctions between writing and code, even while one is constantly articulated through the other. Laughter, then, was one of our operators. It can disturb naturalized claims and assumptions, including those that conventionally divide the rational and the affective, ideation and the material, nature and culture. Laughter moreover can enable a mode of argumentation that is predicated not on deliberation alone (certainly not to the degree that this implies an always possible reconciliation through modulation) but that also rests on antagonism. Laughter calls out stupidity – the latter defined, following Patrick Crogan, who is concerned in particular with digitally realized stupidity, as failing to ask how we are governed.<a id="ref-en-ch01-19"></a>[19](#note-en-ch01-19)

<a id="ch01-p030-zh"></a>
***笑声、新唯物主义与媒介理论***  
笑声具有交流性。这对我们也有用。笑声可以嘲弄地回应当代各种数字媒介唯物主义所特有的、对物质“真相”的那种完全严肃而极其激烈的关注。后一种关注错失了目标，因为它拒绝看见（也）在那里的东西，拒绝看见一切使事物变得浓厚、使之象征化、使之*交流*的东西。我们现在不妨承认，写这本书的冲动之一，是对‘断绝交流’（excommunication，亦指‘逐出教门’）这一预告的一种愤怒；那种处境将会到来，而我们正坐在它的门槛上。与此同时，据说交流本身正陷入麻烦。亚历克斯·加洛韦对这种麻烦的叙述从解释学与内在性开始，随后被第三种模式取代——他通过召唤复仇女神（动物、“母狗”、玷污性的造物）来命名这一模式，她们定义了我们现在所处的网络复杂性状况。<a id="ref-zh-ch01-20"></a>[20](#note-zh-ch01-20) 针对（完全非人的）复仇女神那种恶魔般的强度，以及以她们为形象似乎会引导出的后批判回应，我们提出美杜莎的愤怒笑声。对西苏而言，笑声是*有意义的*。因此，笑声可以扰乱或质疑‘断绝交流’叙述的序列（解释学、症状学、集群/系统），也可以质疑把这些序列翻译为据说由它们界定的媒介形式/格式：文本、图像、系统（机器、网络）。与加洛韦的主张相反，最后的“系统”不必，也并不总是或完全地，“组合并*消灭*”其他媒介形式。<a id="ref-zh-ch01-21"></a>[21](#note-zh-ch01-21)

<a id="ch01-p030-en"></a>
***Laughter, new materialism and media theory***  
Laughter communicates. This was also of use to us. Laughter can respond mockingly to the entirely serious and very fierce attention paid to the material ‘truth’ that characterizes the approach of various contemporary digital media materialisms. This latter is an attention that misses its mark because it refuses to see what is (also) there, all that which thickens, symbolizes, *communicates*. We may as well admit now that one of the spurs to writing the book was a kind of fury with the suggestion of excommunication; as that situation which will come, on whose doorstep we sit. Meanwhile, it is argued, communication itself is in trouble. Alex Galloway’s account of this trouble begins with hermeneutics and immanence, which are then superseded by a third mode, designated by his invocation of the Furies (animals, ‘bitches’, defiling creatures), who come to define that condition of networked complexity we are now in.<a id="ref-en-ch01-20"></a>[20](#note-en-ch01-20) Against the daemonic intensity of the (entirely inhuman) Furies, and the post-critical response their figuration would seem to curate, we set the furious laughter of Medusa. For Cixous laughter is *meaningful*. It may therefore disrupt or dispute the seriality of the ex-communicative account (hermeneutics, symptomatics, swarms/systems) and for that matter the translation of these to the media forms/formats they are said to define: the text, the image, the system (the machine, the network). Contra Galloway’s claim, the last ‘system’ does not have to, or does not always or entirely, ‘combine and *annihilate*’ the others.<a id="ref-en-ch01-21"></a>[21](#note-en-ch01-21)

<a id="ch01-p031-zh"></a>
《愤怒》理解系统思维，接受网络化的状况，但不“放弃”在场或差异，也不是非人的。相反，作为一个偶然的后人类身体，愤怒地写作并怀着共同意图，我们寻求找到方式，不止通过“狂怒化”来“让世界逃离”，而且我们对对抗可能意味着什么、对“愤怒的媒介”可能得到何种回应有不同的理解。<a id="ref-zh-ch01-22"></a>[22](#note-zh-ch01-22) 我们在此并非完全针对复仇女神写作。加洛韦还提示了第四条路：在可憎而难以忍受的甜蜜之中的爱，代表某种超越对抗与差异的东西。我们随时都会站复仇女神一边反对这条道路，而且我们认为她们或许自有其道理。在另一个时代，西苏为女性写作提出两个目标：去“摧毁”，以及预见不可预见之物，也就是“投射”。换言之，“用笑声打破‘真相’”，然后追问什么可以重新得到肯定。<a id="ref-zh-ch01-23"></a>[23](#note-zh-ch01-23) 这也许还意味着，可以以较少分裂的方式探索门户之外的前景（例如更强的 AI 可能作为“异类”媒介打开什么）。也许这过于玄奥。可能需要一些阐释。

<a id="ch01-p031-en"></a>
*Furious* understands systems thinking, and accepts a networked condition, but does not ‘abdicate’ presence or difference, nor is it inhuman. On the contrary, as a contingent post-human body, writing furiously and with shared intent, we seek to find ways to do more than ‘put the world in flight’ through ‘infuriation’ and we have a different sense of what antagonism can imply, of what a response to ‘furious media’ might be.<a id="ref-en-ch01-22"></a>[22](#note-en-ch01-22) We are not entirely writing against the Furies here. There is also the fourth way suggested by Galloway: a love in the middle of execrable, insufferable sweetness, standing for something beyond antagonism and difference. We’d back the Furies against this any day, and we think they may have their reason(s). In a different era, Cixous suggested two aims for women writing: to ‘destroy’ and to foresee the unforeseeable, which is to say to ‘project’. In other words, ‘break up the “truth” with laughter’ and then ask what may be newly affirmed.<a id="ref-en-ch01-23"></a>[23](#note-en-ch01-23) This might also mean that the prospects of what lies beyond the portal (or what stronger AI, for instance, might open up as ‘alien’ media) could be explored in less schismatic ways. Perhaps that is gnomic. Some explication might be necessary.

<a id="ch01-p032-zh"></a>
让我们在此指出，断绝交流理论（姑且这样称呼）只是新媒介新唯物主义的一种变体，后者本身游弋于一片更大的海域。新唯物主义是一个标签，被赋予四五种思想脉络——思辨实在论、客体导向本体论（OOO）、作为媒介理论的数字唯物主义、新唯物主义女性主义——其中尤以巴拉德（把量子唯物主义作为后批判）<a id="ref-zh-ch01-24"></a>[24](#note-zh-ch01-24)和某种程度上布拉伊多蒂（带有或多或少的德勒兹倾向）为代表。布拉伊多蒂本人正确地质疑了在这些构形中把新唯物主义称为“新”的主张，承认唯物主义传统早于当前许多形式。<a id="ref-zh-ch01-25"></a>[25](#note-zh-ch01-25) 毕竟，早在哈曼与 OOO、思辨实在论、软件研究以及对康德相关主义的攻击之前，女性主义就已经在思考身体与文本。另一方面，这些新唯物主义（或准新唯物主义）形式共享一种被称为“氛围”的东西<a id="ref-zh-ch01-26"></a>[26](#note-zh-ch01-26)，一种对后结构主义的或多或少当代的不满，*以及*对历史唯物主义、批判理论和“怀疑的解释学”的敌意（如凯斯顿·萨瑟兰在本卷中所指出的），这种敌意采取新的形式。

<a id="ch01-p032-en"></a>
Let us note here that excommunication theory (to call it that) is only one variant of new media new materialism, which itself swims in a larger sea. New materialism is a label given to four or five strands of thinking – speculative realism, objected oriented ontology (OOO), digital materialism as medium theory, new materialist feminisms – those of Barad (quantum materialism as post-critique)<a id="ref-en-ch01-24"></a>[24](#note-en-ch01-24) and to some extent Braidotti (with a more or less Deleuzean slant), notably. Braidotti herself rightly questions the claim to new materialism as ‘new’ in these formations, acknowledging traditions of materialism that pre-date many of the present forms.<a id="ref-en-ch01-25"></a>[25](#note-en-ch01-25) Feminism, after all, was thinking about bodies as well as texts long before Harman and the OOO, speculative realism, software studies and attacks on Kantian correlationism. On the other hand, these forms of new materialism (or quasi-new materialism) share what has been called an ‘atmosphere’,<a id="ref-en-ch01-26"></a>[26](#note-en-ch01-26) a more or less contemporary discontent with post-structuralism *and* a hostility to historical materialism, critical theory and the ‘hermeneutics of suspicion’ (as Keston Sutherland notes in this volume), which takes new forms.

<a id="ch01-p033-zh"></a>
这意味着，探索尤西·帕里卡所说的“作为媒介理论的新唯物主义”<a id="ref-zh-ch01-27"></a>[27](#note-zh-ch01-27)的前景，要求承认我们正呼吸着这种“氛围”（或许可以把它定义为一个局势），也要求承认即便在媒介理论内部也存在不同变体。下文我将把关注焦点从批判理论（加洛韦）转向德国媒介理论/媒介考古学唯物主义，以追寻或重新发现活力与数字之间的联系。

<a id="ch01-p033-en"></a>
This means that exploring what Jussi Parikka has called the prospects for ‘new materialism as media theory’<a id="ref-en-ch01-27"></a>[27](#note-en-ch01-27) demands acknowledgement that we are breathing in this ‘atmosphere’ (perhaps this could be defined as a conjuncture), and also perhaps an acknowledgement that even within media theory there are different variants. In what follows, I shift the focus of attention from critical theory (Galloway) towards German medium theory/media archaeological materialisms in order to pursue, or to re-find, a linkage between the vital and the digital.

<a id="ch01-p034-zh"></a>
***死的还是活的？无中介的媒介？***  
快速绕道简·贝内特关于活力唯物主义的有影响的讨论，在此有用。贝内特在各种集合体（不区分是重点之一）中发现一种活力或能动能力，她将其作为“物之力”（thing power）来探索。在《活力物质：物的政治生态学》中，她主张“可食之物、商品、风暴和金属作为准行动者，拥有自己的轨迹、潜能和倾向”，并促成了使网络或集合体得以运作的东西。对象中固有某种力量，这种力量无法完全以人类术语理解，必须在对象自身、其物质中被发现。贝内特因此可以问：

<a id="ch01-p034-en"></a>
***Dead or alive? Media without mediation?***  
A rapid detour through Jane Bennett’s influential discussion of vital materialism is useful here. Bennett finds in assemblages of many kinds (non-differentiation is part of the point) a vitality or agential capacity that she explores as ‘thing power’. In *Vibrant Matter* she argues that ‘edibles, commodities, storms and metals act as quasi agents with their own trajectories, potentialities and tendencies’ and contribute to what makes networks or assemblages operational. A force inheres in objects that is not fully comprehensible in human terms, a force that must be found in the object itself, its material. Bennett can thus ask:

<a id="ch01-q002-zh"></a>
> 什么算作活力唯物主义的物质？仅仅是人类劳动和由男人们使用原材料所制造的社会经济实体吗？还是物质性比这更有力量？政治理论如何能更好地认识非人力量在每个事件和每次稳定化中的积极参与？是否存在一种理论形式，能够承认某种“物之力”，即对象无法被化约为它们同时也体现的人类意义或议程？<a id="ref-zh-ch01-28"></a>[28](#note-zh-ch01-28)

<a id="ch01-q002-en"></a>
> What counts as the material of vital materialism? Is it only human  labour and the socio-economic entities made by men using raw  materials? Or is materiality more potent than that? How can political  theory do a better job of recognizing the active participation of  nonhuman forces in every event and every stabilization? Is there a  form of theory that can acknowledge a certain ‘thing-power’, that is,  the irreducibility of objects to the human meanings or agendas they  also embody?<a id="ref-en-ch01-28"></a>[28](#note-en-ch01-28)

<a id="ch01-p035-zh"></a>
贝内特明确表示，她更喜欢那些或许先前被视为惰性之物的更有力量的物质性，而不是由人类“事物”（例如社会经济）主导的实体；在她设想的模型中，人类（以及其他行动者）虽然保留各种能动性，但这种能动性被削弱了：当物变得有生命，人就被视为更加惰性——二者也被分开；不允许有义肢或延伸。斯科特·拉什曾指出，活力论在历史上从未过多关注人类，这一点在此也很明显。这或许部分解释了为什么“男人们”（原文如此）所制造的东西在贝内特的叙述中显得格格不入，因为它当然依赖一种活力论模式。正是这种模式提供了能动性形式，提供了一种有时似乎充满*生命冲力*（élan vital）的潜能。贝内特在多个事物及其集合体中发现的潜能带有神秘主义色彩。这些集合体如何被装配则不太清楚；如果它们交流，它们当然并不*中介*。

<a id="ch01-p035-en"></a>
Bennett is clear that she prefers the more potent materialities of what might have previously been thought inert over entities dominated by human ‘things’ (socio-economics, for instance), and while humans (among other actants) retain forms of agency in the models she envisages this is reduced: as things become live humans are viewed as more inert – they are also kept apart; no prosthesis or extension is allowed. Scott Lash has noted that vitalism has historically never been much preoccupied with the human, and this is evident here too. It may be partly why what is made by ‘men’ (*sic*) sits uneasily in Bennett’s account since it certainly relies on a mode of vitalism. It is that which provides for forms of agency, for a potency that sometimes appears charged with an *élan vital.* There are mystical undertones to the potentialities Bennett finds in multiple things and in their assemblages. How the latter are assembled is less clear, and if they communicate they certainly do not *mediate*.

<a id="ch01-p036-zh"></a>
对新媒介的新唯物主义分析也关心理解物质力量，也面对这一力量如何有活力、如何运作的问题（并在一种被投注的关系中处理该问题：技术投入到认知自动化，而此事关联能动性与活性），但它们在不同的边界集合上运作。这一次，任务不是模糊区分无生命物（及其能动性）与有意识存在的边界。相反，同样是为了（一种新的）唯物主义，另一组相当不同的边界将被恢复。

<a id="ch01-p036-en"></a>
New materialist analyses of new media, also concerned to understand material force and also confronting the question of how that force is lively, or how it operates (and doing so in relation to that cathected relationship between a technology invested in the automation of cognition and matters of agency, and liveliness), operate at a different set of borders. This time the task is not to blur boundaries dividing inanimate things (and their agency) from conscious beings. Rather, but also in the interests of a (new) materialism, a rather different set of boundaries are to be reinstated.

<a id="ch01-p037-zh"></a>
关键在于把媒介与介质、真实与再现分开。贝内特倾听，听到某种类似生命力的东西。新媒介唯物主义优先剥除附着在数字材料或数字操作之上的种种归因，犹如刮去藤壶（包括贝内特的神秘硬壳），以便更仔细地审视真实之物。贝内特想把一个物从人们认定的惰性中撬出来，寻求理解其活性与能动性的方式；作为媒介理论的新唯物主义则相反，致力于把媒介物从其历史语境、视域中撬出，并在这样做时剥去它的附着物、它的*次级物*，后者被认为不健康。技术媒介对象与系统而非再现。描述那里有什么，而不是可能把它包覆起来的理论化。<a id="ref-zh-ch01-29"></a>[29](#note-zh-ch01-29) 你或许可以说，数字媒介理论中的物质转向产生了一种坚持：寻找物的本质。其余之物被认为非本质，是一层可被蜕去的外皮，是我们本可不要的果皮，或一种我们必须克服的过滤习惯；这种习惯就是相信魔法（贝内特的作品因这一点而遭拒斥），或相信中介——后一种习惯接受世界按照我们能够感知它的方式、按照我们使之有意义的方式来到我们面前。这条路线将产生对技术媒介及其（真实）力量的理解；那种力量先于意义问题而存在和运作，无论这些意义问题可能如何被解释和评估。

<a id="ch01-p037-en"></a>
The point is to divide media from medium, the real from the representational. Bennett listens in and hears something like a life force. New media materialism makes it a priority to strip away the barnacles of what is imputed to digital materials or to digital operations (including Bennett’s mystic encrustations) in order to look harder at the real thing. Where Bennett wants to winkle a thing out of its perceived inertia, seeking ways to understand its aliveness and its agency, new materialism as a medium theory works instead to winkle the media thing out of its historical contexts, its horizons, and in doing so to strip it of its accretions, its *secondaries*, which are regarded as unhealthy. Technical media objects and systems not representations. Description of what is there, not theorizations that might encrust it.<a id="ref-en-ch01-29"></a>[29](#note-en-ch01-29) You might say the material turn in digital medium theory produces an insistence on finding the essence of the thing. The rest is thought inessential, an outer skin to be sloughed off, a rind we could do without or a filter habit we need to get over; the habit being to believe in magic (Bennett’s work has been rejected for this) or in mediation, the latter being a habit of accepting that the world comes to us as we are able to sense it and as we make it meaningful. This is the route that will produce an understanding both of technical media and of its (real) power; that which stands and operates prior to matters of significance as these might be interpreted and assessed.

<a id="ch01-p038-zh"></a>
在基特勒著作所体现、后来经沃尔夫冈·恩斯特关于时间性的研究发展的那支德国媒介理论中（二者属于同一传统，后者也被界定为一种媒介考古学），这些论证得到充分表达。它们既产生一种诊断（如基特勒所说：代码今天“决定”我们）<a id="ref-zh-ch01-30"></a>[30](#note-zh-ch01-30)，也产生一种要求。这要求针对媒介形式研究采取特定分析或取径。对恩斯特和基特勒而言，这既是对发展的回应——因为技术媒介的兴起使这种探究取向变得必要，如果说此前并非如此——也构成一种迟来的承认：技术媒介或许一直都需要被如此探究。尤西·帕里卡大致在同一传统中写作，他进一步推进这一主张，并给予它本体论辩护，主张“新唯物主义已经存在于技术媒介传输和处理‘文化’的方式之中”。这一主张表述得有些古怪<a id="ref-zh-ch01-31"></a>[31](#note-zh-ch01-31)，但它有用地表明：基特勒和恩斯特围绕非常具体的技术媒介所发展的取径，已经扩展到成为一系列受新唯物主义启发的计算研究中的普遍取向。它也指向（或解释了）新媒介唯物主义者为何把自己视为*内部人*——他们的分析内在于他们研究的材料。这产生了一系列肯定性的、“非意识形态的”叙述，它们凭自己的位置而自认为格外*有效*。

<a id="ch01-p038-en"></a>
In that strand of German Medium Theory embodied in Kittler’s work and latterly developed through Wolfgang Ernst’s work on temporality, which is in the same tradition and which has come also to be defined as a form of media archaeology, these arguments find full expression. They produce both a diagnosis (as Kittler put it: codes ‘determine’ us today)<a id="ref-en-ch01-30"></a>[30](#note-en-ch01-30) and a demand. The demand is for a particular form of analysis or approach to the study of mediatic forms. For both Ernst and Kittler this is at once a response to developments, since the rise of technical media makes such investigative orientations necessary, if they were not before, and constitutes an overdue recognition of what might have always been necessary to investigate technical media. Jussi Parikka, writing in more or less the same tradition, pushes this claim further and gives it an ontological justification when he argues that ‘new materialism is already present in the way technical media transmits and processes ‘‘culture”.’ This claim is somewhat peculiarly expressed,<a id="ref-en-ch01-31"></a>[31](#note-en-ch01-31) but it usefully indicates the degree to which approaches developed by Kittler and Ernst, around very specific technical media, have broadened to become a general orientation extant across a range of new-materialism-inspired forms of investigation of the computational. It also points to the degree to which (or why) new media materialists regard themselves as *insiders* – their analyses being immanent to the material they are studying. This produces a series of accounts that are affirmative, ‘non-ideological’, and that regard themselves by virtue of their position as exceptionally *effective*.

<a id="ch01-p039-zh"></a>
值得注意的是，在这些取径中，要抵达的核心内核、要探索的本质性物质，被分别确定为软件、硬件、代码、算法。于是，蜕去其他一切、清除肮脏的实在（例如所有那些肮脏现实主义）<a id="ref-zh-ch01-32"></a>[32](#note-zh-ch01-32)的过程，产生的不是一个，而是若干个物。那个本质并不像表面看起来那样容易把握。无论如何，我们有权再次追问：这些是什么种类的媒介对象？

<a id="ch01-p039-en"></a>
It is striking that in these approaches the central kernel to be reached, or the essential matter to be explored, is variously determined as software, hardware, code, algorithm. The process of sloughing off of everything else, purging it of the dirty real (all that dirty realism, for instance)<a id="ref-en-ch01-32"></a>[32](#note-en-ch01-32) thus produces not one, but a number of things. That essence is not as easy to get hold of as it might appear to be. We are at any rate entitled to ask again what kind of media objects are these?

<a id="ch01-p040-zh"></a>
为它们提出的主张很宏大。它们常常是庞大的对象：大数据、强大的算法、全球网络。它们的规模与触及范围也因附于其上的期票而扩展——它们似乎表述甚至物质化这些期票。<a id="ref-zh-ch01-33"></a>[33](#note-zh-ch01-33) 大数据指向更大数据的到来，甚至指向完整数据和一切解释必要性的终结：“所有数字”，意味着“不再需要理论”。并非偶然，克里斯·安德森这一如今臭名昭著的主张最初是在《连线》杂志获得推力的。<a id="ref-zh-ch01-34"></a>[34](#note-zh-ch01-34) 或者想想算法及其证明力，或关于机器学习和涌现的主张。这些例子表明这些东西如何膨胀；它们有变成不真实对象的危险，如凯特·奥赖尔登会说的那样。<a id="ref-zh-ch01-35"></a>[35](#note-zh-ch01-35) 但也有收缩。更仔细地看，这些东西变得越来越不实质；它们收缩。它们几乎变成想象性的；之所以说是想象性的，是因为想象性——它是这些技术物之构成的固有部分，如果这些技术物要运作的话——已被从它们之中剥离。此处关键是抽象，而不是过程；然而，这种辨识出对象、使对象从中物质化的操作/取向，却被声称触及事物的核心，触及使事物有生机的东西。这构成一种拜物教。<a id="ref-zh-ch01-36"></a>[36](#note-zh-ch01-36)

<a id="ch01-p040-en"></a>
The claims made for them are big. They are often big objects: big data, powerful algorithms, global networks. Their scale and reach are also expanded by way of the promissory notes attached to them, which they seem to articulate or even materialize.<a id="ref-en-ch01-33"></a>[33](#note-en-ch01-33) Big data points to the coming of even bigger data, and even towards complete data and the end of all necessity for interpretation: ‘all the numbers’, meaning ‘no more theory’. Un-accidentally this now notorious suggestion from Chris Anderson first gained traction in *Wired* magazine.<a id="ref-en-ch01-34"></a>[34](#note-en-ch01-34) Or consider the algorithm, and its proving power, or claims made for machine learning and emergence. These examples point to the degree to which these things bloat; they threaten to become unreal objects, as Kate O’Riordan would put it.<a id="ref-en-ch01-35"></a>[35](#note-en-ch01-35) But there is also shrinkage. Look harder and these things become increasingly less substantial; they shrink. They become almost imaginary; imaginary because the imaginary, which is an intrinsic part of the constitution of these technical things, if these technical things are to work, has been stripped out of them. Abstraction not process is key here, and yet this operation/ orientation through which an object is discerned, out of which it is materialized, is claimed to get to the heart of things, to get at that which animates things. This constitutes a form of fetishism.<a id="ref-en-ch01-36"></a>[36](#note-en-ch01-36)

<a id="ch01-p041-zh"></a>
回到经典的论述<a id="ref-zh-ch01-37"></a>[37](#note-zh-ch01-37)，同时质疑它组织我们欲望的主张<a id="ref-zh-ch01-38"></a>[38](#note-zh-ch01-38)：*缺席*覆盖着*匮乏*。在试图蒸馏物本身时，物本身被根本性地削减，它与世界的关系以及其物质吸引力的*活力*都随之黯淡。取代后者的，奇怪得很，可能是魔法性的东西。拜物教或许把一种活力论模式重新请了进来，因为传统上隐藏之物可能具有未被承认的力量。这种拜物教如何运作？这是一种媒介拜物教吗？温迪·春等人曾指出软件与代码研究中对代码的拜物教化，但这个版本可能更为彻底。<a id="ref-zh-ch01-39"></a>[39](#note-zh-ch01-39)

<a id="ch01-p041-en"></a>
To refer to the classical invocation,<a id="ref-en-ch01-37"></a>[37](#note-en-ch01-37) while disputing its claims to organize our desire,<a id="ref-en-ch01-38"></a>[38](#note-en-ch01-38) *absence* covers a *lack*. In attempting to distil the thing itself, the thing itself is radically diminished, and its relation to the world and the *vibrancy* of its material appeal are dimmed. In place of the latter, what returns might oddly enough be the magical. The fetish perhaps invites a mode of vitalism back in, since traditionally what is hidden may have unacknowledged powers. How does this fetish work? Is this a medium fetish? Wendy Chun and others have pointed to the fetishization of code within software and code studies, but this version might be more thoroughgoing.<a id="ref-en-ch01-39"></a>[39](#note-en-ch01-39)

<a id="ch01-p042-zh"></a>
拜物教建立在未被承认、或被遮盖（被否认）的匮乏之上。对物质的执着、对“物质”的拜物教化，使数字唯物主义得以宣称它把握了实在，而其他叙述缺乏实质或现实。它们的指控不是其他技术媒介叙述缺少对媒介权力的承认（尽管这是恩斯特等人论证的一部分）。要点在于，技术媒介最必要的维度——确实是唯一真正必要的维度——缺失了；物质地被给予的技术能力，据说在依赖二阶再现（处理死的模拟或反射）的叙述中被熨平进话语或再现，甚至被拉成一条直线。其后果（据称）是能动性的分配被误解：过多给了人类，过少给了技术系统的决定性操作——这些操作与其说中介，不如说安排秩序。<a id="ref-zh-ch01-40"></a>[40](#note-zh-ch01-40)

<a id="ch01-p042-en"></a>
The fetish is based on lack that is not recognized, or that is covered over (disavowed). An adherence to the material, a fetishization of ‘the material’, allows digital materialism to say that it grasps the real while other accounts lack substance or reality. Their charge is not that what is missing in other accounts of technical media is a recognition of media power (though that is part of the argument made by Ernst, for example). The point is that the most necessary dimension, indeed the only really necessary dimension of technical media, is missing; that materially given technical capacity, which is said to be ironed out into discourse or representation, flatlined even, in accounts relying on second-order representations (dealing in dead simulation or reflection). A consequence of this (it is argued) is that the allocation of agency is misunderstood; too much being given to humans, and too little to the determining operations of technical systems – which do not so much mediate as order.<a id="ref-en-ch01-40"></a>[40](#note-en-ch01-40)

<a id="ch01-p043-zh"></a>
思考媒介拜物教化，或许是一种解释媒介理论敌意的途径，这种敌意针对关于新媒介的其他叙述，因为它们纠缠于其他形式的拜物教化（以及异化与误认）：马克思关于商品关系的叙述——人与人的关系被误认为物与物的关系——以及弗洛伊德的叙述——欲望被误认，产生一种自我异化形式。

<a id="ch01-p043-en"></a>
Thinking about medium fetishization might be a way to account for the hostility found in medium theory towards other accounts of new media that tangle with other forms of fetishization (and with alienation and misrecognition): Marx’s account of commodity relations, in which relations between people are mistaken for relations between things, and Freud’s, in which desire is misrecognized, producing a form of self-alienation.

<a id="ch01-p044-zh"></a>
总体而言，新唯物主义会把这类构形当作（几乎字面意义上）没有实质的东西加以清扫，认为它们以错误的方式看错误的东西（或许只是向后看）。<a id="ref-zh-ch01-41"></a>[41](#note-zh-ch01-41)

<a id="ch01-p044-en"></a>
In general, new materialism would sweep away such formations as (almost literally) without substance, as looking in the wrong way, at the wrong thing (perhaps as simply looking backwards).<a id="ref-en-ch01-41"></a>[41](#note-en-ch01-41)

<a id="ch01-p045-zh"></a>
然而，通过拜物教的视角探索新唯物主义媒介理论，提供了一种方式，可借此勾勒新唯物主义数字媒介叙述中的缺失。在这些叙述中，商品关系问题与欲望之事以其缺席而在场，是拜物教化叙述所遮盖——无法处理——之物的一部分；这或许也解释了它为何不能或不愿从生理性别与社会性别的区分出发思考，也看不到为何对性别的系统叙述必然与同一系统的其他要素相交织（即便对处理歧视有明显同情的取向，例如帕里卡的情形）。今天，马克思在社会关系中看到的误认（人与人的关系被误认为物与物的关系），他也始终理解为作用于身体（并促成对身体的伤害）的误认，现在作用于那些被分割化、由数据生产、被要求自行担责、在很大程度上被剥夺能动性并遭受歧视的信息主体的身体；作用于一般社会关系以及我们每个人的生活。取道拜物教并非唯一路径。我们自己当然不会把它“在理论上”所采取的两种经典形式简单并列。<a id="ref-zh-ch01-42"></a>[42](#note-zh-ch01-42) 但若以为可以绕过这些实例化关系、物质复杂性与缠结、这些构形所指向的想象，仍然生产或找到数字对象的核或“真相”，那确实可笑。

<a id="ch01-p045-en"></a>
However, exploring new materialist media theory through the perspective of the fetish provides a means through which to adumbrate what is missing in new materialist accounts of digital media. In them, the question of commodity relations and the matter of desire are present in their absence, are part of what the fetishized account covers up – cannot deal with – which may also be why it cannot or does not wish to think in terms of sex–gender distinctions, and also does not see why a systematic account of gender necessarily intersects with other elements of the same system (this being so even when a sympathetic orientation towards tackling discrimination is evident, as for example is the case for Parikka). Today a version of that misrecognition that Marx saw in social relations (where relations between people are mistaken for relations between things), which he also always understood to operate on bodies (to contribute to harming them), now operates on the bodies of the dividuated, data-produced, responsibilized, largely de-agentialized and discriminated subjects of information; operates on the social relation in general and on each of our lives. Going by way of the fetish is not the only way to go. We ourselves certainly would not parallel the two canonical forms it has taken ‘in theory’.<a id="ref-en-ch01-42"></a>[42](#note-en-ch01-42) But it is laughable indeed to consider that it is possible to reach around the instantiated relations, the material complexities and imbrications, the imaginaries these formations point to, and still produce or find the kernel or the ‘truth’ of the digital object.

<a id="ch01-p046-zh"></a>
在其一些挑衅性的后政治脉络中，新唯物主义媒介分析实际上并不（太）关心这些事情，而更关心完全超出人类的问题。在这个意义上，或在这个变体中，它是反人类的。或者它可能关心，但预设这类问题只能通过被视为“先在”之物（恩斯特）或结构决定之物（德鲁克）的途径来接近。从它自身的术语看，对新媒介唯物主义更严厉的指控——它当然会试图反驳——或许是：它对实在的主张，因未能把握它试图接触的那些材料的全部维度而受损。一种说法是：它无法对它发现自己身处其中的构形产生回应（批判性的或其他），相反（仅仅）与它连续。

<a id="ch01-p046-en"></a>
In some of its defiantly post-political veins, new materialist media analysis doesn’t actually care (much) about these things, being more interested in issues beyond the human entirely. It is in this sense, or in this variant, anti-human. Or it may care but presume such issues may not be approached except by way of what is viewed as ‘prior’ (Ernst), or structurally determining (Drucker). Seen in its own terms, the graver charge against new media materialism, which it would of course seek to refute, might be that its claims to the real are undermined by a failure to grasp the full dimensions of those materials it is seeking to engage with. One way to put this is to suggest that it cannot generate a response (critical or otherwise) to the formation it finds itself in but is on the contrary (simply) continuous with it.

<a id="ch01-p047-zh"></a>
***“因此，为了抵抗当下，我提议”，或者，一条金鱼回应***<a id="ref-zh-ch01-43"></a>[43](#note-zh-ch01-43) 为了把这与活力和生命重新联系起来，我想迅速从理论跳到一条金鱼。更确切地说，跳到马修·温斯坦的动画视频《E Lobro》<a id="ref-zh-ch01-44"></a>[44](#note-zh-ch01-44)，其中心是一条被女性化的金鱼蜿蜒游动——它同时嘲弄生命与人类性别区分，又演绎这些区分，在像金鱼缸中植物一样细长而过度生长的骨架之间滑行。<a id="ref-zh-ch01-45"></a>[45](#note-zh-ch01-45) 温斯坦的鱼和他的骨架一样死气沉沉，而我们无限确信它们都不曾真正活过，尽管全都高度动画化。这里的美学或许与克莱尔·科尔布鲁克所说的酷儿活力论相共鸣——作为潜能场域的被动活力论，它将使生命（包括性别化生命）得以实现——但也可能是其反面：处理一种死的潜能。<a id="ref-zh-ch01-46"></a>[46](#note-zh-ch01-46) 早期人工生命探索往往通过诡异感来运作，把这种感觉建立在“生命出现在不应出现之处”的感觉上（《大都会》再次可能是典型例子）。然而在此，这种诡异感已被驱散。我们或许只剩下罗莎琳德·高尔特所探讨的漂亮或装饰性。<a id="ref-zh-ch01-47"></a>[47](#note-zh-ch01-47)

<a id="ch01-p047-en"></a>
***‘Thus, to resist the present, I propose’, or, a goldfish responds***<a id="ref-en-ch01-43"></a>[43](#note-en-ch01-43) In the interests of linking this back to vitality and life, I want to rapidly jump from theory to a goldfish. More precisely to Matthew Weinstein’s animated video *E Lobro*,<a id="ref-en-ch01-44"></a>[44](#note-en-ch01-44) at the centre of which are the sinuous perambulations of a feminized goldfish – at once mocking life and human gender divisions and enacting them, as it slides between skeletons that are spindly and overgrown like the plants in a goldfish bowl.<a id="ref-en-ch01-45"></a>[45](#note-en-ch01-45) Weinstein’s fish is just as dead as his skeletons, and we are endlessly sure that none of them has ever quite lived, although all are highly animated. The aesthetic here might seem to resonate with what Claire Colebrook has described as a queer vitalism – passive vitalism as a field of potentialities that would enable life (including gendered life) to actualize – but might also be its obverse: dealing in a dead potentiality.<a id="ref-en-ch01-46"></a>[46](#note-en-ch01-46) Early explorations of artificial life tended to work through the uncanny, founding this on that sense of life found where it should not be (*Metropolis*, again, might be a canonical example). Here though, that has been routed. We are left, perhaps, with what Rosalind Galt has explored as the pretty or the decorative.<a id="ref-en-ch01-47"></a>[47](#note-en-ch01-47)

<a id="ch01-p048-zh"></a>
温斯坦的作品既演绎数字的拜物教（作为媒介拜物教），又对它作出评论。这样做时，它找到了一种*斜视*在线、被建构、屏幕上的身体状况的方式。这件作品当然不是教育性的，也不完全是抵抗性的，但它具有诊断性，并揭示某种特定的可感者分配目前如何被操作、如何施展吸引力。相比之下，硬媒介唯物主义无视想象，无法处理它所演绎的拜物教，因而太容易（并非必然）不去追问工业所提供的未来图景，而是径直漂入与它的结盟。新媒介唯物主义更奇怪的一点是，它在坚持物质的同时，最终追随了行业炒作。或许我们可以说，它被现存的不真实对象晃花了眼。

<a id="ch01-p048-en"></a>
Weinstein’s work both enacts the fetish of the digital, as medium fetish, and comments on it. In doing so a way is found to look *askance* at the online, constructed, on-screen bodily condition. This work is certainly not pedagogic and nor is it resistive exactly, but it is diagnostic and revelatory of ways in which a particular distribution of the sensible is currently operated and makes its appeal. By contrast, disregarding the imaginary, unable to deal with the fetish it enacts, hard medium materialism all too easily (not inevitably) does not interrogate, but simply drifts into alignment with, that vision of the future offered by industry. One of the odder things about new media materialism is the extent to which, insisting on the material, it is in the end following the industry hype. Perhaps we might say it is dazzled by extant unreal objects.

<a id="ch01-p049-zh"></a>
同样对斜视感兴趣的《愤怒》，作为一个从事写作的身体和一个写作成果之体，构成对新媒介唯物主义的另一种不完全属于人类的回应——后者被当作思考新媒介的规范视角。顺便说，这也是一个我们并不加以拜物化的身体。我们站在它背后，我、我、我，承认我们行动的限制和我们的可问责性，却并未由此呈现出一种缺席。正是通过一种既被主张又被部分拒绝（或被化解，以使它的权威质疑自身）的作者身份——它与实现明显不同，但与它共享一种肯定感——我们找到行动的空间，同时也承认我们的位置与场所。要点是找到一个写作的位置：既不是从不可能的“外部”（无中介的幻想可能把我们置于那里），也不是完全从内部得到确保——像新唯物主义媒介理论那样，相信自己在本体论上被决定的方式，恰与它所研究的材料相同。针对物质的拜物教——它产生一种匮乏的叙述，却坚持其肯定性，并坚持它完全真实——《愤怒》的回应是坚持写作的具体物质性（包括其中的自动化，以及它对手工劳动的要求），也坚持数字的物质性。它坚持二者的相互依赖。

<a id="ch01-p049-en"></a>
Also interested in looking askance, *Furious*, as a writing body and as a body of writing, constitutes another kind of not entirely human response to new media materialism as a normative perspective for thinking about new media. It is also, by the way, a body we do not fetishize. We stand behind it, I and I and I, recognizing our limits of movement, and our accountability, but not registering an absence. It is by way of an authorship at once asserted and partially refused (or defused so that its authority questions itself), which is conspicuously different from an actualization, but which shares with it a sense of affirmation, that we find room to move while also recognizing our place and location. The point was to find a place to write neither from the impossible outside, where the fantasy of un-mediation might place us, nor as entirely secured from within – as a new materialist medium theory that takes its status as ontologically determined in precisely the same way as the materials it studies believes itself to be. Against the fetish of the material which produces an account that is lacking while insisting it is affirmative – and insists it is entirely true – *Furious* responds by insisting on the specific materiality of writing (including in this its automation, as well as the labour it demands by hand) as well as the materiality of the digital. It insists on their co-dependence.

<a id="ch01-p050-zh"></a>
我们肯定数字媒介以及数字中介的身体与世界的开放潜能。我们抵抗强制/强制性之物，并非在于反对技术，更非反对信息技术。我们感兴趣的恰恰是它如何可能裂解（而非确认）一系列区分，包括活动形式与能动性形式之间的区分，以及那些以人类术语/等级来组织生命的区分。但我们保持我们的（后）人类性，并承认我们在计算资本主义中的处境位置——计算资本主义也是一个系统，却不同于纯信息论或控制论叙述所导出的系统；在后一种系统中，反馈并不理会意图，包括制造、开创、创作的意图。

<a id="ch01-p050-en"></a>
We affirm the open potential of digital media and of digitally mediated bodies and worlds. Our resistance to compulsion/the compulsory is not located in relation to technology, let alone information technology. We are interested in precisely how it may fracture (rather than confirm) a series of divisions, including those between forms of activity and agency, and those that organize life in human terms/hierarchies. But we maintain our (post-) humanity and recognize our situated position in computational capitalism – also a system, but not that derived from an entirely informational or cybernetic account – in which feedback is indifferent to intent, including intent to make, inaugurate, author.

<a id="ch01-p051-zh"></a>
这也为重新思考活力论、数字与唯物主义之间的政治关系指明了道路，至少作为一种建议，开启了以超越以下二分的方式重新思考能动性的可能：活力论（作为一种非人生命力）与被限制在过于频繁地被规范性刻写的身体中的生命。这项任务或许要求重新思考数字理论中一个“传统”的特殊限制；在唐娜·哈拉维（或她的赛博格）成为赛博文化理论奠基人物的程度上，这一限制甚至被奉为神圣。它就是那个说法：“当机器变得更有活力，我们变得更加惰性。”但为什么这个总和必然成立？系统（不必）是封闭的。活动无处不在。寻找计算它的新方式，并作为女性主义技术科学中一项亲技术计划的一部分来做这件事，是一项紧迫任务。如西苏所说：“一分钟也不能耽误。我们离开这里。”<a id="ref-zh-ch01-48"></a>[48](#note-zh-ch01-48)

<a id="ch01-p051-en"></a>
This also points the way for a rethinking of that political relationship between vitalism, the digital and materialism by opening – as a suggestion at least – the possibility of rethinking agency in terms that go beyond a division between vitalism (as an inhuman life force) and life as confined to the all too often normatively inscribed body. This task might entail a rethinking of a peculiar limitation that is ‘traditional’ in digital theory: to the extent that Donna Haraway (or her cyborg) has become a founding figure of cybercultural theory, it is even hallowed. It is the one that says, ‘as machines become more lively, we become more inert’. But why should this sum add up? The system (does not need to be) closed. There is activity all around. Finding new ways to calculate it and doing so as part of a technophile project of feminist technoscience is an urgent task. As Cixous put it: ‘Not a minute to lose. Let’s get out of here.’<a id="ref-en-ch01-48"></a>[48](#note-en-ch01-48)

### 原注

<a id="ch01-n001-zh"></a><a id="note-zh-ch01-1"></a>
[1] Hélène Cixous, ‘The Laugh of the Medusa’, trans. Keith Cohen and Paula Cohen, *Signs*, vol. 1, no. 4, Summer 1976, pp. 875–93, p. 892. 原文‘Le Rire de la Meduse’发表于 *L’Arc*，1975年，第39—54页。 [返回](#ref-zh-ch01-1)

<a id="ch01-n001-en"></a><a id="note-en-ch01-1"></a>
[1] Hélène Cixous, ‘The Laugh of the Medusa’, trans. Keith Cohen and Paula Cohen, *Signs*, vol. 1, no. 4, Summer 1976, pp. 875–93, p. 892. The original, ‘Le Rire de la Meduse’, appeared in *L’Arc*, 1975, pp. 39–54. [返回](#ref-en-ch01-1)

<a id="ch01-n002-zh"></a><a id="note-zh-ch01-2"></a>
[2] Caroline Bassett, Sarah Kember, Kate O’Riordan, *Furious: Technological Feminism and Digital Futures*, London: Pluto, 2020. [返回](#ref-zh-ch01-2)

<a id="ch01-n002-en"></a><a id="note-en-ch01-2"></a>
[2] Caroline Bassett, Sarah Kember, Kate O’Riordan, *Furious: Technological Feminism and* *Digital Futures,* London: Pluto, 2020. [返回](#ref-en-ch01-2)

<a id="ch01-n003-zh"></a><a id="note-zh-ch01-3"></a>
[3] Cixous, ‘The Laugh of the Medusa’, p. 893. [返回](#ref-zh-ch01-3)

<a id="ch01-n003-en"></a><a id="note-en-ch01-3"></a>
[3] Cixous, ‘The Laugh of the Medusa’, p. 893. [返回](#ref-en-ch01-3)

<a id="ch01-n004-zh"></a><a id="note-zh-ch01-4"></a>
[4] Ian Bogost, *Alien Phenomenology, or What It’s Like to Be a Thing*, Minneapolis MN: University of Minnesota Press, 2012, p. 38. [返回](#ref-zh-ch01-4)

<a id="ch01-n004-en"></a><a id="note-en-ch01-4"></a>
[4] Ian Bogost, *Alien Phenomenology, or What It’s Like to Be a Thing*, Minneapolis MN: University of Minnesota Press, 2012, p. 38. [返回](#ref-en-ch01-4)

<a id="ch01-n005-zh"></a><a id="note-zh-ch01-5"></a>
[5] “‘局势分析’可以被宽泛地定义为：分析在特定时期塑造某一社会场域内权力关系总体的趋同与发散倾向。” Jeremy Gilbert, ‘This Conjuncture: For Stuart Hall’, *New Formations: A Journal of Culture/Theory/Politics* 96, 2019, pp. 5–37. [返回](#ref-zh-ch01-5)

<a id="ch01-n005-en"></a><a id="note-en-ch01-5"></a>
[5] ‘“[C]onjunctural analysis” can be broadly defined as the analysis of convergent and divergent tendencies shaping the totality of power relations within a given social field during a particular period of time.’ Jeremy Gilbert, ‘This Conjuncture: For Stuart Hall’, *New Formations: A Journal of Culture/Theory/Politics* 96, 2019, pp. 5–37. [返回](#ref-en-ch01-5)

<a id="ch01-n006-zh"></a><a id="note-zh-ch01-6"></a>
[6] 参见例如斯科特·拉什在《生命（活力论）2》（‘Life (Vitalism) 2’）中对阿甘本的讨论，*Theory, Culture & Society*，第23卷，第2–3期，2006年，第323–49页。 [返回](#ref-zh-ch01-6)

<a id="ch01-n006-en"></a><a id="note-en-ch01-6"></a>
[6] See, for example, Scott Lash’s discussion of Agamben in ‘Life (Vitalism) 2’, *Theory,* *Culture & Society*, vol. 23, nos 2–3, 2006, pp. 323–49. [返回](#ref-en-ch01-6)

<a id="ch01-n007-zh"></a><a id="note-zh-ch01-7"></a>
[7] “乐观地说”，这些新人将是“我们……发生巨大改变”；悲观地说，他们是人类的继任者，“一个新种族，地球的继承者……篡夺者”。Russell Blackford, ‘The Great Transition’, in *The Transhumanist Reader: Classical and Contemporary Essays on the Science, Technology, and Philosophy of the Human Future*, London: Wiley, 2013, pp. 421–9, p. 442. [返回](#ref-zh-ch01-7)

<a id="ch01-n007-en"></a><a id="note-en-ch01-7"></a>
[7] ‘Optimistically’, these new people will be ‘us … greatly changed’; pessimistically they are humanity’s successors, ‘a new race, the inheritors of the earth … usurpers’. Russell Blackford, ‘The Great Transition’, in *The* *Transhumanist Reader: Classical and* *Contemporary Essays on the Science, Technology, and Philosophy of the Human Future*, London: Wiley, 2013, pp. 421–9, p. 442. [返回](#ref-en-ch01-7)

<a id="ch01-n008-zh"></a><a id="note-zh-ch01-8"></a>
[8] Mark Fisher, *Capitalist Realism: Is There No Alternative?*, Winchester: Zero Books, 2009. [返回](#ref-zh-ch01-8)

<a id="ch01-n008-en"></a><a id="note-en-ch01-8"></a>
[8] Mark Fisher, *Capitalist Realism: Is There No Alternative?*, Winchester: Zero Books, 2009. [返回](#ref-en-ch01-8)

<a id="ch01-n009-zh"></a><a id="note-zh-ch01-9"></a>
[9] Ellen Meiksins Wood, ed. Larry Patriquin, *The Ellen Meiksins Wood Reader*, Leiden: Brill, 2012. [返回](#ref-zh-ch01-9)

<a id="ch01-n009-en"></a><a id="note-en-ch01-9"></a>
[9] Ellen Meiksins Wood, ed. Larry Patriquin, *The Ellen Meiksins Wood Reader*, Leiden: Brill, 2012. [返回](#ref-en-ch01-9)

<a id="ch01-n010-zh"></a><a id="note-zh-ch01-10"></a>
[10] 参见例如 Irmgard Emmelhainz, ‘Can We Share a World Beyond Representation?’, *E-Flux Journal* 106, February 2020. [返回](#ref-zh-ch01-10)

<a id="ch01-n010-en"></a><a id="note-en-ch01-10"></a>
[10] See, for example, Irmgard Emmelhainz, ‘Can We Share a World Beyond Representation?’, *E-Flux Journal* 106, February 2020. [返回](#ref-en-ch01-10)

<a id="ch01-n011-zh"></a><a id="note-zh-ch01-11"></a>
[11] Lash, ‘Life (Vitalism) 2’. [返回](#ref-zh-ch01-11)

<a id="ch01-n011-en"></a><a id="note-en-ch01-11"></a>
[11] Lash, ‘Life (Vitalism) 2’. [返回](#ref-en-ch01-11)

<a id="ch01-n012-zh"></a><a id="note-zh-ch01-12"></a>
[12] Hito Steyerl, *Is the Museum a Battlefield?*, 2014年3月在伦敦 ICA 发表的演讲。 [返回](#ref-zh-ch01-12)

<a id="ch01-n012-en"></a><a id="note-en-ch01-12"></a>
[12] Hito Steyerl, *Is the Museum a Battlefield?*, talk delivered to the ICA, London, March 2014. [返回](#ref-en-ch01-12)

<a id="ch01-n013-zh"></a><a id="note-zh-ch01-13"></a>
[13] 西苏：“写作，这一行为……”；“正是用她的身体，她有力地支撑着她言语的‘逻辑’。”《美杜莎的笑声》，第880–81页。 [返回](#ref-zh-ch01-13)

<a id="ch01-n013-en"></a><a id="note-en-ch01-13"></a>
[13] Cixous: ‘To write, an act…’; ‘it’s with her body that she vitally supports the “logic” of her speech’. ‘The Laugh of the Medusa’, pp. 880–81. [返回](#ref-en-ch01-13)

<a id="ch01-n014-zh"></a><a id="note-zh-ch01-14"></a>
[14] Johanna Drucker, ‘Beyond Conceptualisms: Poetics after Critique and the End of the Individual Voice’, *The Poetry Project Newsletter*, April–May 2012; https://pages.gseis.ucla.edu/faculty/drucker/Paris/PoetryNewsletter\_IndVoice.pdf. [返回](#ref-zh-ch01-14)

<a id="ch01-n014-en"></a><a id="note-en-ch01-14"></a>
[14] Johanna Drucker, ‘Beyond Conceptualisms: Poetics after Critique and the End of the Individual Voice’, *The Poetry Project Newsletter*, April–May 2012; https://pages.gseis. ucla.edu/faculty/drucker/Paris/PoetryNewsletter\_IndVoice.pdf. [返回](#ref-en-ch01-14)

<a id="ch01-n015-zh"></a><a id="note-zh-ch01-15"></a>
[15] 本雅明宣称，“一部作品的文学倾向只有在其文学上正确时，政治上才可能是正确的”，并补充说，“一部作品正确的政治倾向包含其文学品质，因为它包含其文学倾向”。‘The Author as Producer’, in Walter Benjamin, *Selected Writings*, vol. 2, London and New York: Harvard University Press, 2004, pp. 768–81, p. 769. [返回](#ref-zh-ch01-15)

<a id="ch01-n015-en"></a><a id="note-en-ch01-15"></a>
[15] Benjamin declared that ‘the literary tendency of a work can only be politically correct if it is also literarily correct’, adding that ‘the correct political tendency of a work includes its literary quality because it includes its literary tendency’. ‘The Author as Producer’, in Walter Benjamin, *Selected Writings*, vol. 2, London and New York: Harvard University Press, 2004, pp. 768–81, p. 769. [返回](#ref-en-ch01-15)

<a id="ch01-n016-zh"></a><a id="note-zh-ch01-16"></a>
[16] 参见 Franco Moretti, *Distant Reading*, London and New York: Verso, 2013. [返回](#ref-zh-ch01-16)

<a id="ch01-n016-en"></a><a id="note-en-ch01-16"></a>
[16] See Franco Moretti, *Distant Reading*, London and New York: Verso, 2013. [返回](#ref-en-ch01-16)

<a id="ch01-n017-zh"></a><a id="note-zh-ch01-17"></a>
[17] 这个新造词来自贝克特，是对法语 *prevoir* 的戏仿。贝克特谈到“最终不可预视的原子”（引自 Conor Carville, *Samuel Beckett and the Visual*, Cambridge: Cambridge University Press, 2018, p. 57）。 [返回](#ref-zh-ch01-17)

<a id="ch01-n017-en"></a><a id="note-en-ch01-17"></a>
[17] The neologism is from Beckett and is a play on the French *prevoir*. Beckett talks of the ‘ultimately unprevisible atom’ (cited in Conor Carville, *Samuel Beckett and the Visual*, Cambridge: Cambridge University Press, 2018, p. 57). [返回](#ref-en-ch01-17)

<a id="ch01-n018-zh"></a><a id="note-zh-ch01-18"></a>
[18] 参见 Karen Barad, ‘Posthumanist Performativity: Toward an Understanding of How Matter Comes to Matter’, *Signs: Journal of Women in Culture and Society*, vol. 28, no. 3, Spring, 2003, pp. 801–31。“话语要紧。文化要紧……唯一似乎不再要紧的，就是物质”（第801页）。 [返回](#ref-zh-ch01-18)

<a id="ch01-n018-en"></a><a id="note-en-ch01-18"></a>
[18] See Karen Barad, ‘Posthumanist Performativity: Toward an Understanding of How Matter Comes to Matter’, *Signs: Journal of Women in Culture and Society*, vol. 28, no. 3, Spring, 2003, pp. 801–31. ‘Discourse matters. Culture matters … the only thing that does not seem to matter anymore is matter’ (p. 801). [返回](#ref-en-ch01-18)

<a id="ch01-n019-zh"></a><a id="note-zh-ch01-19"></a>
[19] Patrick Crogan, ‘Indie Dreams: Video Games, Creative Economy, and the Hyperindustrial Epoch’, *Games and Culture*, vol. 13, no. 7, 2018, pp. 671–89. [返回](#ref-zh-ch01-19)

<a id="ch01-n019-en"></a><a id="note-en-ch01-19"></a>
[19] Patrick Crogan, ‘Indie Dreams: Video Games, Creative Economy, and the Hyperindustrial Epoch’, *Games and Culture*, vol. 13, no. 7, 2018, pp. 671–89. [返回](#ref-en-ch01-19)

<a id="ch01-n020-zh"></a><a id="note-zh-ch01-20"></a>
[20] Alex Galloway, ‘Love of the Middle’, in Alexander R. Galloway, Eugene Thacker and McKenzie Wark, *Excommunication: Three Inquiries in Media and Mediation*, Chicago and London: Chicago University Press, 2013. [返回](#ref-zh-ch01-20)

<a id="ch01-n020-en"></a><a id="note-en-ch01-20"></a>
[20] Alex Galloway, ‘Love of the Middle’, in Alexander R. Galloway, Eugene Thacker and McKenzie Wark, *Excommunication: Three Inquiries in Media and Mediation*, Chicago and London: Chicago University Press, 2013. [返回](#ref-en-ch01-20)

<a id="ch01-n021-zh"></a><a id="note-zh-ch01-21"></a>
[21] 同上，第56页。 [返回](#ref-zh-ch01-21)

<a id="ch01-n021-en"></a><a id="note-en-ch01-21"></a>
[21] Ibid., p. 56. [返回](#ref-en-ch01-21)

<a id="ch01-n022-zh"></a><a id="note-zh-ch01-22"></a>
[22] 同上，第59、62页。 [返回](#ref-zh-ch01-22)

<a id="ch01-n022-en"></a><a id="note-en-ch01-22"></a>
[22] Ibid., pp. 59, 62. [返回](#ref-en-ch01-22)

<a id="ch01-n023-zh"></a><a id="note-zh-ch01-23"></a>
[23] Cixous, ‘The Laugh of the Medusa’, p. 888. [返回](#ref-zh-ch01-23)

<a id="ch01-n023-en"></a><a id="note-en-ch01-23"></a>
[23] Cixous,‘The Laugh of the Medusa’, p. 888. [返回](#ref-en-ch01-23)

<a id="ch01-n024-zh"></a><a id="note-zh-ch01-24"></a>
[24] 参见 Jussi Parikka 对巴拉德的刻画：在帕里卡的描述中，巴拉德坚持认为‘批判’模式有害于当代文化分析。*Machinology*, 2014, jussiparikk.net，无页码。 [返回](#ref-zh-ch01-24)

<a id="ch01-n024-en"></a><a id="note-en-ch01-24"></a>
[24] See Jussi Parikka’s characterization of Barad as insisting on ‘the mode of ‘critique’ as harmful for contemporary cultural analysis. *Machinology*, 2014, jussiparikk.net, n.pag. [返回](#ref-en-ch01-24)

<a id="ch01-n025-zh"></a><a id="note-zh-ch01-25"></a>
[25] Rosi Braidotti, ‘Borrowed Energy’，Timotheus Vermeulen 访谈，*Frieze*, https://frieze.com/article/borrowed-energy，无页码。 [返回](#ref-zh-ch01-25)

<a id="ch01-n025-en"></a><a id="note-en-ch01-25"></a>
[25] Rosi Braidotti, ‘Borrowed Energy’, interview by Timotheus Vermeulen, *Frieze*, https://frieze.com/article/borrowed-energy, n.pag. [返回](#ref-en-ch01-25)

<a id="ch01-n026-zh"></a><a id="note-zh-ch01-26"></a>
[26] Simon Choat, ‘Science, Agency and Ontology: A Historical-Materialist Response to New Materialism’, *Political Studies*, vol. 66, no. 4, 2017, pp. 1027–42, p. 1028. [返回](#ref-zh-ch01-26)

<a id="ch01-n026-en"></a><a id="note-en-ch01-26"></a>
[26] Simon Choat, ‘Science, Agency and Ontology: A Historical-Materialist Response to New Materialism’, *Political Studies*, vol. 66, no. 4, 2017, pp. 1027–42, p. 1028. [返回](#ref-en-ch01-26)

<a id="ch01-n027-zh"></a><a id="note-zh-ch01-27"></a>
[27] Jussi Parikka, ‘New Materialism as Media Theory: Medianatures and Dirty Matter’, *Communication and Critical/Cultural Studies*, vol. 9, no. 1, March 2012, pp. 95–100. [返回](#ref-zh-ch01-27)

<a id="ch01-n027-en"></a><a id="note-en-ch01-27"></a>
[27] Jussi Parikka, ‘New Materialism as Media Theory: Medianatures and Dirty Matter’, *Communication and Critical/Cultural Studies*, vol. 9, no. 1, March 2012, pp. 95–100. [返回](#ref-en-ch01-27)

<a id="ch01-n028-zh"></a><a id="note-zh-ch01-28"></a>
[28] Jane Bennett, *Vibrant Matter: A Political Ecology of Things*, Durham NC: Duke University Press, 2010. [返回](#ref-zh-ch01-28)

<a id="ch01-n028-en"></a><a id="note-en-ch01-28"></a>
[28] Jane Bennett, *Vibrant Matter: A Political Ecology of Things*, Durham NC: Duke University Press, 2010. [返回](#ref-en-ch01-28)

<a id="ch01-n029-zh"></a><a id="note-zh-ch01-29"></a>
[29] 此处与“物理论”的距离似乎很大。但二者有明显联系。在一篇同名文章中，Bill Brown 开头便问，物是否可能不被打扰；“让它们留在别处安息……超越理论……[在]某个未被符号中介的本源之处……某种具体之物，使我们从不必要的抽象中解脱出来。” Bill Brown, ‘Thing Theory’, *Critical Inquiry* 28, Autumn 2001, pp. 1–22；他接着补充说，“想得美”。 [返回](#ref-zh-ch01-29)

<a id="ch01-n029-en"></a><a id="note-en-ch01-29"></a>
[29] The distance here from ‘thing theory’ might seem great. But there are obvious connections. In an eponymous article Bill Brown begins by wondering if things may not be let alone; ‘let them rest somewhere else … beyond theory … [in] some place of origin unmediated by the sign … something concrete that relieves us from unnecessary abstraction.’ Bill Brown, ‘Thing Theory’, *Critical Inquiry* 28, Autumn 2001, pp. 1–22; ‘fat chance’, he goes on to add. [返回](#ref-en-ch01-29)

<a id="ch01-n030-zh"></a><a id="note-zh-ch01-30"></a>
[30] Friedrich Kittler, ‘Code (or, How you can write something differently)’, in Matt Fuller, ed., *Software Studies: A Lexicon*, Cambridge MA and London: MIT Press, 2008, pp. 40–46, p. 40. [返回](#ref-zh-ch01-30)

<a id="ch01-n030-en"></a><a id="note-en-ch01-30"></a>
[30] Friedrich Kittler, ‘Code (or, How you can write something differently)’, in Matt Fuller, ed., *Software Studies: A Lexicon*, Cambridge MA and London: MIT Press, 2008, pp. 40–46, p. 40. [返回](#ref-en-ch01-30)

<a id="ch01-n031-zh"></a><a id="note-zh-ch01-31"></a>
[31] Jussi Parikka, ‘New Materialism as Media Theory: Medianatures and Dirty Matter’, *Communications and Critical Cultural Studies*, vol 9, no. 1, 2012, pp. 95–100, p. 95. Bill Brown 主张，每一种新的媒介形式都会重组人与物的关系（‘Thing Theory’, p. 16）。 [返回](#ref-zh-ch01-31)

<a id="ch01-n031-en"></a><a id="note-en-ch01-31"></a>
[31] Jussi Parikka, ‘New Materialism as Media Theory: Medianatures and Dirty Matter’, *Communications and Critical Cultural Studies*, vol 9, no. 1, 2012, pp. 95–100, p. 95. Bill Brown argues that each new media form reorganizes the relationship between people and things (‘Thing Theory’, p. 16). [返回](#ref-en-ch01-31)

<a id="ch01-n032-zh"></a><a id="note-zh-ch01-32"></a>
[32] 参见 Fredric Jameson 论作为活力强度形式的肮脏现实主义：*The Seeds of Time*, New York: Columbia University Press, 1994, p. 145. [返回](#ref-zh-ch01-32)

<a id="ch01-n032-en"></a><a id="note-en-ch01-32"></a>
[32] See Fredric Jameson on dirty realism as a form of vital intensity: *The* *Seeds of Time*, New York: Columbia University Press, 1994, p. 145. [返回](#ref-en-ch01-32)

<a id="ch01-n033-zh"></a><a id="note-zh-ch01-33"></a>
[33] Dana Boyd and Kate Crawford, ‘Critical Questions for Big Data’, *Information, Communication and Society*, vol. 15, no. 5, 2012, pp. 662–79. [返回](#ref-zh-ch01-33)

<a id="ch01-n033-en"></a><a id="note-en-ch01-33"></a>
[33] Dana Boyd and Kate Crawford, ‘Critical Questions for Big Data’, *Information,* *Communication and Society*, vol. 15, no. 5, 2012, pp. 662–79. [返回](#ref-en-ch01-33)

<a id="ch01-n034-zh"></a><a id="note-zh-ch01-34"></a>
[34] Chris Anderson, ‘The End of Theory: The Data Deluge Makes the Scientific Method Obsolete’, *Wired*, 16 July 2012, http://archive.wired.com/science/discoveries/magazine/16-07/pb\_theory. [返回](#ref-zh-ch01-34)

<a id="ch01-n034-en"></a><a id="note-en-ch01-34"></a>
[34] Chris Anderson, ‘The End of Theory: The Data Deluge Makes the Scientific Method Obsolete’, *Wired*, 16 July 2012, http://archive.wired.com/science/discoveries/ magazine/16-07/pb\_theory. [返回](#ref-en-ch01-34)

<a id="ch01-n035-zh"></a><a id="note-zh-ch01-35"></a>
[35] Kate O’Riordan, *Unreal Objects*, London: Pluto Press, 2017. [返回](#ref-zh-ch01-35)

<a id="ch01-n035-en"></a><a id="note-en-ch01-35"></a>
[35] Kate O’Riordan, *Unreal Objects*, London: Pluto Press, 2017. [返回](#ref-en-ch01-35)

<a id="ch01-n036-zh"></a><a id="note-zh-ch01-36"></a>
[36] Alex Galloway 或许会说，我们大概会那样说。他评论道，“解释学的终极恶棍是拜物教”。‘Love of the Middle’, p. 44。但我们从来不只是解释学的；这正是坚持写作与理论的生产性之要点。 [返回](#ref-zh-ch01-36)

<a id="ch01-n036-en"></a><a id="note-en-ch01-36"></a>
[36] Alex Galloway would say perhaps we would say that. He comments that ‘the ultimate villain for hermeneutics is fetishism’. ‘Love of the Middle’, p. 44. But we were never only hermeneutical; that is the point of insisting on writing and theory’s productivity. [返回](#ref-en-ch01-36)

<a id="ch01-n037-zh"></a><a id="note-zh-ch01-37"></a>
[37] 参见 Boštjan Nedoh, *Ontology and Perversion: Deleuze, Agamben, Lacan*, London: Rowman & Littlefield, 2019, p. 102. [返回](#ref-zh-ch01-37)

<a id="ch01-n037-en"></a><a id="note-en-ch01-37"></a>
[37] See Boštjan Nedoh, *Ontology and Perversion: Deleuze, Agamben, Lacan*, London: Rowman & Littlefield, 2019, p.102. [返回](#ref-en-ch01-37)

<a id="ch01-n038-zh"></a><a id="note-zh-ch01-38"></a>
[38] 参见西苏：“但我们绝无义务把我们的生命存入他们那匮乏的银行。” 《美杜莎的笑声》，第885页。 [返回](#ref-zh-ch01-38)

<a id="ch01-n038-en"></a><a id="note-en-ch01-38"></a>
[38] Cf. Cixous: ‘But we are in no way obliged to deposit our lives in their banks of lack.’ ‘The Laugh of the Medusa’, p. 885. [返回](#ref-en-ch01-38)

<a id="ch01-n039-zh"></a><a id="note-zh-ch01-39"></a>
[39] Wendy Hui Kyong Chun, ‘Sourcery or Code as Fetish’, *Configurations* 16, 2008, pp. 299–324. [返回](#ref-zh-ch01-39)

<a id="ch01-n039-en"></a><a id="note-en-ch01-39"></a>
[39] Wendy Hui Kyong Chun, ‘Sourcery or Code as Fetish’, *Configurations* 16, 2008, pp. 299–324. [返回](#ref-en-ch01-39)

<a id="ch01-n040-zh"></a><a id="note-zh-ch01-40"></a>
[40] 关于维度与动画，参见 Esther Leslie, *Hollywood Flatlands: Animation, Critical Theory and the Avant-Garde*, London: Verso, 2004. [返回](#ref-zh-ch01-40)

<a id="ch01-n040-en"></a><a id="note-en-ch01-40"></a>
[40] On dimensionality and animation, see Esther Leslie, *Hollywood Flatlands:* *Animation, Critical Theory and the Avant-Garde*, London: Verso, 2004. [返回](#ref-en-ch01-40)

<a id="ch01-n041-zh"></a><a id="note-zh-ch01-41"></a>
[41] Brown 指出，拜物教长期与一种特殊的“物理论”相关联；例如在 Arjun Appadurai 的作品中。Brown, ‘Thing Theory’, p. 6; Arjun Appadurai, ‘Introduction’ in *The Social Life of Things*, Cambridge: Cambridge University Press, 1985. [返回](#ref-zh-ch01-41)

<a id="ch01-n041-en"></a><a id="note-en-ch01-41"></a>
[41] Brown points out that the fetish has long been associated with a particular kind of ‘thing theory’; for example, in Arjun Appadurai’s work. Brown, ‘Thing Theory’, p. 6; Arjun Appadurai, ‘Introduction’ in *The Social Life of Things*, Cambridge: Cambridge University Press, 1985. [返回](#ref-en-ch01-41)

<a id="ch01-n042-zh"></a><a id="note-zh-ch01-42"></a>
[42] “打破旧回路……让我们去拜物化”，Cixous, ‘The Laugh of the Medusa’, p. 891. [返回](#ref-zh-ch01-42)

<a id="ch01-n042-en"></a><a id="note-en-ch01-42"></a>
[42] ‘Break the old circuits… Let us defetishize’, Cixous, ‘The Laugh of the Medusa’, p.  891. [返回](#ref-en-ch01-42)

<a id="ch01-n043-zh"></a><a id="note-zh-ch01-43"></a>
[43] 这一说法来自 Irmgaard Emmelhainz。‘Can We Share a World Beyond Representation?’, p. 10. [返回](#ref-zh-ch01-43)

<a id="ch01-n043-en"></a><a id="note-en-ch01-43"></a>
[43] The phrase is Irmgaard Emmelhainz’s. ‘Can We Share a World Beyond Representation?’, p. 10. [返回](#ref-en-ch01-43)

<a id="ch01-n044-zh"></a><a id="note-zh-ch01-44"></a>
[44] www.matthewweinstein.com/works/e-lobro-15/video?view=slider。我感谢 Matthew Weinstein 允许在此复制一张剧照。 [返回](#ref-zh-ch01-44)

<a id="ch01-n044-en"></a><a id="note-en-ch01-44"></a>
[44] www.matthewweinstein.com/works/e-lobro-15/video?view=slider. I am grateful to Matthew Weinstein for permission to reproduce a still here. [返回](#ref-en-ch01-44)

<a id="ch01-n045-zh"></a><a id="note-zh-ch01-45"></a>
[45] Martha Cook 曾在一篇硕士论文中对《E Lobro》作出精彩论述。我对她心存感激。 [返回](#ref-zh-ch01-45)

<a id="ch01-n045-en"></a><a id="note-en-ch01-45"></a>
[45] Martha Cook has written a beautiful account of *E Lobro* in an MPhil essay. I am indebted to her. [返回](#ref-en-ch01-45)

<a id="ch01-n046-zh"></a><a id="note-zh-ch01-46"></a>
[46] Claire Colebrook, ‘Queer Vitalism’, *New Formations* 68, 2010, pp. 77–92, p. 80. [返回](#ref-zh-ch01-46)

<a id="ch01-n046-en"></a><a id="note-en-ch01-46"></a>
[46] Claire Colebrook, ‘Queer Vitalism’, *New Formations* 68, 2010, pp. 77–92, p. 80. [返回](#ref-en-ch01-46)

<a id="ch01-n047-zh"></a><a id="note-zh-ch01-47"></a>
[47] Rosalind Galt, *Pretty: Film and the Decorative Image*, New York: Columbia University Press, 2011. [返回](#ref-zh-ch01-47)

<a id="ch01-n047-en"></a><a id="note-en-ch01-47"></a>
[47] Rosalind Galt, *Pretty: Film and the Decorative Image*, New York: Columbia University Press, 2011. [返回](#ref-en-ch01-47)

<a id="ch01-n048-zh"></a><a id="note-zh-ch01-48"></a>
[48] Cixous, ‘The Laugh of the Medusa’, p. 885. [返回](#ref-zh-ch01-48)

<a id="ch01-n048-en"></a><a id="note-en-ch01-48"></a>
[48] Cixous, ‘The Laugh of the Medusa’, p. 885. [返回](#ref-en-ch01-48)

## 第2章　新唯物主义的慰藉

<a id="ch02-title-zh"></a>
## 新唯物主义的慰藉

<a id="ch02-title-en"></a>
## The consolation of new materialism

<a id="ch02-author-zh"></a>
凯斯顿·萨瑟兰

<a id="ch02-author-en"></a>
KESTON SUTHERLAND

<a id="ch02-p001-zh"></a>
新唯物主义对资本主义表示厌恶时那种阴郁的半心半意，塑造并渲染了它关于生命未来的一切声明。资本主义被含糊地、顺带地、仿佛例行尽职般地责备，罪名是一连串古怪抽象的破坏行为：从用它的“公理”压扁“社会与文化运动”的“多向敞开”和“多种由好奇心驱动的知识实践”，到阻止“宇宙的虚拟性”继续作为“一切生命的共有形式”。<a id="ref-zh-ch02-1"></a>[1](#note-zh-ch02-1) 资本主义显然是这些劝诫的目标，因为它被点名；而资本主义干出这些事确实不可取；若不在新唯物主义无畏地宣告新的抵抗时与它携起手来，似乎有点闹别扭。这必定是抵抗，因为这个词也是一个关键词。任何一个诚实的资本主义憎恨者，为何会退缩，不敢“把‘活物质’当作一个以*生命*（*zoe*）—地球为中心的过程，它以复杂方式与技术—社会、心理和自然环境互动，并抵抗资本主义利润原则（及其带来的结构性不平等）的过编码”，也不敢通过对抗而“最终落在一个横贯主体性的肯定性构成平面上”？那么，“一种可能启发、配合或支撑信息与科学实践，并抵抗发达资本主义对生命的跨物种商品化的后人类思想”，究竟能有什么害处？<a id="ref-zh-ch02-2"></a>[2](#note-zh-ch02-2) 抵抗当然受欢迎，无论它来自何种复杂互动过程或支撑性思想。即便它不能恰好来自人类，它仍可惠及（某些）人类。“人内部的非人，作为抵抗，是使（某些）人得以改变其生存条件、去制造、创造、发明的创造性力量。”<a id="ref-zh-ch02-3"></a>[3](#note-zh-ch02-3)（这个括号将被理解为非常高效地表示：承认人类的多样性，以及他们相对于人内部的非人所处的显然极不相同的立场；同时表示谦逊，承认并非所有人类都能同样地通过重新使用这种创造性力量来改变其生存条件。）

<a id="ch02-p001-en"></a>
The dismal half-heartedness of new materialism’s professions of antipathy to capitalism shapes and colours all its pronouncements on the future of life. Capitalism is reproved, indistinctly and in passing, as if with due diligence, for a catalogue of oddly abstract vandalisms: everything from squashing with its ‘axioms’ the ‘multi-directional opening out’ of ‘social and cultural movements’ and ‘multiple curiosity-driven knowledge practices’ to preventing the ‘virtuality of the cosmos’ from remaining ‘as a form of commons for all life’.<a id="ref-en-ch02-1"></a>[1](#note-en-ch02-1) Capitalism evidently is the target of these remonstrances because it is called out by name, and these certainly are undesirable things for capitalism to get up to, and it may seem a bit sulky not to link arms with new materialism in its dauntless proclamations of the new resistance. Resistance it must be, because this word, too, is a keyword. Why would any honest hater of capitalism shrink from ‘taking “living matter” as a *zoe*-geo-centred process that interacts in complex ways with the techno-social, psychic and natural environments and resists the over-coding by the capitalist profit principle (and the structural inequalities it entails)’ and by opposing ‘end up on an affirmative plane of composition of transversal subjectivities’? What could possibly be the harm in ‘a posthuman thought that might inspire, work with or subtend informational and scientific practices and resist the trans-species commodification of life by advanced capitalism’?<a id="ref-en-ch02-2"></a>[2](#note-en-ch02-2) Resistance, surely, is welcome, whatever process of complex interaction or subtensive thought it comes from. If it cannot exactly come from humans, it can still be of benefit to (some of) them. ‘The inhuman within the human, as resistance, is the creative force that enables (some) humans to transform their conditions of existence, to make, create, invent.’<a id="ref-en-ch02-3"></a>[3](#note-en-ch02-3) (The parenthesis will be understood to signify, very efficiently, acknowledgement of the diversity of humans and the obviously very different positions they are in relative to the inhuman within the human, and humility with respect to the fact that not all humans will be equally enabled to transform their conditions of existence by making new use of this creative force.)

<a id="ch02-p002-zh"></a>
那种绝不能来自人类的抵抗，最终或许由物质本身提供——按新的方式理解，遵循德里达对“物质之去实体化”的解释，这种去实体化“源于把物质性铭写为与他者的不可能关系这一解构性铭写”；物质不再是物质，而是不可能的“物质性之力”。在这种新意义上，物质甚至还可以代表一种彻底回避人类的最精巧方法，这反过来会使抵抗从政治中解放出来。“作为对主体力量的瓦解，物质性之力不能通向任何政治纲领。”作为不能通向政治纲领的抵抗，物质性之力也把资本主义的对手——其作为主体的力量最终被彻底瓦解——从可被预期的未来的死胡同中解放出来。“因为物质性把我们引向彻底的他者，它也是不可预见之未来的开启，一个不能被预期为某种在场形式的*à-venir*（将来）。”通过诉诸彻底他者、或诉诸“比具体实际更物质、更真实得令人诧异”的“不可能者”而来的抵抗，不允许其更激进的瓦解有任何例外，无论历史如何；最革命的批判，甚至革命战争，也与任何其他“基于理性计算或理想目的之筹划的目的性行动或目标导向行动”无异，因为那不可能的、比具体实际更真实的物质性之力，连同“任何目的论，例如马克思主义的目的论”，一起“抵抗并挫败”这一切。<a id="ref-zh-ch02-4"></a>[4](#note-zh-ch02-4)

<a id="ch02-p002-en"></a>
Resistance that must not come from humans may ultimately be provided by matter itself, understood in the new way, following Derrida’s explanation of ‘the desubstantialization of matter that occurs as a result of the deconstructive inscription of materiality as the impossible relation to the other’, no longer as matter, but now as ‘the force of materiality’ that is impossible. Matter in this new sense may even in addition represent the most sophisticated method of avoiding the human altogether, which would in turn liberate resistance from politics. ‘As the undoing of the power of the subject, the force of materiality cannot lead to a political program.’ The force of materiality as resistance that cannot lead to a political program also frees the opponent of capitalism, whose power as a subject has at last been altogether undone, from the dead end of a future that can be anticipated. ‘Because it refers us to the radically other, materiality is also the opening of an unforeseeable future, an *à-venir* (to come) that cannot be anticipated as a form of presence.’ Resistance by referral to the radically other, or ‘the impossible’ that ‘is curiously more material and real than concrete actuality’, can allow no exceptions to its more radical undoing, irrespective of history; the most revolutionary critique and even revolutionary warfare is no different from any other ‘purposive or end-oriented action that is based on rational calculations or the projection of an ideal end’, since the force of materiality that is impossible and more real than concrete actuality ‘resists and confounds’ all this along with ‘any teleology such as that of Marxism’.<a id="ref-en-ch02-4"></a>[4](#note-en-ch02-4)

<a id="ch02-p003-zh"></a>
用 Pheng Cheah 的话说，对新唯物主义而言，对资本主义的抵抗与对马克思主义的抵抗“令人诧异地”相似，甚至完全相同；从前者跳到后者，短得令人诧异。马克思主义一旦以新方式、以物质性之力、非人和横贯主体性的名义被成功抵抗，就显露出真面目：它并不是其死硬追随者至今仍执迷不悟地误认的那种资本主义革命批判，而是与资本主义一样，是一种病态的先驱，预示着将要到来的后人类内在性平面的活力——那个少数主义天堂，充满“从资本主义公理中解放出来的市场经济中各种新型经济生产实践”的繁荣。<a id="ref-zh-ch02-5"></a>[5](#note-zh-ch02-5) 美妙之处在于，抵达那里竟如此简单。进入它，就像进入克雷格·雷恩诗中的尘世天堂一样容易——别人只是把洗好的衣服从后花园收进来。我们只需放弃我们的“普罗米修斯式的人类统治自然观念”和马克思主义，同时放弃那由有毒律令所定义的“物种自恋”——该律令说“‘生命’必须保持特殊，也就是从根本上不同于物质”。<a id="ref-zh-ch02-6"></a>[6](#note-zh-ch02-6) 唯物主义仍然是——或者说，现在才第一次成为——这种转变的恰当载体，前提是首先根据一种“范式转换”迅速重估“马克思主义的遗产及其对唯物主义的特殊主张”：从（历史悠久且仍占主导的）把唯物主义与经济主义混为一谈，转向一种主要被定义为意指和过程中的主体性的革新版唯物主义。<a id="ref-zh-ch02-7"></a>[7](#note-zh-ch02-7)

<a id="ch02-p003-en"></a>
The resistance of capitalism and the resistance of Marxism are, to use Cheah’s word, ‘curiously’ alike, or even identical, for new materialism, and it is a curiously short hop from one to the other. Marxism, once it has been successfully resisted, in the new way, in the name of the force of materiality, the inhuman and transversal subjectivities, turns out to be not the revolutionary critique of capitalism that its diehard adherents even now persist in mistaking it for, but, like capitalism, a morbid precursor to the vitality of the posthuman plane of immanence to come, that minoritarian paradise full of the flourishing of ‘new kinds of economically productive practices in a market economy liberated from capitalist axioms’.<a id="ref-en-ch02-5"></a>[5](#note-en-ch02-5) And the beautiful thing is, what a simple thing it is to get there. It is as easy to enter as the heaven on earth accessed by somebody else bringing the washing in from the back garden in a Craig Raine poem. We need only give up our ‘Promethean ideas of human mastery over nature’ and Marxism, along with the ‘kind of species-narcissism’ defined by the toxic imperative that ‘“life” must remain special – that is, radically other to matter’.<a id="ref-en-ch02-6"></a>[6](#note-en-ch02-6) Materialism is still, or, rather, is now for the first time, the proper vehicle for this transformation, provided that ‘the legacy of Marxism and its particular claim to materialism’ is first swiftly revaluated in the light of the ‘paradigm shift from the (time-honoured and still prevalent) conflation of materialism with economism to a revamped materialism defined primarily as signification and subjectivity-in-process.’<a id="ref-en-ch02-7"></a>[7](#note-en-ch02-7)

<a id="ch02-s01-zh"></a>
## **或者以狄慈根为例**

<a id="ch02-s01-en"></a>
## **Or Dietzgen, for example**

<a id="ch02-p004-zh"></a>
在马克思、恩格斯、狄慈根、普列汉诺夫、列宁、卢森堡和其他革命者使用该词的意义上，唯物主义从来不只是关于物质或物质性的理论，而始终也是、并且首先是革命教育学。<a id="ref-zh-ch02-8"></a>[8](#note-zh-ch02-8) 它是那些献身于摧毁资本的个体群体训练其“思维力”、并相互教导世界知识的途径。这种教导大多发生在学习机构之外，或逆着其文化进行，与学术资本和学术生涯的生产律令几乎没有关系。（这样一种想法：这种革命唯物主义有朝一日会因对主体性过于浪漫、因执迷于过时的人类、因轻信到竟试图详细预想未来社会关系的各种形式并在实践中加以实现——而不是退后一步、张口凝视“不可预见者的开启”——而被辞退或归档；以及这样一种想法：与那逆着学术资本而繁荣的旧式粗糙革命唯物主义相比，这个新未来的思想家们会在“新学术领域的蓬勃增长”中找到这种新的、改良版唯物主义的活力证据，这些领域“集中在若干富有创造性的跨学科枢纽，并已产生自己的超学科后代”<a id="ref-zh-ch02-9"></a>[9](#note-zh-ch02-9)——对于“社会主义人道主义”黑暗中的旧辩证摸索者来说，这种想法恰恰会是可预见之物的定义：那就是他们早已熟悉的学院。）约瑟夫·狄慈根——这位自学成才的“哲学工人”、制革匠，也是马克思朋友与同代人中最专注的革命唯物主义阐释者——在写到“我们这些辩证的或社会民主主义的唯物主义者”时，他指的是，他的同志们也理解他指的是：我们这些资本主义社会与资产阶级思想的不共戴天的敌人，我们研究自然和世界的一切细节，是为了学会如何摧毁资本主义社会。<a id="ref-zh-ch02-10"></a>[10](#note-zh-ch02-10)

<a id="ch02-p004-en"></a>
Materialism, in the sense in which Marx, Engels, Dietzgen, Plekhanov, Lenin, Luxemburg and other revolutionaries used the word, was never merely a theory of matter or materiality, but always also, and primarily, a revolutionary pedagogy.<a id="ref-en-ch02-8"></a>[8](#note-en-ch02-8) It was how groups of individuals who dedicated their lives to the destruction of capital disciplined their ‘thought-capacity’ and taught themselves and each other about the world. Most of this teaching went on outside institutions of learning, or in defiance of their culture, and had little or nothing to do with the production imperatives of academic capital and the academic career. (The thought that this revolutionary materialism would one day be pensioned off or archived for being too romantic about subjectivity, for clinging to the outmoded human, and for being credulous enough to try to anticipate in detail and work out in practice forms of future social relations, instead of standing back and gaping at ‘the opening of the unforeseeable’; and the thought that, in preference to the old, crude revolutionary materialism that flourished in defiance of academic capital, the thinkers of this new future would find proof of the vitality of the new and improved materialism in ‘the exuberant growth’ of ‘new fields of scholarship … concentrated in a number of creative trans-disciplinary hubs, which have generated their own extra-disciplinary offspring’<a id="ref-en-ch02-9"></a>[9](#note-en-ch02-9) – for the old dialectical gropers in the dark of ‘socialist humanism’, this thought would have been the definition of the foreseeable: it was the academy they already knew.) When Joseph Dietzgen, the self-taught ‘philosophical working man’, a tanner by trade, and the most dedicated exponent of revolutionary materialism among Marx’s friends and contemporaries, wrote of ‘us dialectical or Social-Democratic materialists’, he meant, and was understood by his comrades to mean, those of us who are the implacable enemies of capitalist society and bourgeois thought, who study nature and the world in all its detail in order to learn how to destroy capitalist society.<a id="ref-en-ch02-10"></a>[10](#note-en-ch02-10)

<a id="ch02-p005-zh"></a>
按照狄慈根，唯物主义革命教育学的第一条根本教训是：意识——包括诸如“物质之去实体化源于把物质性铭写为与他者的不可能关系这一解构性铭写”这样稀有的意识例子——应当“从谋生方式和途径”来解释。或者，如狄慈根更展开地所说：“人……获取每日面包的方式，一代人身体上*劳作*所处的文明水平，决定其思想立场，决定它构想——并且必须如何构想——真、善与正义、上帝、自由与不朽、哲学、政治与法律的方式。”<a id="ref-zh-ch02-11"></a>[11](#note-zh-ch02-11) 这一根本知识或许是教条式的，但不能通过任何临时的理论调和来达到。它只能在生活中践行。只有对于全心全意接受它并将其彻底内化的坚定革命者，它才是真实的、有意义的；到那时，它不再仅仅是一个命题，而是一个“批判性地牢固、不容置疑的立场”。（狄慈根解释说，正是他对1848年革命的经验，唤醒了他一种巨大的“获得批判性地牢固、不容置疑的立场的渴望”：唯物主义教育学观念的核心，是某种原初的攫取或俘获——生命被一种独特强度的欲望所攫取或俘获；这种强度经验，只有通过生活在一个真正革命可能性的时刻之中、并穿越这个时刻，才能被引爆。）<a id="ref-zh-ch02-12"></a>[12](#note-zh-ch02-12) 一旦这一知识成为牢固的立场，它便使其余一切变得可理解。但它并不以那种跨越世界的普罗米修斯式智性（或其新唯物主义漫画像）理解一切的方式去理解任何事物。它不导向全能的人类掌控，也不是其产物；事实上，它几乎恰恰相反。

<a id="ch02-p005-en"></a>
The first and fundamental lesson of the revolutionary pedagogy of materialism, according to Dietzgen, is that consciousness – not excluding such rare examples of consciousness as the thought that ‘the desubstantialization of matter occurs as a result of the deconstructive inscription of materiality as the impossible relation to the other’ – is to be explained ‘from the way and manner of bread-winning’. Or, as Dietzgen more expansively put it, ‘that the way … in which man earns his daily bread, that the level of civilization on which a generation physically *works*, determines the mental standpoint or the way in which it conceives and must conceive the True, the Good and Right, God, Freedom and Immortality, Philosophy, Politics and Law.’<a id="ref-en-ch02-11"></a>[11](#note-en-ch02-11) This fundamental knowledge, which may indeed be dogmatic, cannot be reached by any temporary theoretical accommodation. It can only be lived. It is true and it makes sense only for the determined revolutionary who accepts it wholeheartedly and radically internalizes it; it is then no longer merely a proposition, but a ‘critically firm, undoubted standpoint’. (Dietzgen explains that it was his experience of the revolutions of 1848 that awoke in him a great ‘desire to acquire a critically firm, undoubted standpoint’: essential to the idea of materialist pedagogy is some kind of originary seizure or captivation of life by a singular pitch of desire, an experience of intensity that can only be made to erupt by living in and through a moment of real revolutionary possibility).<a id="ref-en-ch02-12"></a>[12](#note-en-ch02-12) Once this knowledge is a firm standpoint, it makes sense of everything else. But it does not make sense of anything in the way that a Promethean intellect astride the world (or its new materialist caricature) would make sense of everything. It does not lead to and is not the product of an omnipotent human mastery; in fact, it is almost the very opposite.

<a id="ch02-p006-zh"></a>
狄慈根的革命唯物主义植根于一种持久的惊奇：一切可以被思考、考察、学习、理解、领会或尝试的事物都是无穷无尽的。这是一种革命教育学：学习这项工作的力量在于这样一个现实——这项工作永远不会完成；不是因为人类智力太少或太不安分，而是因为“被给予我们的思维力作为材料的东西，与空间一样无限”。<a id="ref-zh-ch02-13"></a>[13](#note-zh-ch02-13) 这对每个对象、每个生命、每个观念、每种可能性都成立：没有任何事物会被思想穷尽，即便它就在眼前或可以预见；思想总能做更多，总能发现更多，总能感知和认识更多。狄慈根写道：“无论一个人想测量无限，还是只想测量最小的原子，他总得面对不可测量者。自然，无论作为整体还是其部分，都是不可穷尽的，不能认识至其最后一个粒子——因而没有开端和终结。”<a id="ref-zh-ch02-14"></a>[14](#note-zh-ch02-14) 这是一种“社会民主主义”的无限：其重点完全落在对象的不可穷尽性上，因此也落在发现的劳动上——任何真正尝试的人，只要认真接触任何对象，就会进入这种无尽地引人入胜、无尽地令人沮丧、也无尽地给予回报的发现劳动。

<a id="ch02-p006-en"></a>
Dietzgen’s revolutionary materialism is rooted in permanent wonder at the inexhaustibleness of everything that can be thought, examined, learned, understood, picked up or tried out. It is a revolutionary pedagogy for which the power of the work of learning consists in the reality that this work is never done, not because the human intellect is too little or too restless, but because ‘the stuff that is given as material for our thought-capacity is as infinite as space’.<a id="ref-en-ch02-13"></a>[13](#note-en-ch02-13) This is true of every object, every life, every idea, every possibility: nothing is ever exhausted by thought, not even when it is present or foreseeable, but there is always more that thought can do, always more to find, always more to sense and to know. ‘Whether one wants to measure the Infinite or merely the smallest atom, one always has to deal with the Immeasurable’, Dietzgen wrote. ‘Nature, both as a whole and in its parts, is inexhaustible, not knowable to its last particle – consequently without beginning and end.’<a id="ref-en-ch02-14"></a>[14](#note-en-ch02-14) This is a ‘social democratic’ type of infinity: its emphasis falls squarely on the inexhaustibleness of the object and the therefore endlessly compelling, endlessly frustrating, endlessly rewarding work of discovery that follows serious engagement with any object at all, by anyone at all who really tries.

<a id="ch02-p007-zh"></a>
智性——或者用狄慈根那种咄咄逼人的直接唯物主义语言来说，“头脑”——在唯物主义动机的驱动下，对这无限材料所做的是工作。“思想就是工作。”<a id="ref-zh-ch02-15"></a>[15](#note-zh-ch02-15) 重新概念化工作的革命唯物主义决心，对马克思主义女性主义批判和当代社会再生产理论始终具有根本意义。正如南希·哈索克所写：

<a id="ch02-p007-en"></a>
What the intellect – or in Dietzgen’s aggressively direct materialist language, what the ‘head’ – does with this infinite stuff, when activated by materialist motives, is work. ‘Thought is work.’<a id="ref-en-ch02-15"></a>[15](#note-en-ch02-15) The revolutionary materialist determination to reconceptualize work has remained fundamental for Marxist feminist critique and for contemporary social reproduction theory. As Nancy Hartsock wrote:

<a id="ch02-q001-zh"></a>
> 女性的解放——以及一切人类的解放——取决于理解工作对我们作为个体的发展至关重要，取决于在我们的生活中为我们的工作创造新的位置。我们必须发展出一种关于工作本身的新概念。为开始这一过程，我们必须弄清楚资本主义与父权制的工作组织究竟哪里出了问题，并界定*人类*工作的要求。

<a id="ch02-q001-en"></a>
> The liberation of women – and all human beings – depends  on understanding that work is essential to our development as  individuals and on creating new places in our lives for our work. We  must develop a new conception of work itself. To begin this process,  we must clarify what is wrong with the capitalist and patriarchal  organization of work and define the requirements of *human* work.

<a id="ch02-p008-zh"></a>
“人类”在此显然不是指“非动物”或“非机器”，而是指“资本主义与父权制一直阻止我们为自己共同去做的事”。<a id="ref-zh-ch02-16"></a>[16](#note-zh-ch02-16) 在这个意义上，人类工作很可能是动物或机器也能做的工作（关键在于，我们必须通过斗争去发现）。唯物主义动机是整个身体的动机，而不仅是头脑的动机。无产阶级哲学家狄慈根坚持说：“思维是身体的工作。”<a id="ref-zh-ch02-17"></a>[17](#note-zh-ch02-17) 感官经验是一种思想，而思想是一种感官经验。许多新唯物主义者的批评中有一个古怪观念，认为“现代西方文化中主导性的物质观念是：物质本质上是被动的东西”<a id="ref-zh-ch02-18"></a>[18](#note-zh-ch02-18)；与这种观念相反，对狄慈根——他与恩格斯是马克思主义传统中最杰出的唯物主义阐释者——而言，物质就是一切，无处不在，既有主动也有被动，既存在于心灵最内在的活动，也存在于引力之中。

<a id="ch02-p008-en"></a>
‘Human’ evidently does not mean, here, ‘not animal’ or ‘not machine’, but ‘what we have been prevented from doing together, for ourselves, by capitalism and by patriarchy’.<a id="ref-en-ch02-16"></a>[16](#note-en-ch02-16) Human work in this sense might very well be work that animals or machines could do: the point is, we have to fight to find out). Materialist motives are motives of the whole body, not only of the head. ‘Thinking is bodily work’, Dietzgen the proletarian philosopher insisted.<a id="ref-en-ch02-17"></a>[17](#note-en-ch02-17) Sensory experience is a kind of thought, and thought is a sensory experience. Contrary to the curious idea, central to the criticism of many new materialists, that ‘the predominant sense of matter in modern Western culture has been that it is essentially passive stuff’,<a id="ref-en-ch02-18"></a>[18](#note-en-ch02-18) for Dietzgen, who with Engels was the most prominent exponent of materialism in the Marxist tradition, matter is everything and everywhere, active and passive, in the most intimate activity of the mind as well as in the force of gravity.

<a id="ch02-q002-zh"></a>
> 我们现代社会主义者并不持有那种狭隘意见，认为有重量、可触知的物质才是*最典型意义上的*物质。我们认为花香、声音和气味也是物质的。我们不把力设想为物质的单纯附属物、单纯谓词，也不把可触知的物质设想为统治一切属性的“那个东西”。可以说，我们对物质和力的构想是民主的。一方与另一方具有同等价值；一切个别之物都只是整个自然整体的属性、附属物、谓词或特质。大脑不是斗牛士，心智功能也不是从属的仆役。不，我们现代唯物主义者主张，功能之为独立之物的程度，与可触知的大脑团块或任何其他物质性完全相同（都同样多，也同样少）。思想，连同其起源和本性，也是与任何其他事物一样真实的事物和材料，值得研究。<a id="ref-zh-ch02-19"></a>[19](#note-zh-ch02-19)

<a id="ch02-q002-en"></a>
> We, modern Socialists, are not of the narrow opinion that the  ponderable and tangible matter is matter *par excellence*. We hold  that the scent of flowers, sounds and smells are also material. We  do not conceive the forces as mere appendices, mere predicates of  matter, and matter, the tangible one as ‘the thing’ which dominates  over all properties. Our conception of matter and force is, so to  speak, democratic. One is of the same value as the other; everything  individual is but the property, appendix, predicate or attribute of  the entire Nature as a whole. The brain is not the matador and  the mental functions are not the subordinate servants. No, we  modern materialists assert that the function is as much and as  little an independent thing as the tangible brain-mass or any other  materiality. The thoughts, too, their origin and nature, are just as  real matters and materials worthy of study as any.<a id="ref-en-ch02-19"></a>[19](#note-en-ch02-19)

<a id="ch02-p009-zh"></a>
狄慈根对无限自然的不可穷尽性、对每个对象之于头脑和感官的无限性的唯物主义惊奇，以及他对那种幼稚而幻想的观念的蔑视——这种观念把人或人类设想为一个普罗米修斯式的项目经理，蹲踞在宇宙之上并统治一切——在数十年间一直是马克思主义传统中革命唯物主义特性的根本。“外部世界、客观世界不仅存在于我之外，也存在于我之内，在我自己的皮肤之内”，格奥尔基·普列汉诺夫写道——他是1917年革命前俄国最有影响的马克思革命唯物主义倡导者。“人只是自然的一部分，是存在的一部分；因此，他的思想与他的存在之间不可能有矛盾。”<a id="ref-zh-ch02-20"></a>[20](#note-zh-ch02-20) 对普列汉诺夫和狄慈根来说，如果没有一种植根于惊奇的工作理论，就不可能有有意义的唯物主义，换言之，也不可能有给决心摧毁资本主义社会的革命者的教育学；这种惊奇面对的是：一切尚待学习、理解、认识、并因而最终为工人实现或*赢得*为现实之物的不可穷尽性——在此之前，工人在资本之下注定以被压碎、被掏空的间接或直接奴役状态存在。没有工作理论，就不可能有革命唯物主义。狄慈根的工作理论既涉及我们现在所做的工作——已经作为“思想”和“谋生”完成的工作——也涉及尚未完成、却仍可能完成的工作：如果我们从资本主义生产关系中解放出来，并献身于探索自然、思想本身、与我们共同工作的他人，以及任何认真吸引我们注意的对象的无限性。现在必须进行思想工作，以构想这些新的、未来的工作形式和对不可穷尽者的探索；也正是通过这种思想工作，资本之下存在的绝对贫困才能越来越令人难以忍受地得到明确揭示。狄慈根写道，唯物主义必须学会“不可知者如何转变为可知者”<a id="ref-zh-ch02-21"></a>[21](#note-zh-ch02-21)；对一个唯物主义者来说，这一点尤其适用于两种情况。唯物主义者必须研究：资本主义对生命的碾压给工人造成的苦难——这种苦难当然被感受和忍受，但就其真相而言可能仍“不可知”——如何能够被清楚而牢固地认识。唯物主义者还必须研究：在摧毁资本之后可能赢得的世界和可能过上的生活，如何能尽可能完整地保持在可达范围内：作为愿景、作为诗、作为幻想、作为科学、作为预测、作为目的论、作为欲望、作为一个纲领或一个梦；无论如何都要全心全意，并且始终处在不可预见的未来——或尚不能被绘制成社会蓝图之物——与可知的未来——或被压碎的人们确实知道自己首先想要、甚至愿冒生命危险去争取之物——之间最鲜明的张力与重叠点上。这些想法很简单，甚至粗糙，在哲学上是原始的：思想是工作，思想是身体劳动，意识由谋生方式决定，世界对思想而言不可穷尽，我们永远达不到终点，总还有一切有待学习和争取。它们简单，一是不需要非常复杂的逻辑，二是它们不考虑大量复杂性和偶然性，几乎到了让人难以相信偶然性真的被考虑过的地步。作为革命唯物主义教育学的教训，它们不难理解。它们容易理解，却极难与之共处。

<a id="ch02-p009-en"></a>
Dietzgen’s materialist wonder at the inexhaustibleness of infinite nature and the infinity of every object for the head and the senses remained fundamental to the character of revolutionary materialism in the Marxist tradition for many decades, as did his contempt for the infantile and fantastical idea of man or the human as a Promethean project manager squatting on the cosmos and dominating everything. ‘The outer world, the objective world, does not exist only outside me, but also within me, inside my own skin’, wrote Georgy Plekhanov, the most influential proponent of Marx’s revolutionary materialism in Russia before the revolution of 1917. ‘Man is only a part of nature, a part of being; that is why there can be no contradiction between his thought and his being.’<a id="ref-en-ch02-20"></a>[20](#note-en-ch02-20) For Plekhanov, as for Dietzgen, there can be no meaningful materialism, or, in other words, no pedagogy for revolutionaries determined to destroy capitalist society, without a theory of work rooted in wonder at the inexhaustibleness of everything that remains to be learned, understood, known, and, consequently and ultimately, realized or *won* as reality for workers who, until that time, are condemned under capital to exist in crushed and voided states of indirect or direct slavery. There can be no revolutionary materialism that is not a theory of work. Dietzgen’s theory of work is about both the work that we do now, work that is done already as ‘thought’ and as ‘breadwinning’, and work that is not done yet, but that might yet be done, if and when we free ourselves from capitalist relations of production, and dedicate our lives to exploring the infinity of nature, of thought itself, of others who work with us, and of every object that seriously engages our attention. The work of thought that is necessary now to conceive these new, future forms of work and exploration of the inexhaustible is also how the absolute poverty of existence under capital can be made more and more excruciatingly explicit. Materialism must learn ‘how the unknowable changes into the knowable’, Dietzgen wrote;<a id="ref-en-ch02-21"></a>[21](#note-en-ch02-21) and for a materialist this is true in two cases above all. The materialist must study how the suffering inflicted on the worker by the capitalist crushing of life – suffering that is certainly felt and endured, but that may yet be ‘unknowable’ for what it is – can be clearly and firmly known. And the materialist must study how the world that may be won and the life that may be lived after the destruction of capital can be kept as fully as possible within reach: as vision, as poetry, as fantasy, as science, as prediction, as teleology, as desire, as a programme or as a dream; in any case wholeheartedly, and always at the most vivid point of tension and overlap between the unknowable future, or what cannot yet be drawn up as a blueprint for society, and the knowable future, or what people who are crushed do know that they want above all else and would even risk life to get. These are simple thoughts, rough even, and philosophically primitive: thought is work, thought is bodily labour, consciousness is determined by the manner of breadwinning, the world is inexhaustible for thought, we never get to the end, there is always everything still to learn and to win. They are simple thoughts in the sense that they do not require a very complex logic, and in the sense that they leave out of consideration a great number of complexities and contingencies, almost to the point where it is difficult to believe that contingency has really been reckoned with at all. As lessons of a revolutionary materialist pedagogy, they are not difficult to understand. They are easy to understand, but intensely difficult to live with.

<a id="ch02-s02-zh"></a>
## **功与劳动：从恩格斯的（反诗的）唯物主义到马克思的（诗的）唯物主义**

<a id="ch02-s02-en"></a>
## **Work: from Engels’s (anti-poetic) to Marx’s (poetic)** **materialism**

<a id="ch02-p010-zh"></a>
恩格斯在《自然辩证法》论‘功’的那一章末尾，加了一条气恼的脚注，谈把“物理学意义上的功（work）”与“经济学意义上的”工作相混淆的危险。<a id="ref-zh-ch02-22"></a>[22](#note-zh-ch02-22) 恩格斯说，“物理学意义上的功”这一概念，是“现代力学表达机械运动转化为另一种运动形式”的方式。

<a id="ch02-p010-en"></a>
Engels concluded the chapter on ‘work’ in his *Dialectics of Nature* with an irritable footnote on the perils of confusing ‘the concept of work in the physical sense of the word’ with work ‘in the economic sense’.<a id="ref-en-ch02-22"></a>[22](#note-en-ch02-22) The ‘concept of work in the physical sense of the word’, says Engels, is how ‘modern mechanics expresses the conversion of mechanical motion into another form of motion’.

<a id="ch02-q003-zh"></a>
> 如果在蒸汽机或热机中，热转化为机械运动，即分子运动转化为宏观运动；如果热分解一种化合物；如果热在热电堆中转化为电；如果电流从稀硫酸中释放出水的元素，或者反过来，如果发电电池的化学过程中释放出的运动（别名能量）采取电的形式，而这一运动在闭合电路中又一次转化为热——在所有这些过程中，启动该过程、并在过程中转化为另一种形式的那种运动形式在做功，而且所做的功的量与其自身的量相当。

<a id="ch02-q003-en"></a>
> If, as in a steam or heat engine, heat is converted into mechanical  motion, i.e., molecular motion is converted into mass motion, if  heat breaks up a chemical compound, if it becomes converted  into electricity in a thermopile, if an electric current liberates the  elements of water from dilute sulphuric acid, or conversely, if the  motion (alias energy) set free in the chemical process of a generating  cell takes the form of electricity and this in the closed circuit once  more becomes converted into heat – in all these processes the form  of motion that initiates the process, and which is converted by it  into another form, performs work, and indeed an amount of work  corresponding to its own amount.

<a id="ch02-q004-zh"></a>
> 因此，功就是运动形式的变换，从其量的方面来看［*Arbeit ist also Formwechsel der Bewegung, betrachtet nach seiner quantitativen Seite hin*］。<a id="ref-zh-ch02-23"></a>[23](#note-zh-ch02-23)

<a id="ch02-q004-en"></a>
> Work, therefore, is change of form of motion regarded in  its quantitative aspect [*Arbeit ist also Formwechsel der Bewegung,*  *betrachtet nach seiner quantitativen Seite hin*].<a id="ref-en-ch02-23"></a>[23](#note-en-ch02-23)

<a id="ch02-p011-zh"></a>
对恩格斯来说显然，任何真正唯物主义的自然叙述都会理解并利用现代力学的发现。但一种不仅唯物主义而且辩证的自然叙述会走得更远。辩证唯物主义者不仅会利用现代力学的发现，还会借助矛盾与同一的逻辑阐发其真理。恩格斯特别称赞古斯塔夫·基尔霍夫的《数学物理学讲义》，并从中引用基尔霍夫关于静止状态的典范性辩证定义：“静止是运动的一种特殊情况”（*Die Ruhe ist ein spezieller Fall der Bewegung*）。<a id="ref-zh-ch02-24"></a>[24](#note-zh-ch02-24) 据恩格斯说，基尔霍夫“由此证明他不仅能计算，而且能辩证地思考”。<a id="ref-zh-ch02-25"></a>[25](#note-zh-ch02-25) 恩格斯告诫说，辩证地思考要求概念清晰，为此唯物主义者必须谨慎对待词语，并实行严格的词汇纪律。《自然辩证法》论功一章末尾的脚注解释说，由于德语中 *Arbeit* 一词同时被用于“物理学意义上的功”和“经济学意义上的”工作，“近来在伪科学文献中，才有可能把物理学意义上的功作出各种奇特应用，用于劳动的经济条件，反之亦然”。<a id="ref-zh-ch02-26"></a>[26](#note-zh-ch02-26) 恩格斯建议，德语词 *Werk* 应当用于机械运动的转化，以便把它与作为劳动力出售的工作区分开来；后者被称为（且马克思一直称之为）*Arbeit*。

<a id="ch02-p011-en"></a>
For Engels, it is obvious that any account of nature that is truly materialist will comprehend and make use of the discoveries of modern mechanics. But an account of nature that is not only materialist but also dialectical will go further yet. A dialectical materialist will not merely make use of the discoveries of modern mechanics, but will work out their truth by means of the logic of contradiction and identity. Engels singles out for praise the *Lectures on Mathematical Physics* of Gustav Kirchoff, and cites from that work Kirchoff’s exemplary dialectical definition of the state of rest: ‘Rest is a special case of motion’ (*Die Ruhe ist ein spezieller Fall der Bewegung*).<a id="ref-en-ch02-24"></a>[24](#note-en-ch02-24) According to Engels, Kirchoff ‘thus proves that he can not only calculate but can also think dialectically’.<a id="ref-en-ch02-25"></a>[25](#note-en-ch02-25) Thinking dialectically, Engels warns, requires conceptual clarity, and for this the materialist must be careful about words and exercise strict lexical discipline. The footnote that ends the chapter on work in *Dialectics of Nature* explains that, because in German the word *Arbeit* has been used for both ‘the concept of work in the physical sense of the word’ and work ‘in the economic sense’, ‘it has been possible in recent pseudoscientific literature to make various peculiar applications of work in the physical sense to economic conditions of labour and vice versa.’<a id="ref-en-ch02-26"></a>[26](#note-en-ch02-26) Engels’s prescription is that the German word *Werk* should be used for the conversion of mechanical motion in order to distinguish this from the work that is sold as labour-power, which is called (and was always called by Marx) *Arbeit*.

<a id="ch02-p012-zh"></a>
这条脚注是恩格斯在炫耀他的反诗倾向。也正是这位恩格斯，在初次读完《资本论》完整手稿后写信给马克思，痛切抱怨这部作品没有按教科书的风格组织，以便尽可能容易阅读和吸收。但是，尽管马克思作为“辩证唯物主义者”的名声显然难以磨灭，恩格斯所谓以严格词汇纪律“辩证地思考”或“辩证唯物主义”，对马克思而言，却不如恩格斯贬称的“把现代科学发现奇特应用于劳动的经济条件”更有意思。因为马克思在《资本论》中做的，恰恰是辩证唯物主义者恩格斯说绝不可做的事。马克思在《资本论》论相对剩余价值的那一章中，把工人称为“抗拒着却又有弹性的自然界限”，其存在就是为了在价值增殖之力下被压平。<a id="ref-zh-ch02-27"></a>[27](#note-zh-ch02-27) 这种力，马克思在《大纲》中称为资本主义社会的“比重”。<a id="ref-zh-ch02-28"></a>[28](#note-zh-ch02-28) 马克思在《资本论》中咄咄逼人地把工人定义为：恰恰不过是机械运动（以“活劳动”形式被掏空的身体运动）转化为另一种运动形式的一个例子——这就是马克思在《大纲》中著名的说法：资本自身的“运动中的矛盾”。<a id="ref-zh-ch02-29"></a>[29](#note-zh-ch02-29)

<a id="ch02-p012-en"></a>
This footnote is Engels showing off his anti-poetic tendency. It is the same Engels who wrote to Marx after he first read the completed manuscript of *Capital* to complain bitterly that the work had not been organized in the style of a textbook, to make it as easy as possible to read and to absorb. But despite the apparently indelible reputation of Marx as a ‘dialectical materialist’, what Engels calls ‘thinking dialectically’ with strict lexical discipline, or ‘dialectical materialism’, was less interesting to Marx than what Engels derogatively calls ‘peculiar applications’ of the discoveries of modern science to the economic conditions of labour. For Marx does in *Capital* precisely what Engels the dialectical materialist says must not be done. Marx calls the worker in the chapter of *Capital* on relative surplus value a ‘repellent but elastic natural limit’ that exists in order to be crushed flat under the force of valorization.<a id="ref-en-ch02-27"></a>[27](#note-en-ch02-27) This force is what Marx calls in the *Grundrisse* the ‘specific gravity’ of capitalist society.<a id="ref-en-ch02-28"></a>[28](#note-en-ch02-28) The worker is aggressively defined by Marx in *Capital* as precisely nothing but an example of the conversion of mechanical motion (the motion of the body voided in the form of ‘living labour’) into another form of motion, what Marx famously calls, in the *Grundrisse*, the ‘moving contradiction’ of capital itself.<a id="ref-en-ch02-29"></a>[29](#note-en-ch02-29)

<a id="ch02-p013-zh"></a>
马克思对所谓“资本关系”宇宙的全部描述——他将其描述为一种普遍化的非关系，从个别劳动者被暴力分离出来的“尘埃般”存在，一直到无限积累螺旋之无限性的崇高高度——是一次宏大的“把物理学意义上的功奇特地应用于劳动的经济条件”。按恩格斯的说法，严格来讲，这并不是对资本主义生产的一种有纪律的、辩证唯物主义的叙述，而是物理学与经济学的一次生动混淆，处处宛如一首幻想曲（*quasi una fantasia*），是一幅不可阻挡的噩梦景观，由对“劳动折磨”地狱的谵妄“伪科学”照亮构成。<a id="ref-zh-ch02-30"></a>[30](#note-zh-ch02-30) 对辩证唯物主义者恩格斯来说，这是容易造成混乱并为“伪科学”提供支持的词汇无序（在此即混淆物质所做的功与人类从事的劳动）；对马克思来说，这是诗学。力学与经济学的纠缠，是《资本论》那种自觉错乱、极度误用修辞、具有革命性的诗学的核心。马克思对“劳动力”的描述，是一个特定诗性的意象：把“经济学意义上的”工作描绘为物理学意义上的机械力或做功；把一方“奇特应用”于另一方，不是言语失滑或范畴错误；它就是价值增殖的地狱。

<a id="ch02-p013-en"></a>
Marx’s whole description of the universe of the so-called ‘capital-relation’, which he describes as a universalized non- relation – from the violently separated ‘speck-like’ existence of the individual labourer right up to the sublime heights of the infinity of the spiral of limitless accumulation – is one great ‘peculiar application of work in the physical sense to economic conditions of labour’. This is, on Engels’s terms, strictly speaking, not a disciplined, dialectical materialist account of capitalist production, but a vivid confusion of physics and economics, at all points *quasi una fantasia*, an inexorable nightmarescape of deliriously ‘pseudoscientific’ illuminations of the hell of ‘work-torture’.<a id="ref-en-ch02-30"></a>[30](#note-en-ch02-30) What for Engels the dialectical materialist is lexical indiscipline liable to produce confusion and give support to ‘pseudoscience’ (in this case, mixing up the work done by matter with the work done by human beings) is poetics for Marx. The tangling up of mechanics and economics is at the core of the consciously deranged, wildly catachrestic, revolutionary poetics of *Capital*. Marx’s description of ‘labour-power’ is a specifically poetic image of work ‘in the economic sense’ as a mechanical force or performance of work in the sense understood by physics: the ‘peculiar application’ of one to the other is not verbal slippage or a category mistake; it is the hell of valorization.

<a id="ch02-p014-zh"></a>
资本主义价值增殖的地狱，是物质“完全无关紧要”的地方。每个人或物、甚至自然的特定物质性，在这个地狱中几乎无足轻重；在这里，唯一要紧的是从无论何种性质的人类、动物或机械容器中生产剩余价值，或把价值抽空。地狱在本质上是逻辑的，然后才是物质的。被罚入资本主义逻辑地狱的物质，其命运是只存在于马克思所说的“价值对象性的”（*wertgegenständlich*）形式中。那个显眼而丑怪的新词 *Wertgegenständlichkeit*，即“价值对象性”，借用恩格斯的话说，是把一种逻辑“奇特应用”于另一种逻辑，两种逻辑相互排斥：李嘉图的逻辑应用于黑格尔的逻辑。马克思平静地解释说：“无论价值拥有某种使用价值以便存在于其中多么重要，究竟哪个特定对象服务于这一目的，仍然完全无关紧要。”<a id="ref-zh-ch02-31"></a>[31](#note-zh-ch02-31) 这种怪诞的颠倒对诗学至关重要：要紧的不是对人类重要之物，而是对价值重要之物，仿佛价值真能觉得什么东西重要。这里甚至不必直接提到人类，因为人类将被理解为被统摄在“服务于某种目的的对象”这一范畴之下。马克思在梅西耶·德·拉里维埃的《政治社会的自然与本质秩序》（*L’Ordre naturel et essential des sociétés politiques*，1767年）中，发现了这种关于对象“无差异”的思想，并将其发展成关于物质性的无差异和劳动形式的无差异、或物质与生命的无差异的思想。令马克思兴奋的是这个词的特定共鸣，而不仅是它对价值逻辑的意义。他始终以讽刺诗人的姿态阅读政治经济学著作和科学著作，永远在留意概念的滑脱，总是在倾听片段的习惯性不协和、反讽，以及那些可以被嫁接到自己的批判中或加以戏仿、从而让读者皱眉、退缩或作呕的、无意的内涵蔓延。梅西耶·德·拉里维埃的《政治社会的自然与本质秩序》是一种特定诗学灵感的文学来源：物质与人类无差异的观念。“用银”，梅西耶·德·拉里维埃写道，

<a id="ch02-p014-en"></a>
The capitalist hell of valorization is where matter is ‘a matter of complete indifference’. The specific materiality of every person or thing, even of nature, is of virtually no consequence in this hell, where all that matters is the production of surplus value, or the emptying out of value, from no matter what character of human, animal or mechanical vessel. Hell is essentially logical before it is material. The fate of matter damned to the hell of capitalist logic is to exist only in what Marx calls ‘value-objective’ (*wertgegenständlich*) form. The conspicuously hideous neologism *Wertgegenständlichkeit*, or ‘value-objectivity’, is a ‘peculiar applica tion’, to borrow Engels’s phrase, of one logic to another, each one mutually repellent: Ricardo’s to Hegel’s. ‘However important it may be to value that it should have some use-value to exist in, it is still a matter of complete indifference what particular object serves this purpose’, Marx serenely explains.<a id="ref-en-ch02-31"></a>[31](#note-en-ch02-31) The grotesque inversion is essential to the poetics: not what is important to human beings, but what is important to value, as though value could find anything important, is what matters. Human beings need not even be directly mentioned here, since they will be understood to be comprehended under the category of ‘object that serves a purpose’. Marx found this thought about the ‘indifference’ of objects, which he developed into a thought about the indifference of materiality and the indifference of forms of labour, or the indifference of matter and life, in Mercier de la Rivière’s *L’Ordre naturel et essential des sociétés politiques* (1767). The specific resonance of the word, not merely its meaning for the logic of value, is what excited Marx, who consistently read works of political economy, as well as works of science, in the attitude of a satirical poet, permanently on the lookout for slips of the concept, always listening out for bits of idiomatic dissonance, ironies and unintended creeps of connotation that could be grafted onto or parodied in his own critique, to make his reader wince, recoil or heave. Mercier de la Rivière’s *L’Ordre* *naturel et essential des sociétés politiques* was the literary source of a specific poetic inspiration: the idea of the indifference of matter and human beings. ‘With silver’, writes Mercier de la Rivière,

<a id="ch02-q005-zh"></a>
> 人们购买商品，又用商品购买银：卖或买在任何情况下都是……任何价值与任何其他价值的交换：这些价值之一是银，或二者都是有用商品，这本身完全无关紧要。<a id="ref-zh-ch02-32"></a>[32](#note-zh-ch02-32)

<a id="ch02-q005-en"></a>
> one buys commodities, and with commodities one buys silver: selling  or buying is in every case … the exchange of any value for any other  value: that one of these values should be silver, or that both should  be useful commodities, is a matter of complete indifference in itself.<a id="ref-en-ch02-32"></a>[32](#note-en-ch02-32)

<a id="ch02-p015-zh"></a>
*Rien de plus indifférent en soi*（没有什么比这本身更无关紧要）。只要机械运动的完善形式——被称为价值之价值增殖的*永动机*——继续不受阻碍，被送入这条无限螺旋中旋转的对象的物质形式就完全无关紧要，反之亦然。在资本主义的逻辑地狱中，无差异就是‘自在’。聚苯乙烯、人类、系外行星或蝙蝠屎，这些都不需要通过一种“扁平本体论”被拉到同一层面，因为一切早已平等。资本负责这件事。对象早已“有自己的生命”，早于新唯物主义的种种赋予生命之举：一种无差异的生命。<a id="ref-zh-ch02-33"></a>[33](#note-zh-ch02-33) 一切都是一种“某种使用价值”，供价值“存在于其中”；而“究竟哪个特定对象服务于这一目的，完全无关紧要”。<a id="ref-zh-ch02-34"></a>[34](#note-zh-ch02-34)

<a id="ch02-p015-en"></a>
*Rien de plus indifférent en soi*. So long as the perfected form of mechanical motion, the *perpetuum mobile* called the valorization of values, continues unobstructed, the material form of the object sent spinning round this spiral to infinity is a matter of complete indifference, and vice versa. In capitalist logical hell, indifference is the ‘in-itself’. Polystyrene, human being, exoplanet or bat shit, none of this need be brought down to the same level by a ‘flat ontology’, because everything is already equal. Capital takes care of that. Objects already ‘have a life of their own’, prior to the vivifications of new materialism: an indifferent life.<a id="ref-en-ch02-33"></a>[33](#note-en-ch02-33) Everything is ‘some use-value’ for value ‘to exist in’, and it is ‘a matter of complete indifference what particular object serves this purpose’.<a id="ref-en-ch02-34"></a>[34](#note-en-ch02-34)

<a id="ch02-p016-zh"></a>
这就是关于“无差异”的真相，马克思通过对物质特定性之灭绝的诗性具体化，使这一真相发出回响。若不借助强烈而令人信服的诗性攻击，这样的真相无法像在《资本论》中那样发出回响。一方面因为其中没有攻击性，或者说没有令人信服的攻击性；另一方面因为它毫无诗意，新唯物主义关于一切物质平等的这一思想版本，最终让人感觉像是马克思所谓“乌托邦”那类华丽遐想的晚期开花。按照马克思，乌托邦思想的问题不在于它过于幻想，也不在于它设想了一个对现实而言太好或太完美的世界；问题在于它永远无法指明真正抵达它所设想的世界所必需的工作。它对如何抵达那里不感兴趣，因为它并不真正关心暴力：既不关心资本主义生产过程中不可阻挡的暴力形式——现在存在、必须被斗争和废除的暴力，也不关心那种将不可避免地成为寻找和建设我们所知自己想要的世界之必要与本质的革命暴力。理论方案足以用来设想一个只需在理论上被欲求的世界，也适合那些不必日复一日承受这种处境的人：被难以忍受地压碎，觉得自己的存在渺小如尘埃、令人无法忍耐，探索无限的一切可能性也都被切断和封闭。但对于确实那样被压碎、每天确实感受到这一切、且无路可走的人类来说，那些关于攻击与暴力的矜持审慎的理论化风格，或干脆完全回避攻击与暴力的理论，不仅可笑，而且猥亵。

<a id="ch02-p016-en"></a>
This is the truth about ‘indifference’, the truth that Marx makes resound by a poetic specification of the extinction of material specificity. Truth like this could not be made to resound as it does in *Capital* without intense, compelling poetic aggression. Partly for the reason that there is no aggression in it, or none that is compelling, and partly for the reason that it is not remotely poetic, new materialism’s version of this thought about the equality of all matter ends up feeling like a late blossoming of the species of florid reverie that Marx called ‘utopian’. The problem with utopian thought, according to Marx, was not that it was too fantastical or that it envisioned a world too good or perfect for reality; the problem was that it never could specify the work that is actually necessary to get to the world it envisioned. It was not interested in how to get there, because it was not really interested in violence: neither in the forms of violence that are inexorable in the capitalist process of production, the violence that exists now and that must be fought and abolished, nor in the revolutionary violence that will unavoidably be necessary and essential to finding and building the world that we know we want. Theoretical solutions suffice for envisioning a world that need only be desired in theory, and are good for human beings who are not crushed right now, every day, unbearably, to the point where their existence feels unendurably speck-like, and for whom every possibility of exploration of the infinite is cut off and shut down. But for human beings who are crushed like that and do feel all those things, every day, and who have no way out, reticent and cautious styles of theorizing about aggression and violence, or theories that simply avoid aggression and violence altogether, are not only risible, but obscene.

<a id="ch02-p017-zh"></a>
新唯物主义者罗西·布拉伊多蒂写道：“对生命本身的关注，可能促成一种以生物为中心的平等主义，迫使人们从‘生命力量’的角度重新思考主体性概念。”这种促成平等主义、迫使重新思考主体性概念的关注，也

<a id="ch02-p017-en"></a>
‘The focus on life itself’, writes the new materialist Rosi Braidotti, ‘may encourage a sort of biocentred egalitarianism, forcing a reconsideration of the concept of subjectivity in terms of “life-forces.”’ This focus that encourages egalitarianism and forces reconsideration of the concept of subjectivity also

<a id="ch02-q006-zh"></a>
> 使自我与他者的关系发生错位，同时也重新定义这种关系：它把性别化、种族化和自然化的轴线从二元对立转向一种更复杂、较少对立性的互动模式。<a id="ref-zh-ch02-35"></a>[35](#note-zh-ch02-35)

<a id="ch02-q006-en"></a>
> dislocates but also redefines the relationship between self and  other by shifting the axes of genderization, racialization, and  naturalization away from a binary opposition into a more complex  and less oppositional mode of interaction.<a id="ref-en-ch02-35"></a>[35](#note-en-ch02-35)

<a id="ch02-p018-zh"></a>
这种对立性的互动模式，无论它可能是什么，都是新唯物主义表示异议时的常规靶子。戴安娜·库尔和萨曼莎·弗罗斯特在她们合编的文集《新唯物主义：本体论、能动性与政治》的导言中谨慎地说，新唯物主义思想家这一多样领域中的所有人共同感受到的一点，是“对对立性思维方式的厌恶”。<a id="ref-zh-ch02-36"></a>[36](#note-zh-ch02-36) 想来，对立的思维方式不能被简单地反对，但可以、而且经常在原则上被不优先选择，转而优先选择某种与“移动”事物有关的“更复杂”的东西。对立性思维本身复杂性较低这一点，已不再可供讨论。那种复杂思维的原始形式，始于承认对抗力量或不可调和差异的僵局——这种僵局不能被消解，必须被生活（尽可能充分地，无论需要多久，无论进展多慢），并最终被摧毁——如今被默默跳过。但正是这种思维方式——在旧意义上“对立”，因为它是至死方休的冲突——把18世纪的唯物主义转变为马克思名言中的“批判的武器”和一种革命教育学。对立——坚定的、不可调和的、绝对的——不仅是这一转变的条件，也是它的全部要点。对狄慈根而言，马克思和恩格斯的新唯物主义的要点恰恰在于：它是“社会民主主义的唯物主义”，是革命者手中的武器，用以对抗资产阶级国家和资本对生命的统治。社会民主主义的新唯物主义，与旧的“形而上学唯物主义”相反：后者只关心具体现象的本性，不关心心灵与物质的关系，因而不关心被理解为包含不可测量者的整个自然（革命唯物主义“在一个概念中既拥抱真实的幻想，也拥抱真实的铺路石”）。<a id="ref-zh-ch02-37"></a>[37](#note-zh-ch02-37)

<a id="ch02-p018-en"></a>
The oppositional mode of interaction, whatever that might be, is the regular target of new materialist demurral. In their introduction to the volume of essays they co-edited, *New* *Materialisms: Ontology, Agency, and Politics*, Diana Coole and Samantha Frost carefully say that one thing the diverse field of new materialist thinkers all feel in common is an ‘antipathy toward oppositional ways of thinking’.<a id="ref-en-ch02-36"></a>[36](#note-en-ch02-36) Oppositional ways of thinking cannot, presumably, just be opposed, but can be and regularly are dispreferred in principle in favour of something ‘more complex’ to do with ‘shifting’ things. The lesser complexity of oppositional thinking itself is no longer up for discussion. The primitive forms of complex thinking that start with recognition of an impasse of opposed forces or irreconcilable differences that cannot be dissolved but must be lived (as fully as possible, for as long as it might take, however slow the progress) and ultimately destroyed are skipped over in silence. But it was this form of thinking, ‘oppositional’ in the old sense that it was a conflict to the death, that was responsible for transforming the materialism of the eighteenth century into a ‘weapon of critique’, in Marx’s famous phrase, and a revolutionary pedagogy. Opposition – steadfast, irreconcilable, absolute – was not merely the condition of this transformation, but also the whole point of it. For Dietzgen, the point of the new materialism of Marx and Engels was precisely that it is the ‘materialism of Social Democracy’, a weapon in the hands of revolutionaries opposed to the bourgeois state and the domination of life by capital. The new materialism of Social Democracy is the opposite of the old ‘metaphysical materialism’ that was concerned only with the nature of concrete phenomena and not with the relation of mind to matter and therefore not with the whole of nature understood as comprehending the immeasurable’ (revolutionary materialism ‘embraces in one conception both true fancies and true paving stones’).<a id="ref-en-ch02-37"></a>[37](#note-en-ch02-37)

<a id="ch02-q007-zh"></a>
> 无论一个人想测量无限，还是只想测量最小的原子，他总得面对不可测量者。自然，无论作为整体还是其部分，都是不可穷尽的，不能认识至其最后一个粒子——因而没有开端和终结。

<a id="ch02-q007-en"></a>
> Whether one wants to measure the Infinite or merely the smallest  atom, one always has to deal with the Immeasurable. Nature, both  as a whole and in its parts, is inexhaustible, not knowable to its last  particle – consequently without beginning and end.

<a id="ch02-p019-zh"></a>
这听起来像神秘主义，直到人们认清它实际上是什么：一种无产阶级的劝勉，号召把握全部经验，探索一切生命和世界，持续观看，始终把可设想的最高目标保持在视野中，永不放弃。不能把任何事物“认识至其最后一个粒子”这一不可能性，并不具有对思想施加立法性限制的性质：它不是对康德批判性地确立知识界限所作的比喻性简化。狄慈根这一本质上是劝勉性的原则，其要点在于它作为无产阶级手中的武器是有用的：一种击退压抑之痛苦、劈开智性瘫痪的手段。其哲学上的遮掩故事是黑格尔式的：拒绝接受唯心主义把现实以“自在之物”的形式放逐到知识和经验无法触及的领域。但对狄慈根而言，真正重要的强调在于这一断言：没有任何事物能在被穷尽的意义上被认识。

<a id="ch02-p019-en"></a>
This sounds like mysticism, until it is recognized for what it really is: a proletarian exhortation, a call to seize hold of the whole of experience, to explore all of life and the world, to keep looking, to keep the greatest conceivable goals in sight, and never to give up. The impossibility of knowing anything ‘to its last particle’ does not have the character of a legislative restriction on thought: it is not a figurative simplification of Kant’s critical establishment of the limits of knowledge. The point of Dietzgen’s essentially exhortative principle is that it is useful as a weapon in the hands of the proletariat: a means of fighting off the agonies of inhibition and hacking clear of intellectual paralysis. The philosophical cover story is the Hegelian one about refusing to accept the idealist ejection of reality in the form of ‘thing in itself’ into a region beyond the reach of knowledge and experience. But the vital emphasis for Dietzgen is on the assertion that nothing can be known in the sense of being exhausted.

<a id="ch02-q008-zh"></a>
> 世界上没有任何事物，连一个原子也没有，能被彻底认识尽。世界上的一切事物在其秘密中都是不可穷尽的，正如它在其本质中是不朽而不可摧毁的。尽管如此，我们每天越来越多地学会认识事物，并认识到没有任何东西对我们的心灵是封闭的。<a id="ref-zh-ch02-38"></a>[38](#note-zh-ch02-38)

<a id="ch02-q008-en"></a>
> Nothing in the world, not an atom of it, is to be known out and out.  Everything in the world is inexhaustible in its secrets, no less than  it is imperishable and indestructible in its essence. With all that, we  learn every day more and more to know the things, and learn that  there is nothing which is closed to our mind.<a id="ref-en-ch02-38"></a>[38](#note-en-ch02-38)

<a id="ch02-p020-zh"></a>
<a id="ch02-p021-zh"></a>
对狄慈根来说，这是特定的革命唯物主义或“社会民主主义”唯物主义的理论基石。革命唯物主义不单纯是一种哲学学说或世界观，而是一种教育学：它是“我们［革命者］每天越来越多地学习……并认识到没有什么对我们的心灵封闭”的方式——同样，正因为如此，没有任何关系形式、任何工作形式对我们的生命封闭。革命唯物主义教育学不能没有“不可测量者”“无限”和“不可穷尽者”，不仅因为这种唯物主义必须与一个只允许（如蒲鲁东所说）“消费能力”无限的社会作斗争，更根本地因为“每天越来越多地”学习、从经验中学到一切可能的东西，才能使一个充满待发展潜能的人类主体的可能性保持活着——而资本系统地把它吸空抽干，掏成主体的一幅怪诞戏仿：劳动力。面对一个“不可穷尽的”世界——其任何部分都不对心灵“封闭”——的唯物主义者，与那种只作为一定量的社会必要“劳动力”而存在、等待被耗尽的工人相反；从价值对象性来看，工人在耗尽过程持续之前和之后都无足轻重。唯物主义教育学所激活的生命，与那种只不过是“生产过程的主观要素”的存在的怪诞空虚之间的对立，并不只是范畴的对立——不是各种新唯物主义者显然都觉得“反感”的“对立性思维方式”的产物——而是一场工人深切感受到的斗争，一种必须每天承受并正面回应的痛苦来源，甚至要“每天越来越多地”如此。

<a id="ch02-p020-en"></a>
<a id="ch02-p021-en"></a>
For Dietzgen, this was the theoretical bedrock of specifically revolutionary or ‘Social Democratic’ materialism. Revolutionary materialism is not a philosophical doctrine or world-view, simply, but a pedagogy: it is how ‘we [revolutionaries] learn every day more and more … and learn that there is nothing which is closed to our mind’ – just as, and for this very reason, there is no form of relation, no form of work, that is closed to our lives. Revolutionary materialist pedagogy cannot do without the ‘immeasurable’, the ‘infinite’ and the ‘inexhaustible’, not only because this materialism must fight against a society in which it is only (as Proudhon put it) ‘the power to consume’ that is allowed to be infinite, but more fundamentally because learning ‘every day more and more’, learning everything possible from experience, is what keeps alive the possibility of a human subject full of potential to be developed, the same subject that capital systematically sucks empty and hollows out into the grotesque parody of a subject, ‘labour-power’. The materialist who confronts an ‘inexhaustible’ world, no part of which is ‘closed’ to the mind, is the opposite of the worker who exists only as a quantity of socially necessary ‘labour-power’ to be exhausted, and who is, value-objectively speaking, of no consequence before or after the duration of the process of that exhaustion. This opposition of the life activated by materialist pedagogy to the grotesque emptiness of existence as nothing but ‘the subjective element in the production process’ is not a mere opposition of categories – a product of the ‘oppositional ways of thinking’ that new materialists of every sort apparently find ‘antipathetic’ – but a struggle that is deeply felt by the worker and a source of pain that must be lived with and lived up to, every day, and even ‘every day more and more’.

<a id="ch02-p022-zh"></a>
这种对立根本无法以“二元对立过时了”或“二元对立不够复杂”之类的说法打发。这是工人从根本上摆脱不掉的对立，是生命的一种基本规定。费尔巴哈曾激情地称之为“令人厌恶的矛盾”（*abstoßender Widerspruch*）的那种矛盾，内在于这种对立之中。<a id="ref-zh-ch02-39"></a>[39](#note-zh-ch02-39) 那种只不过是非人力量之耗尽的、作为戏仿形式的主体，是*碾压性的*：它是未被活过的生命的被感受到的事实。<a id="ref-zh-ch02-40"></a>[40](#note-zh-ch02-40) 这就是马克思在《资本论》中把商品形式描述为“可感觉而又超感觉的”这一表述的真相——这个表述人们早已熟悉，但即便现在也几乎未被理解，或只被小心翼翼地把握（这个谓词是马克思从黑格尔那里取来的，一如既往带有讽刺风格）。商品就是被感受到的未被活过的生命。

<a id="ch02-p022-en"></a>
This opposition is simply not dismissible by talk of the outmodedness or insufficient complexity of binaries. It is an opposition that workers are fundamentally stuck with, a basic determination of life. Contradiction, of the kind passionately characterized by Feuerbach as ‘abhorrent contradiction’ (*abstoßender Widerspruch*), is intrinsic to this opposition.<a id="ref-en-ch02-39"></a>[39](#note-en-ch02-39) The parody form of the subject that is nothing but the exhaustion of a nonhuman power is *crushing*: it is the felt fact of unlived life.<a id="ref-en-ch02-40"></a>[40](#note-en-ch02-40) This is the truth of Marx’s long familiar but even now scarcely understood or only delicately grasped description of the commodity form in *Capital* as ‘sensuous-supersensuous’ (a predicate that Marx lifted from Hegel, as usual in satirical style). The commodity is felt unlived life.

<a id="ch02-p023-zh"></a>
一极是能够在发现他人、对象和世界真正不可穷尽性的工作中“每天越来越多地”实现的主体性；另一极是这种主体性被无差异地转化为劳动力的抹除与封堵——这种劳动力存在只是为了在价值增殖中被耗尽。这种极化就是马克思在《德意志意识形态》中所说的“每个单独无产者的个性与劳动、与强加于他的生活条件之间的矛盾”。<a id="ref-zh-ch02-41"></a>[41](#note-zh-ch02-41) 劳动，在这种特定的资本主义形式中作为“生活条件”，随着无产者被迫服从它的时间越长，就日益“在其无内容性中令人憎恨”，它在如下意义上矛盾：对无产者而言，它既是一切，又是虚无。劳动是无产者“终其一生”的全部，同时劳动又与无产者“分离”或在其“之外”，甚至在其触及范围之外；这不仅是因为他不能为自己决定它将是什么活动、他要做多久、在何处何时去做，而且——对马克思来说最重要的是——他无法越过其无内容性，用狄慈根所描述的那种发现之真理去填充它：狄慈根在革命唯物主义劝勉中号召一种从经验中学习的方式，以揭示世界真正的不可穷尽性。真正自由的工作形式恰恰会这样做，会成为“每天越来越多地”关于自我、他人、对象和世界的知识——即便它令人沮丧、痛苦或在其他方面没有产出。狄慈根用一个音乐类比让这种唯物主义观念变得可理解：

<a id="ch02-p023-en"></a>
At one pole, a subjectivity that can be realized ‘every day more and more’ in the work of discovering the true inexhaustibleness of others, objects and the world; at the other pole, the blanking out and blocking in of that subjectivity by its indifferent conversion into labour-power that exists only in order to be exhausted in the valorization of value. This polarization is what, in *The* *German Ideology*, Marx calls ‘the contradiction between the individuality of each separate proletarian and labour, the condition of life forced upon him’.<a id="ref-en-ch02-41"></a>[41](#note-en-ch02-41) Labour, in this specifically capitalist form as a ‘condition of life’ that grows steadily more ‘hateful in its contentlessness’ the longer the proletarian is forced to submit to it, is contradictory in the sense that for the proletarian it is both everything and nothing. Labour is all that the proletarian is ‘for the entirety of his life’, and at the same time labour is ‘separate’ from or ‘outside’ of the proletarian and even out of his reach, not only in the sense that he cannot determine for himself what activity it will be, or how long he will do it for, or where and when he will do it, but also, and most importantly for Marx, that he cannot get past its contentlessness and fill it with the truth of discovery described by Dietzgen in his revolutionary materialist exhortation to a kind of learning from experience that discloses the true inexhaustibleness of the world. A form of work that is really free would do precisely that, and would be ‘every day more and more’ knowledge – of oneself, others, of objects, of the world – even when it is frustrating, painful or otherwise unproductive. Dietzgen makes sense of this idea of materialism with a musical analogy:

<a id="ch02-q009-zh"></a>
> 在我看来，只有彻底懂得如何演奏小提琴的人，才知道小提琴的本性——他知道其中有什么，也知道要做什么才能把它发挥出来。<a id="ref-zh-ch02-42"></a>[42](#note-zh-ch02-42)

<a id="ch02-q009-en"></a>
> In my opinion only that person is able to understand the nature of a  violin who knows thoroughly how to play it – who knows what there  is in it and what is to be done to bring it out of it.<a id="ref-en-ch02-42"></a>[42](#note-en-ch02-42)

<a id="ch02-p024-zh"></a>
正是在演奏小提琴数十年之后，指尖无穷小的运动的无限性才开始在现实中显现——也就是说，才真正被感受和认识——成为狄慈根所描述的那种“实质真理”。正是在这里，无穷小真正成为无限：感觉成为“通过眼睛、耳朵和手所构想”的真理，这种真理是“普遍生命的产物”。<a id="ref-zh-ch02-43"></a>[43](#note-zh-ch02-43) 在这个意义上，物质的人严格说来就像物质的小提琴：相互认识的要旨，是学会如何彻底认识彼此，发现我们自身之中有什么，以及要做什么才能把它从我们身上带出来；而革命唯物主义的要旨，是教会我们自己如何改造社会生产劳动，以便我们真的通过共同工作来认识自己和他人。那时，生产将是我们自己生命的生产。

<a id="ch02-p024-en"></a>
It is after playing the violin for decades that the infinity of the infinitesimal movement of a fingertip begins to appear in reality – that is, really to be felt and known – as the sort of ‘substantial truth’ that Dietzgen describes. This is where the infinitesimal becomes infinite for real: sensation becomes truth ‘conceived through the eyes, ears and hands’ that is the ‘product of universal life’.<a id="ref-en-ch02-43"></a>[43](#note-en-ch02-43) The material human being is in this sense strictly like the material violin: the point of knowing each other is to learn how to know each other thoroughly, to find out what there is in ourselves and what is to be done to bring it out of us, and the point of revolutionary materialism is to teach ourselves how to transform socially productive work so that we really do learn about ourselves and others by working together. Production will then be the production of our own lives.

<a id="ch02-p025-zh"></a>
工作是无限的，因为个体不可穷尽。新唯物主义或后人类把马克思主义漫画化为一种统治自然的哲学，未能认出这种关于工作与不可穷尽者之根本关系的愿景，也错过了它的诗性特征。这并不令人惊讶，因为新唯物主义对工作无话可说。

<a id="ch02-p025-en"></a>
The work is infinite because individuals are inexhaustible. The new materialist or post-human caricature of Marxism as a philosophy of domination over nature fails to recognize this vision of a fundamental relation of work to the inexhaustible, and misses its poetic character. This is not surprising, because new materialism has nothing to say about work.

<a id="ch02-s03-zh"></a>
## **旧的反马克思主义**

<a id="ch02-s03-en"></a>
## **Old anti-Marxisms**

<a id="ch02-p026-zh"></a>
只有一种被周密保护起来、拒不承认这场斗争之现实（它在今天、对如今活着的绝大多数人而言的现实）的理论，才会把这种关于唯物主义教育学揭示不可穷尽者之力量革命乐观主义，重新解释为一种过时的幻想：一个掌控性的、普罗米修斯式的人类跨立在自然之上，试图统治或殖民一切。狄慈根和马克思试图概念化的关系——以无产阶级的名义、为个体工人而做的，诗性的、充满激情的、具有哲学胆识的概念化——不是全知全能的人类主体与一个只为被统治或殖民而存在的自然之间的关系；这种关系是工作与不可穷尽者之间的关系。如果说某种掌控对于实现这种关系而可能从事的工作仍然不可或缺，那是因为正是在发现的远端，这种意义上的工作往往变得最为艰苦、最为引人入胜、要求最高、最为紧张。

<a id="ch02-p026-en"></a>
Only a theory that is well defended against recognition of the reality of this struggle – its reality today, for the vast majority of people alive now – could reinterpret this revolutionary optimism about the power of materialist pedagogy to disclose the inexhaustible as an outmoded fantasy about the masterful or Promethean human being standing astride nature and trying to dominate or colonize everything. The relation that Dietzgen and Marx tried to conceptualize – poetically, passionately and with philosophical daring, in the name of the proletariat and for individual workers – is not between a masterful human subject who knows everything and a nature that is there only to be dominated or colonized; the relation is between work and the inexhaustible. If mastery of a kind is nonetheless essential to the work that might be done to actualize this relation, it is because it is at the far reaches of discovery that work in this sense tends to get most seriously arduous, compelling, demanding and intense.

<a id="ch02-p027-zh"></a>
但如果说实际的对立性思维令新唯物主义者反感，某种对立的表示仍然被允许，只为维持体面。库尔和弗罗斯特在谈到他们的一些新唯物主义同行时写道：“一个马克思主义的标签，有助于表示他们对占主导地位的新自由主义趋势的反对。”导言的下一句话表明，他们说到“标签”时是认真的。他们写道：“在后结构主义及其批评之后，任何可行的马克思主义版本都不能推进一种历史元叙事，不能期望识别决定性的经济规律，不能推崇一种原初的、纯净的自然，也不能把共产主义设想为历史被理想化的物质命运。”<a id="ref-zh-ch02-44"></a>[44](#note-zh-ch02-44) 根据新唯物主义严苛的新标准，马克思本人的思想当然不够格成为马克思主义的“可行版本”。作为对照，《新唯物主义》文集中由 Pheng Cheah 和周蕾（Rey Chow）提供了“后结构主义及其批评”的一些可行版本。Cheah 解释说，马克思主义对“作为社会历史主体的无产阶级”的顽固依恋，使它无法认识到“与他异性的关系比作为实体或在场的物质更物质”。<a id="ref-zh-ch02-45"></a>[45](#note-zh-ch02-45) 因为马克思主义不能或不愿放弃阶级、历史和主体性，以及对立性思维的其他一切执念，它就被困在一个不够物质的物质概念中——这种物质比德里达的“没有唯物主义、甚至或许没有物质的物质性”更不物质。<a id="ref-zh-ch02-46"></a>[46](#note-zh-ch02-46) 这解释了马克思主义者为何未能领会：“不可能者奇怪地比具体实际更物质、更真实。”新唯物主义的物质比旧唯物主义的物质更物质；这种新的、更物质的物质性，在理论上让新唯物主义者的生活比马克思主义者更难，因为后者仍可天真地享受一种幻觉：经济规律可以被识别，共产主义可以被设想。新唯物主义者必须处理一种更物质的物质性，它不再“轻易由政治话语可识别的具体形象（例如工人阶级）所实例化”。<a id="ref-zh-ch02-47"></a>[47](#note-zh-ch02-47) 面对不可能者那更物质的物质性，像工人阶级这样易于实例化的具体形象并不可行。然而新唯物主义者不必绝望，因为究竟有什么具体形象可用来实例化物质性，毕竟甚至不是一个新问题；“也许更好的问题是”，Cheah 安慰地建议，“不要问这些新唯物主义与政治思想的相关性及其对具体政治的含义，而要问它们如何激进地置疑政治理论的基本范畴，包括政治本身的概念。”<a id="ref-zh-ch02-48"></a>[48](#note-zh-ch02-48)

<a id="ch02-p027-en"></a>
But if actual oppositional thinking is antipathetic for new materialists, some signifying of opposition is nonetheless permissible, for the purposes of keeping up appearances. ‘A Marxist label’, write Coole and Frost of some of their fellow new materialists, ‘has helped to signify their opposition to dominant neoliberal trends.’ The next sentence of the introduction makes clear that when they say ‘label’, they mean it. ‘Coming after poststructuralism and its criticisms’, they write, ‘no workable version of Marxism can advance a historical metanarrative, aspire to the identification of determining economic laws, valorize an originary, pristine nature, or envisage communism as history’s idealized material destiny.’<a id="ref-en-ch02-44"></a>[44](#note-en-ch02-44) Marx’s own thought would certainly not qualify as a ‘workable version’ of Marxism, according to the tough new stand ards of new materialism. For contrast, some workable versions of ‘poststructuralism and its criticisms’ are provided in the *New* *Materialisms* volume by Pheng Cheah and Rey Chow. Cheah explains that Marxism’s stubborn attachment to the ‘proletariat as a sociohistorical subject’ stops it from recognizing that the ‘relation to alterity is more material than matter as substance or presence’.<a id="ref-en-ch02-45"></a>[45](#note-en-ch02-45) Because Marxism cannot or will not let go of class, history and subjectivity, and all the other hang-ups of oppositional thought, it is stuck with a concept of matter that is not material enough, a matter that is less material than Derrida’s ‘materiality without materialism and even perhaps without matter.’<a id="ref-en-ch02-46"></a>[46](#note-en-ch02-46) This explains the failure of Marxists to grasp that ‘the impossible is curiously more material and real than concrete actuality.’ The new materialist’s matter is more material than the old materialist’s matter, and this new, more material materiality makes life harder in theory for the new materialist than it was for the Marxist, who could still naively enjoy the delusion that economic laws can be identified and communism can be envisioned. The new materialist has to deal with a more material materiality that is no longer ‘easily instantiated by concrete figures that are recognizable by political discourse’, like the working class.<a id="ref-en-ch02-47"></a>[47](#note-en-ch02-47) Easily instantiated concrete figures like the working class are not workable in light of the more material materiality of the impossible. Yet the new materialist need not despair, because the question what concrete figure might be available to instantiate materiality is after all not even a new question; ‘perhaps the better question to ask’, Cheah consolingly suggests, ‘is not that of the relevance of these new materialisms to political thought and their implications for concrete politics but how they radically put into question the fundamental categories of political theory including the concept of the political itself.’<a id="ref-en-ch02-48"></a>[48](#note-en-ch02-48)

<a id="ch02-p028-zh"></a>
<a id="ch02-p029-zh"></a>
新唯物主义者周蕾对“如何改变世界”这个旧而不可行的马克思主义问题另有更好的问题设想。她以一种自由主义的非排他精神——这种精神在此一直延伸到马克思主义废料场的边缘——问道：“如果我们采纳马克思主义对唯物主义/物质性的关注（作为批判意识哲学的一种方式），却不把它（像马克思主义往往那样）定义为一种带来改善性变革的能动力量，那会怎样？”<a id="ref-zh-ch02-49"></a>[49](#note-zh-ch02-49) 借用德里达的说法，简·贝内特对某一个马克思也同样好客。《德意志意识形态》《共产党宣言》和《资本论》的马克思或许不再可行，因为那个马克思是人道主义者；但在荣誉性的原初新唯物主义者名册中，可以为“写德谟克利特论文的马克思”留出位置——即为马克思按照大学提交规定、在身为大学成员并受学术知识礼仪规范约束时写下的那一篇作品留出位置。<a id="ref-zh-ch02-50"></a>[50](#note-zh-ch02-50) 与这部早期作品的精神及其对萌芽中的新唯物主义所作的充满希望的暗示相反，马克思不久便离开大学，成为一个好斗、大嗓门、狂放诗性的共产主义者；他对工人这一“社会历史主体”的前解构式执迷，使他犯了过高估计人类的错误。他最终成为贝内特所谓“物种自恋”的牺牲品——一种对我们之外事物的深度麻木，其养分是有毒信念：人类生命“特殊——也就是从根本上不同于物质”。认为我们活着并没有错；麻烦始于“我们人类……把自己看作［生命的］*最*特殊的表现形式”。<a id="ref-zh-ch02-51"></a>[51](#note-zh-ch02-51) 没有哪种聚苯乙烯、蝙蝠屎或系外行星会如此自恋，我们为何要如此？<a id="ref-zh-ch02-52"></a>[52](#note-zh-ch02-52) 难道人类独一无二地易受“人类中心偏见”影响吗？<a id="ref-zh-ch02-53"></a>[53](#note-zh-ch02-53)（狄慈根显然从未成为这种自恋焦虑的猎物，尽管他是一个旧唯物主义者、一个人道主义者、一个未被解构的革命者：“人们对自己智力的骄傲是正当的，但把在他们看来头等重要的东西赋予世界之中的首要地位，则是幼稚的。”<a id="ref-zh-ch02-54"></a>[54](#note-zh-ch02-54)）新唯物主义者罗西·布拉伊多蒂用一种令人安心地近似于新技术营销推介的语汇，庆祝后人类终于在新唯物主义中到来：它“经验上有根据，因为它被嵌入并被具身”，它“更像一个形象，而不像一个实体发挥作用”，它“是一种由理论驱动的制图工具，旨在充分理解……解构人类的过程”，它“提供了一个框架，以理解我们快速变化的时代中正在进行的成为主体的过程”，同时它“使我们能够跨越若干跨学科领域，追踪关于非人/非人性（inhuman）/跨人/元人/后人类的话语的出现，这些话语由对人本主义和人类中心主义的交叉批判所产生”。<a id="ref-zh-ch02-55"></a>[55](#note-zh-ch02-55) 但即便在这“新”之新曙光的光照下，人们仍发现有必要加一个清醒的警示。布拉伊多蒂说，所有这些收获都可能被“泛人类的重新发明”逆转；这种泛人类在天主教会的保守话语、企业泛人类主义和好战的军事干涉主义中“显而易见”，但更不祥的是，“它在进步左翼中更为迂回，却同样强大，那里社会主义人道主义的遗产提供了工具，把焦虑改造成政治狂怒”。<a id="ref-zh-ch02-56"></a>[56](#note-zh-ch02-56)

<a id="ch02-p028-en"></a>
<a id="ch02-p029-en"></a>
New Materialist Rey Chow has another idea for a better question than the old unworkable Marxist one about how to change the world. In a spirit of liberal non-exclusivity that here extends right up to the periphery of the Marxist scrapyard, she asks: ‘what if we were to adopt Marxism’s focus on materialism/ materiality (as a way to critique the philosophy of consciousness), yet without defining it (as Marxism tends to) as an agency of change-as-improvement?’<a id="ref-en-ch02-49"></a>[49](#note-en-ch02-49) Jane Bennett is comparably hospitable to a certain Marx, to borrow Derrida’s phrase. The Marx of *The German Ideology*, *The Communist Manifesto* and *Capital* may no longer be workable, since that Marx was a humanist, but room can be made in a roster of honorary proto-new materialists for ‘the Marx of his dissertation on Democritus’ – that is, for the one piece of writing that Marx did according to university regulations for submission, while he was a member of a university, constrained by the norms of academic intellectual decorum.<a id="ref-en-ch02-50"></a>[50](#note-en-ch02-50) Contrary to the spirit of this early work and its promising intimations of the budding new materialism, Marx would shortly leave the university, and would become an aggressive, loud-mouthed, wildly poetic communist whose pre-deconstructive obsession with the ‘sociohistorical subject’ of the worker led him into the error of overvaluing human beings. He ended up a casualty of what Bennett calls ‘species-narcissism’, a kind of deep numbness to things other than ourselves, nourished by the toxic belief that human life is ‘special – that is, radically other to matter’. There is nothing wrong with thinking that we are alive; the trouble starts when ‘we humans … think of ourselves as the *most* special of [life’s] expressions’.<a id="ref-en-ch02-51"></a>[51](#note-en-ch02-51) No polystyrene, bat shit or exoplanet would be so narcissistic, so why should we?<a id="ref-en-ch02-52"></a>[52](#note-en-ch02-52) Can it be that humans are uniquely susceptible to ‘humancentric prejudice’?<a id="ref-en-ch02-53"></a>[53](#note-en-ch02-53) (Dietzgen was apparently never prey to such anxieties about narcissism, despite being an old materialist, a humanist and an un-deconstructed revolutionary: ‘Men are, and have a right to be, proud of their intellect, but it is puerile to give to a thing, which appears to them of primary importance, the primacy of the world.’<a id="ref-en-ch02-54"></a>[54](#note-en-ch02-54)) New materialist Rosi Braidotti, in an idiom reassuringly similar to that of a marketing pitch for a new technology, celebrates the arrival in new materialism of the posthuman that is at last ‘empirically grounded, because it is embedded and embodied’ and that ‘functions less as a substantive entity than a figuration’ and that ‘is a theoretically-powered cartographic tool that aims at achieving adequate understanding of … processes of undoing the human’ and that ‘provides a frame to understand the ongoing processes of becoming-subjects in our fast-changing times’, while it also ‘enables us to track, across a number of interdisciplinary fields, the emergence of discourses about the non/in/trans/meta/ post-human, which are generated by the intersecting critiques of humanism and of anthropocentrism’.<a id="ref-en-ch02-55"></a>[55](#note-en-ch02-55) But even in this light of the new dawn of the new, one sober note of caution is found to be necessary. All these gains may yet be reversed, says Braidotti, by ‘the reinvention of a pan-human’, which is ‘explicit in the conservative discourse of the Catholic Church, in corporate pan-humanism, [and] belligerent military interventionism’, but which, more ominously, ‘is more oblique but equally strong in the progressive Left, where the legacy of socialist humanism provides the tools to re-work anxiety into political rage’.<a id="ref-en-ch02-56"></a>[56](#note-en-ch02-56)

<a id="ch02-p030-zh"></a>
新唯物主义者不去沉溺于用社会主义人道主义遗产的工具、由焦虑编造出来的政治狂怒，也不采用那种不符合“通过标签表示对主导结构之反对”要求的旧人道主义马克思主义；他们常常喜欢引用德勒兹。但他们拥抱的德勒兹，不是《反俄狄浦斯》中那个满口脏话、好斗的合著者；后者向学院提出的问题是：“人是否应当因为所吃之物而窒息，吞咽空气，用嘴拉屎？”<a id="ref-zh-ch02-57"></a>[57](#note-zh-ch02-57) 新唯物主义偏爱一套柔和的德勒兹母题调色板：晚期哲学写作中关于内在性、切口、褶皱、平面和生成的灰色与米色。德勒兹那野性的调色板，真正刺目的原色，那个充满他在尼采身上热爱并崇拜的攻击性与暴力的野兽派德勒兹，被礼貌的沉默略过。《反俄狄浦斯》的德勒兹是“主动的、攻击性的、艺术的、生产性的、凯旋的”德勒兹，是“狂野生产与爆炸性欲望”和“公开恶意的活动”的热爱者；他对“再现”逻辑的超暴力“精神分裂分析”攻击，如今几乎不合时宜得令人难以忍受（“整个欲望—*生产*都被碾碎，屈从于*再现*的要求，屈从于再现中代表者与被代表者的沉闷游戏”）。<a id="ref-zh-ch02-58"></a>[58](#note-zh-ch02-58) 这个特定的德勒兹痴迷于“性无处不在这一真相”，例如“资产阶级如何操无产阶级”，以及“希特勒如何让法西斯分子勃起”。<a id="ref-zh-ch02-59"></a>[59](#note-zh-ch02-59) 这个特定的德勒兹在新唯物主义手中遭受的，正是他在1965年论尼采的文章中所阐明的那种可鄙病态的命运：“他不再是诗人，而成为‘公共教授’”。<a id="ref-zh-ch02-60"></a>[60](#note-zh-ch02-60) 正如列宁在谈到“对对立性思维的厌恶”这一漫长历史中的另一段插曲时所说：“教授们利用并且想要利用大学的自由，不是为了煽起大火，而是为了扑灭它。”<a id="ref-zh-ch02-61"></a>[61](#note-zh-ch02-61)

<a id="ch02-p030-en"></a>
Instead of wallowing in political rage fabricated out of anxiety using the tools of the legacy of socialist humanism, and instead of the old humanist Marxism that does not meet the requirements of signifying opposition to dominant structures by means of a label, new materialists often like to quote Deleuze. But the Deleuze they embrace is not the foul-mouthed, aggressive co-author of *Anti-Oedipus*, whose question for the academy was ‘Should one, or should one not, suffocate from what one eats, swallow air, shit with one’s mouth?’<a id="ref-en-ch02-57"></a>[57](#note-en-ch02-57) New materialism prefers a muted palette of Deleuzean motifs, the greys and beiges of the late philosophical writing about immanence, cuts, folds, planes and becoming. The savage palette of Deleuze, the really lurid primary colours, the fauvist Deleuze full of the aggression and violence that he loved and idolized in Nietzsche, is passed over in polite silence. The Deleuze of *Anti-Oedipus* was the ‘active, aggressive, artistic, productive, and triumphant’ Deleuze, the lover of ‘wild production and explosive desire’ and of ‘openly malevolent activity’, the Deleuze whose ultra-violent, ‘schizoanalytic’ attack on the logic of ‘representation’ is now almost insufferably untimely (‘The whole of desiring-*production* is crushed, subjected to the requirements of *representation*, and to the dreary games of what is representative and represented in representation’).<a id="ref-en-ch02-58"></a>[58](#note-en-ch02-58) This certain Deleuze was obsessed with ‘the truth that sexuality is everywhere’, such as in ‘the way the bourgeoisie fucks the proletariat’ and in how ‘Hitler gave the fascists hard-ons’.<a id="ref-en-ch02-59"></a>[59](#note-en-ch02-59) This certain Deleuze has suffered at the hands of new materialism the very fate whose despicable morbidity he spelled out in his 1965 essay on Nietzsche: ‘he ceases to be a poet and becomes a “public professor”’.<a id="ref-en-ch02-60"></a>[60](#note-en-ch02-60) As Lenin said, with reference to another episode in the long history of ‘antipathy to oppositional ways of thinking’, ‘professors use and desire to use the freedom of the universities not to fan the conflagration but to extinguish it.’<a id="ref-en-ch02-61"></a>[61](#note-en-ch02-61)

<a id="ch02-p031-zh"></a>
这一切都回到诗学，最终回到马克思《资本论》的诗学。布拉伊多蒂称为“解构人类”、贝内特称为克服我们的“物种自恋”的理论化，从根本上是在禁止那种真正暴烈而革命的自我灭绝的诗学。新唯物主义宣告放弃宏大的自我、膨胀的自我、跨立世界的自我、与动物和物质不同且更优越的自我，但实际上，它靠一种通过滴灌大量施予的否定配方，让所有这些令人反感的角色保持活着。真正被从新唯物主义的万有理论中排除掉的自我，不是自大狂或夸张化的自我，而是被压碎、被掏空、被无限削小的自我：马克思的工人——其在资本关系中的存在，是无关紧要的暴风雪中的“尘埃性”。<a id="ref-zh-ch02-62"></a>[62](#note-zh-ch02-62) 通过把一种内在于物质本身的新的“平等主义”理论化，通过推出新的物质概念，使它包摄生命、宇宙以及一切可能被评价之物，通过坚持这种物质性是一种比任何对立性思维（或革命社会批判）所梦见过的都更物质的物质性，新唯物主义实际上糊住了社会现实中那道无底裂缝——在那里，尚待物质化的存在之尘埃卡在永恒的坠落中。说明这一意味的一种方式是：新唯物主义漫不经心地废除了马克思从亚里士多德那里发展出的潜能逻辑——正是这种逻辑塑造了工人的形象：他还远不能过上我们知道应当属于我们的生活；这个活着的个体被世界阻挡、压碎、掏空，正因如此，他很久以前就等同于任何物质事物，甚至早于新平等主义的福音，因为人类与聚苯乙烯在‘从价值对象性来看’完全无关紧要这一点上完全一样。

<a id="ch02-p031-en"></a>
All this comes back to poetics, and ultimately back to the poetics of Marx’s *Capital*. The theorizing that Braidotti calls ‘undoing the human’ and Bennett calls getting over our ‘species- narcissism’ is fundamentally about proscribing the really violent and revolutionary poetics of self-extinction. New materialism proclaims its renunciation of the grandiose self, the inflated ego, the self astride the world, the self that is different from and better than animals and matter, but in fact it keeps all these objectionable personae alive on a formula of repudiation liberally administered by drip-feed. The self that is actually written out of new materialism’s theory of everything is not the egomaniacal or hyperbolized self but the one that is crushed, emptied and infinitely diminished: Marx’s worker, whose existence in the capital-relation is ‘specklikeness’ in a blizzard of indifference.<a id="ref-en-ch02-62"></a>[62](#note-en-ch02-62) By theorizing a new ‘egalitarianism’ intrinsic in matter itself, by rolling out the new concept of matter so that it comprehends life, the universe and everything that could ever be valued, and by insisting that this materiality is a more material materiality than any oppositional mode of thinking (or revolutionary social criticism) ever dreamt of, new materialism in effect papers over the bottomless crack in social reality where the speck of existence that is yet to be materialized is stuck in a perpetual plummet. One way of saying what this means is to say that new materialism casually abolishes the logic of potentiality that Marx developed out of Aristotle to create the figure of the worker who is not yet anywhere near being able to live the life that we know is meant for us; the living individual who is blocked, crushed and emptied by the world and who precisely for that reason was long ago equal to any and every material thing, even prior to the good news about the new egalitarianism, since the human being and polystyrene are perfectly alike in being ‘value-objectively’ a matter of complete indifference.

<a id="ch02-p032-zh"></a>
另一种说法是：新唯物主义特地抽空了那种攻击性，而它作为社会革命思想形式的唯物主义批判史一直不可或缺。马克思的写作充满暴烈的批判：这种暴力不只是谴责或模仿，而是反击并引爆社会关系的暴力，它以概念和想象的极端去考验那些社会关系逻辑在诗性火焰的错乱之下还能支撑多久。马克思的唯物主义批判不是像教科书那样推进，而是旋转进入伪科学的、或认知上难以处理的概念化谵妄，把可感觉者与超感觉者、物理学与经济学、李嘉图与狼人、蝙蝠屎与黑格尔强行拼在一起，抓取政治经济学的语言，拉出其骇人地凸出的反讽内脏，处处违反其自身范畴逻辑的词汇纪律。所有这些都是马克思的*诗学*：马克思思想的唯物主义就在那里，不在那些关于所谓目的论的、熟悉而其实懒惰且虚构的投射中，也不在那种被动惰性的物质世界、以及跨立其上挥舞辩证法的伟大普罗米修斯式人类的图景中（那只是教授们的自由主义宣传），而在对工人已灭绝的自我与生命的逻辑上操蛋的、幻想的、不可忍受地真实的描述中：一个原子尘埃，在价值增殖无限性的螺旋下被碾碎。马克思对人类生命的唯物主义愿景，对主体施加巨大压力，迫使其经验这一真理；正如体力劳动者、旧唯物主义者狄慈根曾写道的，这意味着像脑中烈火一样感受它。

<a id="ch02-p032-en"></a>
Another way of saying the same thing is that new materialism specifically evacuates the aggression that has been essential to the history of materialist criticism as a form of socially revolutionary thought. Marx’s writing is full of violent critique: a violence that does not merely condemn, or mimic, but that reacts against and sparks off the violence of social relations, by testing to conceptual and imaginative extremes the strength of the logic of those social relations to hold up under the derangements of poetic fire. Marx’s materialist critique proceeds not like a textbook but by spinning out into deliriums of pseudoscientific or cognitively intractable conceptualization, jamming together the sensuous and supersensuous, physics and economics, Ricardo and the werewolf, bat shit and Hegel, grabbing at the language of political economy and pulling out its gruesomely obtruding ironic innards, violating at every turn the lexical discipline of its own logic of categories. All this is Marx’s *poetics*: the materialism of Marx’s thought is right there, not in the familiar, and in fact lazy and fictitious, projections about so-called teleology, or the passive and inert world of matter astride which stands the great Promethean human being swinging his dialectics, which is just the liberal propaganda of professors, but in the logically fucked-up, fantastical, intolerably true description of the extinct self and life of the worker as an atomic speck crushed under the spiral of valorization’s infinity. Marx’s materialist vision of human life puts intense pressure on the subject to experience this truth, which means, as the manual labourer and old materialist Dietzgen once wrote, to feel it like a fire in the brain.

### 原注

<a id="ch02-n001-zh"></a><a id="note-zh-ch02-1"></a>
[1] Rosi Braidotti, ‘A Theoretical Framework for the Critical Posthumanities’, *Theory, Culture & Society*, vol. 36, no. 6, 2018, pp. 31–61, p. 53; Elizabeth Grosz, ‘An Interview with Elizabeth Grosz: Geopower, Inhumanism and the Biopolitical’, interviewers Kathryn Yusoff and Nigel Clark, *Theory, Culture & Society*, vol. 34, nos 2–3, 2017, p. 132. [返回](#ref-zh-ch02-1)

<a id="ch02-n001-en"></a><a id="note-en-ch02-1"></a>
[1] Rosi Braidotti, ‘A Theoretical Framework for the Critical Posthumanities’, *Theory,* *Culture & Society*, vol. 36, no. 6, 2018, pp. 31–61, p. 53; Elizabeth Grosz, ‘An Interview with Elizabeth Grosz: Geopower, Inhumanism and the Biopolitical’, interviewers Kathryn Yusoff and Nigel Clark, *Theory, Culture & Society*, vol. 34, nos 2–3, 2017, p. 132. [返回](#ref-en-ch02-1)

<a id="ch02-n002-zh"></a><a id="note-zh-ch02-2"></a>
[2] Braidotti, ‘A Theoretical Framework for the Critical Posthumanities’, p. 42. [返回](#ref-zh-ch02-2)

<a id="ch02-n002-en"></a><a id="note-en-ch02-2"></a>
[2] Braidotti, ‘A Theoretical Framework for the Critical Posthumanities’, p. 42. [返回](#ref-en-ch02-2)

<a id="ch02-n003-zh"></a><a id="note-zh-ch02-3"></a>
[3] Grosz, ‘An Interview with Elizabeth Grosz’, pp. 135–6. [返回](#ref-zh-ch02-3)

<a id="ch02-n003-en"></a><a id="note-en-ch02-3"></a>
[3] Grosz, ‘An Interview with Elizabeth Grosz’, pp. 135–6. [返回](#ref-en-ch02-3)

<a id="ch02-n004-zh"></a><a id="note-zh-ch02-4"></a>
[4] Pheng Cheah, ‘Non-dialectical Materialism’, in Diana Coole and Samantha Frost, eds, *New Materialisms: Ontology, Agency, and Politics*, Durham NC: Duke University Press, 2010, pp. 75–81. 正如韩炳哲所指出的，抹除目的论的不是解构，而是资本，它连同“每一个‘为了’”一起抹除，结果是“生命从未像今天这样短暂”。*Topology of Violence*, trans. Amanda Demarco, Cambridge MA and London: MIT Press, 2018, p. 19. [返回](#ref-zh-ch02-4)

<a id="ch02-n004-en"></a><a id="note-en-ch02-4"></a>
[4] Pheng Cheah, ‘Non-dialectical Materialism’, in Diana Coole and Samantha Frost, eds, *New Materialisms: Ontology, Agency, and Politics*, Durham NC: Duke University Press, 2010, pp. 75–81. As Byung-Chul Han has pointed out, it is not deconstruction but capital that ‘wipes out’ teleology, along with ‘every in-order-to’, with the result that ‘life has never been so fleeting as it is today’. *Topology of Violence*, trans. Amanda Demarco, Cambridge MA and London: MIT Press, 2018, p. 19. [返回](#ref-en-ch02-4)

<a id="ch02-n005-zh"></a><a id="note-zh-ch02-5"></a>
[5] Braidotti, ‘A Theoretical Framework for the Critical Posthumanities’, p. 53. [返回](#ref-zh-ch02-5)

<a id="ch02-n005-en"></a><a id="note-en-ch02-5"></a>
[5] Braidotti, ‘A Theoretical Framework for the Critical Posthumanities’, p. 53. [返回](#ref-en-ch02-5)

<a id="ch02-n006-zh"></a><a id="note-zh-ch02-6"></a>
[6] Diana Coole and Samantha Frost, ‘Introducing the New Materialisms’, in Coole and Frost, eds, *New Materialisms*, p. 17; Jane Bennett, ‘A Vitalist Stopover on the Way to a New Materialism’, in ibid., pp. 59–60. [返回](#ref-zh-ch02-6)

<a id="ch02-n006-en"></a><a id="note-en-ch02-6"></a>
[6] Diana Coole and Samantha Frost, ‘Introducing the New Materialisms’, in Coole and Frost, eds, *New Materialisms*, p. 17; Jane Bennett, ‘A Vitalist Stopover on the Way to a New Materialism’, in ibid., pp. 59–60. [返回](#ref-en-ch02-6)

<a id="ch02-n007-zh"></a><a id="note-zh-ch02-7"></a>
[7] Rey Chow, ‘The Elusive Material, What the Dog Doesn’t Understand’, in Coole and Frost, eds, *New Materialisms*, p. 226. [返回](#ref-zh-ch02-7)

<a id="ch02-n007-en"></a><a id="note-en-ch02-7"></a>
[7] Rey Chow, ‘The Elusive Material, What the Dog Doesn’t Understand’, in Coole and Frost, eds, *New Materialisms*, p. 226. [返回](#ref-en-ch02-7)

<a id="ch02-n008-zh"></a><a id="note-zh-ch02-8"></a>
[8] 正如 Susanne Lettow 所解释的，在马克思和恩格斯的全部著作中，“实践、活动、生产与生活条件都被刻画为物质的……形容词‘物质的’充当一整套身体、自然、技术和社会问题的占位符。” ‘Turning the Turn: New Materialism, Historical Materialism and Critical Theory’, *Thesis Eleven*, vol. 140, no. 1, 2017, pp. 106–21. [返回](#ref-zh-ch02-8)

<a id="ch02-n008-en"></a><a id="note-en-ch02-8"></a>
[8] As Susanne Lettow has explained, throughout the works of Marx and Engels ‘practice, activity, production, and conditions of life are all characterized as material … the adjective “material” functions as placeholder for a whole bundle of bodily, natural, technological and social issues.’ ‘Turning the Turn: New Materialism, Historical Materialism and Critical Theory’, *Thesis Eleven*, vol. 140, no. 1, 2017, pp. 106–21. [返回](#ref-en-ch02-8)

<a id="ch02-n009-zh"></a><a id="note-zh-ch02-9"></a>
[9] Braidotti, ‘A Theoretical Framework for the Critical Posthumanities’, p. 38. [返回](#ref-zh-ch02-9)

<a id="ch02-n009-en"></a><a id="note-en-ch02-9"></a>
[9] Braidotti, ‘A Theoretical Framework for the Critical Posthumanities’, p. 38. [返回](#ref-en-ch02-9)

<a id="ch02-n010-zh"></a><a id="note-zh-ch02-10"></a>
[10] Joseph Dietzgen, *Excursions of a Socialist into the Domain of Epistemology* [*Streifzüge eines Sozialisten in das Gebiet der Erkenntnistheorie*] (1887), in *Some of the Philosophical Essays on Socialism and Science, Religion, Ethics, Critique-of-Reason and the World-at-large*, trans. M. Beer and T. Rothstein, Chicago: Charles H. Kerr, 1906, p. 294. 布鲁诺·维勒在发表于 *Der Sozialistiche Akademiker*（1896年）、回忆自己拜访狄慈根制革厂的一篇文章中，称狄慈根为“哲学工人”；该文转引自 Eugene Dietzgen, ‘Sketch of the Life of Joseph Dietzgen’, *Some of the Philosophical Essays*, p. 19：“我从他最初几句话就发现，他对更高精神生活的领域完全熟悉。他的灵魂上没有一丝店铺的灰尘。没有一位教授能从书桌前起身时比这位制革匠从体力劳动中起身时更有精神。几分钟内，我们就深谈起了哲学书籍和问题。……这位哲学工人甚至研究过古代文学，而且比一般大学毕业生表现出的更成功，尽管他并不熟悉希腊文，拉丁文也只是初学者。” [返回](#ref-zh-ch02-10)

<a id="ch02-n010-en"></a><a id="note-en-ch02-10"></a>
[10] Joseph Dietzgen, *Excursions of a Socialist into the Domain of Epistemology* [Stre*ifzüge eines Sozialisten in das Gebiet der Erkenntnistheorie*] (1887), in *Some of the* *Philosophical Essays on Socialism and Science, Religion, Ethics, Critique-of-Reason and* *the World-at-large*, trans. M. Beer and T. Rothstein, Chicago: Charles H. Kerr, 1906, p. 294. Dietzgen was dubbed the ‘philosophical working man’ by Bruno Wille in an article recollecting Wille’s visit to Dietzgen’s tannery in *Der Sozialistiche Akademiker*, 1896, cited in Eugene Dietzgen, ‘Sketch of the Life of Joseph Dietzgen’, *Some of the Philosophical* *Essays*, p. 19: ‘I discovered by his very first sentences that he was perfectly at home in the regions of higher mental life. Not a trace of the dust of the shop was on his soul. No professor could rise from his desk more spiritualized than this tanner did from his manual labor. In a few minutes, we were deeply engaged in a discussion of philosophical books and problems. … This philosophical working man had even occupied himself with antique literature, and with better success than is generally shown by a graduate of a college, in spite of the fact that he was not familiar with Greek and only a beginner in Latin.’ [返回](#ref-en-ch02-10)

<a id="ch02-n011-zh"></a><a id="note-zh-ch02-11"></a>
[11] Dietzgen, *Excursions*, pp. 300, 279. 关于狄慈根著作的一个有用概览——该文主张狄慈根应被视为“辩证唯物主义”的发明者——参见 Tony Burns, ‘Joseph Dietzgen and the History of Marxism’, *Science & Society*, vol. 66, no. 2, Summer 2002, pp. 202–27. Burns 以令人失望地清醒的判断作结：狄慈根对马克思主义理论的贡献很小，其哲学并不很有原创性。但 Burns 对狄慈根关于思想与工作之关系的观念（对本文至关重要）只字未提。 [返回](#ref-zh-ch02-11)

<a id="ch02-n011-en"></a><a id="note-en-ch02-11"></a>
[11] Dietzgen, *Excursions*, pp. 300, 279. For a useful overview of Dietzgen’s work that argues that Dietzgen should be credited as the inventor of ‘dialectical materialism’, see Tony Burns, ‘Joseph Dietzgen and the History of Marxism’, *Science & Society*, vol. 66, no. 2, Summer 2002, pp. 202–27. Burns concludes with the disappointingly sober judgement that Dietzgen’s contribution to Marxist theory was minor and that his philosophy was not very original. But Burns says nothing about Dietzgen’s ideas (crucial for the present essay) about the relation of thought to work. [返回](#ref-en-ch02-11)

<a id="ch02-n012-zh"></a><a id="note-zh-ch02-12"></a>
[12] Dietzgen, *Excursions*, p. 279. [返回](#ref-zh-ch02-12)

<a id="ch02-n012-en"></a><a id="note-en-ch02-12"></a>
[12] Dietzgen, *Excursions*, p. 279. [返回](#ref-en-ch02-12)

<a id="ch02-n013-zh"></a><a id="note-zh-ch02-13"></a>
[13] Joseph Dietzgen, *Das Wesen der Menschlichen Kopfarbeit* [The Essence of Human Headwork], Stuttgart, 1903, p. 64; 本文作者译。 [返回](#ref-zh-ch02-13)

<a id="ch02-n013-en"></a><a id="note-en-ch02-13"></a>
[13] Joseph Dietzgen, *Das Wesen der Menschlichen Kopfarbeit* [The Essence of Human Headwork], Stuttgart, 1903, p. 64; my translation. [返回](#ref-en-ch02-13)

<a id="ch02-n014-zh"></a><a id="note-zh-ch02-14"></a>
[14] Dietzgen, *Excursions*, pp. 317–18. [返回](#ref-zh-ch02-14)

<a id="ch02-n014-en"></a><a id="note-en-ch02-14"></a>
[14] Dietzgen, *Excursions*, pp. 317–18.s [返回](#ref-en-ch02-14)

<a id="ch02-n015-zh"></a><a id="note-zh-ch02-15"></a>
[15] Dietzgen, *Das Wesen der Menschlichen Kopfarbeit*, p. 58. [返回](#ref-zh-ch02-15)

<a id="ch02-n015-en"></a><a id="note-en-ch02-15"></a>
[15] Dietzgen, *Das Wesen der Menschlichen Kopfarbeit*, p. 58. [返回](#ref-en-ch02-15)

<a id="ch02-n016-zh"></a><a id="note-zh-ch02-16"></a>
[16] Nancy C.M. Hartsock, *The Feminist Standpoint Revisited and Other Essays*, Boulder CO: Westview, 1998, p. 45. [返回](#ref-zh-ch02-16)

<a id="ch02-n016-en"></a><a id="note-en-ch02-16"></a>
[16] Nancy C.M. Hartsock, *The Feminist Standpoint Revisited and Other Essays*, Boulder CO: Westview, 1998, p. 45. [返回](#ref-en-ch02-16)

<a id="ch02-n017-zh"></a><a id="note-zh-ch02-17"></a>
[17] ‘Denken ist eine leibliche Arbeit’, in Dietzgen, *Das Wesen der Menschlichen Kopfarbeit*, p. 64. [返回](#ref-zh-ch02-17)

<a id="ch02-n017-en"></a><a id="note-en-ch02-17"></a>
[17] ‘Denken ist eine leibliche Arbeit’, in Dietzgen, *Das Wesen der Menschlichen* *Kopfarbeit*, p. 64. [返回](#ref-en-ch02-17)

<a id="ch02-n018-zh"></a><a id="note-zh-ch02-18"></a>
[18] Diana Coole, ‘The Inertia of Matter and the Generativity of Flesh’, in Coole and Frost, eds, *New Materialisms*, p. 17. [返回](#ref-zh-ch02-18)

<a id="ch02-n018-en"></a><a id="note-en-ch02-18"></a>
[18] Diana Coole, ‘The Inertia of Matter and the Generativity of Flesh’, in Coole and Frost, eds, *New Materialisms*, p. 17. [返回](#ref-en-ch02-18)

<a id="ch02-n019-zh"></a><a id="note-zh-ch02-19"></a>
[19] Dietzgen, *Excursions*, p. 301. 狄慈根若听到新唯物主义关于“人道主义与辩证思维”全都在“把心灵置于物质之上，或把文化置于自然之上”的抱怨，会感到惊讶。Iris van der Tuin and Rick Dolphijn, ‘The Transversality of New Materialism’, *Women: A Cultural Review*, vol. 21, no. 2, 2010, pp. 153–71, p. 156. [返回](#ref-zh-ch02-19)

<a id="ch02-n019-en"></a><a id="note-en-ch02-19"></a>
[19] Dietzgen, *Excursions*, p. 301. Dietzgen would have been surprised by the new materialist complaint that ‘humanism and dialecticist thought’ is all about ‘prioritising mind over matter, or culture over nature’. Iris van der Tuin and Rick Dolphijn , ‘The Transversality of New Materialism’, *Women: A Cultural Review*, vol. 21, no. 2, 2010, pp. 153–71, p. 156. [返回](#ref-en-ch02-19)

<a id="ch02-n020-zh"></a><a id="note-zh-ch02-20"></a>
[20] G. Plekhanov, *Fundamental Problems of Marxism*, ed. D. Ryazanov, London: Lawrence & Wishart, 1937, p. 13. [返回](#ref-zh-ch02-20)

<a id="ch02-n020-en"></a><a id="note-en-ch02-20"></a>
[20] G. Plekhanov, *Fundamental Problems of Marxism*, ed. D. Ryazanov, London: Lawrence & Wishart, 1937, p. 13. [返回](#ref-en-ch02-20)

<a id="ch02-n021-zh"></a><a id="note-zh-ch02-21"></a>
[21] Dietzgen, *Excursions*, p. 327. [返回](#ref-zh-ch02-21)

<a id="ch02-n021-en"></a><a id="note-en-ch02-21"></a>
[21] Dietzgen, *Excursions*, p. 327. [返回](#ref-en-ch02-21)

<a id="ch02-n022-zh"></a><a id="note-zh-ch02-22"></a>
[22] Frederick Engels, *Dialectics of Nature*, in Karl Marx and Frederick Engels, *Collected Works*, vol. 25, London: Lawrence & Wishart, 1987, p. 391. [返回](#ref-zh-ch02-22)

<a id="ch02-n022-en"></a><a id="note-en-ch02-22"></a>
[22] Frederick Engels, *Dialectics of Nature*, in Karl Marx and Frederick Engels, *Collected* *Works*, vol. 25, London: Lawrence & Wishart, 1987, p. 391. [返回](#ref-en-ch02-22)

<a id="ch02-n023-zh"></a><a id="note-zh-ch02-23"></a>
[23] 同上，第388页。 [返回](#ref-zh-ch02-23)

<a id="ch02-n023-en"></a><a id="note-en-ch02-23"></a>
[23] Ibid., p 388. [返回](#ref-en-ch02-23)

<a id="ch02-n024-zh"></a><a id="note-zh-ch02-24"></a>
[24] Gustav Kirchoff, *Vorlesungen über mathematische Physik*, Teubner, Leipzig, 1876, p. 32; 本文作者译。基尔霍夫呼应了年轻的威廉·华兹华斯：“整个自然都平静，如一只静止的轮子”。 [返回](#ref-zh-ch02-24)

<a id="ch02-n024-en"></a><a id="note-en-ch02-24"></a>
[24] Gustav Kirchoff, *Vorlesungen über mathematische Physik*, Teubner, Leipzig, 1876, p. 32; my translation. Kirchoff echoes the young William Wordsworth: ‘Calm is all nature as a resting wheel’. [返回](#ref-en-ch02-24)

<a id="ch02-n025-zh"></a><a id="note-zh-ch02-25"></a>
[25] Engels, *Dialectics of Nature*, p. 388. [返回](#ref-zh-ch02-25)

<a id="ch02-n025-en"></a><a id="note-en-ch02-25"></a>
[25] Engels, *Dialectics of Nature*, p. 388. [返回](#ref-en-ch02-25)

<a id="ch02-n026-zh"></a><a id="note-zh-ch02-26"></a>
[26] 同上，第391页。 [返回](#ref-zh-ch02-26)

<a id="ch02-n026-en"></a><a id="note-en-ch02-26"></a>
[26] Ibid., p. 391. [返回](#ref-en-ch02-26)

<a id="ch02-n027-zh"></a><a id="note-zh-ch02-27"></a>
[27] Marx, *Capital: A Critique of Political Economy, Volume 1*, trans. Ben Fowkes, Harmondsworth: Penguin, 1990, p. 527; 本文作者改译了所引英译文。德文原文是 *die widerstrebende, aber elastische menschliche Naturschranke*。Fowkes 将其整理为 ‘obstinate yet elastic barrier’（顽固却又有弹性的界限）。 [返回](#ref-zh-ch02-27)

<a id="ch02-n027-en"></a><a id="note-en-ch02-27"></a>
[27] Marx, *Capital: A Critique of Political Economy, Volume 1,* trans. Ben Fowkes, Harmondsworth: Penguin, 1990, p. 527; translation emended. The original German is *die widerstrebende, aber elastische menschliche Naturschrank*e. Fowkes tidies this up into ‘obstinate yet elastic barrier’. [返回](#ref-en-ch02-27)

<a id="ch02-n028-zh"></a><a id="note-zh-ch02-28"></a>
[28] Karl Marx, *Grundrisse: Foundations of the Critique of Political Economy (Rough Draft)*, trans. Martin Nicolaus, Harmondsworth: Penguin, 1973, p. 106. [返回](#ref-zh-ch02-28)

<a id="ch02-n028-en"></a><a id="note-en-ch02-28"></a>
[28] Karl Marx, *Grundrisse: Foundations of the Critique of Political Economy (Rough Draft)*, trans. Martin Nicolaus, Harmondsworth: Penguin, 1973, p. 106. [返回](#ref-en-ch02-28)

<a id="ch02-n029-zh"></a><a id="note-zh-ch02-29"></a>
[29] 同上，第706页。 [返回](#ref-zh-ch02-29)

<a id="ch02-n029-en"></a><a id="note-en-ch02-29"></a>
[29] Ibid., p. 706. [返回](#ref-en-ch02-29)

<a id="ch02-n030-zh"></a><a id="note-zh-ch02-30"></a>
[30] 关于马克思对工人“尘埃般”存在的描述，参见 *Grundrisse*, p. 385。关于新词“劳动折磨”，参见 Marx, *Capital, Volume 1*, p. 548；本文作者改译了所引英译文。Fowkes 把字面意为“劳动折磨”的 *Arbeitsqual* 弱化为“苦役”。 [返回](#ref-zh-ch02-30)

<a id="ch02-n030-en"></a><a id="note-en-ch02-30"></a>
[30] For Marx’s description of the ‘speck-like’ existence of the worker, see *Grundrisse*, p. 385. For the neologism ‘work-torture’, see Marx, *Capital*, *Volume 1*, p. 548; translation emended. Fowkes softens *Arbeitsqual*, literally ‘work-torture’, to ‘drudgery’. [返回](#ref-en-ch02-30)

<a id="ch02-n031-zh"></a><a id="note-zh-ch02-31"></a>
[31] Marx, *Capital, Volume 1*, pp. 310–11. [返回](#ref-zh-ch02-31)

<a id="ch02-n031-en"></a><a id="note-en-ch02-31"></a>
[31] Marx, *Capital, Volume 1*, pp. 310–11. [返回](#ref-en-ch02-31)

<a id="ch02-n032-zh"></a><a id="note-zh-ch02-32"></a>
[32] Pierre-Paul Le Mercier de la Rivière, *L’Ordre naturel et essential des sociétés politiques*, Librairie Paul Geuthner, Paris, 1910, p. 261; 本文作者译。参见马克思另一个来源文本（也是他一些最精彩的标志性尖刻攻击的对象），Antoine-Elisée Cherbuliez, *Riche ou Pauvre. Exposition succincte des causes et des effets de la distribution actuelle des richesses sociales*, Paris: Librairie d’Abel Cherbuliez, 1840, p. 32：“资本与任何其他部分财富之间没有区别：只有通过对它的使用，某物才成为*资本*。”本文作者译。 [返回](#ref-zh-ch02-32)

<a id="ch02-n032-en"></a><a id="note-en-ch02-32"></a>
[32] Pierre-Paul Le Mercier de la Rivière, *L’Ordre naturel et essential des sociétés politiques*, Librairie Paul Geuthner, Paris, 1910, p. 261; my translation. Cf. another of Marx’s source texts (and the target for some of his best signature vitriol), Antoine-Elisée Cherbuliez, *Riche ou Pauvre. Exposition succincte des causes et des effets de la distribution actuelle des* *richesses sociales*, Paris: Librairie d’Abel Cherbuliez, 1840, p. 32: ‘There is no difference between a capital and any other portion of wealth: it is only by the use that is made of it that something becomes *capital*.’ My translation. [返回](#ref-en-ch02-32)

<a id="ch02-n033-zh"></a><a id="note-zh-ch02-33"></a>
[33] “如果物质性具有能动性，那么对象就有自己的生命；它们积极地互动、抵抗并共同塑造其他实体，包括人类。” Hans Schouwenburg, ‘Back to the Future? History, Material Culture and New Materialism’, *International Journal for History, Culture and Modernity*, vol. 3, no. 1, 2015, pp. 59–72, p. 65. 究竟有谁怀疑过人类会被对象抵抗和塑造？ [返回](#ref-zh-ch02-33)

<a id="ch02-n033-en"></a><a id="note-en-ch02-33"></a>
[33] ‘If materiality is agentive, then objects have a life of their own; they actively interact with, resist and co-shape other entities, including humans.’ Hans Schouwenburg, ‘Back to the Future? History, Material Culture and New Materialism’, *International Journal* *for History, Culture and Modernity*, vol. 3, no. 1, 2015, pp. 59–72, p. 65. Who ever doubted that humans are resisted and shaped by objects? [返回](#ref-en-ch02-33)

<a id="ch02-n034-zh"></a><a id="note-zh-ch02-34"></a>
[34] 不清楚为什么 Bruno Latour 认为，理论和科学仍然紧迫的“政治任务”是“确立构成共同世界的所有实体的连续性”，也不清楚为什么他认为，只有这个“任务”完成后，“共同世界”才会出现。所有实体的连续性在《资本论》中已经以明白的逻辑术语轻易确立。诚然，那是一种坏的而非好的连续性，或者用 Latour 的另一些术语说，是一种坏而非好的“构成”，而且它没有带来一个足够共同的世界。这一失败应归咎于马克思连续性概念的缺陷，还是他未能足够好地确立连续性？ Bruno Latour, ‘An Attempt at a “Compositionist Manifesto”’, *New Literary History*, vol. 41, no. 3, Summer 2010, pp. 471–90, p. 485. [返回](#ref-zh-ch02-34)

<a id="ch02-n034-en"></a><a id="note-en-ch02-34"></a>
[34] It is not clear why Bruno Latour thinks that it remains the urgent ‘political task’ of theory and science to ‘establish the continuity of all entities that make up the common world’, or why he thinks that ‘the common world’ will not show up until that ‘task’ has been completed. The continuity of all entities was easily established, in plain logical terms, in *Capital*. Admittedly, it was a bad, not a good continuity, or, in Latour’s other terms, a bad and not a good ‘composition’, and it did not bring about a world that was common enough. Was this failure down to Marx’s faulty concept of continuity, or did he not establish the continuity well enough? Bruno Latour, ‘An Attempt at a “Compositionist Manifesto”’, *New Literary History*, vol. 41, no. 3, Summer 2010, pp. 471–90, p. 485. [返回](#ref-en-ch02-34)

<a id="ch02-n035-zh"></a><a id="note-zh-ch02-35"></a>
[35] Rosi Braidotti, ‘The Politics of “Life Itself” and New Ways of Dying’, in Coole and Frost, eds, *New Materialisms*, p. 204. [返回](#ref-zh-ch02-35)

<a id="ch02-n035-en"></a><a id="note-en-ch02-35"></a>
[35] Rosi Braidotti, ‘The Politics of “Life Itself” and New Ways of Dying’, in Coole and Frost, eds, *New Materialisms*, p. 204. [返回](#ref-en-ch02-35)

<a id="ch02-n036-zh"></a><a id="note-zh-ch02-36"></a>
[36] Coole and Frost, ‘Introducing the New Materialisms’, p. 8. [返回](#ref-zh-ch02-36)

<a id="ch02-n036-en"></a><a id="note-en-ch02-36"></a>
[36] Coole and Frost, ‘Introducing the New Materialisms’, p. 8. [返回](#ref-en-ch02-36)

<a id="ch02-n037-zh"></a><a id="note-zh-ch02-37"></a>
[37] Dietzgen, *Excursions*, p. 335. [返回](#ref-zh-ch02-37)

<a id="ch02-n037-en"></a><a id="note-en-ch02-37"></a>
[37] Dietzgen, *Excursions*, p. 335. [返回](#ref-en-ch02-37)

<a id="ch02-n038-zh"></a><a id="note-zh-ch02-38"></a>
[38] 同上，第326页。 [返回](#ref-zh-ch02-38)

<a id="ch02-n038-en"></a><a id="note-en-ch02-38"></a>
[38] Ibid., p. 326. [返回](#ref-en-ch02-38)

<a id="ch02-n039-zh"></a><a id="note-zh-ch02-39"></a>
[39] Ludwig Feuerbach, *Werke* 3, Frankfurt am Main: Suhrkamp, 1975, p. 32. “逻辑存在与智力的经验、具体感知存在处于直接的、无中介的、令人厌恶的矛盾之中。” Ludwig Feuerbach, ‘Towards a Critique of Hegel’s Philosophy’, in *The Fiery Brook: Selected Writings*, trans. Zawar Hanfi, London: Verso, 2012, p. 76. [返回](#ref-zh-ch02-39)

<a id="ch02-n039-en"></a><a id="note-en-ch02-39"></a>
[39] Ludwig Feuerbach, *Werke* 3, Frankfurt am Main: Suhrkamp, 1975, p. 32. ‘logical being is in direct, unmediated, and abhorrent contradiction with the being of the intellect’s empirical and concrete perception.’ Ludwig Feuerbach, ‘Towards a Critique of Hegel’s Philosophy’, in *The Fiery Brook: Selected Writings*, trans. Zawar Hanfi, London: Verso, 2012, p. 76. [返回](#ref-en-ch02-39)

<a id="ch02-n040-zh"></a><a id="note-zh-ch02-40"></a>
[40] 关于被压碎，参见 Alexander García Düttmann, ‘Against Self-Preservation, or can *SCUM* be Serious?’, *World Picture* 9, Summer 2014：“总之，可以说，严肃性问题——一个无疑在许多耳朵听来很隆重的问题——必须被理解为一个花环，它至少把四个不同、相互冲突又相互依赖的问题松散地系在一起，这四个问题都是针对自我保存、在自我保存的背景及其强制之下提出的。这四个问题是：‘我能做什么来避免被压碎？’；‘我判定自己生命中什么重要？’；‘我如何能既年老又年轻，年老到足以年轻？’；‘我如何——创造如何——揭示永恒？’” [返回](#ref-zh-ch02-40)

<a id="ch02-n040-en"></a><a id="note-en-ch02-40"></a>
[40] On being crushed, see Alexander García Düttmann, ‘Against Self-Preservation, or can *SCUM* be Serious?’, *World Picture* 9, Summer 2014: ‘In conclusion, it can be said that the question of seriousness, a question that no doubt sounds ceremonious to many ears, needs to be understood as a wreath that binds together, if only loosely, at least four distinct, conflicting and at the same time interdependent questions, four questions posed against self-preservation, against the background and against the imposition of self-preservation. The four questions are: “What can I do to avoid being crushed?”; “What do I judge to be important in my life?”; “How can I be old and young enough, old enough to be young enough?”; and “How can I, how can creation, disclose eternity?”’ [返回](#ref-en-ch02-40)

<a id="ch02-n041-zh"></a><a id="note-zh-ch02-41"></a>
[41] *The German Ideology*, in Karl Marx and Frederick Engels, *Collected Works*, Volume 5: *1845–1847*, London: Lawrence & Wishart, 1976, p. 79. [返回](#ref-zh-ch02-41)

<a id="ch02-n041-en"></a><a id="note-en-ch02-41"></a>
[41] *The German Ideology*, in Karl Marx and Frederick Engels, *Collected Works*, Volume 5: *1845–1847*, London: Lawrence & Wishart, 1976, p. 79. [返回](#ref-en-ch02-41)

<a id="ch02-n042-zh"></a><a id="note-zh-ch02-42"></a>
[42] Dietzgen, *Excursions*, p. 264. [返回](#ref-zh-ch02-42)

<a id="ch02-n042-en"></a><a id="note-en-ch02-42"></a>
[42] Dietzgen, *Excursions*, p. 264. [返回](#ref-en-ch02-42)

<a id="ch02-n043-zh"></a><a id="note-zh-ch02-43"></a>
[43] “真理具有实质本性，而非观念本性；它是唯物主义的；它不能仅通过思想被构想，也要通过眼睛、耳朵和手；它不是思想的产物，相反，思想是普遍生命的产物。” Dietzgen, *Excursions*, p. 313. 手指技艺高超、知识丰富的运动，因此不仅类似于概念思维（狭义地理解为使用概念进行思维），而且本质上是同一回事。狄慈根引用黑格尔：“黑格尔在其《精神现象学》序言中说：‘在科学领域中，接受时的自满与给予时的吝啬都不是美德。’”（*Excursions*, p. 329）手指的运动或感觉中，它们也不是美德。 [返回](#ref-zh-ch02-43)

<a id="ch02-n043-en"></a><a id="note-en-ch02-43"></a>
[43] ‘Truth is of a substantial nature and not of an ideal one; it is materialistic; it is not to be conceived through thoughts alone, but also through the eyes, ears and hands; it is not a product of thought, but on the contrary, the thought is a product of universal life.’ Dietzgen, *Excursions*, p. 313. Masterfully knowledgeable movement of the fingers is in this way not merely analogous to conceptual thinking (understood narrowly as thinking with the use of concepts), but is essentially the same thing. Dietzgen quotes Hegel: ‘“The contentedness in receiving and the parsimony in giving are not virtues in the domain of science,” says Hegel in the preface to his “Phenomenology of the Mind.”’ (*Excursions*, p. 329). Neither are they virtues in the movement of a fingertip, or in sensation. [返回](#ref-en-ch02-43)

<a id="ch02-n044-zh"></a><a id="note-zh-ch02-44"></a>
[44] Coole and Frost, ‘Introducing the New Materialisms’, p. 30. [返回](#ref-zh-ch02-44)

<a id="ch02-n044-en"></a><a id="note-en-ch02-44"></a>
[44] Coole and Frost, ‘Introducing the New Materialisms’, p. 30. [返回](#ref-en-ch02-44)

<a id="ch02-n045-zh"></a><a id="note-zh-ch02-45"></a>
[45] Cheah, ‘Non-Dialectical Materialism’, p. 75. [返回](#ref-zh-ch02-45)

<a id="ch02-n045-en"></a><a id="note-en-ch02-45"></a>
[45] Cheah, ‘Non-Dialectical Materialism’, p. 75. [返回](#ref-en-ch02-45)

<a id="ch02-n046-zh"></a><a id="note-zh-ch02-46"></a>
[46] 转引自同上，第77页。 [返回](#ref-zh-ch02-46)

<a id="ch02-n046-en"></a><a id="note-en-ch02-46"></a>
[46] Cited in ibid., p. 77. [返回](#ref-en-ch02-46)

<a id="ch02-n047-zh"></a><a id="note-zh-ch02-47"></a>
[47] 同上，第89页。 [返回](#ref-zh-ch02-47)

<a id="ch02-n047-en"></a><a id="note-en-ch02-47"></a>
[47] Ibid., p. 89. [返回](#ref-en-ch02-47)

<a id="ch02-n048-zh"></a><a id="note-zh-ch02-48"></a>
[48] 同上。 [返回](#ref-zh-ch02-48)

<a id="ch02-n048-en"></a><a id="note-en-ch02-48"></a>
[48] Ibid. [返回](#ref-en-ch02-48)

<a id="ch02-n049-zh"></a><a id="note-zh-ch02-49"></a>
[49] Rey Chow, ‘The Elusive Material, What the Dog Doesn’t Understand’, in Coole and Frost, eds, *New Materialisms*, p. 224. [返回](#ref-zh-ch02-49)

<a id="ch02-n049-en"></a><a id="note-en-ch02-49"></a>
[49] Rey Chow, ‘The Elusive Material, What the Dog Doesn’t Understand’, in Coole and Frost, eds, *New Materialisms*, p. 224. [返回](#ref-en-ch02-49)

<a id="ch02-n050-zh"></a><a id="note-zh-ch02-50"></a>
[50] Jane Bennett, ‘A Vitalist Stopover on the Way to a New Materialism’, in Coole and Frost, eds, *New Materialisms*, p. 48. [返回](#ref-zh-ch02-50)

<a id="ch02-n050-en"></a><a id="note-en-ch02-50"></a>
[50] Jane Bennett, ‘A Vitalist Stopover on the Way to a New Materialism’, in Coole and Frost, eds, *New Materialisms*, p. 48. [返回](#ref-en-ch02-50)

<a id="ch02-n051-zh"></a><a id="note-zh-ch02-51"></a>
[51] 同上，第60页。 [返回](#ref-zh-ch02-51)

<a id="ch02-n051-en"></a><a id="note-en-ch02-51"></a>
[51] Ibid., p. 60. [返回](#ref-en-ch02-51)

<a id="ch02-n052-zh"></a><a id="note-zh-ch02-52"></a>
[52] Slavoj Žižek 在‘Marx Reads Object-Oriented Ontology’中描述了新唯物主义为了急于阻止我们人类过高评价自己而进行的一种类似的选择性清空：“‘对象的民主’这一愿景，即所有对象占据同一本体论地位，或 Jane Bennet［原文如此］所部署的‘非人’集合体视角，只有从一个（空的）主体的立场才可能。” Slavoj Žižek, Frank Ruda and Agon Hamza, *Reading Marx*, Cambridge: Polity Press, 2018, p. 58. 我的批评与此相关但不同。一旦新唯物主义不加批判地把人道主义本体论的问题误认为“自恋”，它便焦虑地着手设计一种纠正性本体论，以回应“不要再如此自恋”的律令。 [返回](#ref-zh-ch02-52)

<a id="ch02-n052-en"></a><a id="note-en-ch02-52"></a>
[52] Slavoj Žižek, in ‘Marx Reads Object-Oriented Ontology’, describes a similar sort of elective emptying out performed by new materialism in its anxiety to prevent us humans from overvaluing ourselves: ‘the vision of “democracy of objects” where all objects occupy the same ontological standing, or the “inhuman” view of an assemblage deployed by Jane Bennet [*sic*], are only possible from the standpoint of an (empty) subject.’ Slavoj Žižek, Frank Ruda and Agon Hamza, *Reading Marx*, Cambridge: Polity Press, 2018, p. 58. My criticism is related to this one but is different. Once new materialism has uncritically misidentified the problem with humanist ontology as ‘narcissism’, it then anxiously sets about contriving a corrective ontology answerable to the imperative to stop being so narcissistic. [返回](#ref-en-ch02-52)

<a id="ch02-n053-zh"></a><a id="note-zh-ch02-53"></a>
[53] Erika Cudworth and Stephen Hobden, ‘Liberation for Straw Dogs? Old Materialism, New Materialism, and the Challenge of an Emancipatory Posthumanism’, *Globalizations*, vol. 12, no. 1, 2015, pp. 134–48, p. 138. [返回](#ref-zh-ch02-53)

<a id="ch02-n053-en"></a><a id="note-en-ch02-53"></a>
[53] Erika Cudworth and Stephen Hobden, ‘Liberation for Straw Dogs? Old Materialism, New Materialism, and the Challenge of an Emancipatory Posthumanism’, *Globalizations*, vol. 12, no. 1, 2015, pp. 134–48, p. 138. [返回](#ref-en-ch02-53)

<a id="ch02-n054-zh"></a><a id="note-zh-ch02-54"></a>
[54] Dietzgen, ‘Social-Democratic Philosophy’ (1876), in *Some of the Philosophical Essays*, p. 176. [返回](#ref-zh-ch02-54)

<a id="ch02-n054-en"></a><a id="note-en-ch02-54"></a>
[54] Dietzgen, ‘Social-Democratic Philosophy’ (1876), in *Some of the Philosophical Essays*, p. 176. [返回](#ref-en-ch02-54)

<a id="ch02-n055-zh"></a><a id="note-zh-ch02-55"></a>
[55] Braidotti, ‘A Theoretical Framework for the Critical Posthumanities’, p. 4. [返回](#ref-zh-ch02-55)

<a id="ch02-n055-en"></a><a id="note-en-ch02-55"></a>
[55] Braidotti, ‘A Theoretical Framework for the Critical Posthumanities’, p. 4. [返回](#ref-en-ch02-55)

<a id="ch02-n056-zh"></a><a id="note-zh-ch02-56"></a>
[56] 同上，第6页。 [返回](#ref-zh-ch02-56)

<a id="ch02-n056-en"></a><a id="note-en-ch02-56"></a>
[56] Ibid., p. 6. [返回](#ref-en-ch02-56)

<a id="ch02-n057-zh"></a><a id="note-zh-ch02-57"></a>
[57] Gilles Deleuze and Félix Guattari, *Anti-Oedipus: Capitalism and Schizophrenia*, trans. Robert Hurley, Mark Seem and Helen R. Lane, London: Continuum, 2012, p. 41. [返回](#ref-zh-ch02-57)

<a id="ch02-n057-en"></a><a id="note-en-ch02-57"></a>
[57] Gilles Deleuze and Félix Guattari, *Anti-Oedipus: Capitalism and Schizophrenia*, trans. Robert Hurley, Mark Seem and Helen R. Lane, London: Continuum, 2012, p. 41. [返回](#ref-en-ch02-57)

<a id="ch02-n058-zh"></a><a id="note-zh-ch02-58"></a>
[58] 同上，第132–3、62、123、61页。 [返回](#ref-zh-ch02-58)

<a id="ch02-n058-en"></a><a id="note-en-ch02-58"></a>
[58] Ibid., pp. 132–3, 62, 123, 61. [返回](#ref-en-ch02-58)

<a id="ch02-n059-zh"></a><a id="note-zh-ch02-59"></a>
[59] 同上，第322页。 [返回](#ref-zh-ch02-59)

<a id="ch02-n059-en"></a><a id="note-en-ch02-59"></a>
[59] Ibid., p. 322. [返回](#ref-en-ch02-59)

<a id="ch02-n060-zh"></a><a id="note-zh-ch02-60"></a>
[60] Gilles Deleuze, *Pure Immanence: Essays on a Life*, trans. Anne Boyman, New York: Zone, 2005, p. 69. [返回](#ref-zh-ch02-60)

<a id="ch02-n060-en"></a><a id="note-en-ch02-60"></a>
[60] Gilles Deleuze, *Pure Immanence: Essays on a Life*, trans. Anne Boyman, New York: Zone, 2005, p. 69. [返回](#ref-en-ch02-60)

<a id="ch02-n061-zh"></a><a id="note-zh-ch02-61"></a>
[61] V.I. Lenin, ‘The Lessons of the Moscow Events’, *Collected Works*, 4th English edition, Progress Publishers, Moscow, 1972, vol. 9, p. 381. [返回](#ref-zh-ch02-61)

<a id="ch02-n061-en"></a><a id="note-en-ch02-61"></a>
[61] V.I. Lenin, ‘The Lessons of the Moscow Events’, *Collected Works*, 4th English edition, Progress Publishers, Moscow, 1972, vol. 9, p. 381. [返回](#ref-en-ch02-61)

<a id="ch02-n062-zh"></a><a id="note-zh-ch02-62"></a>
[62] 参见 Grit Höppner, ‘Rethinking Socialization Research through the Lens of New Materialism’, *Hypothesis and Theory*, 13 September 2017, p. 6：“由于新唯物主义学者不把能动性中心放在一个预先具有意义和知识处理倾向的单一人类身上，他们拒绝把人设想为能动性的起源或结果，而这在以具体方式思考——主张儿童、青年或成人形式的能动性——时很常见。在新唯物主义中，能动性由异质的‘中介’协商而成。新唯物主义学者问：究竟是谁在社会化谁或什么——是轮椅使人社会化，还是人实际上使轮椅社会化？” [返回](#ref-zh-ch02-62)

<a id="ch02-n062-en"></a><a id="note-en-ch02-62"></a>
[62] Cf. Grit Höppner, ‘Rethinking Socialization Research through the Lens of New Materialism’, *Hypothesis and Theory*, 13 September 2017, p. 6: ‘Since new materialist scholars do not center agency in a single human who has a preexisting disposition in processing meaning and knowledge, they refuse to think of a human as origin or result of agency, as is common in a concrete way of thinking that argues for childish, youthful or adult forms of agency. In new materialism, agency is negotiated by heterogeneous “mediums.” New materialist scholars ask: who actually socializes whom or what – does the wheelchair socialize the person or does the person in fact socialize the wheelchair?’ [返回](#ref-en-ch02-62)

# 第二部　艺术与劳动

<a id="part2-title-zh"></a>
## **艺术与劳动**

<a id="part2-title-en"></a>
## ART & LABOUR

## 第3章　艺术的反资本主义本体论：论艺术家作为反资本主义者的历史根源

<a id="ch03-title-zh"></a>
## 艺术的反资本主义本体论：论艺术家作为反资本主义者的历史根源

<a id="ch03-title-en"></a>
## Art’s anti-capitalist ontology: on the historical roots of the artist as an anti-capitalist

<a id="ch03-author-zh"></a>
戴夫·比奇

<a id="ch03-author-en"></a>
DAVE BEECH

<a id="ch03-p001-zh"></a>
从历史上看，“艺术问题”——什么是艺术？——主要关涉对象的分类及其效果，尽管自1960年代以来，这一问题已有些转向对象经由制度程序被引导跨越艺术门槛的过程。<a id="ref-zh-ch03-1"></a>[1](#note-zh-ch03-1) 本文通过追溯艺术问题的历史，勾勒一条走出艺术对象本体论与艺术制度理论之间对立的道路；我认为，这一历史植根于围绕劳动的争论。我的观点并不是说，探究艺术定义的“真正”指涉物是艺术劳动或审美劳动（马尔库塞关于艺术作为非异化劳动的概念），<a id="ref-zh-ch03-2"></a>[2](#note-zh-ch03-2) 也不是说艺术家是决定某物是否为艺术的决定性因素（贾德的箴言）。<a id="ref-zh-ch03-3"></a>[3](#note-zh-ch03-3) 我的目标毋宁是，把艺术问题重新放回艺术、手艺、商业与工业之间对抗的历史及其遗产之中——这场对抗发生于欧洲从封建主义向资本主义过渡期间为使艺术凌驾于体力劳动之上而进行的长期斗争。

<a id="ch03-p001-en"></a>
Historically, ‘the art question’ – what is art? – has been principally concerned with the classification of objects and their effects, although since the 1960s it has been redirected somewhat towards the institutional procedures by which objects are marshalled across the threshold of art.<a id="ref-en-ch03-1"></a>[1](#note-en-ch03-1) This essay maps a route out of the opposition between an ontology of art objects and an institutional theory of art by retracing the history of the art question, which, I will argue, is rooted in disputes over labour. My point is not that the ‘real’ referent of inquiries into the definition of art is artistic or aesthetic labour (Marcuse’s concept of art as non-alienated labour),<a id="ref-en-ch03-2"></a>[2](#note-en-ch03-2) nor that the artist is the decisive factor in determining what is or is not art (Judd’s dictum).<a id="ref-en-ch03-3"></a>[3](#note-en-ch03-3) My aim, rather, is to resituate the art question within the history and legacies of the confrontation between art, handicraft, commerce and industry during the prolonged struggle in Europe to elevate art above manual labour during the transition from feudalism to capitalism.

<a id="ch03-p002-zh"></a>
耶拿浪漫派开创的对艺术本体论的探究，历史上源于从文艺复兴延续到18世纪中叶的争论：绘画、雕塑及相关艺术应如何归类、处于何种地位、具有哪些共同特征。<a id="ref-zh-ch03-4"></a>[4](#note-zh-ch03-4) 瓦萨里的*设计艺术*（*Arti del disegno*）范畴与巴托1746年的*美的艺术*（*Beaux Arts*）理论，首尾框定了一个雄心勃勃的计划：在自由艺术与机械艺术的等级制内部划出一条新的分界线，把某些特定的艺术归为一组并重新分类。其目标是使绘画和雕塑（及相关艺术）从机械艺术提升为自由艺术，但这场斗争的结果却是这些艺术被赋予一个自己的名称——*beaux arts*、美的艺术、*die bildende Kunst*、*Fri Konst* 及同源术语。<a id="ref-zh-ch03-5"></a>[5](#note-zh-ch03-5)

<a id="ch03-p002-en"></a>
The inquiry into the ontology of art which was inaugurated by the Jena Romantics arose historically out of debates about the grouping, status and common features of painting, sculpture and related arts, which ran from the Renaissance to the middle of the eighteenth century.<a id="ref-en-ch03-4"></a>[4](#note-en-ch03-4) Vasari’s category of the *Arti del disegno* and Batteux’s 1746 theory of the *Beaux Arts* bookend an ambitious project to draw a new line of demarcation within the hierarchy of the liberal and mechanical arts in which certain specified arts are grouped together and reclassified. The aim was to promote painting and sculpture (and related arts) from the mechanical to the liberal arts, but the struggle culminates instead with these arts being assigned a name of their own – the *beaux arts*, fine arts, *die bildende Kunst*, *Fri Konst* and cognate terms.<a id="ref-en-ch03-5"></a>[5](#note-en-ch03-5)

<a id="ch03-p003-zh"></a>
这一对绘画和雕塑（及相关艺术）进行历史性重新分类的插曲，不仅告诉我们艺术是什么，也告诉我们这个问题如何对我们具有意义，以及它如何可能以更令人满意的方式得到回答。我不打算去确认对象必须具有何种特征才能被归入艺术，也不打算把这一探究置换为对艺术那些受到严密巡查的边界之条件的考察，或承认能被纳入艺术范畴的东西没有界限；相反，我想通过重构艺术这一范畴如何经由偶然的社会过程而形成，来重新思考它的不确定性。

<a id="ch03-p003-en"></a>
This episode in the historical reclassification of painting and sculpture (and related arts) has something to tell us not only about what art is but also about how this question comes to have a meaning for us, and how it might be answered in a more satisfactory way. In place of identifying the features that objects must have in order to be categorized as art, or displacing that inquiry to investigate the conditions of art’s heavily policed borders, or acknowledging that there is no limit to what can be included in the category of art, I want to reconsider the indeterminacy of art as a category by reconstructing how it was formed through contingent social processes.

<a id="ch03-p004-zh"></a>
尽管为绘画和雕塑（及相关艺术）提出的历史主张最终以所谓的对象属性——以及对这些对象的体验——得到表达，它们最初却被归属于各种劳动类型。艺术作品的显性品质最初被理解为特定劳动形式的结果；也就是说，是在每一门特定艺术内部生产一系列作品所需的心智能力与手工能力的具体结合。<a id="ref-zh-ch03-6"></a>[6](#note-zh-ch03-6) 我的论证重新强调劳动的重要性，但并不主张艺术是某种劳动的结果；我想把围绕艺术形成并不断重构的那个充满争议、不断移动的边界，描述为围绕劳动的各种斗争的高度编码化表征。我的意图是，把关于各类对象相对价值及其隐含本体论的问题，重新连接到一部关于与之相应的活动类型之差别的、挥之不去却大多未被承认的历史，从而澄清如下问题：艺术一方与手艺、制造业、商业和工业另一方之间是什么关系。<a id="ref-zh-ch03-7"></a>[7](#note-zh-ch03-7)

<a id="ch03-p004-en"></a>
While the historical claims made for painting and sculpture (and related arts) ultimately came to be expressed in the alleged properties of objects – and the experience of them – they were initially assigned to types of labour. The ostensive qualities of works of art were initially understood as the result of specific forms of labour; that is to say, the concrete combination of mental and manual capacities needed to produce a range of products within each specific art.<a id="ref-en-ch03-6"></a>[6](#note-en-ch03-6) My argument re-emphasizes the significance of labour, but instead of claiming that art is the result of a certain kind of labour I want to characterize the contested and shifting boundary that is formed and reformed around art as a highly codified representation of struggles over labour. My intention is to clarify questions about the relationship between art, on the one hand, and handicraft, manufacturing, commerce and industry, on the other, by reconnecting questions about the relative merits and implied ontologies of various categories of object to a lingering but largely unacknowledged history of the differentiation of types of activity appropriate to them.<a id="ref-en-ch03-7"></a>[7](#note-en-ch03-7)

<a id="ch03-s01-zh"></a>
## **艺术与市场**

<a id="ch03-s01-en"></a>
## **Art and the marketplace**

<a id="ch03-p005-zh"></a>
从艺术话语中不时爆发的恐慌来看，艺术不是一种特定类型的对象，而是特定类型经济的效果。对某些艺术史家、批评家和艺术家来说，艺术的存在似乎永远受到威胁：一接触完全为商业利润而生产的文化，或者更严重地，一旦降入其中，艺术便遭威胁。充当这个反面角色的，可以是平面设计，也可以是文化产业、媚俗艺术或商品生产，以及任何数量的其他样本，但逻辑始终如一：艺术不是*x*也不是*y*，因此当艺术变得（更像）*x*或*y*时，它就遭到稀释或否定。T.J.克拉克在2000年的一次讲话中，带着某种紧迫感讲述了这则熟悉的故事：

<a id="ch03-p005-en"></a>
To judge from the panic which erupts in the discourses of art every now and then, art is not a specific kind of object but the effect of a specific kind of economy. For certain art historians, critics and artists it seems the existence of art is perpetually threatened by its contact with, or – more seriously – its descent into, culture produced entirely for commercial gain. The stooge can be graphics or the culture industry or kitsch or commodity production, and any number of other specimens, but the logic remains: art is not *x* or *y* and therefore art is diluted or negated by becoming (more like) *x* or *y*. T.J. Clark, speaking in 2000, tells this familiar tale with some urgency:

<a id="ch03-q001-zh"></a>
> 视觉艺术难道不是正在简单而不可逆转地成为图像生活生产装置的一部分吗？例如，视觉艺术与时尚产业之间的那条分界线已不复存在；这个备受注意的事实——翻一翻*Artforum*或*Parkett*的页面便会无情而单调地证实它——其真正含义难道不正是如此吗？它不仅不存在，艺术还以其不存在为荣。这种不存在正是艺术当前的重要主题之一……现代主义始终与它所赖以为生的表象领域保持着紧密而危险的邻近关系。<a id="ref-zh-ch03-8"></a>[8](#note-zh-ch03-8)

<a id="ch03-q001-en"></a>
> Is not visual art in the process of becoming simply and irrevocably  part of the apparatus of image life production? Is not this the real  sense of the much-noticed fact (a flip through the pages of *Artforum*  or *Parkett* confirms the fact, relentlessly, monotonously) that the  one demarcation between visual art and the fashion industry, for  example, simply does not exist any longer? Not only does it not exist  but art glories in its non-existence. The non-existence is one of art’s  great present themes… Modernism always stood in close, dangerous  proximity to the realm of appearances it fed on.<a id="ref-en-ch03-8"></a>[8](#note-en-ch03-8)

<a id="ch03-p006-zh"></a>
克拉克理解在艺术与流行文化那些令人不适的接触点上开展工作的批判要求，但在此例中，在他看来，对艺术与商业文化之区分的政治化颠覆已经走得太远。<a id="ref-zh-ch03-9"></a>[9](#note-zh-ch03-9) 在这里，把艺术作为一种实践加以界分的意识形态划界，并非完全独立于其物质与经济条件。在我的分析中，我将尤其强调艺术作品特定生产方式的历史建构，包括那种赋予艺术家以特权位置的特殊社会分工。因此，按我的解读，克拉克对艺术邻近时尚产业的焦虑，是艺术与设计之间界线被彻底侵蚀的一个例子，也就是说，艺术变得只不过是一种商业活动；他之所以以时尚作为商业文化的例证，正是要突出这一点。他对艺术与商业之区分崩塌的分析，主要落在艺术作品本身，以及一代艺术家的意志涣散之上——他们不再忠实于审美劳动的现代主义罗曼司，不再坚持先锋派与媚俗艺术之间那种精英主义式的对立，也不再具备在否定实践中批判性地运用流行形式所必需的形式细察。<a id="ref-zh-ch03-10"></a>[10](#note-zh-ch03-10) 然而，这一分析所倚赖的，是对艺术与市场之间一种隐含对抗关系的敏锐感受。

<a id="ch03-p006-en"></a>
Clark understands the critical demands of operating at the uncomfortable points of contact between art and popular culture, but in this instance the politically charged subversion of the distinction of art from commercial culture appears to him to have gone too far.<a id="ref-en-ch03-9"></a>[9](#note-en-ch03-9) Here, the ideological demarcation of art as a practice is not completely independent from its material and economic conditions. In my analysis, emphasis will be placed in particular on the historical construction of a specific mode of production for artworks, including the specific social division of labour in which the artist is assigned a place of privilege. So, Clark’s anxieties about art’s proximity to the fashion industry, on my reading, is an instance of the complete erosion of the divide between art and design, that is to say of art becoming nothing but a commercial activity, which he highlights by taking fashion as the exemplification of commercial culture. His analysis of the collapse of the distinction between art and commerce falls mainly on artworks themselves and the failure of nerve of a generation of artists who no longer demonstrate fidelity to the modernist romance of aesthetic labour, or the elitist opposition of avant-garde and kitsch, or the formal scrutiny required for the critical deployment of popular forms within practices of negation.<a id="ref-en-ch03-10"></a>[10](#note-en-ch03-10) What it rests on, though, is a keen sense of an implied antagonism between art and the marketplace.

<a id="ch03-p007-zh"></a>
我不想把这个具体例子说得过重。克拉克有他自己版本的这一叙事，即艺术受到商业化威胁，但这种思维模式很常见。安德烈亚·弗雷泽在2004年回顾她创作的一件作品时，把同一种对立用于某些不同的目的；那件作品的内容是与一位收藏家发生性关系：

<a id="ch03-p007-en"></a>
I do not want to overstate the specific case. Clark has his own variant of this narrative of art’s threat from commercialization, but the pattern of thought is common. Andrea Fraser, reflecting in 2004 on a work that she produced which consisted of having sex with a collector, puts the same opposition to work for somewhat different ends:

<a id="ch03-q002-zh"></a>
> 嗯，是的，那是艺术；我有兴趣提出的问题是，艺术是否就是卖淫——当然，是在隐喻意义上。我碰巧和一个人发生性关系，难道就比我只是卖给他一件作品更像卖淫吗？事实上，对于出售《无题》的DVD，我至今仍远比我制作这件作品时更不舒服。艺术界那种“正常”的销售情境，在我看来，比我与参与收藏者的关系或交换的任何方面都更具剥削性。那才是我失去控制的地方。投机就是从那里开始的。<a id="ref-zh-ch03-11"></a>[11](#note-zh-ch03-11)

<a id="ch03-q002-en"></a>
> Well, yes, it’s art, and the question I’m interested in posing is  whether art is prostitution – in a metaphorical sense, of course. Is  it any more prostitution because I happen to be having sex with a  man than it would be if I were just selling him a piece? In fact, I  remain much less comfortable with selling the DVDs of ‘Untitled’  than I was with producing the piece. The ‘normal’ sales situation  that one has in the art world feels much more exploitative to me  than any aspect of my relationship with, or the exchange with the  participating collector. That’s where I lose control of it. That’s where  the speculation begins.<a id="ref-en-ch03-11"></a>[11](#note-en-ch03-11)

<a id="ch03-p008-zh"></a>
在这一情形中，艺术品的出售对艺术家而言代表一场同时是道德与经济的危机（使艺术家既感到不适又遭到剥削）。这些话语套路或许把对艺术品销售的焦虑，与异化劳动概念以及致力于废除异化劳动的行动主义传统联系起来。但我想考察这里一个更为具体的预设：艺术与商业严重对立。如果说克拉克只是通过联想暗示艺术受到市场的危害，那么在弗雷泽这里，艺术与商业之间的对抗就像这一观念最初被提出时一样明确。在康德表述美的艺术的双重自由时，艺术与销售相对抗的观念已牢固确立。他说，这些特定艺术必须在没有外在目的的意义上是自由的，而且还要“在这样一种意义上是自由的：它们不是一种雇佣职业，因而也不是一种其大小可按确定标准来评判、索取或支付的劳动”。<a id="ref-zh-ch03-12"></a>[12](#note-zh-ch03-12)

<a id="ch03-p008-en"></a>
The sale of art, in this scenario, represents a crisis for the artist that is at once moral and economic (subjecting the artist to both discomfort and exploitation). These tropes, perhaps, link anxieties about art sales to the concept of alienated labour and the activist tradition intent on abolishing it. But I want to investigate the more specific assumption, here, that art and commerce are seriously at odds. If Clark only implied by association that art is endangered by the marketplace, in Fraser the antagonism between art and commerce is as explicit as when this idea was first formulated. The conception of art as antagonistic to sales is firmly established by the time of Kant’s formulation of the twofold freedom of the fine arts. These specific arts, he said, must be free in the sense that they have no extrinsic purpose, but also ‘free in the sense of not being a mercenary occupation and hence a kind of labor, whose magnitude can be judged, exacted, or paid for according to a determinate standard’.<a id="ref-en-ch03-12"></a>[12](#note-en-ch03-12)

<a id="ch03-p009-zh"></a>
艺术与商业对抗的历史，是艺术得以凌驾于手艺及其他商业活动之上的一个组成部分。

<a id="ch03-p009-en"></a>
The history of art’s antagonism to commerce is a component of art’s elevation above handicraft and other commercial activities.

<a id="ch03-p010-zh"></a>
当前，艺术机构内部的政治行动主义已从对机构的意识形态批判，转向要求机构向艺术家和艺术工作者（实习生、工作室助手等）支付报酬。<a id="ref-zh-ch03-13"></a>[13](#note-zh-ch03-13) 我对艺术与资本主义对抗史的研究，是对艺术中各种“资本主义现实主义”<a id="ref-zh-ch03-14"></a>[14](#note-zh-ch03-14) 的反驳；这类立场宣称艺术作品是商品、艺术家是工人，而艺术家与商业相对抗的神话助长了把艺术家当作无酬劳动者加以剥削。我的目的不是支持对设计、工艺与媚俗艺术的谴责以警示艺术家，而是考察艺术内部反资本主义的历史。

<a id="ch03-p010-en"></a>
Currently, political activism within art’s institutions has shifted from the ideological critique of institutions to the demand for artists and art workers (interns, studio assistants and others) to be paid by them.<a id="ref-en-ch03-13"></a>[13](#note-en-ch03-13) My inquiry into the history of the antagonism between art and capitalism is a rebuttal to forms of ‘capitalist realism’<a id="ref-en-ch03-14"></a>[14](#note-en-ch03-14) in art that declare artworks are commodities, artists are workers, and the myth of the artist as antagonistic to commerce contributes to the exploitation of artists as unpaid labourers. My purpose is not to endorse the condemnation of design, craft and kitsch as a warning to artists but to investigate the history of anti-capitalism within art.

<a id="ch03-p011-zh"></a>
艺术与商业或销售相对抗这一观念的历史根源何在？在某种意义上可以说，对买卖之腐化的忧虑并不限于艺术领域，而是以这种或那种形式贯穿历史。然而，我心中所想的起源，并不能通过找出这一观念的最初表述而发掘出来。艺术与市场之间的结构性对抗，也不是在文艺复兴时期的个别画家和雕塑家在行会与宫廷这一封建艺术组织内部争取到某些特权时实现的。我们需要解开艺术中对商业的特定拒斥与更为悠久的贵族业余爱好者传统之间的关系；而二者之间相互借用、替换与转化的历史使这项任务变得困难。

<a id="ch03-p011-en"></a>
What is the historical source of the idea that art is antagonistic to commerce or sales? In some sense, we might say, concerns about the corruptions of buying and selling are not limited to the field of art and are present in one form or another throughout history. However, the origin I have in mind is not unearthed by identifying the first formulation of the idea. Nor is the structural antagonism between art and the marketplace realized when individual painters and sculptors in the Renaissance manage to secure certain privileges within the feudal organization of the arts in the guilds and court. We need to unpick the relationship between the specific rejection of commerce in art and the longer tradition of the noble amateur, a task that is hampered by the history of borrowing, substitution and transformation between the two.

<a id="ch03-p012-zh"></a>
由于业余性对贵族而言是一种规范，并在资产阶级革命后以改变过的形式存留下来，按照拒斥商业的原则对艺术进行改造究竟发生于何时，便难以确切指明，尤其是如果我们把视野局限于观念史。然而，如果我们把注意力集中于艺术不断变化的生产方式，这项考察就能获得一些清晰性。这等于把哲学中的艺术问题，以及艺术话语中艺术与商业的规范性分离，都锚定到对封建主义向资本主义过渡的研究之中——但有一项限定：在这一历史过渡中，艺术并未采用标准的资本主义生产方式，因为后者主要由资本与雇佣劳动之间的对抗构成，而这种对抗在艺术作品的生产中几乎完全缺席。<a id="ref-zh-ch03-15"></a>[15](#note-zh-ch03-15) 在封建主义向资本主义过渡的时期，行会制度内部曾占主导的工作社会关系遭到工资制度的对抗，并最终被其吞没。然而，画家和雕塑家并未像手工业者通常那样，从行会成员转变为雇佣劳动者或资本主义雇主。相反，对行会的拒斥走上了一条不同的道路。

<a id="ch03-p012-en"></a>
Since amateurism is a norm for the nobility, and this survives in modified forms after the bourgeois revolutions, the reformation of art according to the principle of the rejection of commerce is difficult to pinpoint, especially if we restrict our view to a history of ideas. Some clarity is brought to this investigation, however, if we focus our attention on the changing mode of production of art. This amounts to indexing the art question in philosophy and the normative separation of art from commerce in art’s discourses to the study of the transition from feudalism to capitalism – with the proviso that this historical passage does not see art adopt a standard capitalist mode of production, since the latter consists principally of a confrontation between capital and wage-labour that is almost entirely absent in the production of artworks.<a id="ref-en-ch03-15"></a>[15](#note-en-ch03-15) During the period of transition from feudalism to capitalism the social relations of work which had prevailed within the guild system were opposed and ultimately overrun by the wage system. However, painters and sculptors were not converted from members of the guild to either wage labourers or capitalist employers, as artisans typically were. Instead, the rejection of the guilds took a different turn.

<a id="ch03-s02-zh"></a>
## **通往艺术市场的漫长道路**

<a id="ch03-s02-en"></a>
## **The long road to the art market**

<a id="ch03-p013-zh"></a>
一个区别于手工业者的艺术家概念的出现，是那场充满争议的转变的关键要素：绘画和雕塑（及相关艺术）先从机械艺术被重新归入美的艺术，随后又从若干特定艺术转变为一般意义上的艺术。史蒂夫·爱德华兹在论述摄影历史上如何与艺术相区别、以及在摄影内部文献如何与图像相区别时，回顾了这段历程。

<a id="ch03-p013-en"></a>
The emergence of a concept of the artist distinct from the artisan is a vital ingredient of the contested transition from the classification of painting and sculpture (and related arts) from the mechanical arts to the fine arts and, subsequently, from the several specific arts to art in general. Steve Edwards recalls this passage in his account of how photography has historically been distinguished from art and how, within photography, the document has been distinguished from the picture.

<a id="ch03-q003-zh"></a>
<a id="ch03-q004-zh"></a>
> 这些对立大多植根于“自由”艺术与“机械”艺术之间的区分……［并］植根于一场旷日持久的斗争，即为提升……画家的地位而进行的斗争，他们力图把自己同车轮匠、制桶匠以及其他常常被归入同一类别的人区分开来。为了做到这一点，他们坚持认为，他们的工作是一门自由艺术，而不是低贱的手工艺（或机械）行业。<a id="ref-zh-ch03-16"></a>[16](#note-zh-ch03-16)

<a id="ch03-q003-en"></a>
<a id="ch03-q004-en"></a>
> Most of these oppositions have their roots in the distinction  between the ‘liberal’ and the ‘mechanical arts’ … [and] in a  protracted struggle to raise the status of … painters [who] sought  to distinguish themselves from wheelwrights, barrel-makers, and  others with whom they were frequently classed. To do this they insisted that their work was a liberal art and not a lowly artisanal (or  mechanical) trade.<a id="ref-en-ch03-16"></a>[16](#note-en-ch03-16)

<a id="ch03-p014-zh"></a>
艺术问题围绕艺术与手艺之间的关系转动，这种关系不仅把自由艺术置于机械艺术之上，也把业余活动的贵族价值置于商业之上。爱德华兹指出，“艺术家争取地位的长期斗争中，一个决定性的转折点出现在1648年巴黎皇家绘画与雕塑学院建立之时”。<a id="ref-zh-ch03-17"></a>[17](#note-zh-ch03-17) 那么，让我们看看这一事件在艺术经济与规范转型的历史中是如何被理解的。

<a id="ch03-p014-en"></a>
The art question pivots around a relationship between art and handicraft that prioritizes not only the liberal arts over the mechanical arts but also the noble value of amateurism over trade. Edwards notes that a ‘decisive turning point in artists’ protracted struggle over status occurred with the establishment of the Académie Royale de Peinture et de Sculpture in Paris in 1648’.<a id="ref-en-ch03-17"></a>[17](#note-en-ch03-17) So, let’s look at how this event has been understood in the history of art’s economic and normative transformation.

<a id="ch03-p015-zh"></a>
辛西娅·怀特与哈里森·怀特在他们那本颇有影响的著作中，论述了艺术的现代制度如何经由皇家学院的建立，从“中世纪画家行会”中产生。他们写道，画家们“在行会限制下愤懑不安”，而皇家学院“起初只是独立于行会，但很快便在权力与声望上支配行会，随后取代了行会”，此后才出现“批评家—画商体系”。<a id="ref-zh-ch03-18"></a>[18](#note-zh-ch03-18) 这一高度压缩的叙述在许多方面仍是一份有用的路线图，但叙事的每个部分都需要依据生产关系视角重新审视。例如，行会→学院→艺术市场这一更替叙事，为共时性的戏剧效果牺牲了历时性的细微差别。我们可以部分克服这一点：承认自14世纪起，各种画家与雕塑家学院就与行会并行存在，而皇家学院与行会并行运行了近150年，直到两者都被革命政府废除。<a id="ref-zh-ch03-19"></a>[19](#note-zh-ch03-19)

<a id="ch03-p015-en"></a>
Cynthia and Harrison White, in their influential book on the emergence of art’s modern institutions out of the ‘medieval painters’ guilds’ via the founding of the Académie Royale, write that painters ‘chafed under guild restrictions’ and that the Académie Royale ‘was at first merely independent of the guild, but soon dominated and then replaced it in power and prestige’ before the advent of the ‘critic–dealer system’.<a id="ref-en-ch03-18"></a>[18](#note-en-ch03-18) This compacted account remains, in many respects, a useful road map, but each section of the narrative needs to be reconsidered according to the perspective of the social relations of production. For instance, the narrative of succession – guild to academy to art market – sacrifices diachronic nuance for synchronic drama. We can overcome this, partly, by acknowledging that various academies for painters and sculptors existed in parallel with the guilds from the fourteenth century onwards and that the Académie Royale ran parallel with the guilds for almost 150 years before they were both abolished by the revolutionary government.<a id="ref-en-ch03-19"></a>[19](#note-en-ch03-19)

<a id="ch03-p016-zh"></a>
的确，这些学院从行会与宫廷的双重体系中生长出来，以巩固画家和雕塑家在宫廷中的地位；17世纪建立的皇家学院则将宫廷画家和雕塑家的特权正式化并加以扩展。文艺复兴时期的学院并不是教学机构，但佛罗伦萨设计学院的章程规定，每年选出三名学院成员，前往年轻从业者的工坊拜访，给予友好建议。工坊活动不仅与学院并行进行，而且是学院运作所必需的。然而，讲座从一开始就是学院的常规项目，最初是作为手段，在封建主义设定的条件下把某些艺术——特别是绘画和雕塑——从机械艺术提升为自由艺术；但后来，我认为，它也成为一种方法，用以在社会分工中把艺术家同雇佣劳动者、手工业者、制造商、店主和产业资本家区分开来。

<a id="ch03-p016-en"></a>
Indeed, the academies grew out of the dual system of guild and court to bolster the position of painters and sculptors in the court, and the royal academy established in the seventeenth century formalized and extended the privileges of court painters and sculptors. The Renaissance academy was not a teaching institution, but the statutes of the Florence Academy of Design specify that three members of the academy would be selected annually to visit young practitioners in their workshops to give friendly advice. Workshop activities not only went on in parallel with the academies but were necessary for its functioning. However, from the outset, lectures were a regular feature of the academies, initially as a device to raise the status of certain arts – specifically painting and sculpture – from the mechanical arts to the liberal arts on terms set by feudalism, but also later, I would argue, as a method to differentiate the artist within the social division of labour from the wage-labourer, artisan, manufacturer, shopkeeper and industrial capitalist.

<a id="ch03-p017-zh"></a>
怀特夫妇把画家在三种历史模式——行会、学院与市场——中的演进，设定为一部从封建束缚中解放出来的线性故事中的一个插曲。这种现代主义叙事遵循一条经济史学家熟悉的路径，即自由主义关于自由放任兴起、对抗看似过时的封建管制与干预形式的叙事。通过美的艺术倡导者如何竭力把行会手工业者指认为机械的复制者，并以此对照院士们受灵感启发、具有原创性、富有学识的活动，来重读这一叙事，颇能说明问题。克里斯蒂安·米歇尔指出，现代主义对学院的批判“与学院当初对行会的批判极为相似”。<a id="ref-zh-ch03-20"></a>[20](#note-zh-ch03-20) 我们可以看到，两者都强调对手在机械与手工方面的局限。因此，当怀特夫妇说学院“强调一种新的艺术家概念：他不再是手工业者，也不是兜售货物的低等小贩，而是一个有学问的人，是美与趣味之高尚原则的教师”时，我们也得以瞥见，现代主义把学院拒斥为死记硬背、教条僵化与中央集权的官僚机构之地，其中包含着怎样的利害关系。<a id="ref-zh-ch03-21"></a>[21](#note-zh-ch03-21)

<a id="ch03-p017-en"></a>
White and White’s procession of painters in three historical modes – guild, academy and market – is set up as an episode in a linear tale of emancipation from feudal constraints. This modernist narrative follows a path familiar to historians of economics, namely the liberal tale of the rise of laissez-faire against seemingly obsolete forms of feudal regulation and intervention. It is instructive to reread this narrative through the extraordinary efforts of the advocates of the fine arts to designate guild artisans as mechanical copyists in contrast with the inspired, original and scholarly activities of the academicians. Christian Michel points out that the modernist critique of the academy ‘strongly resembled the critiques levelled by the Académie against the guild’.<a id="ref-en-ch03-20"></a>[20](#note-en-ch03-20) Both, we can observe, stressed the mechanical and manual limitations of its opponent. So, when White and White say the academy ‘emphasized a new conception of the artist: no longer an artisan or a low-caste hawker of wares, he was instead a learned man, a teacher of the high principles of beauty and taste’, we get a glimpse, also, at what was at stake in the modernist rejection of the academy as a place of rote learning, doctrinal stiffness and centralized bureaucracy.<a id="ref-en-ch03-21"></a>[21](#note-en-ch03-21)

<a id="ch03-p018-zh"></a>
怀特夫妇等人主张，艺术作为从赞助制向艺术市场过渡的结果，从诸艺术中浮现出来。这一论证的优点是指向结构性经济变化，缺点是聚焦流通变化而非艺术的生产方式：它阻碍了对以下变化进行分析：艺术家工作室及其供应链的社会关系，艺术家与其助手之间的分工，艺术家、画商与艺术导师之间的分工，等等。尽管中世纪和文艺复兴时期的画家与雕塑家在手工业工坊中集体工作这一事实并非无人注意，艺术史家还是倾向于把注意力集中在某些典范性的个人身上，常常夸大这些人在多大程度上独立于手工业工坊体系运作，以及在多大程度上拒绝使用助手和学徒。

<a id="ch03-p018-en"></a>
White and White and others argue that art emerges from the arts as a result of the transition from patronage to the art market. This argument has the advantage of pointing towards structural economic changes but the disadvantage of focusing on changes in circulation rather than art’s mode of production: it blocks the analysis of changes in the social relations of the artist’s studio and its supply chains, the division of labour between artists and their assistants, the division of labour between the artist, the art dealer and the art tutor, and so forth. While it has certainly not gone unnoticed that painters and sculptors in the Middle Ages and the Renaissance worked collectively in artisan workshops, art historians have tended to focus their attention on certain exemplary individuals and often exaggerated the degree to which they operated outside the artisan workshop system, and abjured the use of assistants and apprentices.

<a id="ch03-p019-zh"></a>
艺术与手艺之间的边界，是作为行会与学院之间的区分而锻造出来的，二者都是男性专有的领域；但到18世纪末，这条分界线获得了一种明确带性别色彩的性质。乔舒亚·雷诺兹爵士曾由他的姐姐——一位有造诣的水彩画家——教习绘画，他带头禁止水彩画参加年度夏季展览；用头发制成的画、剪纸以及其他兼有浓重手工艺和女性气质气息的图像，也一并被排除。相比之下，承认行会师傅对学徒、日工及更广义的家庭的依赖，比认清在工作室里为某位艺术家的艺术生产作出贡献的全体工人，要容易得多。这种误认内建于学院体系之中。<a id="ref-zh-ch03-22"></a>[22](#note-zh-ch03-22)

<a id="ch03-p019-en"></a>
The border between art and handicraft is forged as a differentiation between the guild and the academy, both exclusively male provinces, but by the end of the eighteenth century the dividing line takes on an emphatically gendered quality. Sir Joshua Reynolds, who had been taught to paint by his sister, an accomplished watercolourist, led the charge to disallow watercolour paintings from the annual summer exhibition, alongside pictures made of hair, paper cut-outs and other images with a strong whiff both of craft and of femininity. By comparison, it is easier to acknowledge the guild master’s dependence on apprentices, day-labourers and their household more generally than it is to recognize the full cast of workers who contribute to the production of art by an individual artist in a studio. This misrecognition was built into the academy system.<a id="ref-en-ch03-22"></a>[22](#note-en-ch03-22)

<a id="ch03-p020-zh"></a>
学院并非自给自足的机构。例如，皇家学院在很大程度上似乎是从行会中吸纳最优秀的画家和雕塑家。学院并不教授任何技术意义上的绘画或雕塑，而是仅接纳能够通过提交一件“入选作品”证明其在某一门美的艺术中具备娴熟能力的候选人。“在执笔和培养良好眼力方面当过学徒——先临摹素描和版画，再对立体形态写生——是进入皇家学院的条件，但学院本身并不教授素描。”<a id="ref-zh-ch03-23"></a>[23](#note-zh-ch03-23) 因此，皇家学院仍依赖某种正式或非正式的学徒训练，作为其学生教育的预备阶段。

<a id="ch03-p020-en"></a>
The academy was not a self-sufficient body. For instance, the Académie Royale appeared for the most part to draw the best of the painters and sculptors from the guild. Academies did not teach painting or sculpture in any technical sense but restricted admission to candidates who could demonstrate facility in one of the fine arts through the presentation of a ‘reception piece’. ‘An apprenticeship in handling a pencil and acquiring a good eye, first by copying drawings and engravings and then by drawing from three-dimensional forms, was a condition of admission to the Académie, but drawing was not taught there.’<a id="ref-en-ch03-23"></a>[23](#note-en-ch03-23) As such, the Académie continued to rely on a type of formal or informal apprenticeship as a preliminary stage of education for its students.

<a id="ch03-p021-zh"></a>
关于从手工业者到艺术家的转变的叙述，从两个个体生产者的狭隘视角来看待艺术生产社会关系的历史转型。实际上，这一转变由先前在工坊内进行的大量任务在地理上的分散构成。合作工坊中的每一个手工业者都能胜任若干后来成为专门职业的工作：熟练工人、工具制造者、材料供应者、设计者、教师和商人。因此，手工业者并非只转变为艺术家，也转变为所有其他这些专门职业。于是，从手工业者到艺术家的转变，伴随着从手工业者到材料供应商、从手工业者到技术员或助手、从手工业者到教师或画商等等的转变。也就是说，工坊内部的分工被转化为以市场交换为中介的整个社会中的社会分工。<a id="ref-zh-ch03-24"></a>[24](#note-zh-ch03-24)

<a id="ch03-p021-en"></a>
Accounts of the passage from the artisan to the artist view the historical transformation of the social relations of artistic production from the narrow perspective of two individual producers. Actually, this transition consists of the geographical dispersal of numerous tasks previously conducted within the workshop. Each single artisan within the cooperative workshop was capable of several jobs that would later become specialisms, namely skilled worker, manufacturer of tools, supplier of materials, designer, teacher and dealer. Hence, the artisan does not exclusively turn into the artist but also into all these other specialisms. The passage from the artisan to the artist is accompanied therefore by the passage from the artisan to the materials supplier, from the artisan to the technician or assistant, from the artisan to the teacher or dealer, and so on. That is to say, the division of labour within the workshop is converted into a social division of labour in society as a whole mediated by market exchange.<a id="ref-en-ch03-24"></a>[24](#note-en-ch03-24)

<a id="ch03-p022-zh"></a>
让我们暂时聚焦于封建主义向资本主义过渡期间艺术劳动重组在空间上的方面：我们必须考虑的不仅是艺术劳动发生的空间，即从手工业工坊到艺术家工作室的转变，更根本地，是从行会工坊内部一系列活动的整合，向这些活动在空间上分散的转变——它们后来发生在工作室、画廊、艺术学校、博物馆、代工工坊之内及彼此之间，也发生在为艺术的生产与流通提供工具、机械和材料的所有供应链之中。从商业性的手工业者那里购买供应品，以及伴随这场从工坊出走而发展起来的其他一切专门职业，把技术分工转化为社会分工。商业供应商削弱了学徒为“师傅”完成这项工作的需要，因而巩固了绘画和雕塑的学院教育体系；该体系由艺术家与艺术教师之间的社会分工构成，从而把工作室与艺术学校分离开来。

<a id="ch03-p022-en"></a>
Focusing for a moment on the spatial aspect of the reorganization of artistic labour during the transition from feudalism to capitalism, we must consider not only the spaces in which artistic labour takes place, as a passage from the artisanal workshop to the artist’s studio, but more fundamentally as the transition from the integration of a range of activities within the guild workshop to the spatial dispersal of activities that come to take place within and between the studio, gallery, art school, museum, fabricators’ workshop and all the supply chains that provide their tools, machinery and materials for the production and circulation of art. The purchasing of supplies from commercial artisans, and all the other specialisms that developed out of this exodus from the workshop, converted the technical division of labour into a social division of labour. Commercial suppliers diminished the need for apprentices to complete this work for the ‘master’ and therefore consolidated the academic system of education for painting and sculpture, which consists of a social division of labour between the artist and the art teacher, thereby separating the studio from the art school.

<a id="ch03-p023-zh"></a>
在资本主义门槛处，艺术劳动的社会分工凭借艺术作品生产者与其收藏者之间专门中介者的创新，重新界定了有别于手工业者的艺术家。今天，我们把画商或画廊主设想为一种代理人，把艺术家引入艺术市场的方向；但从历史上看，艺术作品专业销售者的引入，把销售任务从生产者自己手中拿走，因而在艺术家与直接面对付费顾客之间充当了一种缓冲。宫廷赞助的惯例长期以来掩盖了赞助人与画家之间的经济交易，但在工坊里卖画的行会画家别无选择，只能把产品卖给市场。学院体系的创立者抓住了这些区分。

<a id="ch03-p023-en"></a>
The social division of artistic labour at the threshold of capitalism redefined the artist as distinct from the artisan by the innovation of specialist mediators between the producers of artworks and their collectors. Today, we think of the art dealer or gallerist as an agent who funnels the artist in the direction of the art market, but historically the introduction of the specialist seller of works of art took the task of sales away from the producers themselves and acted, therefore, as a kind of buffer between the artist and the direct encounter with paying customers. Conventions of courtly patronage had long suppressed the economic transaction between patrons and painters, but guild painters selling paintings from their workshop had no choice but to sell their products to the market. These distinctions were seized on by the founders of the academy system.

<a id="ch03-s03-zh"></a>
## **商业禁令**

<a id="ch03-s03-en"></a>
## **The ban on commerce**

<a id="ch03-p024-zh"></a>
学院把自己与行会区分开来，确保其成员区别于手工业者，并主张其学生区别于学徒；这重新塑造了画家和雕塑家，使他们成为学识的产物而非手艺的产物。整个计划的症候，是1648年（并在1777年再次出现）的一个插曲：皇家学院颁布章程，宣布那些“希望开店经营他人之手的绘画、素描和雕塑，出售颜料、金箔及其他绘画和雕塑艺术辅料者……必须申请加入画家—雕塑家共同体［行会］”。<a id="ref-zh-ch03-25"></a>[25](#note-zh-ch03-25) 这一章程不是艺术与商业相对抗这一观念的终极来源，但它对于该观念在维护它的新社会制度内部得到巩固至关重要。正是这一章程，以及与之相应的争论和实践——无论在法国学院内部，还是在国外任何重述其模式的地方——把作为个人品格问题而贬低商业的高贵姿态，转化为一种将艺术与手艺、工业和企业区别开来的定义的基础。

<a id="ch03-p024-en"></a>
The academy distinguished itself from the guild, secured the distinction of its members from artisans and asserted the distinction of its students from apprentices, which recast the painter and sculptor as the product of scholarship rather than handicraft. Symptomatic of the entire project is an episode in 1648 (and again in 1777) when the Académie Royale issued a statute proclaiming those who ‘wish to open a shop and trade in pictures, drawings, and sculptures by other hands, sell colors, gilding, and other accessories of the arts of painting and sculpture … shall be required to seek admission to the Community [Guild] of Painter-Sculptors’.<a id="ref-en-ch03-25"></a>[25](#note-en-ch03-25) This statute is not the ultimate source of the idea that art is antagonistic to commerce but it was essential to the consolidation of that idea within new social institutions that upheld it. It is this statute, and the debates and practices that corresponded to it, both within the French academy and wherever its model was reiterated abroad, that converted the nobility of disparaging commerce as a matter of individual character into the basis of a definition of art as distinct from handicraft, industry and business.

<a id="ch03-p025-zh"></a>
由于具有正式资格的行会成员拥有开店的专属权利，禁止院士开店的章程可以被解读为行会的胜利，以及学院承认自己无法将这种权利授予其成员。事实上，从工坊到学院的历史转变把美的艺术家重塑为有学问的个人，却使艺术家不能再从事手工业者仍在进行的那一整套广泛活动。在某种意义上，它构成了对画家和雕塑家自由与能动性的明显削减。然而，17世纪学院的商业禁令是沙龙展创办的前提——沙龙展为学院成员提供机会，使他们无须开店即可向公众展出，并向赞助人和收藏家宣传自己——也是画商兴起的前提，而画商把美的艺术中有学问的实践者与直接经济交易隔绝开来。因此，即便章程本身无权禁止艺术家开店，他们总体上也没有这样做，而是遵循学院先例，为公众举办展览，并通过画商和画廊主销售作品。换言之，学院商业禁令的后果以客观的社会方式把艺术的生产方式界定为与市场对抗，从而为把这一命令作为抽象规范延续下去提供了物质基础。

<a id="ch03-p025-en"></a>
Since the freemen of the guilds held the exclusive right to own a shop, the statute forbidding academicians from opening a shop can be read as a victory of the guilds and the admission that the academy could not award such a right to its members. In fact, the historical transition from the workshop to the academy, which recast the fine artist as a scholarly individual, blocked the breadth of activities that continued to be practised by artisans. In some sense, then, it constituted a palpable reduction of freedom and agency for the painter and sculptor. Nevertheless, the ban on commerce in the seventeenth-century academy was the precondition for the inauguration of the salons – opportunities for its members to exhibit to the public and advertise themselves to patrons and collectors without opening a shop – and the rise of art dealers, which sealed off the scholarly practitioner of the fine arts from direct economic transactions. So, even when the statute itself had no power to prohibit artists from opening shops, they did not on the whole do so, but followed academic precedent in staging exhibitions for the public and selling works via dealers and gallerists. In other words, the consequences of the academic ban on commerce defined art’s mode of production as antagonistic to the market in objective social terms that provided material grounds for the command to be perpetuated as an abstract norm.

<a id="ch03-p026-zh"></a>
关于艺术家范畴如何从更悠久的手工业生产史中产生的标准叙事，强调一场把精英少数提升到平庸的零工手工业者大众之上的运动。无论论证的是文艺复兴的伟大画家、雕塑家和建筑师事实上就是艺术家，还是把“艺术家”一词留给18世纪之后以现代意义使用该词的后来世代，故事都一样：艺术家在历史上经由一个与手工业者相区分的过程而出现。然而，艺术家与手工业者之间的区分从来都不是绝对的，也从未以确定无疑的方式被主张。这与行会制度漫长时期中手工业者同所有其他工人的区分形成鲜明对照。行会依靠绝对区分来运作，并对这些区分加以规制和执行。例如，服完学徒期的人与未服完学徒期的人之间的差别是显而易见的。可以出示证据和证词来确定事实，解决关于某个特定个人地位的争议。

<a id="ch03-p026-en"></a>
The standard narrative of the emergence of the category of the artist out of a longer history of handicraft production stresses the campaign to elevate an elite minority above the mediocre mass of jobbing artisans. Whether it is argued that the great painters, sculptors and architects of the Renaissance were in fact artists, or whether the word itself is saved for later generations after the eighteenth century that used the word ‘artist’ in the modern sense, the story is the same: the artist emerges historically through a process of distinction from the artisan. Yet the differentiation of the artist from the artisan has never been absolute or asserted with certainty. This contrasts sharply with the differentiation of the artisan from all other workers during the long period of the guild system. Guilds operated with absolute distinctions that they regulated and enforced. For instance, the difference between an individual who had served an apprenticeship and another who had not was palpable. Evidence and testimony could be presented to determine the facts and resolve disputes about the status of a particular individual.

<a id="ch03-p027-zh"></a>
相反，艺术家的地位以及美的艺术凌驾于手艺之上的提升，始终是相对的而非绝对的。这种质量与地位上的新型相对区分，是通过一场针对手工业画家和雕塑家的话语运动实现的：把他们仅仅与机械技术和低微的准备性工作联系起来——能复制而不能发明，有技能而无才华，如此等等。一个例子可以显示这些细微而模糊的差别是如何被表述出来的。在皇家学院早年，围绕学院绘画中应重视色彩还是素描的问题，出现了一场原则性辩论。“色彩与研磨颜料和给布上色这一手工任务相联系”，因此关于色彩与线条的辩论，是一种关于美的艺术与手艺之间关系的编码化话语。色彩作为一种物质，是手工业者的领域，因此在色彩方面，院士似乎有两种方法可以用来标示自己与手艺的分离。要么把色彩贬低到素描和线条之下的低等地位，要么赋予色彩一种它在行会那里并不具有的新的智性意义。色彩要么被排除，要么被形而上学地提升，以此遭到否定。<a id="ref-zh-ch03-26"></a>[26](#note-zh-ch03-26)

<a id="ch03-p027-en"></a>
The status of the artist, on the contrary, and the elevation of the fine arts above handicraft, was always relative rather than absolute. This new relative differentiation of quality and status was achieved through a discursive campaign against artisan painters and sculptors by associating them with nothing more than mechanical techniques and menial preparatory tasks, capable of copying but not inventing, skilled but not talented, and so forth. An example may show how these nuanced vague differences were articulated. In the early years of the Académie Royale a principled debate arose over the question of whether to privilege colour or drawing in academic painting. ‘Colour was associated with the manual task of grinding pigments and staining cloths’, therefore debates on colour and line were a coded discourse on the relationship between the fine arts and handicraft. Colour, as a substance, was the province of the artisan, and therefore the academician appeared to have two methods available for marking a separation from handicraft with regard to colour. Either colour could be relegated to a low status below drawing and line, or colour could be assigned a new intellectual significance that it did not have for the guilds. Colour was negated by elimination or metaphysical elevation.<a id="ref-en-ch03-26"></a>[26](#note-en-ch03-26)

<a id="ch03-p028-zh"></a>
可以预料，色彩与素描之争从未以任何一方获胜而告终，但模式已经确立：美的艺术（以及随后的一般艺术）将凌驾于手艺之上，艺术家将凌驾于手工业者之上，其依据不是显而易见的证据或绝对区分，而是对不可测量品质的判断、由未经确保的等级制引导的比较、对未被测绘之边界的充满不确定性的边境管控、对无形属性的不可计算的度量，以及对相对区分的不受法律约束的巡查。这也反映在以下替代之中：行会享有的众多具体自由（在城界内经商、开店、招收学徒等自由）被替换为美的艺术（以及后来的一般艺术）那种未加规定的抽象自由。

<a id="ch03-p028-en"></a>
Predictably, the quarrel of colour versus drawing was never settled one way or the other, but the pattern was set: the fine arts (and subsequently art in general) would be elevated above handicraft, and the artist above the artisan, not on the basis of palpable evidence or absolute distinctions but through judgements of immeasurable qualities, comparisons guided by unsecured hierarchies, uncertain border controls of unmapped boundaries, the incalculable measurements of incorporeal properties and the lawless policing of relative differentiations. This is also reflected in the replacement of the numerous specific freedoms enjoyed by the guild (the freedom to trade within the city limits, the freedom to open a shop, the freedom to take on apprentices, and so on) with the unspecified abstract freedom of the fine arts (and later art in general).

<a id="ch03-p029-zh"></a>
艺术与工艺和工业之差别在确定性上的相对缺乏，明显体现在它凌驾于二者之上这一备受争议的提升之中。正因如此，艺术才是一个会引发去魅式、揭穿式批判的范畴；也正因如此，有时“艺术”一词看起来仿佛是一个空洞的能指，是精英主义与特权资格的委婉语。然而与此同时，这种不确定性也正是艺术为何被珍视为不可还原为工具理性、艺术活动为何被视为异化劳动的死敌、艺术作品为何被视为超出商品形式的核心原因。在我的分析中，艺术范畴的不确定性，是艺术借以把自己提升到手艺之上的那些社会过程的必然结果，这些过程包括：对手工业者的歪曲呈现、对艺术家的自由与原创性的夸大、对有偿和无酬工人为艺术生产所作贡献的压制，以及关键的——艺术家与市场之间中介机构的增殖。

<a id="ch03-p029-en"></a>
The relative lack of determinacy of art’s difference from craft and industry is evident in its contested elevation above them. This is why art is a category that triggers the demystifying and debunking critique of it, and why, at times, it has appeared as if the word ‘art’ is an empty signifier and a euphemism for elitism and entitlement. At the same time, however, this indeterminacy is at the heart of why art is cherished as irreducible to instrumental reason, why artistic activity is taken to be anathema to alienated labour, and why the artwork is seen to exceed the commodity-form. In my analysis, the indeterminacy of the category of art is a necessary consequence of the social processes by which art elevated itself above handicraft, including the misrepresentation of the artisan, exaggerations of the freedom and originality of the artist, suppressions of the contribution of paid and unpaid workers to the production of art, and, crucially, the proliferation of intermediary agencies between the artist and the market.

<a id="ch03-p030-zh"></a>
艺术中的商业禁忌虽然并未把美的艺术与手艺之间的相对区分完全转化为绝对差异，却是艺术家与手工业者之区分得到生活化实行的一种方式，并在艺术制度、经济与教育学中具体化时成为该区分的客观相关物。艺术家与其助手、代工者、技术人员和实习生之间的关系——最近已在艺术劳动政治中被提出——见证了那种作为学院体系奠基姿态的对手艺的退避仍在延续。它存留于两种现象中：对艺术中手艺在场的长久焦虑，以及悬在艺术家与由直接和间接助手组成的配角阵容之间关系上的持续问号。

<a id="ch03-p030-en"></a>
Though not quite converting the relative distinction of the fine arts from handicraft into an absolute difference, the taboo on commerce in art was one of the ways in which the distinction between the artist and artisan was lived out, and became an objective correlate of that distinction when it was concretized in art’s institutions, economies and pedagogy. The relationship between artists and their assistants, fabricators, technicians and interns – which has been raised recently within a politics of artistic labour – testifies to the continuation of the withdrawal from handicraft that was the founding gesture of the academy system. It survives in both the perennial anxiety about the presence of handicraft in art and the persistent question mark over the relationship between the artist and a supporting cast of direct and indirect assistants.

<a id="ch03-p031-zh"></a>
在观念史中，“艺术问题”产生于未能确定各门美的艺术所共享的原则或共同特征。在社会史中，这个问题则以学院长期开展的运动为标志：贬抑手艺，并把有学问的画家和雕塑家提升到手工业者之上。把绘画和雕塑从机械艺术中提升出来的运动，并未成功将它们牢固地安置在自由艺术之内。面对这一失败，人们铸造了一个新范畴——美的艺术，它在封建艺术体制内把少数特定艺术归入机械艺术与自由艺术之间某个未加指明的位置。当封建生产方式被资本主义生产方式取代时，艺术对手艺的优越地位借由把艺术那种高贵的反商业性（反资本主义的前资本主义版本）重构为对市场需求无动于衷的原创作品生产而存续下来；从19世纪起，这常常被表述为与资产阶级、公众、时尚和富人趣味的对立。

<a id="ch03-p031-en"></a>
In the history of ideas, ‘the art question’ arises out of the failure to determine the shared principles or common features of the various fine arts. In social history, this question is marked by the long campaign by the academy to undermine handicraft and elevate scholarly painters and sculptors above artisans. The campaign to lift painting and sculpture out of the mechanical arts did not succeed in lodging them firmly within the liberal arts. In the face of this failure a new category was coined, the fine arts, which classified a small number of specific arts in some unspecified place between the mechanical and liberal arts within the feudal regime of the arts. When the feudal mode of production was superseded by the capitalist mode of production, the elevation of art above handicraft survived by reconstituting art’s noble antagonism to commerce (a pre-capitalist version of anti-capitalism) as the production of original works indifferent to market demand, often expressed from the nineteenth century onwards as an opposition to the bourgeoisie, the public, fashion and the taste of the wealthy.

<a id="ch03-p032-zh"></a>
因此，聚焦于艺术对商业的敌意，可以构成对行会向自由放任过渡之标准叙事的挑战，或者，在艺术史中，对赞助制向艺术市场过渡之标准叙事的挑战。在关于艺术从封建主义向资本主义过渡的叙述中，商品化过程被夸大了。在考虑艺术的特殊性时，不应聚焦于艺术对象的性质或经典化过程，而必须更多地关注艺术生产的社会关系。艺术中对商业的敌意——它常常显得像是意识形态的、浪漫主义的或一种禁忌——才是艺术那有别于雇佣劳动、手艺、商业和工业的标志性劳动范畴得以形成的真正历史前提。

<a id="ch03-p032-en"></a>
Focus on the hostility of art to commerce may thus act as a challenge to the standard narrative of the transition from the guild to laissez-faire or, in art history, from patronage to the art market. There is an overstatement of processes of commodification in accounts of art’s passage from feudalism to capitalism. When considering the specificity of art, rather than focusing on the nature of art objects or processes of canonization, more attention must be paid to the social relations of artistic production. The hostility to commerce in art, which often appears to be ideological or romantic or a taboo, is the real historical precondition for the formation of art’s characteristic category of labour distinct from wage-labour, handicraft, trade and industry.

### 原注

<a id="ch03-n001-zh"></a><a id="note-zh-ch03-1"></a>
[1] 这一说法出自英国分析哲学家奈杰尔·沃伯顿（*The Art Question*, London and New York: Routledge, 2002）。在此，我把它与更具“欧陆”色彩的艺术本体论观念联系起来。我的目的是评论两种传统各自追问艺术之特殊性的方式，同时也为与二者交叠的艺术社会史内部争论作出贡献。 [返回](#ref-zh-ch03-1)

<a id="ch03-n001-en"></a><a id="note-en-ch03-1"></a>
[1] The phrase is from Nigel Warburton, a British analytical philosopher (*The* *Art Question*, London and New York: Routledge, 2002). Here, I link it to the more ‘continental’ idea of art’s ontology. My purpose is to comment on the way both traditions interrogate the peculiarity of art, as well as to contribute to debates within the social history of art which overlap them. [返回](#ref-en-ch03-1)

<a id="ch03-n002-zh"></a><a id="note-zh-ch03-2"></a>
[2] Herbert Marcuse, ‘The Foundation of Historical Materialism’ (1932), in *Studies in Critical Philosophy*, trans. Joris de Bres, London: New Left Books, 1972。关于艺术家作为非异化劳动之范例的观念，或许由 Braunschweig、Sánchez Vázquez、Schapiro 和 Brantlinger 表达得更为清楚。 [返回](#ref-zh-ch03-2)

<a id="ch03-n002-en"></a><a id="note-en-ch03-2"></a>
[2] Herbert Marcuse, ‘The Foundation of Historical Materialism’ (1932), in *Studies in* *Critical Philosophy*, trans. Joris de Bres, London: New Left Books, 1972. The notion of the artist as the exemplification of non-alienated labour is perhaps expressed more clearly by Braunschweig, Sánchez Vázquez, Schapiro and Brantlinger. [返回](#ref-en-ch03-2)

<a id="ch03-n003-zh"></a><a id="note-zh-ch03-3"></a>
[3] 这就是贾德的箴言：“如果有人说他的作品是艺术，那它就是艺术”（Donald Judd, ‘Statement’，载展览图录 *Primary Structures: Younger American and British Sculptors*, New York: The Jewish Museum, 1966; 后重印于 Donald Judd, *Complete Writings 1959–1975*, Halifax NS: Press of the Nova Scotia College of Art and Design and New York: New York University Press, 1975, p. 190）。“贾德的箴言”这一说法来自 Art & Language，是对约瑟夫·科苏斯在《哲学之后的艺术》一文中评论的回应。见 Charles Harrison, *Essays on Art & Language*, Cambridge MA: MIT Press, 1991, pp. 84–5；Joseph Kosuth, *Art After Philosophy and After: Collected Writings 1966–90*, Cambridge MA: MIT Press, 1991。关于这些观念的讨论，另见 Peter Osborne, ‘Conceptual Art and/as Philosophy’, in Michael Newman and Jon Bird, eds, *Rewriting Conceptual Art*, London: Reaktion Books, 1999, pp. 47–65。 [返回](#ref-zh-ch03-3)

<a id="ch03-n003-en"></a><a id="note-en-ch03-3"></a>
[3] This is Judd’s dictum: ‘If someone says his work is art it’s art’ (Donald Judd, ‘Statement’ in the exhibition catalogue *Primary Structures: Younger American and British* *Sculptors*, New York: The Jewish Museum, 1966, reprinted in Donald Judd, *Complete* *Writings 1959–1975*, Halifax NS: Press of the Nova Scotia College of Art and Design and New York: New York University Press, 1975, p. 190). The phrase ‘Judd’s dictum’ comes from Art & Language, responding to Joseph Kosuth’s comments in his essay ‘Art After Philosophy’. See Charles Harrison, *Essays on Art & Language*, Cambridge MA: MIT Press, 1991, pp. 84–5; Joseph Kosuth, *Art After Philosophy and After: Collected Writings 1966–90*, Cambridge MA: MIT Press, 1991. Also, for a discussion of these ideas, see Peter Osborne, ‘Conceptual Art and/as Philosophy’, in Michael Newman and Jon Bird, eds, *Rewriting* *Conceptual Art*, London: Reaktion Books, 1999, pp. 47–65. [返回](#ref-en-ch03-3)

<a id="ch03-n004-zh"></a><a id="note-zh-ch03-4"></a>
[4] 我将区分“艺术”（art）、“诸艺术”（arts）和“美的艺术”（fine arts）这三个术语。尽管它们常被当作可互换的术语，日常语言也允许把它们用作同义词，但我将用它们指称劳动分类的历史形式。“诸艺术”以复数形式出现，指烹饪、捕鱼、编篮和修辞等具体技能实践；这些实践在历史上被分为机械艺术与自由艺术。“美的艺术”是附属于绘画和雕塑的一组特定艺术。单数形式的“艺术”指一般意义上的艺术概念，它不可还原为绘画、雕塑或任何特定艺术。艺术的一般性概念最早由耶拿浪漫派以“什么是文学？”这一问题加以表述。这个问题标志着从众多特定艺术向一般艺术的过渡。对他们而言，文学不被狭义地设想为若干艺术之一，而被设想为一种抽象：“被当作文学来考察的艺术……［以及］被当作艺术之本质来考察的文学”。见 Philippe Lacoue-Labarthe and Jean-Luc Nancy, *The Literary Absolute: The Theory of Literature in German Romanticism*, New York: State University of New York Press, 1988, p. 83。 [返回](#ref-zh-ch03-4)

<a id="ch03-n004-en"></a><a id="note-en-ch03-4"></a>
[4] I will distinguish the terms ‘art’, ‘arts’ and ‘fine arts’. Although these terms are often treated as interchangeable, and common language allows them to be used as synonyms, I will use them to refer to historical forms of the classification of labour. ‘Arts’, in the plural, refers to specific skilled practices such as cooking, fishing, basket weaving and rhetoric, which historically were divided in to the mechanical and liberal arts. ‘The fine arts’ are the group of specific arts attached to painting and sculpture. ‘Art’ in the singular refers to the concept of art in general, which is not reducible to painting, sculpture or any of the specific arts. The concept of art in its generality is first formulated by the Jena Romantics as the question: ‘what is literature?’ This question is marked by transition from the numerous specific arts to art in general. For them literature is conceived not narrowly as one of several arts but as an abstraction: ‘art considered as literature … [and] literature considered as the essence of art’. See Philippe Lacoue-Labarthe and Jean-Luc Nancy, *The Literary Absolute: The Theory of Literature in German Romanticism*, New York: State University of New York Press, 1988, p. 83. [返回](#ref-en-ch03-4)

<a id="ch03-n005-zh"></a><a id="note-zh-ch03-5"></a>
[5] 诗与音乐一直包含在自由艺术之内，因此，对把绘画、雕塑和建筑归类为机械艺术的挑战，是从不包含它们的“设计艺术”观念开始的。后来诗、音乐、绘画、雕塑和舞蹈被归为美的艺术，但确切的选择从未完全固定。 [返回](#ref-zh-ch03-5)

<a id="ch03-n005-en"></a><a id="note-en-ch03-5"></a>
[5] Poetry and music had always been included within the liberal arts, and therefore the challenge to the classification of painting, sculpture and architecture as mechanical arts began without them in the idea of the arts of design. Later poetry, music, painting, sculpture and dance were grouped as the fine arts, but the exact selection was never completely settled. [返回](#ref-en-ch03-5)

<a id="ch03-n006-zh"></a><a id="note-zh-ch03-6"></a>
[6] 安德烈·费利比安1669年在皇家学院所作讲座中对体裁等级制的著名阐述，显然围绕一种劳动等级制展开。他那精细的艺术作品等级尺度，建立在绘画制作的机械程序与心智程序之间的二元区分之上。等级的一端是对自然的复制（“仅仅由勾勒线条和调配色彩构成的自然形态再现，被认为是机械性的工作”），另一端则是天才画家（“一位机敏而博学的作者，因为他发明并产生完全属于他自己的思想”）。见 André Félibien, ‘Conférence de l’Académie Royale de Peinture et de Sculpture’ [1669], trans. Linda Walsh, in Steve Edwards, ed., *Art and its Histories: A Reader*, New Haven CT: Yale University Press, 1999。 [返回](#ref-zh-ch03-6)

<a id="ch03-n006-en"></a><a id="note-en-ch03-6"></a>
[6] André Félibien’s famous elaboration of the hierarchy of genres, delivered in a lecture at the Académie Royale in 1669, is clearly articulated around a hierarchy of labour. His elaborate scale of works of art is based on a binary distinction between mechanical and mental procedures for making paintings. At one end of the scale is the copying of nature (‘the representation of a natural form which consists simply of drawing lines and mixing colours is considered to be work of a mechanical kind’), and at the other end is the genius painter (‘an ingenious and learned Author; as he invents and produces thoughts quite his own’). See André Félibien, ‘Conférence de l’Académie Royale de Peinture et de Sculpture’ [1669], trans. Linda Walsh, in Steve Edwards, ed., *Art and its Histories: A Reader*, New Haven CT: Yale University Press, 1999. [返回](#ref-en-ch03-6)

<a id="ch03-n007-zh"></a><a id="note-zh-ch03-7"></a>
[7] 下面是一个典型例子，展示那种通过聚焦对象属性而非围绕劳动的斗争史来界定范畴的艺术本体论哲学探究：“艺术本体论的核心问题是：艺术作品是哪一类实体？它们是物理对象、观念种类、想象实体，还是别的什么？各种艺术作品如何与艺术家或观看者的心理状态、与物理对象、或与抽象的视觉、听觉或语言结构发生关联？作品在什么条件下开始存在、存续或停止存在？” Amie Thomasson, ‘The Ontology of Art’, in Peter Kivy, ed., *The Blackwell Guide to Aesthetics*, Oxford: Blackwell, 2004, p. 78。 [返回](#ref-zh-ch03-7)

<a id="ch03-n007-en"></a><a id="note-en-ch03-7"></a>
[7] Here is a typical example of the philosophical inquiry into the ontology of art that defines the category by focusing on the properties of objects rather than the history of struggles over labour: ‘The central question for the ontology of art is this: What sort of entities are works of art? Are they physical objects, ideal kinds, imaginary entities or something else? How are works of art of various kinds related to the mental states of artists or viewers, to physical objects, or to abstract visual, auditory or linguistic structures? Under what conditions do works come into existence, survive, or cease to exist?’ Amie Thomasson, ‘The Ontology of Art’, in Peter Kivy, ed., *The Blackwell Guide to* *Aesthetics*, Oxford: Blackwell, 2004, p. 78. [返回](#ref-en-ch03-7)

<a id="ch03-n008-zh"></a><a id="note-zh-ch03-8"></a>
[8] T.J. Clark, ‘The Painting of Postmodern Life?’, *Quaderns portàtils* 20, Barcelona: MACBA, 2000, pp. 7–8。 [返回](#ref-zh-ch03-8)

<a id="ch03-n008-en"></a><a id="note-en-ch03-8"></a>
[8] T.J. Clark, ‘The Painting of Postmodern Life?’, *Quaderns portàtils* 20, Barcelona: MACBA, 2000, pp. 7–8. [返回](#ref-en-ch03-8)

<a id="ch03-n009-zh"></a><a id="note-zh-ch03-9"></a>
[9] 可以说，克拉克的全部著作都在审视艺术与流行文化、或艺术与官方趣味视域之间的往来。下面是一个典型例子：“抽象表现主义的特别之处——使它区别于所有其他现代主义之处——在于它同粗俗而非‘流行’或‘低俗’打交道。我认为，我们应当把19世纪和20世纪艺术中的‘流行’理解为一系列回避粗俗的形象：也就是说，一系列回避艺术实际上从属于资产阶级趣味的悲情这一事实的形象：不断变换并变出各种单纯、直接、天真、感伤与多愁善感、情感力量与物质力量的形象，尽管艺术的实际位置与功能中的一切因素都使这些品质超出其掌控。” T.J. Clark, *Farewell to an Idea: Episode from a History of Modernism*, New Haven CT: Yale University Press, 1999, p. 379。 [返回](#ref-zh-ch03-9)

<a id="ch03-n009-en"></a><a id="note-en-ch03-9"></a>
[9] Clark’s entire body of work, it could be said, interrogates the traffic between art and popular culture, or art and the horizons of official taste. Here is a typical example: ‘what is special about Abstract Expressionism – what marks it off from all other modernisms – is that the engagement is with the vulgar as opposed to the “popular” or “low”. I think we should understand the “popular” in nineteenth- and twentieth-century art as a series of figures of avoidance of the vulgar: that is, figures of avoidance of art’s actual belonging to the pathos of bourgeois taste: a perpetual shifting and conjuring of kinds of simplicity, directness, naivety, sentiment and sentimentality, emotional and material force, in spite of everything about art’s actual place and function that put such qualities beyond its grasp.’ T.J. Clark, *Farewell to an Idea: Episode from a History of* *Modernism*, New Haven CT: Yale University Press, 1999, p. 379. [返回](#ref-en-ch03-9)

<a id="ch03-n010-zh"></a><a id="note-zh-ch03-10"></a>
[10] “否定实践”这一说法是克拉克自己的用语。见 T.J. Clark, ‘Clement Greenberg’s Theory of Art’, in Francis Frascina, ed., *Pollock and After: The Critical Debate*, London: Harper & Row, 1985, pp. 47–64。 [返回](#ref-zh-ch03-10)

<a id="ch03-n010-en"></a><a id="note-en-ch03-10"></a>
[10] The phrase ‘practices of negation’ is Clark’s own. See T.J. Clark, ‘Clement Greenberg’s Theory of Art’, in Francis Frascina, ed., *Pollock and After: The Critical Debate*, London: Harper & Row, 1985, pp. 47–64. [返回](#ref-en-ch03-10)

<a id="ch03-n011-zh"></a><a id="note-zh-ch03-11"></a>
[11] Andrea Fraser, ‘In Conversation’, *The Brooklyn Rail*, https://brooklynrail.org/2004/10/art/andrea-fraser；访问日期：2020年5月21日。 [返回](#ref-zh-ch03-11)

<a id="ch03-n011-en"></a><a id="note-en-ch03-11"></a>
[11] Andrea Fraser, ‘In Conversation’, *The Brooklyn Rail,* https://brooklynrail. org/2004/10/art/andrea-fraser; accessed 21 May 2020. [返回](#ref-en-ch03-11)

<a id="ch03-n012-zh"></a><a id="note-zh-ch03-12"></a>
[12] Immanuel Kant, *Critique of the Power of Judgement*, trans. Paul Guyer and Eric Matthews, Cambridge: Cambridge University Press, 1987 [1790], p. 190。 [返回](#ref-zh-ch03-12)

<a id="ch03-n012-en"></a><a id="note-en-ch03-12"></a>
[12] Immanuel Kant, *Critique of the Power of Judgement*, trans. Paul Guyer and Eric Matthews, Cambridge: Cambridge University Press, 1987 [1790], p. 190. [返回](#ref-en-ch03-12)

<a id="ch03-n013-zh"></a><a id="note-zh-ch03-13"></a>
[13] 见 Dani Child, *Working Aesthetics: Labour, Art and Capitalism*, London: Bloomsbury, 2019；Precarious Workers Brigade, *Training for Exploitation?* London: Journal of Aesthetics and Protest, 2017；Leigh Clare La Berge, *Wages Against Artwork: Decommodified Labor and the Claims of Socially Engaged Art*, Durham NC: Duke University Press, 2019。 [返回](#ref-zh-ch03-13)

<a id="ch03-n013-en"></a><a id="note-en-ch03-13"></a>
[13] See Dani Child, *Working Aesthetics: Labour, Art and Capitalism*, Bloomsbury, London, 2019; Precarious Workers Brigade, *Training for Exploitation?* London: Journal of Aesthetics and Protest, 2017; Leigh Clare La Berge, *Wages Against Artwork: Decommodified Labor* *and the Claims of Socially Engaged Art*, Durham NC: Duke University Press, 2019. [返回](#ref-en-ch03-13)

<a id="ch03-n014-zh"></a><a id="note-zh-ch03-14"></a>
[14] 见 Mark Fisher, *Capitalist Realism: Is There No Alternative?* Winchester: O Books, 2009。 [返回](#ref-zh-ch03-14)

<a id="ch03-n014-en"></a><a id="note-en-ch03-14"></a>
[14] See Mark Fisher, *Capitalist Realism: Is There No Alternative?* Winchester: O Books, 2009. [返回](#ref-en-ch03-14)

<a id="ch03-n015-zh"></a><a id="note-zh-ch03-15"></a>
[15] 关于艺术以各种方式不符合资本主义生产方式的更详细分析，见 Dave Beech, *Art and Value: Art’s Economic Exceptionalism in Classical, Neoclassical and Marxist Economics*, Leiden: Brill, 2015。 [返回](#ref-zh-ch03-15)

<a id="ch03-n015-en"></a><a id="note-en-ch03-15"></a>
[15] For a more detailed analysis of the various ways in which art does not conform to the capitalist mode of production, see Dave Beech, *Art and Value: Art’s Economic* *Exceptionalism in Classical, Neoclassical and Marxist Economics*, Leiden: Brill, 2015. [返回](#ref-en-ch03-15)

<a id="ch03-n016-zh"></a><a id="note-zh-ch03-16"></a>
[16] Steve Edwards, *Photography: A Very Short Introduction*, Oxford: Oxford University Press, 2006, p. 14。 [返回](#ref-zh-ch03-16)

<a id="ch03-n016-en"></a><a id="note-en-ch03-16"></a>
[16] Steve Edwards, *Photography: A Very Short Introduction*, Oxford: Oxford University Press, 2006, p. 14. [返回](#ref-en-ch03-16)

<a id="ch03-n017-zh"></a><a id="note-zh-ch03-17"></a>
[17] 同上，第15页。 [返回](#ref-zh-ch03-17)

<a id="ch03-n017-en"></a><a id="note-en-ch03-17"></a>
[17] Ibid., p. 15. [返回](#ref-en-ch03-17)

<a id="ch03-n018-zh"></a><a id="note-zh-ch03-18"></a>
[18] Cynthia White and Harrison White, *Canvases and Careers: Institutional Change in the French Painting World*, New York: John Wiley, 1993 [1965], p. 5。 [返回](#ref-zh-ch03-18)

<a id="ch03-n018-en"></a><a id="note-en-ch03-18"></a>
[18] Cynthia White and Harrison White, *Canvases and Careers: Institutional Change in* *the French Painting World*, New York: John Wiley, 1993 [1965], p. 5. [返回](#ref-en-ch03-18)

<a id="ch03-n019-zh"></a><a id="note-zh-ch03-19"></a>
[19] 最早的绘画学院位于佛罗伦萨和罗马。英国等地也存在并非实体机构、而是一种聚会形式的学院。关于1791年国民议会废除行会的叙述，见 William Sewell, *Work and Revolution in France: The Language of Labor from the Old Regime to 1848*, Cambridge: Cambridge University Press, 1980。 [返回](#ref-zh-ch03-19)

<a id="ch03-n019-en"></a><a id="note-en-ch03-19"></a>
[19] The earliest academies of painting were in Florence and Rome. Academies which were not physical institutions but a type of meeting also existed in England and elsewhere. For an account of the abolition of the guilds by the National Assembly in 1791, see William Sewell, *Work and Revolution in France: The Language of Labor from the Old* *Regime to 1848*, Cambridge: Cambridge University Press, 1980. [返回](#ref-en-ch03-19)

<a id="ch03-n020-zh"></a><a id="note-zh-ch03-20"></a>
[20] Christian Michel, *The Académie Royale de Peinture et de Sculpture: The Birth of the French School*, 1648–1793, trans. Chris Miller, Los Angeles: Getty Research Institute, 2018, p. 200。 [返回](#ref-zh-ch03-20)

<a id="ch03-n020-en"></a><a id="note-en-ch03-20"></a>
[20] Christian Michel, *The Académie Royale de Peinture et de Sculpture: The Birth of the* *French School*, 1648–1793, trans. Chris Miller, Los Angeles: Getty Research Institute, 2018, p. 200. [返回](#ref-en-ch03-20)

<a id="ch03-n021-zh"></a><a id="note-zh-ch03-21"></a>
[21] White and White, *Canvases and Careers*, p. 6。 [返回](#ref-zh-ch03-21)

<a id="ch03-n021-en"></a><a id="note-en-ch03-21"></a>
[21] White and White, *Canvases and Careers,* p. 6. [返回](#ref-en-ch03-21)

<a id="ch03-n022-zh"></a><a id="note-zh-ch03-22"></a>
[22] 在大多数情况下，手工业工坊不仅位于“师傅”及其家人的住所之内或附属于其住所，而且附属于包括学徒和日工在内的整个家户。女性被排除在正式行会成员资格之外（虽有女性学徒和师傅的个案，但制度限制使她们始终只占少数），学院延续了这种排除，几乎完全把女性排除在其行列之外。 [返回](#ref-zh-ch03-22)

<a id="ch03-n022-en"></a><a id="note-en-ch03-22"></a>
[22] For the most part, artisan workshops were within or attached to the living quarters not only of the ‘master’ and his or her family but to the household in general, including apprentices and day labourers. The exclusion of women from full guild membership (there are cases of female apprentices and masters but these are an institutionally imposed minority) is picked up by the academies which almost completely excluded women from their ranks. [返回](#ref-en-ch03-22)

<a id="ch03-n023-zh"></a><a id="note-zh-ch03-23"></a>
[23] Michel, *The Académie Royale de Peinture et de Sculpture*, p. 243。 [返回](#ref-zh-ch03-23)

<a id="ch03-n023-en"></a><a id="note-en-ch03-23"></a>
[23] Michel, *The Académie Royale de Peinture et de Sculpture*, p. 243. [返回](#ref-en-ch03-23)

<a id="ch03-n024-zh"></a><a id="note-zh-ch03-24"></a>
[24] 马克思解释说：“社会内部的分工与工坊内部的分工虽然有无数类比和联系，但二者不仅在程度上不同，而且在性质上也不同。这种类比在存在一条无形纽带把不同行业联结起来的地方显得最无可争议。例如，畜牧者生产生皮，制革者把生皮制成皮革，鞋匠把皮革制成靴子。在这里，每个人生产的东西都只是走向最终形态的一个步骤，而最终形态是他们全部劳动结合起来的产物。此外，还有各种行业为畜牧者、制革者和鞋匠提供生产资料。现在，完全可能像亚当·斯密那样设想：上述社会分工与工场手工业内部分工之间的差别纯属主观的，只对观察者而言存在——在工场手工业中，观察者一眼就能看到在同一地点进行的大量工序；而在上述例子中，工作散布在广大区域，每个劳动部门雇用的众多人员掩盖了这种联系。但是，究竟是什么构成了畜牧者、制革者和鞋匠各自独立劳动之间的纽带？是他们的产品各自都是商品这一事实。另一方面，工场手工业内部的分工又以什么为特征？以局部工人不生产任何商品这一事实为特征。只有所有局部工人的共同产品才成为商品。社会分工是由不同工业部门产品的买卖引起的，而工坊内部各局部工序之间的联系，则源于若干工人把他们的劳动力卖给一个资本家，资本家把它作为结合起来的劳动力来使用。” Karl Marx, *Capital: A Critique of Political Economy, Volume One*, trans. Ben Fowkes, Harmondsworth: Penguin, 1990 [1867], pp. 474–5。 [返回](#ref-zh-ch03-24)

<a id="ch03-n024-en"></a><a id="note-en-ch03-24"></a>
[24] Marx explains: ‘the numerous analogies and links connecting them, division of labour in the interior of a society, and that in the interior of a workshop, differ not only in degree, but also in kind. The analogy appears most indisputable where there is an invisible bond uniting the various branches of trade. For instance the cattle-breeder produces hides, the tanner makes the hides into leather, and the shoemaker, the leather into boots. Here the thing produced by each of them is but a step towards the final form, which is the product of all their labours combined. There are, besides, all the various industries that supply the cattle-breeder, the tanner, and the shoemaker with the means of production. Now it is quite possible to imagine, with Adam Smith, that the difference between the above social division of labour, and the division in manufacture, is merely subjective, exists merely for the observer, who, in a manufacture, can see with one glance, all the numerous operations being performed on one spot, while in the instance given above, the spreading out of the work over great areas, and the great number of people employed in each branch of labour, obscure the connexion. But what is it that forms the bond between the independent labours of the cattle-breeder, the tanner, and the shoemaker? It is the fact that their respective products are commodities. What, on the other hand, characterises division of labour in manufactures? The fact that the detail labourer produces no commodities. It is only the common product of all the detail labourers that becomes a commodity. Division of labour in society is brought about by the purchase and sale of the products of different branches of industry, while the connexion between the detail operations in a workshop, is due to the sale of the labour-power of several workmen to one capitalist, who applies it as combined labour-power.’ Karl Marx, *Capital: A Critique of Political Economy, Volume One*, trans. Ben Fowkes, Harmondsworth: Penguin, 1990 [1867], pp. 474–5. [返回](#ref-en-ch03-24)

<a id="ch03-n025-zh"></a><a id="note-zh-ch03-25"></a>
[25] 转引自 Michel, *Académie Royale de Peinture et de Sculpture*, p. 112。 [返回](#ref-zh-ch03-25)

<a id="ch03-n025-en"></a><a id="note-en-ch03-25"></a>
[25] Quoted in Michel, *Académie Royale de Peinture et de Sculpture*, p. 112. [返回](#ref-en-ch03-25)

<a id="ch03-n026-zh"></a><a id="note-zh-ch03-26"></a>
[26] Charles Harrison, Paul Wood and Jason Gaiger, *Art in Theory 1648–1815: An Anthology of Changing Ideas*, Oxford: Blackwell, 2000, p. 17。 [返回](#ref-zh-ch03-26)

<a id="ch03-n026-en"></a><a id="note-en-ch03-26"></a>
[26] Charles Harrison, Paul Wood and Jason Gaiger, *Art in Theory 1648–1815: An* *Anthology of Changing Ideas*, Oxford: Blackwell, 2000, p. 17. [返回](#ref-en-ch03-26)

## 第4章　艺术、生活与劳动：卡拉·隆齐关乎生存的女性主义批判

<a id="ch04-title-zh"></a>
## 艺术、生活与劳动：卡拉·隆齐关乎生存的女性主义批判

<a id="ch04-title-en"></a>
## Art, life and labour: Carla Lonzi’s existential feminist critique

<a id="ch04-author-zh"></a>
乔万娜·扎佩里

<a id="ch04-author-en"></a>
GIOVANNA ZAPPERI

<a id="ch04-p001-zh"></a>
任何试图叙述20世纪下半叶意大利女性主义与艺术史的尝试，都不可避免地会撞上卡拉·隆齐（1931—1982）这个人物：她整个1960年代都是知名艺术批评家，后来成为意大利女性主义最具标志性的人物。隆齐的思想与政治轨迹以1970年退出艺术界为标志：她与意大利艺术家卡拉·阿卡尔迪、非裔意大利记者埃尔维拉·巴诺蒂共同创立了激进女性主义团体“女性反叛”（Rivolta Femminile）。因此，她的女性主义由一种激进否定性来界定；这种否定性既表现为她拒绝自己成功从事了十余年的职业，也表现为她寻找另类的写作与生活方式，在其中，诸如艺术这样的父权制度可以被挑战。在她的写作与政治实践中，拆解“女人”以及对女性传统上承担的情感劳动的批判，成为她所推动的集体转化过程的关键方面。

<a id="ch04-p001-en"></a>
Any attempt to give an account of the histories of feminism and art in Italy in the second half of the twentieth century inevitably stumbles upon the figure of Carla Lonzi (1931–1982), a renowned art critic throughout the 1960s, who would later become the most emblematic figure of Italian feminism. Lonzi’s intellectual and political trajectory is marked by her withdrawal from the art world in 1970, as she founded the radical feminist group Rivolta Femminile (Feminine Revolt) with Italian artist Carla Accardi and African-Italian journalist Elvira Banotti. Her feminism is therefore defined by a radical negativity, which expresses itself in her refusal of the profession she had successfully carried out for over a decade, as well as in her search for alternative ways of writing and living in which patriarchal institutions, such as art, could be challenged. In both her writings and her political practice, the undoing of ‘woman’ and the critique of the affective labour traditionally performed by women became crucial aspects of the collective transformative process she promoted.

<a id="ch04-p002-zh"></a>
1970年代，隆齐阐发了她退出艺术界、退出艺术批评家职业的政治含义与生存层面的含义。“女性反叛”是意大利最早一批以分离主义和*自觉意识*（*autocoscienza*，即意识提升）为实践基础的女权团体之一。1970至1972年间，隆齐写了一系列文本；这些文本以前所未有的能力处理性与革命政治问题，并呼吁一场以女人成为主体为基础的文化革命，因而成为意大利妇女解放运动的转折点。<a id="ref-zh-ch04-1"></a>[1](#note-zh-ch04-1) 尤其是她1970年的小册子《我们向黑格尔吐口水》（*Sputiamo su Hegel*）的激进性——其大胆标题和对黑格尔主奴辩证法的挑衅性解构——对于确立隆齐作为意大利同代最杰出女性主义思想家的地位至关重要。

<a id="ch04-p002-en"></a>
During the 1970s Lonzi elaborated the political and existential terms of her withdrawal from the art world and her profession as an art critic. Rivolta Femminile was one of the very first feminist groups in Italy whose practice was based on separatism and *autocoscienza* (consciousness-raising). Between 1970 and 1972 Lonzi wrote a number of texts that marked a turning point for the Italian women’s liberation movement on account of their unprecedented ability to address issues of sexuality and revolutionary politics, and that called for a cultural revolution based on woman’s becoming a subject.<a id="ref-en-ch04-1"></a>[1](#note-en-ch04-1) In particular, the radicalism of her 1970 pamphlet *Sputiamo su Hegel* (*We Spit on Hegel*), with its daring title and provocative deconstruction of Hegelian master–slave dialectics, was crucial in establishing Lonzi as the most prominent feminist thinker of her generation in Italy.

<a id="ch04-p003-zh"></a>
从1970年起，对艺术父权结构的批判成为隆齐发展一种女性主义实践的基础：从结构其生活的角色与期待中退出。尤其是，她持续寻找有价值的不服从形式，以对抗父权对生活的组织；这种寻找建立在对男性声望与成功机制的拒绝服从之上。隆齐建立非等级制关系与共同体的愿望，明确对抗父权对“社会角色定义个人主体性”这一观念的强调，转而把主体置于关系网络之中。

<a id="ch04-p003-en"></a>
From 1970 on, the critique of art’s patriarchal structures became the basis upon which Lonzi develops a feminist practice of withdrawal from the roles and expectations structuring her life. In particular, her continuous search for valuable forms of disobedience against the patriarchal organization of life was based upon the refusal to comply with the male mechanisms of reputation and success. Lonzi’s desire to establish non-hierarchical relations and communities explicitly countered the patriarchal emphasis on the idea that social roles define one’s subjectivity, instead positioning the subject within a network of relations.

<a id="ch04-p004-zh"></a>
在讨论隆齐的立场时，我的目标是强调她对艺术作为意识形态的批判，与其退出所隐含的反工作政治之间的缠绕。隆齐对艺术与生活之关系的理解，是她在全部著作中提出、并在晚期作品中更为痛切地提出的根本问题之一。在《你可以走了》（*Vai pure*）中——这是她1980年与终身伴侣、艺术家彼得罗·孔萨格拉令人痛苦的对谈——隆齐阐发了一种女性主义批判，把艺术视为制度、权力关系、社交形式与劳动的总和，而这些在结构上压迫女性。在她的全部著作中，艺术、生活与职业活动之间的关系通过个人关系展开，从而把生活与政治直接联系起来。隆齐这种关乎生存的女性主义植根于亲身经历的关系对其政治实践的关键意义；同样，她对艺术的看法始终顾及个人历史、亲密性与情感。

<a id="ch04-p004-en"></a>
In addressing Lonzi’s positions, my aim is to emphasize the entwinement between her critique of art as ideology and the anti-work politics that her withdrawal implied. Lonzi’s understanding of the relation between art and life is one of the fundamental issues she raised throughout her writings, and more poignantly in her late work. In *Vai Pure* (*Now You Can Go*), her excruciating 1980 dialogue with her lifelong partner, the artist Pietro Consagra, Lonzi elaborated a feminist critique of art considered as a sum of institutions, power relations, forms of sociability and labour that structurally oppress women. Throughout her writings, the relation between art, life and professional activity is developed through personal relationships, in a way that directly connects life and politics. Lonzi’s existential feminism is rooted in the crucial significance of lived relationships for her political practice, as much as her perspective on art always takes into account personal history, intimacy and emotions.

<a id="ch04-p005-zh"></a>
隆齐从1960年代末到1980年的著作，为发生在私人领域中的冲突之政治强度提供了独特视角。对艺术（与工作）内部个人关系遭到攫取——社会互动正是据此组织起来——的意识，成为她争取承认与社会转化的首要基础。她与艺术家的各种互动表明，艺术与男性特权及女性受压迫之间存在结构性联系，而这种联系排除了任何救赎的可能。尽管到1960年代末，隆齐想强调艺术家与工人之间的差别，但当这两种形象最终重合时，她却不断显得是在为自己主张自主性。她与孔萨格拉对谈最引人注目的方面之一，是艺术家似乎在字面意义上被禁锢在艺术界的价值观之中，而隆齐则体现了一种对超越既定规则、习惯与价值体系的生活的渴望。

<a id="ch04-p005-en"></a>
Lonzi’s writings from the late 1960s until 1980 provide a unique perspective on the political intensity of the conflicts that are played out in the private sphere. The awareness of the seizure of personal relations within art (and work), upon which social interactions are organized, becomes the primary ground for her struggle for recognition and social transformation. Her various interactions with artists demonstrate art’s structural link with male prerogatives and woman’s oppression in a way that precludes any possible redemption. Whereas by the end of the 1960s Lonzi wanted to emphasize the difference between artists and workers, as these two figures eventually coincided, she constantly appears to be claiming autonomy for herself. One of the most striking aspects of her dialogue with Consagra is the ways in which the artist seems to be literally confined within the values of the art world, while Lonzi embodies a desire for a life beyond pre-established rules, habits and systems of value.

<a id="ch04-s01-zh"></a>
## **艺术—生活问题**

<a id="ch04-s01-en"></a>
## **The art–life problem**

<a id="ch04-p006-zh"></a>
如果不考虑隆齐脱离并拆解其作为艺术批评家的职业认同这一复杂过程，她从艺术批评转向女性主义似乎会显得出人意料。她的艺术批评以自我反思的立场为标志，这使她挑战艺术批评的制度框架与语言。隆齐反对艺术批评已变成一种居高临下、威权式的活动，并试图设计新的艺术写作方式，使她能够感到更接近创作过程。整个1960年代，她尝试通过转向艺术家来实验一种关系性写作：她推动对话，并日益避免通过形式分析和审美判断来讨论艺术作品。1969年，她出版《自画像》（*Autoritratto*）；这本书以蒙太奇原则为基础，由与十四位艺术家的磁带录音对话组成，她把这些对话转写下来，再以打断每段对话连续性的方式拼贴起来。<a id="ref-zh-ch04-2"></a>[2](#note-zh-ch04-2) 结果便是三百页偶然的对话，穿插着若干取自参与者私人相册的照片。隆齐本人参与对话，却几乎不提问，也不解释艺术家的作品。她毋宁是以自己的声音为自己说话。《自画像》基于这样一个观念：艺术批评工作是关系性的，因而挑战现代主义关于无利害、中立的审美判断的虚构。个人历史与主体间的相遇取代了界定艺术批评的社会结构与认识结构，因为后者建立在批评家的超然与观察之上。

<a id="ch04-p006-en"></a>
Carla Lonzi’s shift from art criticism to feminism might appear unexpected, if one did not take into account Lonzi’s complex process of disengagement from and unravelling of her professional identification as an art critic. Her art criticism was marked by a self-reflexive position that led her to challenge art criticism’s institutional framework and languages. Lonzi objected that art criticism had become a patronizing and authoritarian activity, and tried to devise innovative ways to write about art, in which she could feel closer to the creative process. Throughout the 1960s she tried to experiment with a form of relational writing by turning to the artists: she promoted dialogues and increasingly avoided discussing the art work via formal analysis and aesthetic judgement. In 1969 she published *Autoritratto* (Self-portrait), a book based on the principle of montage, consisting of a series of tape-recorded conversations with fourteen artists, which she had transcribed and then stitched together in a way that ruptures the continuum of each dialogue.<a id="ref-en-ch04-2"></a>[2](#note-en-ch04-2) The result is three hundred pages of aleatory conversations, interspersed with a number of photographic images taken from the participants’ private albums. Lonzi herself participates in the conversation, but she poses barely any questions; nor does she explain the artists’ artworks. She rather speaks for herself, in her own voice. *Autoritratto* is based on the idea that the work of art criticism is relational and therefore challenges the modernist fiction of a disinterested and neutral aesthetic judgement. Personal history and intersubjective encounters replace the social and epistemic structures defining art criticism, as these were based on the critic’s detachment and observation.

<a id="ch04-p007-zh"></a>
《自画像》已经预示了隆齐即将退出她自1956年从佛罗伦萨大学毕业以来所从事的角色与职业。书中采用的对话形式，是她逃脱这种异化的一种方式：她在被动却又权威的观察者角色中经验到异化，而这个角色不可避免地处于创作过程之外。事实上，艺术批评的压抑功能不仅涉及艺术家，也涉及批评家自身：她的主体性与欲望必须被约束在制度角色的虚构之内：

<a id="ch04-p007-en"></a>
*Autoritratto* already foreshadows Lonzi’s impending withdrawal from the role and profession in which she had been involved since graduating from the University of Florence in 1956. The dialogic format adopted in the book was a way for her to escape the alienation she experienced in the role of the passive yet authoritative observer, which was inevitably located outside of the creative process. As a matter of fact, art criticism’s repressive function concerned not just the artists, but also the critic herself, whose subjectivity and desire had to be contained within the fiction of an institutional role:

<a id="ch04-q001-zh"></a>
> 批评家不再是一个愿意回应他人、也有所求的人，而变成了审判者，因此制造出一整套等级制。而在他最终发展起来的这一整个活动过程中，他实际上取消了自己出发时的起点，从而变成一个完全虚假的人。<a id="ref-zh-ch04-3"></a>[3](#note-zh-ch04-3)

<a id="ch04-q001-en"></a>
> Instead of being the one who is available and in need, the critic  becomes a judge and creates therefore a whole hierarchy. And  throughout this activity that he ends up developing, he actually  repeals the starting point from which he had started, thus becoming  a completely phony person.<a id="ref-en-ch04-3"></a>[3](#note-en-ch04-3)

<a id="ch04-p008-zh"></a>
隆齐把艺术批评活动理解为欺骗性的，这令人想起那种未加标记的普遍性视角的虚构，尽管当时她尚未明确以性别来指认它。该书呈现的主要问题之一，恰恰是拆解艺术批评的功能如何提供了一个机会，使人得以在确保艺术意义的制度框架之外重新思考艺术。与一种以生产“无用评论”为基础的职业相对，隆齐感兴趣的是艺术作品与“生活的姿态”之间的关系；换言之，是“以创造性的方式过自己的生活，而不是顺从地服从社会所提出的模式”这一可能性。<a id="ref-zh-ch04-4"></a>[4](#note-zh-ch04-4) 于是，聚焦关系性成为她把创作过程与生活事实连接起来的方式，仿佛艺术能够存在于角色、习惯与义务的制度链条之外。

<a id="ch04-p008-en"></a>
Lonzi’s understanding of art criticism’s activity as deceptive recalls the fiction of an unmarked universal perspective, even though at the time she didn’t clearly identify it in terms of gender. One of the main issues emerging from the book is precisely how the dismantling of the function of art criticism allowed the opportunity to rethink art beyond the institutional framework in which its meaning was secured. As opposed to a profession based on the production of ‘futile commentaries’, Lonzi is interested in the relation between the art work and the ‘gestures of life’, or, to put it differently, the possibility ‘to live one’s life in a creative manner, instead of obediently comply to the models proposed by society’.<a id="ref-en-ch04-4"></a>[4](#note-en-ch04-4) The focus on relationality thus became a way for her to connect the creative process to the facts of life, as if art could exist outside of the institutional chain of roles, habits and obligations.

<a id="ch04-p009-zh"></a>
因此，批评家自身在职业与生活两方面的异化，成为隆齐全书论证的核心。在讨论自己与艺术批评的疏离时，她转向艺术家；艺术家成为她为自身寻求解放的某种与批评家角色相对照的典范。1960年代编纂《自画像》时，隆齐曾赞同艺术家的自主与自由，以此对抗批评家的制度角色。与关于艺术自主性的现代主义观念相一致，她把艺术家视为超越工作之生活的典范人物。当时，隆齐相信艺术是逃脱组织人类生活的异化力量的唯一可行出口，而艺术家避免与角色、范畴或职业相认同的能力，是她理解艺术自主性的决定性方面。与生活而非与制度化角色直接相连的能力，矛盾地把艺术家置于与艺术批评家“对艺术和艺术家的压抑性控制”相对立的位置。因此，艺术家与工人毫无共同之处；隆齐通过艺术家的“本真性”这一概念来表达这一观念，以对照批评家的“虚假职业”与强制功能。<a id="ref-zh-ch04-5"></a>[5](#note-zh-ch04-5)

<a id="ch04-p009-en"></a>
The critic’s own alienation with respect to both profession and life thus becomes the crux of Lonzi’s argument throughout the book. While discussing her own estrangement from art criticism, she turned to the artists who became a sort of counter-model for the liberation she was seeking for herself. During the 1960s, while she was assembling *Autoritratto*, Lonzi had endorsed the artist’s autonomy and freedom in opposition to the institutional role of the critic. In line with modernist ideas about art’s autonomy, she considered the artist as an exemplary figure of a life beyond work. At the time, Lonzi believed that art was the only viable escape from the alienating forces organizing human life, and that the artist’s ability to evade identification with a role, category or profession was a decisive aspect in her understanding of art’s autonomy. The ability to connect directly with life rather than with an institutionalized role paradoxically posits the artist in antagonism towards the art critic’s ‘repressive control over art and artists’. For these reasons, the artist had nothing in common with the worker, an idea that Lonzi translates via the notion of the artist’s ‘authenticity’, as opposed to the critic’s ‘phony profession’ and coercive function.<a id="ref-en-ch04-5"></a>[5](#note-en-ch04-5)

<a id="ch04-p010-zh"></a>
包括艺术批评在内的艺术制度试图遏制并中和艺术家的自由；因此，艺术家需要远离那些使其活动遭到扭曲的制度，转而面向生活本身，正如隆齐在《自画像》的一段中所言：

<a id="ch04-p010-en"></a>
Art institutions, including art criticism, try to contain and neutralize the artist’s freedom; for this reason artists need to move away from the institutions in which their activity is distorted, and rather address life as such, as Lonzi claims in a passage from *Autoritratto*:

<a id="ch04-q002-zh"></a>
> 艺术问题始终是生活问题，不是文化问题。你明白我的意思吗？它不关大学的事。人们厌倦了扮演公众或学徒；他们想进入事情本身，或者更确切地说，他们觉得自己已经置身其中了。<a id="ref-zh-ch04-6"></a>[6](#note-zh-ch04-6)

<a id="ch04-q002-en"></a>
> The art problem is always a life problem; it’s not a cultural problem.  Do you see what I mean? It doesn’t concern the university. People are  tired of playing the public or the apprentice; they want to enter the  thing, or rather, they feel like they are already in.<a id="ref-en-ch04-6"></a>[6](#note-en-ch04-6)

<a id="ch04-p011-zh"></a>
这种把艺术视为涵盖生活一切方面的活动的观念，以及随之而来对分配给艺术的空间（博物馆、画廊、收藏家的私人住宅）的拒绝，是1960年代末质疑现代主义遗产的一个关键方面。也正是在这一框架内，隆齐谴责艺术的选择与评价机制，认为它们因与制度的关联而严重损害了自身的独立性。

<a id="ch04-p011-en"></a>
This notion of art as an activity encompassing all aspects of life, and the ensuing refusal of art’s allocated spaces (the museum, the gallery, the collector’s private homes) was a crucial aspect in the contestation of the modernist legacy in the late 1960s. It was within this framework that Lonzi also condemned the mechanisms of the selection and evaluation of art, considering them to be excessively compromised owing to their association with the institution.

<a id="ch04-p012-zh"></a>
在《自画像》中，隆齐的关系性实践是她完成拆解自身批评家角色这一过程的基础，而这一过程最终把她推向当时政治动荡的中心。然而，这本书也成为失望的来源，因为艺术家们自己并不准备走上同一条道路。在大多数情况下，他们没有参与1968年之后绽放的各种政治化实践与激进主义，也拒绝挑战自己的艺术语汇——大致而言，这种语汇很大程度上建立在各种旨在从内部动摇现代主义遗产的策略之上。<a id="ref-zh-ch04-7"></a>[7](#note-zh-ch04-7) 据隆齐说，她与艺术家的合作之所以令人失望，在于他们不愿面对自己（男性）的社会特权，随之而来的后果是，他们被证明无力审视自身的异化，即他们的生活围绕艺术界的声望与成功机制运转这一事实。<a id="ref-zh-ch04-8"></a>[8](#note-zh-ch04-8)

<a id="ch04-p012-en"></a>
In *Autoritratto*, Lonzi’s relational practice was the ground upon which she accomplished the process of undoing her own role as a critic, a process that ultimately propelled her to the centre of the political turmoil of the time. Yet, the book also became a source of disappointment as the artists themselves were not ready to follow the same path. In most cases, they failed to engage in the various forms of politicized practices and radicalism that had blossomed in the wake of 1968, and refused to challenge their own artistic vocabulary, which was, broadly speaking, very much based on a variety of strategies that aimed at destabilizing the modernist legacy from within.<a id="ref-en-ch04-7"></a>[7](#note-en-ch04-7) According to Lonzi, the disappointing nature of her undertaking with the artists concerned their unwillingness to address their (male) privilege in society, with the accompanying consequence that they proved incapable of examining their own alienation, namely the fact that their lives revolved around the art world’s mechanisms of reputation and success.<a id="ref-en-ch04-8"></a>[8](#note-en-ch04-8)

<a id="ch04-p013-zh"></a>
到1970年代初，隆齐已意识到这一裂痕：她在日记中写道，“艺术家”身上承载了太多神话。<a id="ref-zh-ch04-9"></a>[9](#note-zh-ch04-9) 相应地，1970年代隆齐对自己与艺术家之关系的理解发生剧烈转变：她觉得自己遭到艺术家的伪装背叛和伤害，而艺术家的自由此时已证明在与意识形态的缠绕中过度受损，因此在政治上不可接受。隆齐的女性主义在许多方面基于她对艺术家观念的变化；这种变化促使她退出自己作为艺术批评家所占据的制度位置，也退出艺术领域本身——1970年代，她逐渐把艺术等同于一种建立在男性特权和女性结构性排斥之上的社会结构的精髓。因此，当她在1970年代和1980年代初重返这些问题时，艺术家首先成了一个异化的工人。

<a id="ch04-p013-en"></a>
By the early 1970s Lonzi had become aware of this divide: ‘The artist’, she writes in her diary, ‘is far too loaded with myth.’<a id="ref-en-ch04-9"></a>[9](#note-en-ch04-9) Accordingly, during the 1970s Lonzi’s understanding of her relation with artists underwent a dramatic overhaul: she felt she had been betrayed and victimized by the artists’ imposture, while the artist’s freedom at this point had proved to be far too compromised in its entanglement with ideology and became therefore politically unacceptable. Lonzi’s feminism is in many ways based on her changing ideas about the artist, which precipitated her withdrawal from both the institutional position she had occupied as an art critic and the arena of art as such, which, during the 1970s, she came to equate with the quintessence of a social structure based on male privilege and woman’s structural exclusion. Hence, upon her return to these issues in the 1970s and early 1980s, the artist has become first and foremost an alienated worker.

<a id="ch04-s02-zh"></a>
## **艺术劳动的性别分工**

<a id="ch04-s02-en"></a>
## **The sexual division of artistic labour**

<a id="ch04-p014-zh"></a>
隆齐想把艺术批评重新定义为一种由生活事实滋养的实践，但这一抱负最终证明不足以回应1960年代末影响意大利社会的转变，她最终决定退出。然而，《自画像》凸显了她对政治的特定理解：政治与构成生活织物的种种关系之存在空间相等同。1970年代，她不断回到书中处理的某些问题，尤其是艺术、生活与工作问题。这也许是隆齐最后一本书《你可以走了：与彼得罗·孔萨格拉的对话》（*Vai pure. Dialogo con Pietro Consagra*）的核心主题；该书也标志着对对话形式的回归，这一次是与她的伴侣、艺术家彼得罗·孔萨格拉的一对一对话。该书出版于1980年，由一段磁带录音对话的转写构成，记录了隆齐与孔萨格拉长期关系的危机。<a id="ref-zh-ch04-10"></a>[10](#note-zh-ch04-10) 对话发生在隆齐的罗马公寓中，于1980年4月下旬至5月上旬的四天里进行。

<a id="ch04-p014-en"></a>
Lonzi’s ambition to redefine art criticism as a practice informed by the facts of life turned out to be an inadequate response to the transformations that were affecting Italian society by the end of the 1960s, and she ultimately decided to opt out. And yet *Autoritratto* foregrounds her specific understanding of politics as identified with the existential space of the relations that form the fabric of life. During the 1970s she constantly returned to some of the issues addressed in the book, most notably to the questions of art, life and work. This is perhaps the central subject of Lonzi’s last book, *Vai pure. Dialogo con Pietro Consagra* (*Now You Can Go: A Dialogue with Pietro Consagra*), which also marks a return to the conversation format, this time as a one-to-one dialogue with her partner, the artist Pietro Consagra. The book, published in 1980, comprises the transcription of a tape-recorded dialogue, which records the crisis of the long-term relationship between Lonzi and Consagra.<a id="ref-en-ch04-10"></a>[10](#note-en-ch04-10) The conversation took place in Lonzi’s Rome apartment and is carried out over four days, between late April and early May 1980.

<a id="ch04-p015-zh"></a>
讨论围绕艺术、工作与爱的问题展开。隆齐与孔萨格拉痛苦地审视彼此如何相处，并尽管方向截然不同，考察私人领域中发生之事的政治意义。他们讨论创造性劳动与再生产劳动之间的差别、男性艺术家的主体性，以及女性争取被承认为自主主体的尝试等话题。争执点在于二人各自理解其关系条件的方式存在分歧。一方面，孔萨格拉似乎满足于自己的处境，满足于构成其生活与关系的既定习惯、特权与义务。相反，隆齐试图应对一种情境的结构性暴力，她在此情境中感到被困住、被剥夺权力。正如她在导言中所说，这本书意在打破围绕异性恋伴侣的秘密性：因此，公开传播这段对话的决定是一种披露。

<a id="ch04-p015-en"></a>
The discussion revolves around issues of art, work and love. Lonzi and Consagra painfully scrutinize how they relate to each other and examine, albeit in radically different directions, the political significance of what happens in the personal sphere. They address topics such as the difference between creative and reproductive labour, the male artist’s subjectivity and woman’s attempt to be recognized as an autonomous subject. The point of contention concerns the divergent manner in which each of them understands the terms of their relationship. On one side, Consagra seems to be content with his own circumstances, with their range of established habits, privileges and obligations, which constitute his life and relationship. Lonzi, on the contrary, tries to tackle the structural violence of a situation in which she feels trapped and disempowered. As she states in the introduction, the book intends to break the secrecy surrounding the heterosexual couple: the decision to disseminate the conversation was therefore a form of disclosure.

<a id="ch04-p016-zh"></a>
在对话中，隆齐回到她退出艺术的意义，并强调自己相对于孔萨格拉作为成功艺术家的特权位置而言的脆弱处境：“嗯，我只是想让你意识到我们这种状况：你是文化人物，而我则生活在一个不受控制的世界的摆布之下，那就是私人的……”<a id="ref-zh-ch04-11"></a>[11](#note-zh-ch04-11) 她的活动与生活融为一体，因而始终不被注意；孔萨格拉的境况则完全得到社会与文化认可机制的确认。对隆齐而言，这些机制与父权结构一致——诸如个人主义以及男性之间的竞争——而女性被排除在这些结构之外。

<a id="ch04-p016-en"></a>
During the dialogue, Lonzi returns to the meaning of her withdrawal from art, and underlines her precarious situation in comparison to Consagra’s privileged position as a successfully established artist: ‘Well, I just want you to realize this condition of ours: of you as a cultural figure, and of myself, living at the mercy of a world without control, which is the private...’<a id="ref-en-ch04-11"></a>[11](#note-en-ch04-11) While her activity accords with her life, thus remaining unnoticed, Consagra’s circumstances are entirely registered by the mechanisms of social and cultural approval. For Lonzi, these are consistent with patriarchal structures – such as individualism and competition between men – from which women are excluded.

<a id="ch04-p017-zh"></a>
讨论围绕孔萨格拉作为艺术家的认同——以及这一认同如何决定其生活的每一个方面——与隆齐寻找一种从组织人类活动的角色中脱离认同的策略之间的对照展开。据隆齐说，艺术家的生活受创造性劳动规制，其方式模糊了生活与工作的区分：一个人一天二十四小时都是艺术家。因此，艺术家体现了一种个体范式：其生活——关系、情感、时间与性——完全服务于对其创造性人格的肯定。

<a id="ch04-p017-en"></a>
The discussion revolves around Consagra’s identification as an artist – and how this determines every single aspect of his life – as opposed to Lonzi’s search for a strategy of disidentification from the roles that organize human activity. According to Lonzi, an artist’s life is regulated by creative labour in a way that blurs the distinction between life and work: one is an artist twenty-four hours a day. Artists thus embody the paradigm of the individual whose life – relations, affects, time and sexuality – is entirely at the service of the affirmation of their creative personality.

<a id="ch04-p018-zh"></a>
《你可以走了》让人想起隆齐过去对艺术家的幻灭以及《自画像》的经历。与她在1960年代所主张的相反，如今隆齐阐明，艺术家的自主性只能以女性的自由为代价而存在，因为它必须摒弃生活的关系维度，并将其压抑到私人领域之中。在分析艺术与生活之间的冲突时，隆齐把作为唯一主角的男性艺术家，与女性被承认为自主主体的渴望对立起来。《你可以走了》以孔萨格拉作为艺术家的认同与隆齐拒绝履行创造性人格所要求的伴随任务之间的僵局开场：这些任务就是传统上由艺术家之妻或情人承担的情感劳动。隆齐已退出日常生活中涉及她作为艺术家伴侣角色的所有任务，例如出席展览开幕式以及其他标记艺术界社交日程的活动。这成为孔萨格拉受挫的来源，他明确表达了自己对协助的渴望：

<a id="ch04-p018-en"></a>
*Vai pure* is reminiscent of Lonzi’s past disillusion with the artists and the experience of *Autoritratto*. As opposed to what she had maintained in the 1960s, now Lonzi clarifies that the artist’s autonomy can only exist at the expense of woman’s freedom, since it needs to dismiss the relational dimension of life and repress it into the private sphere. In analysing the conflict between art and life, Lonzi opposes the male artist, as the unique protagonist, to the woman’s desire to be recognized as an autonomous subject. *Vai pure* opens up with the deadlock between Consagra’s identification as an artist and Lonzi’s refusal to fulfil the accompanying tasks required by the creative personality: the affective labour traditionally performed by the artist’s wife or lover. Lonzi had withdrawn from all the tasks that, in her everyday life, involved her role as an artist’s partner, such as attending exhibition openings and other events that punctuate the art world’s social calendar. This was a source of frustration for Consagra, who affirms his desire for assistance:

<a id="ch04-q003-zh"></a>
> 我在社交生活、工作、忧虑中，也怀念身边有个人。……我无法忍受这种孤独：和我在一起的女人，在我极其需要帮助时却不帮我——在我感到孤独时，在我为展览出行时，或者在我的工作室里，我本需要陪伴与鼓励。<a id="ref-zh-ch04-12"></a>[12](#note-zh-ch04-12)

<a id="ch04-q003-en"></a>
> I missed someone by my side during my social life as well, in my  work, in my worries. … I couldn’t stand the loneliness while I was  with a woman who didn’t help me when I desperately needed help:  company and encouragement when I felt lonely, or when I was  travelling for my exhibitions, or in my studio.<a id="ref-en-ch04-12"></a>[12](#note-en-ch04-12)

<a id="ch04-p019-zh"></a>
难怪孔萨格拉明确把女性在创作过程中的角色限定为从属性的。<a id="ref-zh-ch04-13"></a>[13](#note-zh-ch04-13) 他视为自己正当需求的东西，事实上正是隆齐所抗争的男性特权；因为在她看来，艺术家的自主性如今建立在女性的被排斥以及被禁锢于关怀性他者角色之上。

<a id="ch04-p019-en"></a>
No wonder that Consagra explicitly qualifies a woman’s role in the creative process as subordinate.<a id="ref-en-ch04-13"></a>[13](#note-en-ch04-13) What he considers as his legitimate needs are in fact the male prerogatives against which Lonzi is struggling, as in her view the artist’s autonomy is now based on women’s exclusion and confinement to the role of the caring other.

<a id="ch04-p020-zh"></a>
据隆齐说，艺术的“有限空间”<a id="ref-zh-ch04-14"></a>[14](#note-zh-ch04-14) 正是关系为了艺术家的“主角地位”而被变得不可见的地方：这种主角地位就是关于艺术家原创性与连贯性的神话，依据这一神话，艺术作品可以被视为绝对自我的单纯表达。有趣的是，在对抗缠绕其关系的权力结构时，隆齐不断参照艺术家作为文化英雄的现代主义意识形态，以及包含女性排斥的男性自恋结构。<a id="ref-zh-ch04-15"></a>[15](#note-zh-ch04-15) 这或许就是为什么在《自画像》中，隆齐把原本分别录制的一些对话拼装起来，制造出一种持续的集体交流的虚构，仿佛艺术家们真的在彼此交谈。这样做，隆齐表明她不再相信艺术是一项个体的、孤独的事业，正如她反对批评家独占评判艺术作品的资格一样。这本书转而强调创作过程缠绕在多重关系之中的观念。

<a id="ch04-p020-en"></a>
According to Lonzi, ‘the limited space’<a id="ref-en-ch04-14"></a>[14](#note-en-ch04-14) of art is where relations are rendered invisible in favour of the artist’s ‘protagonism’: the myth of his originality and coherence, according to which artworks can be considered as mere expressions of an absolute self. Interestingly, in confronting the power structures in which her relationship is entwined, Lonzi constantly refers to the modernist ideology of the artist as a cultural hero, as well as to the structures of male narcissism that entail women’s exclusion.<a id="ref-en-ch04-15"></a>[15](#note-en-ch04-15) This is perhaps the reason why, in *Autoritratto*, Lonzi assembled a number of dialogues that were originally recorded separately in a way that creates the fiction of an ongoing, collective exchange, as if the artists were actually talking to each other. In doing so, Lonzi demonstrates that she no longer believed that art is an individual and solitary endeavour, as much as she opposed the critic’s exclusive entitlement to assess the art work. The book emphasizes instead the idea that the creative process is entangled in a multiplicity of relations.

<a id="ch04-p021-zh"></a>
与这一思路一致，《你可以走了》以隆齐对自身关系性劳动的自觉为起点：作为女人和艺术家的伴侣，她从事这种劳动，而她的活动参与到一个她实际上被排除在外的创作过程之中。在某种意义上可以说，隆齐在《自画像》中试图通过把批评家的权威功能转化为关系性劳动，来重新发明艺术批评。这一举措最终使她能够在她想要挑战的制度角色之外与艺术家建立联系，同时生产出一个相遇与对话的网络。1960年代，她相信自己的努力以某种方式也让她为自己主张了创造性——通过她能够生成的关系；而到《你可以走了》时，她已逐渐认识到，在艺术领域中，女人除了保持沉默或说一种自我否定的语言之外别无选择。女人至多能占据倾听性他者的角色——艺术批评家或情人——两者都是他人成就的旁观者。隆齐借助个人经验，在她作为艺术批评家和作为艺术家伴侣的角色之间提出一种平行关系：在两种情况下，女人都凭借协助、理解与支持促成创作过程。另一种选择是，女人也可以尝试自己成为艺术家，因此不得不同现有标准与认可体系的不充分性相抗衡。女性艺术家不可避免地撞上自己需要男性制度与男性艺术家认可这一事实；因此，当她们认可一种最终压迫自己的社会角色时，最终便被困在自身的异化之中。<a id="ref-zh-ch04-16"></a>[16](#note-zh-ch04-16)

<a id="ch04-p021-en"></a>
In keeping with this line of reasoning, *Vai pure* takes as its starting point Lonzi’s awareness of the relational labour she performs, as a woman and the partner of an artist, and how her activity participates in a creative process from which she is virtually excluded. In a way, it can be said that in *Autoritratto* Lonzi sought to reinvent art criticism precisely by turning the critic’s authoritative function into relational labour. This move ultimately allowed her to connect with the artists outside of the institutional role she wanted to challenge, while at the same time producing a network of encounters and dialogues. In the 1960s she believed that her endeavour had somehow also allowed her to claim creativity for herself – via the relations she was able to generate – while by the time of *Vai pure* she had come to realize that, in the field of art, a woman has no other choices than remaining silent or speaking a language of self-negation. At best, a woman can occupy the role of the listening other, art critic or lover, both spectators of someone else’s accomplishments. Lonzi draws on her personal experience while suggesting a parallel between her role as an art critic and as the artist’s partner, as in both cases woman facilitates the creative process thanks to her assistance, understanding and support. Alternatively, a woman can also try to become an artist herself, therefore having to confront the inadequacy of the existing criteria and systems of validation. Women artists inevitably stumble upon their need for approval from male institutions and artists; therefore they end up being trapped in their own alienation as they endorse a social role that ultimately oppresses them.<a id="ref-en-ch04-16"></a>[16](#note-en-ch04-16)

<a id="ch04-p022-zh"></a>
在讨论艺术家对不平等关系的需求时，隆齐指出自己面对的生存困境，即对爱的渴望与对自主的渴望相互矛盾：

<a id="ch04-p022-en"></a>
While discussing the artist’s demand for an unequal relation, Lonzi points at the existential dilemma she is facing between the contradictory desires for love and for autonomy:

<a id="ch04-q004-zh"></a>
> 我不知道这种感受方式会把我带向何处，但我无法颠倒我们需求之间的优先次序。……因为我想要的，是对我自主性的爱，而不是对我的依赖和对我的服务的爱。<a id="ref-zh-ch04-17"></a>[17](#note-zh-ch04-17)

<a id="ch04-q004-en"></a>
> I don’t know where this way of feeling is taking me, but I cannot  overturn the priorities between our needs. ... because what I want is  love for my autonomy, which is not love of my dependence and of my  service.<a id="ref-en-ch04-17"></a>[17](#note-en-ch04-17)

<a id="ch04-p023-zh"></a>
尽管与孔萨格拉的对话有时会传达出人们预期中濒临分手的情侣之间的那种相互指责，但其意义在于，它能够揭露异性恋伴侣内部构成性的权力差异，以及卷入艺术与生活冲突之中的文化结构。隆齐反对这段关系被纳入创作过程之中，因为孔萨格拉只为他自己行动，或者更确切地说，只为艺术作品行动，而艺术作品字面上“规定着议程”。<a id="ref-zh-ch04-18"></a>[18](#note-zh-ch04-18) 艺术家的男性气质用与其凌驾于女性之上的特权地位相联系的区分来包裹自己；这种特权地位意味着私人领域在创作过程中被占有并升华。换言之，艺术与隆齐所谓的“男性主角主义”不可分离，而正是这种主角主义生产出她所抗争的权力失衡。在现代传统中，这种失衡通常可以转译为艺术家工作室内部的分工，正如艺术家与其模特之间被情欲化的关系所例示的那样。“升华”与“支配”押韵——当隆齐强调创作过程的这种配置把女性的工作变成一种象征功能、成为把她们排除在主体性领域之外的另一种方式时，她似乎就在暗示这一点。

<a id="ch04-p023-en"></a>
Even if the dialogue with Consagra might at times convey the kind of recriminations one would expect from a couple on the edge of a break-up, its significance lies in its ability to expose the constitutive power differential within the heterosexual couple, as well as the cultural structures involved in the conflict between art and life. Lonzi contests that the relationship is subsumed within the creative process, as Consagra only acts for himself, or rather for the art work, which literally ‘dictates the agenda’.<a id="ref-en-ch04-18"></a>[18](#note-en-ch04-18) The artist’s masculinity wraps itself with the distinction connected to his privileged status over women, which entails the fact that the personal sphere is appropriated and sublimated in the creative process. In other terms, art is inseparable from what Lonzi calls ‘male protagonism’, which generates the power imbalance she is fighting against. In the modern tradition, this imbalance could typically be translated as the division of labour within the artist’s studio, as exemplified in the eroticized relation between the artist and his model. Sublimation rhymes with domination, Lonzi seems to suggest when she underlines that this configuration of the creative process turns women’s work into a symbolic function, another way of excluding them from the sphere of subjectivity.

<a id="ch04-p024-zh"></a>
在此，隆齐意味深长地提到泽尔达·菲茨杰拉德的案例，把它作为这一有害装置破坏性后果的象征性例子。泽尔达·菲茨杰拉德发现自己受制于一个为了自身文学创作而把他们的关系工具化的男人，这一事实最终导致她精神上的痛苦。泽尔达之所以精神失常，是因为她被孤立、被剥夺权力，无法为自己找到本需要的支持，因为当时“没有女性主义团体”。<a id="ref-zh-ch04-19"></a>[19](#note-zh-ch04-19) 相反，隆齐能够避免崩溃，因为女性主义为她提供了必要力量，去抵抗创造性人格所要求的自我湮灭。艺术家的主角主义要求女性在私人领域中否认自身，而在公共领域中，女性被期待通过充当缪斯、灵感来源和支持性伴侣来表演自己的牺牲，而隆齐拒绝这样做。因此，她试图拆解艺术作为意识形态的功能，同时又发现自己不得不反抗艺术对其生活的破坏性影响。

<a id="ch04-p024-en"></a>
Here, significantly, Lonzi refers to the case of Zelda Fitzgerald as an emblematic example of this pernicious apparatus’s destructive consequences. Zelda Fitzgerald found herself at the mercy of a man who instrumentalized their relationship for the sake of his own literary production, a fact that eventually culminated in her mental distress. Zelda lost her mind because she was isolated, disempowered and unable to find the support she would have needed for herself, as ‘there were no feminist groups’<a id="ref-en-ch04-19"></a>[19](#note-en-ch04-19) at the time. On the contrary, Lonzi can avoid collapsing because feminism provides her with the necessary strength to resist the self-annihilation required by the creative personality. The artist’s protagonism requires that women disavow themselves in the private sphere, while in the public domain they are expected to perform their own sacrifice by acting as muses, sources of inspiration and supporting partners, which Lonzi refuses to do. Hence she tries to dismantle the function of art as an ideology, while at the same time finding herself in the position of having to struggle against art’s destructive effects on her life.

<a id="ch04-s03-zh"></a>
## **工作之外的生活**

<a id="ch04-s03-en"></a>
## **A life beyond work**

<a id="ch04-p025-zh"></a>
隆齐拒绝其艺术家伴侣所要求的情感劳动，以“去文化化”（deculturation）实践为前提；该词由她在1970年代初创造，当时她正试图把自身从职业活动中的退出概念化为一种去认同。<a id="ref-zh-ch04-20"></a>[20](#note-zh-ch04-20) 这是隆齐解放观念的核心，指拆解那些决定女性存在的角色的过程。为了回应自身对转化的渴望，作为社会身份的‘女人’必须被共同拆解，起点是那些既压迫又界定“女人”的角色、刻板印象、姿态以及一切范畴。在此意义上，去文化化实践对应于一个过程：女性敢于抛弃她们自以为了解的关于自身的一切。拒绝“女人”的角色，开启了想象另一种生成的可能性，这种生成不再以男人的认可为基础。因此，去文化化对隆齐的主体观念至关重要：这一主体从一种激进否定性中拆解自身的过程中出现，换言之，从拒绝做女人或成为女人的过程中出现。<a id="ref-zh-ch04-21"></a>[21](#note-zh-ch04-21) 她的关键贡献之一，恰恰在于把拆解“女人”同时作为政治努力与亲身经验。

<a id="ch04-p025-en"></a>
Lonzi’s refusal of the affective labour requested by her artist partner is predicated upon a practice of ‘deculturation’, a term she coined in the early 1970s, as she was trying to conceptualize her own withdrawal from her professional activity as a form of disidentification.<a id="ref-en-ch04-20"></a>[20](#note-en-ch04-20) This the core of Lonzi’s idea of liberation and refers to the process of undoing the roles that determine women’s existence. In order to engage with her own desire for transformation, womanhood must be collectively undone starting from the roles, stereotypes, gestures and all the categories that both oppress and define ‘woman’. In this respect, a practice of deculturation corresponds with a process in which women dare to abandon what they thought they knew about themselves. Refusing the role of ‘woman’ opens up the possibility of imagining a different becoming, which is no longer based on man’s approval. Deculturation is therefore key to Lonzi’s notion of the subject as it emerges from a process of unravelling oneself in a sort of radical negativity, or, in other words, in the refusal to be or to become a woman.<a id="ref-en-ch04-21"></a>[21](#note-en-ch04-21) One of her crucial contributions has consisted precisely in undoing ‘woman’, as both a political endeavour and a lived experience.

<a id="ch04-p026-zh"></a>
隆齐在1970年代初设想的“阴蒂女人”形象，恰恰暗示了对作为现成产品的“女人”的反叛；在隆齐的词汇中，这种现成产品就是“阴道女人”，其性完全被社会再生产机制所捕获。<a id="ref-zh-ch04-22"></a>[22](#note-zh-ch04-22) 这两个对立的形象必须被理解为政治虚构，指示一条通向肯定“非顺从主义性身份”的道路，<a id="ref-zh-ch04-23"></a>[23](#note-zh-ch04-23) 因为阴蒂女人使得在拒绝再生产劳动与对父权制度——如异性恋伴侣、浪漫爱情、核心家庭等等——的激进批判之间建立联系成为可能。<a id="ref-zh-ch04-24"></a>[24](#note-zh-ch04-24) 隆齐把这些社会结构指认为“文化”。

<a id="ch04-p026-en"></a>
The figure of the ‘clitoral woman’ that Lonzi envisions in the early 1970s suggests precisely the revolt against ‘woman’ as an already-available product, which is, in Lonzi’s vocabulary, the ‘vaginal woman’, whose sexuality is entirely captured within the mechanisms of social reproduction.<a id="ref-en-ch04-22"></a>[22](#note-en-ch04-22) These two opposing figures need to be understood as political fictions indicating a path towards the affirmation of a ‘non-conformist sexual identity’,<a id="ref-en-ch04-23"></a>[23](#note-en-ch04-23) as the clitoral woman allows for the establishment of a link between the refusal of reproductive labour and a radical critique of patriarchal institutions such as the heterosexual couple, romantic love, the nuclear family, and so on.<a id="ref-en-ch04-24"></a>[24](#note-en-ch04-24) Lonzi identifies these social structures as ‘culture’.

<a id="ch04-p027-zh"></a>
整个1970年代，隆齐持续拆解那些把女人身份与一系列角色和任务交织在一起的线索，这些角色和任务涵盖社会领域及亲密领域。在此过程中，她始终把亲身经验以及其生活所缠绕的关系，作为政治努力的主要关切。因此，*rapporto*（关系）这一概念成为她著作中关键且反复出现的关键词。*Rapporto* 可以被视为隆齐女性主义实践的内核，因为它凸显主体性的关系维度，以及改变我们彼此相待方式的政治必要性，尤其是在私人领域中。<a id="ref-zh-ch04-25"></a>[25](#note-zh-ch04-25) 在推动对话与关系性时，隆齐试图生成一个相互承认的过程，使一种新的主体性得以展开，以对抗从现代主义传统继承而来的、作为自主而普遍之个体的主体观念。与建立在艺术家区分和特权之上的生活相对，隆齐提出一种激进替代：非工具性的关系，在其中，共在可以成为某种类似“无目的的手段”的东西。<a id="ref-zh-ch04-26"></a>[26](#note-zh-ch04-26)

<a id="ch04-p027-en"></a>
Throughout the 1970s Lonzi would keep on unravelling the threads that interweave womanhood with a number of roles and tasks encompassing the social as well as the intimate sphere. In doing so, she always took her lived experience and the relations in which her life was enmeshed as the main concern of her political endeavour. The notion of *rapporto* (relationship) therefore emerges as a crucial and recurring keyword in her writings. *Rapporto* can be considered as the nucleus of Lonzi’s feminist practice as it foregrounds the relational dimension of subjectivity and the political necessity to transform the way we relate to one another, especially within the personal sphere.<a id="ref-en-ch04-25"></a>[25](#note-en-ch04-25) In promoting dialogues and relationality, Lonzi sought to generate a process of mutual recognition in which a new subjectivity can unfold, as opposed to the notion of the subject as an autonomous and universal individual inherited from the modernist tradition. In opposition to a life based on the artist’s distinction and privilege, Lonzi proposes the radical alternative of a non-instrumental relationship, where being together can be something like a ‘means without an end’.<a id="ref-en-ch04-26"></a>[26](#note-en-ch04-26)

<a id="ch04-p028-zh"></a>
隆齐与孔萨格拉的对话，是一次改变那些使压迫女性的角色得以延续的关系的尝试。针对父权对生活的组织与攫取，隆齐以自己对一种基于集体性和参与性共在的社会的渴望相抗衡；这种社会从社会认可的规训中解放出来。这是她与孔萨格拉冲突中的一个中心方面，因为她所争取的并非仅仅是平等主义乌托邦。用隆齐的话说，*rapporto* 的意义指向另类生活的可能性本身，指向一种能够抵抗艺术家存在所特有的价值增殖与捕获机制的生活。

<a id="ch04-p028-en"></a>
Lonzi’s conversation with Consagra is an attempt to change the relations that perpetuate the roles oppressing women. Against the patriarchal organization and seizure of life, Lonzi counters her desire for a society based on a collective and participatory being together, liberated from the conditioning of social approval. This is a central aspect in the conflict opposing her to Consagra, as what she is striving for is not a mere egalitarian utopia. In Lonzi’s terms, the meaning of *rapporto* refers to the very possibility of living otherwise, of a life that is able to resist the mechanism of valorization and capture typical of the artist’s existence.

<a id="ch04-p029-zh"></a>
*rapporto* 与艺术之间不可调和冲突的问题，是《你可以走了》所收对话第四天、也是最后一天处理的主要问题。在上次录音过去两周后，隆齐与孔萨格拉再次见面。讨论的整体语气此时已从先前各章占主导的论战情绪，转向某种疲惫；这种疲惫源于二人共同的感受：他们的关系已到达无法回头的节点。例如，孔萨格拉愿意承认，是的，在他看来，“人类关系只有与这种对对象的投入相联系才可能”；而隆齐重申她的看法：他作为艺术家的认同及其一般意义上的工作阻碍了关系。<a id="ref-zh-ch04-27"></a>[27](#note-zh-ch04-27) 孔萨格拉反过来如今承认，“工作在某种程度上与人类关系相抵触”，并且“艺术是某一类工作的象征，这类工作要求我们参与一个神话”。<a id="ref-zh-ch04-28"></a>[28](#note-zh-ch04-28) 在概述他们危机的原因时，他说：“我们的分歧来自你希望在关系中获得的那种愉悦——因为你创造了一种趋向于此的关系，每个人都会享受它——以及我作为交换所提议的东西，而它并不令你愉快。”<a id="ref-zh-ch04-29"></a>[29](#note-zh-ch04-29) 然而，对隆齐来说，孔萨格拉的提议不仅不愉快，而且“无法在其中生活”，恰恰因为她寻求过一种不同于工作的生活，而她的伴侣无法理解这一点。对隆齐而言，“艺术的生长与传播是以人类关系为代价的”，<a id="ref-zh-ch04-30"></a>[30](#note-zh-ch04-30) 因为这些关系在艺术作品的逻辑中不可避免地遭到工具化。隆齐悲叹，他们的关系建立在孔萨格拉工作之首要性上，而这种首要性侵入了他们作为伴侣生活的一切方面；她在该书最后几页论证道：

<a id="ch04-p029-en"></a>
The problem of the irreconcilable conflict between *rapporto* and art is the main issue addressed in the fourth and last day of the dialogue comprising *Vai pure*. Lonzi and Consagra meet again after two weeks have passed since their last recording. The general tone of the discussion has now shifted from the polemical mood that had prevailed in the previous chapters, towards a certain fatigue prompted by the shared feeling that the couple have now reached a point of no return. Consagra is willing to admit, for example, that yes, in his view, ‘human relations are only possible if they are connected to this commitment to the object’, whereas Lonzi reaffirms her perception that his identification as an artist and his work in general hinder the relation.<a id="ref-en-ch04-27"></a>[27](#note-en-ch04-27) Consagra, in turn, now acknowledges that ‘work is a bit against human relations’, and that ‘art is the symbol of a type of work that requires us to participate in a myth.<a id="ref-en-ch04-28"></a>[28](#note-en-ch04-28) While recapitulating the reasons for their crisis, he says: ‘Our disagreement arises from the pleasure that you want to have in a relation – because you create a relation that tends to this, and everyone enjoys it – and what I propose in exchange, which is not pleasant to you.’<a id="ref-en-ch04-29"></a>[29](#note-en-ch04-29) However, for Lonzi, Consagra’s proposal is not just unpleasant, it is ‘unliveable’, precisely because she seeks to live a life that is something different from work, which her partner is unable to understand. For Lonzi ‘art grows and disseminates to the detriment of human relations’,<a id="ref-en-ch04-30"></a>[30](#note-en-ch04-30) inasmuch as these are inevitably instrumentalized within the logic of the artwork. Lonzi laments the fact that their relationship is predicated upon the primacy of Consagra’s work in a way that invades all aspects of their life as a couple, as she argues in the book’s final pages:

<a id="ch04-q005-zh"></a>
> 你必须明白，我们的整个生活都由工作结构起来，全部都是如此，我们从不为我们自己而在一起。那只是工作中的一个停顿、一段休息。有生命、有意识、主动的时刻，应许之地，就是工作……你没有规定的工作时间，没有受雇职位，没有必须履行的职责，却制造出一种比受雇工作、有老板管着还要受约束的处境。<a id="ref-zh-ch04-31"></a>[31](#note-zh-ch04-31)

<a id="ch04-q005-en"></a>
> You must understand that our whole life is structured by work, all  of it, that we are never together for ourselves. It’s just a pause, a rest  from work. The vital, conscious and active moment, the promised  land is work... You don’t have a schedule, you don’t have a job, you  don’t have obligations, but you create a more constraining situation  than if you had a job and a boss.<a id="ref-en-ch04-31"></a>[31](#note-en-ch04-31)

<a id="ch04-p030-zh"></a>
《你可以走了》以赋予书名的那句告别结束（“你可以走了”是隆齐对孔萨格拉说的结束语），也以生活与工作之间未解决的困境结束；这个困境自隆齐开始质疑自己作为艺术批评家的角色以来，一直占据她的思想。该书的最后一段表明，生活在多大程度上从属于工作的逻辑，已使这段关系被抽空一切独立意义；而隆齐所争取的，是一种能够超越构成艺术家生活的义务与习惯而存在的关系。她的异议指示了一种可能性：过一种关系不受工作逻辑规训的生活，而这种工作逻辑隐含地且不可避免地指向资本主义的生产效率逻辑。

<a id="ch04-p030-en"></a>
*Vai pure* ends with a farewell that gives the book its title (‘you can go’ is Lonzi’s concluding remark addressed to Consagra) and with the unresolved dilemma of life and work, a dilemma that had occupied Lonzi’s thinking ever since she had started to contest her role as an art critic. The book’s final passage shows the extent to which life’s subordination to the logic of work has emptied the relationship of any independent meaning, whereas Lonzi strives for a relation that can exist beyond the obligations and habits that make an artist’s life. Her disagreement indicates the possibility of living a life where relations are not disciplined within the logic of work, which implicitly, and inevitably, suggests capitalist productivity.

<a id="ch04-p031-zh"></a>
在此意义上，《你可以走了》不仅回到她作为艺术批评家提出的某些问题，也回到她早期女性主义著作，尤其是1970年春天写成的第一份《女性反叛宣言》。宣言中有若干段落，在反工作政治的框架内讨论对再生产劳动的批判；这种反工作政治强调女性隐蔽且未得到充分承认的劳动，同时主张非生产性具有独立价值。对“女性反叛”而言，拒绝工作<a id="ref-zh-ch04-32"></a>[32](#note-zh-ch04-32) 转译了一种从社会期待中退出的政治策略：

<a id="ch04-p031-en"></a>
In this respect, *Vai pure* also returns not just to some of the issues she had raised as an art critic, but also to her early feminist writings, in particular the first *Manifesto of Rivolta Femminile*, written in the spring of 1970. Several passages of the manifesto discuss the critique of reproductive labour within the framework of an anti-work politics that emphasize women’s hidden and under-recognized labour, while at the same time claiming unproductivity’s independent value. For Rivolta Femminile, the refusal of work<a id="ref-en-ch04-32"></a>[32](#note-en-ch04-32) translates a political strategy of withdrawal from social expectations:

<a id="ch04-q006-zh"></a>
> 我们在无酬家务劳动中认出了让私人资本主义和国家资本主义都得以存续的助力。……我们憎恶竞争机制，以及工作中由效率霸权所施加的勒索。我们希望把自己的工作能力交给一个不受这种逻辑影响的社会支配。……赋予“非生产性”时刻以价值，是女人所提出的一种生命的延展。<a id="ref-zh-ch04-33"></a>[33](#note-zh-ch04-33)

<a id="ch04-q006-en"></a>
> We identify in unpaid domestic work the help that allows both  private and state capitalism to survive. ... We detest the mechanism  of competitiveness and the blackmail exercised in the work by the  hegemony of efficiency. We want to put our working capacity at the  disposal of a society that is immune to this. ... Attributing value to  ‘unproductive’ moments is an extension of life proposed by woman.<a id="ref-en-ch04-33"></a>[33](#note-en-ch04-33)

<a id="ch04-p032-zh"></a>
这些段落与跨国的‘以争取工资反对家务劳动’运动相互呼应；该运动在1970年代初的意大利获得势头，得益于若干女性的写作与行动主义，她们阐发了一种在其他方面与“女性反叛”立场相距甚远的女性主义话语。<a id="ref-zh-ch04-34"></a>[34](#note-zh-ch04-34) 因此，“女性反叛”和隆齐的观念可以在一个更宽广的框架内讨论，即拒绝西尔维娅·费德里奇所谓的“爱的劳动”，也就是女性在日常生活中从事的关系性与情感性劳动。<a id="ref-zh-ch04-35"></a>[35](#note-zh-ch04-35) 据费德里奇说，以争取工资反对家务劳动，是反抗女性社会角色、因而也是反抗工作本身的斗争的第一步。<a id="ref-zh-ch04-36"></a>[36](#note-zh-ch04-36) 工资要求使再生产劳动变得可见，而这是开始反抗它的条件。资本主义通过否认家务劳动具有劳动地位，把它转化为一种爱的行为，并把女性等同于她们必须完成的任务。费德里奇挑战女性与再生产劳动的同化，也挑战“爱只能等同于工作”这一观念本身。类似地，隆齐也反驳女性工作是非生产性的观念，同时反对把生活化约为工作的视角。然而，与费德里奇相反，她无意在马克思主义的阶级关系框架内分析女性的臣属，因为在她看来，把女性等同于阶级，会再次把她们放回一个积极运作以排斥她们的结构之中。<a id="ref-zh-ch04-37"></a>[37](#note-zh-ch04-37)

<a id="ch04-p032-en"></a>
These paragraphs resonate with the transnational ‘wages against housework’ campaign, which gained momentum in Italy in the early 1970s, thanks to the writings and activism of a number of women who articulated a feminist discourse that was otherwise very remote from Rivolta Femminile’s positions.<a id="ref-en-ch04-34"></a>[34](#note-en-ch04-34) Rivolta Femminile’s and Lonzi’s ideas can therefore be discussed in the wider framework of the refusal of what Silvia Federici called the ‘labour of love’, namely the relational and affective labour women perform in their everyday lives.<a id="ref-en-ch04-35"></a>[35](#note-en-ch04-35) According to Federici, wages against housework are the first step of the struggle against woman’s social role, and thus against work itself.<a id="ref-en-ch04-36"></a>[36](#note-en-ch04-36) The demand for wages renders reproductive labour visible, which is the condition to start struggling against it. In denying housework the status of labour, capitalism has transformed it into an act of love and has identified women with the tasks they have to accomplish. Federici challenges woman’s assimilation with reproductive labour, as well as the very notion that love can be nothing else than work. In a similar way, Lonzi also counters the idea that woman’s work is unproductive and at the same time opposes the perspective of a life reduced to work. However, contrary to Federici, she is not interested in analysing woman’s subjection within the Marxist framework of class relations, because in her view identifying women with class would put them back within a structure that actively operates towards their exclusion.<a id="ref-en-ch04-37"></a>[37](#note-en-ch04-37)

<a id="ch04-p033-zh"></a>
与她从女性的生存处境理解其受压迫相一致，隆齐毋宁要颠覆女性与非生产性的关联，并将其转化为一项政治纲领。在整本《你可以走了》中，宣言对再生产劳动的批判及其反工作政治，成为隆齐反对孔萨格拉只专注于艺术作品的论证核心。因此，艺术家显现为一个异化的个体，其存在建立在“他是谁”与“他做什么”之间的完美重合之上，从而成为当代劳动的典范人物：自我专注而好竞争。隆齐渴望因自己的自主性而非自己的服务被爱；这为“关系在生产逻辑内部运作”的观念提供了一个激进替代。

<a id="ch04-p033-en"></a>
In keeping with her existential understanding of woman’s oppression, Lonzi rather aims at overturning woman’s association with unproductivity and transforming it into a political programme. Throughout *Vai pure*, the manifesto’s critique of reproductive labour and its anti-work politics becomes the crux of Lonzi’s argument against Consagra’s exclusive focus on the artwork. Hence, the artist emerges as an alienated individual whose existence is based on the perfect coincidence between what he is and what he does, thus becoming a paradigmatic figure of contemporary labour, self-absorbed and competitive. Lonzi’s desire to be loved for her autonomy instead of her service offers instead a radical alternative to the idea that relationships operate within the logics of production.

<a id="ch04-p034-zh"></a>
隆齐关于艺术家男性气质以及艺术作为意识形态之功能的观念，可以在一个更广泛的、自1970年代以来一直是许多女性主义艺术史与批评中心的对艺术批判中得到富有成效的讨论。在她的同代英美女性主义艺术史家中——例如琳达·诺克林或卡罗尔·邓肯——有人指出了把女性排除在艺术生产之外的物质条件，并在艺术劳动的性别分工内部指出艺术意识形态装置的关键方面。<a id="ref-zh-ch04-38"></a>[38](#note-zh-ch04-38) 然而，隆齐立场的独特之处不仅在于她放弃了艺术（也就是说，她从未像比如露西·利帕德那样成为“女性主义艺术批评家”），还在于她的批判是她与自身亲身经验、更重要的是与她试图实验的那类转化性关系相中介的结果——无论这些关系发生在艺术界、女性主义团体，还是爱情关系的亲密性之中。在思考女性关系性劳动的政治意义时，隆齐尤其关注强调女性在男性文化剧场中扮演的表演性角色。这一方面对我理解隆齐反对艺术的立场至关重要：该立场是她想象并体现一种新女性主义主体性的基础。

<a id="ch04-p034-en"></a>
Lonzi’s ideas about the artist’s masculinity and the function of art as ideology can be productively addressed within the broader critique of art that has been at the centre of much of feminist art history and criticism since the 1970s. Feminist art historians of her generation in the Anglo-American context – such as Linda Nochlin or Carol Duncan – pointed out the material conditions that have excluded women from artistic production, indicating within the sexual division of artistic labour a crucial aspect of art’s ideological apparatus.<a id="ref-en-ch04-38"></a>[38](#note-en-ch04-38) However, what differentiates Lonzi’s position is not just the fact that she abandoned art (i.e. she never became a ‘feminist art critic’, as did, for instance, Lucy Lippard), but also that her critique is the result of a mediation with her lived experience and, more importantly, with the kind of transformative relations with which she tried to experiment, be it in the art world, in the feminist group or in the intimacy of a love relationship. While reflecting upon the political significance of women’s relational labour, Lonzi was particularly interested in stressing the performative role women play within the theatre of male culture. This aspect is crucial to my understanding of Lonzi’s positioning against art as the basis upon which she imagines and embodies a new feminist subjectivity.

<a id="ch04-p035-zh"></a>
与孔萨格拉的对话在某种意义上仍悬置着，因为自编纂《自画像》以来一直占据隆齐思想的艺术与生活困境，不存在可能的解决。隆齐的轨迹及其对另类生活方式的激进寻找，给我们留下一组没有简单答案的开放问题。她的政治与生活实践计划当然注定仍是乌托邦式的，因为它似乎缠绕在若干矛盾之中。不用说，隆齐的反工作政治之所以可能，是因为她享有能够避免工作的相对特权，尽管这使依赖与自主之间的冲突变得更加难以解开。人们也可以追问，在异性恋资产阶级伴侣内部上演的冲突——无论多么具有文化结构的典范性——如何能够转置到整个社会。然而，通过以生活对抗艺术、因而对抗工作，卡拉·隆齐表达了一种渴望：一种从组织社会互动的权力关系中解放出来的生活。她把生活与政治相互关联的能力今天仍可能具有相关性，因为私人领域与生产领域之间的壁垒正日益消融，而全球各地的女性主义运动不断实验并想象新的生活与共在方式。

<a id="ch04-p035-en"></a>
The dialogue with Consagra remains somehow held in suspension, as there is no possible resolution of the dilemma between art and life that had occupied Lonzi ever since assembling *Autoritratto*. Lonzi’s trajectory and radical search for alternative modes of living leave us with a set of open questions with no easy answers. Her political and existential project is certainly fated to remain utopian, as it appears entangled in a number of contradictions. Needless to say, Lonzi’s anti-work politics was made possible by her relative privilege of being able to avoid work, even though this made the conflict between dependence and autonomy even more inextricable. One could also wonder how the conflicts that are played out within the heterosexual bourgeois couple, no matter how exemplary of a cultural structure, can be transposed to society at large. However, in opposing life to art, and thus to work, Carla Lonzi expresses a desire for a life liberated from the power relations that organize social interactions. Her ability to correlate life and politics can still be relevant today, as the barriers between the personal and the productive spheres are increasingly dissolving, and feminist movements around the globe keep on experimenting and imagining new ways of living and being together.

### 原注

<a id="ch04-n001-zh"></a><a id="note-zh-ch04-1"></a>
[1] 见 Carla Lonzi, ‘Sputiamo su Hegel’ (1970), in *Sputiamo su Hegel, La donna clitoridea e la donna vaginale e altri scritti*, Milan: Scritti di Rivolta Femminile, 1974, pp. 19–61; ‘Let’s Spit on Hegel’, trans. G. Bellesia and E. Maclachnan, in P. Jagentowicz Mills, ed., *Feminist Interpretations of G.F.W. Hegel*, University Park: Pennsylvania State University Press, 1996。 [返回](#ref-zh-ch04-1)

<a id="ch04-n001-en"></a><a id="note-en-ch04-1"></a>
[1] See Carla Lonzi, ‘Sputiamo su Hegel’ (1970), in *Sputiamo su Hegel, La donna clitoridea* *e la donna vaginale e altri scritti*, Milan: Scritti di Rivolta Femminile, 1974, pp. 19-61; ‘Let’s Spit on Hegel’, trans. G. Bellesia and E. Maclachnan, in P. Jagentowicz Mills, ed., *Feminist* *Interpretations of G.F.W. Hegel*, University Park: Pennsylvania State University Press 1996. [返回](#ref-en-ch04-1)

<a id="ch04-n002-zh"></a><a id="note-zh-ch04-2"></a>
[2] Carla Lonzi, *Autoritratto*, Bari: De Donato, 1969。这些艺术家的名字也出现在该书封面上：Accardi、Alviani、Castellani、Consagra、Fabro、Fontana、Kounellis、Nigro、Paolini、Pascali、Rotella、Scarpitta、Turcato、Twombly。关于《自画像》的编纂过程，见 Laura Iamurri, *Un margine che sfugge. Carla Lonzi e l’arte in Italia, 1955–1968*, Macerata: Quodlibet, 2016, pp. 167–213。 [返回](#ref-zh-ch04-2)

<a id="ch04-n002-en"></a><a id="note-en-ch04-2"></a>
[2] Carla Lonzi, *Autoritratto*, Bari: De Donato, 1969. The artists’ names are also mentioned on the book’s cover: Accardi, Alviani, Castellani, Consagra, Fabro, Fontana, Kounellis, Nigro, Paolini, Pascali, Rotella, Scarpitta, Turcato, Twombly. On the process of assembling *Autoritratto*, see Laura Iamurri, *Un margine che sfugge. Carla Lonzi e l’arte in* *Italia, 1955–1968*, Macerata: Quodlibet, 2016, pp. 167–213. [返回](#ref-en-ch04-2)

<a id="ch04-n003-zh"></a><a id="note-zh-ch04-3"></a>
[3] Lonzi, *Autoritratto*, pp. 47–8。隆齐在讨论艺术批评家形象时总使用男性人称。除非另有说明，此后所有隆齐文本的引文均由本文作者译成英文。 [返回](#ref-zh-ch04-3)

<a id="ch04-n003-en"></a><a id="note-en-ch04-3"></a>
[3] Lonzi, *Autoritratto*, pp. 47–8. Lonzi always uses the male person when discussing the figure of the art critic. All subsequent quotations from Lonzi’s texts are translated by the author, unless otherwise indicated. [返回](#ref-en-ch04-3)

<a id="ch04-n004-zh"></a><a id="note-zh-ch04-4"></a>
[4] 同上，第48页。 [返回](#ref-zh-ch04-4)

<a id="ch04-n004-en"></a><a id="note-en-ch04-4"></a>
[4] Ibid., p. 48. [返回](#ref-en-ch04-4)

<a id="ch04-n005-zh"></a><a id="note-zh-ch04-5"></a>
[5] 同上，第7、44页。关于隆齐的本真性概念与艺术和女性主义的关系，见 Giovanna Zapperi, ‘The Making of a Feminist Subject: Autonomy, Authenticity and Withdrawal’, in Francesco Ventrella and Giovanna Zapperi, eds, *Art and Feminism in Post-war Italy: The Legacy of Carla Lonzi*, London: Bloomsbury, 2020, pp. 89–110。 [返回](#ref-zh-ch04-5)

<a id="ch04-n005-en"></a><a id="note-en-ch04-5"></a>
[5] Ibid., pp. 7, 44. On Lonzi’s notion of authenticity in relation to art and feminism, see Giovanna Zapperi, ‘The Making of a Feminist Subject: Autonomy, Authenticity and Withdrawal’, in Francesco Ventrella and Giovanna Zapperi, eds, *Art and Feminism in* *Post-war Italy: The Legacy of Carla Lonzi*, London: Bloomsbury 2020, pp. 89–110. [返回](#ref-en-ch04-5)

<a id="ch04-n006-zh"></a><a id="note-zh-ch04-6"></a>
[6] Lonzi, *Autoritratto*, pp. 203–4。 [返回](#ref-zh-ch04-6)

<a id="ch04-n006-en"></a><a id="note-en-ch04-6"></a>
[6] Lonzi, *Autoritratto*, pp. 203–4. [返回](#ref-en-ch04-6)

<a id="ch04-n007-zh"></a><a id="note-zh-ch04-7"></a>
[7] 见亚历克斯·波茨关于贫困艺术（Arte Povera）艺术家面对现代主义艺术自主性观念及艺术—生活关系时的矛盾策略的讨论，Alex Potts, ‘Disencumbered Objects’, *October* 124, Spring 2008, pp. 169–89；以及 Alex Potts, ‘Autonomy in Post-War Art: Quasi-heroic and Casual’, *Oxford Art Journal*, vol. 17, no. 1, 2004, pp. 53–7。 [返回](#ref-zh-ch04-7)

<a id="ch04-n007-en"></a><a id="note-en-ch04-7"></a>
[7] See Alex Potts’s discussion of Arte Povera artists’ ambivalent strategy towards the modernist notion of art’s autonomy and the art–life relation, in Alex Potts, ‘Disencumbered Objects’, *October* 124, Spring 2008, pp. 169–89; and Alex Potts, ‘Autonomy in Post-War Art: Quasi-heroic and Casual’, *Oxford Art Journal*, vol. 17, no. 1, 2004, pp. 53–7. [返回](#ref-en-ch04-7)

<a id="ch04-n008-zh"></a><a id="note-zh-ch04-8"></a>
[8] 《自画像》所涉所有艺术家均为男性，卡拉·阿卡尔迪是唯一例外；隆齐正是与她一起发现并接纳了女性主义运动，这一过程通过阿卡尔迪在书中的介入得到记录。作为“女性反叛”的创始成员，阿卡尔迪对隆齐成为女性主义者起了关键作用；隆齐后来在日记中回忆：“‘女性反叛’诞生于两个人，［卡拉］和我；我们之所以质疑男性主体性，恰恰是因为我们把自己安置为主体：［卡拉］作为艺术家，而我作为一种不同身份的意识。” Carla Lonzi, ‘14 August 1972’, in *Taci, anzi parla. Diario di una femminista*, Milan: Scritti di Rivolta femminile, 1978, p. 40。然而，与隆齐相反，阿卡尔迪没有退出艺术界，并拒绝放弃自己作为艺术家的认同，这最终导致二人友谊在1973年终结。 [返回](#ref-zh-ch04-8)

<a id="ch04-n008-en"></a><a id="note-en-ch04-8"></a>
[8] All the artists involved in *Autoritratto* are male with the exception of Carla Accardi, with whom Lonzi discovered and embraced the feminist movement in a process that is chronicled via Accardi’s interventions in the book. A founding member of Rivolta Femminile, Accardi was instrumental in Lonzi’s becoming a feminist, as she would later recount in her diary: ‘Rivolta Femminile was born out of two persons, [Carla] and I, who had questioned male subjectivity precisely because we had positioned ourselves as subjects: [Carla] as an artist, and myself as a consciousness of a different identity.’ Carla Lonzi, ‘14 August 1972’, in *Taci, anzi parla. Diario di una femminista*, Milan: Scritti di Rivolta femminile 1978, p. 40. However, contrary to Lonzi, Accardi did not step out of the art world and refused to give up her identification as an artist, which ultimately caused the end of their friendship in 1973. [返回](#ref-en-ch04-8)

<a id="ch04-n009-zh"></a><a id="note-zh-ch04-9"></a>
[9] Lonzi, ‘12 May 1973’, in *Taci, anzi parla*, p. 378。关于隆齐对“神话”一词的使用及其与罗兰·巴特著作的关联的讨论，见 Francesco Ventrella, ‘Carla Lonzi e la disfatta della critica d’arte: registrazione, scrittura e risonanza’, *Studi Culturali*, vol. 12, no. 1 (2015), pp. 83–100。 [返回](#ref-zh-ch04-9)

<a id="ch04-n009-en"></a><a id="note-en-ch04-9"></a>
[9] Lonzi, ‘12 May 1973’, in *Taci, anzi parla*, p. 378. For a discussion of Lonzi’s use of the term ‘myth’ and its reference to Roland Barthes’s writings, see Francesco Ventrella, ‘Carla Lonzi e la disfatta della critica d’arte: registrazione, scrittura e risonanza’*, Studi Culturali*, vol. 12, no. 1 (2015), pp. 83–100. [返回](#ref-en-ch04-9)

<a id="ch04-n010-zh"></a><a id="note-zh-ch04-10"></a>
[10] Carla Lonzi, *Vai pure. Dialogo con Pietro Consagra*, Milan: Scritti di Rivolta Femminile, 1980; Milan: et al., 2011。此后所有引文均依据2011年版。卡拉·隆齐与彼得罗·孔萨格拉在1960年代初相识，作为伴侣共同生活了近二十年。彼得罗·孔萨格拉（1920—2005）是意大利同代最重要的艺术家之一，主要以抽象雕塑、与意大利共产党（PCI）的接近，以及参与二战后意大利形式主义美学而闻名，尤其是作为艺术家团体“形式1”（Forma 1）的成员，该团体自认兼具马克思主义与形式主义。 [返回](#ref-zh-ch04-10)

<a id="ch04-n010-en"></a><a id="note-en-ch04-10"></a>
[10] Carla Lonzi, *Vai pure. Dialogo con Pietro Consagra*, Milan: Scritti di Rivolta Femminile, 1980; Milan: et al., 2011. All subsequent quotations refer to the 2011 edition. Carla Lonzi and Pietro Consagra met in the early 1960s and had lived as a couple for almost twenty years. Pietro Consagra (1920–2005) counts among the most significant Italian artists of his generation, mostly known for his abstract sculptures, his closeness to the PCI (Italian Communist Party) and his engagement in post-World War II formalist aesthetics in Italy, most notably as part of the artist collective Forma 1, which considered itself both Marxist and formalist. [返回](#ref-en-ch04-10)

<a id="ch04-n011-zh"></a><a id="note-zh-ch04-11"></a>
[11] Lonzi, *Vai pure*, p. 81。 [返回](#ref-zh-ch04-11)

<a id="ch04-n011-en"></a><a id="note-en-ch04-11"></a>
[11] Lonzi, *Vai pure*, p. 81. [返回](#ref-en-ch04-11)

<a id="ch04-n012-zh"></a><a id="note-zh-ch04-12"></a>
[12] 同上，第13页。 [返回](#ref-zh-ch04-12)

<a id="ch04-n012-en"></a><a id="note-en-ch04-12"></a>
[12] Ibid., p. 13. [返回](#ref-en-ch04-12)

<a id="ch04-n013-zh"></a><a id="note-zh-ch04-13"></a>
[13] 同上，第7页。 [返回](#ref-zh-ch04-13)

<a id="ch04-n013-en"></a><a id="note-en-ch04-13"></a>
[13] Ibid., p. 7. [返回](#ref-en-ch04-13)

<a id="ch04-n014-zh"></a><a id="note-zh-ch04-14"></a>
[14] 同上，第49页。 [返回](#ref-zh-ch04-14)

<a id="ch04-n014-en"></a><a id="note-en-ch04-14"></a>
[14] Ibid., p. 49. [返回](#ref-en-ch04-14)

<a id="ch04-n015-zh"></a><a id="note-zh-ch04-15"></a>
[15] 见罗齐卡·帕克与格里塞尔达·波洛克同时期对艺术家男性气质与特权的解构，Rozsika Parker and Griselda Pollock, *Old Mistresses: Women, Art and Ideology*, London: Pandora, 1981; London: Bloomsbury, 2020。 [返回](#ref-zh-ch04-15)

<a id="ch04-n015-en"></a><a id="note-en-ch04-15"></a>
[15] See Rozsika Parker and Griselda Pollock’s concomitant deconstruction of the artist’s masculinity and privilege in Rozika Parker and Griselda Pollock, *Old Mistresses:* *Women, Art and Ideology*, London: Pandora, 1981; London: Bloomsbury, 2020. [返回](#ref-en-ch04-15)

<a id="ch04-n016-zh"></a><a id="note-zh-ch04-16"></a>
[16] Lonzi, ‘3 December 1975’, *Taci anzi parla*, p. 1174。 [返回](#ref-zh-ch04-16)

<a id="ch04-n016-en"></a><a id="note-en-ch04-16"></a>
[16] Lonzi, ‘3 December 1975’, *Taci anzi parla*, p. 1174. [返回](#ref-en-ch04-16)

<a id="ch04-n017-zh"></a><a id="note-zh-ch04-17"></a>
[17] Lonzi, *Vai pure*, p. 9。关于卡拉·隆齐《你可以走了》中爱与自主的困境，见 Lea Melandri, *Una visceralità indicibile. La pratica dell’inconscio nel movimento delle donne degli anni settanta*, Rome: Franco Angeli, 2000, pp. 43–50。 [返回](#ref-zh-ch04-17)

<a id="ch04-n017-en"></a><a id="note-en-ch04-17"></a>
[17] Lonzi, *Vai pure*, p. 9. On the dilemma between love and autonomy in Carla Lonzi’s *Vai pure*, see Lea Melandri, *Una visceralità indicibile. La pratica dell’inconscio nel* *movimento delle donne degli anni settanta*, Rome: Franco Angeli, 2000, pp. 43–50. [返回](#ref-en-ch04-17)

<a id="ch04-n018-zh"></a><a id="note-zh-ch04-18"></a>
[18] Lonzi, *Vai pure*, p. 10。 [返回](#ref-zh-ch04-18)

<a id="ch04-n018-en"></a><a id="note-en-ch04-18"></a>
[18] Lonzi, *Vai pure*, p. 10. [返回](#ref-en-ch04-18)

<a id="ch04-n019-zh"></a><a id="note-zh-ch04-19"></a>
[19] 同上，第103页。 [返回](#ref-zh-ch04-19)

<a id="ch04-n019-en"></a><a id="note-en-ch04-19"></a>
[19] Ibid., p. 103. [返回](#ref-en-ch04-19)

<a id="ch04-n020-zh"></a><a id="note-zh-ch04-20"></a>
[20] 见 Lonzi, ‘Let’s Spit on Hegel’, p. 288。在英译本中，意大利语 *deculturizzazione* 被译为“shedding of culture”（卸除文化）。参见 *Sputiamo su Hegel*, p. 47。 [返回](#ref-zh-ch04-20)

<a id="ch04-n020-en"></a><a id="note-en-ch04-20"></a>
[20] See Lonzi, ‘Let’s Spit on Hegel’, p. 288. In the English version the Italian *deculturizzazione* is translated as ‘shedding of culture’. Cf. *Sputiamo su Hegel*, p. 47. [返回](#ref-en-ch04-20)

<a id="ch04-n021-zh"></a><a id="note-zh-ch04-21"></a>
[21] 沿此思路，隆齐的著作可以在杰克（朱迪斯）·哈尔伯斯塔姆所谓的“影子女性主义”框架内得到富有成效的讨论；这是一种另类女性主义计划，其谱系可追溯至1970年代，代表者如莫妮克·维蒂格和瓦莱丽·索拉纳斯。见 Judith (Jack) Halberstam, *The Queer Art of Failure*, Durham NC: Duke University Press, 2011, pp. 4, 123–45。 [返回](#ref-zh-ch04-21)

<a id="ch04-n021-en"></a><a id="note-en-ch04-21"></a>
[21] Following this line of reasoning, Lonzi’s writings could be productively addressed within the framework of what Jack (Judith) Haberstam has called a ‘shadow feminism’, or an alternative feminist project whose genealogy may be traced back to the 1970s with figures such as Monique Wittig and Valerie Solanas. See Judith (Jack) Halberstam, *The* *Queer Art of Failure*, Durham NC: Duke University Press, 2011, pp. 4, 123–45. [返回](#ref-en-ch04-21)

<a id="ch04-n022-zh"></a><a id="note-zh-ch04-22"></a>
[22] 见 Carla Lonzi, ‘La donna clitoridea e la donna vaginale’ (1971), in *Sputiamo su Hegel*, pp. 102–3。 [返回](#ref-zh-ch04-22)

<a id="ch04-n022-en"></a><a id="note-en-ch04-22"></a>
[22] See Carla Lonzi, ‘La donna clitoridea e la donna vaginale’ (1971), in *Sputiamo su* *Hegel*, pp. 102–3. [返回](#ref-en-ch04-22)

<a id="ch04-n023-zh"></a><a id="note-zh-ch04-23"></a>
[23] Carla Lonzi, ‘Itinerario di riflessioni’, in M.G. Chinese, C. Lonzi, M. Lonzi and A. Jaquinta, *È già politica*, Milan: Scritti di Rivolta femminile, 1977, p. 22。 [返回](#ref-zh-ch04-23)

<a id="ch04-n023-en"></a><a id="note-en-ch04-23"></a>
[23] Carla Lonzi, ‘Itinerario di riflessioni’, in M.G. Chinese, C. Lonzi, M. Lonzi and A. Jaquinta, *È già politica*, Milano: Scritti di Rivolta femminile, 1977, p. 22. [返回](#ref-en-ch04-23)

<a id="ch04-n024-zh"></a><a id="note-zh-ch04-24"></a>
[24] Liliana Ellena, ‘Carla Lonzi e il neo-femminismo degli anni ’70: disfare la cultura, disfare la politica’, in L. Conte, V. Fiorino and V. Martini, eds, *Carla Lonzi: la duplice radicalità*, Pisa: ETS, 2011, pp. 136–7。 [返回](#ref-zh-ch04-24)

<a id="ch04-n024-en"></a><a id="note-en-ch04-24"></a>
[24] Liliana Ellena, ‘Carla Lonzi e il neo-femminismo degli anni ’70: disfare la cultura, disfare la politica’, in L. Conte, V. Fiorino and V. Martini, eds, *Carla Lonzi: la duplice* *radicalità*, Pisa: ETS, 2011, pp. 136–7. [返回](#ref-en-ch04-24)

<a id="ch04-n025-zh"></a><a id="note-zh-ch04-25"></a>
[25] Maria Luisa Boccia, *L’io in rivolta. Pensiero e vissuto in Carla Lonzi*, Milan: La Tartaruga, 1990, p. 119。 [返回](#ref-zh-ch04-25)

<a id="ch04-n025-en"></a><a id="note-en-ch04-25"></a>
[25] Maria Luisa Boccia, *L’io in rivolta. Pensiero e vissuto in Carla Lonzi*, Milano: La Tartaruga, 1990, p. 119. [返回](#ref-en-ch04-25)

<a id="ch04-n026-zh"></a><a id="note-zh-ch04-26"></a>
[26] Claire Fontaine, ‘We are all Clitoridian Women: Some Notes on Carla Lonzi’s Legacy’, *e-flux journal* 47, September 2013。 [返回](#ref-zh-ch04-26)

<a id="ch04-n026-en"></a><a id="note-en-ch04-26"></a>
[26] Claire Fontaine, ‘We are all Clitoridian Women: Some Notes on Carla Lonzi’s Legacy’, *e-flux journal* 47, September 2013. [返回](#ref-en-ch04-26)

<a id="ch04-n027-zh"></a><a id="note-zh-ch04-27"></a>
[27] Lonzi, *Vai pure*, p. 115。 [返回](#ref-zh-ch04-27)

<a id="ch04-n027-en"></a><a id="note-en-ch04-27"></a>
[27] Lonzi, *Vai pure*, p. 115. [返回](#ref-en-ch04-27)

<a id="ch04-n028-zh"></a><a id="note-zh-ch04-28"></a>
[28] 同上，第116页。 [返回](#ref-zh-ch04-28)

<a id="ch04-n028-en"></a><a id="note-en-ch04-28"></a>
[28] Ibid., p. 116. [返回](#ref-en-ch04-28)

<a id="ch04-n029-zh"></a><a id="note-zh-ch04-29"></a>
[29] 同上，第117页。 [返回](#ref-zh-ch04-29)

<a id="ch04-n029-en"></a><a id="note-en-ch04-29"></a>
[29] Ibid., p. 117. [返回](#ref-en-ch04-29)

<a id="ch04-n030-zh"></a><a id="note-zh-ch04-30"></a>
[30] 同上，第121页。 [返回](#ref-zh-ch04-30)

<a id="ch04-n030-en"></a><a id="note-en-ch04-30"></a>
[30] Ibid., p. 121. [返回](#ref-en-ch04-30)

<a id="ch04-n031-zh"></a><a id="note-zh-ch04-31"></a>
[31] 同上，第131页。 [返回](#ref-zh-ch04-31)

<a id="ch04-n031-en"></a><a id="note-en-ch04-31"></a>
[31] Ibid., p. 131. [返回](#ref-en-ch04-31)

<a id="ch04-n032-zh"></a><a id="note-zh-ch04-32"></a>
[32] “拒绝工作”这一说法，尤其在意大利语境中，可能指向自治马克思主义中的*工人主义*（*Operaismo*，英语作Workerism）传统。然而，卡拉·隆齐年轻时曾是意大利共产党（PCI）成员，并直言批评马克思主义政治。关于隆齐的成长岁月，见 Iamurri, *Un margine che sfugge*, pp. 26–34。关于意大利*工人主义*及其遗产，见 Steve Wright, *Storming Heaven: Class Composition and Struggle in Italian Autonomist Marxism*, London: Pluto, 2017；Sylvère Lotringer and Christian Marazzi, eds, *Autonomia: Post-political Politics*, New York: Semiotexte, 2007。 [返回](#ref-zh-ch04-32)

<a id="ch04-n032-en"></a><a id="note-en-ch04-32"></a>
[32] The expression ‘refusal of work’, especially in the Italian context, might refer to the autonomous Marxist tradition of *Operaismo* (or Workerism). However, Carla Lonzi, who was a member of the Italian Communist Party (PCI) during her youth, was vocal in criticizing Marxist politics. On Carla Lonzi’s formative years, see Iamurri, *Un margine* *che sfugge*, pp. 26–34. On Italian *Operaismo* and its legacy, see Steve Wright, *Storming* *Heaven: Class Composition and Struggle in Italian Autonomist Marxism*, London: Pluto, 2017; Sylvère Lotringer and Christian Marazzi, eds, *Autonomia: Post-political Politics*, New York: Semiotexte, 2007. [返回](#ref-en-ch04-32)

<a id="ch04-n033-zh"></a><a id="note-zh-ch04-33"></a>
[33] Rivolta Femminile, ‘Manifesto of Rivolta Femminile’ (1970), in Paola Bono and Sandra Kemp, eds, *Italian Feminist Thought: A Reader*, Oxford: Blackwell, 1991, p. 39。 [返回](#ref-zh-ch04-33)

<a id="ch04-n033-en"></a><a id="note-en-ch04-33"></a>
[33] Rivolta Femminile, ‘Manifesto of Rivolta Femminile’ (1970), in Paola Bono and Sandra Kemp, eds, *Italian Feminist Thought: A Reader*, Oxford: Blackwell, 1991, p. 39. [返回](#ref-en-ch04-33)

<a id="ch04-n034-zh"></a><a id="note-zh-ch04-34"></a>
[34] 见 Maud Anne Bracke, ‘Between the Transnational and the Local: Mapping the Trajectories and Contexts of the Wages for Housework Campaign in 1970s Italian Feminism’, *Women’s History Review*, vol. 2, no. 4, 2013, pp. 625–42。 [返回](#ref-zh-ch04-34)

<a id="ch04-n034-en"></a><a id="note-en-ch04-34"></a>
[34] See Maud Anne Bracke, ‘Between the Transnational and the Local: Mapping the Trajectories and Contexts of the Wages for Housework Campaign in 1970s Italian Feminism’, *Women’s History Review*, vol. 2, no. 4, 2013, pp. 625–42. [返回](#ref-en-ch04-34)

<a id="ch04-n035-zh"></a><a id="note-zh-ch04-35"></a>
[35] 见 Silvia Federici, ‘Wages against Housework’ (1975), in S. Federici, *Revolution at Point Zero: Housework, Reproduction, and Feminist Struggle*, Brooklyn: Autonomedia, 2012, pp. 15–22。关于意大利马克思主义女性主义视角下的女性主义拒绝工作，见 Kathi Weeks, *The Problem with Work: Feminism, Marxism, Anti-work Politics and Postwork Imaginaries*, Durham NC: Duke University Press, 2011。 [返回](#ref-zh-ch04-35)

<a id="ch04-n035-en"></a><a id="note-en-ch04-35"></a>
[35] See Silvia Federici, ‘Wages against Housework’ (1975), in S. Federici, *Revolution* *at Point Zero: Housework, Reproduction, and Feminist Struggle*, Brooklyn: Autonomedia, 2012, pp. 15–22. On the feminist refusal of work from a Marxist-feminist perspective in Italy, see Kathi Weeks, *The Problem with Work: Feminist, Marxism, Anti-work Politics and* *Postwork Imaginaries*, Durham NC: Duke University Press, 2011. [返回](#ref-en-ch04-35)

<a id="ch04-n036-zh"></a><a id="note-zh-ch04-36"></a>
[36] Federici, ‘Wages against Housework’, p. 19。 [返回](#ref-zh-ch04-36)

<a id="ch04-n036-en"></a><a id="note-en-ch04-36"></a>
[36] Federici, ‘Wages against Housework’, p. 19. [返回](#ref-en-ch04-36)

<a id="ch04-n037-zh"></a><a id="note-zh-ch04-37"></a>
[37] 这是《我们向黑格尔吐口水》处理的主要观点之一；在该文中，隆齐解构了马克思主义—黑格尔式的革命政治理解。 [返回](#ref-zh-ch04-37)

<a id="ch04-n037-en"></a><a id="note-en-ch04-37"></a>
[37] This is one of the main points addressed in ‘Let’s Spit on Hegel’, where Lonzi deconstructs the Marxist–Hegelian understanding of revolutionary politics. [返回](#ref-en-ch04-37)

<a id="ch04-n038-zh"></a><a id="note-zh-ch04-38"></a>
[38] 见 Linda Nochlin, ‘Why Have There Been No Great Women Artists?’ (1971), in *Women, Art, and Power*, New York: Harper & Row, 1988, pp. 145–78；Carol Duncan, ‘Virility and Domination in Early 20th Century Vanguard Painting’, *Artforum*, December 1973, pp. 30–39。 [返回](#ref-zh-ch04-38)

<a id="ch04-n038-en"></a><a id="note-en-ch04-38"></a>
[38] See Linda Nochlin, ‘Why Have There Been No Great Women Artists?’ (1971), in *Women, Art, and Power*, New York: Harper & Row, 1988, pp. 145–78; Carol Duncan, ‘Virility and Domination in Early 20th Century Vanguard Painting’, *Artforum*, December 1973, pp. 30–39. [返回](#ref-en-ch04-38)

## 第5章　银行里的夜间保洁：桑娅·伊韦科维奇为不可见女性所做的试镜

<a id="ch05-title-zh"></a>
## 银行里的夜间保洁：桑娅·伊韦科维奇为不可见女性所做的试镜

<a id="ch05-title-en"></a>
## Night cleaning at the bank: Sanja Iveković’s screen tests for invisible women

<a id="ch05-author-zh"></a>
克拉拉·肯普-韦尔奇

<a id="ch05-author-en"></a>
KLARA KEMP-WELCH

<a id="ch05-p001-zh"></a>
2016年，埃斯特集团银行股份公司（Erste Group Bank AG）在维也纳贝尔维德区开设了新总部——埃斯特园区（Erste Campus），由亨克·施赖克建筑事务所设计。首席执行官安德烈亚斯·特赖希尔（曾被《欧洲货币》评为2019年“年度银行家”）解释说，他想废除传统办公空间，把所有人迁入一栋建筑，使一切变得非常“开放”。埃斯特园区将成为一个“让人感觉良好”的空间，一个用于“团队建设”的空间，在那里，“员工、客户以及所有希望与我们共同塑造未来的人可以聚在一起”，从而产生一个“鼓舞人心且令人兴奋的工作场所，促进个人与团队之间的交流，增强团队凝聚力”。银行网站把该园区描述为“银行业的新型工作环境”：一种“新企业文化的办公理念”。<a id="ref-zh-ch05-1"></a>[1](#note-zh-ch05-1) 这段简介的乐观语调，与贝尔维德区本身的整体愿景一致。正如埃斯特集团网站所解释的：

<a id="ch05-p001-en"></a>
In 2016, Erste Group Bank AG opened a new headquarters – Erste Campus – in the Quartier Belvedere District in Vienna, designed by Henke Schreieck architects. CEO Andreas Treichl (named Euromoney’s ‘Banker of the Year’ 2019) has explained that he had wanted to do away with conventional office spaces and to move everyone into a single building to make everything very ‘open’. Erste Campus was to be a space ‘to feel good about’; a space for ‘team building’ where ‘staff, customers and everyone who wishes to shape the future with us can come together’ to produce an ‘inspiring and exhilarating workplace, promoting communication between individuals and teams and strengthening team cohesion’. The bank’s website describes the Campus as ‘a new working environment for banking’: an ‘office concept of new corporate culture’.<a id="ref-en-ch05-1"></a>[1](#note-en-ch05-1) The upbeat tone of this blurb is in line with the wider vision for the Quartier Belvedere itself. As the Erste Group site explains:

<a id="ch05-q001-zh"></a>
<a id="ch05-q002-zh"></a>
> 该街区的投资者将提供一种此地从未有过的工作与生活方式：入驻该街区的公司员工在工作日结束时不会立刻回家，而是与同事、居民以及旅人一起留在贝尔维德区，为一天画上积极的句号。<a id="ref-zh-ch05-2"></a>[2](#note-zh-ch05-2)

<a id="ch05-q001-en"></a>
<a id="ch05-q002-en"></a>
> investors in this district will be providing a way of living and  working here never experienced before: workers in the firms establishing themselves in this district will not immediately head for  home at the end of the working day, but will stay on in the Quartier  Belvedere together with their colleagues, with residents and with  travellers and bring the day to a positive close.<a id="ref-en-ch05-2"></a>[2](#note-en-ch05-2)

<a id="ch05-p002-zh"></a>
于是，新街区与埃斯特园区都倡导一种新的企业工作场所模式；这症候性地体现了营造新型工作环境、以支持更大“灵活性”、提高员工投入、生产率与利润的驱动力；这是欧洲银行业学习圣克拉拉谷歌总部（Googleplex）成功经验的一次实验。

<a id="ch05-p002-en"></a>
Both the new district and Erste Campus, then, champion a new approach to the corporate workplace, symptomatic of the drive to deliver new working environments supporting greater ‘flexibility’, increasing worker commitment, productivity and profits; a Euro-banking experiment in learning from the successes of Googleplex, Santa Clara.

<a id="ch05-p003-zh"></a>
埃斯特园区处处坚持使用玻璃，症候性地体现了企业建筑在观念上对透明性的依附。在采访中，米夏埃尔·维尔纳（埃斯特集团银行股份公司房地产投资与运营主管）把透明描述为“我们的核心价值之一：当你审视流程时，你知道发生了什么”。他解释说：

<a id="ch05-p003-en"></a>
The insistence on glass throughout the Erste Campus is symptomatic of corporate architecture’s conceptual attachment to transparency. In interview, Michael Werner (head of Real Estate Investment and Operations, Erste Group AG) describes transparency as ‘one of our core values: when you look into the process, you know what happens’. He explains:

<a id="ch05-q003-zh"></a>
> 透明性的承诺也应当由办公大楼来例示；因此，你能够从外部看到内部，这一点很重要。我们不向客户隐藏；处理资金的金融服务提供者似乎总是在秘密或地下的地方做些什么，没人能进入。而在这里，你可以直接看到建筑内部。

<a id="ch05-q003-en"></a>
> the promise of transparency should also be exemplified by the  office building; so it’s important that you can look into the interior  from the outside. We don’t hide from the client; financial services  providers handling money always seem to be doing something in  secret or underground, where nobody has access. Here you can look  directly into the building.

<a id="ch05-p004-zh"></a>
然而，这样的工作环境也带来挑战：

<a id="ch05-p004-en"></a>
Nevertheless, such a working environment brings challenges:

<a id="ch05-q004-zh"></a>
> 透明不是一个轻松的话题；对人来说有时非常困难。在开放空间里、桌面整洁地工作，意味着完全透明……我们需要特定的工作环境，才能真正高效或富有创造力。

<a id="ch05-q004-en"></a>
> Transparency is not an easy topic; sometimes it is very difficult  for people. Working in an open space with a clean desk means full  transparency … we need a specific working environment in order to  be really efficient or creative.

<a id="ch05-p005-zh"></a>
当被问及为何觉得有必要为该项目制作一本“氛围手册”时，维尔纳解释说：

<a id="ch05-p005-en"></a>
Asked about why he had felt the need to produce a ‘mood book’ for the project, Werner explains:

<a id="ch05-q005-zh"></a>
<a id="ch05-q006-zh"></a>
> 开发企业总部的过程并不意味着把公司的企业身份转译为物理空间。相反，它是要理解品牌态度，并将其转化为一种品牌氛围。理想情况下，品牌不应对园区使用者或访客过于可见——相反，他们应当感受到它。

<a id="ch05-q005-en"></a>
<a id="ch05-q006-en"></a>
> The process of developing corporate headquarters does not imply  translating the corporate identity of the company into physical  space. Instead, it is to understand the brand attitude and to transform it into a brand atmosphere. Ideally, the brand should not  be too visible to the user or a visitor to the Campus – instead, they  should feel it.

<a id="ch05-p006-zh"></a>
他接着说：

<a id="ch05-p006-en"></a>
He goes on:

<a id="ch05-q007-zh"></a>
> 我们想传达埃斯特如何看待某些问题、我们如何看待事物、我们希望客户如何看待我们和我们的工作。这与我们的顾问工作有关，与我们如何对待客户和员工有关，也与我们在日常业务中希望如何行事有关。<a id="ref-zh-ch05-3"></a>[3](#note-zh-ch05-3)

<a id="ch05-q007-en"></a>
> we wanted to convey how Erste thinks about certain issues, how  we see things, how we want clients to see us and our work. This is  related to our advisor work and how we treat both customers and  employees, and how we want to conduct ourselves in daily business.<a id="ref-en-ch05-3"></a>[3](#note-en-ch05-3)

<a id="ch05-p007-zh"></a>
埃斯特集团是“中欧和东欧最大的金融服务提供者之一”，<a id="ref-zh-ch05-4"></a>[4](#note-zh-ch05-4) 拥有47,000名员工，核心市场在奥地利、克罗地亚、捷克共和国、匈牙利、罗马尼亚、塞尔维亚和斯洛伐克，次级市场在波斯尼亚、摩尔多瓦、黑山、北马其顿和斯洛文尼亚。<a id="ref-zh-ch05-5"></a>[5](#note-zh-ch05-5) 公司创新中心（Erste HUB）负责人鲍里斯·马特强调了这一历史地点对于总部选址的特殊意义：

<a id="ch05-p007-en"></a>
The Erste Group is ‘among the largest financial service providers in Central and Eastern Europe’,<a id="ref-en-ch05-4"></a>[4](#note-en-ch05-4) with 47,000 employees, and core markets in Austria, Croatia, Czech Republic, Hungary, Romania, Serbia and Slovakia, as well as secondary markets in Bosnia, Moldova, Montenegro, North Macedonia and Slovenia.<a id="ref-en-ch05-5"></a>[5](#note-en-ch05-5) Boris Marte, head of the company’s Innovation Centre (Erste HUB) stresses the particular relevance of the historic site for the location of the headquarters:

<a id="ch05-q008-zh"></a>
> 我们把场地建在“南站”（Südbahnhof）旧址上，那是这座城市南面的火车站……1960和70年代，数十万来自共产主义东欧的人抵达这座车站，寻找某种类似自由的东西……1970年代，数十万来自苏联的犹太人也来到这里，然后继续前往以色列……南站曾在铁幕仍然存在的时代作为重要枢纽拥有自己的历史。这是人们来往于东方与东南方之间的唯一火车站。在这样一个地方建设一家在这些国家有着强大存在的公司，承载着某种信息。<a id="ref-zh-ch05-6"></a>[6](#note-zh-ch05-6)

<a id="ch05-q008-en"></a>
> We constructed our venue on the former site of the ‘Südbahnhof’,  the city’s southern railway station… In the 1960s and 70s, hundreds  of thousands of people from communist Eastern Europe arrived at  this train station to look for something like freedom … in the 1970s,  hundreds of thousands of Jews from the Soviet Union also arrived  here and then travelled on to Israel … the Südbahnhof had its history  as an important hub at a time when the iron curtain still existed.  This was the only train station where people moved back and forth  between the East and the Southeast. Building a company that is  strongly represented in those countries in that very place carries a  certain message.<a id="ref-en-ch05-6"></a>[6](#note-en-ch05-6)

<a id="ch05-p008-zh"></a>
这一“信息”想必意在提醒人们维也纳曾是其前社会主义邻国的中转站；但这座庞大建筑的拆除以及新商业区的建设，也标志着优先事项的重大转变。如果这一地点曾经编排着人员跨越国境的流动，那么如今它主要被设计为资本流动的枢纽。

<a id="ch05-p008-en"></a>
The ‘message’ is presumably intended to be a reminder of Vienna’s role as a way station for its former socialist neighbours, but the demolition of the massive structure and the construction of the new business district also mark a significant shift in priorities. If the site once orchestrated the flow of people across borders, it is now primarily designed in as a hub for the flow of capital.

<a id="ch05-p009-zh"></a>
银行对前东方阵营“回馈”的承诺，更清楚地体现在其慈善分支埃斯特基金会（ERSTE Foundation）上；在乔治·索罗斯从1990年代的当代艺术中心网络中撤资后，该地区新兴当代艺术界留下资金缺口，而基金会一直是填补这一缺口的主要力量。基金会致力于三个核心领域：“社会创新、欧洲凝聚与民主、当代文化”，并参与了广泛的文化计划：创立康塔克特收藏（Kontakt Collection）——埃斯特集团与埃斯特基金会的艺术收藏——专门收藏该地区的现代与当代艺术；资助 Tranzit——一个“在奥地利、罗马尼亚、斯洛伐克、捷克共和国和匈牙利开展当代艺术自主计划的网络”；并赞助伊戈尔·扎贝尔文化与理论奖等。<a id="ref-zh-ch05-7"></a>[7](#note-zh-ch05-7) 基金会还发布在线访谈与故事，主题包括罗姆儿童教育及斯洛伐克学校的隔离、克罗地亚的制药污染、波斯尼亚未能安置流离失所者、波兰与欧盟的冲突路线、波斯尼亚—克罗地亚边境营地中难民的困境、科索沃的青年，以及保加利亚维丁的凋敝——那里被称为“世界人口衰退之都”。<a id="ref-zh-ch05-8"></a>[8](#note-zh-ch05-8) 因此，基金会致力于介入与后社会主义语境相关的一系列广泛人权与平等问题。

<a id="ch05-p009-en"></a>
The bank’s commitment to ‘giving back’ to the former East is better evidenced by its philanthropic wing, the ERSTE Foundation, which has been the main plug for the funding gap left in the region’s emerging contemporary art world after George Soros pulled his money out of the 1990s’ network of Centres for Contemporary Art. The Foundation is devoted to three core areas: ‘social innovation, European cohesion and democracy and contemporary culture’ and has engaged in a wide range of cultural initiatives: the founding of the Kontakt Collection – the Erste Group and ERSTE Foundation art collection – dedicated to modern and contemporary art from the region; the funding of the Tranzit – a ‘network of autonomous initiatives in contemporary art in Austria, Romania, Slovakia, Czech Republic and Hungary’; and the sponsoring of the Igor Zabel Award for Culture and Theory, among others.<a id="ref-en-ch05-7"></a>[7](#note-en-ch05-7) The Foundation also publishes online interviews and stories on topics such as the education of Roma children and segregation in Slovak schools, pharma pollution in Croatia, Bosnia’s failure to house its displaced, Poland’s collision course with the EU, the plight of refugees in camps on the Bosnian–Croatian border, the youth of Kosovo, and the emptying of Bulgaria’s Vidin, ‘the world capital of population decline’.<a id="ref-en-ch05-8"></a>[8](#note-en-ch05-8) The Foundation, then, is committed to engaging with a wide range of human rights and equality issues relevant to the post-socialist context.

<a id="ch05-p010-zh"></a>
当埃斯特集团开始考虑如何在园区中运用艺术时，他们很想避免把艺术当作一种通用的企业室内设计形式（大幅面、抽象绘画、全球摄影）。园区《氛围手册》明确指出：“没有法律规定企业总部的墙上必须装饰艺术。我们只在认为艺术具有相关性、并且能够为埃斯特园区的所有使用者和访客带来灵感的地方展示艺术。”在为新园区委托创作艺术品时，集团选择了中欧和东欧艺术家的新作，这些作品“要求艺术家不仅考虑埃斯特集团运营所在的地缘政治区域语境，还要在项目中参照埃斯特园区建筑的特征及其位于南站旧址的位置”。<a id="ref-zh-ch05-9"></a>[9](#note-zh-ch05-9) 该项目后来被称为“建筑中的艺术”，是与康塔克特收藏负责人卡特琳·罗姆贝格的合作。策展人兼联合委托方皮埃尔·巴尔-布朗解释说，该项目旨在“重新思考艺术与资本的关系，并考察当使用者、银行家和雇主这些在这家金融企业场所交汇的视角彼此趋同或相互矛盾时，被强加的妥协”。他还说：“任何在私人土地上发展的计划都有其盲点，一种被压抑的意识，一旦展览结束便显露出来……暴露出使这家银行重新焕发活力的矛盾的生机。”<a id="ref-zh-ch05-10"></a>[10](#note-zh-ch05-10)

<a id="ch05-p010-en"></a>
When Erste Group came to consider how they would deploy art as part of the Campus, they were keen to avoid using it as a generic form of corporate interior design (large format, abstract painting, global photography). The Campus ‘Mood Book’ explicitly makes the point that ‘there is no law stating that the walls of corporate headquarters have to be adorned with art. We only display art where we believe it has relevance and can be an inspiration for all Erste Campus users and visitors.’ In commissioning artwork for its new campus, the Group opted for new work by artists from central and eastern Europe which ‘required the artists not only to take into account the context of the geopolitical area in which Erste Group operates, but also to make reference in the projects to the character and location of the Erste Campus building on the former site of the Südbahnhof railway station’.<a id="ref-en-ch05-9"></a>[9](#note-en-ch05-9) ‘Art in Architecture’, as the project came to be called, was a collaboration with Kathrin Rhomberg, head of the Kontakt collection. The curator and co-commissioner, Pierre Bal-Blanc, explained that the project was about ‘rethinking the relationship between art and capital, and examining the compromises imposed when the viewpoints of users, bankers and employers who cross paths at the site of this financial enterprise converge or contradict one another’. He added that ‘Any initiative developed on private terrain has its blind spot, a repressed consciousness that reveals itself once the exhibit is finished … exposing the vitality of contradictions that revitalize this bank.’<a id="ref-en-ch05-10"></a>[10](#note-en-ch05-10)

<a id="ch05-p011-zh"></a>
本文对园区及其抱负的简短介绍所引用的许多埃斯特代表陈述，是由克罗地亚艺术家桑娅·伊韦科维奇收集的，作为她为影片《埃斯特园区里不可见的女性》进行的“田野调查”的一部分；该片由她编剧和导演，并作为“建筑中的艺术”委托项目的一部分在园区内展出。埃斯特园区建筑面积广阔，达165,000平方米。当伊韦科维奇问马特，他认为园区里有多少清洁工时，他回答说：“我猜在100到150之间。”伊韦科维奇温和地反驳：“我也是这么想的，但实际只有58人。”她解释说：“作为女性主义者，我感兴趣的是女性在这里工作的处境和条件。当我受邀做一个项目，看到这座巨大的建筑时，我脑中浮现的第一个问题是：谁在清洁这一切？因此，我的项目是关于清洁女工的。”<a id="ref-zh-ch05-11"></a>[11](#note-zh-ch05-11) 关于埃斯特代表希望通过园区设计传达的“感受”之性质，伊韦科维奇指出：“你们强调想看到每个人，也让人人可见，能够与每个人交谈并沟通。我正在做的项目——讨论交流以及在这里受雇的每个人——追求的是同一个目标。”<a id="ref-zh-ch05-12"></a>[12](#note-zh-ch05-12) 《埃斯特园区里不可见的女性》试图检验该集团对“透明”的企业承诺，其方式确保清洁这栋建筑的女性被楼里的每个人看见。这部与清洁女工合作完成的影片，是对她们不可见劳动的一首颂歌。影片在A—F座0—9层电梯厅的一系列显示器上播放。<a id="ref-zh-ch05-13"></a>[13](#note-zh-ch05-13)

<a id="ch05-p011-en"></a>
Many of the statements by Erste representatives cited in this brief introduction to the Campus and its ambitions were gathered by Croatian artist Sanja Iveković as part of her ‘field research’ for a film piece entitled *The Invisible Women of the* *Erste Campus*, which she wrote and directed, and installed on Campus as part of the ‘Art in Architecture’ commission. The floor area of Erste Campus is vast, standing at 165,000 m2. When Iveković asked Marte how many cleaners he thought there are on Campus, he replied: ‘I guess between 100 and 150’. Iveković countered gently: ‘That’s what I thought, too, but there are only 58.’ She explained: ‘As a feminist I’m interested in the situation and the conditions under which women are working here. When I was invited to do a project and saw the big building, the first question that came to my mind was, who’s cleaning all this? Thus, my project is about the cleaning ladies.’<a id="ref-en-ch05-11"></a>[11](#note-en-ch05-11) With reference to the nature of the ‘feeling’ Erste representatives wanted to convey through the Campus design, Iveković noted: ‘you stressed you wanted to see everybody and also everybody to be seen, to be able to talk to everyone and communicate with them. The project I’m working on – talking about communication and everybody who is employed here – is pursuing the same goal.’<a id="ref-en-ch05-12"></a>[12](#note-en-ch05-12) *The Invisible Women of the Erste Campus* set out to test the Group’s corporate commitment to ‘transparency’ by making sure that the women who clean the building were made visible to everyone in the building. The film, made collaboratively with the cleaners, is an ode to their invisible labour. It is played on a series of monitors in the Elevator areas of Levels 0–9 in Building A–F.<a id="ref-en-ch05-13"></a>[13](#note-en-ch05-13)

<a id="ch05-p012-zh"></a>
影片在黑暗中开场；细雨蒙蒙，车流轰鸣，镜头环摇过一组弧形的玻璃幕墙办公楼，楼内灯光昏暗。画面转向其中一栋楼的入口，我们听到清晨的鸟鸣。外面仍然黑着，穿牛仔裤和夹克的女人们开始穿过巨大的玻璃门，走进门厅。她们进入时，我们听到一连串名字：安杰拉、安杰利卡、佐尔蒂、埃尔维拉、玛丽亚娜、索菲娅、戈尔达娜、德拉加娜、米尔卡、巴尔塔、莉迪娅、米格蕾塔，还有更多。镜头跳转到一条长长的后勤走廊，头顶是红色管道，随后又转向一间空更衣室，里面有窄长凳和整齐排列的实用鞋与运动鞋；鞋的主人们已换上制服，开始值班。穿着白T恤、系着海军蓝与白色条纹围裙的女人们在一间储藏室里，把按颜色编码的抹布装进灰色塑料托盘。她们默默地做着这项工作，每个人都专注于例行事务。装好清洁用品后，她们把灰色塑料托盘叠起来，系上背带，然后沿走廊返回。清洁团队出发时，一队厨房员工从旁经过，她们戴着塑料发罩，推着摆满托盘和餐饮设备的金属推车。

<a id="ch05-p012-en"></a>
The film opens in the dark; there is light drizzle and the roar of traffic as the camera pans around a series of curved, glass- fronted office blocks, their lights dimmed. The view shifts to the entrance to one of the blocks, and we hear early-morning bird song. It is still dark outside, when women in jeans and jackets begin to walk through the large glass doors and into the lobby. As they enter, we hear a rollcall of names: Angela, Angelika, Zolti, Elvira, Marijana, Sofia, Gordana, Dragana, Milka, Balta, Lidia, Migreta, and more. The camera jumps to a long service corridor with red pipes overhead and then to an empty locker room, with narrow benches and neat rows of practical shoes and trainers; their owners have changed into uniforms and are beginning their shifts. Women in white T-shirts and navy-and-white striped aprons are in a storeroom, loading grey plastic trays with colour-coded cloths. They go about this work silently, each focused on the routine. Having loaded up with cleaning supplies, they stack the grey plastic trays and attach carry straps before heading back up the corridor. As the cleaning team heads out, a team of kitchen staff pass by, wearing plastic hair coverings and wheeling metal trolleys ranged with trays and catering equipment.

<a id="ch05-p013-zh"></a>
画面渐变为刺眼的白，一位面容和善、深色头发别在耳后的中年女人在素净背景前特写出现，微微一笑。出人意料的是，她用母语背诵了一首诗的三个诗行。她面部的镜头淡出，我们读到英文插字幕：“我从南方来／无论我去往何处／苔藓总跟着我”。背景中，物件碰撞的声响持续不断，像劳动的合唱。另一位女人接着上场，说出她的诗句：她也是中年，这次是金发，戴着耳环，微笑着，带着浓重的斯拉夫口音，微微出汗。她穿着同样的制服。插字幕传达一种惬意的休息状态：“星期天来临时／我躺在荫影里／那是我家谱树的荫影”，尽管最后一行“我是那根折断的树枝”带有一丝忧郁和孤立感。然而，当我们试图欣赏这诗时，吸尘器发出震耳欲聋的嗡鸣，令人不快地持续着，与诗所传达的平静状态形成鲜明对比。

<a id="ch05-p013-en"></a>
The screen fades to a blinding white and a middle-aged woman with pleasant features and dark hair tucked behind her ears is shown close up against a plain background, smiling lightly. Unexpectedly, she recites three lines of a poem in her native language. The shot of her face fades out and we read the English intertitle: ‘I came from the South / Wherever I go / the moss keeps following me’. In the background, the sound of objects clattering about continues like a chorus of labour. Another woman takes her turn, and says her piece: she is also middle-aged, this time blonde, with earrings, smiling, in a deep Slavonic accent, slightly perspiring. She wears the same uniform. The intertitle conveys a pleasurable state of rest: ‘When Sunday comes / I lie down in the shade / Of my family tree’, though this is tinged with melancholy and a sense of isolation in the final line, which reads: ‘I am the branch that broke off’. As we try to appreciate the poetry, though, there is a deafening drone of hoovering, unpleasantly insistent and in stark contrast with the state of calm conveyed by the poem.

<a id="ch05-p014-zh"></a>
建筑外景显示，穿制服的清洁女工在每一层工作，日出映照在弧形建筑群的玻璃楼层中。开放式设计中设有数百个工作位，每个都有各自的清洁难题。清洁是全身性的工作，女人们执行各种各样的任务：推车、吸尘、掸灰。她们伸手越过圆桌擦拭桌面；俯身清洁桌下，一只手拉出椅子，另一只手引导吸尘器；擦净每一种可想象的表面——桌子、椅子、椅背、橱柜、咖啡桌、复印机、马桶（座圈、座圈背面、圈缘下方、底座周围）、水槽、水龙头、镜子；从洗碗机中取出餐具，把餐具摆上架子；更换垃圾袋。在食堂厨房里，穿白T恤、套蓝色一次性塑料围裙、戴黑手套的女人们在传送带上工作，分拣盘子、托盘、杯子，把食物残渣刮进垃圾桶；那里是一片不停歇的活动蜂巢。在洗碗机的另一侧，更多女人把干净餐具分类堆放并运走。工作单调乏味，而传送带不停运转这一事实使其变得无休无止。一些系橙色围裙的男人在相邻空间工作，也许是厨房搬运工。许多被清洁的空间是混合性与辅助性空间，而非严格意义上的工作空间：白领员工的公共休息室，摆放矮桌和报纸的休息处。桌子已为早晨的会议摆好，咖啡杯和瓶装水准备就绪，舒适而有品位的办公椅，与窗外晨光中的城市景观一样诱人。女人们使用各式各样的旋转拖把和清洁用品，从粉色清洁液到外科手套。她们以大幅度的动作来回、打圈擦拭，打磨到一切闪闪发亮。她们填写清洁记录表，注明厕所已清洁。随着清洁推进，太阳升起，白天到来：白领员工和客户开始抵达。当他们到达时，清洁女工正在擦拭玻璃旋转门。

<a id="ch05-p014-en"></a>
An exterior view of the building reveals uniformed cleaners working on every floor, as the sunrise is reflected in the glass stories of the curved complex. There are hundreds of workstations in the open-plan design, each with its own cleaning challenges. The cleaning is full body work and the women perform a wide range of tasks: wheeling trolleys, hoovering, dusting. They reach across round tables to wipe them; lean down to clean underneath desks, pulling out chairs with one hand and directing the hoover with the other; wipe down every imaginable surface – tables, chairs, backs of chairs, cupboards coffee tables, photocopiers, toilets (seats, backs of seats, under the rims, around the pedestals), sinks, taps, mirrors; unload dishwashers, stack crockery on shelves; change bin-liners. Women in white T-shirts in blue plastic disposable aprons and black gloves work on a conveyer belt in the kitchens of the canteen, sorting plates, trays, cups, scraping remains of food into bins; it is a hive of relentless activity. On the other side of the dishwasher, more women sort clean crockery into piles and take it away. The work is monotonous and made relentless by the fact it is a conveyer belt that just keeps going. Some men in orange aprons work in the adjacent space, perhaps as kitchen porters. Many of the spaces being cleaned are hybrid and auxiliary spaces rather than workspaces per se: common rooms for the white-collar workers, resting places with low tables and newspapers. Tables are set up for the morning’s meetings, coffee cups and bottled waters at the ready, comfortable tasteful office chairs as inviting as the view of the city in the morning sunshine beyond. The women wield all manner of swivel-mops and products, from pink cleaning fluid to surgical gloves. They wipe with sweeping movements to and fro, round and round, polishing until everything gleams. Time sheets are filled out to show that the toilets have been cleaned. As the cleaning progresses, the sun rises and it is daytime: the white collar workers and clients begin to arrive. As they do, the cleaning women polish the glass turn-style doors.

<a id="ch05-p015-zh"></a>
摄影机无声见证着这片在条形灯光下展开的大量活动。垃圾与污垢只在被消失的过程中被短暂瞥见。镜头角度聚焦于女人们双手的灵巧，以及她们熟练动作的细微之处。她们常常优雅如舞的动作，仿佛经过编排，与建筑相流动：她们沿着宽敞的楼梯往下走、边走边拖地时，场景从下方拍摄。白色门厅那些微缩的尼迈耶式曲线，与接待台流线型的金属带相得益彰；接待台上装饰着一排新鲜红色剑兰的花瓶。其他空间也点缀着盆栽和炫耀性的企业花艺（无疑是通过一系列分包商采购的）。繁多的室内设计元素与照明装置争相吸引我们的注意：天花板上点缀着星系般的LED灯，还有立柱、圆形悬浮墙，而相似却不同的空间之间的通道似乎没有尽头。镜头似乎在嘲弄所有这些品味上的努力，更感兴趣的是待清洁的大量表面。影片中有一处，一位女人在典型地宽阔的空间（12层高管会议区）吸尘。背景中，我们看到一张投影照片：一个高大、裸体、秃顶的男人——萨格勒布艺术家托米斯拉夫·戈托瓦茨，出自他的影像作品《守望莱茵河》（*Watch on the Rhine*，1994），作于南斯拉夫战争期间；他在这件作品中花数小时眺望萨格勒布城，站在克罗地亚艺术家协会屋顶上充当“清真寺守卫”的哨兵（该建筑曾在1940年代被穆斯林社群用作清真寺）。当代的清洁女工照常工作，仿佛那影像并不存在，忽略那个越过她望去的裸体男人——他的目光越过上方，投向远处的城市。摄影机穿行建筑的段落伴随着嗖嗖擦洗与咔嗒声响构成的打击乐：拖把在抛光混凝土地面上划出无尽的圈，吸尘器嗡鸣，餐具叮当作响，而这一切都弥漫着一种安静的电子滋滋声。这是一个完全人造的工作环境，清洁工的大量劳动发生在无窗的混凝土与金属后勤区域，与办公空间中大量的木材和玻璃形成对比。值班结束时，伊韦科维奇镜头中的女人们把清洁抹布放进两台大型洗烘一体机：右侧放粉色和黄色抹布，左侧放蓝色和绿色抹布。想必不同抹布用于不同工作，但人们也感到伊韦科维奇或许在此还作出一种艺术类比：她们的劳动和她的劳动一样涉及审美选择，尽管方式极为不同。往机器里装填抹布，让我们想到下一班接班的工人：她们会先取出这些洗好的抹布，再次启动整个日常循环。

<a id="ch05-p015-en"></a>
The camera plays silent witness to this mass of strip-lit activity. Waste and dirt are glimpsed only fleetingly, in the process of being disappeared. The camera angles focus on the manual dexterity of the women and the minutiae of their expert movements. Their often graceful, dance-like movements appear choreographed to flow with the architecture: scenes are shot from below as they make their way down the generous staircases, mopping as they go. The micro-Niemeyerian curves of the white lobby are complemented by the aerodynamic metal swathe of a welcome desk, adorned with a series of vases of fresh red gladioli. Other spaces are also dotted with potted plants and ostentatious corporate flower arrangements (doubtless procured through a series of subcontractors). A plethora of internal design features and lighting fixtures vie for our attention: the ceilings are dotted with a galaxy of LED lights, there are columns, circular floating walls, and the passage between the similar but different spaces seems endless. The camera seems to mock all these efforts at taste, more interested in the masses of surfaces to be cleaned. At one point in the film a woman is shown hoovering a characteristically expansive space (Executive Meeting Area, Level 12). In the background we see a projected photo of a tall, naked, balding man – Zagreb artist Tomislav Gotovac, in his video piece *Watch on the Rhine* (1994), made during the Yugoslav wars, which involved him spending hours looking across the city of Zagreb, standing sentry as a ‘mosque guard’ on the roof of the Croatian Association of Artists (once used as a mosque by the Muslim community in the 1940s). The contemporary cleaner goes about her work as though the image were not there, ignoring the naked man looking past her, his gaze directed above and away, to the city beyond. The passage of the camera through the building is accompanied by a percussion of swish-swashing and clicking as mops make endless loops of polished concrete floors, while hoovers drone and dishes clatter, all pervaded by a quiet electronic buzz. It is an entirely artificial working environment and much of the cleaners’ labour takes place in windowless concrete and metal service areas, in contrast to the abundance of wood and glass in the office spaces. At the end of their shift, Iveković’s subjects put their cleaning cloths into two large washer dryers: pink and yellow cloths on the right, blue and green cloths on the left. Presumably the different cloths are for different jobs, though one senses Iveković may also be drawing an artistic analogy here too: their labour, like hers, is involved with aesthetic choices, though in very different ways. The loading of the machines reminds us of those that will come on in the next shift, and begin by unloading these same, washed cloths, to restart the whole daily cycle once more.

<a id="ch05-p016-zh"></a>
工人们受雇，以不可见的方式抹去其他工人的痕迹，让一栋气派的玻璃幕墙建筑看起来像新的一样。这一情境呼应了杰夫·沃尔的摄影作品《晨间清洁，密斯·凡·德·罗基金会，巴塞罗那》（1999）所精心布置的场景：一名有色人种正在擦拭这座标志性玻璃建筑的地面，而庭院后方一尊古典裸体雕塑炫耀着其理想化的白色形体。或许症候性的是，泰特美术馆网站对该作品的解读起初聚焦于图像的形式构图，似乎避开了“清洁工”一词，而把这位工人先称为“服务人员”，随后称为“看管者”：

<a id="ch05-p016-en"></a>
The workers are paid to invisibly erase the traces of other workers and to make a prestigious glass-fronted building look as good as new. The situation echoes that staged so well in Jeff Wall’s photograph *Morning Cleaning Mies van der Rohe Foundation*, *Barcelona* (1999), in which a person of colour is seen mopping the floor of the iconic glass building, while a classical nude sculpture flaunts its idealized white form in the courtyard behind. Symptomatically, perhaps, the Tate website’s interpretation of the piece initially focuses on the formal composition of the images and appears to shrink from the term ‘cleaner’, referring to the worker, instead, as first an ‘attendant’ and then as a ‘custodian’:

<a id="ch05-q009-zh"></a>
> 在清晨明亮的光线中，可见陈设极简的空间。前景中，一根闪亮的钢柱几乎把构图垂直分成两半。钢柱之外，越过一大片深色地毯，一名服务人员正在清洁一面玻璃板墙。晨光照亮建筑清晰利落的线条，同时在左侧一面纹理很深的缟玛瑙墙上投下明显的阴影。在看管者准备清洁的玻璃板上，流下的水在对称图案的玻璃表面形成随意图案，部分遮住一个庭院，那里有一尊格奥尔格·科尔贝（1877—1947）的女性裸体雕塑立在池畔。<a id="ref-zh-ch05-14"></a>[14](#note-zh-ch05-14)

<a id="ch05-q009-en"></a>
> The minimally-furnished space is seen in the bright light of early  morning. In the foreground, a gleaming steel pillar divides the  composition vertically almost in half. Beyond the pillar, across an  expanse of dark carpet, an attendant is in the process of cleaning a  glass-panelled wall. The morning sun illuminates the clear and crisp  lines of the building’s architecture, while producing pronounced  shadows on a deeply veined onyx wall to the left. On the panels the  custodian has prepared for cleaning, streaming water adds a random  design onto the surface of the symmetrically-patterned glass, which  partially obscures a courtyard where a sculpture of a female nude by  Georg Kolbe (1877–1947) stands by a pond.<a id="ref-en-ch05-14"></a>[14](#note-en-ch05-14)

<a id="ch05-p017-zh"></a>
密斯建筑的形式严谨传达一种简洁感，并沉溺于材料的纯粹，而清洁工的劳动则指向维持“少即是多”幻觉所需的努力。沃尔指出：“清洁是神秘的……因为它是那种如果成功就会抹除自身的劳动。”他评论道：“［这些］建筑需要格外一丝不苟的维护。在更传统的空间里，一点灰尘和污垢并不构成对整体概念如此刺眼的对比。它甚至可以变成包浆，但这些密斯式建筑尽其所能抵抗包浆。”<a id="ref-zh-ch05-15"></a>[15](#note-zh-ch05-15)

<a id="ch05-p017-en"></a>
Whilst the Mies building’s formal rigour conveys a sense of simplicity and luxuriates in the purity of materials, the cleaner’s labour points to the effort entailed in maintaining an illusion of ‘less’ as ‘more’. Wall has noted that ‘Cleaning is mysterious … since it is the labour that erases itself if it is successful.’ He observes: ‘[These] buildings require an especially scrupulous level of maintenance. In more traditional spaces a little dirt and grime is not such a shocking contrast to the whole concept. It can even become patina, but these Miesian buildings resist patina as much as they can.’<a id="ref-en-ch05-15"></a>[15](#note-en-ch05-15)

<a id="ch05-p018-zh"></a>
在伊韦科维奇整部影片中，劳动场景不断被女人们的特写打断。摄影机在她们脸上停留长达一分钟，产生一种让人想起安迪·沃霍尔著名“试镜”系列的效果。沃霍尔有一句名言：“银幕魅力是一种秘密。如果你能弄明白它是什么、如何制造它，你就有了一个真正能卖的好产品。但在你真正看到某个人出现在银幕上之前，你甚至无法判断他有没有这种魅力。你必须通过试镜来发现。”<a id="ref-zh-ch05-16"></a>[16](#note-zh-ch05-16) 在我看来，埃斯特园区的清洁女工即使不是全部，也有许多颇具银幕魅力。当我们看着她们在明亮白光下接受摄影机的审视时，她们的面孔展现出中欧、东欧和南欧“类型”的多样性：从金发蓝眼、宽脸高颧骨，到肤色较深、黑发油亮的人。有些年轻，有些年长，很可能已经做了祖母。我们不禁想到，较年轻的人是否会把整个职业生涯都花在类似的岗位上。如果说沃霍尔声称“我只想找到很棒的人，让他们做自己……然后拍他们一定长度的时间，那就是电影”，<a id="ref-zh-ch05-17"></a>[17](#note-zh-ch05-17) 那么伊韦科维奇镜头下的女人则汇聚成一个合唱队，围绕一位女性主义诗人的诗句团结起来。

<a id="ch05-p018-en"></a>
Throughout Iveković’s film, the scenes of labour are interrupted by close-up shots of the women. The camera lingers on their faces for up to a minute, producing an effect reminiscent of Andy Warhol’s famous series of ‘screen tests’. Warhol famously claimed that ‘screen magnetism is something secret. If you could figure out what it is and how you make it, you’d have a really good product to sell. But you can’t even tell if someone has it until you actually see them up there on the screen. You have to give screen tests to find out.’<a id="ref-en-ch05-16"></a>[16](#note-en-ch05-16) Many, if not all, of the Erste Campus cleaning women seem magnetic to me. As we watch them subject themselves to the scrutiny of the camera under bright white light, their faces demonstrate a diversity of central, eastern and southern European ‘types’, from blonde and blue-eyed with wide faces and high cheekbones to others with darker complexions and glossy black hair. Some are young, some are older, likely already grandmothers. We wonder whether the younger ones will spend their whole working lives in similar roles. If Warhol claimed ‘I only wanted to find great people and let them be themselves … and I’d film them for a certain length of time and that would be the movie’,<a id="ref-en-ch05-17"></a>[17](#note-en-ch05-17) Iveković’s individual women come together to form a chorus, rallying around the words of a feminist poet.

<a id="ch05-p019-zh"></a>
因为伊韦科维奇的女人们不像沃霍尔的被摄者那样沉默，尽管她们说出的话也不完全属于自己。她们用别人的词，却以自己的语言说话；她们选择自己要背诵的诗行，这些诗行选自艾达·巴吉奇的诗歌，从克罗地亚语译成她们的母语，每人几行。聆听时，人们会为她们声音的不同质感以及构成各种语言的声音多样性所打动。我们也许能辨认出其中一些是斯拉夫语言，另一些则感觉较为陌生。与伊韦科维奇合作的这组女性是波斯尼亚人、克罗地亚人、科索沃人、波兰人、罗马尼亚人、塞尔维亚人和土耳其人。她们有些人像女学生那样背诵，有些人像初露头角的女演员；有些女人背诵得清晰自信，另一些更害羞、有些局促，不习惯摄影机的关注，但她们都念完了自己的诗句，看上去松了口气，甚至可能有些自豪。所有人都似乎为念完诗行而高兴，许多人露出微笑。她们所选的文本显得极为个人化，令观者想了解她们的人生故事，以及她们怎么会来到维也纳清洁这家银行。每个人都被鼓励选择自己在某种方式上感到共鸣的诗行。

<a id="ch05-p019-en"></a>
For Iveković’s women are not silent like Warhol’s sitters, though neither are the words they speak entirely their own. They speak the words of another but in their own languages, and they have chosen their own lines to recite, selected from the poetry of Aida Bagić, translated from Croatian into their native tongues, a few lines each. Listening, one is struck by the different qualities of their voices and the diversity of sounds that make up the various languages. We may recognize some as Slavonic; others may feel less familiar. The group of women Iveković worked with were Bosnian, Croatian, Kosovan, Polish, Romanian, Serbian and Turkish. Some of them recite like schoolgirls, some like budding actresses; some of the women recite clearly and confidently, others are more shy, a little embarrassed and not used to the attention of the camera, but they all get through their lines and look relieved and perhaps even a little proud. All seem pleased to come to the end of their lines, and many smile. Their selections of text seem highly personal and make the viewer wonder about their life stories and how it came to be that they are working at cleaning the bank, in Vienna. Each has been encouraged to choose lines to which she felt connected to in some way.

<a id="ch05-p020-zh"></a>
有些诗句似乎追忆更艰难的时光：“失忆不是一种病症／它是一种解药／用来对抗那一刻的记忆／当一切开始走下坡路／如果我记不起来”。许多是日常的，却以某种方式指示着微小的满足，以及一种一切井然有序的感觉：“我天亮前离家／城市安静／面包已烤好”；“我四点半起床／电车不挤／于是我睡在温暖里”；“我有一座小花园／除草占据我全部注意力／每一片草叶都独一无二”；“我天亮前起床／看云、人们和／瓶中信漂过／然后我看看自己／手掌，我看见／一切都会好的”。它们提供实用的生存建议：“我母亲告诉我／别花那么多时间／待在自己脑子里／你最好到外面去。到新鲜空气里／我母亲是个聪明的女人。”考虑到清洁工作是在室内接触化学品，这一建议的讽刺意味显而易见。有几句涉及女性劳动的性质：“女人的工作／永远做不完／我刚做完／就感觉自己还没开始”；“人们说女人撑着／房子的三个角／但我清洁全部四个角”；也许是以男人的口吻说——“女人能做到／我也能做到／各种各样的事我都能做／但我不必做，所以我不会做”。另一些涉及等待邮件：“我向邮递员挥手／但他们不认识我／因为我不是从这里来的／我是从那里来的／我随风而来／也将随风而去”；“我一直在等一封信／已经好几个月了／邮递员后来对我说／我不知道那是你”。最后引用的句子是“我不知道那是你”，也许呼应了这些女人本身不被了解、不被承认这一意味——正如伊韦科维奇的标题所暗示的，她们是“不可见的”。

<a id="ch05-p020-en"></a>
Some of the lines of poetry seem to hark back to harder times: ‘Loss of memory is not a disorder / It is a remedy / Against memories of the moment / when everything started to go downhill / If I cannot remember it’. Many are day-to-day, yet somehow indicative of small satisfactions, and a sense that things are in order: ‘I leave the house before dawn / The city is quiet / the bread is baked’; ‘I get up at half past four / trams are not crowded / so I sleep in the warm’; ‘I have a small garden / Weeding takes my full attention / Each blade of grass is unique’; ‘I get up before dawn / And I watch clouds people and / bottled messages go by / Then I look at the palm of / my hand and I see / It will be alright’. They offer practical advice for getting by: ‘My mother tells me / Don’t spent that much time / inside your head / You’re better off outside. In the fresh air / My mother is a wise woman’. The irony of this advice, in view of the indoor chemical nature of the cleaning work is clear. Several lines address the nature of female labour: ‘A woman’s work is / never done / As soon as I finish / it feels as if I haven’t even started’; ‘They say a woman holds / three corners of the house / But I clean all four’; perhaps in the voice of a man – ‘Women can do it / I can do it too / I can do all kinds of things / But I don’t have to, so I won’t’. Others refer to the experience of waiting for the mail: ‘I wave to the postmen / But they do not know me / Because I am not from here / I am from there / I came with the wind / And with wind I will go’; ‘I’ve been waiting for a letter / for months now / The postman later said to me / I didn’t know it was you’. The last line cited is ‘I didn’t know it was you’, perhaps echoing the sense in which the women themselves are not known, not recognized, ‘invisible’ as Iveković’s title implies.

<a id="ch05-p021-zh"></a>
离家的距离是一个关键主题：“我的生活会轻松许多／如果我一只手握雨／另一只手握太阳／那我就不必去任何地方。”<a id="ref-zh-ch05-18"></a>[18](#note-zh-ch05-18) 一些核心诗句像叠句一样被重复，因为它们被不止一次选中。值得注意的是，这些是涉及流离失所经验以及坚持伦理的诗句：“我不是从这里来的／我是从那里来的／我随风而来／我将随风而去”。有几位女人，尤其是那些年长者——她们的眼神比更年轻、更乐观的同事更悲伤、更受压制——重复这些诗句：“跌倒，起来。／再次跌倒。／起来。／跌倒。／如果你每天练习／跌倒很容易”。较年轻的女人往往是选择更浪漫诗句的人；年长者则选择更忧郁的诗句，不过跌倒、起来、再次跌倒的问题，也可能像萨缪尔·贝克特在《向着更糟去》中的箴言“无所谓。再试一次。再失败一次。失败得更好”一样，是一种行动号召。这是伊韦科维奇过去自己也曾处理过的主题，尤其是在名为《练习造就大师》（1982）的影像表演中。在这件作品中，一位穿黑色晚礼服的女性相当僵硬地站在舞台上的摄影机前，头上套着白色塑料袋。突然，她身体一震，倒在地上。过了一会儿。她一动不动地躺着。然后，她站起来，再次站在舞台上。她身体猛然一震，仿佛被枪杀，又倒了下去。这一动作循环重复。女人跌倒，爬起，再跌倒，再起来。在另一件重要的合作作品《女性之家》（2009）中，伊韦科维奇与来自一家庇护所的女性合作——她们离开了暴力关系以重建生活——并为她们的面部制作石膏翻模；这些面具后来被转化成一个肃穆的陵墓，一圈由翻模面孔组成的肖像安装在基座上。每个面具下方记录了其主人的故事。这些女人及其孩子的故事读来令人悲伤。虽然每个故事都不同，但其中描述的暴力关系的动力机制从根本上相同，而且显然家庭暴力折磨着所有国籍和年龄群体：玛丽亚，51岁，葡萄牙人，已婚，一个孩子；蕾妮，35岁，卢森堡人，已婚，三个孩子；法蒂玛，24岁，佛得角人，已婚……名单还在继续。正如玛丽亚·赫拉瓦约娃所论证的，伊韦科维奇对这类新合作实践形式的拥抱，用艺术家自己的话说，旨在“不仅阐明政治论点，从而使已经知道它的人明白，而且把艺术纳入政治实践，形成新观念并将其传播到社会中”。<a id="ref-zh-ch05-19"></a>[19](#note-zh-ch05-19)

<a id="ch05-p021-en"></a>
Distance from home is a key theme: ‘My life would be so easy / If I had rain in one hand / and the sun in the other / Then I wouldn’t need to go anywhere’.<a id="ref-en-ch05-18"></a>[18](#note-en-ch05-18) A number of core lines are repeated like a refrain, having been selected more than once. Notably these are those that relate to the experience of displacement: ‘I am not from here / I am from there / I came with the wind / With the wind I will go’, as well as to an ethic of perseverance. Several of the women, particularly those who are older, their eyes sadder, more browbeaten than their younger, more optimistic colleagues, repeat the lines ‘Fall down, get up. / Fall down again. / Get up. / Fall down. / Falling comes easy if you / practice every day’. The younger women tend to be the ones who chose the more romantic lines; the older ones those more melancholic, though the question of falling down, getting up and falling down again, might also be a call to action, along the lines of Samuel Beckett’s mantra ‘No matter. Try again. Fail Again. Fail Better’ from *Worstward Ho!* It is a topic Iveković has addressed herself in the past, notably in a video performance entitled *Practice Makes a Master* (1982). Here, a woman in a black evening dress is shown standing rather stiffly on the stage before the camera, hooded with a white plastic bag. Suddenly her body jolts and she collapses to the ground. Some time passes. She lies immobile. Then, she gets up, and stands on the stage again. Her body jolts as though she had been shot dead, and she collapses again. The action is repeated, on a loop. Women fall, pick themselves up, fall again, get up again. In another major collaborative work, *Women’s House* (2009), Iveković worked with women from a shelter, who had left violent relationships to rebuild their lives, and made plaster casts of their faces, which were later transformed into an austere mausoleum in a circle of cast faces, installed on plinths. Its owner’s stories were recorded beneath each mask. The stories of these women and their children make sad reading. While every story is different, the dynamics of the violent relationships described in each are fundamentally the same, and it is clear that domestic violence afflicts all nationalities and age groups: Maria, 51, Portuguese, married, one child; Renee, 35, Luxembourger, married, three children; Fatima, 24, Cap Verdese, married… the list goes on. As Maria Hlavajova has argued, Iveković’s embrace of new forms of collaborative practice like these seeks, as the artist has herself put it, ‘not just to illustrate the political thesis, thus making it clear to those who already know it, but to include art into the political praxis, form new ideas and spread them into society’. <a id="ref-en-ch05-19"></a>[19](#note-en-ch05-19)

<a id="ch05-p022-zh"></a>
然而，正如曼努埃拉·博亚齐耶夫与塞尔哈特·卡拉卡亚勒所论证的，必须警惕这样一种程度：“尤其是在左派中间……与主要是移民的‘他者’团结的表达，不仅使自己的‘自身’位置免于质疑，而且把‘可怜的他人’受害者化，剥夺他们自身采取政治行动的能力。”<a id="ref-zh-ch05-20"></a>[20](#note-zh-ch05-20) 因此，问题应当由“所有那些”像他们一样“不再相信移民斗争是历史附戏的人”提出：“如果并且当移民跨越边界时……他们……已经（并以一种新的方式）成为民族与全球社会关系的一部分，而他们自己也改变这些关系。”他们坚持认为，“移民的主体性不可还原为其劳动力角色”。<a id="ref-zh-ch05-21"></a>[21](#note-zh-ch05-21) 在我看来，这正是伊韦科维奇邀请清洁女工选择并朗诵诗歌时所努力展示的，关键在于这些诗被译成她们自己的语言；而不是把合作者化约为基本人口统计资料——《女性之家》项目在文献记录中的后续呈现也许不可避免地部分如此。尽管这些诗句在某些情况下可能与女人们的劳动、与清洁的经验产生联系，但在这个意义上它们不可还原：它们还暗示过去与未来、渴望、梦想，以及共同的移民经验；这种经验对于今日欧洲现实的性质及其体验仍然至关重要：无论1989年及向后社会主义的“转型”所加速的境况变化与新的经济社会不平等如何，它都是如此；而与此同时，也恰恰是这些变化与不平等，使这一经验如此重要。

<a id="ch05-p022-en"></a>
Nevertheless, as Manuela Bojadzijev and Serhat Karakayali have argued, it is essential to be mindful of the degree to which, ‘particularly among leftists … expressions of solidarity with the mostly migrant “others” not only leave one’s “own” position unquestioned, but also victimise the “poor others” and deny them their own capacity for political action’.<a id="ref-en-ch05-20"></a>[20](#note-en-ch05-20) And questions should therefore be posed by ‘all those who’, like them, ‘no longer believe the struggles of migration to be a sideshow of history’: ‘if and when migrants cross borders … they … are already (and then, in a new way) a part of national and global social relations, which they also themselves transform’. They insist that ‘the subjectivity of migrants is not reducible to their role as labour-power’. <a id="ref-en-ch05-21"></a>[21](#note-en-ch05-21) This, it seems to me, is what Iveković strives to demonstrate when she invites the cleaners to select and recite poetry, crucially, translated into their own languages; rather than reduce her collaborators to vital statistics, as was, perhaps inevitably, in part the case in the documentary afterlife of the *Woman House* project. While the lines of poetry may be relatable, in some cases, to the women’s experience of labour, to cleaning, they are not reducible in this sense: they also allude to the past and future, to longing, to dreams, and to the shared experience of migration, which remains so central to the nature and experience of European reality today, both irrespective of and yet also precisely because of the changed circumstances and new economic and social inequalities accelerated by 1989 and the ‘transition’ to post-socialism.

<a id="ch05-p023-zh"></a>
甚至在新冠疫情之前，弗朗索瓦丝·韦尔热斯就写道，我们生活在“一个对干净的艺术、干净的水、干净的房屋、干净的身体、干净的心灵和绿色空间的关切日益增长的时代”。她论证说，这是“1970年代新时代意识形态的延伸”，也是一种市场的延伸，而该市场的“目标是个人效率以及身体与精神力量的最大化”。她写到“清洁与肮脏之间被划出的新边界”，解释说新自由主义白人男性的表演性身体从根本上由“不可见身体……女性和有色人种”支撑，而后者的疲惫反过来仍是“提取主义历史逻辑的后果，这种逻辑构建了原始积累与资本——从被种族化的身体中提取劳动”；她得出结论：“有色人种女性清洁工作的不可见性，创造了干净家庭和公共空间的可见性。”因此，她论证说，今天的清洁是一项更长久的历史性“*疲惫经济*”的一部分。她指出，清洁女工“谈到自己睡的时间很少……谈到花在通勤上的漫长小时，以及回家后还必须做的工作”。<a id="ref-zh-ch05-22"></a>[22](#note-zh-ch05-22) 完全相同的一点，已在伯威克街电影集体1975年的影片《夜间清洁工》（第一部分，90分钟）中得到明确表达；该片致力于提高人们对清洁工劳动的认识，并记录她们争取工会化的运动。片中一系列女性被令人难忘地询问“你能睡上觉吗？”，她们以就事论事的口吻讲述——仿佛惊讶于竟然有人想知道——如何在哄孩子入睡与出门上夜班之间平均每晚抢睡一个半小时。正如西奥娜·威尔逊等人所概述的，夜间清洁工运动“挑战了有组织左派内部更深层的一套排斥”，并“试图界定一种超越中产阶级女性经验范围、把工人阶级和移民女性包括在内的女性主义政治”。<a id="ref-zh-ch05-23"></a>[23](#note-zh-ch05-23)

<a id="ch05-p023-en"></a>
Even before Covid-19, Françoise Vergès had written that we lived in ‘an age in which concerns are growing for clean art, clean water, clean houses, clean bodies, clean minds and green space’. This was, she argued, ‘an extension of New Age ideology of the 1970s’ and of a market whose ‘aim is personal efficiency and a maximization of physical and mental power’. She wrote of ‘new borders that have been drawn between cleanliness and dirtiness’, explaining how the performing body of the neoliberal white male was fundamentally undergirded by the ‘invisible body ... female and a person of color’, whose exhaustion, in turn, remains ‘the consequence of the historical logic of extractivism that built primitive accumulation and capital – extracting labor from racialised bodies’; concluding that ‘invisibility of the cleaning jobs of women of color creates the visibility of clean homes and public spaces’. Thus, she argues, cleaning, today, is part of a longer, historical ‘*economy of exhaustion*’. Cleaning women, she noted, ‘speak of the very little time they sleep … of the long hours devoted to their commutes, and of the work they have to do once they return home’.<a id="ref-en-ch05-22"></a>[22](#note-en-ch05-22) The very same point was already made explicit in the 1975 film *Night Cleaners* (*Part 1*, 90 mins) by the Berwick Street Film Collective, devoted to raising recognition of the labour of cleaners and documenting the campaign for their unionization, in which a series of women are memorably asked ‘Do you get any sleep?’, and recount, in matter-of-fact tones, as though surprised that anyone is even interested to know, how they try to snatch an average of an hour and a half per might, between putting their babies to bed and heading out for their night shifts. As Siona Wilson, among others, has outlined, the night cleaners’ campaign ‘challenged a deeper set of expulsions within the organized left’ and ‘sought to define a feminist politics that went beyond the confines of middle-class women’s experience to include working-class and immigrant women\*’\*.<a id="ref-en-ch05-23"></a>[23](#note-en-ch05-23)

<a id="ch05-p024-zh"></a>
伊韦科维奇追随这一早期女性主义项目的足迹，邀请奥地利工会联合会下属工会VIDA的代表（乌尔苏拉·沃迪奇卡）与埃斯特园区的清洁女工交谈，并向她们解释奥地利关于职工委员会的法律。谈话记录显示，女人们挣的是每小时8.36欧元的最低工资，而且自新大楼大约五个月前启用以来，她们一直在那里工作。沃迪奇卡向女人们解释为什么职工委员会重要：“如果大家联合起来、组织起来，就能改善状况。”她说：“需要像你们这样的人告诉我们问题在哪里、你们担心什么、你们有哪些恐惧、需要哪些帮助。”<a id="ref-zh-ch05-24"></a>[24](#note-zh-ch05-24) 她告诉她们，“职工委员会可以帮助向老板提出各种各样的问题”，从清洁用品的质量或机器的效率，到尝试为有育儿责任的员工协商更合适的工作时间，再到确保如果老板想裁减员工，委员会可以帮助决定谁较有条件在被裁后找到新工作等等。她解释说，委员会大约可以在两个月内成立，并谈到程序与成员规则，讨论自我组织以及如何挑选和选举代表的问题。她在语言与沟通问题对她这类组织的重要性上停留了一阵。她说，重要的是，代表清洁工与老板谈判的人要德语说得好，否则不会被认真对待。她说，她的工会致力于与清洁女工沟通、努力理解她们的关切，以克服这群时间匮乏、讲许多种不同母语、德语熟练程度各异的女性所面临的不可避免的语言障碍。

<a id="ch05-p024-en"></a>
Iveković follows in the footsteps of this earlier feminist project, when she invites a representative from the trade union VIDA, part of the Austrian Trade Union Federation (Ursula Woditscha) to speak with the cleaning women at Erste Campus and to explain Austrian laws about workers’ council’s with them. The notes from the conversation record that the women earned the minimum rate of €8.36 and that they had been working in the new building since it opened approximately some five months before. Woditscha explained to the women why a work council is important, explaining: ‘If everyone gets together and gets organized, you can improve things.’ She says: ‘people like you who tell us where the problems lie, what worries you, which fears you have and which help you need.’<a id="ref-en-ch05-24"></a>[24](#note-en-ch05-24) She tells them that ‘the council can help raise all sorts of issues with the bosses’, ranging from the quality of cleaning products or the efficiency of machines, to trying to negotiate more suitable working hours for staff with childcare responsibilities, to ensuring that if the boss wants to reduce the number of staff the council can help decide who is best placed to find a new job and to be laid off, and so on. She explains that a council can be formed in around two months and talks about the procedure and membership rules, discussing issues around self-organization and how to select and elect a representative. She lingers for a while on the importance of issues around language and communication in an organization like hers. It is important, she says, that those sent to negotiate on the cleaners’ behalf with the bosses speak good German, otherwise they will not be taken seriously. Her union, she says, is committed to communicating with the cleaners and to trying to understand their concerns, to overcome the inevitable language barriers faced by a time-poor group of women speaking many different home languages with differing levels of German proficiency.

<a id="ch05-p025-zh"></a>
当邀请女人们提问时，有人问及获得医疗服务的途径，解释说她们被告知可以使用埃斯特的医疗服务，但从未见过相关代表：“某个地方写着埃斯特集团有医生，但我们从没见过这个人。”

<a id="ch05-p025-en"></a>
When the women were invited to ask questions, one asked about access to healthcare, explaining that they had been told that they had access to Erste healthcare but had not met any representatives about it: ‘Somewhere it is written that we have a doctor at the Erste Group, but we have never seen this person.’

<a id="ch05-p026-zh"></a>
沃迪奇卡指出，由于清洁工作被分包，严格来说这些女人是另一家公司——此处是一家名为蒙多（Mundo）的公司——的雇员，而非埃斯特的直接雇员，这可能影响她们获得医疗服务。尽管约有4,500名埃斯特员工在园区工作，清洁工作当然已被外包，成为庞大商业清洁服务市场的一部分；在这个市场中，雇主承担更少风险，雇员领取更低工资，中间商拿走大部分利益。正如赫尔马·卢茨所论证的：“雇主喜欢把家政工人视为服务提供者；这大体上是一种开脱性修辞，方便地把辩论从权力与依赖关系中转移开，因为（受过学术教育的）中上层阶级客户通常知道，自己并非一项受法律保障的服务提供合同的当事方。”<a id="ref-zh-ch05-25"></a>[25](#note-zh-ch05-25) 伊韦科维奇对工人状况的田野调查所产生的一个结果，直接来自工会代表与清洁女工之间的问答。项目结束时，这些女性尽管身份是间接雇员，仍获得了使用埃斯特园区健康中心的权利。<a id="ref-zh-ch05-26"></a>[26](#note-zh-ch05-26)

<a id="ch05-p026-en"></a>
Woditscha points out that as the cleaning is subcontracted, the women are technically employees of another company, in this case one called Mundo, rather than Erste directly, and that this may have implications for their access to healthcare. While there are around 4,500 Erste employees working on campus, cleaning has of course been contracted out, part of a massive commercial cleaning service market, which sees employers take less risk, employees take lower wages, and middlemen take the lion’s share of the benefits. As Helma Lutz has argued: ‘Employers like to see their domestic workers as service providers; it is largely a form of exculpatory rhetoric which conveniently diverts the debate away from relations of power and dependence, since the (academically) educated upper-middle class clients will usually know that they are not party to a legally safeguarded service-provider contract.’<a id="ref-en-ch05-25"></a>[25](#note-en-ch05-25) One of the outcomes of Iveković’s field research into the workers’ conditions was a direct result of the Q&A between the union representative and the cleaners. On conclusion of the project, the women gained access to the health centre on the Erste campus, despite their status as indirect employees.<a id="ref-en-ch05-26"></a>[26](#note-en-ch05-26)

<a id="ch05-p027-zh"></a>
在一个力图成为新式“企业文化”典范的园区拍摄清洁工，伊韦科维奇凸显了所谓“非物质”与“物质”劳动者之间的相互依赖，并把后者持续被视作理所当然的种种方式推到前景。凯蒂·丘赫罗夫观察到，“‘非物质劳动者’这一‘阶级’内部的阶级鸿沟极其巨大”，因为“大部分非物质劳动工作者完全用不上自己的高等教育，并在专业之外工作”。此外，她有力地反驳了当代艺术界的一个神话：“‘革命性’词汇和‘无产阶级’诗学主要出现在当代批评与创意产业的话语中，很少出现在不受尊崇的物质劳动领域。”鉴于这些及其他有问题的预设，她指出：

<a id="ch05-p027-en"></a>
In filming cleaners on a campus that set out to make itself a model for a new form of ‘corporate culture’, Iveković highlighted the interdependence of so-called ‘immaterial’ and ‘material’ workers, foregrounding ongoing modes of taking the latter for granted. Keti Chukhrov observes that the ‘class gap within the “class” of immaterial workers is enormous’ as ‘the bulk of immaterial labour workers make no use whatsoever of their higher education and are working outside their specialization’. Moreover, she argues compellingly against the contemporary art-world myth that ‘“revolutionary” vocabulary and “proletarian” poetics are predominantly employed in the discourse of contemporary criticism and the creative industries, and rarely emerge in the realm of unprestigious material labour’. In view of these and other problematic assumptions, she notes that

<a id="ch05-q010-zh"></a>
> 有趣的是，西方艺术家调查日常化、低薪的工业劳动的作品，总是显眼地带有一种不可能性的印记：不可能有一个由泛欧洲中产阶级——包括物质劳动工作者和不受尊崇职业的代表——所建构的共享文化空间。

<a id="ch05-q010-en"></a>
> it is interesting that the work of Western artists investigating the  routine industrial, poorly paid labour is always conspicuously  marked by the impossibility of a shared cultural space constructed  by a pan-European middle class that includes material labour  workers and representatives of non-prestigious professions.

<a id="ch05-p028-zh"></a>
她接着说：

<a id="ch05-p028-en"></a>
She continues:

<a id="ch05-q011-zh"></a>
> 在发达国家的社会空间中，体力劳动是不可见的；而一旦进入视野，它就被看作某种徘徊于猎奇与淫秽之间的东西。……物质劳动见证了日常化、机械性劳动与中产阶级生活及活动的智性—创造性文化空间之间致命的分裂。

<a id="ch05-q011-en"></a>
> In the social space of developed countries, physical labour is  invisible; and if it comes into view, it is seen as something hovering  between the exotic and the obscene. … Material labour testifies  to the fatal division between routine, mechanical labour, and the  intellectual-creative and cultural space of middle-class life and  activity.

<a id="ch05-p029-zh"></a>
丘赫罗夫主张，有必要继续保有一种对非剥削与非商品化之可能性的感觉，即“一般性的潜能，而不在物质劳动与非物质劳动之间实行隔离——不从人类学意义上把人划分为两个生产者种族”。<a id="ref-zh-ch05-27"></a>[27](#note-zh-ch05-27)

<a id="ch05-p029-en"></a>
Chukhrov argues for the need to continue to retain a sense of the possibility of non-exploitation and non-commodification, of the ‘potential of the general without a segregation between material and immaterial labour – without an anthropological division of people into two races of producers’.<a id="ref-en-ch05-27"></a>[27](#note-en-ch05-27)

<a id="ch05-p030-zh"></a>
伊韦科维奇试图在影片最后一幕克服这种分裂，以她与纪录片拍摄对象作为后社会主义女性的共同经验为基础，与她们搭建一座共同的桥。清洁女工结束一天工作后，镜头显示一扇沉重的钢门轻轻关闭，也许是在指涉电影史上工厂大门打开、工人涌出的标志性时刻。然后，出人意料地，一只八音盒响起。它奏出《国际歌》单薄发脆的版本，镜头跟随一位高个年轻金发女人忧郁地沿着后勤走廊行走，一边走一边给八音盒上发条；她缓缓走在走廊里。<a id="ref-zh-ch05-28"></a>[28](#note-zh-ch05-28) 摄影机转向一位年长女性面部的特写。她戴着珍珠耳环，眼神遥远。她的神情表明她记得太清楚了。房间里聚集着各个年龄的其他女性的面孔，她们与艺术家一起听着这曲调，轮流被镜头审视，有些一起出现，有些单独出现。每个人都极其严肃，没人在笑。她们显然明白这里所表达的意思。几乎所有人都来自前社会主义国家，和艺术家本人一样。有些人开始跟着点头，另一些人看上去难过，甚至快要落泪，坚强外表濒临崩溃。她们的集体处境显然充满反讽；她们正生活在梦想的失败之中。画面变黑。八音盒音乐越来越慢。镜头摇回空荡的走廊，其红色管道开始可疑地像是社会主义过去之承诺的非自愿纪念碑。突然，红色似乎无处不在：其中一层整个被漆成红色。然而，在地面之上，镜头回到浮华的新自由主义当下。尽管银行总部位于维也纳，所有标识却都用英语；浮夸地命名为“宏伟大厅”（Grand Hall）的空间开始坐满人。城市交响曲，或至少其园区微观世界，正在重新开始。清洁已完成，白领员工陆续到来接手，而不可见的清洁工该消失回她们不可见的生活了。园区接下来的一部分日程与她们无关。正如网站介绍“埃斯特集团作为雇主”之优点的部分所宣称：“赚钱可以具有更深的含义”——尽管严格来说，清洁工并非埃斯特集团的雇员。

<a id="ch05-p030-en"></a>
Iveković attempts to overcome such a division in the final scene of her film, building a common bridge with the subjects of her documentary, on the platform of their shared experience as post-socialist women. After the cleaners have finished their working day, the camera shows a heavy steel door gently closing, perhaps in reference to the iconic cinematic moment of the factory doors opening and the workers flooding out. Then, unexpectedly, a music box starts up. It plays a tinny version of ‘The Internationale’ and the camera tracks a tall young blonde woman melancholically walking down a service corridor winding it up as she goes, as she walks slowly down a corridor.<a id="ref-en-ch05-28"></a>[28](#note-en-ch05-28) The camera shifts to a close-up of an older woman’s face. She wears pearl earrings and a far-away look in her eye. Her look suggests that she remembers all too well. Other women’s faces, of all ages, gathered in the room, together with the artist, listening to the tune together, are scrutinized, in turn, some together, some along. Everyone looks deadly serious and no one is laughing. They clearly get the point being made here. Almost all are from former socialist countries, like the artist herself. Some begin to nod along, others looks upset, even on the verge of tears, their tough exteriors threatening to crumble. There is clearly an irony in their collective situation; they are living the failure of the dream. The screen goes black. The music box music gets slower and slower. The camera pans back to the empty corridor, its red pipes beginning to look suspiciously like involuntary monuments to the promise of the socialist past. Suddenly red seems to be everywhere: one of the floors is painted red in its entirety. Above ground, though, the camera returns to the flashy neoliberal present. All the signage is in English, despite the bank’s headquarters being in Vienna, and the pompously named ‘Grand Hall’ is beginning to fill up. The city symphony, or at least its campus microcosm, is starting over. The cleaning is done, the white collar staff are arriving to take over, and it is time for the invisible cleaners to disappear back to their invisible lives. The next part of the day on campus is not about them. As the section of the website introducing the merits of ‘Erste Group as an Employer’ proclaims: ‘Earning money can have a deeper meaning’ – though, technically, the cleaners are not Erste group employees.

### 原注

<a id="ch05-n001-zh"></a><a id="note-zh-ch05-1"></a>
[1] “新企业文化的办公理念”。见 www.erstegroup.com/en/about-us/erste-campus。 [返回](#ref-zh-ch05-1)

<a id="ch05-n001-en"></a><a id="note-en-ch05-1"></a>
[1] ‘Office concept for a new corporate culture’. See www.erstegroup.com/en/about-us/ erste-campus. [返回](#ref-en-ch05-1)

<a id="ch05-n002-zh"></a><a id="note-zh-ch05-2"></a>
[2] “埃斯特园区周边环境”。见 www.erstegroup.com/en/about-us/erste-campus。 [返回](#ref-zh-ch05-2)

<a id="ch05-n002-en"></a><a id="note-en-ch05-2"></a>
[2] ‘Erste Campus Surroundings’. See www.erstegroup.com/en/about-us/erste-campus. [返回](#ref-en-ch05-2)

<a id="ch05-n003-zh"></a><a id="note-zh-ch05-3"></a>
[3] ‘Who’s cleaning all this? Interviews by Sanja Iveković’, in Pierre Bal-Blanc and Kathrin Rhomberg, eds, *The Canaletto View*, Köln: Verlag der Buchhandlung Walther König, 2020, p. 94。 [返回](#ref-zh-ch05-3)

<a id="ch05-n003-en"></a><a id="note-en-ch05-3"></a>
[3] ‘Who’s cleaning all this? Interviews by Sanja Iveković’, in Pierre Bal-Blanc and Kathrin Rhomberg, eds, *The Canaletto View*, Köln: Verlag der Buchhandlung Walther König, 2020, p. 94. [返回](#ref-en-ch05-3)

<a id="ch05-n004-zh"></a><a id="note-zh-ch05-4"></a>
[4] www.erstegroup.com/en/home。 [返回](#ref-zh-ch05-4)

<a id="ch05-n004-en"></a><a id="note-en-ch05-4"></a>
[4] www.erstegroup.com/en/home. [返回](#ref-en-ch05-4)

<a id="ch05-n005-zh"></a><a id="note-zh-ch05-5"></a>
[5] 见“我们的市场”，同上。 [返回](#ref-zh-ch05-5)

<a id="ch05-n005-en"></a><a id="note-en-ch05-5"></a>
[5] See ‘Our Markets’, ibid.. [返回](#ref-en-ch05-5)

<a id="ch05-n006-zh"></a><a id="note-zh-ch05-6"></a>
[6] ‘Who’s cleaning all this?’, p. 94。 [返回](#ref-zh-ch05-6)

<a id="ch05-n006-en"></a><a id="note-en-ch05-6"></a>
[6] ‘Who’s cleaning all this?’, p. 94. [返回](#ref-en-ch05-6)

<a id="ch05-n007-zh"></a><a id="note-zh-ch05-7"></a>
[7] 其他计划包括2019年“临界点”讲座（首场由弗朗西斯·福山主讲，另一场由费尔文·萨尔主讲“如何为多数人而非少数人实现全面的繁荣概念？”），以及资助2019年欧洲日在维也纳犹太广场举行的一年一度讲座，首场由蒂莫西·斯奈德主讲。 [返回](#ref-zh-ch05-7)

<a id="ch05-n007-en"></a><a id="note-en-ch05-7"></a>
[7] Other initiatives include the 2019 ‘Tipping Point’ talks (the first of which was by Francis Fukuyama, another by Felvine Sarr on ‘How Can We Realise a Holistic Concept of Prosperity for the Many and Not the Few?’), and funding an annual lecture in Judenplatz in Vienna on Europe Day 2019, kicking off with Timothy Snyder. [返回](#ref-en-ch05-7)

<a id="ch05-n008-zh"></a><a id="note-zh-ch05-8"></a>
[8] 见 Angel Petrov, ‘Where did everyone go?’, 2020年5月11日, www.erstestiftung.org/en/where-did-everyone-go。 [返回](#ref-zh-ch05-8)

<a id="ch05-n008-en"></a><a id="note-en-ch05-8"></a>
[8] See Angel Petrov, ‘Where did everyone go?’, 11 May 2020, www.erstestiftung.org/ en/where-did-everyone-go. [返回](#ref-en-ch05-8)

<a id="ch05-n009-zh"></a><a id="note-zh-ch05-9"></a>
[9] “建筑中的艺术”（‘Art in Architecture’）。见 www.erstegroup.com/en/about-us/erste-campus。 [返回](#ref-zh-ch05-9)

<a id="ch05-n009-en"></a><a id="note-en-ch05-9"></a>
[9] ‘Art in Architecture’. See www.erstegroup.com/en/about-us/erste-campus. [返回](#ref-en-ch05-9)

<a id="ch05-n010-zh"></a><a id="note-zh-ch05-10"></a>
[10] Pierre Bal-Blanc, ‘Private Foundations, Innovating Conformity’, *Switch on Paper International*, trans. Maya Dalinsky, 2019, www.switchonpaper.com/wp-content/uploads/2019/06/Private-foundations-Innovating-Conformity.pdf。 [返回](#ref-zh-ch05-10)

<a id="ch05-n010-en"></a><a id="note-en-ch05-10"></a>
[10] Pierre Bal-Blanc, ‘Private Foundations, Innovating Conformity’, Switch on Paper International, trans. Maya Dalinsky, 2019, www.switchonpaper.com/wp-content/ uploads/2019/06/Private-foundations-Innovating-Conformity.pdf. [返回](#ref-en-ch05-10)

<a id="ch05-n011-zh"></a><a id="note-zh-ch05-11"></a>
[11] 安德烈亚斯·特赖希尔评论道：“我原以为她们不会像现在这样不可见。对我来说她们并非不可见，因为我早上很早就开始工作。”‘Who’s cleaning all this? Interviews by Sanja Iveković’, p. 94。 [返回](#ref-zh-ch05-11)

<a id="ch05-n011-en"></a><a id="note-en-ch05-11"></a>
[11] Andreas Treichl comments: ‘I thought they would be less invisible than they are. They are not invisible to me because I start to work very early in the morning.’ ‘Who’s cleaning all this? Interviews by Sanja Iveković’, p. 94. [返回](#ref-en-ch05-11)

<a id="ch05-n012-zh"></a><a id="note-zh-ch05-12"></a>
[12] Kathrin Rhomberg and Pierre Bal-Blanc, ‘Sanja Iveković, “The Invisible Women of Erste Campus”’, 2016, ‘影像项目，A—F座0—9层电梯厅’, www.erstegroup.com/en/about-us/erste-campus/sanja-ivekovic。 [返回](#ref-zh-ch05-12)

<a id="ch05-n012-en"></a><a id="note-en-ch05-12"></a>
[12] Kathrin Rhomberg and Pierre Bal-Blanc, ‘Sanja Iveković, ‘The Invisible Women of Erste Campus’, 2016, ‘Film Project, Elevator areas, Level 0–9, Building A–F’, www. erstegroup.com/en/about-us/erste-campus/sanja-ivekovic. [返回](#ref-en-ch05-12)

<a id="ch05-n013-zh"></a><a id="note-zh-ch05-13"></a>
[13] 它现在也以单频道影像装置的形式存在；我接触到、并作为本文论述对象的正是这一版本。 [返回](#ref-zh-ch05-13)

<a id="ch05-n013-en"></a><a id="note-en-ch05-13"></a>
[13] It now also exists as a single channel film installation, and it is this version of the film to which I have had access, and on which my essay focuses. [返回](#ref-en-ch05-13)

<a id="ch05-n014-zh"></a><a id="note-zh-ch05-14"></a>
[14] 见 Alice Sanger, ‘Morning Cleaning, Mies van der Rohe Foundation, Barcelona, 1999’, 2010, www.tate.org.uk/art/artworks/wall-morning-cleaning-mies-van-der-rohe-foundation-barcelona-t12294。 [返回](#ref-zh-ch05-14)

<a id="ch05-n014-en"></a><a id="note-en-ch05-14"></a>
[14] See Alice Sanger, ‘Morning Cleaning, Mies van der Rohe Foundation, Barcelona, 1999’, 2010,www.tate.org.uk/art/artworks/wall-morning-cleaning-mies-van-der-rohe-foundation-barcelona-t12294. [返回](#ref-en-ch05-14)

<a id="ch05-n015-zh"></a><a id="note-zh-ch05-15"></a>
[15] 同上。沃尔解释说：“画中人是真正的清洁工。这张照片在如下意义上是纪录性的：那正是他一天中那个时刻会做的事。我称之为‘近纪实’（near documentary）。尽管我布置了画面并与清洁工合作，这张照片仍然非常接近在那一刻拍摄的快照所会呈现的样子。”转引自 Sanger，据 Craig Burnett, *Jeff Wall*, London: Tate Publishing, 2005, p. 90。 [返回](#ref-zh-ch05-15)

<a id="ch05-n015-en"></a><a id="note-en-ch05-15"></a>
[15] Ibid. Wall explained: ‘The man in the picture is the real cleaner. The picture is documentary in the sense that that’s exactly what he would be doing at that moment of the day. It’s what I call “near documentary”. Although I arranged the picture and worked in collaboration with the cleaner, the picture resembles very closely what a snapshot made at that moment would show’. Cited in Sanger, after Craig Burnett, *Jeff Wall*, London: Tate Publishing, 2005, p. 90. [返回](#ref-en-ch05-15)

<a id="ch05-n016-zh"></a><a id="note-zh-ch05-16"></a>
[16] Andy Warhol, *The Philosophy of Andy Warhol: From A to B and Back Again*, New York: Harvest Books, 1975, 转引自 www.openculture.com/2018/09/watch-andy-warhols-screen-tests-of-three-female-muses.html。 [返回](#ref-zh-ch05-16)

<a id="ch05-n016-en"></a><a id="note-en-ch05-16"></a>
[16] Andy Warhol, *The Philosophy of Andy Warhol: From A to B and Back Again*, New York: Harvest Books, 1975, cited in www.openculture.com/2018/09/watch-andy-warhols-screen-tests-of-three-female-muses.html. [返回](#ref-en-ch05-16)

<a id="ch05-n017-zh"></a><a id="note-zh-ch05-17"></a>
[17] 沃霍尔，转引自 Geralyn Huxley, ‘About Andy Warhol’s Screen Texts’, www.warholscreentest.com/about.php?renter=。 [返回](#ref-zh-ch05-17)

<a id="ch05-n017-en"></a><a id="note-en-ch05-17"></a>
[17] Warhol, cited in Geralyn Huxley, ‘About Andy Warhol’s Screen Texts’, www. warholscreentest.com/about.php?renter=. [返回](#ref-en-ch05-17)

<a id="ch05-n018-zh"></a><a id="note-zh-ch05-18"></a>
[18] “那时我们就不必去任何地方了”呼应了亚当·霍兹科影片《采摘者》（2009）中的一句台词。片中在肯特采摘草莓的罗马尼亚工人推测，如果英国经济崩溃、英国人不得不来罗马尼亚谋生，会发生什么：“那时我们就不必去任何地方了。”“我会喜欢那样，”其中一位采摘者怅然地说，“是的……那时他们就会知道离家是什么滋味。”见 Klara Kemp-Welch, ‘“The Romanians are Coming”: Labour Migration and the Politics of the Observational Documentary’, *Third Text*, 2020. doi.org/10.1080/09528822.2020.1765601。 [返回](#ref-zh-ch05-18)

<a id="ch05-n018-en"></a><a id="note-en-ch05-18"></a>
[18] ‘Then we wouldn’t need to go anywhere’ echoes a line from Adam Chodzko’s film *The Pickers* (2009) in which Romanian strawberry pickers in Kent speculate what would happen if the British economy collapsed and if the British had to come to Romania to make a living: ‘Then we wouldn’t need to go anywhere.’ ‘I would like that’, said one of the pickers, wistfully, ‘Yes… then they would know what it is to be away from home.’ See Klara Kemp-Welch, ‘“The Romanians are Coming”: Labour Migration and the Politics of the Observational Documentary’, *Third Text*, 2020. doi.org/10.1080/09528822.2020.1765601. [返回](#ref-en-ch05-18)

<a id="ch05-n019-zh"></a><a id="note-zh-ch05-19"></a>
[19] Maria Hlavajova, ‘In Short: Thoughts behind the Exhibition’, in *Sanja Iveković. Urgent Matters*, exh. cat., Eindhoven: Van Abbemuseum; Utrecht: BAK, 2009, p. 12。 [返回](#ref-zh-ch05-19)

<a id="ch05-n019-en"></a><a id="note-en-ch05-19"></a>
[19] Maria Hlavajova, ‘In Short: Thoughts behind the Exhibition’, in *Sanja Iveković.* *Urgent Matters*, exh. cat., Eindhoven: Van Abbemuseum; Utrecht: BAK, 2009, p. 12. [返回](#ref-en-ch05-19)

<a id="ch05-n020-zh"></a><a id="note-zh-ch05-20"></a>
[20] Isabell Lorey, ‘Becoming Common: Precarization as Political Constituting’, *e-flux journal* 17, June–August 2010, pp. 4–5。 [返回](#ref-zh-ch05-20)

<a id="ch05-n020-en"></a><a id="note-en-ch05-20"></a>
[20] Isabell Lorey, ‘Becoming Common: Precarization as Political Constituting’, *e-flux* *journal* 17, June–August 2010, pp. 4–5. [返回](#ref-en-ch05-20)

<a id="ch05-n021-zh"></a><a id="note-zh-ch05-21"></a>
[21] Manuela Bojadzijev and Serhat Karakayali, ‘Recuperating the Sideshows of Capitalism: The Autonomy of Migration Today’, *e-flux journal* 17, June–August 2010, pp. 3–4。 [返回](#ref-zh-ch05-21)

<a id="ch05-n021-en"></a><a id="note-en-ch05-21"></a>
[21] Manuela Bojadzijev and Serhat Karakayali, ‘Recuperating the Sideshows of Capitalism: The Autonomy of Migration Today’, *e-flux journal* 17, June–August 2010, pp. 3–4. [返回](#ref-en-ch05-21)

<a id="ch05-n022-zh"></a><a id="note-zh-ch05-22"></a>
[22] Françoise Vergès, ‘Capitalocene, Waste, Race, and Gender’, *e-flux journal* 100, May 2019, p. 10。 [返回](#ref-zh-ch05-22)

<a id="ch05-n022-en"></a><a id="note-en-ch05-22"></a>
[22] Françoise Vergès, ‘Capitalocene, Waste, Race, and Gender’, *e-flux journal* 100, May 2019, p. 10. [返回](#ref-en-ch05-22)

<a id="ch05-n023-zh"></a><a id="note-zh-ch05-23"></a>
[23] Siona Wilson, *Art Labor, Sex Politics: Feminist Effects in 1970s British Art and Performance*, Minneapolis: University of Minnesota Press, 2015, ch. 1 n8。 [返回](#ref-zh-ch05-23)

<a id="ch05-n023-en"></a><a id="note-en-ch05-23"></a>
[23] Siona Wilson, *Art Labor, Sex Politics: Feminist Effects in 1970s British Art and* *Performance*, Minneapolis: University of Minnesota Press, 2015, ch. 1 n8. [返回](#ref-en-ch05-23)

<a id="ch05-n024-zh"></a><a id="note-zh-ch05-24"></a>
[24] Ursula Woditschka, in ‘Meeting Ursula Woditschka, VIDA with the Cleaning Ladies, Fri. May 20th’, 艺术家惠予本文作者的未刊会议转录稿。Sanja Iveković 档案，编号 Clea0317。 [返回](#ref-zh-ch05-24)

<a id="ch05-n024-en"></a><a id="note-en-ch05-24"></a>
[24] Ursula Woditschka, in ‘Meeting Ursula Woditschka, VIDA with the Cleaning Ladies, Fri. May 20th’, unpublished transcript of meeting kindly shared with me by the artist. Sanja Iveković archive, ref. Clea0317. [返回](#ref-en-ch05-24)

<a id="ch05-n025-zh"></a><a id="note-zh-ch05-25"></a>
[25] Helma Lutz, *The New Maids: Transnational Women and the Care Economy*, London: Zed Books, 2011, 转引自 Françoise Vergès, ‘Capitalocene, Waste, Race, and Gender’, *e-flux journal* 100, May 2019, p. 8。 [返回](#ref-zh-ch05-25)

<a id="ch05-n025-en"></a><a id="note-en-ch05-25"></a>
[25] Helma Lutz, *The New Maids: Transnational Women and the Care Economy*, London: Zed Books, 2011, cited in Françoise Vergès, ‘Capitalocene, Waste, Race, and Gender’, *e-flux journal* 100, May 2019, p. 8. [返回](#ref-en-ch05-25)

<a id="ch05-n026-zh"></a><a id="note-zh-ch05-26"></a>
[26] ‘Who’s cleaning all this? Interviews by Sanja Iveković’, p. 94。 [返回](#ref-zh-ch05-26)

<a id="ch05-n026-en"></a><a id="note-en-ch05-26"></a>
[26] ‘Who’s cleaning all this? Interviews by Sanja Iveković’, p. 94. [返回](#ref-en-ch05-26)

<a id="ch05-n027-zh"></a><a id="note-zh-ch05-27"></a>
[27] Keti Chukhrov, ‘Towards the Space of the General: On Labor beyond Materiality and Immateriality’, trans. Ainsley Morse, *e-flux journal* 20, November 2010, pp. 4, 7。 [返回](#ref-zh-ch05-27)

<a id="ch05-n027-en"></a><a id="note-en-ch05-27"></a>
[27] Keti Chukhrov, ‘Towards the Space of the General: On Labor beyond Materiality and Immateriality’, trans. Ainsley Morse, *e-flux journal* 20, November 2010, pp. 4, 7. [返回](#ref-en-ch05-27)

<a id="ch05-n028-zh"></a><a id="note-zh-ch05-28"></a>
[28] 我很感谢贝亚塔·霍克指出，这件作品是对匈牙利艺术家拉斯洛·拉克纳一件作品的重新演绎。拉克纳曾制作过一段实验录像，内容是他在一只从跳蚤市场买来的发条八音盒上演奏《国际歌》；当时他于1974年在西柏林获得DAAD奖学金（作品名为《记忆3》）。拉克纳后来在2004年以彩色重复了这件作品，并称之为《那是一场梦吗？》。两部影片——《记忆3》（黑白，数字化16毫米胶片，52秒）与《那是一场梦吗？》（《记忆3》，彩色，数字化录像，57秒）——都收录于2018年在柏林新美术协会（Neue Gesellschaft für bildende Kunst）举办的展览“左翼表演史：追忆东欧艺术实践”中。 [返回](#ref-zh-ch05-28)

<a id="ch05-n028-en"></a><a id="note-en-ch05-28"></a>
[28] I am grateful to Beata Hock for pointing out that the piece is a reprise of a work by the Hungarian artist Laszlo Lakner, who had made an experimental video of himself playing ‘The Internationale’ on a wind-up music box, bought from a fleamarket while on a DAAD scholarship in 1974 in West Berlin (entitled *Memory 3*). Lakner went on to repeat the work in colour in 2004, this time calling it *Was It a Dream?* Both films – *Memory 3*, b/w, digitalized 16 mm film, 52 sec.; *Was It a Dream?* (*Memory 3*), colour, digitalized video, 57 sec. – were included in the 2018 exhibition *Left Performance Histories: Recollecting* *Artistic Practices in Eastern Europe* at the Neue Gesellschaft für bildende Kunst, Berlin. [返回](#ref-en-ch05-28)

# 第三部　形式的不稳定性

<a id="part3-title-zh"></a>
## **形式的不稳定性**

<a id="part3-title-en"></a>
## INSTABILITIES OF FORM

## 第6章　艺行哲学

<a id="ch06-title-zh"></a>
## 艺行哲学

<a id="ch06-title-en"></a>
## Arting philosophy

<a id="ch06-author-zh"></a>
卢德格·施瓦尔特

<a id="ch06-author-en"></a>
LUDGER SCHWARTE

<a id="ch06-p001-zh"></a>
在下文中，我想论证哲学是艺术实践的必要组成部分。<a id="ref-zh-ch06-1"></a>[1](#note-zh-ch06-1) 我将集中分析艺术实践，因为我不同意主流审美传统：它把产品——即审美对象——的出现视为理所当然，并集中于审美经验。相反，我想把注意力转向对艺术实践本身的分析。我想表明，艺术实践既不是生产的一种形式，也不是工作的一种形式——如果允许采用汉娜·阿伦特的区分——也不是一种表演。我还想区分*艺术*实践与其他实践形式，尤其是*审美*实践；二者常常纠缠在一起，在实践学路径中尤其如此。

<a id="ch06-p001-en"></a>
In what follows, I want to argue that philosophy is a necessary part of artistic practice.<a id="ref-en-ch06-1"></a>[1](#note-en-ch06-1) I will concentrate on an analysis of artistic practice, because I am at odds with the dominant aesthetic tradition which takes the appearance of a product, the aesthetic object, for granted, and concentrates on the aesthetic experience. Instead I want to turn attention to an analysis of artistic practice as such. I want to show that artistic practice is neither a form of production, nor of work – if you allow Hannah Arendt’s distinctions – nor is it a kind of performance. And I would like to distinguish *artistic* practice from other forms of practice, notably *aesthetic* practice, with which it is often meshed, especially in praxeological approaches.

<a id="ch06-p002-zh"></a>
几乎每一种实践形式都包含某种审美要素，但艺术不止于此。我们不仅需要更好地解释一般艺术实践的特殊性——因为这是一个研究空白。集中考察艺术实践是什么、或在重新思考后可能成为什么，其主要理由是政治性的：艺术实践具有政治意义，这独立于其潜在产品或痕迹，因为它是自我决定的实验场，是自主性的训练场。

<a id="ch06-p002-en"></a>
Almost every form of practice contains some aesthetic element, but art is more than that. It is not only that we need a better explanation for the specificity of artistic practice in general – because it is a research lacuna. The main reason to concentrate on what artistic practice is, or can be, when reconsidered, is a political one: artistic practice has a political significance, independent of its potential products or traces, for it is an experimental field of self-determination, a training ground for autonomy.

<a id="ch06-p003-zh"></a>
我的标题可能暗示我想用艺术征服全部哲学。这并非我的意思。我说的是艺术哲学的一个方面。我的目标不是主张哲学的审美化（有些人就是这样解读阿多诺《美学理论》这一标题的），而是表明：哲学——吉尔·德勒兹曾把它定义为概念的工程——需要成为艺术实践的一部分，以使艺术免于某种当代范式；在我看来，这种范式把艺术化约为应用艺术史或审美化的社会学。反过来说，目标也在于改变哲学（艺术哲学与美学）的实践。

<a id="ch06-p003-en"></a>
My title might suggest that I want to conquer all philosophy with art. This is not what is meant. I am talking of an aspect of the philosophy of art. And my aim is not to argue for an aestheticization of philosophy (as some have read Adorno’s title, *Aesthetic Theory*), but to show that philosophy – the engineering of concepts, as Gilles Deleuze once defined it – needs to become part of artistic practice in order to save art from a particular contemporary paradigm, which, to my eyes, reduces art to applied art history or aestheticized sociology. The aim is also, in turn, to change the practice of philosophy (of art and aesthetics).

<a id="ch06-p004-zh"></a>
这里的动词“艺行”（arting）需要解释。在德语中，我想在英语中也是如此，名词“艺术”/*Kunst* 缺少一个动词形式。我们有时说“从事”“制作”或“生产”艺术。我对此不满意，于是在德语中创造了动词 *kunsten*。在英语中，这会是“to art”：艺行的实践，以动词不定式表达的艺术生成。亚历山大·加西亚·迪特曼把阿多诺的 *Entkunstung* 一词不是译为“去审美化”，而是译为“去艺化”（de-arting）。<a id="ref-zh-ch06-2"></a>[2](#note-zh-ch06-2) 因此，正如存在 *Entkunstung*——去艺化，一种移出艺术领域的运动——也可能存在相反的运动：*Kunsten*，艺行。艺行意味着把艺术界之外的某物转化为某种艺术性的东西。那么，什么是艺术性的？

<a id="ch06-p004-en"></a>
The verb ‘arting’ here needs explanation. In German, and I think in English, too, a verb form is missing for the noun ‘art’/*Kunst*. We sometimes speak of ‘practising’ or ‘making’ or ‘producing’ art. I was dissatisfied with this and coined in German the verb *kunsten*. In English, this would be ‘to art’: the practice of arting, the infinitive becoming of art. Alexander García Düttmann has translated Adorno’s expression *Entkunstung* not as ‘de-aestheticization’ but as ‘de-arting’.<a id="ref-en-ch06-2"></a>[2](#note-en-ch06-2) So, just as there is *Entkunstung* – de-arting – a moving out of the realm of art, there can be the contrary movement – *Kunsten*, arting. Arting means to transform something outside the art world into something artistic. Now, what is artistic?

<a id="ch06-p005-zh"></a>
三种哲学路径曾试图解释这样一种运动。迪基的制度理论会说，某物一旦进入艺术机构，就成为艺术作品。但椅子、马桶和人也在其中，而它们并不是艺术作品。丹托的路径是说，它是对象加上解释。阿多诺则提出要求：某种审美之物通过解释、评论与批评成为艺术作品。

<a id="ch06-p005-en"></a>
Three philosophical approaches have tried to explain such a movement. Dickie’s institutional theory would say that something becomes a work of art once it is in art institutions. But chairs, toilets and people are in there, and they are not artworks. Danto’s approach is to say that it is an object plus interpretation. And Adorno utters the requirement that something aesthetic becomes an artwork through interpretation, comment and criticism.

<a id="ch06-s01-zh"></a>
## **审美实践与艺术实践**

<a id="ch06-s01-en"></a>
## **Aesthetic versus artistic practice**

<a id="ch06-p006-zh"></a>
但所有这些都聚焦于审美对象的接受、审美经验，而忽视了生产方面。你如何说明艺术家所做的事？他们做什么？乍看之下，事情似乎简单：当艺术家工作时，她生产一件艺术作品。但这真的是工作吗？汉娜·阿伦特说：工作是再生产。但它是生产吗？艺术家所做之事的核心，是生产审美对象——可与珠宝、室内设计或精致烹饪相比吗？它是投资产品的制造式生产吗？是供消费的产品吗？还是供审美沉思的产品？

<a id="ch06-p006-en"></a>
But all of these focus on the reception of an aesthetic object, on aesthetic experience, and neglect the productive aspect. How do you give an account for what artists do? What do they do? At first glance, things seem simple: when an artist works, she produces a work of art. But is it really work? Hannah Arendt says: work is reproduction. But is it production? Is the core of what artists do the production of aesthetic objects – comparable to jewellery, interior design or fine cooking? Is it a manufactory production of investment products? Products destined for consumption? Or for aesthetic contemplation?

<a id="ch06-p007-zh"></a>
这里有必要区分*审美*实践与*艺术*实践。美学关注的是对感知方式的反思，包括对象、再现与审美判断。什么是审美实践？它不只是接受的实践——看、听、体验、解释一件作品、一顿饭、一处风景。

<a id="ch06-p007-en"></a>
It is necessary to differentiate here between *aesthetic* and *artistic* practices. Aesthetics is concerned with the reflection on modes of perception, including objects, representations and aesthetic judgements. What are aesthetic practices? It is not just the practices of receiving – of seeing, listening, experiencing, interpreting a work, a meal, a view.

<a id="ch06-p008-zh"></a>
审美实践是那些关注我们感知事物方式的一切实践。它们构成对感知过程的反思，并准备审美判断（趣味判断）。然而，审美实践主要关切的不是这些判断，而首先是唤起并体验审美品质。

<a id="ch06-p008-en"></a>
Aesthetic practices are all those where attention is paid to the way we perceive things. They form a reflection on perceptual processes and prepare aesthetic judgements (judgements of taste). However, aesthetic practices are not concerned primarily with these judgements, but first and foremost with evoking and experiencing aesthetic qualities.

<a id="ch06-p009-zh"></a>
烤蛋糕、品酒、游览名胜、设计花园、理发、化妆和冲咖啡——这些都是审美实践。它们不一定是职业活动，比如设计时装、装饰房屋、修建坟墓、制作纹身。作为一种审美活动，其目的不是赚钱或获得社会尊重。所有审美活动，无论是业余还是专业，无论是绘画与音乐还是陶艺与园艺，主要都不是以接受为目的。问题不在于感受愉悦或获得社会区隔。人们从事审美实践，不是为了达到这种效果，因为它不可由会产生同样效果的其他实践（如吸毒或沉浸式幻觉）替代。它本身就是目的：把注意力集中于感知方式。

<a id="ch06-p009-en"></a>
Baking cakes, tasting wine, visiting places of interest, designing gardens, cutting hair, applying make-up and making coffee – these are all aesthetic practices. They are not necessarily professional activities, such as designing fashion, decorating houses, erecting graves, making tattoos. Their purpose, as an aesthetic activity, is not to make money or to gain social esteem. All aesthetic activities, amateur and professional, be it painting and music or pottery and gardening, are not primarily intended for reception. It is not about feeling pleasure or gaining social distinction. One performs an aesthetic practice not to achieve such an effect, because it is not replaceable by other practices that will have the same effect (as by taking drugs or by immersive illusion). But it is an end in itself: to focus attention on modes of perception.

<a id="ch06-p010-zh"></a>
对大多数审美实践来说，这一追求——把注意力集中于感知方式——是决定性要素。我们弹钢琴是为了弹钢琴，而不是为了听钢琴发出的声音。我做饭因为我爱做饭，而不只是为了喂饱自己。我画画因为我喜欢画画，而不是为了激起解释。审美活动的进行，是为了在对象上或情境中带出审美品质。实践的目标是活动本身，活动中的自发性要素在其中显现：把它进行下去。以风格、令人印象深刻的和谐与美丽形式呈现一件花艺，这些都是自发性的审美成就。它可归因于我，恰恰因为我并不确切知道它会是怎样，但我必须反思如何去做。

<a id="ch06-p010-en"></a>
For most aesthetic practices, this quest – to focus attention on modes of perception – is the decisive element. We play piano in order to play piano, not to listen to the sound produced by the piano. I cook because I love to cook, not just to feed myself. I paint because I like to paint, not to stir interpretation. Aesthetic activities are carried out to bring out aesthetic qualities on an object or in a situation. The goal of the practice is the activity itself, in which the spontaneous element of the activity becomes manifest: to carry it out. Bringing out a floral arrangement with style, impressive harmony, beautiful form, these are spontaneous aesthetic achievements. It is attributable to me, precisely because I didn’t know exactly what it would be like, but I had to reflect on how to do it.

<a id="ch06-p011-zh"></a>
审美实践关联于一种特定构想：审美因素依赖于非审美品质的生产。审美效果由本身并非审美性的品质（就承载某一类感知判断而言）触发：形状、颜色、声音、体积。现在，即便自发性处于中心，也有两种“进行”方式：一种基于诀窍，另一种基于尝试。花艺布置或音乐作品的演绎，旨在重复和变化已知的非审美品质组合（花、音符）。许多审美实践满足于这种重复—变化，烹饪亦然。

<a id="ch06-p011-en"></a>
Aesthetic practices are related to a specific vision of the dependence of aesthetic factors on the production of non-aesthetic qualities. Aesthetic effects are triggered by qualities that are not *in themselv*es aesthetic (in the sense of carrying a certain type of perceptual judgement): shape, colour, sound, volume. Now, even if spontaneity is at the centre, there are two ways of ‘carrying out’: one based on know-how, the other on trying something out. The arrangement of flowers or the interpretation of a musical composition aims at the repetition and variation of already known combinations of non-aesthetic qualities (flowers, notes). Many aesthetic practices are sufficient in this repetition-variation, also cooking.

<a id="ch06-p012-zh"></a>
然而，艺术实践（也包括烹饪的艺术）超越了基于诀窍、模仿与练习的重复生产，因为它以这样一种构想为特征：一个最初仅属假设的审美效果，可能由新的、可能且可行的非审美品质类型之组合触发。换言之，艺术实践基于一个假设性的非审美品质组合方案。它基于尝试，基于实验性路径。

<a id="ch06-p012-en"></a>
Artistic practice (also the art of cooking), however, goes beyond repeated production, based on know-how, on imitation and exercise, in so far as it is characterized by the vision of an initially hypothetical aesthetic effect that could be triggered by a combination of new, possible and feasible types of non-aesthetic qualities. In other words, artistic practice is based on the project of a hypothetical combination of non-aesthetic qualities. It is based on trying-out, on experimental approaches.

<a id="ch06-p013-zh"></a>
尼克·赞格威尔称之为“审美洞见”。<a id="ref-zh-ch06-3"></a>[3](#note-zh-ch06-3) 确实，所有艺术作品都包含审美品质，无论剂量多少，因此也都基于这种审美洞见。但设计、好莱坞和宝莱坞电影的创造过程也是如此。审美洞见使文化产业得以存活。它们并非艺行所特有。

<a id="ch06-p013-en"></a>
Nick Zangwill calls this an ‘aesthetic insight’.<a id="ref-en-ch06-3"></a>[3](#note-en-ch06-3) It is true that all works of art contain, in whatever dose, aesthetic qualities, and are therefore also based on such aesthetic insights. But the same goes for creative processes in design, in Hollywood and Bollywood film. Aesthetic insights keep the culture industry alive. They are not specific to arting.

<a id="ch06-p014-zh"></a>
因此，必须划出鲜明的区分。审美品质（美、优雅、丑）不是艺术作品的唯一品质——也许甚至不是决定性品质。与形式已完成、被塑造成具有功能性的日常对象不同，艺术作品被评价为“大胆、无礼、不敬、机智而聪明”（这些是丹托用来标示杜尚《泉》区别于小便池的那些品质的表述）。<a id="ref-zh-ch06-4"></a>[4](#note-zh-ch06-4) 这些品质归赋指向一种可能性的构想，而非实际的审美品质。因此，艺术标准与审美标准并不相同。审美品质是艺术作品（或多或少）可直接感知的品质：成功的形式、令人震惊的颜色、不协和的声音。另一方面，艺术品质，如机智与原创性，是一种关系性品质，意味着与其他事件相比较。审美品质可感知。艺术品质则不可直接感知。

<a id="ch06-p014-en"></a>
Therefore it is important to draw a sharp distinction. Aesthetic qualities (beautiful, elegant, ugly) are not the only – or perhaps even the decisive – qualities of works of art. In contrast to everyday objects, which are formally finished and shaped to be functional, works of art are assessed as ‘daring, impudent, irreverent, witty and intelligent’ (these are the expressions with which Danto marks out the qualities by which Duchamp’s Fountain differs from a urinal).<a id="ref-en-ch06-4"></a>[4](#note-en-ch06-4) These attributions of qualities address a vision of possibilities and not actual aesthetic quality. Artistic and aesthetic criteria are therefore not identical. Aesthetic quality is a (more or less) directly perceptible quality of a work of art: a successful form, a shocking colour, a dissonant sound. On the other hand, artistic quality, such as wit and originality, is a relational quality and implies a comparison with other events. Aesthetic qualities are perceptible. Artistic qualities are not directly perceptible.

<a id="ch06-p015-zh"></a>
把某物限定为“大胆、无礼、不敬、机智而聪明”，是通过认识性知识的形容语，区分出先于实现的理解、引导方案的理解。*艺术*标准是认识性的；它们相对于一个概念集合把某物挑选出来。因此，艺术活动并不止于审美品质的生产。“制作艺术”所需的那类理解，不只是可能的新方式据以促进审美品质的那类理解。那么，仅有“审美洞见”还不够。毋宁说，人们所寻求的，可以称之为一种*艺术构想*。在艺术构想中，审美洞见是必要但肯定不充分的条件，因为艺术作品不能凭审美品质与其他事物区分，至少不能仅凭审美品质。从杜尚和沃霍尔到挪用艺术与制度批判，这一点已被充分证明。

<a id="ch06-p015-en"></a>
The qualification of something as ‘daring, impudent, irreverent, witty and intelligent’ distinguishes the understanding that precedes the realization, that which guides the project, by means of epithets of epistemic knowledge. *Artistic* criteria are epistemic; they single something out in relation to a conceptual set. Artistic doing is therefore not exhausted in the production of aesthetic qualities. The kind of understanding that is needed to ‘make art’ is not only the kind of understanding on which possible new ways of encouraging aesthetic qualities are based. An ‘aesthetic insight’ is then just not enough. Rather, what is sought, one might say, is an *artistic vision*. In an artistic vision, aesthetic insight is a necessary but certainly not sufficient condition, since works of art cannot be distinguished from other things, or at least not exclusively, by aesthetic qualities. From Duchamp and Warhol to Appropriation Art and Institutional Critique, this has been fully demonstrated.

<a id="ch06-p016-zh"></a>
艺术性的实现只间接依赖于我们感官的组织。仅仅因为我素描、绘画、拍电影、押韵、写书、跳舞或弹钢琴，并不意味着我在“制作”艺术。也不是因为我在反身性的星丛中联结或组合材料，我就在制作艺术。<a id="ref-zh-ch06-5"></a>[5](#note-zh-ch06-5) 因为这些活动也出现在毫无艺术性的语境中（垃圾分类厂、纪录片、电子游戏、电视新闻）。这类活动，就为从零生产的非审美安排而组合材料并组织感官而言，当然可以参与艺术的创造，但它们不是、或不再是艺术活动的标志。艺术活动已从审美实践中解放出来。

<a id="ch06-p016-en"></a>
An artistic realization is only indirectly dependent on the organization of our senses. Just because I draw, paint, make a film, rhyme, write a book, dance or play the piano does not mean that I ‘make’ art. Nor is it because I conjugate or combine material in a reflexive constellation that I make art.<a id="ref-en-ch06-5"></a>[5](#note-en-ch06-5) Because the same activities also appear in contexts that have nothing artistic about them (waste separation plants, documentaries, video games, television news). Activities of this kind, in the sense of a combination of the material and the organization of the senses for *de novo*-produced non-aesthetic arrangements, can certainly be involved in the creation of art, but they are not, or no longer, the hallmarks of an artistic activity. Artist activity has emancipated itself from aesthetic practices.

<a id="ch06-p017-zh"></a>
艺术性在于某物如何被制作，而不在于某物以何种方式存在；最重要的是实践的转化。但“实践的转化”本身并不构成对艺术的规定，因为第一，这种转化必须使我们相信它带来了有雄心的质性革新（仅凭任性——例如决定不再用手画画、而用脚画画——是不够的）；第二，实践的艺术转化与公共空间的转化紧密相连，而公共空间始终以随机的、未参与其中的人在场为特征。一种在公共空间中的实践转化，如果同时旨在转化公共空间，就会成为艺术活动的合适规定。艺术不是密谋者共同体的事务，也不是这样一个机构的事务：其道路不容任何偏离。相反，它投入自由的接受，投入对判断可能性的实验：只有通过（匿名的）公众进行判断的可能性，才潜在地赋予一个事件以艺术地位。无论基于鉴赏家的知识，还是基于审美经验，还是基于非审美的接受（震惊、直觉），还是作为愉悦与欲望的自发表达：艺术只存在于公共空间中，存在于与既定公众的交锋中，存在于对某事物展开公共辩论的创造中，存在于对显现空间的重新配置中。正因如此，强调审美对象与艺术作品之间的过渡以再现或展出为标志，是正确的。

<a id="ch06-p017-en"></a>
What is artistic is how something is made, not how something is something, and above all it is the transformation of the practice. But the ‘transformation of practice’ is not in itself a characterization of art, because, firstly, this transformation must convince us that it brings about an ambitious qualitative renovation (mere whim – for example, the decision to no longer paint with hands, but with feet – is not enough), and secondly, the artistic transformation of practice is closely linked to the transformation of public space, which is always characterized by the presence of random, uninvolved people. The transformation of a practice in public space would be a suitable qualification for artistic activity if it also aims at a transformation of the public space. Art is not the business of a community of conspirators; nor of an institution from the path of which nothing can deviate. On the contrary, it engages in free reception, in experimenting with the possibilities of judgement: only the possibility of judging through an (anonymous) public potentially confers the status of art on an event. Whether on the basis of a connoisseur’s knowledge, or on the basis of aesthetic experience, or on the basis of non-aesthetic reception (shock, intuition), or as a spontaneous expression of pleasure and desire: there is art only in the public space, in the confrontation with a given public, as the creation of a public debate about something, as the reconfiguration of the space of appearance. This is why it is right to stress that the passage between an aesthetic object and a work of art is marked by representation or exhibition.

<a id="ch06-p018-zh"></a>
尤莉安妮·雷本蒂施持对立观点。<a id="ref-zh-ch06-6"></a>[6](#note-zh-ch06-6) 对她而言，艺术作品本质上是对象经由经验而发生的反身性转化。据她说，这种转化不可控制，尤其因为经验指向外观，因而指向作品相对于其表演者的独立性。在外观中，对象向转化为艺术的过程敞开，并引发主体各种解释性与想象性的行动。这些行动作为审美判断被施行。<a id="ref-zh-ch06-7"></a>[7](#note-zh-ch06-7)

<a id="ch06-p018-en"></a>
Juliane Rebentisch takes an opposing view.<a id="ref-en-ch06-6"></a>[6](#note-en-ch06-6) For her, a work of art is essentially the reflexive transformation of an object through an experience. This transformation is uncontrollable, according to her, notably because experience refers to appearance, and therefore to the independence of works with regard to their performers. In appearance, objects open themselves to the process of transformation into art and give rise to all kinds of interpretative and imaginative acts by subjects. These are performed as aesthetic judgements.<a id="ref-en-ch06-7"></a>[7](#note-en-ch06-7)

<a id="ch06-p019-zh"></a>
但艺术作品之所以存在（哪怕只是作为“欣赏的候选者”），并不只是归功于制度，也不只是归功于经验或解释。艺术的对象或情境并非单纯被给予，而大多是形塑而成的，并需要被重新发明。艺术作品的体验并不是每个星期天再度指向同一组开放对象，而必须让自己暴露于某种尚无名称之物。

<a id="ch06-p019-en"></a>
But it is not only thanks to the institution, nor only thanks to experience or interpretation, that works of art exist in the first place (be it only as ‘candidates for appreciation’). Art’s objects or situations are not simply given, but are mostly formed and need to be reinvented. The experience of artworks is not directed at the same set of open objects every Sunday, yet again, but needs to expose itself to something that has no name yet.

<a id="ch06-s02-zh"></a>
## **艺行**

<a id="ch06-s02-en"></a>
## **Arting**

<a id="ch06-p020-zh"></a>
那么，艺术是生产我们无法辨认之物吗，正如阿多诺曾提出的那样？我们说，“制作艺术”就是完成一种艺术活动。但它真的是“做”或“制作”吗？完成是否意味着我随后生产了艺术，或我生产了艺术作品？不，严格来说，制作本身并不规定艺术活动，因为工作室助手或制作技师可以被委以这项任务，却不会因此成为艺术家。只要他们只生产别人所想象的东西，作品就不被归功于他们，即便他们最终因自己添加的品质而受到赞赏。细究之下，艺术家不是制作艺术的人。没有人通过完美复制而成为艺术家。即便独特之物的完美执行——技艺高超的助手或技师所能达到的那种——也不能使任何人成为艺术家。公众、观众常常是艺术作品生产的一部分——例如在互动性或关系性审美形式或观念艺术中。把艺术家提升到表演者与制作者群体之上的，是她关于某件待制作之物的观念，连同对一种新的制作*方式*的发展。这不仅是相对于另一件艺术作品的新方式，而是相对于艺术的新方式。

<a id="ch06-p020-en"></a>
Is art, then, the production of things we can’t identify, as Adorno once proposed? ‘To make art’, we said, is to accomplish an artistic activity. But is it really a ‘doing’ or ‘making’? Does the accomplishment imply that I then produce art or that I produce an artwork? No, strictly speaking the making itself does not characterize the artistic activity, because studio assistants or production technicians can be entrusted with the task without them becoming artists for all that. As long as they only produce what others have imagined, the work is not attributed to them, even if they are ultimately admired for the qualities they have added to it. On closer inspection, an artist is not the one who makes art. No one becomes an artist by perfectly copying. Even the perfect execution of the unique, such as can be achieved by highly skilled assistants or technicians, does not make anyone an artist. The public, the spectators, are often part of the production of the artwork – in interactive or relational aesthetic formats or conceptual art, for instance. What elevates an artist above the group of performers and manufacturers is her idea of something to be made, coupled with the development of a new *way* of making it. It is not just a new way with regard to another artwork, but to art.

<a id="ch06-p021-zh"></a>
*艺行*所指向的首先是自发性的实现，一种新的生成方式。去艺行并不意味着制作或生产任何东西。它意味着进行自身的重新发明。

<a id="ch06-p021-en"></a>
What is aimed at in *arting* is above all a spontaneous realization, a new mode of becoming. To art does not mean to make or produce anything. It means to carry out a reinvention of itself.

<a id="ch06-p022-zh"></a>
艺术有一种特定历史，并不等同于文化史，因为它不断重新发明自身。因此，艺术必须在其概念制度与社会制度之外被寻找。它是一种否定性的动力学；正因如此，存在艺术，却没有作为单一整体的“艺术”——只有多元的、争竞性的进路。关于艺术将成为什么的争执，处于艺术概念的中心。

<a id="ch06-p022-en"></a>
Art has a specific history, not identical with cultural history, because it is constantly reinventing itself. Art must therefore be sought outside its conceptual and social institutions. It is a dynamic of negation; and for this very reason there is art, but not ‘the art’ – only plural and agonal approaches. The quarrel about what art will become is at the centre of the concept of art.

<a id="ch06-p023-zh"></a>
因此，对艺术的概念进路的原创性，似乎成为艺术实践的一项要求。原创性是相对的标准。它是艺术作品的充分条件，但也许不是唯一条件。在这一点上，我不想被误解。此外，这里的原创性并不意味着“相同但不同”。艺术创造性产生一种新类型的观念、对象或事件。<a id="ref-zh-ch06-8"></a>[8](#note-zh-ch06-8) 具有艺术相关性的原创性是类型新颖性：它超越某一方面的单纯新颖或个体数目上的区别，最终指向概念转变。因为只有在一个艺术领域内、依照该领域现行的生成规则*迄今为止*不可能出现的东西，才能从艺术观点被视为原创：另一种说话方式，而不只是一个新短语。它将是某种会令所有熟悉现行生成规则、或对当代艺术有充分了解的人感到惊讶，甚至超出他们理解范围的东西。<a id="ref-zh-ch06-9"></a>[9](#note-zh-ch06-9)

<a id="ch06-p023-en"></a>
The originality of their conceptual approach to art seems therefore to be a requirement for artistic practices. Originality is a relative criterion. It is a sufficient, but perhaps not the only, condition for works of art. I don’t want to be misunderstood on this point. Furthermore, originality here does not mean ‘same but different’. Artistic creativity gives rise to ideas or objects or events of a new kind.<a id="ref-en-ch06-8"></a>[8](#note-en-ch06-8) Artistically relevant originality is genre novelty: it goes beyond the mere novelty of an aspect or numerical difference and ultimately aims at a conceptual shift. For only what could not have emerged *until now* within an artistic field, and in accordance with the generative rules in force there, can be considered original from an artistic point of view: another way of speaking, and not just a new phrase. It will be something that will surprise, or even surpass, all those who are familiar with the generative rules in force, or who have sufficient information about contemporary art.<a id="ref-en-ch06-9"></a>[9](#note-en-ch06-9)

<a id="ch06-p024-zh"></a>
决定性要素是一种概念跃迁，它把所寻求之物或所应做之事从自身概念中提升出来，并为迄今为止从范畴观点被排除之物打开一道裂隙。借助概念跃迁，艺术过程应当被分析为其构成规则、规范与惯例、框定它们的制度以及作为参照点的目的的对象化否定。每一个微小的否定都促成艺术作品概念的转变，并最终促成艺术概念的转变。

<a id="ch06-p024-en"></a>
The decisive element is a conceptual leap that elevates what is sought, or what ought to be done, out of its concept and opens a gap for what was hitherto excluded from a categorical point of view. With the conceptual leap, artistic processes should be analysed as the objectified negations of their constitutive rules, norms and conventions, of the institutions that frame them and of the purposes that serve as a point of reference. Every minuscule negation contributes to the transformation of the concept of the artwork, and ultimately the concept of art.

<a id="ch06-p025-zh"></a>
这种概念跃迁源于哲学实验。它们提供一种可能：相对于一个被证明不充分的感知图式，把握某种独异之物。如果艺术的首要取向是类型的新颖性，那不是因为它庆祝新颖，而是因为原初之物、新的类型是独异的、独特的——因为今天（仍然）独特的东西同时属于未来。<a id="ref-zh-ch06-10"></a>[10](#note-zh-ch06-10)

<a id="ch06-p025-en"></a>
Such conceptual leaps stem from philosophical experimentation. They offer the possibility of apprehending something singular in contrast to a scheme of perception whose inadequacy is proven. If art is above all oriented towards the novelty of the genre, it is not because it celebrates novelty, but because the originary, the new genre is singular, unique – because what is (still) unique today is, at the same time, of the future.<a id="ref-en-ch06-10"></a>[10](#note-en-ch06-10)

<a id="ch06-p026-zh"></a>
如果艺术活动的主要定向点不是当代性，而是初始性、非存在、未来性，那么哲学实验就需要成为它的一部分。艺术哲学不应再指向完成的、对解释开放的艺术作品——如主流审美经验理论所认为的那样——而应指向在其原创性主张上有所作为的活动；也就是说，指向艺术的施行。艺术的这种生成——艺行——必须与工作、制作、行动分离，也与表演和解释分离，只要后者严格受制于规则、制度与结果。

<a id="ch06-p026-en"></a>
If the main point of orientation of artistic activity is not contemporaneity, but initiality, inexistence, futurity, then philosophical experimentation needs to be part of it. Philosophy of art should no longer be directed towards finished works of art that are open to interpretation – as is the case under the dominant theories of aesthetic experience – but towards activities that make a difference in their claim to originality; that is, to the exercise of art. This becoming of art – arting – must be separated from work, from making, from action, but also from performance and interpretation, in so far as these are strictly subject to rules, institutions and result.

<a id="ch06-p027-zh"></a>
与经济创新的准则相比，激进的新是对构成规则的否定或变形。激进的新不是一个类别中的新要素；它作为无类别的聚集体而是新的。作为概念跃迁，它关联于自己所脱离之物，并且通过检验新的基础、规则与实施方式——这些不能从先前被认为有效的东西中推演出来——而做到这一点。激进想象显露于过程之中，而非产品之中。

<a id="ch06-p027-en"></a>
Compared with the maxims of economic innovation, the radically new is the negation or metamorphosis of the constituent rules. The radically new is not a new element in a class; it is new as a conglomerate without classes. As a conceptual leap, it relates to what it stands out from, and moreover it does so by testing new bases, rules and modes of implementation that are non-deductible from what was known as valid before. It is in the process, not in the product, that radical imagination is revealed.

<a id="ch06-p028-zh"></a>
艺行作为一个过程，指一种（自我）创造性行动；它可以相对于研究者的系统性“发现”、工程师的发明、自然演化，以及设计师、理发师和厨师的职业创造性而被界定。它不是一种人确知如何施行的行动，而始终是在未知领域中的试错路径。艺行不遵从外部规定，甚至不遵从不断产出的律令，因为它是对失败可能性及这一可能性之条件的直面，是对实现之风险的直面。艺行不同于绘画、造型或音乐实践，不同于重复或即兴，因为像游戏一样，它就在自身的施行中完成。它不同于游戏之处在于，它不预设或实施具体规则，而总是从确立规则开始。在其他追求相对新意的职业创造性形式中（从炫技表演、新一季时尚到工程师的发明），艺行以缺乏任何适当性要求而区别开来。

<a id="ch06-p028-en"></a>
Arting as a process refers to the (self-)creative action that can be delimited in relation to the systematic ‘findings’ of the researcher, the invention of the engineer, to natural evolution, to the professional creativity of designers, hairdressers and cooks. It is not an act which one knows firmly how to perform, but always a trial-and-error approach in the field of the unknown. Arting does not comply with external prescriptions, not even the imperative of productivity, because it is a confrontation with the possibility of failure and the condition of this possibility, with the risk of the realization. Arting differs from pictorial, plastic or musical practice, from repetition or improvisation because, like play, it is completed in accomplishment. It differs from play in that it does not suppose or implement concrete rules, but always begins by establishing them. Of the other forms of professional creativity in which one seeks the relatively new (from virtuoso performance, fashion for the new season, the engineer’s inventions), arting is distinguished by the absence of any requirement of adequacy.

<a id="ch06-p029-zh"></a>
必须为其发明满足适当性要求的审美实践，局限于对少数规则的可理解转化，以保持可识别性和可归属性。艺术不以同样方式受制于此。因为艺术中的新离开了既定概念、感知模式与行动形式的轨道。因此，艺术也要求悬置自我理解。这种悬置可能导致现实变得陌生，导致现实之外的东西影响感官，或导致某事在注意乃至感知的阈限之下发生并显现。对主体技术的否定、现实形式的改变以及构成规则的变形，可以被设想为内在的艺术行动。

<a id="ch06-p029-en"></a>
Aesthetic practices that have to satisfy claims of adequacy for their inventions limit themselves to the comprehensible transformation of a few rules in order to remain recognizable and attributable. Art is not subject to this in the same way. For what is new in art goes off the rails of established concepts, patterns of perception and forms of action. Art therefore also requires a suspension of self-understanding. This suspension can result in reality becoming alien, in something other than reality affecting the senses, or in something happening and manifesting itself below the threshold of attention and even perception. The negation of the subject’s techniques, the change of form of the real and the metamorphosis of the constitutive rules can be conceived as intrinsic artistic acts.

<a id="ch06-p030-zh"></a>
那么，艺行不是绘画、雕塑、舞蹈、音乐、戏剧、写作和影像制作的总和或统称。不仅有个别艺术与个别艺术对象，还有作为一种艺术形式的艺行。

<a id="ch06-p030-en"></a>
Arting, then, is not the sum of or generic term for painting, sculpture, dance, music, theatre, writing and video-making. There is not only individual arts and individual art objects, but also arting as an art form.

<a id="ch06-s03-zh"></a>
## **未来性与自主**

<a id="ch06-s03-en"></a>
## **Futurity and autonomy**

<a id="ch06-p031-zh"></a>
从更总体的层面思考，艺术实现——通过孤立、动员并模块化事件的品质——使某种在现实秩序中尚不算数之物行动。在探究成为现实的可能性时，它也探究非现实的前提。对艺行而言，一个艺术集体必须投入去现实化过程，并探究事件的前提及其可受影响性。艺术所特有的对时间可能性的检验，始于一种脱离过程：脱离归属，脱离固定的因果结构，脱离注意力装置，脱离延展或收缩当下的发生场域。

<a id="ch06-p031-en"></a>
Thought in more global terms, artistic realization – by isolating, mobilizing and modularizing the qualities of events – makes something act that does not yet count in the order of reality. At the same time as it probes the possibilities of a becoming reality, it probes the presuppositions of irreality. For arting, an art collective must engage in a process of derealization and probe the presuppositions and the influenceability of events. The art-specific testing of temporal possibilities begins with the process of detachment with regard to belonging, with regard to fixed structures of cause and effect, with regard to devices of attention, with regard to fields of occurrence that extend or contract a present.

<a id="ch06-p032-zh"></a>
*艺行由此脱离其主体性、其文化、其传统、其在时间中的位置*。艺术性的去认同消解那些关系固着：它们执拗地使我们把某物看作某物、把某物看作另一物中的某物、看作方面的序列、意义的序列。当艺行方式集体地允许一种新的想象界时，也就是当它们发明现实之外的效果时，它们便是原初的。艺术的实现就是艺行：一种实现的展示，一次朝向未来性的伸展。

<a id="ch06-p032-en"></a>
*Arting thus detaches itself from its subjectivity, from its culture,* *from its tradition, from its place in time*. Artistic disidentifications dissolve the fixations of relationships that obsessively make us see something as something, something in something, sequences of aspects, sequences of meaning. Ways of arting are originary when they allow, collectively, a new imaginary; that is to say, when they invent effects beyond reality. The realization of art is arting: the exhibition of a realization, an outreach toward futurity.

<a id="ch06-p033-zh"></a>
正如科内利乌斯·卡斯特里亚迪斯所表明的，现实只存在于一种激进想象的基础上，这种想象带出模式、形象与概念。<a id="ref-zh-ch06-11"></a>[11](#note-zh-ch06-11) 这恰恰不发生在艺术的新封建殿堂及其对全球当下的固着之中。<a id="ref-zh-ch06-12"></a>[12](#note-zh-ch06-12) 正是通过把艺行从它与媒介技术当下的策略、乃至与定义当代艺术的“当代”的缠绕中解放出来，我们才抵达未来艺术。因此，需要的是一种对当代性的哲学批判。从当代艺术迈向未来艺术的这一步，需要艺行哲学。

<a id="ch06-p033-en"></a>
As Cornelius Castoriadis has shown, reality only exists on the basis of a radical imagination that brings out patterns, figures and concepts.<a id="ref-en-ch06-11"></a>[11](#note-en-ch06-11) This does not happen precisely in the neo-feudal temples of art and their fixation on the global now.<a id="ref-en-ch06-12"></a>[12](#note-en-ch06-12) It is by freeing arting from its intertwining with the strategies of the media-technological present, or even with the contemporary defining contemporary art, that we arrive at future art. What is needed is therefore a philosophical critique of contemporaneity. This step from contemporary to future art requires arting philosophy.

<a id="ch06-p034-zh"></a>
自主的思想、行动与感知只能在与非现实的关联中存在，现实正是从非现实中产生。因此，艺行也意味着一种内在于艺术的赋权过程：以艺术的未来之名，基于对形象／形式／图像的无条件创造，对迄今为止所实践之艺术的基础与规则进行批判。这一内在于艺术的艺行过程，是一项更总体的自主化工作的要素。

<a id="ch06-p034-en"></a>
Autonomous thought, action and perception can only exist in connection with the unreal from which the real arises. Consequently, arting also implies a process of empowerment immanent to art: a critique of the foundations and rules of the art practised so far, based on the unconditional creation of figures/ forms/images, in the name of a future of art. This process of arting, immanent to art, is an element of a more global work of autonomization.

<a id="ch06-p035-zh"></a>
艺术是一种自由的实现。一种能够实现这一点的艺术哲学，因此是艺术实践的组成部分。

<a id="ch06-p035-en"></a>
Art is a free realization. A philosophy of art that achieves this is therefore an integral part of artistic practice.

### 原注

<a id="ch06-n001-zh"></a><a id="note-zh-ch06-1"></a>
[1] 本文基于我的著作 *Notate for eine künftige Kunst*，Berlin: Merve, 2016。 [返回](#ref-zh-ch06-1)

<a id="ch06-n001-en"></a><a id="note-en-ch06-1"></a>
[1] This essay is based on my book, *Notate for eine künftige Kunst*, Berlin: Merve, 2016. [返回](#ref-en-ch06-1)

<a id="ch06-n002-zh"></a><a id="note-zh-ch06-2"></a>
[2] Alexander García Düttmann, ‘De-arting’, in Peter Osborne, ed., *From an Aesthetic Point of View: Philosophy, Art and the Senses*, London: Serpent’s Tail, 2000, pp. 71–87。 [返回](#ref-zh-ch06-2)

<a id="ch06-n002-en"></a><a id="note-en-ch06-2"></a>
[2] Alexander García Düttmann, ‘De-arting’, in Peter Osborne, ed., *From an Aesthetic* *Point of View: Philosophy, Art and the Senses*, London: Serpent’s Tail, 2000, pp. 71–87. [返回](#ref-en-ch06-2)

<a id="ch06-n003-zh"></a><a id="note-zh-ch06-3"></a>
[3] Nick Zangwill, *Aesthetic Creation*, Oxford: Oxford University Press, 2012 (2007), pp. 42–3。 [返回](#ref-zh-ch06-3)

<a id="ch06-n003-en"></a><a id="note-en-ch06-3"></a>
[3] Nick Zangwill, *Aesthetic Creation*, Oxford: Oxford University Press, 2012 (2007), pp. 42–3. [返回](#ref-en-ch06-3)

<a id="ch06-n004-zh"></a><a id="note-zh-ch06-4"></a>
[4] Arthur C. Danto, *The Transfiguration of the Commonplace: A Philosophy of Art*, Cambridge MA and London: Harvard University Press, 1981, pp. 93–4. 参见 Zangwill, *Aesthetic Creation*, p. 66。 [返回](#ref-zh-ch06-4)

<a id="ch06-n004-en"></a><a id="note-en-ch06-4"></a>
[4] Arthur C. Danto, *The Transfiguration of the Commonplace: A Philosophy of Art*, Cambridge MA and London: Harvard University Press, 1981, pp. 93–4. Cf. Zangwill, *Aesthetic Creation*, p. 66. [返回](#ref-en-ch06-4)

<a id="ch06-n005-zh"></a><a id="note-zh-ch06-5"></a>
[5] 这就是迪特·梅尔施对艺术实践的界定。Dieter Mersch, *Epistemologien des Ästhetischen*, Zürich: Diaphanes, 2015, p. 171。 [返回](#ref-zh-ch06-5)

<a id="ch06-n005-en"></a><a id="note-en-ch06-5"></a>
[5] This is how Dieter Mersch defines artistic practice. Dieter Mersch, *Epistemologien* *des Ästhetischen*, Zürich: Diaphanes 2015, p. 171. [返回](#ref-en-ch06-5)

<a id="ch06-n006-zh"></a><a id="note-zh-ch06-6"></a>
[6] Juliane Rebentisch, *Theorien der Gegenwartskunst zur Einführung*, Hamburg: Junius Verlag, 2013, p. 49。 [返回](#ref-zh-ch06-6)

<a id="ch06-n006-en"></a><a id="note-en-ch06-6"></a>
[6] Juliane Rebentisch, *Theorien der Gegenwartskunst zur Einführung*, Hamburg: Junius Verlag, 2013, p. 49. [返回](#ref-en-ch06-6)

<a id="ch06-n007-zh"></a><a id="note-zh-ch06-7"></a>
[7] 同上，第51、55页。 [返回](#ref-zh-ch06-7)

<a id="ch06-n007-en"></a><a id="note-en-ch06-7"></a>
[7] Ibid., pp. 51, 55. [返回](#ref-en-ch06-7)

<a id="ch06-n008-zh"></a><a id="note-zh-ch06-8"></a>
[8] 一个行为或过程要被视为创造性的，就不能是偶然的或机械地产生某一结果。见 Berys Gaut, ‘Creativity and Imagination’, in Berys Gaut and Paisley Livingston, *The Creation of Art: New Essays in Philosophical Aesthetics*, Cambridge: Cambridge University Press, 2003, p. 151。 [返回](#ref-zh-ch06-8)

<a id="ch06-n008-en"></a><a id="note-en-ch06-8"></a>
[8] For an act or process to be considered creative, it must not be the accidental or mechanical production of a result. See Berys Gaut, ‘Creativity and Imagination’, in Berys Gaut and Paisley Livingston, *The Creation of Art: New Essays in Philosophical Aesthetics*, Cambridge: Cambridge University Press, 2003, p. 151. [返回](#ref-en-ch06-8)

<a id="ch06-n009-zh"></a><a id="note-zh-ch06-9"></a>
[9] 参见 Margaret A. Boden, ‘What is Creativity?’, in *Dimensions of Creativity*, Cambridge MA and London: MIT Press, 1996, p. 76。 [返回](#ref-zh-ch06-9)

<a id="ch06-n009-en"></a><a id="note-en-ch06-9"></a>
[9] Cf. Margaret A. Boden, ‘What is Creativity?’, in *Dimensions of Creativity*, Cambridge MA and London: MIT Press, 1996, p. 76. [返回](#ref-en-ch06-9)

<a id="ch06-n010-zh"></a><a id="note-zh-ch06-10"></a>
[10] “每件艺术作品的形式与内容，若以最高精确性把握，始终是某种独一无二、首次出现之物。”Walter Benjamin, ‘Zur Ästhetik: Fragmente vermischten Inhalts’, in *Gesammelte Schriften*, vol. 6, Frankfurt am Main: Suhrkamp, 1968, p. 125。 [返回](#ref-zh-ch06-10)

<a id="ch06-n010-en"></a><a id="note-en-ch06-10"></a>
[10] ‘Die Form und der Gehalt jedes Kunstwerkes ist, denn man sie in höchster Genauigkeit faßt, stets etwas Einmaliges und Erstmaliges.’ Walter Benjamin, ‘Zur Ästhetik: Fragmente vermischten Inhalts’, in *Gesammelte Schriften*, vol. 6, Frankfurt am Main: Suhrkamp. 1968, p. 125. [返回](#ref-en-ch06-10)

<a id="ch06-n011-zh"></a><a id="note-zh-ch06-11"></a>
[11] Cornelius Castoriadis, *The Imaginary Institution of Society: Creativity and Autonomy in the Socio-Historical World*, Cambridge: Polity Press, 1997 (1975)。 [返回](#ref-zh-ch06-11)

<a id="ch06-n011-en"></a><a id="note-en-ch06-11"></a>
[11] Cornelius Castoriadis, *The Imaginary Institution of Society: Creativity and Autonomy* *in the Socio-Historical World*, Cambridge: Polity Press, 1997 (1975). [返回](#ref-en-ch06-11)

<a id="ch06-n012-zh"></a><a id="note-zh-ch06-12"></a>
[12] 按彼得·奥斯本的说法，当代艺术是后观念的、跨范畴的、跨媒介的；它通过国际艺术空间找到自己的身份。双年展之类的国际展览使艺术作品服从于一种全球主义叙事。奥斯本对当代艺术的抵抗潜能及其与未来性的关系抱乐观态度：“在其最佳状态下，当代艺术示范着否定性的实验实践，刺穿期待的视界。”Peter Osborne, *Anywhere or Not at All: Philosophy of Contemporary Art*, London and New York: Verso, 2013, p. 211。 [返回](#ref-zh-ch06-12)

<a id="ch06-n012-en"></a><a id="note-en-ch06-12"></a>
[12] Contemporary art, according to Peter Osborne, is post-conceptual, transcategorial, intermedial; it finds its identity through international art spaces. International exhibitions such as biennials subject works of art to a narrative of globalism. Osborne is optimistic about the potential of resistance in contemporary art and its relation to futurity: ‘At its best, contemporary art models experimental practices of negation that puncture horizons of expectation.’ Peter Osborne, *Anywhere or Not at All: Philosophy of* *Contemporary Art*, London and New York: Verso, 2013, p. 211. [返回](#ref-en-ch06-12)

## 第7章　情境图表：论当代艺术中语境与形式的解／重组之呈现

<a id="ch07-title-zh"></a>
## 情境图表：论当代艺术中语境与形式的解／重组之呈现

<a id="ch07-title-en"></a>
## The situational diagram: on rendering the de/recomposition of context and form in contemporary art

<a id="ch07-author-zh"></a>
贾莱赫·曼苏尔

<a id="ch07-author-en"></a>
JALEH MANSOOR

<a id="ch07-q001-zh"></a>
> 资本与劳动的剩余从一个地区向另一个地区的平稳转移，在整个体系内部创造出一种补偿性振荡的模式。

<a id="ch07-q001-en"></a>
> The smooth switching of surpluses of capital and labour from one region to another create[s] a pattern of compensatory oscillations within the whole.

<a id="ch07-a001-zh"></a>
大卫·哈维，《资本的限度》<a id="ref-zh-ch07-1"></a>[1](#note-zh-ch07-1)

<a id="ch07-a001-en"></a>
David Harvey, *The Limits to Capital*<a id="ref-en-ch07-1"></a>[1](#note-en-ch07-1)

<a id="ch07-q002-zh"></a>
> 线条无法逃脱它进入世界时的现在时态，正如它无法逃入油画那抹除与隐藏的秘密藏身之处。因此，这一根本状况能使它比图像更接近观者自身的处境。

<a id="ch07-q002-en"></a>
> Line can no more escape the present tense of its entry into the world than it can escape into oil paint’s secret hiding place of erasure and concealment. This fundamental condition can bring it, therefore, much closer to the viewer’s own situation than can the image.

<a id="ch07-a002-zh"></a>
诺曼·布赖森<a id="ref-zh-ch07-2"></a>[2](#note-zh-ch07-2)

<a id="ch07-a002-en"></a>
Norman Bryson<a id="ref-en-ch07-2"></a>[2](#note-en-ch07-2)

<a id="ch07-p001-zh"></a>
对艺术史——一门奠基于十九世纪民族主义的学科——而言，“语境”意味着什么？在这门学科中，地点、时间与风格相互定位，在不同历史时刻构成一个连贯的启发式框架：1945年之后、1973年之后，以及再次的现在？我们又当如何找到术语，来描述在艺术博览会与双年展、在既有博物馆与资产阶级公共领域（如尤尔根·哈贝马斯所称）的建制中遭遇的众多零散而显然互不相关的潮流中，当代艺术的流行趋向——尽管在全球资本之下，“资产阶级”的含义正如“语境”一词一样迅速变化？这两个问题看似无关，直到一种模式开始显现，暗示着一个问题对另一个问题的依赖。图表就是这些问题在其中汇聚、或被表明早已缠绕在一起的（审美）操作。这一图形实践模式早在两次世界大战之间的历史先锋派中便已运作（布朗库西、杜尚、毕卡比亚），并在过去六十年中升至主导地位：皮耶罗·曼佐尼、温琴佐·阿涅蒂、巴里·弗拉纳根、汉斯·哈克、马塞尔·布达埃尔、多萝西娅·罗克伯恩、理查德·汉密尔顿、阿格尼丝·德内斯、南希·霍尔特、李·洛扎诺、安娜·玛丽亚·马约利诺、理查德·塔特尔、马克·隆巴迪、加布里埃尔·奥罗斯科、埃伦·加拉格尔、威廉·肯特里奇、卡拉·沃克、克里斯托瓦尔·莱特、朱莉·梅赫雷图、丹尼尔·泽勒与 Nobuya Hoki。<a id="ref-zh-ch07-3"></a>[3](#note-zh-ch07-3)

<a id="ch07-p001-en"></a>
What does ‘context’ mean for art history, a discipline founded in the nationalisms of the nineteenth century, wherein place, time and style have triangulated to form a coherent heuristic frame at different historical moments: after 1945, after 1973 and again now? And how do we find the terms to describe prevailing tendencies in contemporary art among the numerous scattered and apparently unrelated trends encountered at art fairs and biennials, and in established museums and institutions of the bourgeois public sphere, as Jürgen Habermas called it, although what ‘bourgeois’ means under global capital is shifting as rapidly as the term ‘context’? These two questions appear unrelated until a pattern begins to emerge suggesting the dependence of one question on the other. The diagram is one (aesthetic) operation within which the questions converge, or are shown to be already entwined. Already operative in the historical avant-gardes of the interwar period (Brancusi, Duchamp, Picabia), this modality of graphic practice has risen to dominance over the last sixty years: Piero Manzoni, Vincenzo Agnetti, Barry Flanagan, Hans Haacke, Marcel Broodthaers, Dorothea Rockburne, Richard Hamilton, Agnes Denes, Nancy Holt, Lee Lozano, Anna Maria Maiolino, Richard Tuttle, Mark Lombardi, Gabriel Orozco, Ellen Gallagher, William Kentridge, Kara Walker, Cristobal Lehyt, Julie Mehretu, Daniel Zeller and Nobuya Hoki.<a id="ref-en-ch07-3"></a>[3](#note-en-ch07-3)

<a id="ch07-p002-zh"></a>
或许，比艺术史“方法”问题更为根本地，语境问题对批评构成压力，因为艺术实践已经表明，世界的“解域”与“再域化”在多大程度上影响了再现形式（如素描）得以连贯并产生意义——得以展示并讲述这个“世界”——的基本可用性。<a id="ref-zh-ch07-4"></a>[4](#note-zh-ch07-4) 于是，图表或线的指示功能兴起了。线被赋予传达数据与信息的任务，而非建立轮廓、把图形与背景分开并呈现再现的基本要素——这曾是它的历史功能。再现的基本工具在我们所认识的那些旧形式无法表征的世界变化之后被表明失效，这本身已是需要新形式与新术语的极端症候。艺术与精微的文化生产预兆性地症候化了那些尚无法清晰表述的剧烈转变：它们先发生于经济领域，随后开始在社会场域中回荡。它做到这一点的方式，是挪用／再挪用那些传统上属于理性化形式的装置，如图表；这些理性化形式曾是所谓“基础”相对于“上层建筑”的根基。<a id="ref-zh-ch07-5"></a>[5](#note-zh-ch07-5) 无论这一过程的描述显得多么循环，艺术生产都是原因与效果回路上的一个位置，可在那里定位时间之真实运动、以及与资源、价值和社会再生产之代谢交换的病因学。

<a id="ch07-p002-en"></a>
Running more fundamentally, perhaps, than even the question of art-historical ‘method’, the question of context presses on criticism given that art practices have shown the degree to which the ‘de-’ and ‘reterritorialization’ of the world have affected the basic availability of forms of representation, such as drawing, to cohere and to make sense – to show and to tell about this ‘world’.<a id="ref-en-ch07-4"></a>[4](#note-en-ch07-4) And so one sees the rise of the diagram or indexical functions of line. Line is tasked to convey data, information, rather than to establish contour, divide a figure from ground, and present the rudiments of representation, its historical function. That the basic tools of representation are shown to fail in the wake of world changes that exceed their own representability by the old forms as we recognize them is already an extreme symptom of the need for new forms and new terms. Art and rarified cultural production presciently symptomatize the yet inarticulable seismic shifts that occur first in the economic sphere, then begin to resonate throughout the social field. It does so by means of appropriating/reappropriating the very devices, such as of the diagram, which traditionally belong to forms of rationalization foundational to what was once known as the ‘base’ in relation to a ‘superstructure’.<a id="ref-en-ch07-5"></a>[5](#note-en-ch07-5) Circular as the description of this process may seem, artistic production is one place along a circuit of cause and effect to locate an aetiology of the real movement of time and the metabolic exchange with resources, value and social reproduction.

<a id="ch07-p003-zh"></a>
图表常被挪用为一种认知测绘的形式。它取代了欧洲艺术史上所理解的素描。素描曾是再现的基石，把充盈的视觉场分解为图形与背景，随后保证所描绘身体相对于空间包膜的完整性。线性形式的生产与操控能力长期被视为技艺的基石，到二十世纪初也已成为一种表现能力的载体——在维也纳与中欧语境中尤其如此，那里深受浪漫主义影响。正如莫莉·内斯比特在《Their Common Sense》中有力论证的，杜尚式现成品——克劳斯的“理论对象”——是工业设计的功能。<a id="ref-zh-ch07-6"></a>[6](#note-zh-ch07-6) 内斯比特指出，杜尚那一代是法国公立学校体系中第一批被强制教授设计素描的人，表面上的目的是培养工程师与工厂工人。无论如何，图表的特殊可供性双重地重新引入了生产代谢与艺术力比多经济之间的困难关系。<a id="ref-zh-ch07-7"></a>[7](#note-zh-ch07-7) 它的能力在于表达诸项之间运动的独特辩证法，既在历时性层面、即历史性层面上，又在结构并决定任何主体对现代性总体之把握过程的静止层面。它测绘主体化过程。更确切地说，它把主体化过程测绘为一种与物化紧密相关但并不等同于物化的过程，预示了朗西埃在《阅读〈资本论〉》中关于主体与生产、与其对象即商品、并最终与价值形式和市场抽象之间迂回而中介化之关系的主张。

<a id="ch07-p003-en"></a>
The diagram is often appropriated as a form of cognitive mapping. It displaces drawing as it had been understood in the history of European art. Drawing had been the cornerstone of representation, breaking the visual plenum into figure and ground, then guaranteeing the integrity of a depicted body against the envelope of space. Long understood to be a cornerstone of skill, the capacity to produce and manipulate linear form had also by the opening of the twentieth century come to be a vehicle of expressive capacity, notably in the Viennese and central European context with its debt to Romanticism. As Molly Nesbit convincingly argues in *Their Common Sense*, the Duchampian readymade – Krauss’s ‘theoretical object’ – is a function of industrial design.<a id="ref-en-ch07-6"></a>[6](#note-en-ch07-6) Nesbit notes that Duchamp’s gen eration was the first to be taught mandatory drawing-for-design in the French public-school system, ostensibly to train engineers and factory workers alike. Be that as it may, the diagram’s special affordance doubly reintroduced the difficult relation between the metabolic of production and the libidinal economy of art.<a id="ref-en-ch07-7"></a>[7](#note-en-ch07-7) Its capacity to express the singular dialectic of movement among terms on both a diachronic register, or that of historicity, and the stasis structuring and determining the process by which any subjective grasp on the totality of modernity could be made. It maps the process of subjectivization. More to the point, it maps the process of subjectivization as one bound up with, but not identical to, reification, anticipating Rancière’s claims in *Reading* *Capital* about the subject’s circuitous and mediated relation to production, to its object the commodity, and ultimately to the value form and abstraction of the market.

<a id="ch07-p004-zh"></a>
二十世纪早期的先锋派并不缺少先见之明，尤其是在“语境”的解域方面——“语境”曾是“艺术史”的基石——以及向图表之无界无边的经济的转变方面。未来主义、达达，以及二者相遇所产生的各种混杂体，似乎为晚于它们的时代、也就是我们的当下，充当了一种辩证的研究与开发。另一种表述方式是借用杰里米·吉尔伯特为毛里齐奥·拉扎拉托论杜尚现成品——作为不生产价值的管理劳动的化身——之分析所写序言中的术语，说它们，即先锋派，已经*预先认知*了它们的未来，也就是我们的当下。<a id="ref-zh-ch07-8"></a>[8](#note-zh-ch07-8)

<a id="ch07-p004-en"></a>
The avant-gardes of the early twentieth century demonstrate no shortage of clairvoyance, not least with relation to the deterritorialization of ‘context’, once the bedrock of ‘art history’, and the shift to the boundless and borderless economy of the diagram. Futurism, Dada and the assorted hybrids generated of their mutual encounters seem to have acted as a form of dialectical research and development for the era post-dating them, which is to say our current moment. Another way to formulate the thought would be to borrow a term from Jeremy Gilbert’s preface to Maurizio Lazzarato’s analysis of the Duchampian readymade as avatar to non-value productive managerial labour and say that they, the avant-gardes, have *pre-cognized* it their future and our present.<a id="ref-en-ch07-8"></a>[8](#note-en-ch07-8)

<a id="ch07-p005-zh"></a>
自1960年代起，图表与图解在众多当代实践中日益压过图像，是实在界层面剧烈变化的强烈症候。艺术，尤其在其最自主的时候，在变化于话语中被象征化和形式化之前，便预演并症候化了实在领域中的变化。

<a id="ch07-p005-en"></a>
From the 1960s on, that the chart and diagram increasingly overtake the image in many contemporary practices is a strong symptom of seismic changes on the register of the real. Art, especially when it is most autonomous, prefigures and symptomatizes changes in the field of the real before they are symbolized and formalized in discourse.

<a id="ch07-p006-zh"></a>
然而，图表式思维早在1960年代之前就已在艺术中被动员。人们早已针对构成主义及二十世纪初的其他实践指出：“图表线虽取自科学与技术制图的领域……最终作品却具有记谱的要素。作品并不‘再现世界’（如果这指的是具象艺术所用的模型），而是通过联想、材料、方法的流通，包含对生产它的世界的暗示。”<a id="ref-zh-ch07-9"></a>[9](#note-zh-ch07-9) 也许较少被阐发的是，这一转变在多大程度上回荡于整个世纪，并取代具象，使实在与其接受之间、或基础与上层建筑之间中介过程中那些否则无法描绘、不可见的转变变得可感知。此处的关键，是线被期待传达意义之层面的转变。以记谱取代轮廓与模仿，这一处于基本视觉实践核心的转变，标示出与内容及意义在根本层面上的分解和重组之间更为深刻的关系，或许并非不像图像在技术可复制性之后所经历的转变——如本雅明著名描述的那样。本文的赌注是：语境的（不）连贯性，乘着晚期资本主义现代性中图表问题的浪潮而来。

<a id="ch07-p006-en"></a>
However, diagrammatic thinking was mobilized in art well before the 1960s. It has long been noted with reference to constructivism and other practices of the early twentieth century that while ‘the diagrammatic line is drawn from the realm of science and technical drawing … the final work has elements of notation. The works do not “represent the world” if that is taken to be the model used in figurative art, but they contain allusions to the world in which they were produced by the currency of associations, materials, methods.’<a id="ref-en-ch07-9"></a>[9](#note-en-ch07-9) Less elaborated, perhaps, is the degree to which the shift reverberates through the century and, replacing figuration, renders perceptible otherwise unfigurable and invisible shifts in the mediation between the real and its reception, or between the base and the superstructure. The key here is the shift in the register within which line is expected to deliver meaning. Replacing contour and mimesis with notation, this transition at the heart of basic visual practice signals a more profound relation to the de- and recomposition of content and meaning at a fundamental level, perhaps not unlike the transition the image underwent in the wake of technological reproducibility, as famously described by Benjamin. It is the gambit of this essay that the in/coherence of context rides in on the question of the diagram in late capitalist modernity.

<a id="ch07-p007-zh"></a>
把这些先锋派联结起来的唯一因素，是它们对大众主体、对普通人以及“他”作为大众主体进入历史舞台——无论自觉与否——的执拗关注。哈尔·福斯特以一个问题总结这一病因学，自2008年、上一轮重大资本主义危机开始之际读到他的《义肢之神》以来，我一直反复回到这个问题：“未来主义会不会并不像它看起来那样异常？会不会此时盛期现代主义的真正赌注，恰恰涉及与物化和死亡的赌局？”<a id="ref-zh-ch07-10"></a>[10](#note-zh-ch07-10) 这一赌局是否可能采取图表的形式与运作方式？我在此的主张是：毕卡比亚——甚至早于杜尚，尽管我对起源神话或对原创性的所有权主张不感兴趣——以图表的运动取代了图像与符号、图画与词语（分别是图像再现与诗学中模仿的基石），图表在此测绘欲望关系并铭刻一种社会动力学。

<a id="ch07-p007-en"></a>
The single factor binding these avant-gardes was their obsessive preoccupation with the mass subject, with the everyman and ‘his’ entry qua mass subject onto the arena of history, consciously or otherwise. Hal Foster concludes this aetiology with a question that I have returned to since reading his *Prosthetic Gods* in 2008, at the beginning of the last major round of capitalist crisis: ‘could it be that Futurism is not as aberrant as it appears? Could it be that the very stake of high modernism at this time involves wagers with reification and death?’<a id="ref-en-ch07-10"></a>[10](#note-en-ch07-10) Might this wager take the form and operational mode of a diagram? My claim here is that Picabia, before even Duchamp – although I am not interested in origin myths or property claims to originality – displaces both icon and symbol, both picture and word (the cornerstones of mimesis in pictorial representation and poetics respectively), for the movement of the diagram as it charts relations of desire and inscribes a social dynamic.

<a id="ch07-s01-zh"></a>
## **毕卡比亚与杜尚**

<a id="ch07-s01-en"></a>
## **Picabia and Duchamp**

<a id="ch07-p008-zh"></a>
在弗朗西斯·毕卡比亚的《普遍的卖淫》（1916—17）与杜尚的《Tu m’》（1918）中，图表是一种经济运动的索引，这种经济被一条在词语与图像之下如河流般奔涌的力比多经济所联结又所阻遏。杜尚此时与毕卡比亚密切合作；毕卡比亚的《没有母亲的女孩》（1917）、二人各自的《L.H.O.O.Q.》（均完成于1919年），以及毕卡比亚1920年的《年轻女孩（机械形态）》——合起来不过少数几件作品——构成进入这一术语星丛的入口：物化、主体化、经由价值形式的抽象。杜尚的《Tu m’》展示了一系列实验：现成品及相关偶然性策略，通过自行车轮等著名现成品的投影，以指示方式呈现。

<a id="ch07-p008-en"></a>
The diagram is an index of the movements of an economy articulated and thwarted by a libidinal economy coursing like a river below words and pictures, in Francis Picabia’s *Universal Prostitution* (1916–17) and Duchamp’s *Tu m’* (1918). Duchamp was at this time working closely with Picabia, whose *Girl Born without a Mother* (1917) and his and Marcel Duchamp’s respective \*L.H.O.O.Q.\*s (both completed in 1919), and finally Picabia’s *Jeune Fille (Mécanomorph)* of 1920 – together, a handful works – constitute a point of entry into the constellation of terms: reification, subjectivization, abstraction-by-value-form. Duchamp’s *Tu m’* showcases a range of the artist’s experiments with the readymade and related strategies of contingency presented indexically through cast shadows of well-known readymades such as the bicycle wheel.

<a id="ch07-p009-zh"></a>
表面上看，1917年的《没有母亲的女孩》与1920年的《年轻女孩（机械形态）》似乎把资本主义内部作为一个主体的状况——在自我构成的分子层面上以被遮蔽的方式从属*于*资本——字面化了。前者在未分化的金色底子上描绘机器部件。它以一种暗示精神分析在“移置”名目下所理论化的机制的方式，调换了图形与背景的关系：图像的基底意指金钱。从文艺复兴早期到西方艺术近代早期，金色一直是映照赞助人财富的方式。于是，金钱是以它为背景的“图形”——机器或“女孩”——的母体；这女孩“没有母亲”，起源非生物学，母体被工厂车间的转喻性符码取代。自动机与非人占了上风。《年轻女孩》作为《女孩》的佐证，是一幅肖像，就所描绘的对象充满画面而言——这种类型惯例由拉斐尔1510年的《巴尔达萨雷·卡斯蒂利奥内肖像》确立。机器部件的通用工业再现充满画面，垂直升向墙面与画面，召唤绘画作品的反思性。但所展示的东西不过如此，一件随意之物。在它下方，“For-Ever”一词漂浮着，仿佛要保证这件奇怪肖像之物的在场；但当然，从立体主义学会了语言课程之后，这词只锚定画面场域的平面性与物的非现实性。然而那物确实昭示了现代个体，以及其奇异地被抽空的、对自身在场性的承诺票据——它永远无法兑现。<a id="ref-zh-ch07-11"></a>[11](#note-zh-ch07-11) 作为连接视觉信息以及物、词语、质地与概念的图表，毕卡比亚另一件由马塞尔·杜尚购得并遗赠耶鲁大学美术馆的杰作《普遍的卖淫》，重复了那些机器部件形式。一个部件立在画面左侧，以完美的塑形与明暗对照法描绘；其他部件散落在视觉表面上。词语从机器中发出，像工厂传送带上的货物一样交叉，水平滑动，与呼应画框垂直上升的机器部件图像志形成张力。一条看似弦或线的物事从主要机器部件伸向其他部件。这些部件虽以三维方式表现，仿佛能占据三维空间，却在真空之中，衬着平坦而未分化的虚空。其平面性再次被横穿表面的词语所确认。

<a id="ch07-p009-en"></a>
*Girl Born without a Mother* of 1917 and *Jeune Fille* (*Mécanomorph*) of 1920 would seem on the face of things to literalize the condition of being a subject within capitalism as occluded subjugation *to* capital at the molecular level of the constitution of the self. The first represents machine parts against an undifferentiated gold ground. Switching out figure and ground relations in a way suggestive of mechanisms theorized by psychoanalysis under the rubric of displacement, the ground of the image denotes money. Gold, from the early Renaissance to the early modern period of Western art, had been a way to reflect the wealth of the patron. Money, then, is the matrix of the ‘figure’ against it, the machine or ‘girl’ born ‘without a mother’, of non-biological origins where the maternal body is replaced by the metonymic cipher of the factory floor. Automata and the inhuman have prevailed. *Jeune Fille*, in support of *Girl*, is a portrait in so far as the object figured fills the frame in a genre convention set by Raphael in his *Portrait of Baldissare Castigleone* of 1510. A generic industrial representation of machine parts fills the frame, rising vertically to the wall and picture plane to summon the reflexivity of the pictorial work. But the thing shown is just that, a random thing. Under it, the words ‘For-Ever’ float as though to guarantee the presence of this strange portrait-thing, but of course, having learned the lessons of language from cubism, the words anchor only the flatness of the picture place and the unreality of the thing. And yet that thing figures forth the modern individual and its strangely evacuated promissory note of being present to itself, which it can never rise to meet.<a id="ref-en-ch07-11"></a>[11](#note-en-ch07-11) A diagram connecting visual information as well as things, words, textures and concepts, Picabia’s other great work, purchased by Marcel Duchamp and bequeathed to Yale University Art Gallery, *Universal* *Prostitution*, repeats those machine part forms. One stands left of field, depicted in perfect modelling and chiaroscuro; others are strewn over the visual surface. Words issue from the machine and cross like goods on the factory belt, sliding horizontally in tension against the iconography of a machine part that echoes the vertical rise of the frame. What appears to be a chord or wire stretches from the main machine part to the other. While the parts are represented in three dimensions, as though capable of occupying three-dimensional space, they do so in a vacuum, against a flat and undifferentiated void. Its flatness is once again ratified by the words that cross the surface.

<a id="ch07-p010-zh"></a>
换言之，毕卡比亚那幅奇怪的图表，或许更应被理解为对现代性中重新分配身份与财产含义之社会关系的演示，即物化，而非对机器部件——物——的拜物化；俄意未来主义在等价与价值形式体制下对感官全面钙化的表演中，正是把机器部件拜物化了。

<a id="ch07-p010-en"></a>
Picabia’s strange diagram, in other words, might be understood more as a demonstration of the social relations redistributing the meaning of identity and property in modernity, namely reification, than the machine parts – objects – fetishized by Russian and Italian Futurisms in the latter’s performance of the total calcification of the senses under the regime of equivalence and the value form.

<a id="ch07-p011-zh"></a>
朗西埃在重读《资本论》时，建立在阿尔都塞及其他人的工作之上，他们追问资本主义相对于人类利益的自主性与冷漠。朗西埃提出一种资本主义内部的主体理论：主体既是资本结构性自我复制的载体，又是对资本主义所必需之社会结构的中断：“决定诸效果之间关系的，是原因（社会生产关系），就其*缺席*而言。”在此，朗西埃对马克思所谓“生产的隐秘居所”作了必要的致意。然而，他在这里把它作为缺席的原因引入。这一缺席的原因不是作为主体的劳动。毋宁说，它是抽象劳动相对于具体劳动的非同一性。“这一缺席的原因不是作为主体的劳动，而是抽象劳动与具体劳动的同一性，因为其普遍化表达了某种生产方式——资本主义生产方式——的结构。<a id="ref-zh-ch07-12"></a>[12](#note-zh-ch07-12)”

<a id="ch07-p011-en"></a>
Building on the work of Althusser and others who interrogate capitalism’s autonomy from and indifference to human interest in their rereading of *Capital*, Rancière offers a theory of the subject within capitalism as both a vehicle to capital’s structural self-replication and an interruption to a social structure necessary to capitalism: ‘what determines the relation between the effects is the cause (social relations of production) insofar as it is *absent*.’ Here, Rancière gives the requisite nod to the ‘hidden abode of production’ as Marx called it. Here, however, he introduces it as absent cause. This absent cause is not labour as a subject as such. Rather, it is the non-identity of abstract labour in relationship to concrete labour. ‘This absent cause is not labour as a subject, it is the identity of abstract labour and concrete labour inasmuch as its generalization expresses the structure of a certain mode of production, the capitalist mode of production.<a id="ref-en-ch07-12"></a>[12](#note-en-ch07-12)

<a id="ch07-p012-zh"></a>
换言之，不存在分析的对象。存在的只是一组关系：工人、他或她的劳动能力，以及体现于他或她参与制造的产品中的劳动之间的关系。在资本主义生产方式中，没有哪个特定场所或身份是资本的生成之处；剩余资本是关系的功能。不存在经验上可证实的肯定性身份。

<a id="ch07-p012-en"></a>
In other words, there is no object of analysis. Rather, there is only a set of relations among the worker, his or her capacity for work and the work expressed in products he or she is part of making. There is no particular site or identity in the capitalist mode of production from which capital is generated; surplus capital is a function of relations. There is no empirically verifiable positive identity.

<a id="ch07-p013-zh"></a>
*资本本身是一种图表功能。资本主义是诸运动与过渡之间的关系。*

<a id="ch07-p013-en"></a>
*Capital itself is a diagrammatic function. Capitalism is a relationship among movements and transitions.*

<a id="ch07-p014-zh"></a>
这一裂隙——作为人的劳动者、他或她的劳动力、以及商品中耗费的劳动时间之间——作为劳动普遍化的场所运作。它是一种围绕缺席结构起来的故障，生成着相对于它而组织起来的社会关系。如此，它把资本主义生产方式表达为一种缺席与差异的结构，一种围绕具体劳动与抽象劳动之间裂隙组织起来的社会关系。这一缺席的原因不是工作，而是劳动力——被对象化、被度量、匿名的劳动力，利润的关键——进入社会场域的方式：它伪装成个体，以一种拟人化的层面被社会地呈现，把具体劳动的承担者与其承载劳动的能力（价值的来源）混为一谈。社会场域错失的事实是：劳动的抽象尺度及其市场上的销售点——在那里它同时被抽象化和实现——并不等同于劳动者，后者身处由与他人的关系所规定的日常生活中。被抽象并交换／实现的劳动悬置了劳动力承担者个人的和集体的经验，以一种“第二自然”取代它，而这一“第二自然”由交换过程本身自然化；在此过程中，经验性的东西被抽空，以榨取价值。<a id="ref-zh-ch07-13"></a>[13](#note-zh-ch07-13) 朗西埃如此解释劳动能力感知中的这一故障：它被困在一个间隙里，在此，人或劳动力的承担者被等同于劳动力带来利润的能力，而人的其他品质与轨迹则被遮蔽：“内在结构规定的倒转表现为过程的一个基本特征。正是这一规律决定了其形式的发展。”<a id="ref-zh-ch07-14"></a>[14](#note-zh-ch07-14) 简言之，朗西埃在此提供了一种物化理论，对格奥尔格·卢卡奇的理论作了细化。

<a id="ch07-p014-en"></a>
This gap, between the labourer as a person, his or her labour-power, and the labour time expended in the commodity, operates as the site of generalization of labour. It is a kind of glitch structured around absence which generates social relations organized in relation to it. As such it expresses the capitalist mode of production as a structure of absence and difference, of social relations organized around a gap between concrete and abstract labour. This absent cause is not work, but the way in which labour-power, objectified and metricized and anonymous, the key to profit, enters the social field disguised as the individual, presented socially in an anthropomorphic register that conflates the bearer of concrete labour with her or his labour-bearing capacity (the source of value). The social field misses the fact that the abstract measure of labour and its point of sale on the market – where it becomes at once abstracted and realized – is not the same thing as the labourer, situated as s/he is in a daily life determined by relations with others. The labour abstracted and exchanged/realized suspends the personal and collective experience of the bearer of labour-power, replacing it with a ‘second nature’ naturalized thus by the process of exchange itself, in which the experiential is evacuated in the interest of deriving value.<a id="ref-en-ch07-13"></a>[13](#note-en-ch07-13) Rancière explains this glitch in the perception of labour- power, caught in an interval where the person or bearer of labour-power becomes equated with the profit-bearing capacity of labour-power to the occlusion of the other qualities and trajectory of the human: ‘The inversion of the inner structural determinations appears as a fundamental characteristic of the process. It is this law that determines the development of its forms.’<a id="ref-en-ch07-14"></a>[14](#note-en-ch07-14) In short, Rancière here provides a theory of reification that nuances that of Georg Lukács.

<a id="ch07-p015-zh"></a>
毕卡比亚在《L.H.O.O.Q.》（1919）中拾起图表作为形式装置。这是对杜尚同年同名卑下唯物主义作品的对话式回应：杜尚作品中，《蒙娜丽莎》的复制品被加上胡须和山羊胡，标题字母横穿下部区域，快速读出会在法语中听起来像“她有个火辣的屁股”——以粗俗幽默和一丝被贬低又贬低他人的欲望，多半是为震惊中产阶级，打断了它在西方艺术万神殿中的神圣性。毕卡比亚的版本则以几何级数更加令人不安，也更为激进。它把人物想象为图表或某种地图：*bas*（下）、*haut*（上）、*fragile*（易碎）与*à domicile*（到家）这些词确立四个参照点或坐标，而构成这人物肖似与拒斥的粗曲线形式则在它们之间弯曲、盘绕、扭曲，越过表面。它类似于雅克·拉康为把主体描绘为诸时刻或站点之间不透明运动的函数而画的那种图表；他称这些站点为实在界、想象界与象征界。

<a id="ch07-p015-en"></a>
Picabia picks up the diagram as a formal device in *L.H.O.O.Q.* (1919), a dialogic response to Duchamp’s base materialist work of the same title in the same year, in which a reproduction of the *Mona Lisa* is decorated with a beard and goatee, the letters of the title crossing the lower register, to be spoken swiftly to generate what would sound, in French, like ‘she has a hot ass’ – interrupting its sanctity in the pantheon of Western art with crass humour and a whiff of denigrated and denigrating desire, mostly to shock the middles class. Picabia’s version is exponentially more disturbing, and radical. It imagines the figure as a diagram or a kind of map: the words *bas*, *haut*, *fragile* and *à* *domicile* establish four points of reference or coordinates, while the thick curvilinear form comprising this semblance of and refusal of a figure bends, winds and twists from among them over the surface. It resembles a diagram of movement of the kind Jacques Lacan would draw to figure the subject as a function of an opaque movement among moments or stations, which he called the real, imaginary and symbolic.

<a id="ch07-p016-zh"></a>
动员从轮廓转向图表的艺术实践名单横跨整个世纪，从1915年到2016年。我们可以带有倾向性地把这些实践定位为众多文化实例，标示图表作为启发式装置被纯粹审美地挪用、并加以精炼和发展的过程。

<a id="ch07-p016-en"></a>
The list of artistic practices that mobilize the turn from contour to diagram crosses the century, from 1915 to 2016. We could tendentiously situate these practices as so many cultural instances marking the elaboration and development of the purely aesthetic appropriation of the diagram as a heuristic device.

<a id="ch07-p017-zh"></a>
但这一文化发展的展开，反过来可以被表明追踪着一种平行的双重运动：文化嵌套于资本主义生产方式解体及全球资源与人口再整合所带来的运动之中，并与之相对。虽然不可能把一方（图表的内部*目的*）映射到另一方（资本主义吸纳的历史性）上，一种模式仍然浮现。在没有任何因果关联的情况下，线的转变仍然标记着资本主义贫困化的进程，以及进步诸时刻之间的过渡点。仿佛线的解域以某种方式指示性地记录了认知测绘与“全球化”——资本主义的另一个名字——同步的分解与重组。在下文中，我挑出这样一项实践，尝试把它读作实在抽象的索引。

<a id="ch07-p017-en"></a>
But this unfolding of a cultural development, in turn, could be shown to track a parallel, double movement of culture nested in and against the movement brought about by the disintegration of the capitalist mode of production and the reintegration of global resources and demographics. While it would be impossible to map the one (the internal *telos* of the diagram) onto the other (the historicity of capitalist subsumption), a pattern nonetheless emerges. In the absence of any causal correlation, the transformation of line nevertheless marks the progress of capitalist immiseration and the transitional points between moments of progress. It is as though the deterritorialization of line somehow recorded, indexically, the de- and recomposition of cognitive mapping ‘in line’ with ‘globalization’, itself another name for capitalism. In what follows, I isolate one such practice and attempt to read it as an index of real abstraction.

<a id="ch07-s02-zh"></a>
## **曼佐尼：先锋派的重复与展开**

<a id="ch07-s02-en"></a>
## **Manzoni: reiteration and elaboration of the avant-garde**

<a id="ch07-p018-zh"></a>
二十世纪中叶，曼佐尼的《线》（1959）激进化了现代主义——从杜尚到阿多诺再到凯奇——对艺术过程之禁欲式还原的关注，尤其是把素描从前被设想和实践为展示技艺的手段，转化为其他能动性形式。

<a id="ch07-p018-en"></a>
In the mid-twentieth century, Manzoni’s *Linea* (1959) radicalized the modernist preoccupation – from Duchamp to Adorno to Cage – with the ascetic reduction of artistic process, particularly the transformation of drawing, formerly conceived and practised as a means to demonstrate skill, into other modalities of agency.

<a id="ch07-p019-zh"></a>
每一次“线”的呈现都由一个硬纸板圆筒、一卷画有黑线的纸，以及一张简单印刷并签名的标签组成，标签上简要说明作品：艺术家姓名、创作日期及其长度。这件探讨线本身之可能性的作品，通过对工厂车间中生产价值的劳动的模仿性铭刻，思考作出痕迹的条件如何在规训性日常生活所强加的预定系统中逐渐消失。换言之，艺术作品展示了规训性劳动如何不可避免地限制那些被认为超越经济决定之低俗事务的、历史上确立的文化形式。《线》辩证地、否定地从艺术家的视角把问题置于前景；艺术家在阶级认同上远非工人，却被期待在资本主义价值逻辑所管理的独裁规定之内并与之对抗地交付意识。制造与作者身份同样被网状化，专属于同一种普遍等价形式，而不顾工人类型之间众多质的差异。《线》从制造的角度设定“自我反思性”——现代主义的支柱——以及在一个为抽象价值而加速的时代中艺术能动性那日益消失的可能性。

<a id="ch07-p019-en"></a>
Each presentation of ‘line’ consists of a cardboard tube, a scroll of paper with a black line drawn down it, and a simple printed and autographed label, which contains a brief description of the work: the artist’s name, the date it was created and its length. This work about the very possibility of line thinks through the vanishing conditions of mark-making within predetermined systems enforced by disciplinary everyday life in mimetic inscription to value-productive labour on the factory floor. In other words, the work of art demonstrates the way in which disciplinary labour comes inevitably to limit historically established forms of culture believed to transcend lowly matters of economic determination. *Linea* dialectically, and negatively, foregrounds the problem from the point of view of the artist, who, while far from the worker in terms of class identification, was expected to deliver consciousness within and against the dictatorial determinations managed by the capitalist logic of value. Manufacture and authorship alike came to be reticulated exclusively to the same form of general equivalence, irrespective of the numerous qualitative differences among types of workers. The *Linee* posit ‘self-reflexivity’ – that linchpin of modernism – in terms of manufacture, and the vanishing possibility of artistic agency in an era accelerated in the interest of abstracted value.

<a id="ch07-p020-zh"></a>
一如既往，阿多诺擅长把吸纳问题转译回文化术语；霸权的自由主义文化中介着同样的过程，并使它们合法化。“资产阶级社会由等价原则统治。它把不同事物还原为抽象数量，从而使它们可比。对启蒙而言，凡不能被还原为数字、并最终还原为一的东西，都是幻象；现代实证主义把它交托给诗。”<a id="ref-zh-ch07-15"></a>[15](#note-zh-ch07-15) 然而，由剩余价值榨取所产生的社会关系——它本身是由价值榨取过程所结构之链条的效果——本身已经是一种多样性，一种无法被分解为任何经验上稳定要素的复合体。早在1929年，在为《法兰克福报》写作时，西格弗里德·克拉考尔就观察到，现代工厂的运作除了通过图表之外无法被确定：“在参观视察之前，一家现代工厂的商务总监向我解释业务。……他指着图表，上面彩色的线条说明整个运作。”然而这一整个运作却沿着一个枢纽性的缺席运行：“多亏投入设备的智力劳动，它的女仆们得以免于拥有知识；如果商业学院的课程不是义务的，她们根本什么都不需要知道。公司的奥秘对她们是一本合上的书。”<a id="ref-zh-ch07-16"></a>[16](#note-zh-ch07-16) 这不只是说工人不知道自己所卷入的、从开端到利润的整个过程总体；而是仿佛她们必须不知道。

<a id="ch07-p020-en"></a>
As ever, Adorno is adept at translating the issue of subsumption back into cultural terms; hegemonic liberal culture mediates the same processes, legitimating them. ‘Bourgeois society is ruled by equivalence. It makes dissimilar things comparable by reducing them to abstract quantities. For the Enlightenment, anything which cannot be resolved into numbers, and ultimately into one, is illusion; modern positivism consigns it to poetry.’<a id="ref-en-ch07-15"></a>[15](#note-en-ch07-15) And yet the social relations generated of the extraction of surplus value, itself the effect of a chain structured by the process of value extraction, is itself already a multiplicity, a complex that cannot be resolved into any empirically stable terms. Already in 1929, writing for the *Frankfurter Zeitung*, Siegfried Kracauer observed the way in which the operations of the modern factory cannot be pinned down other than through a diagram: ‘The commercial director of a modern factory explains business to me before my tour of the inspection. … He points to diagrams whose colourful lines illustrate the whole operation.’ And yet this whole operation moves along a pivotal absence: ‘Thanks to the intellectual labour invested in the equipment, its handmaidens are spared the possession of knowledge; if attendance at commercial college were not compulsory, they would need to know nothing at all. The mysteries of the firm are a closed book to them.’<a id="ref-en-ch07-16"></a>[16](#note-en-ch07-16) It is not simply that workers do not know the totality of the process in which they are implicated, from inception to profit; it is as though they must not know.

<a id="ch07-p021-zh"></a>
曼佐尼模仿这些由资本主义生产方式所结构的关系状况——在其中，价值在关系网络之外没有确定的内容或起源——在米兰一家工厂的装配线上“制作”了《线》。他坐在传送带上，手持蘸了墨的画笔，一个机械轮送入一卷纸，纸触到他的笔，产生一条线。他被动留下的痕迹被抽空了任何技艺或情感性的在场，把去技能化的体力劳动折叠进特权的在场空间：艺术家的痕迹。线对任何表现性、感官性、力比多内容的取消（从超现实主义到表现主义，线的作用晚近已从模仿再现中的工具性角色解放出来），与夸张的包装形成张力，暗示作品对匿名主体——工人／制作者——的嵌入性依赖；这个主体的实体痕迹生成了产品本身的参数，而产品又折返回来取消这一在场。确实，*有某物缺失*。我们可以称之为关于商品拜物教前提的实物教学课——它把人变成物，把能动性归于物——但其中比这还要多一点，也少一点。最终作品浮现于以下诸者之间的间隙：机器、艺术家—工人、把这一*隐藏*劳动提供出售的包装，以及通过签名功能确认其为艺术作品的市场。

<a id="ch07-p021-en"></a>
Mimicking these relational conditions structured by the capitalist mode of production in which value has no certain content or origin outside of a network of relations, Manzoni ‘made’ the *Linea* on an assembly line in a factory in Milan. He sat on a conveyor belt holding an ink-stained brush while a mechanical wheel fed a scroll of paper touching his brush to produce a line. His passive mark, vacated of any kind of skilled or emotive presence, folds deskilled manual labour into the privileged space of presence: the artist’s mark. The line’s foreclosure of any expressive, sensual, libidinal content (the role of line from surrealism through expressionism, having been lately liberated from its instrumental role in mimetic representation), set into tension with exaggerated packaging, implies the work’s embedded dependence on an anonymous subject, the worker/ maker whose substantive trace generates the parameters of the very product that doubles back to cancel that presence. Indeed, *something is missing*. We could call this an object lesson in the preconditions of the commodity fetish that makes things of people and ascribes agency to things, but there’s a little more and a little less to it than this. The resulting work emerges in the gap among the machine, the artist-worker, the packaging that offers for sale this *hidden* labour and the market that affirms it as an artwork through the function of a signature.

<a id="ch07-p022-zh"></a>
行动者（艺术家，代表工人）的痕迹被记录，并使筒罐与罐子、标签以及市场的众多框架得以积累。人面对的是层层叠叠的框架，如镜像般层层嵌套（*en abyme*）：标签、罐子、基座、博物馆，如此多的容器，如此多的形式，但内容似乎凭其自身的一种否定意志而退去。这种现代主义的封闭式退隐，最终仍让位于一种挫败的承认：内容与能动性都是被主动抹除的，而非存在论上的退隐。曼佐尼把层面从海德格尔调回马克思：不是*这个*，而是*异于*这个，纠缠*于*这个之中，构成它并由它组成，是特定劳动条件的功能，具体说是一种与技艺的关系，它使书写字符成为价值的空占位符。《线》双重地扣留了身体痕迹：通过折叠进工业程序，以及通过其包装。它由此悖论性地支撑起身体痕迹，把其缺席指定*为*缺席，把它标记为*他者*。

<a id="ch07-p022-en"></a>
The agent’s (artist, standing for worker) trace is recorded and enables the accumulation of canisters and cans, of labels and the many frames of the market. One is confronted with cascading frames, *en abyme*: label, can, pedestal, museum, so many containers, so many forms, but the content seems to withdraw as though by a negative will of its own. This use of modernist hermetic withdrawal nevertheless yields to a frustrated acknowledgement of the active erasure, rather than ontological withdrawal, of both content and agency. Manzoni shifts register from Heidegger back to Marx: not *this*, but *other* than this, entangled *in* this, constituting it and composed of it is a function of particular labour conditions, specifically a relationship to skill that makes of the grapheme an empty placeholder for value. The *Linee* doubly withhold the corporeal trace: by folding into the industrial procedure and through its packaging. It thus paradoxically shores up the corporeal trace, designating its absence *as* absence, marking it as *other.*

<a id="ch07-s03-zh"></a>
## **抽象**

<a id="ch07-s03-en"></a>
## **Abstraction**

<a id="ch07-p023-zh"></a>
朗西埃指出，在围绕缺席、或劳动者与劳动力之间、一般抽象劳动与最终在剩余价值中表现的具体劳动之间的故障所结构的偶然社会关系中，现实变得“思辨性”。<a id="ref-zh-ch07-17"></a>[17](#note-zh-ch07-17) 它成为社会行动者与物之间偶然关系运动的功能，这些关系可沿图表被测绘。现在回到抽象与图表这一更大的问题：如果“实在抽象”不是物化的另一个术语，还会是什么？它由工资、匿名劳动与商品这三驾马车在日常生活中带来的存在论转变所标示。<a id="ref-zh-ch07-18"></a>[18](#note-zh-ch07-18) 这些存在论转变如何在时间中运动？“金融化”、“后福特主义”、乃至“后现代主义”这些术语暗示一种序列，无论每个术语多么准确或错误。它们描述工人、群众与大众在世界各地感受并承受的政治经济现实中的一系列发展——用任何别的名字称呼它，它生成一种常被称作“新自由主义”的状况。什么是新自由主义？在《新自由主义简史》中，大卫·哈维论证说，这个术语描述的是一系列事件的结果，即在巩固国际货币基金组织（IMF）、世界银行、世界贸易组织（WTO）与华尔街之间关系的过程中的结果。

<a id="ch07-p023-en"></a>
Rancière notes that within the contingent social relations structured around absence, or a glitch between the labourer and labour-power, and between abstract labour in general and concrete labour expressed finally expressed in surplus value, reality becomes ‘speculative’.<a id="ref-en-ch07-17"></a>[17](#note-en-ch07-17) It becomes a function of the movement of the contingent relations among social agents and objects that might be charted along a diagram. Returning now to the larger problem of abstraction and the diagram, what is ‘real abstraction’ if not just another term for reification, signalled by the ontological shifts in everyday life brought about by the triumvirate of wage, anonymous labour and the commodity?<a id="ref-en-ch07-18"></a>[18](#note-en-ch07-18) How do these ontological shifts move in time? The terms ‘financialization’, ‘post-Fordism’, even ‘post-modernism’ suggest a sequence, however accurate or erroneous each may be. They describe a succession of developments in the political-economic reality felt and suffered by workers, masses and multitudes all over the world, one by any other name, one that generates a condition frequently evoked as ‘neoliberalism’. What is neoliberalism? In *A* *Brief History of Neoliberalism*, David Harvey argues that the term describes the result of a succession of events in the consolidation of the relationship between the IMF (International Monetary Fund), the World Bank, the WTO (World Trade Organization) and Wall Street.

<a id="ch07-q003-zh"></a>
> 新自由主义化的过程带来了大量创造性毁灭，不仅针对先前的制度框架与权力（甚至挑战传统的国家主权形式），也针对劳动分工、社会关系、福利供给、技术组合、生活方式与思想方式、再生产活动、对土地的依恋以及心灵的习惯。<a id="ref-zh-ch07-19"></a>[19](#note-zh-ch07-19)

<a id="ch07-q003-en"></a>
> The process of neoliberalization has entailed much creative  destruction not only of prior institutional frameworks and powers  (even challenging traditional forms of state sovereignty) but also  divisions of labour, social relations, welfare provisions, technological  mixes, ways of life and thought, reproductive activities, attachments  to the land and habits of heart.<a id="ref-en-ch07-19"></a>[19](#note-en-ch07-19)

<a id="ch07-p024-zh"></a>
针对一种叙事——即一系列国家与制度联盟把全球警治为所谓“新自由主义”——许多人指出，资本主义的深远触及在结构上不可避免，是资本主义积累周期需要更大领土以供劳动与资源开采的逻辑结果。晚近的危机资本主义理论（它们回到罗莎·卢森堡、格奥尔格·卢卡奇等人的较早理论）挑战哈维的论述，指出资本主义的基本结构状况，即需要保持领先于其内在的利润率下降倾向。<a id="ref-zh-ch07-20"></a>[20](#note-zh-ch07-20) 而这一倾向正是产生利润所必需的贫困化的核心，*除非*资本能把资源与劳动来源吸收进自己的机器，以助长其自身的结构性熵，从而回到与哈维因果性路径不同的资本主义论述。例如，保罗·马蒂克在《照常营业》中的论题坚持结构优先于全球治理与管制机构之间次级政治谈判的展开，构成对哈维的纠正。但问题不在于哪位马克思主义名家比另一位更好，而在于各自试图描述和分期那些*无法描绘*的新兴状况时敞开的空白。

<a id="ch07-p024-en"></a>
Against the narrative according to which a succession of state and institutional alliances policed the globe into so-called ‘neoliberalism’, many note that the far reach of capitalism is structurally inevitable, the logical outcome of capitalism’s cycles of accumulation necessitating greater territories to be mined for labour and resources. Recent theories (which return to older theories such as those of Rosa Luxemburg, Georg Lukács and others) of crisis capitalism challenge Harvey’s account by pointing to the basic structural condition of capitalism, namely the need to keep ahead of its inherent tendency of falling profits.<a id="ref-en-ch07-20"></a>[20](#note-en-ch07-20) And this very tendency is at the heart of the immiseration necessary for generating profits, *unless* capital can absorb resources and sources of labour into its machinery to abet its own structural entropy, thereby returning to accounts of capitalism at odds with Harvey’s approach to causality. Paul Mattick’s thesis in *Business as Usual*, for instance, acts as a corrective to Harvey in its insistence on structure over the unfolding of secondary political negotiations among global bodies of governance and regulation. But the question is not what Marxian luminary is better than the other, but rather the lacunae that open up in how each tries to describe and periodize emergent conditions *impossible to figure.*

<a id="ch07-p025-zh"></a>
问题在历史宏大叙事的最大尺度上被提出。记着詹姆森的“永远总体化！”，我既依赖大卫·哈维的工作，也依赖乔瓦尼·阿里吉、罗伯特·布伦纳等人；他们提出了在全球化力量、尤其是金融化力量造成复杂化之后思考历史因果性的方式，而金融化已开始决定通信网络，并重塑我们所指的时间、地点与原因。<a id="ref-zh-ch07-21"></a>[21](#note-zh-ch07-21) 对哈维、阿里吉、布伦纳等人而言（尽管有众多差异），1973年的石油危机是第一世界国家保持高利润战略的信号性时刻；这些战略如今被我们用未经检视的简写称作“全球化”：欠发达世界的廉价劳动力、从福特主义转向后福特主义生产技术、强调供应链甚于工厂车间中的生产，以更高效地榨取利润（更少承担劳动成本），更不用说在新经济中、在危机导致增长停滞后，国际货币基金组织在撒切尔—里根年代所实施的新一轮原始积累。我们需要通过文化生产提供的病因学，描述并追踪这个由资本主义价值增殖形式所带来的复杂规定的马蜂窝——它们以人口在全球的大规模流动为前提。哈维所谓的“解域”与“再域化”——由日常生活在发达资本的支配下的创造性毁灭与再巩固所强制执行——改变了语境与因果性的根本概念。

<a id="ch07-p025-en"></a>
The problem is posed on the largest scale of a historical grand narrative. With Jameson’s ‘Always totalize!’ in mind, I am relying as much on the work of David Harvey as on Giovanni Arrighi, Robert Brenner and others, who have proposed ways of thinking historical causality after the complications wrought by the forces of globalization and, above all, financialization, which have come to determine communications networks and to reshape what we mean by time, place and cause.<a id="ref-en-ch07-21"></a>[21](#note-en-ch07-21) For Harvey, Arrighi, Brenner and others (despite numerous differences), the oil crisis of 1973 was a signal moment for strategies on the part of First World nations to keep profits high, strategies that we now refer to in the unexamined shorthand of ‘globalization’: cheap labour in the underdeveloped world, moving from Fordist to post-Fordist production techniques, emphasizing supply chains over production on the factory floor in the interest of exacting profits more efficiently (to bear the expense of labour less), not to mention new rounds of primitive accumulation exacted by the IMF during the new economy of the Thatcher–Reagan years in the wake of stagnating growth caused by the crisis. We need to describe and trace – through the aetiology provided by cultural production – this hornet’s nest of complex determinations wrought by capitalist forms of valorization predicated on the mass movement of people across the planet. What Harvey would call ‘deterritorialization’ and ‘reterritorialization’ – enforced by the creative destruction and reconsolidation of everyday life under the dictates of advanced capital – change the very notions of context and causality.

<a id="ch07-p026-zh"></a>
于是，进入“后媒介状况”。<a id="ref-zh-ch07-22"></a>[22](#note-zh-ch07-22)

<a id="ch07-p026-en"></a>
Enter ‘the post-medium condition’.<a id="ref-en-ch07-22"></a>[22](#note-en-ch07-22)

<a id="ch07-p027-zh"></a>
流离失所问题的反复出现，可能引出安置本身究竟意味着什么的问题。或许可以说，在一个本身诞生于冷战、推崇专业化的制度与职业秩序中，艺术实践成为最后一片规定不足（或相反，过度编码）的空间，使人们得以探索那些渗透日常生活如此多方面、否则不可能被容纳于一个有限研究领域的问题集。从阿多诺到萨义德，离散的结构状况常被理解为——无论多么暴力——现代性所生成的集体转化既定过程之一。然而在现代性的历史性中，或许可以注意到，暴力流离失所的形式在强度和频率上都在加速。离散是一种跨越民族国家与大陆的大规模社会重组，是资本主义创造性毁灭的加速所迫成的；资本主义周期性地重构自身，一方面为了开采资源，另一方面为了更高效地从劳动中榨取剩余价值。

<a id="ch07-p027-en"></a>
The recurrence of the question of displacement may beg the question of the very meaning of placement. It might be said that in an institutional and professional order, itself born of the cold war, in which specialization is prized, art practices become the last underdetermined (or, in contrast, over-coded) space to enable the exploration of problem sets saturating so many aspects of everyday life as to be otherwise impossible to contain in a circumscribed field of study. From Adorno to Said, the structural condition of diaspora is frequently understood to be, however violent, one of the given processes of collective transformation born of modernity. And yet within the historicity of modernity, it might be noted that forms of violent displacement are accelerating in intensity and frequency. Diaspora is a form of mass social reorganization across nation-states and continents necessitated by the acceleration of capitalism’s creative destruction, as it periodically restructures in the interest of resource mining, on the one hand, and, on the other hand, ever more efficient ways of extracting surplus value from labour.

<a id="ch07-p028-zh"></a>
资本主义不断转移地点、寻找剩余劳动力储备的需求，促使劳动与资本之间的关系不断变化，这已为世界大部分人口重绘了时间与空间的坐标。1945年与1973年都是关键日期，标志着语境、起源与因果性基本含义的根本变化。不断变化的经验与历史条件开始要求包括人文学科在内的学术探究去探索那些支撑古典分析形式的基本坐标；其中，作为稳定地点与时间的“语境”是根本性的。

<a id="ch07-p028-en"></a>
The shifting relationship between labour and capital, required by capitalism’s peripatetic need for pools of surplus labour, has redrawn the coordinates of time and space for much of the world’s population. 1945 and 1973 are both crucial dates that mark fundamental changes in the basic meanings of context, origin and causality. Changing empirical and historical conditions begin to demand scholarly inquiry, including the humanities, to explore the basic coordinates that subtend classical forms of analysis, of which context, understood as a stable place and time, is fundamental.

<a id="ch07-p029-zh"></a>
此处的悖论、或辩证的纠缠在于：语境（定义为作品生产的时间与地点）继续是艺术社会史最基本的确定项之一，同时却也成为其首要问题之一。在语境感知——必然受网络化传播支配、与金融化密切相关——的解根化与重构之后，什么构成一个稳定的时间与地点，即一个语境？金融化使全球的“银行”（一组操作）在一个人的生活中，比正在经历这一“生活”的人更具因果能动性。自批判决定论的理论（后结构主义）兴起以来，过去数十年中，能动性与主体性的形成一直是迫切的问题，然而语境仍是一个稳定的范畴。

<a id="ch07-p029-en"></a>
The paradox, or dialectical involution, here is that while context (defined as the time and place in which a work is produced) continues to be one of social history of art’s most basic certainties, it also becomes one of its primary questions. What constitutes a stable time and place – that is, a context – in the wake of the deracination and reconstitution of its perception necessarily governed by networked communication, intimately bound up with financialization, which has made ‘the bank’ (a set of operations) across the globe more causally active in a life than s/he who is experiencing this ‘life’? Agency and the formation of subjectivity have been pressing matters of concern over the last several decades in the wake of theories critical of determination (post-structuralism) and yet context has remained a stable category.

<a id="ch07-p030-zh"></a>
语境本身，即对文化连贯性具有根本意义的时间与空间基本母体，必须被重新定义，因为它已被资本主义重构，从而重构了因果性的线索。<a id="ref-zh-ch07-23"></a>[23](#note-zh-ch07-23) 资本重绘了时间与空间的线索，面对历史的运动，恢复连贯性的迫切需要乘着图表而来，因为图表具有独特能力，能回应晚期现代性中的实在抽象与物化。

<a id="ch07-p030-en"></a>
Context itself, the basic matrix of time and space fundamental to cultural coherence, must be redefined, given the fact that it has been already restructured by capitalism, thereby restructuring lines of causality.<a id="ref-en-ch07-23"></a>[23](#note-en-ch07-23) The urgent need to find coherence again in response to the movement of history wherein capital has redrawn the lines of time and space rides in on the diagram because of its singular capacity to respond to both real abstraction and reification in late modernity.

<a id="ch07-p031-zh"></a>
转向图表之运作能力、背离再现逻辑与表现冲动的作品数量——由杜尚与毕卡比亚，也包括俄／苏与意大利未来主义——使1915—1920年成为通过线性重新思考表达之根本参数的生成性时刻。我们可以带有倾向性地把这些实践定位为众多文化实例，标示图表作为启发式装置被纯粹审美地挪用、并加以精炼和发展的过程。但这一文化发展的展开，反过来可以被表明追踪着一种平行的双重运动：资本主义生产方式将自身整合进审美实践的形式，而这些新形式反过来又提供描述资本对世界之激进重组的诸种方式。虽然不可能把一方（图表的谱系）映射到另一方（资本对全球市场再整合的历史性）上，两种探究（美学与社会场域）共有的模式仍然浮现。在没有任何因果关联的情况下，线的转变仍然标记着资本主义贫困化的进程，以及进步诸时刻之间的过渡点。

<a id="ch07-p031-en"></a>
The number of works that turn away from representational logic and expressive drives toward the operational capacity of the diagram – by Duchamp and Picabia but also within Russian/ Soviet and Italian Futurism – mark 1915–20 as a generative time in rethinking the very parameters of articulation through linearity. We could tendentiously situate these practices as so many cultural instances marking the elaboration and development of the purely aesthetic appropriation of the diagram as a heuristic device. But this unfolding of a cultural development, in turn, could be shown to track a parallel, double movement where the capitalist mode of production integrates itself into forms of aesthetic praxis but, reciprocally, these new forms in turn afford ways of describing the radical reordering of the world by capital. While it would be impossible to map the one (the genealogy of the diagram) onto the other (the historicity of capitalist reintegration of global markets), a pattern common to both inquiries (aesthetics and the social field) nonetheless emerges. In the absence of any causal correlation, the transformation of line nevertheless marks the progress of capitalist immiseration and the transitional points between moments of progress.

### 原注

<a id="ch07-n001-zh"></a><a id="note-zh-ch07-1"></a>
[1] David Harvey, *The Limits to Capital*, London and New York: Verso, 2007, p. 428。 [返回](#ref-zh-ch07-1)

<a id="ch07-n001-en"></a><a id="note-en-ch07-1"></a>
[1] David Harvey, *The Limits to Capital*, London and New York: Verso, 2007, p. 428. [返回](#ref-en-ch07-1)

<a id="ch07-n002-zh"></a><a id="note-zh-ch07-2"></a>
[2] Norman Bryson, ‘A Walk for a Walk’s Sake’, in Catherine de Zegher and Avis Newman, eds, *The Stage of Drawing: Gesture and Act, Gesture and Art. Selected from the Tate Collection*, London: Tate Gallery and New York: Drawing Center, 2003, pp. 149–58。 [返回](#ref-zh-ch07-2)

<a id="ch07-n002-en"></a><a id="note-en-ch07-2"></a>
[2] Norman Bryson, ‘A Walk for a Walk’s Sake’, in Catherine de Zegher and Avis Newman, eds, *The Stage of Drawing: Gesture and Act, Gesture and Art. Selected from the* *Tate Collection*, London: Tate Gallery and New York: Drawing Center, 2003, pp. 149–58. [返回](#ref-en-ch07-2)

<a id="ch07-n003-zh"></a><a id="note-zh-ch07-3"></a>
[3] 见 Pamela Lee, ‘Some Kinds of Duration: The Temporality of Drawing as Process Art’, in *After Image: Drawing Through Process*, 由 Cornelia H. Butler 为1999年4—8月洛杉矶当代艺术博物馆的展览编排, Cambridge MA and London: MIT Press, 1999; Jordan Kantor and Igor Zabel, *Vitamin D: New Perspectives in Drawing*, London: Phaidon, 2005; de Zegher and Newman, *The Stage of Drawing*; Briony Fer, *The Infinite Line: Remaking Art After Modernism*, New Haven CT and London: Yale University Press, 2004。 [返回](#ref-zh-ch07-3)

<a id="ch07-n003-en"></a><a id="note-en-ch07-3"></a>
[3] See Pamela Lee, ‘Some Kinds of Duration: The Temporality of Drawing as Process Art’, in *After Image: Drawing Through Process*, organized by Cornelia H. Butler for an exhibit at the Los Angeles Museum of Contemporary Art, April–August 1999, Cambridge MA and London: MIT Press, 1999; Jordan Kantor and Igor Zabel, *Vitamin D: New* *Perspectives in Drawing*, London: Phaidon, 2005; de Zegher and Newman, *The Stage of* *Drawing*; Briony Fer, *The Infinite Line: Remaking Art After Modernism*, New Haven CT and London: Yale University Press, 2004. [返回](#ref-en-ch07-3)

<a id="ch07-n004-zh"></a><a id="note-zh-ch07-4"></a>
[4] 关于“解域”或空间与时间的解体与重组同资本主义整合之特定构型的关系，见 David Harvey, *Justice, Nature & the Geography of Difference*, Oxford: Blackwell, 1996, and *The Condition of Postmodernity*, Oxford: Blackwell, 1989。 [返回](#ref-zh-ch07-4)

<a id="ch07-n004-en"></a><a id="note-en-ch07-4"></a>
[4] For a discussion of the ‘deterritorialization’ or disarticulation and reorganization of space and time in relation to the specific configuration of capitalist integration, see David Harvey, *Justice, Nature & the Geography of Difference*, Oxford: Blackwell, 1996, and *The* *Condition of Postmodernity*, Oxford: Blackwell, 1989. [返回](#ref-en-ch07-4)

<a id="ch07-n005-zh"></a><a id="note-zh-ch07-5"></a>
[5] Michael Baxandall, *Painting and Experience in Fifteenth Century Italy*, Oxford: Oxford University Press, 1988; Walter Benjamin, ‘One Way Street’ and ‘The Work of Art in the Age of its Technological Reproducibility’, in Walter Benjamin, *Selected Writings*: Volume 1: *1913–1926*, ed. Howard Eiland and Michael Jennings, Cambridge MA and London: Belknap Press of Harvard University Press, 1996, pp. 444–88, and *Selected Writings*, Volume 3: *1935–1938*, ed. Howard Eiland and Michael Jennings, Cambridge MA and London: Belknap Press of Harvard University Press, 2002, pp. 101–34。 [返回](#ref-zh-ch07-5)

<a id="ch07-n005-en"></a><a id="note-en-ch07-5"></a>
[5] Michael Baxandall, *Painting and Experience in Fifteenth Century Italy,* Oxford: Oxford University Press, 1988; Walter Benjamin. ‘One Way Street’ and ‘The Work of Art in the Age of its Technological Reproducibility’, in Walter Benjamin, *Selected Writings*: Volume 1: *1913–1926,* ed. Howard Eiland and Michael Jennings, Cambridge MA and London: Belknap Press of Harvard University Press, 1996, pp. 444–88, and *Selected Writings*, Volume 3: *1935–1938*, ed. Howard Eiland and Michael Jennings, Cambridge MA and London: Belknap Press of Harvard University Press, 2002, pp. 101–34,. [返回](#ref-en-ch07-5)

<a id="ch07-n006-zh"></a><a id="note-zh-ch07-6"></a>
[6] Molly Nesbit, *Their Common Sense*, London: Black Dog, 2000. 另见 Molly Nesbit, ‘The Language of Industry’, in *The Definitely Unfinished Marcel Duchamp*, ed. Thierry de Duve, Cambridge MA and London: MIT Press, 1992。关于这种图表式操作如何在二十世纪艺术实践中确立自身、并在所谓“社会转向”的晚期二十世纪艺术中成为范式的例子，见 Jaleh Mansoor, ‘Cristóbal Lehyt’s Concrete Abstraction: Un-Mapping the “Global South”’, in Cristóbal Lehyt, *America’s Society*, New York, Spring 2014。 [返回](#ref-zh-ch07-6)

<a id="ch07-n006-en"></a><a id="note-en-ch07-6"></a>
[6] Molly Nesbit, *Their Common Sense*, London: Black Dog, 2000. See also Molly Nesbit, ‘The Language of Industry’, in *The Definitely Unfinished Marcel Duchamp*, ed. Thierry de Duve, Cambridge MA and London: MIT Press, 1992. For an example of how this diagrammatic operation establishes itself in twentieth-century art practices and comes to be paradigmatic in late-twentieth-century art of the so-called ‘social turn’, see Jaleh Mansoor, ‘Cristóbal Lehyt’s Concrete Abstraction: Un-Mapping the “Global South”’, in Cristóbal Lehyt, *America’s Society*, New York, Spring 2014. [返回](#ref-en-ch07-6)

<a id="ch07-n007-zh"></a><a id="note-zh-ch07-7"></a>
[7] “可供性”（affordance）与“可供”（affords）这两个术语的用法来自 Caroline Levine, *Forms: Whole, Rhythm, Hierarchy, Network*, Princeton NJ: Princeton University Press, 2015。 [返回](#ref-zh-ch07-7)

<a id="ch07-n007-en"></a><a id="note-en-ch07-7"></a>
[7] This usage of the term ‘affordance’ and ‘affords’ comes from Caroline Levine, *Forms:* *Whole, Rhythm, Hierarchy, Network,* Princeton NJ: Princeton University Press, 2015. [返回](#ref-en-ch07-7)

<a id="ch07-n008-zh"></a><a id="note-zh-ch07-8"></a>
[8] Jeremy Gilbert, ‘Experimental Politics: Its Background and Some Implications’, Preface to Maurizio Lazzarato, *Experimental Politics: Work, Welfare, and Creativity in the Neoliberal Age*, ed. Jeremy Gilbert, Cambridge MA: MIT Press, 2017, p. xxxv。 [返回](#ref-zh-ch07-8)

<a id="ch07-n008-en"></a><a id="note-en-ch07-8"></a>
[8] Jeremy Gilbert, ‘Experimental Politics: Its Background and Some Implications’, Preface to Maurizio Lazzarato, *Experimental Politics: Work, Welfare, and Creativity in the* *Neoliberal Age*, ed. Jeremy Gilbert, Cambridge MA: MIT Press, 2017, p. xxxv. [返回](#ref-en-ch07-8)

<a id="ch07-n009-zh"></a><a id="note-zh-ch07-9"></a>
[9] Briony Fer, David Batchelor and Paul Wood, *Realism, Rationalism, Surrealism: Art Between the Wars*, New Haven CT: Yale University Press, 1993, p. 108。关于工业设计与商业素描作为法美先锋派——尤其是杜尚实践——之母体的主导地位，见 Nesbit, ‘The Language of Industry’。 [返回](#ref-zh-ch07-9)

<a id="ch07-n009-en"></a><a id="note-en-ch07-9"></a>
[9] Briony Fer, David Batchelor and Paul Wood, *Realism, Rationalism, Surrealism: Art* *Between the Wars*, New Haven CT: Yale University Press, 1993, p. 108. On the dominance of industrial design and commercial drawing as the matrix of the French and American avant-gardes, most notably Duchamp’s practice, see Nesbit, ‘The Language of Industry’. [返回](#ref-en-ch07-9)

<a id="ch07-n010-zh"></a><a id="note-zh-ch07-10"></a>
[10] Hal Foster, ‘Prosthetic Gods’, *Prosthetic Gods*, Cambridge: MIT Press, 2004, p. 149。 [返回](#ref-zh-ch07-10)

<a id="ch07-n010-en"></a><a id="note-en-ch07-10"></a>
[10] Hal Foster, ‘Prosthetic Gods’, *Prosthetic Gods*, Cambridge: MIT Press, 2004, p. 149. [返回](#ref-en-ch07-10)

<a id="ch07-n011-zh"></a><a id="note-zh-ch07-11"></a>
[11] 见 Giorgio Agamben, *Man Without Content*, Stanford CA: Stanford University Press, 1999。 [返回](#ref-zh-ch07-11)

<a id="ch07-n011-en"></a><a id="note-en-ch07-11"></a>
[11] See Giorgio Agamben, *Man Without Content*, Stanford CA: Stanford University Press, 1999. [返回](#ref-en-ch07-11)

<a id="ch07-n012-zh"></a><a id="note-zh-ch07-12"></a>
[12] Jacques Rancière, ‘Critique and Science in *Capital*’, in Louis Althusser, Étienne Balibar, Roger Establet, Pierre Macherey and Jacques Rancière, *Reading Capital: The Complete Edition*, London and New York: Verso, 2016, p. 108。 [返回](#ref-zh-ch07-12)

<a id="ch07-n012-en"></a><a id="note-en-ch07-12"></a>
[12] Jacques Rancière, ‘Critique and Science in *Capital*’, in Louis Althusser, Étienne Balibar, Roger Establet, Pierre Macherey and Jacques Rancière, *Reading Capital: The* *Complete Edition*, London and New York: Verso, 2016, p. 108. [返回](#ref-en-ch07-12)

<a id="ch07-n013-zh"></a><a id="note-zh-ch07-13"></a>
[13] 见 Alfred Sohn-Rethel, ‘The Formal Characteristics of Second Nature’, *Selva*, https://selvajournal.org/the-formal-characteristics-of-second-nature。 [返回](#ref-zh-ch07-13)

<a id="ch07-n013-en"></a><a id="note-en-ch07-13"></a>
[13] See Alfred Sohn-Rethel, ‘ The Formal Characteristics of Second Nature’, *Selva*, https://selvajournal.org/the-formal-characteristics-of-second-nature. [返回](#ref-en-ch07-13)

<a id="ch07-n014-zh"></a><a id="note-zh-ch07-14"></a>
[14] Rancière, ‘Critique and Science in *Capital*’, p. 126。 [返回](#ref-zh-ch07-14)

<a id="ch07-n014-en"></a><a id="note-en-ch07-14"></a>
[14] Rancière, ‘Critique and Science in *Capital*’, p. 126. [返回](#ref-en-ch07-14)

<a id="ch07-n015-zh"></a><a id="note-zh-ch07-15"></a>
[15] Theodor W. Adorno and Max Horkheimer, *Dialectic of Enlightenment*, trans. Edmund Jephcott, Stanford CA: Stanford University Press, 2002, p. 4。 [返回](#ref-zh-ch07-15)

<a id="ch07-n015-en"></a><a id="note-en-ch07-15"></a>
[15] Theodor W. Adorno and Max Horkheimer, *Dialectic of Enlightenment*, trans. Edmund Jephcott, Stanford CA: Stanford University Press, 2002, p. 4. [返回](#ref-en-ch07-15)

<a id="ch07-n016-zh"></a><a id="note-zh-ch07-16"></a>
[16] Siegfried Kracauer, ‘Short Break for Ventilation’ (1929), in *The Salaried Masses: Duty and Distraction in Weimar Germany*, London: Verso, 1998, pp. 40–42。 [返回](#ref-zh-ch07-16)

<a id="ch07-n016-en"></a><a id="note-en-ch07-16"></a>
[16] Siegfried Kracauer, ‘Short Break for Ventilation’ (1929), in *The Salaried Masses: Duty* *and Distraction in Weimar Germany*, London: Verso, 1998, pp. 40–42. [返回](#ref-en-ch07-16)

<a id="ch07-n017-zh"></a><a id="note-zh-ch07-17"></a>
[17] Rancière, ‘Critique and Science in *Capital*’, p. 112。 [返回](#ref-zh-ch07-17)

<a id="ch07-n017-en"></a><a id="note-en-ch07-17"></a>
[17] Rancière, ‘Critique and Science in *Capital*’, p. 112. [返回](#ref-en-ch07-17)

<a id="ch07-n018-zh"></a><a id="note-zh-ch07-18"></a>
[18] 见 Georg Lukács, *History and Class Consciousness: Studies in Marxist Dialectics* (1923), trans. Rodney Livingstone, Cambridge MA: MIT Press, 1968。 [返回](#ref-zh-ch07-18)

<a id="ch07-n018-en"></a><a id="note-en-ch07-18"></a>
[18] See Georg Lukács, *History and Class Consciousness: Studies in Marxist Dialectics* (1923), trans. Rodney Livingstone, Cambridge MA: MIT Press, 1968. [返回](#ref-en-ch07-18)

<a id="ch07-n019-zh"></a><a id="note-zh-ch07-19"></a>
[19] David Harvey, *A Brief History of Neoliberalism*, Oxford: Oxford University Press, 2005, p. 3。 [返回](#ref-zh-ch07-19)

<a id="ch07-n019-en"></a><a id="note-en-ch07-19"></a>
[19] David Harvey, *A Brief History of Neoliberalism,* Oxford: Oxford University Press, 2005, p. 3. [返回](#ref-en-ch07-19)

<a id="ch07-n020-zh"></a><a id="note-zh-ch07-20"></a>
[20] Anwar Shaikh, *Capitalism: Competition, Conflict, Crisis*, Oxford: Oxford University Press, 2016。 [返回](#ref-zh-ch07-20)

<a id="ch07-n020-en"></a><a id="note-en-ch07-20"></a>
[20] Anwar Shaikh, *Capitalism: Competition, Conflict, Crisis*, Oxford: Oxford University Press, 2016. [返回](#ref-en-ch07-20)

<a id="ch07-n021-zh"></a><a id="note-zh-ch07-21"></a>
[21] 详见我的 *Marshall Plan Modernism: Italian Postwar Abstraction and the Beginnings of Autonomia*（Durham, NC: Duke University Press, 2016）导论中的论述。 [返回](#ref-zh-ch07-21)

<a id="ch07-n021-en"></a><a id="note-en-ch07-21"></a>
[21] As detailed in the introduction to my *Marshall Plan Modernism: Italian Postwar* *Abstraction and the Beginnings of Autonomia*, Durham, NC: Duke University Press, 2016. [返回](#ref-en-ch07-21)

<a id="ch07-n022-zh"></a><a id="note-zh-ch07-22"></a>
[22] Rosalind Krauss, *Voyage on the North Sea: Essays on the Postmedium Condition*, London: Thames & Hudson, 2000. 另见 Rosalind Krauss, *Perpetual Inventory*, Cambridge: MIT Press, 2013。 [返回](#ref-zh-ch07-22)

<a id="ch07-n022-en"></a><a id="note-en-ch07-22"></a>
[22] Rosalind Krauss, *Voyage on the North Sea: Essays on the Postmedium Condition*, London: Thames & Hudson, 2000. See also Rosalind Krauss, *Perpetual Inventory*, Cambridge: MIT Press, 2013. [返回](#ref-en-ch07-22)

<a id="ch07-n023-zh"></a><a id="note-zh-ch07-23"></a>
[23] 见大卫·哈维论金融化所带来的解域与因果性问题之间的关系：https://thenextrecession.wordpress.com/2015/04/02/david-harvey-on-monocauses-multicauses-and-metaphors。 [返回](#ref-zh-ch07-23)

<a id="ch07-n023-en"></a><a id="note-en-ch07-23"></a>
[23] See David Harvey on the relationship between deterritorialization brought about by financialization and the problem of causality: https://thenextrecession.wordpress. com/2015/04/02/david-harvey-on-monocauses-multicauses-and-metaphors. [返回](#ref-en-ch07-23)

## 第8章　形式札记

<a id="ch08-title-zh"></a>
## 形式札记

<a id="ch08-title-en"></a>
## Notes on form

<a id="ch08-author-zh"></a>
彼得·奥斯本

<a id="ch08-author-en"></a>
PETER OSBORNE

<a id="ch08-p001-zh"></a>
“我们今天应如何理解艺术形式的概念？”以及“它与社会形式有何关系？”<a id="ref-zh-ch08-1"></a>[1](#note-zh-ch08-1) 尤其，如果我们把社会形式理解为内在于艺术形式，那么在这一特定历史时刻，这种内在性应如何被反思地建构、表达和解释？而如果正是“现实那些未解决的对抗”“作为其形式的内在问题在艺术作品中回归”，<a id="ref-zh-ch08-2"></a>[2](#note-zh-ch08-2) 那么当代艺术中的形式问题能告诉我们，今日现实中未解决的对抗是什么？

<a id="ch08-p001-en"></a>
‘How are we to understand the concept of artistic form today?’ and ‘What are its relations to social form?’<a id="ref-en-ch08-1"></a>[1](#note-en-ch08-1) In particular, if we understand social form to be immanent to artistic form, how is this immanence to be reflectively constructed, expressed and interpreted at this particular historical moment? And if it is ‘the unresolved antagonisms of reality’ that ‘return in artworks as immanent problems of their form’,<a id="ref-en-ch08-2"></a>[2](#note-en-ch08-2) what do the problems of form in contemporary art have to tell us about the unresolved antagonisms of our reality today?

<a id="ch08-s01-zh"></a>
## **当代艺术的运动**

<a id="ch08-s01-en"></a>
## **The movement of contemporary art**

<a id="ch08-p002-zh"></a>
在接近这些问题时，一个根本困难一开始就出现：在当代艺术中，形式这一范畴本身显得成问题。<a id="ref-zh-ch08-3"></a>[3](#note-zh-ch08-3) 确实，形式概念标志着当代艺术实践与批评共同的主要困难之一：如何给日益“个体”——高度个体化——的作品赋予一般的社会与历史意义（因而用古典术语说，“普遍性”）？困难是双重的。它源于这样一个事实：当代艺术是一个一般性艺术实践的场域，它在欧美核心地带发展起来，既反对（i）媒介特定现代主义的形式批评规范及其对旧的文艺复兴“艺术体系”的转化性再生产与扩展，也反对（ii）所有其他既定审美形式与普遍性的残余文化权威——所谓残余，是从以下论点看：在自由主义（如今是新自由主义）资本主义社会中，艺术作品具有倾向性增长的唯名论或个体性。<a id="ref-zh-ch08-4"></a>[4](#note-zh-ch08-4) 这种唯名论——内在于自主艺术的社会逻辑，并在艺术抵抗把形式化约为“格式”<a id="ref-zh-ch08-5"></a>[5](#note-zh-ch08-5)文化技术时加剧——因艺术之间边界的消解而强化，或被提升到更高次幂。作为反应，过去三十年特有的、日益社会化之新艺术形式的反向力量被激起。<a id="ref-zh-ch08-6"></a>[6](#note-zh-ch08-6) 在这方面，作为一般性艺术实践场域的当代艺术场域，展现出一种双重而矛盾的运动：对艺术形式的*尝试性消解*与*反思性、扩展性的恢复*。于是，形式的问题性历史上首先表现为对艺术形式本身的尝试性消解和反思性扩展。

<a id="ch08-p002-en"></a>
In approaching these questions, a fundamental difficulty appears at the outset: in contemporary art the very category of form appears problematic.<a id="ref-en-ch08-3"></a>[3](#note-en-ch08-3) Indeed, the concept of form marks one of the main difficulties of contemporary art practice and criticism alike: namely, how to give general social and historical significance (and hence, in the classical terminology, ‘universality’) to increasingly ‘individual’ – highly individuated – works? The difficulty is twofold. It derives from the fact that contemporary art is a field of generically artistic practices that developed via its Euro–North American heartlands in reaction against both (i) the formal critical norms of medium-specific modernisms and their transformative reproduction and extension of the old, Renaissance ‘system of the arts’, and (ii) the residual cultural authority of all other received aesthetic forms and universals – residual, that is, from the standpoint of the thesis of the tendentially increasing nominalism or individuality of works of art in liberal (now neoliberal) capitalist societies.<a id="ref-en-ch08-4"></a>[4](#note-en-ch08-4) This nominalism – inherent in the social logic of autonomous art, and exacerbated in artistic resistance to the reduction of form to the cultural technology of ‘formats’<a id="ref-en-ch08-5"></a>[5](#note-en-ch08-5) – has been intensified, or raised to a higher power, by the dissolution of the boundaries between the arts. In reaction, the countervailing forces of new, increasingly socialized artistic forms, characteristic of the last three decades, have been provoked.<a id="ref-en-ch08-6"></a>[6](#note-en-ch08-6) In this respect, the field of contemporary art as a field of generically artistic practices exhibits a double and contradictory movement of the *attempted dissolution* and the *reflective, expanded* *restitution* of artistic form. The problematicity of form, then, manifests itself historically, primarily, as an attempted dissolution and reflective expansion of artistic form itself.

<a id="ch08-p003-zh"></a>
这一双重运动重演了二十世纪末与二十一世纪初资本主义中社会形式的问题性；它是一般资本主义个体性之矛盾结构的产物，既在其*承诺*中（个体作为交换关系之“自我占有”主体的自由——可称之为消费者主权），也在其*现实*中（缺乏自我占有，或遭到剥夺，表现为交换体系对构成它的个体之冷漠的非社会同一性——可称之为异化与债务社会）。在这方面，我们可以说，当代艺术是对破碎的“幸福承诺”的模仿，不仅是对艺术的幸福承诺，也是对资本主义本身的幸福承诺的模仿。<a id="ref-zh-ch08-7"></a>[7](#note-zh-ch08-7) 我们或许可以说，*艺术是资本主义社会对其自身规则秘密不满的代理人*。<a id="ref-zh-ch08-8"></a>[8](#note-zh-ch08-8) 在其对艺术形式的矛盾性消解与反思性扩展中，当代艺术反映资本主义社会性的矛盾结构，即社会本身的被中介的消解——一种持续的消解与变形后的恢复。这是仅在形式层面上恢复社会——商品形式、货币、资本与国家——而这种恢复与构成社会的个体间关系相异化。这是资本主义的波兰尼维度，晚近由德国社会学家与批判理论家沃尔夫冈·施特雷克在分析上复兴：一种食人的资本主义，通过侵蚀社会之作为社会的活生生的社会性，侵蚀自身的人类学与社会条件。这是一种自1970年代末以来被新自由主义政治经济策略加剧的矛盾结构；在其中，哈耶克的《通往奴役之路》迟来地压倒了波兰尼的《大转型》；尽管那种霸权目前似乎正在崩塌，至少在一定程度上如此。<a id="ref-zh-ch08-9"></a>[9](#note-zh-ch08-9)

<a id="ch08-p003-en"></a>
This double movement re-enacts the problematic character of social form in late-twentieth- and early-twenty-first-century capitalism that is a product of the contradictory structure of capitalistic individuality as such, in both its *promise* (the freedom of the individual as a ‘self-possessing’ subject of exchange relations – call it consumer sovereignty) and its *reality* (the lack of self-possession, or dispossession, manifest in the asocial sameness of the indifference of the system of exchange to the individuals who make it up – call it alienation and the debt society). In this respect, we might say, contemporary art is a mimesis of the broken ‘promise of happiness’ not merely of art but of capitalism itself.<a id="ref-en-ch08-7"></a>[7](#note-en-ch08-7) *Art is the agent of the secret discontent of capitalist societies* *with their own rules*, we might say.<a id="ref-en-ch08-8"></a>[8](#note-en-ch08-8) In its contradictory dissolution and reflective expansion of artistic form, contemporary art reflects the contradictory structure of capitalistic sociality as a mediated dissolution – a constant dissolution and transformed reinstatement – of the social itself. This is a reinstatement of the social at the level of form alone – commodity form, money, capital and the state – alienated from its constitutive relations between individuals. This is the Polanyian dimension of capitalism, recently analytically revived by the German sociologist and critical theorist Wolfgang Streeck: a cannibalistic capitalism that erodes its own anthropological and social conditions by eroding the living sociality of the social as such. It is a contradictory structure that has been intensified by the political-economic strategies of neoliberalism since the end of the 1970s, in which Hayek’s *Road to Serfdom* belatedly prevailed over Polanyi’s *The* *Great Transformation*; although that hegemony currently appears to be crumbling, at least to some extent.<a id="ref-en-ch08-9"></a>[9](#note-en-ch08-9)

<a id="ch08-p004-zh"></a>
在欧美语境中——当时该语境主导国际艺术界争论——在1960年代后半叶反格林伯格现代主义形式主义的高峰，尝试性消解与反思性扩展艺术形式的双重运动，更广泛地构成当代艺术场域，当时被归在“后形式主义”的总标题下。这不只是批评领域及与其直接相关的艺术实践中的反应，还涉及一种更广泛的意识，即杰克·伯纳姆1967年著作《超越现代雕塑》中所称的“形式耗尽”。<a id="ref-zh-ch08-10"></a>[10](#note-zh-ch08-10) 伯纳姆把它归因于科学技术对艺术的影响，但它同样是个人主义之社会力量的效果，这种个人主义推动了1960年代那些受益于二战后繁荣的“消费社会”中的文化变革。罗伯特·史密森以新（但仅名义上的）范畴的“雪崩”诊断画廊与博物馆对这一状况的悖论性反应。<a id="ref-zh-ch08-11"></a>[11](#note-zh-ch08-11) 这种范畴唯名论产生了当代意义上的“策展”，即通过展览制作进行临时意义建构的实践，而非在长时间内照料一个收藏。这种意义上的“策展”已成为艺术机构的核心，因为它通过新的关系配置，赋予高度个体化的作品以部分而暂时的社会历史意义。

<a id="ch08-p004-en"></a>
In the Euro–North American context, which dominated international artworld debates at the time, at the height of the reaction against Greenberg’s modernist formalism in the second half of the 1960s, the double movement of the attempted dissolution and the reflective expansion of artistic form, constituting the field of contemporary art more widely, went under the general heading of ‘post-formalism’. This was not just a reaction in the field of criticism, and of art practices tied directly to it, but involved a wider sense of what, in his 1967 book *Beyond Modern* *Sculpture*, Jack Burnham called ‘form exhaustion’.<a id="ref-en-ch08-10"></a>[10](#note-en-ch08-10) Burnham attributed this to the effect on art of science and technology, but it was equally the effect of the social power of the individualism that drove the cultural transformations of the 1960s in those ‘consumer societies’ that benefited from the post-World War II boom. Robert Smithson diagnosed the paradoxical reaction of galleries and museums to this situation in terms of an ‘avalanche’ of new (yet merely nominal) categories.<a id="ref-en-ch08-11"></a>[11](#note-en-ch08-11) This categorial nominalism produced ‘curation’ in its contemporary sense, as a practice of temporary sense-making via exhibition-making, rather than the care of a collection over a prolonged period of time. ‘Curation’ in this sense has become central to art institutions since it gives partial and temporary social and historical meaning to highly individualized works via new relational configurations.

<a id="ch08-p005-zh"></a>
“形式耗尽”，伯纳姆论证说，导致了“现象主义的兴起”，以及从“纯粹形式”向他所称“纯粹经验”的批评上的转变。这对应于作品层面焦点从形式转向对材料（及其往往由工业生产的诸种技术属性）的关注，同时作品向自身的不完整性敞开——常通过序列主义，但更一般地通过任何把时间引入作品构成的手段，尤其是表演，以及对语境构成性作用的日益意识。这导致某种*非*物质主义，与作品的观念维度相关联，并相应地带来关于如何定位单件作品边界或限度的一种不确定性。1969年，维克多·伯金在“情境美学”概念中总结了这一点，文章发表在《Studio International》同一期，与约瑟夫·科苏斯更具争议的“艺术与哲学”第一部分同时——由此开启英语世界观念艺术的双重轨迹：关系性与语言性（后形式主义与新形式主义）。<a id="ref-zh-ch08-12"></a>[12](#note-zh-ch08-12) 前者导向1980与1990年代的语境性与关系性艺术；后者导向各种观念形式主义，包括1990年代与2000年代初的模仿性新观念主义。<a id="ref-zh-ch08-13"></a>[13](#note-zh-ch08-13)

<a id="ch08-p005-en"></a>
‘Form exhaustion’, Burnham argued, had led to ‘The Rise of Phenomenalism’ and a consequent critical transition from ‘pure form’ to what he called ‘pure experience’. This corresponded to a shift of focus, at the level of the work, away from form towards a preoccupation with materials (and their often industrially produced technical properties), along with an opening of works onto their own incompletions – often through serialism, but more generally through any means for introducing time into the constitution of the work, especially performance, along with a growing sense of the constitutive role of context. This led to a certain *im*materialism, associated with the conceptual dimension of works and a corresponding uncertainty as to how to locate the boundaries or limits of individual works. This was summed up in 1969 by Victor Burgin in the concept of ‘situational aesthetics’, in an article published in the same issue of *Studio International* as the first part of Joseph Kosuth’s more notorious ‘Art and Philosophy’ – thereby inaugurating the double trajectory of anglophone conceptual art: relational and linguistic (post-formalist and neo-formalist).<a id="ref-en-ch08-12"></a>[12](#note-en-ch08-12) The former led to the contextual and relational art of the 1980s and 1990s; the latter to various conceptual formalisms, including the mimetic neo-conceptualisms of the 1990s and early 2000s.<a id="ref-en-ch08-13"></a>[13](#note-en-ch08-13)

<a id="ch08-p006-zh"></a>
然而，作为一个仅仅抽象的否定，无法以内在方式与自身增殖对象的多重规定性相连，后形式主义作为批评范畴并未持续多久；甚至比其继任者后现代主义还短。尽管如此，后形式主义的冲动通过“艺术的扩展”观念获得了更持久、更确定的遗产（不同于曾变形为早期哈尔·福斯特“批判性后现代主义”的批评多元主义）：艺术通过可能的艺术材料场域向无限扩展而向无限扩展。<a id="ref-zh-ch08-14"></a>[14](#note-zh-ch08-14) 这一观念原则上应区别于罗莎琳德·克劳斯的“扩展场域”概念——人们常把二者混为一谈——在后者中，克劳斯用直接施加于艺术场域的一般符号学之理论形式主义（或理论主义）取代了格林伯格的美学形式主义。<a id="ref-zh-ch08-15"></a>[15](#note-zh-ch08-15) 因为“场域”的扩展——克劳斯以受限的符号学方式理解为通过其生产艺术意义的具有意义的差异之场域的扩展——实际上更根本地是作品自身边界的瓦解，并由此向无限扩展，通过纳入新材料：不只是打破不同艺术之间的边界，而更根本地打破艺术与非艺术之间的边界，或者用阿多诺稍微更具悖论性存在论细微差别的话说，艺术与“经验之物”（*der Empirie*）之间的边界。

<a id="ch08-p006-en"></a>
However, as a merely abstract negation, unable to connect itself immanently to the multiple determinacies of its proliferating objects, post-formalism did not last long as a critical category; less time even than its successor, postmodernism. Nonetheless, the impulse of post-formalism acquired a more enduring, more determinate legacy (different from the critical pluralism that had morphed into the early Hal Foster’s ‘critical postmodernism’) through the idea of the ‘expansion of art’: the expansion of art to infinity, through the expansion to infinity of the field of possible artistic materials.<a id="ref-en-ch08-14"></a>[14](#note-en-ch08-14) This idea should be distinguished in principle from Rosalind Krauss’s concept of the ‘expanded field’, with which it is often conflated, in which Krauss exchanged Greenberg’s aesthetic formalism for the theoretical formalism (or theoreticism) of a general semiotics applied directly to the artistic field.<a id="ref-en-ch08-15"></a>[15](#note-en-ch08-15) For the expansion of the ‘field’ – understood by Krauss in a restricted semiotic manner, as the expansion of the field of significant differences through which artistic meaning is produced – was actually more fundamentally the breaking down – and thereby expansion to infinity – of the borders of the work itself, through the inclusion of new materials: not simply by breaking down the borders between the different arts, but more fundamentally the borders between art and non-art, or what, with slightly more paradoxical ontological nuance, Adorno called the borders between art and ‘the empirical’ (*der Empirie*).

<a id="ch08-p007-zh"></a>
然而，“艺术的扩展”非但没有完成形式的消解，反而在“成为形式”的母题中找到了其批评与策展的对应物，象征性地体现在“当态度成为形式”这一短语中，它出自哈拉尔德·泽曼1969年在伯尔尼美术馆举办的著名展览（主标题为《Live in Your Head》）副标题的开头。征候性地，这一短语后来成为该展览广为人知的名称。（完整副标题是“当态度成为形式［作品—概念—过程—情境—信息］”，这份清单显然对赋予展览某种批评确定性很重要。）随着晚近对1960年代展览的修正主义史学，这一“成为形式”母题在越来越宽广的批评语境中被复兴并重新重复。<a id="ref-zh-ch08-16"></a>[16](#note-zh-ch08-16) 过去二十年，“纬度”成为形式，“历史”乃至“生活”本身也成为形式。<a id="ref-zh-ch08-17"></a>[17](#note-zh-ch08-17) 更平白地说，2013年埃莱娜·菲利波维奇提出，随着艺术家—策展人的兴起，“展览成为形式”——她借用了对威尼斯重演版《态度》一篇评论的标题——当然，展览不需要*艺术家*策展人才能如此；而且从当代策展概念开端起，它们本来就已经是“形式”。<a id="ref-zh-ch08-18"></a>[18](#note-zh-ch08-18)

<a id="ch08-p007-en"></a>
However, rather than consummating the dissolution of form, the ‘expansion of art’ found its critical and curatorial correlate in the motif of ‘becoming form’, emblematically in the phrase ‘When Attitudes Become Form’, from the opening to the subtitle of Harald Szeeman’s famous exhibition (its main title was *Live* *in Your Head*) at the Kunsthalle, Berne, 1969. Symptomatically, this was the phrase by which the exhibition subsequently became generally known. (The full subtitle was ‘When Attitudes Become Form [Works – Concepts – Processes – Situations – Information]’, and that list is obviously important in giving the exhibition some critical determinacy.) In the wake of the recent revisionist historiography of the exhibitions of the 1960s, this motif of ‘becoming form’ has been revived and repeated anew in ever more expansive critical contexts.<a id="ref-en-ch08-16"></a>[16](#note-en-ch08-16) In the last twenty years, ‘latitudes’ have become form, along with ‘history’ and even ‘living’ itself.<a id="ref-en-ch08-17"></a>[17](#note-en-ch08-17) More prosaically, in 2013 Elena Filipovic suggested that with the rise of the artist-curator, ‘Exhibitions Become Form’ – borrowing her title from a review of the Venice remake of *Attitudes* – although of course exhibitions don’t need an *artist*-curator to do that; and they have in any case been ‘form’ from the outset of the contemporary conception of curation.<a id="ref-en-ch08-18"></a>[18](#note-en-ch08-18)

<a id="ch08-p008-zh"></a>
那么，当代艺术的基本运动涉及艺术概念的扩展：通过消解于并反思性地吸收那些不仅先前、而且持久地属于非艺术的材料与实践场域。这相应地扩展了“艺术形式”的外延，同时要求作品在其形式整合中保持某些新元素的非艺术地位。因为这种整合的批评性依赖于这些元素的*存在论双重编码*，即同时处于作品之内与之外，拼贴提供了范式性例证。正是这种构成作品批评地位、其矛盾结构及其赋予艺术概念之发展动力学的双重编码，使辩证逻辑成为理解艺术形式概念的哲学钥匙。<a id="ref-zh-ch08-19"></a>[19](#note-zh-ch08-19) 同时，一个新问题出现：如果可能的艺术材料范围原则上无限，那么在单件作品层面，究竟是什么（如果有的话）*限定*艺术形式概念的这一扩展？

<a id="ch08-p008-en"></a>
The basic movement of contemporary art, then, has involved an expansion of the concept of art through its dissolution into and reflective absorption of fields of – not just previously, but enduringly – non-art materials and practices. This correspondingly expanded the extension of ‘artistic form’, while requiring the work’s simultaneous preservation of the non-art status of certain of its new elements within their formal integration. For the criticality of this integration depends on the *ontological* *double-coding* of these elements, as at once inside and outside the work, in a manner paradigmatically exemplified by collage. It is this kind of double-coding constituting the critical status of the work, their contradictory structure, and the developmental dynamic they impart to the concept of art that suggests dialectical logic as a philosophical key to the comprehension of the concept of artistic form.<a id="ref-en-ch08-19"></a>[19](#note-en-ch08-19) At the same time, a new question arises: namely, what, if anything, *delimits* this expansion of the concept of artistic form, at the level of the individual work, if the range of possible artistic materials is in principle infinite?

<a id="ch08-p009-zh"></a>
然而，在我们考虑这一点之前，需要稍微回溯传统的“质料—形式”（hylomorphic）形式概念；1960年代以来艺术的自我扩展实际上摧毁了它作为哲学理解艺术的可行模型，无论其客观（亚里士多德式）还是主观（康德式）变体；同时也要回溯西蒙东式的唯名论替代方案，一些人认为它是取代上述模型、作为艺术创造过程之哲学说明的最佳选择。

<a id="ch08-p009-en"></a>
Before we consider this, though, we need to backtrack a little to the traditional, ‘hylomorphic’ concept of form, which the self-expansion of art since the 1960s effectively destroyed as a viable model for the philosophical comprehension of art, in both its objective (Aristotelian) and subjective (Kantian) variants; along with the Simondonian nominalist alternative that is taken by some as the best option for their replacement as a philosophical account of the process of artistic creation.

<a id="ch08-s02-zh"></a>
## **质料—形式论及其唯名论批判**

<a id="ch08-s02-en"></a>
## **Hylomorphism and its nominalist critique**

<a id="ch08-p010-zh"></a>
从词源上说，“质料—形式论”（hylomorphism）源自希腊语*hylé*（木材或质料）与*morphé*（形状或形式），但直到十九世纪才被铸造。它表示，在传统亚里士多德构想中，与形式相对的是质料，这种方式是通过从塑造木材的雕塑活动中进行概括抽象而获得的。质料—形式论是这样一种哲学理论：存在是形式与质料的结合，其中质料是*潜能*（不确定、不变且无限），形式则是*现实*且实体的：在每一情形中赋予质料以确定性。因此，形式在存在论上优先于“单纯的”质料。质料被贬低为同质而无形的；形式被颂扬为赋予意义的。特别是，在这一熟悉的构想中，质料本质上对它据以被塑形的形式漠不关心。<a id="ref-zh-ch08-20"></a>[20](#note-zh-ch08-20)

<a id="ch08-p010-en"></a>
Derived etymologically from the Greek *hylé* (wood or matter) and *morphé* (shape or form), but coined only in the nineteenth century, the term ‘hylomorphism’ indicates that it is matter to which form is opposed in the traditional Aristotlean conception, in a manner derived via generalizing abstraction from the sculptural activity of shaping wood. Hylomorphism is the philosophical theory that being is a combination of form and matter within which matter is *potential* (indeterminate, unchanging and infinite) and form is *actual* and substantial: giving determinacy to matter, in each instance. Hence the ontological prioritization of form over ‘mere’ matter. Matter is denigrated as homogeneous and shapeless; form is lauded as meaning-giving. In particular, on this familiar conception, matter is essentially indifferent to the forms by which it is shaped.<a id="ref-en-ch08-20"></a>[20](#note-en-ch08-20)

<a id="ch08-p011-zh"></a>
这种观点的问题——正如吉尔伯特·西蒙东对质料形式论的批判如今经典地指出的（粗略地说）——在于它是对*个体化*的不充分说明，因为它把个体化约为一般形式的特殊实例，或诸特殊项，而非在存在论上使它们个体化。在西蒙东的著名例子中，把混凝土倒入模具，按质料—形式论的理解，形式完全存在于模具中，并从外部强加于漠然的质料。相反，西蒙东寻求一种个体化（物理的、生物的、心理的与集体的）说明，把它视为个体从“前个体”存在过程中涌现的一元论过程，这些过程在个体内部留下残余的*跨*个体性印记。因此有“一切个体都是跨个体”的观念。然而只有个体是现实的；这是一种唯名论存在论。质料由此被理解为积极的物质能动者，无需外部形式从外部强加。<a id="ref-zh-ch08-21"></a>[21](#note-zh-ch08-21) 正如德勒兹与瓜塔里在《千高原》中所呈现的：

<a id="ch08-p011-en"></a>
The problem with this view, as now-canonically pointed out in Gilbert Simondon’s critique of hylomorphism (crudely put) is that it is an inadequate account of *individuation*, since it reduces individuals to no more than particular instances of general forms, or particulars, rather than individuating them ontologically. In Simendon’s well-known example, the pouring of concrete into a mould, form is hylomorphically understood to reside exclusively in the mould, and to be imposed externally upon an indifferent matter. In contrast, Simendon sought an account of individuation (physical, biological, psychic and collective) as a monistic process of the emergence of individuals out of ‘pre-individual’ processes of being, which leave their mark within individuals in a residual *trans*individuality. Hence the idea that all individuals are transindividuals. Yet only individuals are actual; this a nominalist ontology. Matter is thus understood as an active material agent with no need of an external form to impose itself from without.<a id="ref-en-ch08-21"></a>[21](#note-en-ch08-21) As presented by Deleuze and Guattari in *A Thousand Plateaus*:

<a id="ch08-q001-zh"></a>
<a id="ch08-q002-zh"></a>
> 西蒙东揭示了质料—形式模型在技术上的不充分性，因为它假定了一种固定的形式与一种被视为同质的质料。正是规律（law）的观念保证了这一模型的连贯性，因为规律使质料服从于这种或那种形式，并反过来在质料中实现从形式推演出的某种属性。……西蒙东表明，*质料—形式*模型漏掉了许多能动的与情动性的东西。一方面，对已成形或可成形的质料，我们必须加上整个运动中的能量物质性，它承载着*奇异性*或*此性*，后者已经像是隐含的形式——是拓扑的而非几何的——并与变形过程相结合。……另一方面，对质料的本质属性［源于形式本质］，我们必须加上可变的强度情动，它们有时由操作产生，有时相反使操作成为可能……无论如何，问题在于顺应……［材料］，循着它的引导，把操作连接到一种物质性，而不是把形式强加于质料：我们所面对的，与其说是服从规律的质料，不如说是拥有*法*（nomos）的物质性。……

<a id="ch08-q001-en"></a>
<a id="ch08-q002-en"></a>
> Simondon exposes the technological insufficiency of the matter– form model, in that it assumes a fixed form and a matter deemed  homogeneous. It is the idea of the law that assures the model’s coherence, since laws are what submit matter to this or that form,  and conversely, realize in matter a given property deduced from the  form. … Simondon demonstrates that the *hylomorphic* model leaves  many things, active and affective, by the wayside. On the one hand,  to the formed or formable matter we must add an entire energetic  materiality in movement, carrying *singularities* or *haecceitie*s that  are already like implicit forms that are topological, rather than  geometrical, and that combine with processes of deformation.  … On the other hand, to the essential properties of the matter  [deriving from the formal essences] we must add variable intensive  affects, now resulting from the operation, now on the contrary  making it possible… At any rate, it is a question of surrendering …  [to the material], following where it leads by connecting operations  to a materiality, instead of imposing a form upon a matter: what one  addresses is less a matter submitted to the laws than a materiality  possessing a *nomos* [law]. …

<a id="ch08-q003-zh"></a>
> 简言之，西蒙东批判质料—形式模型，是因为它把形式与质料当作分别定义的两项，如同两条半链的末端，其连接已不可见；又像一种简单的模塑关系，其背后是一种永远变化、连续、不再能被把握的调制。对质料—形式图式的批判基于“在形式与质料之间，存在一个中介与中间维度的区域”，一个能量的、分子的维度——一个自成一体、通过质料展开其物质性的空间，一个自成一体、通过形式推进其特性的数。<a id="ref-zh-ch08-22"></a>[22](#note-zh-ch08-22)

<a id="ch08-q003-en"></a>
> In short, what Simondon criticizes the hylomorphic model for  is taking form and matter to be two terms defined separately, like  the end of two half-chains whose connection can no longer be  seen, like a simple relation of moulding behind which there is a  perpetually variable, continuous modulation that it is no longer  possible to grasp. The critique of the hylomorphic schema is based  on ‘the existence, between form and matter, of a zone of medium  and intermediary dimension’, of energetic, molecular dimension  – a space unto itself that deploys its materiality through matter, a  number unto itself that propels its traits through form.<a id="ref-en-ch08-22"></a>[22](#note-en-ch08-22)

<a id="ch08-p012-zh"></a>
很容易看出，这种个体化存在论为何显得有吸引力：它可作为当代艺术唯名论的哲学基础，在这种艺术中，每件作品都被设想为个体化到了独异性的程度。质料取代形式成为能动原则。只需额外把活动等同于能动性，便可抵达“新唯物主义”的一元论前提。但这种“扁平”的自然主义存在论是否有足够区分度，以理解像当代艺术作品这样既深刻社会历史性、又形式错综复杂的东西？问题在于质料形式论及其批评者所共有的形式与质料对立的未经反思性质。另一方面，对黑格尔而言，尽管形式对理解任何规定过程都至关重要，并因此是一般可理解性的条件，它并非简单与质料对立，更重要的是也与“内容”对立。确实，后者表现为形式—质料关系辩证法的概念反思结果。

<a id="ch08-p012-en"></a>
It is easy to see the appeal of such an ontology of individuation as a philosophical foundation for the nominalism of a contemporary art in which each work is imagined as individual to the point of singularity. Matter replaces form as the active principle. It only requires the additional equation of activity with agency to arrive at the monistic premiss of ‘new materialism’. But is such a ‘flat’ naturalist ontology sufficiently differentiated to comprehend anything as deeply social and historical, as well as formally intricate, as works of contemporary art? The problem lies in the unreflected character of the opposition between form and matter shared by hylomorphism and its critics alike. For Hegel, on the other hand, while form is central to the comprehension of any process of determination, and as such it is a general condition of intelligibility, it is not simply opposed to matter, but more importantly also to ‘content’. Indeed, the latter appears as the result of conceptual reflection of the dialectics of the form–matter relation.

<a id="ch08-s03-zh"></a>
## **形式的辩证哲学**

<a id="ch08-s03-en"></a>
## **A dialectical philosophy of form**

<a id="ch08-p013-zh"></a>
在黑格尔的《逻辑学》中，形式概念通过一系列三重辩证对立——形式与非形式（形式作为本质）；形式与质料；形式与内容——从最一般的含义发展到更具体的含义，同时沿途也带入一系列其他逻辑概念。

<a id="ch08-p013-en"></a>
In Hegel’s *Science of Logic* the concept of form is developed, from its most general meaning to more concrete ones, through a series of three dialectical oppositions – form and non-form (form as essence); form and matter; and form and content – while also bringing a range of other logical concepts into play along the way.

<a id="ch08-p014-zh"></a>
1. *形式作为本质，或形式与非形式*

<a id="ch08-p014-en"></a>
1. *Form as essence, or, form and non-form*

<a id="ch08-q004-zh"></a>
> 一般而言，属于形式的是一切*有规定性*的东西；它是形式规定，就其是被设定之物、并因而区别于*其形式所归属者*而言……

<a id="ch08-q004-en"></a>
> To form belongs in general everything *determinate*; it is a form  determination in so far as it is something posited and consequently  distinct from *that of which* it is the form…

<a id="ch08-q005-zh"></a>
> ……本质的形式规定，作为反思的规定性，在其更精确的规定性中……是同一与差异。后者部分地作为杂多，部分地作为对立。<a id="ref-zh-ch08-23"></a>[23](#note-zh-ch08-23)

<a id="ch08-q005-en"></a>
> … the form determinations of essence, as determinatenesses of  reflection, are, in their more precise determinateness … identity and  difference. The latter partly as diversity, partly as opposition.<a id="ref-en-ch08-23"></a>[23](#note-en-ch08-23)

<a id="ch08-p015-zh"></a>
在这方面，形式概念确实通过其与某种无形式之物（“其形式所归属者”）的差异而获得最初确定性。然而，同样，其对立面的无形式性也只有通过它相应地与形式的反思性对立才被*规定*为无形式的。在那一刻，它已被规定为“质料”。

<a id="ch08-p015-en"></a>
In this respect, the concept of form does indeed gain its initial determinacy through its difference from something formless (‘that of which it is the form’). However, equally, the formlessness of its opposite is only *determined* as formless through its corresponding reflective opposition to form. At that point, it has become determined as ‘matter’.

<a id="ch08-p016-zh"></a>
2. *形式与质料* 黑格尔论证说，“质料［并不‘先于’形式，而是］被规定为无形式的同一性”；也就是说，它通过与形式的关系而“被规定为未规定者”。作为“形式所归属者”的第一个名称，我们可以说质料是一种*否定性*形式。“质料是一种纯粹的*抽象*”；<a id="ref-zh-ch08-24"></a>[24](#note-zh-ch08-24) 形式概念在质料形式论的理解中本身也是如此。然而，在与形式的这种抽象同一性中，在已被赋形之后（通过它与形式的对立），质料成为*内容*。

<a id="ch08-p016-en"></a>
2. *Form and matter* ‘Matter [does not “precede” form, but rather] is determined as formless identity’, Hegel argues; that is, it is ‘determined as undetermined’ by its relation to form. As the first name for ‘that of which the form is the form’, we could say that matter is a kind of *negative* form. ‘Matter is a sheer *abstraction*’;<a id="ref-en-ch08-24"></a>[24](#note-en-ch08-24) as is the concept of form itself in its hylomorphic understanding. However, in this abstract identity with form, in having been formed (through its opposition to form), matter becomes *content*.

<a id="ch08-p017-zh"></a>
3. *形式与内容* 对黑格尔而言，内容是形式与质料之统一的名称：“形式与质料中的同一要素”；“内容［因此］在其自身中是确定的”。<a id="ref-zh-ch08-25"></a>[25](#note-zh-ch08-25) 于是，在内容内部，形式与质料的对立被再生产，以致形式的确定性成为“内容的漠然性”。辩证地说，这里每个概念都发生了加倍：形式与内容。

<a id="ch08-p017-en"></a>
3. *Form and content* Content, for Hegel, is the name for the unity of form and matter: ‘the identical element in form and matter’; ‘content is [therefore] determinate in its own self’.<a id="ref-en-ch08-25"></a>[25](#note-en-ch08-25) There is, then, a reproduction of form’s opposition to matter, within content, such that the determinateness of form is ‘indifference of content’. Dialectically, there is thus a doubling of each concept here: form and content.

<a id="ch08-p018-zh"></a>
4. *形式的辩证加倍*

<a id="ch08-p018-en"></a>
4. *Dialectical doubling of form*

<a id="ch08-q006-zh"></a>
> 关于形式与内容的对立，至关重要的是记住，内容并非无形式的，而是同样具有*内在于自身的*形式，正如形式是*某种外在于它*的东西。我们在此拥有形式的加倍：一方面，作为内在地被反思的东西，它是内容；另一方面，作为未被内在地反思的东西，它是外在实存，对内容漠不关心。在此*自在*呈现的是形式与内容的绝对关系，即二者相互翻转［*Umschlagen*］，以致“内容”不过是形式向内容的相互*翻转*，“形式”不过是内容向形式的*翻转*。<a id="ref-zh-ch08-26"></a>[26](#note-zh-ch08-26)

<a id="ch08-q006-en"></a>
> Regarding the antithesis of form and content it is essential to  remember that the content is not formless, but that it has the *form*  *within itself* just as much as the form is *something external* to it.  We have here the doubling of form: on the one hand, as inwardly  reflected, it is the content; on the other hand, as not reflected  inwardly, it is the external existence, that is indifferent to the  content. What is here present *in-itself* is the absolute relationship  of form and content, i.e. the reciprocal overturning [*Umschlagen*]  of one into the other, so that ‘content’ is nothing but the reciprocal  *overturning of form* into content, and ‘form’ nothing but *overturning*  *of content* into form.<a id="ref-en-ch08-26"></a>[26](#note-en-ch08-26)

<a id="ch08-p019-zh"></a>
因此，在形式的辩证规定中，“内容”对“质料”具有优先性。内容是发展了的*形式*。此外，当内容具有历史性时，它依赖于一个历史上给定的状态，不是一般质料的状态，而是特定*材料*的状态。

<a id="ch08-p019-en"></a>
There is thus a primacy of ‘content’ over ‘matter’ in the dialectical determination of form. Content is developed form. Furthermore, where content is historical, it relies on a historically given state not of matter in general, but of determinate *materials*.

<a id="ch08-p020-zh"></a>
5. *内容作为发展了的、自我运动的形式的辩证加倍*

<a id="ch08-p020-en"></a>
5. *Dialectical doubling of content as developed, self-moving form*

<a id="ch08-q007-zh"></a>
> 内容就是发展了的*形式*，即独立实存的外在性与*对立*，以及它们的同一关系；唯有在这一关系中，这些有区别的实存才成其所是。

<a id="ch08-q007-en"></a>
> [The] content is the developed form, i.e. both the externality and  *opposition* of independent existences, and their identical relation,  within which alone these distinct existences are what they are.

<a id="ch08-p021-zh"></a>
“发展了的”形式因此是*自我运动的形式*：

<a id="ch08-p021-en"></a>
‘Developed’ form is thus a *self-moving form*:

<a id="ch08-q008-zh"></a>
> 形式的自我运动是*活动*［*Tätigkeit*］，是事物［*Sache*］作为*真实*根据的激活［*Betätigung*］，它自身扬弃为现实性，并且是偶然现实性、即诸条件的激活：它们的内在反思及其自我扬弃……成为事物／*事情*［*Sache*］的现实性。<a id="ref-zh-ch08-27"></a>[27](#note-zh-ch08-27)

<a id="ch08-q008-en"></a>
> self-movement of the form is *activity* [*Tätigkeit*], activation  [*Betätigung*] of the thing [*Sache*] as the *real* ground, which sublates  itself into actuality, and the activation of the contingent actuality,  i.e. of the conditions: their inward reflection and their self-sublation  into … the actuality of the thing/*matter* [*Sache*].<a id="ref-en-ch08-27"></a>[27](#note-en-ch08-27)

<a id="ch08-p022-zh"></a>
于是我们最终得到这样一个形式概念：形式是事物的自我运动活动，扬弃“发展了的*形式*”的内容。或者，正如阿多诺在《美学理论》中关于艺术的历史性所说：“运动的规律就是形式的规律。”<a id="ref-zh-ch08-28"></a>[28](#note-zh-ch08-28)

<a id="ch08-p022-en"></a>
We thus end up with a concept of form as the self-moving activity of things (*Sachen*), sublating the content of ‘developed form’. Or, as Adorno put it in *Aesthetic Theory* with regard to the historical character of art: ‘the law of movement is the law of form’.<a id="ref-en-ch08-28"></a>[28](#note-en-ch08-28)

<a id="ch08-p023-zh"></a>
在黑格尔那里，形式概念辩证地多面，是在穿越一系列反思性对立配对的发展中被建构的；而在与西蒙东相关、由德勒兹与瓜塔里提出的质料形式论批判中，目标却是简单的亚里士多德形式概念，它完全通过其与“质料”的对立而被建构，不涉及内容。因此，当德勒兹与瓜塔里写到“与其说是服从规律的质料，不如说是*拥有* *nomos*／法的物质性”时，他们似乎并未逃离“形式”，而是隐含地诉诸内容这一辩证概念，即形式与质料的统一，随后通过它，与形式更高层次的对立被再生产出来。而当他们写到“在形式与质料*之间*，存在一个中介与中间维度的区域”时，他们自己似乎恰恰是在“把形式与质料当作分别定义的两项”——这正是质料形式论模型的主要问题。

<a id="ch08-p023-en"></a>
Whereas in Hegel the concept of form is dialectically multifaceted, being constructed in a development running through a series of reflected oppositional pairings, in the critique of hylomorphism associated with Simondon and propounded by Deleuze and Guattari it is the simple Aristotelian concept of form that is the target, constructed exclusively through its opposition to ‘matter’, without reference to content. Thus when Deleuze and Guattari write of ‘less a matter submitted to the laws than a materiality *possessing* a *nomos/law*’, they appear not to be escaping ‘form’, but rather to be implicitly invoking the dialectical concept of content, as the unity of form and matter, through which a higher-level opposition to form is then reproduced. And when they write of ‘the existence, *between* form and matter, of a zone of medium and intermediary dimension’, they appear themselves to be precisely ‘taking form and matter to be two terms defined separately’ – the main problem with the hylomorphic model.

<a id="ch08-p024-zh"></a>
在这方面，黑格尔不只是超越了质料形式论模型中形式与质料的抽象对立，还辩证地把对质料形式论的非辩证批判纳入自己的形式概念。这并非暗示这里不再有由艺术形式的历史发展所提出的概念问题，但它确实重新安置了追求这些问题的哲学地形。这是阿多诺对黑格尔自身艺术哲学辩证缺陷进行内在批判的地形；在那里，一种特定的唯心主义形而上学非辩证地过度决定了艺术内容概念。<a id="ref-zh-ch08-29"></a>[29](#note-zh-ch08-29) 因为在黑格尔的艺术概念——理念的感性显现——中，一种预先规定的形而上学“内容”驱动着对其感性显现形式的推演，尽管这些形式与它存在辩证差异。然而，就社会形式而言，恰恰是这种形式规定过程描绘中的形而上学唯心主义，使黑格尔的逻辑适合在马克思《资本论》中呈现价值的社会形式——在那里，社会普遍性恰恰*只*出现在“异化的”、虚幻地自足的、观念的形式中：商品、货币、资本。正是这种*虚幻地自足的观念性*，使资本主义社会形式在结构上同构于自主艺术作品的存在论地位。

<a id="ch08-p024-en"></a>
In this regard, Hegel does not just move beyond the abstract opposition of form and matter in the hylomorphic model, but dialectically incorporates the undialectical critique of hylomorphism into his concept of form. This is not to suggest that there are no conceptual problems remaining here, posed by the historical development of artistic form, but it does relocate the philosophical terrain on which they are to be pursued. This is the terrain of Adorno’s immanent critique of the dialectical shortcomings of Hegel’s own philosophy of art, in which a particular idealist metaphysics undialectically overdetermines the notion of artistic content.<a id="ref-en-ch08-29"></a>[29](#note-en-ch08-29) For in Hegel’s concept of art as the sensuous semblance of the idea, a predetermined metaphysical ‘content’ drives the deduction of its sensuous forms of appearance, despite their dialectical difference from it. However, with regard to social form, it is precisely the metaphysical idealism of this depiction of the process of form-determination that makes Hegel’s logic appropriate for the presentation of the social form of value, in Marx’s *Capital*, wherein social universality appears, precisely, *only* in ‘alienated’ and illusorily self-sufficient, ideal forms: commodity, money, capital. It is this *illusorily self-sufficient ideality* that makes capitalistic social form structurally homologous to the ontological status of the autonomous artwork.

<a id="ch08-p025-zh"></a>
然而，如果黑格尔（大体主题性的）艺术内容概念背叛了其逻辑中形式—内容区分的更深辩证特征，那么阿多诺自己对艺术形式的呈现也被一种挥之不去的审美主义所背叛，其标志是他广泛使用“审美形式”（*ästhetische Form*）一语，而他自身文本的哲学语境要求继续使用他的“艺术形式”（*kunsterlich Form*）一语——尽管阿多诺认识到：“康德的美学没有强调性的艺术作品概念，而把它贬低为一种升华了的愉悦手段的层次”，即一种“被阉割的享乐主义，没有欲望的欲望”。<a id="ref-zh-ch08-30"></a>[30](#note-zh-ch08-30) 讽刺的是，正是把“审美的”一词用作“艺术的”同义词（黑格尔在其《美学讲演录》导论开篇首次注意到这一点，但随后又否认了它）所传播的挥之不去的混淆，损害了阿多诺《美学理论》中的若干表述。在阿多诺那里，黑格尔因此成为维护一种残余康德式审美主义的特洛伊木马，而这种审美主义在形式上仍被否认。这是把艺术作品主体中介的持久重要性同康德式“审美的”一词用法相混淆的后果。

<a id="ch08-p025-en"></a>
However, if Hegel’s (broadly thematic) conception of artistic content betrays the deeper dialectical character of the form–content distinction in his logic, Adorno’s own presentation of artistic form is itself betrayed by a lingering aestheticism, marked by his widespread use of the phrase ‘aesthetic form’ (*ästhetische Form*), when the philosophical context of his own text demands rather the continued use of his phrase ‘artistic form’ (*kunsterlich Form*) – and this, despite Adorno’s recognition of the fact that ‘Kant’s aesthetics had no emphatic concept of the artwork and relegated it to the level of a sublimated means of pleasure’, a ‘castrated hedonism, desire without desire’.<a id="ref-en-ch08-30"></a>[30](#note-en-ch08-30) Ironically, it is the lingering confusion spread by the use of the term ‘aesthetic’ as synonymous to ‘art’ (first noted but then disavowed by Hegel at the outset of the Introduction to his *Lectures on* *Beautiful Art*) that vitiates a number of formulations in Adorno’s *Aesthetic Theory*. In Adorno, Hegel thus comes to act as a Trojan Horse for the maintenance of a residual Kantian aestheticism that is nonetheless formally disavowed. This is a consequence of the conflation of the enduring importance of the subjective mediation of the artwork with a Kantian use of the term ‘aesthetic’.

<a id="ch08-p026-zh"></a>
因此，更新黑格尔—阿多诺问题所需的哲学步骤是：（i）用阿多诺更具历史具体性的内容概念取代黑格尔对艺术“内容”的理解，即把内容理解为*艺术材料*与*技术*之间的关系，并放在对形式—内容关系更充分辩证化的说明中；<a id="ref-zh-ch08-31"></a>[31](#note-zh-ch08-31) （ii）对阿多诺的艺术形式概念进行去审美化或概念扩展，使其与他自己的技术概念和艺术材料概念一致；因此（iii）更充分地理解艺术作品如何在内部中介*艺术制度*形式，以及最一般的社会形式——商品、货币、资本与国家——连同其他历史上既定并受争夺的文化形式，如性别、种族与性。

<a id="ch08-p026-en"></a>
The philosophical moves required to update the Hegel– Adorno problematic are thus (i) the replacement of Hegel’s understanding of the ‘content’ of art with Adorno’s more concretely historical conception of content as a relationship between *artistic materials* and *techniques*, within a more fully dialecticized account of form–content relations;<a id="ref-en-ch08-31"></a>[31](#note-en-ch08-31) (ii) the de-aestheticization or conceptual expansion of Adorno’s conception of artistic form, rendering it consistent with his own concepts of technique and artistic materials; and hence (iii) a greater sense of the ways in which the artwork internally mediates *art-institutional* forms, as well as the most general social forms of commodity, money, capital and the state, along with other historically received and contested cultural forms, such as gender, race and sexuality.

<a id="ch08-p027-zh"></a>
另一方面，在德勒兹与瓜塔里那里，沿着尼采的一条思想路线，形式问题被完全置换，代之以关于*力量*的话语，它以历史化的方式与艺术发生关系，如下：

<a id="ch08-p027-en"></a>
In Deleuze and Guattari, on the other hand, following one line of thought in Nietzsche, the problematic of form is displaced altogether, in favour of a discourse on *forces* that appears in a historicized manner in relation to art, as follows:

<a id="ch08-q009-zh"></a>
> 如果存在一个现代时期……［那么］本质关系不再是质料—形式（或实体—属性）；也不是形式的连续发展与质料的连续变化。现在它是*材料—力量*的直接关系。材料是一种分子化的质料，因此必须“驾驭”宇宙的力量。不再有找到其相应可理解性原则的质料。现在的问题在于加工出一种承担着驾驭另一层次之力量这一任务的材料：可见材料必须捕捉不可见的力量。……要被捕捉的力量是……一种非物质的、非形式的、能量的宇宙的力量。……这是后浪漫主义的转折点：本质的东西不再是形式与质料，或主题，而是力量、密度与强度。……问题……现在是一致性或巩固的问题：如何巩固材料，使之具有一致性，从而能够驾驭不可思考、不可见、无声的力量？<a id="ref-zh-ch08-32"></a>[32](#note-zh-ch08-32)

<a id="ch08-q009-en"></a>
> If there is a modern age … [t]he essential relation is no longer  matter-forms (or substances-attributes); neither is it the continuous  development of form and the continuous variation of matter. It is  now a direct relation *material-forces*. A material is a molecularized  matter, which must accordingly ‘harness’ forces of the Cosmos.  There is no longer a matter that finds its corresponding principle of  intelligibility. It is now a question of elaborating a material charged  with harnessing forces of a different order: the visible material must  capture nonvisible forces. … The forces to be captured are … the  forces of an immaterial, nonformal and energetic Cosmos. … This  is the postromantic turning point: the essential thing is no longer  forms and matters, or themes, but forces, densities and intensities.  … The problem is … now a problem of consistency or consolidation:  how to consolidate the material, make it consistent, so that it can  harness unthinkable, invisible, nonsonorous forces?<a id="ref-en-ch08-32"></a>[32](#note-en-ch08-32)

<a id="ch08-p028-zh"></a>
一致性确实是问题——但尼采式与西蒙东式框架都只能对此给出实证主义回应。因为这种普遍化的力量宇宙论对内在的艺术／非艺术关系漠不关心，而后者正是当代艺术在协商形式问题时的“生命”中心。德勒兹与瓜塔里反倒以*捕获*与*域化*的一般概念取代艺术形式那问题性地区分、自我封闭的功能。然而在特定艺术语境中，“一致性或巩固”问题——对他们而言，这取代了形式问题，作为统一性问题的变体——从另一视角看，似乎再一次恰恰是形式本身的问题，以作品被组织为连贯整体的面貌出现。

<a id="ch08-p028-en"></a>
Consistency is indeed the problem – but neither the Nietzschean nor the Simondonian framework can offer more than a positivistic response to this issue. For this generalized cosmology of forces is indifferent to the immanent art/non-art relation, which is at the centre of the ‘life’ of contemporary art in its negotiation of the problem of form. The problematically differentiating, self-enclosing function of artistic form is instead replaced by Deleuze and Guattari by general concepts of *capture* and *territorialization*. Yet in a specifically artistic context, the problem of ‘consistency or consolidation’ – which for them replaces the problem of form, as a variant of the problem of unity – appears from an alternative perspective to be, once again, precisely the problem of form itself, in the guise of the problem of the organization of a work into coherence.

<a id="ch08-s04-zh"></a>
## **接合、组织与连贯，或实在的自我限定性自我悬置**

<a id="ch08-s04-en"></a>
## **Articulation, organization and coherence, or,** **the self-limiting self-suspension of the real**

<a id="ch08-p029-zh"></a>
与“接合”并列，“连贯”（*Stimmigkeit*）是阿多诺《美学理论》中形式的主要范畴。“连贯”从整体一致性立场命名形式问题。<a id="ref-zh-ch08-33"></a>[33](#note-zh-ch08-33) “接合”（*Artikulation*）是从把作品诸要素组织为统一体的实践立场来看同一问题的名称。组织（*Organisation*），即“要素彼此之间的关系”，正是“构成形式”的东西。因此，形式可以被概括为“艺术作品中一切逻辑性要素、或更广泛地连贯［*Stimmigkeit*］的精粹”。<a id="ref-zh-ch08-34"></a>[34](#note-zh-ch08-34) 确实，说阿多诺认为艺术*就是*形式，并不为过。

<a id="ch08-p029-en"></a>
Alongside ‘articulation’, ‘coherence’ (*Stimmigkeit*) is the main category of form in Adorno’s *Aesthetic Theory*. ‘Coherence’ names the problem of form from the standpoint of the consistency of the whole.<a id="ref-en-ch08-33"></a>[33](#note-en-ch08-33) ‘Articulation’ (*Artikulation*) is the name of the same problem viewed from the practical standpoint of organizing the elements of the work into a unity. Organization (*Organisation*), ‘the relation of elements to each other’ is what ‘constitutes form’. Form may thus be summarized as ‘the quintessence of all elements of logicality, or more broadly, coherence [*Stimmigkeit*] in artworks’.<a id="ref-en-ch08-34"></a>[34](#note-en-ch08-34) Indeed, it is not going too far to suggest that for Adorno\*\*,\*\* art *is* form.

<a id="ch08-q010-zh"></a>
> 正如艺术不能由任何其他要素来定义，它也不能简单地等同于形式。在形式概念中，其他每个要素都可以被否定……

<a id="ch08-q010-en"></a>
> As little as art is to be defined by any other element, it is simply  identical with form. Every other element can be negated in the  concept of form…

<a id="ch08-q011-zh"></a>
> ［形式因此是］艺术的区分性方面……［它是］艺术作品中使它们成为艺术作品的东西。

<a id="ch08-q011-en"></a>
> [Form is thus] the distinguishing aspect of art… [it is] that in  artworks by which they become artworks.

<a id="ch08-q012-zh"></a>
> 艺术存活的机会与形式完全相同，并不更好。<a id="ref-zh-ch08-35"></a>[35](#note-zh-ch08-35)

<a id="ch08-q012-en"></a>
> Art has precisely the same chance of survival as does form, no  better.<a id="ref-en-ch08-35"></a>[35](#note-en-ch08-35)

<a id="ch08-p030-zh"></a>
原因在于，正是通过人工制品的形式或连贯，“每一件成功的作品*把自身从单纯存在者中分离出来*”。在从单纯存在者中分离出来时，“艺术通过形式要素［*Moment*］*对抗经验之物*［*der Empirie*］”，并由此在作品本身层面构成其“自主性”。在此过程中，形式表现为“对存在者进行变形的规律，与之相对，它代表自由”。<a id="ref-zh-ch08-36"></a>[36](#note-zh-ch08-36)

<a id="ch08-p030-en"></a>
The reason for this is that it is through the artefact’s form or coherence that ‘each and every successful work *separates itself* from the merely existing’. In separating itself from the merely existing, ‘art *opposes the empirical* [*der Empirie*] through the element [*Moment*] of form’ and thereby constitutes its ‘autonomy’ at the level of the work itself. In so doing form appears as ‘the law of the transfiguration of the existing, counter to which it represents freedom’.<a id="ref-en-ch08-36"></a>[36](#note-en-ch08-36)

<a id="ch08-p031-zh"></a>
然而，这种分离／对抗／变形*并不*被理解为某种先验审美主体性的行为，而是作品的“客观”品质。正是参照这一客观品质，阿多诺使用“审美的”一词。在这方面，据说作品在形式中“使自己从仅仅是主体性的产物中解放出来”。“在艺术作品中，形式本质上是审美的，就它是客观规定［*objective Bestimmung*］而言。”然而，外观仍不可消除地属于对审美之物的指涉：

<a id="ch08-p031-en"></a>
However, this separation/opposition/transfiguration is *not* understood to be the act of some transcendental aesthetic subjectivity, but is rather an ‘objective’ quality of the work. And it is with reference to this objective quality that Adorno uses the term ‘aesthetic’. In this regard, in form, the work is said to ‘free itself from being simply a product of subjectivity’. ‘In artworks, form is aesthetic essentially insofar as it is an objective determination [*objective Bestimmung*].’ Appearance, though, remains ineliminable from the reference to aesthetic:

<a id="ch08-q013-zh"></a>
> 审美形式是每件艺术作品内部对*显现为具有约束力的雄辩*之物的客观组织。<a id="ref-zh-ch08-37"></a>[37](#note-zh-ch08-37)

<a id="ch08-q013-en"></a>
> aesthetic form is the objective organization within each artwork of  *what appears* as *bindingly eloquent*.<a id="ref-en-ch08-37"></a>[37](#note-en-ch08-37)

<a id="ch08-p032-zh"></a>
那么，在那种“运动规律”或艺术的自我发展——对阿多诺而言，在最高层面上即艺术的“形式规律”——之中，材料扩展与形式限制之间的关系如何显现？首先：

<a id="ch08-p032-en"></a>
So, how does the relationship between the expansion of materials and formal limitation appear, in that ‘law of movement’ or self-development of art that is for Adorno, at the highest level, art’s ‘law of form’? In the first place:

<a id="ch08-q014-zh"></a>
> 形式不可避免地限定被赋形者，否则其概念将失去与被赋形者的特定差异。……赋形的艺术劳动始终是选择、修剪、放弃的过程。没有拒绝，就没有形式……<a id="ref-zh-ch08-38"></a>[38](#note-zh-ch08-38)

<a id="ch08-q014-en"></a>
> Form inevitably limits what is formed, for otherwise its concept  would lose its specific difference to what is formed. … the artistic  labour of forming is always a process of selecting, trimming,  renouncing. Without rejection there is no form…<a id="ref-en-ch08-38"></a>[38](#note-en-ch08-38)

<a id="ch08-p033-zh"></a>
这导向对形式的生机论反应。在这方面，“可用材料的扩展”（阿多诺认为它“被外行*大大高估了*”）“被艺术家因……所选［特定］材料的状况而必须作出的放弃所抵消”。

<a id="ch08-p033-en"></a>
This is what leads to the vitalist reaction against form. In this respect, ‘the expansion of available materials’ (which Adorno believed had ‘been *much overestimated* by those external to it’) ‘is offset by the renunciation demanded of the artist by … the condition of the [particular] material’ selected.

<a id="ch08-q015-zh"></a>
> 每一次材料向未知的创新性扩展，超越材料给定状况，在很大程度上都是材料及其批判的功能，而这种批判由材料自身所界定。<a id="ref-zh-ch08-39"></a>[39](#note-zh-ch08-39)

<a id="ch08-q015-en"></a>
> Every innovative expansion of the material into the unknown, going  beyond the material’s given condition, is to a large extent a function  of the material and its critique, which is defined by the material  itself.<a id="ref-en-ch08-39"></a>[39](#note-en-ch08-39)

<a id="ch08-p034-zh"></a>
因此，艺术材料的选择在此是决定因素。依照“黑格尔反对康德的论证”：“一旦设定界限，界限即被越过，而设立界限所针对的对立面也被吸收。”反过来，作为“被设定的统一体”，形式“不断把自身［*suspendiert sie*］作为这样的统一体悬置起来：其本质在于它*通过自己的他者*［它的材料］*中断自身*，正如其连贯性的本质在于它（最终）并不连贯”。<a id="ref-zh-ch08-40"></a>[40](#note-zh-ch08-40) 否则它就会与现实达成和解，并因此变成对现实的肯定。

<a id="ch08-p034-en"></a>
Selection of artistic materials is thus the determining factor here. In accordance with ‘the Hegelian argument against Kant’: ‘The moment a limit is posited, it is overstepped and that against which the limit was established is absorbed.’ Conversely, as a ‘posited unity’, form ‘constantly suspends itself [*suspendiert sie*] as such: essential to it is that it *interrupts itself through its other* [its materials] just as the essence of its coherence is that it does not [ultimately] cohere’.<a id="ref-en-ch08-40"></a>[40](#note-en-ch08-40) Otherwise it would as reconciled to, and hence become affirmative of, actuality.

<a id="ch08-p035-zh"></a>
因此，艺术形式概念扩展之限定问题，归根结底不是艺术材料扩展的*范围*问题，也不是这种扩展范围存在某种*先天界限*的问题。就艺术本身而言，这种扩展原则上已经是无限的，但当然不适用于任何特定单件作品。问题毋宁是：个别作品对存在者一部分之“经验现实”所施行的*自我限定性悬置的诸模式*——封闭这一部分，使其脱离功能语境，组织或重新组织它，并把它设定为艺术反思的对象；随后，又部分地悬置这一悬置。这是一种自我限定性的悬置；由于“形式与内容的中介要求我们把审美［＝艺术］形式认作沉积［*sedimentierter*］的内容”，<a id="ref-zh-ch08-41"></a>[41](#note-zh-ch08-41) 它以社会形式为其内在“内容”。在此，在社会形式层面，可能艺术材料的无限扩展——它使每一次艺术材料的选择都成为自由行为——模仿资本积累的无限自我设定结构（无限生产力）。正如自主艺术作品作为自我规定形式（一个表现得像主体一样行动的客体）的主体般品质，既模仿自我占有的资产阶级个体之自由的幻想，也模仿资本“自动主体”的现实。它这样做，不是直接地或无中介地，而是在每一情形中通过其自身被中介之客观性的异化形式；模仿价值与文化之社会形式——商品、货币、资本、国家、性别、种族、性——之客观结构的异化普遍性……

<a id="ch08-p035-en"></a>
The question of the delimitation of the expansion of the concept of artistic form is thus not, after all, a question of the *extent* of the expansion of artistic materials, or the existence of some *a priori limit* to the extent of that expansion. The expansion is in principle infinite for art as such, already, but not of course for any particular individual work. The question is rather that of the *modes of the self-limiting suspension* of the ‘empirical reality’ of a portion of what exists, performed by individual works, closing this portion off from its functional context, organizing or reorganizing it, and positing it as an object of artistic reflection; then, in part, suspending that suspension. This is a self-limiting suspension which – in so far as ‘the mediation of form and content demands that we recognize aesthetic [=artistic] form as sedimented [*sedimentierter*] content’<a id="ref-en-ch08-41"></a>[41](#note-en-ch08-41) – requires social form as its immanent ‘content’. Here, at the level of social form, the expansion to infinity of possible artistic materials, which makes every selection of artistic materials into an act of freedom, mimics the self-positing structure of infinity of the accumulation of capital (infinite productivity). Just as the subject-like quality of the autonomous artwork as a self-determining form (an object that presents itself as behaving like a subject) mimics both the fantasy of the freedom of the self-possessing bourgeois individual and the actuality of the ‘automatic subject’ of capital alike. And it does so, not directly, or immediately, but, in each case, via the alienated form of its own mediated objectivity; mimicking the alienated universality of the objective structures of the social forms of value and culture – commodity, money, capital, state, gender, race, sexuality…

<a id="ch08-p036-zh"></a>
就社会性显现为形式而言，它只有一种异化的客观性。

<a id="ch08-p036-en"></a>
In so far as sociality appears as form, it has only an alienated objectivity.

<a id="ch08-p037-zh"></a>
因此，这里的问题较少是一个“社会学”问题，即自主艺术通过其商品形式（矛盾的艺术商品）内在于资本主义社会结构；更不是艺术再现与资本主义在主题层面的任何关系；而远为更多地是资本主义社会的结构与过程内在于自主艺术*作为自主的*；也就是说，不是在其依赖性的或他律的维度（如通常所设想），而是在其自主性本身之中。

<a id="ch08-p037-en"></a>
The issue here is thus less the ‘sociological’ one of the internality of autonomous art to the structures of capitalist societies, via its commodity form (the contradictory art commodity); still less any relationship of artistic representation to capitalism, at a thematic level; and far more the internality of the structures and processes of capitalist societies to autonomous art, *qua autonomous*; that is, not in its dependent or heteronomous dimension (as is usually supposed), but in its very autonomy itself.

<a id="ch08-s05-zh"></a>
## **危机作为形式**

<a id="ch08-s05-en"></a>
## **Crisis as form**

<a id="ch08-p038-zh"></a>
正是在这种结构性的历史内在性中，“危机”显现为形式：作为艺术自主性之矛盾社会形式的特定历史实例化，被推到看似无法解决的对抗或二律背反的地步。因为危机，就其正在“永久化”而言，是资本主义社会性本身的一种新形式。危机概念的核心部分——作为过渡过程中的决断时刻（在其极限处，在其医学起源中，是疾病中从生到死的过渡过程）——在于它不可能是永久的。那么，日益被称为“永久危机”的东西，在技术上已不再是危机，而是一种新的、可怕的社会再生产形式——一种以系统性断裂的时间性为基础的社会再生产形式，这种时间性是资本“全球化”所生产的历史同时代性的时间形式的一部分。<a id="ref-zh-ch08-42"></a>[42](#note-zh-ch08-42) 资本主义危机始终是社会自身一致性或连贯性的危机。批判意义上的当代艺术，就是这种情境的艺术。

<a id="ch08-p038-en"></a>
It is within this structural historical immanence that ‘crisis’ appears as form: as a particular historical instantiation of the contradictory social form of art’s autonomy, pushed to the point of a seemingly irresolvable antagonism or antinomy. For crisis, in so far as it is becoming ‘permanent’, is a new form of capitalistic sociality as such. It is part of the core of the concept of crisis, as a moment of decision within a transitional process (at its limit, in its medical origin, a transitional process within illness from life to death), that it cannot be permanent. What is increasingly referred to as ‘permanent crisis’, then, is no longer technically a crisis, but a new and terrible form of social reproduction – a form of social reproduction grounded in the temporality of systemic disjunction that is part of the temporal form of historical contemporaneity produced by the ‘globalization’ of capital.<a id="ref-en-ch08-42"></a>[42](#note-en-ch08-42) Capitalist crisis is always a crisis in the consistency or coherence of the social itself. Contemporary art, in the critical sense of that term, is the art of such a situation.

<a id="ch08-p039-zh"></a>
简言之，危机是社会的一种新的一般形式。它由那种以形式危机为形式的艺术危机所表达。形式危机是当代艺术的首要形式规定。每一件个别作品都参与这一表达，就它施行或中介形式问题、使之成为实在之自我限定性悬置的问题而言。

<a id="ch08-p039-en"></a>
In brief, then, crisis is a new general form of the social. It is expressed by that crisis of art that takes the form of a crisis of form. Crisis of form is the primary form-determination of contemporary art. Each individual work participates in that expression to the extent to which it enacts, or mediates, the problem of form as the problem of the self-limiting suspension of the real.

### 原注

<a id="ch08-n001-zh"></a><a id="note-zh-ch08-1"></a>
[1] 本文部分内容的较早版本曾于2017年1月12日在伦敦艺术大学切尔西艺术学院公开演讲，2017年1月27日在维也纳应用艺术大学“危机作为形式：对当下历史的重写”会议，以及2017年10月2日在耶鲁大学艺术学院演讲。感谢赫尔穆特·德拉克斯勒邀请我参加维也纳会议。 [返回](#ref-zh-ch08-1)

<a id="ch08-n001-en"></a><a id="note-en-ch08-1"></a>
[1] An earlier version of parts of this text was presented as a public lecture at Chelsea College of Arts, University of the Arts London (12 January 2017), to the conference ‘Crisis as Form: Revisions to the History of the Present’, University of Applied Arts Vienna (27 January 2017) and at Yale University School of Art (2 October 2017). I am grateful to Helmut Draxler for the invitation to the Vienna conference. [返回](#ref-en-ch08-1)

<a id="ch08-n002-zh"></a><a id="note-zh-ch08-2"></a>
[2] Theodor W. Adorno, *Aesthetic Theory*, trans. Robert Hullot-Kentor, Minneapolis: Minnesota University Press, 1997 (1970), p. 6。 [返回](#ref-zh-ch08-2)

<a id="ch08-n002-en"></a><a id="note-en-ch08-2"></a>
[2] Theodor W. Adorno, *Aesthetic Theory*, trans. Robert Hullot-Kentor, Minneapolis: Minnesota University Press, 1997 (1970), p. 6. [返回](#ref-en-ch08-2)

<a id="ch08-n003-zh"></a><a id="note-zh-ch08-3"></a>
[3] 也就是说，当代艺术是在过去约二十五年中该短语所获得的批判性历史意义上说的，这一意义可以在解释上大致追溯至1950年代末的艺术转变。见 Peter Osborne, *Anywhere or Not At All: Philosophy of Contemporary Art*, London and New York: Verso, 2013, pp. 18–22。 [返回](#ref-zh-ch08-3)

<a id="ch08-n003-en"></a><a id="note-en-ch08-3"></a>
[3] Contemporary art, that is, in the critical historical sense which that phrase has come to acquire over the last twenty-five years or so, which may be projected back, interpretatively, broadly speaking, to artistic transformations of the late 1950s. See Peter Osborne, *Anywhere or Not At All: Philosophy of Contemporary Art*, London and New York: Verso, 2013, pp. 18–22. [返回](#ref-en-ch08-3)

<a id="ch08-n004-zh"></a><a id="note-zh-ch08-4"></a>
[4] Adorno, *Aesthetic Theory*, pp. 42, 199–202, 219–22。当然，这一倾向如今已通过西方艺术体系的“全球化”在地缘政治上普遍化，而不论这一制度体系侵入的资本主义社会有何特定“种类”。正是在这一点上，跨国艺术机构处于资本主义“新自由主义化”形式地缘政治扩张的前锋，不论其所展示特定作品的意识形态内容。 [返回](#ref-zh-ch08-4)

<a id="ch08-n004-en"></a><a id="note-en-ch08-4"></a>
[4] Adorno, *Aesthetic Theory*, pp. 42, 199–202, 219–22. This tendency has now, of course, been geopolitically generalized via the ‘globalization’ of the Western art system, irrespective of the particular ‘varieties’ of capitalist societies into which this system of institutions intrudes. This is the respect in which transnational art institutions are at the vanguard of the geopolitical spread of ‘neoliberalized’ forms of capitalism, irrespective of the ideological content of the particular works they exhibit. [返回](#ref-en-ch08-4)

<a id="ch08-n005-zh"></a><a id="note-zh-ch08-5"></a>
[5] 见 David Joselit, *After Art*, Princeton NJ and Oxford: Princeton University Press, 2013。乔塞利特以实证主义而非批判的方式对待这一还原，从而退出了艺术批评的领域。 [返回](#ref-zh-ch08-5)

<a id="ch08-n005-en"></a><a id="note-en-ch08-5"></a>
[5] See David Joselit, *After Art*, Princeton NJ and Oxford: Princeton University Press, 2013. Joselit treats this reduction positivistically, rather than critically, thereby exiting the field of art criticism. [返回](#ref-en-ch08-5)

<a id="ch08-n006-zh"></a><a id="note-zh-ch08-6"></a>
[6] 1990年代以来这些连续不断的社会、政治与行动主义“转向”，重复了可追溯至1960年代的各种反制度艺术实践的结构。差别主要在于晚近变体在制度上被承认的更为普遍的盛行。 [返回](#ref-zh-ch08-6)

<a id="ch08-n006-en"></a><a id="note-en-ch08-6"></a>
[6] These successive social, political and activist ‘turns’ since the 1990s repeat the structures of various anti-institutional artistic practices that can be traced back to the 1960s. The difference primarily lies in the more general, institutionally recognized prevalence of the more recent variants. [返回](#ref-en-ch08-6)

<a id="ch08-n007-zh"></a><a id="note-zh-ch08-7"></a>
[7] 关于艺术对其被司汤达视为“幸福承诺”的打破，见 Adorno, *Aesthetic Theory*, p. 311。 [返回](#ref-zh-ch08-7)

<a id="ch08-n007-en"></a><a id="note-en-ch08-7"></a>
[7] On art’s breaking of what Stendhal saw as its ‘promise of happiness’, see Adorno, *Aesthetic Theory*, p. 311. [返回](#ref-en-ch08-7)

<a id="ch08-n008-zh"></a><a id="note-zh-ch08-8"></a>
[8] 参见本雅明论波德莱尔作为“其阶级对其自身统治的秘密不满的代理人”，见 Walter Benjamin, Addendum to ‘The Paris of the Second Empire in Baudelaire’, in *Charles Baudelaire: A Lyric Poet in the Era of High Capitalism*, London and New York: Verso, 1989, p. 104。 [返回](#ref-zh-ch08-8)

<a id="ch08-n008-en"></a><a id="note-en-ch08-8"></a>
[8] Cf. Benjamin on Baudelaire as the ‘agent of a secret discontent of his class with its own rule’, in Walter Benjamin, Addendum to ‘The Paris of the Second Empire in Baudelaire’, in *Charles Baudelaire: A Lyric Poet in the Era of High Capitalism*, London and New York: Verso, 1989, p. 104. [返回](#ref-en-ch08-8)

<a id="ch08-n009-zh"></a><a id="note-zh-ch08-9"></a>
[9] Wolfgang Streeck, *How Will Capitalism End? Essays on a Failing System*, London and New York: Verso, 2016; F.A. Hayek, *Road to Serfdom*, London and New York: Routledge, 2001 (1944); Karl Polanyi, *The Great Transformation: The Political and Economic Origins of our Time*, Boston MA: Beacon Press, 2002 (1944)。有趣的是，晚近关于新自由主义与当代资本主义含义的争论，默认重演了1940年代两位奥地利经济史学家之间的争论——其时正值西方资本主义社会战后重建的前夕。关于波兰尼式分析的复兴，见 Nancy Fraser, ‘Marketization, Social Protection, Emancipation: Toward a Neo-Polanyian Conception of Capitalist Crisis’, in Craig Calhoun and Georgi Derlugian, eds, *Business as Usual: The Roots of the Global Financial Meltdown*, New York: NYU Press, 2011, pp. 137–58, and ‘A Triple Movement? Parsing the Politics of Crisis after Polanyi’, *New Left Review* 81 (May–June 2013), pp. 119–32。 [返回](#ref-zh-ch08-9)

<a id="ch08-n009-en"></a><a id="note-en-ch08-9"></a>
[9] Wolfgang Streeck, *How Will Capitalism End? Essays on a Failing System*, London and New York: Verso, 2016; F.A. Hayek, *Road to Serfdom*, London and New York: Routledge, 2001 (1944); Karl Polanyi, *The Great Transformation: The Political and Economic Origins* *of our Time*, Boston MA: Beacon Press, 2002 (1944). Intriguingly, recent disputes over neoliberalism and the meaning of contemporary capitalism have defaulted to a replay of a dispute between two Austrian economic historians of the 1940s, on the cusp of the post-war reconstruction of Western capitalist societies. For the revival of Polanyian analyses, see Nancy Fraser, ‘Marketization, Social Protection, Emancipation: Toward a Neo-Polanyian Conception of Capitalist Crisis’, in Craig Calhoun and Georgi Derlugian, eds, *Business as Usual: The Roots of the Global Financial Meltdown*, New York: NYU Press, 2011, pp. 137–58, and ‘A Triple Movement? Parsing the Politics of Crisis after Polanyi’, *New* *Left Review* 81 (May–June 2013), pp. 119–32. [返回](#ref-en-ch08-9)

<a id="ch08-n010-zh"></a><a id="note-zh-ch08-10"></a>
[10] Jack Burnham, *Beyond Modern Sculpture: The Effects of Science and Technology on the Sculpture of This Century*, New York: George Braziller, 1967, pp. 167–81。 [返回](#ref-zh-ch08-10)

<a id="ch08-n010-en"></a><a id="note-en-ch08-10"></a>
[10] Jack Burnham, *Beyond Modern Sculpture: The Effects of Science and Technology on* *the Sculpture of This Century,* New York: George Braziller, 1967, pp. 167–81. [返回](#ref-en-ch08-10)

<a id="ch08-n011-zh"></a><a id="note-zh-ch08-11"></a>
[11] Robert Smithson, ‘What is a Museum? A Conversation between Allan Kaprow and Robert Smithson’ (1967), in *Robert Smithson: The Collected Writings*, Berkeley: University of California Press, 1996, p. 40。参见 Peter Osborne, *Anywhere or Not At All*, ch. 4。 [返回](#ref-zh-ch08-11)

<a id="ch08-n011-en"></a><a id="note-en-ch08-11"></a>
[11] Robert Smithson, ‘What is a Museum? A Conversation between Allan Kaprow and Robert Smithson’ (1967), in *Robert Smithson: The Collected Writings*, Berkeley: University of California Press, 1996, p. 40. Cf. Peter Osborne, *Anywhere or Not At All*, ch. 4. [返回](#ref-en-ch08-11)

<a id="ch08-n012-zh"></a><a id="note-zh-ch08-12"></a>
[12] Victor Burgin, ‘Situational Aesthetics’, *Studio International*, vol. 178, no. 915 (October 1969), pp. 118–21; Joseph Kosuth, ‘Art and Philosophy: Part 1’, ibid., pp. 134–7。 [返回](#ref-zh-ch08-12)

<a id="ch08-n012-en"></a><a id="note-en-ch08-12"></a>
[12] Victor Burgin, ‘Situational Aesthetics’, *Studio International*, vol. 178, no. 915 (October 1969), pp. 118–21; Joseph Kosuth, ‘Art and Philosophy: Part 1’, ibid., pp. 134–7. [返回](#ref-en-ch08-12)

<a id="ch08-n013-zh"></a><a id="note-zh-ch08-13"></a>
[13] 这些历史主义的新观念主义（例如英国 Simon Paterson、Gavin Turk、Martin Creed，以及最简化意义上的 Jonathan Monk）原则上应区别于当代艺术最普遍的后观念特征。 [返回](#ref-zh-ch08-13)

<a id="ch08-n013-en"></a><a id="note-en-ch08-13"></a>
[13] These historicist neo-conceptualisms (of, for example, in the UK, Simon Paterson, Gavin Turk, Martin Creed and, most reductively, Jonathan Monk) should be distinguished, in principle, from the most general postconceptual character of contemporary art. [返回](#ref-en-ch08-13)

<a id="ch08-n014-zh"></a><a id="note-zh-ch08-14"></a>
[14] 1960年代末的西欧，这一观念主要与约瑟夫·博伊斯以及一个以维也纳—科隆—杜塞尔多夫三角为中心、由期刊《Interfunctionen》推动的艺术家群体相关。见 Friedrich W. Heubach, ‘Interfunctionen, 1968–1975’, in Gloria Moure, ed., *Behind the Facts: Interfunctionen, 1968–1975*, Barcelona: Ediciones Polígrafa, 2004, pp. 48–59。关于东欧的情况，见 Klara Kemp-Welch, *Networking the Block: Experimental Art in Eastern Europe, 1965–1981*, Cambridge MA and London: MIT Press, 2018。 [返回](#ref-zh-ch08-14)

<a id="ch08-n014-en"></a><a id="note-en-ch08-14"></a>
[14] In Western Europe in the late 1960s this idea was mainly associated with Joseph Beuys and a group of artists centred on the triangle Vienna–Cologne–Düsseldorf, promoted by the journal *Interfunctionen*. See Friedrich W. Heubach, ‘Interfunctionen, 1968–1975’, in Gloria Moure, ed., *Behind the Facts: Interfunctionen, 1968–1975*, Barcelona: Ediciones Polígrafa, 2004, pp. 48–59. For the Eastern European story, see Klara Kemp-Welch, *Networking the Block: Experimental Art in Eastern Europe, 1965–1981*, Cambridge MA and London: MIT Press, 2018. [返回](#ref-en-ch08-14)

<a id="ch08-n015-zh"></a><a id="note-zh-ch08-15"></a>
[15] Rosalind E. Krauss, ‘Sculpture in the Expanded Field’ (1979), in *The Originality of the Avant-Garde and Other Modernist Myths*, Cambridge MA and London: MIT Press, 1985, pp. 276–90。 [返回](#ref-zh-ch08-15)

<a id="ch08-n015-en"></a><a id="note-en-ch08-15"></a>
[15] Rosalind E. Krauss, ‘Sculpture in the Expanded Field’ (1979), in *The Originality of the* *Avant-Garde and Other Modernist Myths*, Cambridge MA and London: MIT Press, 1985, pp. 276–90. [返回](#ref-en-ch08-15)

<a id="ch08-n016-zh"></a><a id="note-zh-ch08-16"></a>
[16] 值得注意的是，当泽曼的展览2013年在威尼斯普拉达基金会重演时，不仅原主标题消失了（《Live in Your Head》也许太有1960年代反文化色彩），副标题其余部分也消失了，从而抹除了展览据以建构、并赋予其内在动力的概念星丛的诸极端。 [返回](#ref-zh-ch08-16)

<a id="ch08-n016-en"></a><a id="note-en-ch08-16"></a>
[16] It is significant that when Szeeman’s show was restaged at the Prada Foundation in Venice in 2013, not only had the main title of the original disappeared (*Live in Your Head* was too counterculturally 1960s perhaps), but the rest of the subtitle has disappeared too, thereby eliminating the extremes of the conceptual constellation across which the exhibition had been constructed, and which provided it with its internal dynamism. [返回](#ref-en-ch08-16)

<a id="ch08-n017-zh"></a><a id="note-zh-ch08-17"></a>
[17] 《纬度如何成为形式：全球化时代的艺术》（2003）是明尼阿波利斯沃克中心在2000年全球观念主义展览之后举办的展览；《历史成为形式》（2010）概括了鲍里斯·格罗伊斯对莫斯科观念主义的分析；纳托·汤普森的《生活作为形式》（2012）是日常性艺术行动主义的口号。 [返回](#ref-zh-ch08-17)

<a id="ch08-n017-en"></a><a id="note-en-ch08-17"></a>
[17] *How Latitudes Become Form: Art in a Global Age* (2003) was an exhibition in the Walker Center, Minneapolis, held in the wake of the 2000 Global Conceptualism show; *History* *Becomes Form* (2010) sums up Boris Groys’s analysis of Moscow Conceptualism; Nato Thompson’s *Living* *as Form* (2012) is the slogan of an art activism of the everyday. [返回](#ref-en-ch08-17)

<a id="ch08-n018-zh"></a><a id="note-zh-ch08-18"></a>
[18] 《当展览成为形式：艺术家—策展人的兴起》现为菲利波维奇为《Mousse Magazine》编辑的系列。这种以“策展人—艺术家”为中心的形式生产概念，似乎是对以下批判性认识的否认：形式规定原则的位置不能在艺术家的主体性中找到，而是分布在整个艺术生产过程之中，并凝结为作品自身的结构逻辑或连贯性。把艺术家作为创造性形式之主观起源的旧神话移置到策展人身上，在此表现为一种双重反动的举动。关于更广泛的展览研究路径，见《Afterall》杂志2010—2020年出版的“展览史”系列丛书。 [返回](#ref-zh-ch08-18)

<a id="ch08-n018-en"></a><a id="note-en-ch08-18"></a>
[18] W*hen Exhibitions Become Form: The Rise of the Artist-Curator* is now a series edited by Filipovic for *Mousse Magazine*. This ‘curator-artist’-centric conception of form-production appears as a disavowal of the critical recognition that the location of the principle of form-determination cannot be found in the subjectivity of the artist, but is rather distributed across the process of artistic production as a whole and condensed into the structural logic or coherence of the work itself. Transposing the old myth of the artist as the subjective origin of creative form onto the curator appears here as a doubly reactionary move. For a broader approach to exhibitions, see the Exhibition Histories series of books published by the journal *Afterall,* 2010–20. [返回](#ref-en-ch08-18)

<a id="ch08-n019-zh"></a><a id="note-zh-ch08-19"></a>
[19] “客观逻辑”，黑格尔论证说，“最直接地取代了存在论”，尽管“它自身也包含形而上学的其余部分”。另一方面，主观逻辑、即概念的逻辑，把客观逻辑中呈现的规定“按其特定内容在自身之中”接纳，并把它们阐述为“某种主观的、自由自存并自我规定的东西”。黑格尔的辩证逻辑由此把存在论转化为第一种历史存在论：精神（*Geist*）的历史存在论。Georg Wilhelm Friedrich Hegel, *The Science of Logic*, trans. George Di Giovanni, Cambridge: Cambridge University Press, 2010, p. 42。 [返回](#ref-zh-ch08-19)

<a id="ch08-n019-en"></a><a id="note-en-ch08-19"></a>
[19] ‘Objective logic’, Hegel argued, ‘most directly replaces ontology’, although ‘it comprises within itself also the rest of metaphysics’. Subjective logic, on the other hand, the logic of the concept, takes up the determinations presented in the objective logic ‘in themselves according to their particular content’, and expounds them as ‘something subjective, freely self-subsisting, self-determining’. Thus was ontology transformed by Hegel’s dialectical logic into the first historical ontology: a historical ontology of spirit (*Geist*). Georg Wilhelm Friedrich Hegel, *The Science of Logic*, trans. George Di Giovanni, Cambridge: Cambridge University Press, 2010, p. 42. [返回](#ref-en-ch08-19)

<a id="ch08-n020-zh"></a><a id="note-zh-ch08-20"></a>
[20] 见 Aristotle, *Metaphysics*; *Physics*, Book II, ch. 7。关于亚里士多德形而上学与物理学中形式定义之存在论一致性（或不一致性）的争论，不影响该概念的基本质料—形式结构。 [返回](#ref-zh-ch08-20)

<a id="ch08-n020-en"></a><a id="note-en-ch08-20"></a>
[20] See Aristotle, *Metaphysics*; *Physics*, Book II, ch. 7. The debates regarding the ontological consistency, or otherwise, of the definitions of form in Aristotle’s metaphysics and physics do not bear on the basic hylomorphic structure of the concept. [返回](#ref-en-ch08-20)

<a id="ch08-n021-zh"></a><a id="note-zh-ch08-21"></a>
[21] 见 Gilbert Simondon, *L’individu et sa genèse physico-biologique*, Paris: PUF, 1964, ch. 1; Muriel Combes, *Gilbert Simondon and the Philosophy of the Transindividual*, Cambridge MA and London: MIT Press, 2013。 [返回](#ref-zh-ch08-21)

<a id="ch08-n021-en"></a><a id="note-en-ch08-21"></a>
[21] See Gilbert Simondon\*, L’individual et sa genèse physico-biologique\*, Paris: PUF, 1964, ch. 1; Muriel Combes, *Gilbert Simondon and the Philosophy of the Transindividual*, Cambridge MA and London: MIT Press, 2013. [返回](#ref-en-ch08-21)

<a id="ch08-n022-zh"></a><a id="note-zh-ch08-22"></a>
[22] Gilles Deleuze and Félix Guattari, *A Thousand Plateaus: Capitalism and Schitzophrenia*, trans. Brian Massumi, Minneapolis: University of Minnesota Press, 1987, pp. 408–9。 [返回](#ref-zh-ch08-22)

<a id="ch08-n022-en"></a><a id="note-en-ch08-22"></a>
[22] Gilles Deleuze and Félix Guattari, *A Thousand Plateaus: Capitalism and* *Schitzophrenia,* trans. Brian Massumi, Minneapolis: University of Minnesota Press, 1987, pp. 408–9. [返回](#ref-en-ch08-22)

<a id="ch08-n023-zh"></a><a id="note-zh-ch08-23"></a>
[23] Hegel, *Science of Logic*, pp. 448–9。 [返回](#ref-zh-ch08-23)

<a id="ch08-n023-en"></a><a id="note-en-ch08-23"></a>
[23] Hegel, *Science of Logic*, pp. 448–9. [返回](#ref-en-ch08-23)

<a id="ch08-n024-zh"></a><a id="note-zh-ch08-24"></a>
[24] 同上，第447—450页。 [返回](#ref-zh-ch08-24)

<a id="ch08-n024-en"></a><a id="note-en-ch08-24"></a>
[24] Ibid., pp. 447–50. [返回](#ref-en-ch08-24)

<a id="ch08-n025-zh"></a><a id="note-zh-ch08-25"></a>
[25] 同上，第455页。 [返回](#ref-zh-ch08-25)

<a id="ch08-n025-en"></a><a id="note-en-ch08-25"></a>
[25] Ibid., p. 455. [返回](#ref-en-ch08-25)

<a id="ch08-n026-zh"></a><a id="note-zh-ch08-26"></a>
[26] G.W.F. Hegel, *The Encyclopaedia Logic*, trans. T.F. Geraets, W.A. Suchting and H.S. Harris, Indianapolis and Cambridge: Hackett, 1991, # 133, p. 202。关于形式作为内容的反思规定，参见 Georg Lukács, *The Ontology of Social Being: Hegel’s False and His Genuine Ontology*, trans. David Fernbach, London: Merlin Press, 1978, pp. 93–4。 [返回](#ref-zh-ch08-26)

<a id="ch08-n026-en"></a><a id="note-en-ch08-26"></a>
[26] G.W.F. Hegel, *The Encyclopaedia Logic*, trans. T.F. Geraets, W.A. Suchting and H.S. Harris, Indianapolis and Cambridge: Hacking, 1991, # 133, p. 202. For form as a reflection determination of content, cf. Georg Lukács, *The Ontology of Social Being: Hegel’s False* *and His Genuine Ontology*, trans. David Fernbach, London: Merlin Press, 1978, pp. 93–4. [返回](#ref-en-ch08-26)

<a id="ch08-n027-zh"></a><a id="note-zh-ch08-27"></a>
[27] Hegel, 同上，# 147, p. 220。 [返回](#ref-zh-ch08-27)

<a id="ch08-n027-en"></a><a id="note-en-ch08-27"></a>
[27] Hegel, ibid., # 147, p. 220. [返回](#ref-en-ch08-27)

<a id="ch08-n028-zh"></a><a id="note-zh-ch08-28"></a>
[28] Adorno, *Aesthetic Theory*, p. 3。 [返回](#ref-zh-ch08-28)

<a id="ch08-n028-en"></a><a id="note-en-ch08-28"></a>
[28] Adorno, *Aesthetic Theory*, p. 3. [返回](#ref-en-ch08-28)

<a id="ch08-n029-zh"></a><a id="note-zh-ch08-29"></a>
[29] 见 *Aesthetic Theory*, pp. 352ff。 [返回](#ref-zh-ch08-29)

<a id="ch08-n029-en"></a><a id="note-en-ch08-29"></a>
[29] See *Aesthetic Theory*, pp. 352ff. [返回](#ref-en-ch08-29)

<a id="ch08-n030-zh"></a><a id="note-zh-ch08-30"></a>
[30] *Aesthetic Theory*, pp. 253, 11。 [返回](#ref-zh-ch08-30)

<a id="ch08-n030-en"></a><a id="note-en-ch08-30"></a>
[30] *Aesthetic Theory*, pp. 253, 11. [返回](#ref-en-ch08-30)

<a id="ch08-n031-zh"></a><a id="note-zh-ch08-31"></a>
[31] 参见本雅明的评论：技术是“形式与内容那无成果的对立得以被超越的关节点”。“The Author as Producer” (1934), in *Selected Writings*, Volume 2: *1927–1934*, ed. Michael W. Jennings, Howard Eiland and Gary Smith, Cambridge MA and London: Belknap Press of Harvard University Press, 1999, p. 777。 [返回](#ref-zh-ch08-31)

<a id="ch08-n031-en"></a><a id="note-en-ch08-31"></a>
[31] Cf. Walter Benjamin’s remark that technique is ‘the point at which the unfruitful antithesis of form and content can be surpassed’. ‘The Author as Producer’ (1934), in *Selected Writings*, Volume 2: *1927–1934*, ed. Michael W. Jennings, Howard Eiland and Gary Smith, Cambridge MA and London: Belknap Press of Harvard University Press, 1999, p. 777. [返回](#ref-en-ch08-31)

<a id="ch08-n032-zh"></a><a id="note-zh-ch08-32"></a>
[32] *A Thousand Plateaus*, pp. 342–3。关于这一轨迹晚近的一次西蒙东式发展（涉及音乐表演），见 Paulo de Assis, ‘Transduction and Ensembles of Transducers: Relaying Flows of Intensities’, in Michael Schwab, ed., *Transpositions: Aesthetico-Epistemic Operators in Artistic Research*, Leuven: Orpheus Institute, Ghent/Leuven University Press, 2018, pp. 245–65。 [返回](#ref-zh-ch08-32)

<a id="ch08-n032-en"></a><a id="note-en-ch08-32"></a>
[32] *A* *Thousand Plateaus,* pp. 342–3. For a recent Simondonian development of this trajectory, with reference to musical performance, see Paulo de Assis, ‘Transduction and Ensembles of Transducers: Relaying Flows of Intensities’, in Michael Schwab, ed., *Transpositions: Aesthetico-Epistemic Operators in Artistic Research*, Leuven: Orpheus Institute, Ghent/Leuven University Press, 2018, pp. 245–65. [返回](#ref-en-ch08-32)

<a id="ch08-n033-zh"></a><a id="note-zh-ch08-33"></a>
[33] *Stimmigkeit*在《美学理论》第一个英译本中被译为“consistency”（一致性）；在第二个英译本中译为“coherence”（连贯性）。人们可以说，沿用蒯因的说法，连贯性不过是整体层面的一致性。 [返回](#ref-zh-ch08-33)

<a id="ch08-n033-en"></a><a id="note-en-ch08-33"></a>
[33] *Stimmigkeit* was rendered as ‘consistency’ in the first English translation of *Aesthetic* *Theory*; ‘coherence’ in the second. Coherence one might say, following Quine, is simply consistency at the level of the whole. [返回](#ref-en-ch08-33)

<a id="ch08-n034-zh"></a><a id="note-zh-ch08-34"></a>
[34] *Aesthetic Theory*, pp. 143, 140。 [返回](#ref-zh-ch08-34)

<a id="ch08-n034-en"></a><a id="note-en-ch08-34"></a>
[34] *Aesthetic Theory*, pp. 143, 140. [返回](#ref-en-ch08-34)

<a id="ch08-n035-zh"></a><a id="note-zh-ch08-35"></a>
[35] 同上，第140、144、141页。 [返回](#ref-zh-ch08-35)

<a id="ch08-n035-en"></a><a id="note-en-ch08-35"></a>
[35] Ibid., pp. 140, 144, 141. [返回](#ref-en-ch08-35)

<a id="ch08-n036-zh"></a><a id="note-zh-ch08-36"></a>
[36] 同上，第142、5、143页，着重号为引者所加。 [返回](#ref-zh-ch08-36)

<a id="ch08-n036-en"></a><a id="note-en-ch08-36"></a>
[36] Ibid., pp. 142, 5, 143, emphases added. [返回](#ref-en-ch08-36)

<a id="ch08-n037-zh"></a><a id="note-zh-ch08-37"></a>
[37] 同上，第142—143页。 [返回](#ref-zh-ch08-37)

<a id="ch08-n037-en"></a><a id="note-en-ch08-37"></a>
[37] Ibid., pp. 142–3. [返回](#ref-en-ch08-37)

<a id="ch08-n038-zh"></a><a id="note-zh-ch08-38"></a>
[38] 同上，第144页。 [返回](#ref-zh-ch08-38)

<a id="ch08-n038-en"></a><a id="note-en-ch08-38"></a>
[38] Ibid., p. 144. [返回](#ref-en-ch08-38)

<a id="ch08-n039-zh"></a><a id="note-zh-ch08-39"></a>
[39] 同上，第148页。 [返回](#ref-zh-ch08-39)

<a id="ch08-n039-en"></a><a id="note-en-ch08-39"></a>
[39] Ibid., p. 148. [返回](#ref-en-ch08-39)

<a id="ch08-n040-zh"></a><a id="note-zh-ch08-40"></a>
[40] 同上，第5与143页，着重号为引者所加。 [返回](#ref-zh-ch08-40)

<a id="ch08-n040-en"></a><a id="note-en-ch08-40"></a>
[40] Ibid., pp. 5 and 143, emphasis added. [返回](#ref-en-ch08-40)

<a id="ch08-n041-zh"></a><a id="note-zh-ch08-41"></a>
[41] 同上，第5页。 [返回](#ref-zh-ch08-41)

<a id="ch08-n041-en"></a><a id="note-en-ch08-41"></a>
[41] Ibid., p. 5. [返回](#ref-en-ch08-41)

<a id="ch08-n042-zh"></a><a id="note-zh-ch08-42"></a>
[42] 参见 Peter Osborne, ‘A Sudden Topicality: Marx, Nietzsche and the Politics of Crisis’, *Radical Philosophy* 160 (March/April 2010), pp. 19–26。 [返回](#ref-zh-ch08-42)

<a id="ch08-n042-en"></a><a id="note-en-ch08-42"></a>
[42] Cf. Peter Osborne, ‘A Sudden Topicality: Marx, Nietzsche and the Politics of Crisis’, *Radical Philosophy* 160 (March/April 2010), pp. 19–26. [返回](#ref-en-ch08-42)

# 第四部　社会生态、灾难预感

<a id="part4-title-zh"></a>
## **社会生态、灾难预感**

<a id="part4-title-en"></a>
## SOCIAL ECOLOGIES, INTIMATIONS OF CATASTROPHE

## 第9章　黑色亚特兰蒂斯：种植园世

<a id="ch09-title-zh"></a>
## 黑色亚特兰蒂斯：种植园世

<a id="ch09-title-en"></a>
## Black Atlantis: the plantationocene

<a id="ch09-author-zh"></a>
阿伊莎·哈米德

<a id="ch09-author-en"></a>
AYESHA HAMEED

<a id="ch09-p001-zh"></a>
这是我在沃克庄园的第一个傍晚。这里曾是甘蔗种植园，如今是奶牛场。正值黄昏。<a id="ref-zh-ch09-1"></a>[1](#note-zh-ch09-1)

<a id="ch09-p001-en"></a>
This is my first evening at Walker’s, once a sugar plantation and now a dairy. It is dusk.<a id="ref-en-ch09-1"></a>[1](#note-en-ch09-1)

<a id="ch09-p002-zh"></a>
我走出公寓，爬上微微生苔的台阶，向右转入泛紫的光里。左侧是马厩，身后是房屋，面前是草地。

<a id="ch09-p002-en"></a>
I step outside of the flat, climb the slightly mossy stairs and turn right into the purpling light. To my left are horse stables, behind me is the house and in front of me are fields of grass.

<a id="ch09-p003-zh"></a>
青蛙的声音在黄昏开始，越来越响。我走着的铺砌车道在田野处结束，我右转上一条土路。小径两侧的草很长。当我走到左侧一棵孤树时，小径沿一段小坡向下延伸，继续伸向远处一排树木。右边是南方，远处有几点闪烁的灯光。一只小蝙蝠从我头顶掠过。

<a id="ch09-p003-en"></a>
The sound of the frogs begins at dusk and it gets louder. The paved drive I am walking on ends at the field, and I turn right onto a dirt path. The grass is long on either side of the path. When I reach a lone tree to my left, the path dips down a small hill and continues to a line of trees in the distance. To the right is the South and there are some twinkling lights in the distance. A small bat swoops over my head.

<a id="ch09-p004-zh"></a>
在青蛙那怪异而尖利的嗡鸣之下，有一种寂静。一只黑狗从大宅跑向我，又转身回去，边跑边回头看我，仿佛想让我跟它走。我离开它，走进长草中倾听。

<a id="ch09-p004-en"></a>
Underneath the alien and screechy whir of the frogs there is a silence. A black dog runs up to me from the big house and then turns around and goes back, looking back at me as if trying to get me to follow it. I walk away from it and into the long grass and listen.

<a id="ch09-p005-zh"></a>
青蛙更响了。天空变黑。

<a id="ch09-p005-en"></a>
The frogs get louder. The sky turns black.

<a id="ch09-p006-zh"></a>
＊  
  
另一个开端：现在是两点半，我在哈里森洞穴外的停车场里等了大约三十分钟。旅游大巴和包租出租车高效地进出停车位，装卸着美国游客。

<a id="ch09-p006-en"></a>
＊  
  
Another beginning: it is half past two and I’ve been waiting in the parking lot outside Harrison’s Cave for about thirty minutes. Tour buses and hired taxis efficiently pull in and out of the parking spaces, loading and unloading their American passengers.

<a id="ch09-p007-zh"></a>
两个男人在我旁边聊天，其中一个让另一个搭车，他们走向一辆涂得鲜艳的公交车。我估计还要等二十分钟。

<a id="ch09-p007-en"></a>
Two men are chatting beside me, one of them offers the other one a lift and they walk over to a brightly painted bus. I figure I have twenty minutes more to wait.

<a id="ch09-p008-zh"></a>
我听到一声巨响，从书上抬起头，看见一辆柴油小巴飞驰穿过停车场，像抢劫案里的逃逸车。它仓促地斜停在我坐着的公交站附近。车上的牌子只写着“City”。人们迅速下车，柴油引擎轰隆作响。

<a id="ch09-p008-en"></a>
I hear a loud noise and look up from my book to see a diesel-powered minibus hurtling through the lot like a getaway car for a heist. It abruptly stops at a hasty angle near the bus stop where I am sitting. The sign on the bus just says ‘City’. People climb out quickly with the diesel engine rumbling.

<a id="ch09-p009-zh"></a>
我上车时，公交车又加速得那么快，我踉跄跌到座位上。我撑起身，向司机递出两元巴巴多斯币，带着歉意的“不好意思”，副驾驶座上的男人不耐烦地挥手让我坐下。

<a id="ch09-p009-en"></a>
As I climb the stairs the bus speeds up again so fast I trip onto a seat. I pull myself up holding out my two Barbadian dollars to the driver with an apologetic ‘excuse me’ and the man in the passenger seat waves impatiently at me to sit down.

<a id="ch09-p010-zh"></a>
车窗外，小巴沿着在甘蔗田中被开凿出的土路飞驰，田野上洒满阳光与尘土。我们尖啸着在另一个站停下，引擎低沉地咕哝又咆哮。

<a id="ch09-p010-en"></a>
I look out of the window as the bus hurtles down dirt roads hewn through fields of cane speckled with sun and dust. We screech to another stop and the engine grumbles and roars.

<a id="ch09-p011-zh"></a>
外面是甘蔗田，男男女女在路边等候。

<a id="ch09-p011-en"></a>
Outside are the fields of cane, and men and women waiting on the side of the road.

<a id="ch09-p012-zh"></a>
＊  
  
气候变化与种植园经济之间是什么关系？这是对许多事物的探索——《黑色亚特兰蒂斯》这部持续进行的表演的第四章开端，走访三角贸易三个停靠点之一的腹地，并认真对待唐娜·哈拉维与安娜·青使用“种植园世”一词的方式：它把种植园式生产的发展与我们当前所处地质纪元的开端联系起来。<a id="ref-zh-ch09-2"></a>[2](#note-zh-ch09-2)

<a id="ch09-p012-en"></a>
＊  
  
What is the relationship between climate change and plantation economies? This is an exploration of many things – the beginnings of a fourth chapter of an ongoing performance called *Black Atlantis*, visiting the heartland of one of the three stops of the triangular trade, and taking seriously Donna Haraway’s and Anna Tsing’s use of the term ‘Plantationocene’, which connects the development of a plantation form of production to the beginning of the geological era that we are currently in.<a id="ref-en-ch09-2"></a>[2](#note-en-ch09-2)

<a id="ch09-p013-zh"></a>
“种植园世”是农业与这个被称为人类世的时代之间关系的占位符。但他们所想的农业类型，是种植园那种工厂式榨取结构对多样农耕方式、森林与牧场的暴力取代——为出口而种植甘蔗和棉花等单一作物，由被强行跨越遥远距离运来、遭奴役或受契约束缚的劳动者身体生产。种植园消灭所栽培之物的多样性，摧毁土地，暴力剥削与剥夺在土地上劳作的身体，并摧毁居住在这些地区者任何可能的自给自足的自主性。

<a id="ch09-p013-en"></a>
The ‘Plantationocene’ is a placeholder for the relationship between agriculture and this era, called the Anthropocene. But the kind of agriculture they are thinking about is the violent replacement of diverse farming tactics, of forests and of pastures, by the factory-like extractive structure of plantations – the cultivation of single crops like sugar and cotton for export, produced by enslaved and indentured labouring bodies forcibly transported across vast distances. Plantations eradicate the diversity of what is cultivated, devastating the land, violently exploiting and expropriating the bodies working on the land and destroying any possible autonomy for self-sustenance for those living in these areas.

<a id="ch09-q001-zh"></a>
<a id="ch09-q002-zh"></a>
> ［我们使用］“种植园世”一词，指对人类照料的多样农场、牧场与森林的毁灭性转化，转变为榨取性的、圈围的种植园，依赖奴隶劳动以及其他被剥削、被异化、通常被空间运输的劳动……为资本积累与利润而将物质—符号的生成能力转移到世界各地——迅速迁移并重新组合种质、基因组、插条，以及其他各种名称与形式的生物体片段和被连根拔起的植物、动物与人——是种植园世、资本世与人类世共同的一项界定性操作。<a id="ref-zh-ch09-3"></a>[3](#note-zh-ch09-3)

<a id="ch09-q001-en"></a>
<a id="ch09-q002-en"></a>
> [we use the term] Plantationocene for the devastating  transformation of diverse kinds of human-tended farms, pastures,  and forests into extractive and enclosed plantations, relying on  slave labor and other forms of exploited, alienated, and usually  spatially transported labor… Moving material semiotic generativity  around the world for capital accumulation and profit – the rapid  displacement and reformulation of germ plasm, genomes, cuttings,  and all other names and forms of part organisms and of deracinated plants, animals, and people – is one defining operation of the  Plantationocene, Capitalocene, and Anthropocene taken together.<a id="ref-en-ch09-3"></a>[3](#note-en-ch09-3)

<a id="ch09-p014-zh"></a>
“种植园世”表明，人类对地球生态系统施加的地质力量根源于种植园奴隶制，根源在于它把土壤工具化为单一生产，并暴力奴役身体，用作栽培和收获甘蔗的机器，理想状态下还自我繁殖与维持。正如安娜·青所说，“种植园世”由“复制机器”或“简化的生态，如种植园，在其中生命世界被重制为未来资产”构成——换言之，它凸显一次激进暴力侵入的后果及其对交织人类与自然的生命世界的影响。

<a id="ch09-p014-en"></a>
The Plantationocene suggests that the geological force of humans on the planet’s ecosystem had its roots in plantation slavery, its instrumentalization of the soil for a singular kind of production and its violent enslavement of bodies to be used as machines to cultivate and harvest the cane, and to ideally reproduce and sustain itself. As Anna Tsing says, the Plantationocene is formed of ‘machines of replication’ or ‘simplified ecologies, such as plantations, in which life worlds are remade as future assets’ – in other words it highlights the aftermath of a radical and violent incursion and its effects on lifeworlds that intertwine the human and the natural.

<a id="ch09-p015-zh"></a>
要读取三百多年种植园及其不断演变的社会关系的历史——它紧随最古老的种植园奴隶制实例而来，且奴隶、种植园主与监工的后代仍然在场——并将其对置于标记气候变化的缓慢时间摆动，这几乎是不可能的努力。把一段仍然活着、仍在场的历史，对置于一个缓慢展开的、自然灾害频率增加、海洋变暖、海洋生命受威胁的未来，是不可通约的，也许毫无意义，因为它们运行在如此不同的层面，而在地面层面找到共同基础的可能性几乎为零。

<a id="ch09-p015-en"></a>
It is an almost impossible endeavour to read a history of over three hundred years of plantations and their continually evolving social relations in the wake of the oldest instance of plantation slavery, and in the continued presence of descendants of slaves and plantation owners and overseers, against the slow temporal swings that mark climate change. Reading a still living and present history against a slowly unravelling future of increasing frequencies of natural disaster, the warming of the ocean, the jeopardization of sea life is incommensurable and probably pointless as they operate in such different registers, and the possibility of finding common ground at ground level is nearly nil.

<a id="ch09-s01-zh"></a>
## **亚特兰蒂斯**

<a id="ch09-s01-en"></a>
## **Atlantis**

<a id="ch09-p016-zh"></a>
一天又一天，上午有太阳，下午有太阳，然后雨从天空劈开一道口子。雨季刚刚结束，边缘处仍有水的威胁。偏偏就在今天，这占据了中心舞台。出租车开到大宅前。雨点硕大而饱满，根本不可能冲上台阶钻进车门而不被淋湿。

<a id="ch09-p016-en"></a>
After day after day after day of sun in the morning, sun in the afternoon, rain sliced through the sky in a gash. The rainy season has just ended and at the margins there is still the threat of water. This has taken centre stage, today of all days. The taxi drives up to the house. The rain is so fat and plummy that it is impossible to sprint up the steps to the car door without getting wet.

<a id="ch09-p017-zh"></a>
出租车驶近城市边缘，雨刷勉强清出视野。每一下刮动都发出刺耳的声响。我们经过码头，所有远洋客轮都停泊在那里，它们庞大的船身在瓢泼大雨的浓密中模糊不清。然后我们到达亚特兰蒂斯办公室。它色彩鲜艳，满是游客纪念品：朗姆酒与海滩、杯垫与钥匙扣。角落里有免费的水果潘趣酒。墙上一幅壁画，一扇画出来并镶嵌装饰得像珊瑚墙的窗户。房间两边各有一台电视——一台循环播放潜艇的纪录片宣传片，另一台锁定CNN，无休止循环着特朗普在十二月下旬赢得选举人团投票。

<a id="ch09-p017-en"></a>
The taxi approaches the outskirts of the city with the wipers barely clearing the view. Each stroke of the blades makes a grating sound. We drive past the terminal where all the ocean liners anchor, their bulky bodies indistinct in the distance with the thickness of the pelting water. And then we arrive at the Atlantis office. It is brightly coloured and full of tourist memorabilia: rum and beaches, coasters and keychains. There is some free fruit punch in the corner. On the wall is a mural, a window painted and encrusted to look like a coral wall. There is a television on each side of the room – one with a looping documentary promo on the submarine, the other tuned into CNN, an endless loop of Trump winning the Electoral College vote in late December.

<a id="ch09-p018-zh"></a>
我们等着。

<a id="ch09-p018-en"></a>
We wait.

<a id="ch09-p019-zh"></a>
一对不堪重负的父母试图让穿着相同衣服的女儿们平静下来——看样子是她们的生日。一车车游客到来，他们纵容地看着两个孩子，或者看CNN。我们都坐在紫色皮长椅上。窗外雨鞭打玻璃。

<a id="ch09-p019-en"></a>
Two overwhelmed parents try to keep their identically dressed daughters calm on what appears to be their birthday. Busloads of tourists arrive and they watch these two children indulgently, or look at CNN. We all sit on purple leather benches. Outside the rain lashes at the windows.

<a id="ch09-p020-zh"></a>
门终于开了，我们被引导出去，步行一百米到等候的船。雨太大了，他们分发雨伞，要我们合用。即便如此，我到达船边时已浑身湿透。经过安全演示和一阵震耳的音乐，我们出发了。水是灰的，天空也是灰的。雨密密地打在窗上，海景化成模糊的像素。最后我们到达水中央一个点，一个金属小结构从水下伸出。我们到了亚特兰蒂斯潜艇。

<a id="ch09-p020-en"></a>
Finally the door opens and we are ushered out to walk the 100 metres to the waiting boat. It is raining so hard that we are instructed to share the umbrellas they hand out to us. Still, I am drenched by the time I get to the boat. After a safety demonstration, and lots of loud music, we head off. The water is grey and the sky is also grey. The rain falls so thick on the window that the seascape falls into blurry pixels. Finally we arrive at a point in the middle of the water where a small metal structure protrudes from underwater. We’ve arrived at the Atlantis Submarine.

<a id="ch09-p021-zh"></a>
＊  
  
二十世纪初，约翰·欧内斯特·威廉森——一位英国船长的儿子——被关于失落亚特兰蒂斯以及牙买加皇家港之类海盗城镇沉没的故事所激发。他与兄弟乔治设计并建造了一个他称为“摄影球”的结构：一个带玻璃板的水下室，用同心环制成的管道连接到水面上的船。

<a id="ch09-p021-en"></a>
＊  
  
In the early twentieth century John Ernest Williamson, son of an English sea captain, was fuelled by the stories about lost Atlantises and the sinking of pirate towns like Port Royal in Jamaica. With his brother George he designed and built a structure he called the photosphere, an underwater chamber with a glass panel, which was connected to a boat on the surface of the water by a tube made of concentric rings.

<a id="ch09-p022-zh"></a>
威廉森搬到巴哈马建造他的摄影球，因为周围水域很浅，珊瑚沙闪闪发白。海水基本没有造成浑浊的浮游植物，因此清澈。摄影球被用于多种目的：作为拍摄最早水下活动影像的舱室，作为旅游新奇事物——游客可以通过水下邮局从海底寄明信片——据说还用于水下打捞沉船。正是在这里拍摄了1916年的《海底两万里》，人影幽灵般静止。1954年的电影也是在这里拍摄的。

<a id="ch09-p022-en"></a>
Williamson moved to the Bahamas to build his photosphere as the surrounding waters are shallow, and the coral sand is sparkling and white. The sea is largely free of clouding phytoplankton, so the water is clear. The photosphere was used for a number of purposes, as a chamber to film the first underwater moving images, as a tourist novelty, where visitors could send postcards from the bottom of the sea through an underwater post office, and reportedly to salvage ships underwater. It is here that the 1916 film of *20,000 Leagues Under the Sea* was filmed, the figures ghostly still. So was the film made in 1954.

<a id="ch09-p023-zh"></a>
克里斯塔·A. 汤普森描述说，这些早期对摄影球的潜入如梦似幻，但水下景象也被感知为险恶。这反映在威廉森自己的思考中：他四处以题为“美与悲剧”的讲座呈现其海洋工作。巴哈马土地并不特别肥沃，但其海洋生命繁荣、丰富、不断繁殖。

<a id="ch09-p023-en"></a>
Krista A. Thompson describes how these early immersions into the photosphere were dreamlike, but that the vista of the underwater was also perceived to be menacing. This was reflected in Williamson’s own thinking as he travelled to present his work on the sea in a lecture titled ‘Beauty and Tragedy’. Bahamian land was not remarkably fertile but its marine life was blooming and rich and multiplying.

<a id="ch09-p024-zh"></a>
十九世纪晚期，水下生命作为一种奇观，作为精英的消遣而兴盛。年轻的黑人男子会潜入海底，为在船上等待的淑女们抓取纪念品，她们透过“热带长柄眼镜”窥视大海。海底世界被视为一座水下花园、一片风景或一座森林。

<a id="ch09-p024-en"></a>
In the late nineteenth century underwater life as a kind of spectacle flourished as an elite pastime. Young black men would dive to the bottom of the sea to grab mementos for genteel women waiting on boats, who peered into the sea through ‘tropical lorgnons’. The submarine world was seen as an underwater garden, a landscape or a forest.

<a id="ch09-q003-zh"></a>
> 哈钦森……把珊瑚海绵重新想象为“迎客的棕榈”，把鱼想象为“蜂鸟”，把珊瑚想象为“大树”与“庄严的森林”……查尔斯·艾夫斯也认为，海底景观呈现的相似关系，犹如“广袤而壮丽的热带森林——终年披绿，优雅的藤蔓点缀其间，各色花朵繁盛，羽色纷呈、羽毛丰美的无数鸟儿鸣声不绝——与一位女士小而奢华的闺房之间的关系；闺房中有常青枝条、攀援藤蔓，以及关在镀金小笼中的鸟儿”。<a id="ref-zh-ch09-4"></a>[4](#note-zh-ch09-4)

<a id="ch09-q003-en"></a>
> Hutchinson … re-envisioned coral sponges as ‘welcoming palms,’ fish  as ‘hummingbirds,’ and coral as ‘great trees’ and ‘stately forests’…  Charles Ives also contended that the seascape bore similarity to  ‘the vast and magnificent tropical forests, clothed in perennial  green, adorned with graceful vines, teeming with flowers of every  hue, and vocal with countless birds of the most varied and of the  richest plumage, bear to a lady’s little but luxurious boudoir, with its  evergreen branches, climbing vines and captive birds in their small  but gilded cages.’<a id="ref-en-ch09-4"></a>[4](#note-en-ch09-4)

<a id="ch09-p025-zh"></a>
＊  
  
杰茜卡·莱曼描述了1738年荷兰奴隶船*Leusden*在苏里南海岸外大西洋水域的沉没。船长钉死了关押680名妇女、男人与儿童的货舱舱口。尽管有充分文献记录，残骸从未被找到。在把海洋深处思考为档案时，她写道：

<a id="ch09-p025-en"></a>
＊  
  
Jessica Lehman describes the sinking of the Dutch slave ship *Leusden* in Atlantic waters off the coast of Suriname in 1738. The captain nailed shut the hatches to the hold of the ship which held 680 women, men and children. Although well documented, the wreck has not been found. In thinking of the ocean depths as archive, she writes:

<a id="ch09-q004-zh"></a>
> 如果说海洋掩盖了奴隶制的一些废墟，它却没有那么轻易地隐藏资本主义帝国主义晚近的全部痕迹。1964年7月，在漫长海洋有毒倾倒历史中的一幕里，英国商船*Halcience*开始把来自数个国营场址的放射性废物包倒入比斯开湾。<a id="ref-zh-ch09-5"></a>[5](#note-zh-ch09-5)

<a id="ch09-q004-en"></a>
> If the ocean has concealed some of slavery’s ruins, it has not so readily  hidden all of the more recent traces of capitalist imperialism. In July  1964, during one episode in a long history of marine toxic dumping,  the British merchant vessel *Halcience* began to discard packages of  radioactive waste from several state-operated sites into the Bay of  Biscay.<a id="ref-en-ch09-5"></a>[5](#note-en-ch09-5)

<a id="ch09-p026-zh"></a>
放射性废物、手套和瓶子留下了更多痕迹，然而早在1964年之前，就已有一段可观的毒物倾倒史。她把这与葬在*Leusden*船体中的奴隶联系起来：海洋是一个由废墟界定的储藏库与档案。放射性瓶子漂浮在水面，而按照爱德华·格利桑的讲述，它们的对应物是大西洋海底的洋流，“由‘几乎未腐蚀’的铁球与锁链标示”。<a id="ref-zh-ch09-6"></a>[6](#note-zh-ch09-6)

<a id="ch09-p026-en"></a>
The items of radioactive waste, gloves and bottles left more of a trace, and yet even in 1964 were preceded by a substantial history of toxic dumping. This she sees as connected to the slaves buried in the *Leusden* hull, the ocean a repository and archive defined by ruin. The radioactive bottles float on the surface, and, following Edouard Glissant’s telling, their counterparts are the Atlantic’s under-sea currents, ‘signposted by “scarcely corroded” balls and chains’.<a id="ref-en-ch09-6"></a>[6](#note-en-ch09-6)

<a id="ch09-p027-zh"></a>
然后是那些被腐蚀的洋流本身，是2010年深水地平线漏油事故后掺杂着石油的波浪；在那场事故中，210加仑石油与天然气顺着大陆坡滑入深水。这个亚特兰蒂斯不是死者、放射性物质、浮油与腐蚀之物的档案。它*就是*所有这些。这是它的悲剧，也许也是它的美。

<a id="ch09-p027-en"></a>
And then there are the corroded currents themselves, waves laced with oil after the Deepwater Horizon oil spill in 2010 where 210 gallons of oil and natural gas slicked down the continental slope into deep water. This Atlantis is not an archive of the dead, the radioactive, the oil slicked and the corroded. It *is* all these things. This is its tragedy and maybe its beauty.

编者说明：底本写作“210加仑”，译文照录。该数值明显存在数量级疑点：NOAA损害评估与修复项目页记载，深水地平线事故约有1.34亿加仑石油泄入海湾。此处仅提示底本数字问题，不把事故总泄漏量直接等同于原句所述进入深水的数量，也不替作者补定数字。 https://darrp.noaa.gov/oil-spills/deepwater-horizon

<a id="ch09-s02-zh"></a>
## **海岸**

<a id="ch09-s02-en"></a>
## **Coasts**

<a id="ch09-p028-zh"></a>
**<––––––>** 十二年后，亚伦来接我，开车环岛时我们重逢。我们决定去大西洋海岸，这是两次出行中的第一次。这像是一组地名逐渐缩短的旅程：第一次我们开车去一个叫巴斯谢巴的村庄，第二次去海岸另一处叫巴斯的地方。我确信，如果我们第三次出行，会招来第三个叫“巴”的地段。但这种糟糕的幽默不能持久。

<a id="ch09-p028-en"></a>
**<––––––>** I meet Aaron after twelve years when he picks me up for a drive around the island. We decide to go to the Atlantic coast, the first of two trips. It seems like a set of journeys of attrition as during the first trip we drive to a village called Bathsheba, and the second time to another part of the coast called Bath. I’m convinced that had we made a third trip it would have conjured a third stretch called Ba. But this kind of bad humour can’t hold.

<a id="ch09-p029-zh"></a>
大西洋海岸是岛上狂野的海岸。这里水面波涛汹涌，聚落更零散，道路更间断、更蜿蜒。我们开车经过一条阳光铺洒的路，看见一个女人耐心地在路边等候。亚伦停下车，提出载她去上班的地方，结果是一家叫圆屋的临水餐厅，据说鸡尾酒很棒。你原本打算怎么去？他问她，她指向一条消失在长草中的小径。不是什么好主意，他说，我们朝餐厅开去，她同意。下车挥手时她喊道：下一杯鸡尾酒我请。

<a id="ch09-p029-en"></a>
The Atlantic coast is the wild coast of the island. The water here is choppy, the settlements more sporadic and the roads more intermittent and winding. As we drive through a sunny road we see a woman waiting patiently at the side. Aaron stops and offers her a lift to where she works, which turns out to be a restaurant called the Roundhouse on the water, which apparently serves great cocktails. How were you planning to get there? he asks her, and she points to a tiny path that disappears in the long grass. Not a great idea, he says, as we drive to the restaurant and she agrees. The next cocktail is on me, she calls, as she climbs out of the car and waves.

<a id="ch09-p030-zh"></a>
我第一次跳进大西洋，感到水在拉扯与推挤我的皮肤。水温暖而回旋。脚下的沙石多而粗粝。海滩空无一人。我身后的沙地里，间隔立着木桩，是曾经沿海岸运输甘蔗的铁路残迹。海岸自那时起已后退，曾经环绕干地的木桩如今半淹没在水中。

<a id="ch09-p030-en"></a>
The first time I jump in the Atlantic I feel the water pull and push against my skin. It is warm and swirling. The sand below my feet is rocky and rough. The beach is empty. Behind me in the sand are stumps of wood periodically placed, remnants of a railway track used to transport sugar along the coast. The coast has receded since then and the stumps which once circled dry land are now half underwater.

<a id="ch09-p031-zh"></a>
我向东望去，越过水面，看不见任何陆地。亚伦顺着我的目光，告诉我下一片陆地是塞内加尔海岸。我继续盯着东方。

<a id="ch09-p031-en"></a>
I look to the east, across the water and see that there is no land in sight. Following my gaze, Aaron tells me that the next land mass is the Senegalese coast. I keep staring east.

<a id="ch09-p032-zh"></a>
＊  
  
2006年4月29日，一艘二十英尺长的船在巴巴多斯东南海岸的拉格德角外被发现。海岸警卫队在船上发现十一具尸体，被阳光与海水保存并风干。这是一艘在大西洋上漂流了四个月的幽灵船。它在圣诞日从佛得角群岛的普拉亚启航，满载来自塞内加尔、几内亚比绍和冈比亚的移民，前往加那利群岛。每个人都为船上的位置付了890英镑。

<a id="ch09-p032-en"></a>
＊  
  
On 29 April 2006 a twenty-foot boat was spotted off Ragged Point on the south-eastern coast of Barbados. On board eleven bodies were found by the coastguards, preserved and desiccated by the sun and salt water. This was a ghost ship adrift for four months on the Atlantic Ocean. It set sail on Christmas Day in Praia in the Cape Verde Islands full of migrants from Senegal, Guinea Bissau and Gambia en route to the Canary Islands. Each of these people paid £890 for their place on the boat.

<a id="ch09-p033-zh"></a>
船在毛里塔尼亚港口努瓦迪布遇到麻烦，曾被另一艘船拖行一段时间。《卫报》一篇文章推测，拖缆可能是被砍刀砍断的。一旦漂流，船便开始横越大西洋的缓慢移动，受风雨冲击，被洋流拉向西。到一月，所有乘客都已死亡；许多人的尸体被抛入海中或从船上冲落。这艘幽灵船随后航行了2,800英里，抵达巴巴多斯。

<a id="ch09-p033-en"></a>
The boat ran into trouble at Nouadhibou, a Mauritian port, and was towed for a time by another ship. An article in the *Guardian* conjectures that the line was possibly severed by being hacked by a machete. Once adrift the boat began its slow movement across the Atlantic, buffeted by the winds and rain, and pulled westward by the ocean’s currents. By January all the passengers had died; many of their bodies were jettisoned into the sea or washed overboard. This ghost ship then travelled the 2,800 miles to Barbados.

编者说明：底本将努瓦迪布称为Mauritian港口（毛里求斯的）；该章所引《卫报》原报道写作Mauritanian（毛里塔尼亚的），译文据此作“毛里塔尼亚”。 https://www.theguardian.com/world/2006/may/29/gilestremlett.mainsection

<a id="ch09-p034-zh"></a>
船上发现的一封死于船上者所写的便条，以及一张塞内加尔航空公司的机票，提供了拼图的最初几块。据《卫报》报道，船上还发现了两张便条：

<a id="ch09-p034-en"></a>
A note written by one of the men who died on board and a ticket for a Senagalese Airlines flight found on the boat provided the first pieces of the puzzle. According to the *Guardian*, these two notes were also found on board:

<a id="ch09-q005-zh"></a>
> “我想给我在巴萨达（塞内加尔内陆的一个城镇）的家人寄一笔钱。请原谅我，再见。这是我在这个巨大的摩洛哥海中的生命终点，”据巴巴多斯报纸《每日国民报》报道，便条这样写道。

<a id="ch09-q005-en"></a>
> ‘I would like to send to my family in Bassada [a town in the interior  of Senegal] a sum of money. Please excuse me and goodbye. This is  the end of my life in this big Moroccan sea,’ the note said, according  to a Barbados paper, the *Daily Nation*.

<a id="ch09-q006-zh"></a>
> “我来自塞内加尔，但在佛得角住了一年。情况很糟。我觉得我活着走不出去了。我需要发现我的人把这笔钱寄给我的家人。请打电话给我的朋友易卜拉希马·德拉梅。  
> 　　署名：迪奥·松卡尔·迪埃米。” 《国家报》对船上发现便条的记述<a id="ref-zh-ch09-7"></a>[7](#note-zh-ch09-7)

<a id="ch09-q006-en"></a>
> ‘I am from Senegal but have been living in Cape Verde for a year.  Things are bad. I don’t think I will come out of this alive. I need  whoever finds me to send this money to my family. Please telephone  my friend Ibrahima Drame.  
>   Signed Diaw Sounkar Diemi.’ *El Pais*’s account of note found on boat<a id="ref-en-ch09-7"></a>[7](#note-en-ch09-7)

<a id="ch09-p035-zh"></a>
＊  
  
清晨时分，太阳辐射加热陆地比加热海洋更快。陆地上更热、更轻的空气把风从海洋拉向陆地。因此，太阳升起时，岛屿四面都被从海洋吹向内陆的风包围。

<a id="ch09-p035-en"></a>
＊  
  
In the morning hours, radiation from the sun warms the land faster than it warms the sea. The hotter, lighter air of the land pulls the wind from sea to land. So, as the sun rises, the island is surrounded on all sides by winds that blow inland from the sea.

<a id="ch09-p036-zh"></a>
巴巴多斯只有两种岛上独有的植物，“一种常见沟壑灌木*Phyllanthus andersonii*，有时称为扫帚，以及一种罕见的细长攀援植物*Metastelma barbadense*，它没有俗名”。<a id="ref-zh-ch09-8"></a>[8](#note-zh-ch09-8) 其余近三千种植物都来自水域彼岸——有些由跨洋船只运来并被暴力栽培，另一些由自然力量带来——由飞越水面的鸟和风带来。

<a id="ch09-p036-en"></a>
Barbados has only two species of plants that are unique to the island, ‘a common gully shrub *Phyllanthus andersonii* sometimes called broom, and a rare slender climber, *Metastelma barbadense*, which has no common name’.<a id="ref-en-ch09-8"></a>[8](#note-en-ch09-8) The rest of the nearly three thousand varieties of plants came from across the water – some borne on ships from across the ocean and violently cultivated, and others carried by forces of nature – by birds flying across the water and by the wind.

<a id="ch09-q007-zh"></a>
> ［在巴巴多斯］植物随风和洋流、在鸟类帮助下抵达海岸。此外，我们许多野生植物是有意引入的，后来变得能自行播种并归化。人们常说，巴巴多斯的许多野生植物是外来的杂草。<a id="ref-zh-ch09-9"></a>[9](#note-zh-ch09-9)

<a id="ch09-q007-en"></a>
> [In Barbados] flora reach the shores on winds and ocean currents  and with the help of birds. In addition many of our wild plants are  deliberate introductions which have since become self-seeding and  naturalised. It is often said that many of the wild plants of Barbados  are exotic weeds.<a id="ref-en-ch09-9"></a>[9](#note-en-ch09-9)

<a id="ch09-p037-zh"></a>
由吹过安的列斯群岛的种子长成的植物，被毁灭性的甘蔗田取代。这些曾遭大量摧毁、由风、洋流与鸟带来的植物，如今在土路两侧、在用作放牧的田野上、在穿过珊瑚洞穴的沟壑中茂密生长。

<a id="ch09-p037-en"></a>
Plants grown from seeds blown across the Antilles were replaced by annihilating fields of sugar cane. These decimated plants, blown by wind and carried by ocean currents and birds, now grow thickly across dirt-hewn paths, on fields grown for grazing, and in gullies carved through coral caves.

<a id="ch09-p038-zh"></a>
一个更强的风系从更远处吹来。信风横越大西洋吹向加勒比海，携带着天气，数个世纪以来也推送着从东到西的船帆。撒哈拉沙漠的尘土吹过大西洋，把一块大陆的物质一粒一粒地搬到海洋另一侧的一串岛屿上。巴巴多斯是这些尘粒触及的第一片海岸；在春、夏、秋三季，空气充满萨赫勒的物质，大地铺满它的磷光。

<a id="ch09-p038-en"></a>
A stronger system of winds travels from farther away. Trade winds blow across the Atlantic Ocean to the Caribbean Sea, carrying the weather, and for centuries the sails of ships from East to West. Dust from the Sahara Desert blows across the Atlantic, moving grain by grain the matter of one continent onto a line of islands on the other side of the ocean. Barbados is the first coast that these particles of dust touch, and for spring, summer and autumn the air is full of matter of the Sahel, and the earth is carpeted with its phosphorescence.

### 原注

<a id="ch09-n001-zh"></a><a id="note-zh-ch09-1"></a>
[1] 本作品的研究得以进行，得益于加拿大艺术委员会颁发的一笔旅行资助，用于参加在特立尼达爱丽丝庭院与巴巴多斯鲜奶驻地项目。 [返回](#ref-zh-ch09-1)

<a id="ch09-n001-en"></a><a id="note-en-ch09-1"></a>
[1] Research for this work was made possible by a travel grant awarded by the Canada Council for the Arts to attend residencies at Alice Yard (Trinidad) and Fresh Milk (Barbados). [返回](#ref-en-ch09-1)

<a id="ch09-n002-zh"></a><a id="note-zh-ch09-2"></a>
[2] Anna Lowenhaupt Tsing, ‘A Feminist Approach to the Anthropocene: Earth Stalked by Man’, Barnard Center for Research on Women Videos, vimeo.com/149475243。 [返回](#ref-zh-ch09-2)

<a id="ch09-n002-en"></a><a id="note-en-ch09-2"></a>
[2] Anna Lowenhaupt Tsing, ‘A Feminist Approach to the Anthropocene: Earth Stalked by Man’, Barnard Center for Research on Women Videos, vimeo.com/149475243. [返回](#ref-en-ch09-2)

<a id="ch09-n003-zh"></a><a id="note-zh-ch09-3"></a>
[3] Donna Haraway, ‘Anthropocene, Capitalocene, Plantationocene, Chthulucene: Making Kin’, *Environmental Humanities* 6, 2015, p. 162; www.environmentalhumanities.org。 [返回](#ref-zh-ch09-3)

<a id="ch09-n003-en"></a><a id="note-en-ch09-3"></a>
[3] Donna Haraway, ‘Anthropocene, Capitalocene, Plantationocene, Chthulucene: Making Kin’, *Environmental Humanities* 6, 2015, p. 162; www.environmentalhumanities.org. [返回](#ref-en-ch09-3)

<a id="ch09-n004-zh"></a><a id="note-zh-ch09-4"></a>
[4] Krista J. Thompson, *An Eye for the Tropics: Tourism, Photography, and Framing the Caribbean Picturesque*, Durham NC: Duke University Press, 2006, pp. 170–71。 [返回](#ref-zh-ch09-4)

<a id="ch09-n004-en"></a><a id="note-en-ch09-4"></a>
[4] Krista J. Thompson, *An Eye for the Tropics: Tourism, Photography, and Framing the* *Caribbean Picturesque.* Durham NC: Duke University Press, 2006, pp. 170–71. [返回](#ref-en-ch09-4)

<a id="ch09-n005-zh"></a><a id="note-zh-ch09-5"></a>
[5] Jessica Lehman, ‘Blue History’, *The New Inquiry*, 6 February 2017, thenewinquiry.com/essays/blue-history。 [返回](#ref-zh-ch09-5)

<a id="ch09-n005-en"></a><a id="note-en-ch09-5"></a>
[5] Jessica Lehman, ‘Blue History’, *The New Inquiry*, 6 February 2017, thenewinquiry. com/essays/blue-history. [返回](#ref-en-ch09-5)

<a id="ch09-n006-zh"></a><a id="note-zh-ch09-6"></a>
[6] 同上。 [返回](#ref-zh-ch09-6)

<a id="ch09-n006-en"></a><a id="note-en-ch09-6"></a>
[6] Ibid. [返回](#ref-en-ch09-6)

<a id="ch09-n007-zh"></a><a id="note-zh-ch09-7"></a>
[7] Giles Tremlett, ‘After four months at sea, ghost ship with 11 petrified corpses washes up in Barbados’, *Guardian*, 29 May 2006, www.theguardian.com/world/2006/may/29/gilestremlett.mainsection。 [返回](#ref-zh-ch09-7)

<a id="ch09-n007-en"></a><a id="note-en-ch09-7"></a>
[7] Giles Tremlett, ‘After four months at sea, ghost ship with 11 petrified corpses washes up in Barbados’, *Guardian*, 29 May 2006, www.theguardian.com/world/2006/may/29/ gilestremlett.mainsection. [返回](#ref-en-ch09-7)

<a id="ch09-n008-zh"></a><a id="note-zh-ch09-8"></a>
[8] Sean Carrington, *Wild Plants of Barbados*, Oxford: Macmillan Caribbean, 2007, p. 1。 [返回](#ref-zh-ch09-8)

<a id="ch09-n008-en"></a><a id="note-en-ch09-8"></a>
[8] Sean Carrington, *Wild Plants of Barbados*, Oxford: Macmillan Caribbean, 2007, p. 1. [返回](#ref-en-ch09-8)

<a id="ch09-n009-zh"></a><a id="note-zh-ch09-9"></a>
[9] 同上。 [返回](#ref-zh-ch09-9)

<a id="ch09-n009-en"></a><a id="note-en-ch09-9"></a>
[9] Ibid. [返回](#ref-en-ch09-9)

## 第10章　家中的陌生人：从指涉性艺术作业到构成性艺术作业

<a id="ch10-title-zh"></a>
## 家中的陌生人：从指涉性艺术作业到构成性艺术作业

<a id="ch10-title-en"></a>
## Strangers at home: from referential to compositional artworking

<a id="ch10-author-zh"></a>
克里斯蒂安·尼扬佩塔

<a id="ch10-author-en"></a>
CHRISTIAN NYAMPETA

<a id="ch10-p001-zh"></a>
2019年12月初，我正返回我居住的纽约。我从卡萨布兰卡起飞的航班准时降落在肯尼迪机场，但由于我正在把临时签证转为永久签证，目前重新进入美国需要经历国土安全调查局（HSI）的二次审查程序。当然，国土安全部在某种意义上审查所有赴美访客，只不过这种二次处理在一间由武装警卫押送前往的办公室里进行。一进入那间灯火通明的房间，就变成等待批准的事，身边还有别人，他们和我一样相当滑稽地竭力避免目光接触，掩藏尴尬、疲惫与绝望的混合。

<a id="ch10-p001-en"></a>
At the beginning of December 2019 I was returning to New York, where I live. My flight from Casablanca landed on time at JFK Airport, but because I am in the process of changing my temporary visa to a permanent one re-entry into the United States currently involves undergoing a secondary clearance process by Homeland Security Investigations (HSI). Homeland Security of course scrutinize all visitors to the USA in a way, except that this secondary processing takes place in an office to which one is escorted by armed guard. Once in that brightly lit room, it becomes a matter of waiting for approval, alongside others who, like myself, rather comically do everything that they can to avoid eye contact and hide their mix of embarrassment, exhaustion and desperation.

<a id="ch10-p002-zh"></a>
我已经习惯这种经历，此前经历过多次，但这次不同：我被叫进*第三*间办公室。“克里斯蒂安先生，”一个威严的声音说，“请跟我走这边。”声音的主人身穿便装，但我猜想他右臀处的鼓包是一把隐藏的手枪。我完全沉默地跟着他，越来越深入机场迂回的内部，每一步都让我的焦虑增加，直到我们到达目的地。

<a id="ch10-p002-en"></a>
I was used to this experience, having gone through it a number of times already, but this occasion was different in that I was called into a *third* office. ‘Mr Christian’, a commanding voice said, ‘please follow me this way.’ The person behind the voice was in civvies, but I assumed the bulge on his right hip was a concealed handgun. I followed him in complete silence deeper and deeper into the circuitous interiors of the airport, each step causing my anxiety to increase, until we reached our destination.

<a id="ch10-p003-zh"></a>
移民官用力握了握我疲惫的手。他确认了我的全名和出生日期，没有自我介绍，指示我坐在他办公桌对面的一把椅子上。他坐下，把我的护照和移民卡放在旁边，在键盘上敲了几下，但随即放弃电脑，拿起一个笔记本，翻到空白页，告诉我被叫来是为了更好地了解我。我没什么可担心的；只需回答他的*所有*问题，我*应该*很快就能离开。我咕哝着表示同意，在椅子上不安地挪动。

<a id="ch10-p003-en"></a>
The immigration officer firmly shook my tired hand. He confirmed my full name and date of birth, refrained from introducing himself, and instructed me to sit at his desk in a chair opposite his own. He took his own seat, placed my passport and immigration card down next to him, hit a few keys on his keyboard, but then immediately abandoned his computer, picked up a notebook, turned over the page to reveal a blank one and told me that I had been called in so that he could get to know me better. I had nothing to worry about; all I had to do was answer *all* his questions and I *should be* out of there in no time. I muttered something in acquiescence, shuffling awkwardly in my chair.

<a id="ch10-p004-zh"></a>
这则轶事是一场演讲的开端；演讲最初被宣布为视听演示，以一组朴素的问题开始：我的名字为什么叫克里斯蒂安？如何建立关于当今生活限度的记忆？如何把有时相互矛盾、尽管都真实的记忆分层？如何把单一的民族与官方记忆同多重个体记忆、集体记忆、也许还有地理的、地质的与生态的记忆调和起来？

<a id="ch10-p004-en"></a>
This anecdote was the beginning of a presentation that was initially announced as an audiovisual presentation commencing with a set of unadorned questions: How come my name is Christian? How to build a memory of present-day limits of living? How to layer the memories that are sometimes contradictory, even though they are all true? How to reconcile the singular national and official memory with the multiple individual, collective memories, and perhaps even the geographical, geological and ecological ones?

<a id="ch10-p005-zh"></a>
想法是通过一部合作性、开放式的影片《一起思考的人一起跳舞》中的声音与视觉片段来处理这些问题。影片通过“声音社会”结构，以播放列表的形式建构社会生态；播放列表取材于艺术集会、哲学会议、社交聚会、教学集会与灵性对话，在历史断裂、不连续、脱节的连续性及其他此类思考模式所产生的地域与知识之内和之外。确实，《一起思考的人一起跳舞》是艺术家兼图书管理员兰戈阿托·赫拉萨内发起的集体聚会与声音集会的名称，作为“艺术教育另一路线图非洲集群”研讨会的组成部分；该研究项目关于艺术教育史，由四大洲的教育者、艺术家与研究者网络开展，始于苏黎世艺术大学（ZHdK）艺术教育研究所。

<a id="ch10-p005-en"></a>
The idea was to address these questions through sonic and visual fragments from a collaborative and open-ended film, *People Who Think Together Dance Together*. The film constructs social ecologies through ‘audiosocial’ structures in the form of a playlist that draws from artistic assemblies, philosophical conferences, social gatherings, pedagogical convenings and spiritual conversations, within and beyond spaces and knowledges that come out of historical ruptures, discontinuities, disjointed continuities and other such modes of thinking. Indeed, *People* *Who Think Together Dance Together* is the name of collective parties and sonic gatherings initiated by the artist and librarian Rangoato Hlasane as an integral component of the symposiums of Another Roadmap for Arts Education Africa Cluster, a research project on the history of arts education undertaken within a network of educators, artists and researchers working in four continents, initiated at the Institute for Art Education at Zurich University of the Arts (ZHdK).

<a id="ch10-s01-zh"></a>
## **从“艺术*是*什么？”到“艺术*何时*是艺术？”**

<a id="ch10-s01-en"></a>
## \*\*From ‘\*\****what*** **is art?’** **to** ***‘when*** **is it art?’**

<a id="ch10-p006-zh"></a>
但正如提及时几乎显得多余，上述公告发布的2020年1月，与我现在写作的2020年5月，看起来和感觉起来都大不相同。<a id="ref-zh-ch10-1"></a>[1](#note-zh-ch10-1) 与世界大多数地方一样，纽约的博物馆关闭，所有展示空间也关闭。相反，一些展览、讲座、放映与表演迁移到线上。此前，在当前危机汇聚开始之前，当代艺术*是*什么这一问题，本来可以通过审视当代艺术*何时*可接触来回答：当代艺术曾是广大公众与观众在正午之前几乎遇不到、也很少在下午六点之后（每周特定日子到晚上九点）遇到的艺术作品。换言之，由画廊与博物馆保存、授权并保护下来的当代艺术，几乎无人与之共同生活。我已经对这类不被共同生活的艺术作品之日常性社会学感到着迷。而如今，为尽量减少病毒传播而全国强制实施的居家令，让我想到自己与那位移民官的个人遭遇。以下是对“不被共同生活的艺术作品”这一悖论如何把艺术工作者塑造成自己家中的陌生人的反思。为此，我回到与HSI移民官的遭遇。

<a id="ch10-p006-en"></a>
But, as it is almost obsolete to mention, the moment of January 2020 in which the above announcement was made looks and feels very different from the month of May 2020 in which I write.<a id="ref-en-ch10-1"></a>[1](#note-en-ch10-1) As has been the case in most parts of the world, in New York museums are closed and so are all spaces of display. Instead, some of the exhibitions, talks, screenings and performances have migrated online. Previously, before the onset of the current convergence of crises, the question of *what* contemporary art is could have been addressed by looking at *when* contemporary art is accessible: contemporary art had been artworks that wider publics and audiences scarcely encounter before noon and rarely past 6 pm (9 pm on select days of the week). In other words, the contemporary art preserved, mandated and conserved by the gallery and the museum is barely lived with. I was already fascinated by something akin to the sociology of the quotidian of such artwork that is not lived with. And now, with the nationwide mandatory sheltering directives that are currently in effect in order to minimize the spread of the virus, this new restriction of mobility reminds me of my personal encounter with the immigration officer. The following is a reflection on how this paradox of ‘artworks that are not lived with’ gives shape to artworkers as strangers in their own home. In order to do this, I return to my encounter with the HSI immigration officer.

<a id="ch10-p007-zh"></a>
当我坐在他办公室里、感觉像是一种*拘留*时，官员向我解释：“基本上，你被我们的系统标记了，因为你是从马里旅行回来的。”他停顿，直视我。“你做什么工作？你在马里做什么？待了多久？住在哪里？跟谁接触？去过哪些地方？”这连串提问让我有点吃惊，我咕哝说参加了巴马科双年展，展览在马里首都巴马科的多个文化机构举行。我住在友谊酒店，整个旅程由马里文化部长办公室安排，事实上我是应其邀请出行的。我给官员看了新闻稿、邀请函，以及双年展上收到的徽章和手提袋。我甚至拿出了一张萨利夫·凯塔的照片，是我在马里国家博物馆的一场开幕式上拍的。我也拍了总统本人的照片，但我说，我更满意的是给文化部长恩迪亚耶·拉马图拉耶·迪亚洛拍的那张，因为她的开幕演讲令人激动不已。

<a id="ch10-p007-en"></a>
‘Basically’, the officer explained to me as I sat in what felt like a *detentio* in his office, ‘you were flagged up in our system because you are travelling from Mali.’ He paused and looked directly at me. ‘What do you do for work? What were you doing in Mali? How long were you there for? Where did you stay? Who were you in contact with? What places did you visit?’ I was taken a little aback by the rapid questioning and mumbled that I had attended the Bamako Biennale held across a number of cultural institutions in Bamako, the capital of Mali. I had stayed at Hôtel l’Amitié and my entire journey had been organized by the Office of the Malian Minister of Culture on whose invitation I was, in fact, travelling. I showed the officer a press release, my invitation letter, and the badge and tote bag I had received at the Biennale. I even produced a picture of Salif Keita, which I had taken at one of the opening ceremonies at the National Museum of Mali. I had also taken a photograph of the president himself, but, I said, I was more pleased with my picture of N’Diaye Ramatoulaye Diallo, the minister of culture, because I had found her opening speech nothing short of electrifying.

<a id="ch10-p008-zh"></a>
“什么是双年展？”官员问。他让人难以捉摸。我不确定这是不是一个真诚的问题。他还问萨利夫·凯塔是谁，并重复之前的问题：“你做什么工作？”“我是艺术家，”我终于迟疑地回答。“一位视觉艺术家，”我赶紧澄清。我自己也开始质疑这究竟意味着什么，以及那是否真的是我。官员不慌不忙地记了些笔记。他一定感觉到我锐利的目光落在他手上，因为他停下来告诉我，这次面谈——他这样称呼——的目的是让他建立对我的全面档案，以便假设面谈成功，下次我的名字被无意标记时，“系统”会自动驳回我的案子。我随后会被允许进入美国，而无需这种HSI严厉盘问。

<a id="ch10-p008-en"></a>
‘What is a biennale?’, the officer asked. He was hard to read. I was not sure if this was a genuine question. He also asked who Salif Keita was and repeated his earlier question: ‘What do you do for work?’ ‘I am an artist’, I finally responded, hesitantly. ‘A visual artist’, I quickly clarified. I was myself starting to question what that actually meant and whether that was actually what I was. The officer unhurriedly took some notes. He must have felt my piercing eyes on his hand because he stopped to tell me that the object of the interview, as he called it, was for him to build a comprehensive profile of me, so that, assuming the interview was successful, next time my name was inadvertently flagged, the ‘system’ would automatically dismiss my case. I would then be admitted into the USA without the need for this HSI third-degree processing.

<a id="ch10-p009-zh"></a>
我暂时放松下来，直到官员再次问道：“什么是艺术？”我又仔细端详他的脸，却无法判断出任何单一情绪。我断定他是极其认真的。我吃了一惊，官员的问题——“什么是艺术？”——变成了“艺术做什么？”我记得，正如艺术家劳伦斯·阿布·哈姆丹会说的，按听者的准备程度说话对我最有利。我的听者很可能对我的热情并不认同，我必须非常注意自己说的话。然而，尽管怀着最好的意图，问题还是自行蒸馏为“艺术作业不做什么？”，从那里，我的头脑又诱使我转向“艺术作业撤销什么？”

<a id="ch10-p009-en"></a>
I momentarily relaxed until the officer asked again: ‘What is art?’ I took another close look at his face but could not determine a single emotion. I concluded he was deadly serious. Startled, the officer’s question – ‘what is art?’ – became ‘what does art do?’ I remembered that it was in my greatest interest to speak at the readiness of my listener, as artist Lawrence Abu Hamdan would say. My listener could very well be unsympathetic to my enthusiasm and I had to be very mindful of what I said. However, despite my best intentions, the question distilled itself into ‘what does artworking not do?’, and from there my mind tricked me into moving to ‘what does artworking undo?’

<a id="ch10-s02-zh"></a>
## **艺术作业不做什么？**

<a id="ch10-s02-en"></a>
## **What does artworking not do?**

<a id="ch10-p010-zh"></a>
当我坐在移民官对面，尽力圆满回答他的问题时，我的头脑在运算一个假设：艺术作品是艺术家行动的索引，艺术家是具有自由能动性的社会人物，能够把自身的感官、行动、运动及其他物质——以及他们所代表者的那些——解释并转化为具有文化价值的作品。由于我处于自我保全模式，我的思维引擎把这个公理倒转过来，艺术作品开始显示艺术工作者*不*做什么。

<a id="ch10-p010-en"></a>
As I sat opposite the immigration officer trying my best to answer his questions to his satisfaction, my mind was computing a hypothesis that an artwork is an index of the artist’s actions, whereby artists are social figures with free agency, capable of interpreting and transforming their senses, actions, movements and other matter – as well as those of whom they represent – into works of cultural value. As I was in self-preservation mode, my thinking engines inverted this axiom and an artwork started to reveal what the artworker does *not* do.

<a id="ch10-p011-zh"></a>
在此，艺术作品似乎显现为艺术工作者“非行动”的储藏库。非行动不是不作为。艺术作业很少是什么都不做；其生产总有能量与劳动的支出。它始终是一种物质现实，尽管有时无形。因此这种非活动确实是能量的支出，而这种能量正在*撤销*某物。这是因为艺术作品把自己置于它所从出的背景之前，这一涌现是社会、文化、有时（当它“成功”时）经济的脱离过程。反过来，这种脱离使一件艺术作品区别于其他艺术作品，也区别于一般的“工作”。这种从背景中的涌现本质上是一种指涉。

<a id="ch10-p011-en"></a>
Here, an artwork seemed to appear as a depository of what I saw as the ‘non-actions’ of the artworker. Non-actions are not inactions. Artworking is rarely doing nothing; there is always an expenditure of energy and labour involved in its production. It is always a material reality, though sometimes formless. Thus this non-activity is indeed an expenditure of energy and this energy is *undoing* something. This is because an artwork sets itself against the background from which it emerges, this emergence being a process of social, cultural and sometimes, when ‘successful’, economic detachment. In turn, this detachment is what distinguishes an artwork from other artworks, but also from ‘work’ in general. This emergence from the background is essentially a reference.

<a id="ch10-p012-zh"></a>
我不确定官员是否听懂了我的话，或者，即使听懂了，我也不确定他是否同意。他质疑我的假设也许有道理，因为悖论性地，这源于*拒绝*给予艺术作品所从出的指涉以前景。事实上，艺术作品*索要*前景；它设立新的前沿，使艺术作品脱离其背景。换言之，艺术作品*撤销*其指涉的前景，撤销其“先在性”。

<a id="ch10-p012-en"></a>
I am not sure if the officer understood what I was saying, or, if he did, I am not sure he agreed with me. He might be right to question my hypothesis because, paradoxically, it follows from *refusing* the foreground to the reference from which the artwork emerges. In fact, an artwork *claims* the foreground; it sets a new front and it detaches the artwork from its background. In other words, an artwork *undoes* the foreground of its reference, its ‘previousness’.

<a id="ch10-p013-zh"></a>
这时，官员问我出生在哪里。我并不总是欢迎这个问题，恰恰因为，作为艺术工作者，我的出生地有时是我可能努力撤销的“先在性”的一部分，因为人当然不可能既是艺术家又仍拥有国籍……我在心里想，实际上，艺术作品的吸引力、成功与被接受，都在这一张力的解决之中：尽管艺术家有非行动，作品仍涌现并使自己区别于背景，把自己物质化为具有文化价值的作品。我温和地指出，我的出生地写在护照上。

<a id="ch10-p013-en"></a>
By this time, the officer was asking me where I was born. I do not always welcome this question, precisely because, as an artworker, where I was born is sometimes part of my previousness that I may strive to undo, for surely one cannot be an artist and still have a nationality… Effectively, I thought, the attraction to an artwork, its success and its acceptance reside in the resolution of this tension: despite the artist’s non-action, the artwork emerges and distinguishes itself from the background, and materializes itself as work of cultural value. I pointed out, gently, that my place of birth was stated on my passport.

<a id="ch10-s03-zh"></a>
## **艺术作业与现实的“生成性”抹除**

<a id="ch10-s03-en"></a>
## **Artworking and the ‘generative’ erasure of reality**

<a id="ch10-p014-zh"></a>
我继续勤勉地回答移民官的问题，但我的头脑已开上自己的失控列车。一件作品通过“雕塑”成为艺术作品。艺术作品的涌现既是对物质的移除，也是赋形，其目的是转化对“现实”的感知。这是一个同样悖论的“生成性”抹除现象。即便在表演、跳舞或绘画时，艺术作业也在移除、亦即*重新*移动现实，通过景观化感知，把一种现实形式塑造成另一种。

<a id="ch10-p014-en"></a>
I continued to diligently answer the immigration officer’s questions, but my mind was on its own runaway train of thought. A work becomes an artwork through ‘sculpting’. The emergence of an artwork is both a removal and a shaping of matter, effected in order to transform the perception of ‘reality’. This is an equally paradoxical phenomenon of ‘generative’ erasure. Even when performing, dancing or painting, artworking *re*moves reality, shaping one form of reality into another, by landscaping perception.

<a id="ch10-p015-zh"></a>
此时官员正在检查我（荷兰）护照上的印章。这使我想起“景观”或荷兰语*landschap*，它源于对土地的塑造。我想到这种“造景”如何在大多数艺术领域中被观察到：现实被采作待塑造的原材料。人们可以把历史想成现实的来源，把社会想成现实的来源，把技术想成现实的来源，把规训想成现实的来源，把流行文化想成现实的来源，把谱系想成现实的来源，把语言想成现实的来源，等等。

<a id="ch10-p015-en"></a>
By now the officer was examining the stamps in my (Dutch) passport. This made me think of ‘landscape’ or *landschap* in Dutch, which originates from shaping the land. I thought about how this ‘scaping’ could be observed in most artistic fields whereby reality is sourced as raw material to be shaped. One can think of history as the source of reality, society as the source of reality, technology as the source of reality, discipline as the source of reality, popular culture as the source of reality, genealogy as the source of reality, language as the source of reality, and so on.

<a id="ch10-s04-zh"></a>
## **现实的来源及其在艺术作业中的显现**

<a id="ch10-s04-en"></a>
## **Sources of reality and their manifestation in artworking**

<a id="ch10-p016-zh"></a>
对这些现实来源的反思，指引我走向由这些来源“造景”所产生的艺术形式。例如，我想到某些艺术作品如何以技术作为其历史指涉，并暗示如果这种技术成为社会常态，未来可能是什么样。同样，档案及其内容作为取材于历史的艺术作品而出现。艺术工作者在其中的角色往往包括干预行为、编辑性重排、博物馆学呈现，以及支持或反对原始材料中历史叙述的论辩性或纠正性主张。除了其他明显好处，这种档案互动的能动性还起到赋予委托机构正当性的作用，即便作品对之持批判态度。

<a id="ch10-p016-en"></a>
Reflecting on these sources of reality pointed me to the artistic forms that result from the ‘scaping’ of these sources. For example, I thought how certain artworks take technology as their historical referent and suggest what the future might look like if this technology became the societal norm. Similarly, archives and their contents emerge as artworks that source history. The artworker’s role therein tends to include interventional acts, editorial reordering, museological presentations and polemical or corrective propositions for or against a historical account contained in the source material. Alongside other obvious benefits, the agency of such archival interactions serves to validate the commissioning institution, even where the work is critical of it.

<a id="ch10-p017-zh"></a>
接着我想到艺术作业机构如何以博物馆的保存律令为模型。当然，这对不出售或收藏艺术作品的机构也成立。我记得在某处读到的一个说法：就“差异性纳入”而言，艺术作业机构总是会从艺术作品的善意——以及对立的敌意——中获益。然后我落到社会参与式艺术作业上，这也是我自己的实践经常被归入的类别。我听见内心耳朵里的低语。社会参与式艺术作业往往通过从社区获取现实来进行，从委托机构扩展街区、网络或集群中社区群体的人力、社会、历史与文化资源中取材。这些互动的成果之前有工作坊：邀请专家主持学习项目，使艺术家与参与者或贡献者受益，有时也使机构受益。从这些工作坊中可能产生艺术作品。它们可能是工作坊的录音、由社区成员主办或包括社区成员的新活动，以及通过某种可转移技能工作坊制作的工艺物品。集体制作的物品可以作为展览重新分配，或在社区中分配给相关利益方。有时艺术作品是“有用的”，例如公共艺术作品：除了象征方面，它们还在委托机构内外具有功能目的。

<a id="ch10-p017-en"></a>
Next I thought about how artworking institutions are modelled after the preservative imperative of the museum. This is, of course, also the case for institutions that do not sell or collect artworks. I remembered an expression I had read somewhere: in terms of ‘differential inclusion’, an artworking institution will always benefit from the benevolence – and the antagonism – of an artwork. I then landed on socially engaged artwork, which is the way my own practice is regularly categorized. I heard whispers in my inner ear. Socially engaged artwork tends to be undertaken through sourcing reality from the community, drawing from the human, social, historical and cultural resources of community groups in the expanded neighbourhood, network or cluster of the commissioning institution. The outcomes of these interactions are preceded by workshops where an expert is invited to lead a programme of learning that benefits the artist and the participants or contributors and sometimes also the institution. From these workshops, artworks may emerge. They might be recordings of the workshops, new events hosted by or including members of the community, as well as craft-based objects produced through some kind of transferable skills workshop. The collectively produced objects could be redistributed as exhibitions, or distributed across the community to the stakeholders involved. At times, the artworks are ‘useful’, as in the case of public artworks, for instance: beyond their symbolic aspect, these also have a functional purpose inside or outside the commissioning institution.

<a id="ch10-p018-zh"></a>
我继续沉溺于思考：从谱系背景中涌现的艺术作品，如何通过教育的原型发展出来。其中许多被描述为研究型项目、策展研究或艺术研究，其实质与成果都是物质的，即便焦点是一个主题、定理、论文或理论，并可能以学位、奖学金或艺术作业机构的关联职位的形式得到回报。这些活动可以呈现为综述区域、国家或跨国主题的调查展；双年展及其卫星附录；或作为研究展览中的搬演，反之亦然。展出的作品可能包括档案、影片、部分或完整的图书馆，以及作为教学枢纽或工作站的布景或场景。随附的卷册或图录会出版。此处关键的不是作品的独异性，而是每件作品对一个主题、策展课题或立场的论证能力。

<a id="ch10-p018-en"></a>
I continued to indulge in thinking about how artworks that emerge from the background of genealogy are developed through the archetypes of education. Many of them are described as research-based projects, curatorial research or artistic research, and their substance and their outcome are material, even when the focus is a theme, a theorem, a thesis or a theory that may be rewarded in the form of an academic degree, a fellowship or an associate position at an artworking institution. These activities may be presented as survey exhibitions that overview regional, national or transnational thematics; as biennales and their satellite appendixes; or as stagings within research exhibitions and vice versa. The exhibited works may include archives, films, partial or complete libraries and settings or scenes that function as pedagogical hubs or working stations. Accompanying volumes or catalogues are published. What is crucial here is not the singularity of the work but the argumentative ability of each work towards one thematic, curatorial subject or position.

<a id="ch10-p019-zh"></a>
同样的谱系背景也可以从“身体”范畴中取材，解剖身体、社会身体、文化身体、公共身体、历史身体或政治身体，都作为待重塑的现实来源。对现实感知的重塑在起作用，而取材于身体显现的艺术作品参与了这一重塑。这些作品的生产过程往往涉及“表演”，而这一范畴与艺术概念本身一样狭窄而宽泛。

<a id="ch10-p019-en"></a>
The same genealogical background can be sourced from the categories of the ‘body’, whereby the anatomical body, the social body, the cultural body, the public body, the historical body or the political body all serve as a source of reality to be reshaped. A reshaping of the perception of reality is at play and the artwork that sources the manifestations of the body partakes in this reshaping. The processes through which these artworks are produced tend to involve ‘performance’, which is a category as narrow and as broad as the concept of art itself.

<a id="ch10-p020-zh"></a>
表演的目标是做什么或达成什么。在金融与管理习语中，performance（业绩）是行动者——例如资产、资源或产品——之属性与特征的指标。例如，销售代理人如果达到或超过销售目标，就表现良好。网站或应用如果吸引读者、下载或使用时长，就表现良好。换言之，业绩与劳动相连，而由于凡有劳动处即有剥削，业绩表明这种剥削如何能被最小化——或最大化。这种剥削的收益有时以薪水、奖金、利润或亏损来表达，但其尺度——尽管任意——是相关行动者或机构表现得多好或多坏。

<a id="ch10-p020-en"></a>
The objective of a performance is to do something or to achieve something. In financial and managerial idioms, performance is an indicator of the properties and the attributes of an actor; for example, an asset, a resource or a product. A sales agent, for instance, performs well if they meet or exceed their sales target. A website or an app performs well if it attracts readership, downloads or airtime. In other words, performance is linked to labour and, because wherever there is labour there is exploitation, performance indicates how such exploitation can be minimized – or maximized. The yield of this exploitation is sometimes expressed through a salary, a bonus, a profit or a loss, but its measure, albeit arbitrary, is how well or how badly the actor or agency in question has performed.

<a id="ch10-p021-zh"></a>
但*我*表现如何？我会被允许重新入境吗？也许此时我并不真的在意，继续向官员解释艺术“撤销”什么。表演是一个有力的范畴，用来考察作为非行动储藏库的艺术作品，因为它不同于其他艺术作业范畴——那些范畴植根于艺术家工作室的传统，和／或其通常不对观看公众开放的当代等价工作空间。表演当然可能需要使用工作室来研究、排练和发展，但其交付与体验依赖于观众在场，同时艺术工作者（重新）生产作品——同时劳作。因此，艺术工作者与公众的双重在场才是表演的实际产品；这是前提条件，有时甚至是作品生产背后的目的与动机。表演似乎在说：我存在。这个身体存在。这个某人存在。我的经验以及产生它的存在具有德性、价值、有效性或紧迫性。

<a id="ch10-p021-en"></a>
But how was *I* performing? Was I going to be allowed back into the country? Maybe I did not really care at this point, continuing to explain what art ‘undoes’ to the officer. Performance is a compelling category for examining an artwork as a depository of non-actions, being unlike other categories of artworking that are rooted in the tradition of an artist studio and/or its contemporary equivalent working spaces that are usually inaccessible to the viewing public. A performance may of course require the use of a studio to research, rehearse and develop the performance, but the delivery and the experience rely on the presence of an audience while the artworkers (re)produce the work – while labouring. The double presence of the artworkers and the public is thus the actual product of a performance; it is a prerequisite, and sometimes even the object and motivation behind the production of the work. A performance seems to say: I exist. This body exists. This somebody exists. There is virtue, value, validity or urgency to my experience and to the existence that produces it.

<a id="ch10-p022-zh"></a>
即便艺术家通过远程出场基础设施预先录制或现场出现在屏幕上，或者艺术家招募代理人、参与者或合作者代表艺术家施行表演，重要的仍是艺术家——或其所代表者——的在场、传记、存在、问题、身体。表演是身体事务的生产，以及这种身体能够存在的社会与文化条件。这是一个确认身体事务及其生命的过程。表演在展示空间中的文化评价、流通与分配，取决于委托或自主发起活动的公众出席。为此，表演似乎需要公众和一个舞台，表演在此发生、展开、纠正、补偿或处理特定的历史、问题、记忆或未来。此外，“生产”公众与舞台也是表演的目的。机构目标可能是举办活动、工作坊与表演，以生产新政策与新公众。因此，即便表演是越界的，这也有助于为表演艺术家与委托事业或机构积累更多社会地位。

<a id="ch10-p022-en"></a>
Even when an artist appears either pre-recorded or live on a screen via a remote appearance infrastructure, or when the artist enlists deputies, participants or collaborators that carry out the performance on the artist’s behalf, what matters is the presence, the biography, the existence, the problem, the body of the artist or what/who they represent. Performance is the production of body matters, and the social and cultural conditions in which such a body can exist. It is a process of affirmation of the matters of the body and its lives. The cultural valuation, circulation and distribution of performance in spaces of display depend on the public attendance of commissioned or self-initiated events. For this, performance seems to necessitate a public and a stage on which a performance takes place, and unfolds, corrects, redresses or addresses a given history, problem, memory or future. Furthermore, it is the object of a performance to ‘produce’ a public and a stage. It can be an institutional aim to stage events, workshops and performances in order to produce new policies and new publics. As such, even when the performance is transgressive, this serves to accumulate further social standing for the performing artist and the commissioning cause or institution.

<a id="ch10-p023-zh"></a>
在这个意义上，表演似乎为一切艺术作业形式提供燃料。但艺术作业在表演什么，为什么——为了达成什么？表演的最终目的是什么，它*不*做什么？换言之，艺术工作者的表演以何种方式塑造和重塑现实？艺术家的在场如何揭示他们所撤销的东西？艺术家的表演以何种方式揭示他们的非行动？艺术家在任何展示空间——家庭、公共或私有——中的在场，都被框定为在中心或边缘的“归属”。实际上，归属是表演的目的。表演以及一般意义上的艺术作业，是确认归属的过程，而争论在于承认什么是中心、什么是边缘。

<a id="ch10-p023-en"></a>
In this sense, performance seems to fuel every form of artworking. But what is artworking performing and why – to achieve what? What is the finality of the performance and what does it *not* do? In other words, in what way does an artworker’s performance shape and reshape reality? How can the presence of the artist reveal what they have undone? In what ways can an artist’s performance reveal their non-actions? The presence of the artist in any given space of display, be it domestic, public or privately owned, is framed as a ‘belonging’ in the centre or in the margin. In effect, belonging is the object of performance. Performance and artworking in general are a process of affirming belonging, and the contention resides in the recognition of what the centres are and what the margins are.

<a id="ch10-s05-zh"></a>
## **美的艺术作业与一切艺术作业的金标准**

<a id="ch10-s05-en"></a>
## **Fine artworking and the gold standard of all artworking**

<a id="ch10-p024-zh"></a>
我接着思考，*美的艺术*（fine art）——至少在英语中——是为艺术而艺术，就艺术作业的最终目的是艺术本身而言；但我也想到，美的艺术这一名称也许是艺术作业的一种特定金融分类。美的艺术甚至可能是这类艺术所代表之阶级的象征性不朽化。换言之，美的艺术自称不受政治困扰，是一种隐蔽的主张：保存它所从出的社会指涉。

<a id="ch10-p024-en"></a>
I went on to think about how *fine art*, at least in English, is art for art’s sake, in the sense that the finality of artworking is art itself, but I also thought that the denomination of fine art might be a specific financial categorization of artworking. Fine art might even be the symbolic immortalization of the class that such art represents. In other words, fine art’s claim to be unbothered by the political is a veiled claim to conserve the social reference from which it emerges.

<a id="ch10-p025-zh"></a>
确实，艺术作业有时假定脱离现实，但（美的）艺术实际上从（艺术）历史中汲取现实，作为它据以塑造自身的首要现实来源，但这一次没有对这样的背景进行去形或撤销。艺术作品也可以对另一件艺术作品提供评论。当然，它也可以对流行文化作品或非美的艺术作品提供评论。这些相互评论有很大价值。例如，一件美的艺术作品可以反对先前历史中美的艺术作品的缺席：艺术作品可以由一个代表性不足的社区成员创作。

<a id="ch10-p025-en"></a>
Indeed, sometimes artworking supposes detachment from reality, but (fine) art, in fact, draws from (art) history as the primary source of reality from which it shapes itself, but this time without unshaping or undoing such background. An artwork may also offer a commentary on another artwork. It can, of course, also offer a commentary on a work from popular culture or a non-fine artwork. There is great merit to these mutual commentaries. For instance, a fine artwork can speak against the absence of fine artworks in previous histories: an artwork can be produced by a member of an under-represented community.

<a id="ch10-p026-zh"></a>
这种代表性不足意味着收藏不足，而这通常最终归结为终于融入一个迄今拒绝其部分成员的世界。融入可能意味着适应或接受不正义，而这可能意味着那些不正义将继续。无论这种差异性纳入的姿态显得多么含糊，反对蓄意缺席可能是关键而紧迫的，因为一件潜在或实际被博物馆收藏的美的艺术作品，是一切艺术生产的金标准。

<a id="ch10-p026-en"></a>
This under-representation means under-collected and this generally culminates in finally fitting into a world that has thus far rejected some of its members. To fit in may impute adjusting to or accepting injustice, and this could mean that those injustices will continue. However ambiguous this gesture of differential inclusion may appear, speaking against deliberate absences can be crucial and urgent, because a fine artwork, virtually or actually collected by a museum, is the gold standard of all artistic productions.

<a id="ch10-p027-zh"></a>
这里我想起艺术家兼研究者埃玛·沃卢考-瓦南布瓦的评论：博物馆不应只被理解为一栋“作为一个去看艺术的地方”的建筑；博物馆还应被理解为其“在美的艺术话语场语境中的功能”。这是因为，至少“在西方美的艺术话语中，‘博物馆’实质上起着金标准的作用——价值的担保人。即便你从未去过博物馆，更不用说让你的作品被博物馆收藏，对其存在价值的信念，以及关于其位置与功能的相对共识，意味着艺术话语场中存在的、发生的一切，都以某种方式与它相关——即便这种关系是对立的。”<a id="ref-zh-ch10-2"></a>[2](#note-zh-ch10-2)

<a id="ch10-p027-en"></a>
The comments artist and researcher Emma Wolukau-Wanambwa came to mind here: the museum should not only be understood as a building ‘in the sense of a place to go and look at art’; a museum should also be understood in ‘its function within the context of fine art’s discursive field’. This is because, at least ‘within Western fine art discourses, the “museum” essentially functions as a gold standard – a guarantor of value. Even though you may never go to a museum, let alone have your work collected by one, belief in the merits of its existence and a relative consensus regarding its position and function means that pretty much everything that exists and occurs within art’s discursive field somehow happens in relation to it – even when that relation is antagonistic.’<a id="ref-en-ch10-2"></a>[2](#note-en-ch10-2)

<a id="ch10-p028-zh"></a>
在这个意义上，“美的”艺术，或现实或观念中的博物馆内的艺术，是评价并因此使所有其他艺术表达不朽的艺术。

<a id="ch10-p028-en"></a>
In that sense ‘fine’ art or the art inside the actual or virtual museums is the art that evaluates and therefore immortalizes all other artistic expressions.

<a id="ch10-s06-zh"></a>
## **线上与线下的中心与边缘**

<a id="ch10-s06-en"></a>
## **Online and offline centres and margins**

<a id="ch10-p029-zh"></a>
读者也许会高兴地得知，我顺利重新入境，没有更多麻烦。事实上，我正在纽约的书桌前写这些，周围是一个珍爱的家所能带来的一切舒适。然而，再一次，任何读者都会意识到，2019年12月初的世界与当下2020年5月的时刻大不相同：

<a id="ch10-p029-en"></a>
The reader might be pleased to learn that I was admitted back into the country without further complications. In fact, I am writing this at my desk in New York, surrounded by all the comforts that a cherished home can bring. However, once again, as any reader will be aware, the world of early December 2019 differs greatly from the present moment of May 2020:

<a id="ch10-p030-zh"></a>
Covid-19的爆发迫使所有公共生活骤然停止，并主要从私人住宅中继续进行——对那些负担得起住宅的人而言。我仍然想着与移民官的遭遇，他问我如何谋生。好问题。我回避了这个问题，含糊地解释艺术作品的最终目的确实在于它能被交易。这种交易当然是金融性的，但它定义了跨越博物馆与资助机构轨道系统，以及其间基础设施——包括商业画廊及其慈善家、经销商、艺博会、非营利机构和艺术学校网络——的跨文化交易。“为什么蒙德里安基金会要支持荷兰以外的项目？”官员问我。

<a id="ch10-p030-en"></a>
the outbreak of Covid-19 has forced all public life to grind to an abrupt halt and to proceed mostly from private homes, for those who can afford them. I still think about the encounter with the immigration officer, who asked me how I earn a living. Good question. I avoided the question by explaining vaguely how the finality of an artwork indeed resides in its ability to be transacted. This transaction is of course financial, but it defines the transcultural transactions across the orbital system of the museum and funding institutions alike, and the infrastructures in between, including the commercial gallery, and its network of philanthropists, dealers, art fairs, not-for-profit institutions and art schools. ‘Why would The Mondriaan Fund want to support projects outside the Netherlands?’, the officer asked me.

<a id="ch10-p031-zh"></a>
在某种意义上，这个问题的答案是对艺术作品所做的双重而同时的归属运动的反思：从边缘到中心，反之亦然。蒙德里安基金会是一种观念形态的博物馆，而任何博物馆都是艺术作业想象中的最终归宿，是有意识地或无意识地担保：保存文化上重要的身体，以承认与（再）分配的形式搬演正义。但在这个金融化、交易性的生态系统中，真正重要的身体是某种*经济人*（*Homo economicus*）的身体，一个交易者。<a id="ref-zh-ch10-3"></a>[3](#note-zh-ch10-3) 这样，博物馆就是一具活着的石棺，一座*经济人*的公共坟墓。在这里重复它们几乎显得多余，但那一刻，安德烈·巴赞的话冲进我的大脑：

<a id="ch10-p031-en"></a>
In a way, the answer to this question is a reflection on the double and simultaneous movements of belonging that an artwork makes, from margins to the centres, and vice versa. The Mondriaan Fund is a virtual type of museum, and any museum is the imagined finality of artworking, the conscious or inadvertent guarantor of keeping the body that matters culturally, of staging justice in the form of recognition and (re)distribution. But in this financialized, transactional ecosystem, the body that really matters is that of *Homo economicus* of some sort, a trader.<a id="ref-en-ch10-3"></a>[3](#note-en-ch10-3) In this way, the museum is a living sarcophagus, a public sepulchre of *Homo economicus*. It is nearly obsolete to repeat them here, but at that moment the words of André Bazin came rushing through my brain:

<a id="ch10-q001-zh"></a>
<a id="ch10-q002-zh"></a>
> 在绘画与雕塑的起源处，存在一种木乃伊情结。古埃及宗教旨在对抗死亡，认为生存取决于肉体的持续存在。因此，通过提供对时间流逝的防御，它满足了人类一种基本的心理需要，因为死亡不过是时间的胜利。人为地保存他的身体外观，就是把它从时间之流中夺走，可以说，把它整齐地收进生命的货舱。因此，面对死亡的现实，通过保存血肉与骨骼来维持外观，是很自然的。<a id="ref-zh-ch10-4"></a>[4](#note-zh-ch10-4)

<a id="ch10-q001-en"></a>
<a id="ch10-q002-en"></a>
> at the origin of painting and sculpture there lies a mummy complex.  The religion of ancient Egypt, aimed against death, saw survival as  depending on the continued existence of the corporeal body. Thus,  by providing a defence against the passage of time it satisfied a basic  psychological need in man, for death is but the victory of time. To preserve, artificially, his bodily appearance is to snatch it from the  flow of time, to stow it away neatly, so to speak, in the hold of life.  It was natural, therefore, to keep up appearances in the face of the  reality of death by preserving flesh and bone.<a id="ref-en-ch10-4"></a>[4](#note-en-ch10-4)

<a id="ch10-s07-zh"></a>
## **艺术作业的普遍可变性**

<a id="ch10-s07-en"></a>
## **Universal variability of artworking**

<a id="ch10-p032-zh"></a>
事实上，为了让移民官相信我不是“坏人”，我告诉他，我在巴马科双年展获得了欧盟艺术奖。这让我想到一般的艺术家奖项公告，它们往往附有评奖委员会成员的简短引语，他们专注于这个问题：艺术家以何种方式“保存”同时“推进”了其知识领域？此处的假设是，获奖作品由一种从既定、可核实、可量化的现象中取材的现实塑造而成，但以新颖而独特的方式，反映了作品生产的时间、空间、文化、社会与历史时刻。换言之，作品在许多方面必须与艺术史中既有作品相似，但新作品也必须在一个或多个重要方面可区分。如果是这样，那么现实塑造便通过*采样*现实来进行。

<a id="ch10-p032-en"></a>
In fact, in order to convince the immigration officer that I was not ‘a bad guy’, I told him that I had received the European Union Art Prize at the Bamako Biennale. This made me think of the announcements of artist prizes in general, which tend to be accompanied by brief quotations from the awarding jury panel members, who preoccupy themselves with this question: in what way has the artist ‘preserved’ and at the same time ‘advanced’ their field of knowledge? The assumption here is that the winning artwork is shaped from a reality sourced from a given, verifiable and quantifiable phenomenon, but in a novel and distinct way that reflects the time, space, culture, society and historical moment in which the artwork is produced. In other words, the artwork has to be similar in many respects to the existing artworks from art history, but the new artwork also has to be distinguishable in one or more significant ways. If this is the case, then the shaping of reality proceeds by way of *sampling* reality.

<a id="ch10-p033-zh"></a>
在与移民官遭遇期间，我的头脑确实毫不留情，悖论不断堆积，源于艺术作业的律令：不仅保存文化或现实，还要把这个必死的、短暂性的现实转化为某种不死而不可动摇的东西。艺术作业不仅是“我存在”的表演，尤其是“我将存在”的表演。悖论性地，美的艺术作业还宣告“我一直存在”。艺术作业这种想象性的先在，把个体的“我”转化为普遍的“我”，转化为一种建立普遍变量的主体性。确立艺术作业的这种普遍可变性，旨在转化并保存主体、文化与现实，使其延续超出自身物理存在与显现的范围。不可避免地，这种通过在未来再现文化来保存文化的需要，必然会与关于过去、现在因而关于现实未来应当如何的对立愿景发生冲突。

<a id="ch10-p033-en"></a>
During my encounter with the immigration officer, my mind really was unsparing, and paradoxes piled up, born of artworking’s imperative to not only preserve culture or reality, but also transform this mortal and transitory reality into something immortal and intransigent. Artworking is not only the performance of ‘I exist’, but especially of ‘I shall exist’. Paradoxically, fine artworking also proclaims ‘I have always existed’. This imagined pre-existence of artworking transforms the individual ‘I’ into a universal ‘I’, into a subjecthood that institutes a universal variable. The institution of this universal variability of artworking aims at transforming and preserving subjects, cultures and realities beyond their physical existence and manifestations. Inevitably, this need to preserve culture by representing it in the future is bound to clash with opposing visions of what the past, the present and therefore the future of reality should be.

<a id="ch10-p034-zh"></a>
如果这种现实采样的目的是生产一个普遍变量，那么同一种现实采样也可能生产文化、社会与政治边缘：艺术家的本性就是把他们的现实感知为边缘的，即便他们本人就是中心或代表中心。奖项、奖励乃至委托，都是这种矛盾的例子：中心被感知为边缘。我觉得，在博物馆关闭的这一刻，这一悖论只会加剧。

<a id="ch10-p034-en"></a>
If the object of such sampling of reality is to produce a universal variable, this same sampling of reality can also produce cultural, social and political margins: it is the nature of artists to perceive their reality as marginal, even where they themselves are or represent the centre. A prize, an award or even a commission is an example of such contradiction, whereby the centre is perceived as the margin. I felt that this paradox only became heightened at this moment of the museum closures.

<a id="ch10-s08-zh"></a>
## **从指涉性到构成性艺术作业？**

<a id="ch10-s08-en"></a>
## **From referential to compositional artworking?**

<a id="ch10-p035-zh"></a>
“社会生态／呈现灾难”是我本应在伦敦ICA“思考艺术”会议上参与的专题小组标题。我不确定我在这里是否处理了这个主题，但我了解到，尽管悖论本身不是问题，我仍不得不下结论：当前的物理隔离状况迫使博物馆重新思考自己身体的显而易见性。实际上，由于目前不可能与构成博物馆固有纪念实践的大多数物质实体发生身体接近，艺术机构纷纷把内容数字化，在正常开放时间之外呈现，其方式与艺术家工作和运作的方式大体相同。计算机与互联网显然相当物质，但其物质方式不同于给绘画和雕塑赋形的结构——艺术作业的祖灵。但在这个过程中，博物馆的收藏越多，其线上在场就越缺乏说服力：机构越具制度性，就越受一种原则性软弱的折磨，无法有意义地回应当下的紧迫性。这种尴尬的无能也许可以由它们“保存”而非干预的律令来解释。在某种意义上，这一目标也有助于解释艺术作业为何生产家中的陌生人：用艺术家兼理论家科乔·埃顺一封电子邮件的话说，这是因为灾难——当前情形下是一场大流行病——同时夸大了所有反保守、超保守与后保守的倾向。

<a id="ch10-p035-en"></a>
’Social Ecologies/Presenting Catastrophe’ is the title of the panel to which I would have contributed at the ‘Thinking Art’ conference at the ICA in London. I am not sure if I have addressed this theme here, but I have learnt that, although paradoxes are not problems as such, I am compelled to conclude that the current situation of physical distancing has forced the museum to rethink the obviousness of its own body. In effect, since bodily proximity to most of the material substances that constitute the memorial practice inherent to the museum is currently impossible, art institutions have rushed to render their content digitally, beyond their normal opening hours, in much the same way that artists work and operate. Computers and the Internet are obviously quite material, but differently so from the structures that give shape to painting and sculpture – the ancestral ghosts of artworking. But in this process, the more the museum has a collection, the more unconvincing their online presence has become: the more institutional an institution, the more it suffers from a principled infirmity to respond meaningfully to the urgency. This awkward illiteracy might be explained by their mandate to ‘conserve’, as opposed to intervene. In a way, this objective could also help to explain why artworking produces strangers at home: it is, to paraphrase an email from artist and theorist Kodwo Eshun, because a catastrophe – a pandemic, in the current case – exaggerates all anti-conservative, hyperconservative and post-conservative tendencies at the same time.

<a id="ch10-p036-zh"></a>
以结论的面貌，回到我故意不加质疑、不加问题化地谈论的“现实”是有意义的，因为篇幅有限。用哲学家兼教育家埃马纽埃尔·巴尼韦西泽的话说，这是一种状况，其当下的历史已经驶向一个由知识与数字技术控制所驱动的未来航程，这种控制由容纳政治威权主义的极权资本主义强制执行并主导。这个未来远非可预测，它不稳定、不确定。它孕育着多重危机与致命威胁、野蛮、敌意，正如多项关闭边境的决定、退入民族主义例外论，以及持续存在的各种话语所示——这些话语由一种挥之不去的诱惑所塑造：把同类人类中的某些阶层置于死地，这些阶层的成员仍被视为低劣，可被转化为“科学”进步与权力确认的豚鼠。除了对数字革命的庆祝，面对行星性的病毒威胁，当下表现为“人类危机——人类未能设法构成自身的人性，因此，是地球仍无法成为一个世界的危机，也是人类仍无法完成其人性的危机”。<a id="ref-zh-ch10-5"></a>[5](#note-zh-ch10-5) 这场危机对身体、感觉、情感、智力等等构成挑战。尤其，它挑战教育、再现与保存机构作为知识及关系之生产与传播空间的角色。挑战在于从一切生命形式所实践的知识中汲取，重建新的想象空间，走向一种能够毫不含糊地把握所有人类——事实上也包括所有非人类，以及非人类的人类——共属于一种共同生活的新思想。如此，艺术作业就可以从异化的指涉模式转向一种构成性实践，作为一场在共同脆弱性面前提高所有人责任感的运动。

<a id="ch10-p036-en"></a>
In the guise of a conclusion, it makes sense to return to the ‘reality’ about which I have deliberately spoken without questioning or problematizing it, because of the lack of space. In the words of philosopher and educator Emmanuel Banywesize, it is a condition whose present history has embarked on a future course driven by the control of knowledge and digital technologies, enforced and dominated by a totalitarian capitalism which accommodates political authoritarianisms. Far from being predictable, this future is unstable and uncertain. It harbours multiple crises and deadly threats, barbarities, enmities, as shown by the multiple decisions to close borders, by the withdrawal into nationalistic exceptionalisms, and by the persistence of discourses informed by the enduring temptation to inflict death on layers of fellow humans whose members are still perceived as inferior and transformable into guinea pigs for ‘scientific’ progress and the affirmation of power. Beyond the celebration of the digital revolution, and in the face of planetary viral threats, the present manifests itself in ‘the crisis of humanity which cannot manage to constitute its own humanity, and therefore, the crisis of the globe still incapable of becoming a world, and the crisis of humans still unable to accomplish their humanity’.<a id="ref-en-ch10-5"></a>[5](#note-en-ch10-5) This crisis constitutes a challenge to bodies, feelings, emotions, intelligence and more. In particular, it challenges the educational, representational and conservational institution as a space for the production and transmission of knowledge and relations. The challenge consists in rebuilding new spaces for the imaginary, drawing from the knowledge practised by all forms of life, toward a new thought capable of apprehending, unambiguously, the co-belonging of all humans – and in fact also all non-humans, and the non-human humans – to a common life. In so doing, artworking could move from the estranging referential mode to a compositional praxis, as a movement that heightens the responsibility of all, in the face of a shared vulnerability.

### 原注

<a id="ch10-n001-zh"></a><a id="note-zh-ch10-1"></a>
[1] 我原为2020年2月底伦敦CRMEP—ICA“思考艺术”会议准备了这篇演讲。然而，预料到为应对持续的Covid-19大流行而即将实施的全球封锁（写作时这些措施已生效），我不得不取消行程，未能出席会议。 [返回](#ref-zh-ch10-1)

<a id="ch10-n001-en"></a><a id="note-en-ch10-1"></a>
[1] I had prepared this presentation as an address to the CRMEP–ICA *Thinking Art* conference in London at the end of February 2020. However, I had to cancel my travel in anticipation of the global lockdowns now in effect in response to the ongoing Covid-19 pandemic, and did not attend the conference. [返回](#ref-en-ch10-1)

<a id="ch10-n002-zh"></a><a id="note-zh-ch10-2"></a>
[2] Emma Wolukau-Wanambwa, 与 Aïcha Diallo 的对谈, *Contemporary And*, 1 October 2014, www.contemporaryand.com/magazines/a-lot-has-changed-in-the-four-years-since-i-started-visiting-kampala（2015年11月20日访问）。 [返回](#ref-zh-ch10-2)

<a id="ch10-n002-en"></a><a id="note-en-ch10-2"></a>
[2] Emma Wolukau-Wanambwa, in conversation with Aïcha Diallo, *Contemporary And*, 1 October 2014, www.contemporaryand.com/magazines/a-lot-has-changed-in-the-four-years-since-i-started-visiting-kampala (accessed 20 November 2015). [返回](#ref-en-ch10-2)

<a id="ch10-n003-zh"></a><a id="note-zh-ch10-3"></a>
[3] Sylvia Wynter, ‘Africa, the West and the Analogy of Culture: The Cinematic Text after Man’, in Jane Givanni, ed., *Symbolic Narratives/African Cinema: Audiences, Theory and the Moving Image*, London: British Film Institute, 2000。 [返回](#ref-zh-ch10-3)

<a id="ch10-n003-en"></a><a id="note-en-ch10-3"></a>
[3] Sylvia Wynter, ‘Africa, the West and the Analogy of Culture: The Cinematic Text after Man’, in Jane Givanni, ed., *Symbolic Narratives/African Cinema: Audiences, Theory and* *the Moving Image*, London: British Film Institute, 2000. [返回](#ref-en-ch10-3)

<a id="ch10-n004-zh"></a><a id="note-zh-ch10-4"></a>
[4] André Bazin, ‘The Ontology of the Photographic Image’, in Andre Bazin, *What Is Cinema?*, vol. 1, Berkeley: University of California Press, 2005 (1967), pp. 9–16, p. 9。 [返回](#ref-zh-ch10-4)

<a id="ch10-n004-en"></a><a id="note-en-ch10-4"></a>
[4] André Bazin, ‘The Ontology of the Photographic Image’, in Andre Bazin, *What Is* *Cinema?*, vol. 1, Berkeley: University of California Press, 2005 (1967), pp. 9–16, p. 9. [返回](#ref-en-ch10-4)

<a id="ch10-n005-zh"></a><a id="note-zh-ch10-5"></a>
[5] Edgar Morin, *Pour sortir du XXe siècle*, Paris: Fernand Nathan, 1981, p. 345，英译为本文作者所译，转引自 Emmanuel Banywesize Mukambilwa, ‘L’humanisme comme pilier de la Politique pour la vie. Réflexion sur le Covid-19’, April 2020，发表于 Centre d’art Waza 2.0——一个由卢本巴希同名艺术机构发起的 WhatsApp 群组。 [返回](#ref-zh-ch10-5)

<a id="ch10-n005-en"></a><a id="note-en-ch10-5"></a>
[5] Edgar Morin, *Pour sortir du XXe siècle*, Paris: Fernand Nathan, 1981, p. 345, my translation, cited in Emmanuel Banywesize Mukambilwa, ‘L’humanisme comme pilier de la Politique pour la vie. Réflexion sur le Covid-19’, April 2020, published in Centre d’art Waza 2.0, a WhatsApp group initiated by the Lubumbashi-based art institution of the same name. [返回](#ref-en-ch10-5)

# 书后材料

<a id="back-credits-h-zh"></a>
## **图片来源与版权**

<a id="back-credits-h-en"></a>
## **Image credits**

<a id="back-credits-01-zh"></a>
## 导论

<a id="back-credits-01-en"></a>
## INTRODUCTION

<a id="back-credits-02-zh"></a>
*Structura Concept*，贝尔格莱德，2019

<a id="back-credits-02-en"></a>
*Structura Concept*, Belgrade, 2019

<a id="back-credits-03-zh"></a>
## 唯物主义

<a id="back-credits-03-en"></a>
## MATERIALISMS

<a id="back-credits-04-zh"></a>
*Digital Deineka*，莫斯科特列季亚科夫画廊，2015

<a id="back-credits-04-en"></a>
*Digital Deineka*, Tretyakov Gallery, Moscow, 2015

<a id="back-credits-05-zh"></a>
（*At the Construction of New Workshops*，1926）

<a id="back-credits-05-en"></a>
(*At the Construction of New Workshops*, 1926)

<a id="back-credits-06-zh"></a>
## 艺术与劳动

<a id="back-credits-06-en"></a>
## ART & LABOUR

<a id="back-credits-07-zh"></a>
*Maintenance Work*，安达卢西亚贝赫尔-德拉弗龙特拉，NMAC 基金会，2018

<a id="back-credits-07-en"></a>
*Maintenance Work*, Fundacion NMAC, Vejer de la Frontera, Andalusia, 2018

<a id="back-credits-08-zh"></a>
## 形式的不稳定性

<a id="back-credits-08-en"></a>
## INSTABILITIES OF FORM

<a id="back-credits-09-zh"></a>
*Picture Window*，巴塞尔，2019

<a id="back-credits-09-en"></a>
*Picture Window*, Basel, 2019

<a id="back-credits-10-zh"></a>
## 社会生态、灾难预感

<a id="back-credits-10-en"></a>
## SOCIAL ECOLOGIES, INTIMATIONS OF CATASTROPHE

<a id="back-credits-11-zh"></a>
*Die-In*，圣但尼，巴黎第八大学，2019

<a id="back-credits-11-en"></a>
*Die-In*, University of Paris-8, Saint-Denis, 2019

<a id="back-credits-12-zh"></a>
所有照片 © 彼得·奥斯本

<a id="back-credits-12-en"></a>
All photographs © Peter Osborne

<a id="back-contrib-h-zh"></a>
## 作者简介

<a id="back-contrib-h-en"></a>
## Contributors

<a id="back-contrib-01-zh"></a>
**卡罗琳·巴塞特**是剑桥大学数字人文教授。她的研究涉及媒介技术、批判理论、女性主义与文化变迁。晚近发表包括关于人工智能与行为主义、性别与数字媒介史的研究。她最新的著作是与萨拉·肯伯、凯特·奥赖尔登合著的《Furious: Technological Feminism and Digital Futures》（Pluto，2020）。

<a id="back-contrib-01-en"></a>
**Caroline Bassett** is Professor of Digital Humanities at Cambridge University. Her research explores media technology, critical theory, feminism and cultural change. Recent publications include work on AI and behaviourism, and on gender and digital media history. Her latest book is *Furious: Technological Feminism and Digital Futures* (Pluto, 2020), co-authored with Sarah Kember and Kate O’Riordan.

<a id="back-contrib-02-zh"></a>
**戴夫·比奇**是伦敦艺术大学艺术与马克思主义准教授（Reader）。著有《Art and Value: Art’s Economic Exceptionalism in Classical, Neoclassical and Marxist Economics》（Brill，2015），该书入围多伊彻纪念奖；《Art and Postcapitalism: Aesthetic Labour, Automation and Value Production》（Pluto，2019）；以及《Art and Labour: On the Hostility to Handicraft, Aesthetic Labour and the Politics of Work in Art》（Brill，2020）。比奇也是一位艺术家，2004至2018年间与安迪·休伊特、梅尔·乔丹在集体*Freee*中工作。他目前的艺术实践把批判性纪录电影传统转化为结合照片蒙太奇与文字艺术的系列版画。

<a id="back-contrib-02-en"></a>
**Dave Beech** is Reader in Art and Marxism at the University of the Arts, London. He is the author of *Art and Value: Art’s Economic Exceptionalism* *in Classical, Neoclassical and Marxist Economics* (Brill, 2015), which was shortlisted for the Deutscher Memorial Prize; *Art and Postcapitalism:* *Aesthetic Labour, Automation and Value Production* (Pluto, 2019); and *Art* *and Labour:* *On the Hostility to Handicraft, Aesthetic Labour and the Politics* *of Work in Art* (Brill, 2020). Beech is an artist who worked in the collective *Freee* (with Andy Hewitt and Mel Jordan) between 2004 and 2018. His current art practice translates the tradition of critical documentary film into sequences of prints that combine photomontage and text art.

<a id="back-contrib-03-zh"></a>
**阿伊莎·哈米德**住在伦敦。自2014年以来，哈米德的多章节项目“黑色亚特兰蒂斯”考察黑色大西洋及其在当代被非法化的海上迁移、海洋环境、非洲未来主义舞池与音响系统以及外层空间中的延续与余波。通过影片、声音随笔与表演讲座，她研究如何把声音、图像、水、暴力与历史思考为活跃档案的要素，以及把时间旅行思考为一种历史方法。晚近展览包括利物浦双年展（2021）、哥德堡双年展（2019）、卢本巴希双年展（2019）与达喀尔双年展（2018）。她是《Futures and Fictions》（Repeater，2017）的合编者，以及《Visual Cultures as Time Travel》（Sternberg/MIT，2021年即出）的合著者。她目前是伦敦大学金史密斯学院视觉文化博士项目联合主任。

<a id="back-contrib-03-en"></a>
**Ayesha Hameed** lives in London. Since 2014 Hameed’s multi-chapter project ‘Black Atlantis’ has looked at the Black Atlantic and its afterlives in contemporary illegalized migration at sea, in oceanic environments, through Afrofuturistic dancefloors and soundsystems and in outer space. Through videos, audio essays and performance lectures, she examines how to think through sound, image, water, violence and history as elements of an active archive; and time travel as a historical method. Recent exhibitions include Liverpool Biennale (2021), Gothenburg Biennale (2019), Lubumbashi Biennale (2019) and Dakar Biennale (2018). She is co-editor of *Futures and Fictions* (Repeater, 2017) and co-author of *Visual* *Cultures as Time Travel* (Sternberg/MIT, forthcoming 2021). She is currently Co-Programme Leader of the PhD in Visual Cultures at Goldsmiths University of London.

<a id="back-contrib-04-zh"></a>
**克拉拉·肯普-韦尔奇**是伦敦大学考陶尔德艺术学院二十世纪现代主义高级讲师。著有《Antipolitics in Central European Art: Reticence as Dissidence under Post-Totalitarian Rule 1956–1989》（I.B.Tauris，2014）与《Networking the Bloc: Experimental Art in Eastern Europe 1965–1989》（MIT University Press，2018），并与贝亚塔·霍克、乔纳森·欧文合编《A Reader in East-Central European Modernism, 1918–1956》（Courtauld Books Online，2019）。她目前正在写作一本关于《Art, Labour and Migration in a ‘Two Speed’ Europe》的书。

<a id="back-contrib-04-en"></a>
**Klara Kemp-Welch** is Senior Lecturer in 20th-century Modernism at the Courtauld Institute of Art, University of London. She is the author of *Antipolitics in Central European Art: Reticence as Dissidence under* *Post-Totalitarian Rule 1956–1989* (I.B.Tauris, 2014) and *Networking the* *Bloc: Experimental Art in Eastern Europe 1965–1989* (MIT University Press, 2018), and co-editor, with Beata Hock and Jonathan Owen, of *A Reader* *in East-Central European Modernism, 1918–1956* (Courtauld Books Online, 2019). She is currently working on a book on *Art, Labour and Migration in* *a ‘Two Speed’ Europe*.

<a id="back-contrib-05-zh"></a>
**贾莱赫·曼苏尔**是温哥华不列颠哥伦比亚大学艺术史、视觉艺术与理论系副教授。她撰有关于皮耶罗·曼佐尼、埃德·鲁沙、阿格尼丝·马丁、布林基·帕莱尔莫、格哈德·里希特与莫娜·哈通作品的专题研究。她合编《Communities of Sense: Rethinking Aesthetics and Politics》（Duke University Press，2010），并著有《Marshall Plan Modernism: Italian Postwar Abstraction and the Beginnings of Autonomia》（Duke University Press，2016）。

<a id="back-contrib-05-en"></a>
**Jaleh Mansoor** is an Associate Professor in the faculty of Art History, Visual Art and Theory at the University of British Columbia, Vancouver. She has written monographic studies on the work of Piero Manzoni, Ed Ruscha, Agnes Martin, Blinky Palermo, Gerhard Richter and Mona Hatoum. She co-edited *Communities of Sense: Rethinking Aesthetics and* *Politics* (Duke University Press, 2010) and is the author of *Marshall Plan* *Modernism: Italian Postwar Abstraction and the Beginnings of Autonomia* (Duke University Press, 2016).

<a id="back-contrib-06-zh"></a>
**克里斯蒂安·尼扬佩塔**是一位艺术家，召集“另一路线图学校”的尼亚恩扎工作组。晚近个展包括纽约雕塑中心的《École du soir》；莱比锡 GfZK 当代艺术博物馆的《A Flower Garden of All Kinds of Loveliness without Sorrow》（与梅赫伦 Contour 双年展第9届联合委约，与布鲁塞尔 Kunstenfestivaldesarts、阿姆斯特丹 Perdu 及鹿特丹 Wilfried Lentz 画廊联合制作）；以及伦敦卡姆登艺术中心的《Words after the World》。他参加了第5届乌拉尔工业当代艺术双年展、2018年达喀尔双年展和2016年第11届光州双年展。尼扬佩塔运营*Radius*，一个线上并偶尔可居住的广播站。他在伦敦大学金史密斯学院获得视觉文化博士学位，导师为科乔·埃顺。他曾获2019年“欧洲未来艺术奖”，以及第12届巴马科相遇——非洲摄影双年展欧盟奖。

<a id="back-contrib-06-en"></a>
**Christian Nyampeta** is an artist who convenes the Nyanza Working Group of Another Roadmap School. His recent solo exhibitions include *École du soir* at the Sculpture Center in New York; *A Flower Garden of* *All Kinds of Loveliness without Sorrow* at the Museum of Contemporary Art GfZK in Leipzig, co-commissioned with Contour Biennale 9 in Mechelen, and co-produced with Kunstenfestivaldesarts, Brussels, Perdu Amsterdam and Wilfried Lentz Gallery in Rotterdam; and *Words after the* *World* at Camden Arts Centre, London. He contributed to the 5th Ural Industrial Biennial of Contemporary Art; the Dakar Biennale 2018; and the 11th Gwangju Biennial in 2016. Nyampeta runs *Radius*, an online and occasionally inhabitable radio station. He was awarded a PhD in Visual Cultures at Goldsmiths, University of London, under the supervision of Kodwo Eshun. He was awarded the Art Prize Future of Europe 2019 and the European Union Prize at the 12th Bamako Encounters – African Biennial of Photography.

<a id="back-contrib-07-zh"></a>
**彼得·奥斯本**是伦敦金斯顿大学欧洲现代哲学教授、欧洲现代哲学研究中心（CRMEP）主任。他曾任巴黎第八大学哲学系（2014、2017）、斯德哥尔摩皇家艺术学院（2015）与耶鲁大学艺术学院（2017）客座教授。1983至2016年间，他是英国期刊《Radical Philosophy》的编辑。其著作包括《The Politics of Time: Modernity and Avant-Garde》（1995；2011）、《Philosophy in Cultural Theory》（2000）、《Conceptual Art》（2002）、《Marx》（2005）、《Anywhere or Not at All: Philosophy of Contemporary Art》（2013）与《The Postconceptual Condition》（2018）。

<a id="back-contrib-07-en"></a>
**Peter Osborne** is Professor of Modern European Philosophy and Director of the Centre for Research in Modern European Philosophy (CRMEP), Kingston University London. He has held Visiting Chairs in the Department of Philosophy at the University of Paris 8 (2014, 2017), the Royal Institute of Art, Stockholm (2015) and Yale University School of Art (2017). From 1983 until 2016 he was an editor of the British journal *Radical* *Philosophy*. His books include *The Politics of Time: Modernity and Avant-Garde* (1995; 2011), *Philosophy in Cultural Theory* (2000), *Conceptual Art* (2002), *Marx* (2005), *Anywhere or Not at All: Philosophy of Contemporary* *Art* (2013) and *The Postconceptual Condition* (2018).

<a id="back-contrib-08-zh"></a>
**卢德格·施瓦尔特**是杜塞尔多夫艺术学院哲学教授。其研究涵盖美学、政治哲学、文化哲学、本体论与科学史。他最新的著作是《Notate für eine künftige Kunst》／《Notes pour un art future》（Merve 2016／les presses du réel，2019）与《Pikturale Evidenz》（W. Fink，2015）。

<a id="back-contrib-08-en"></a>
**Ludger Schwarte** is Professor of Philosophy at the Kunstakademie Düsseldorf. His research covers the areas of aesthetics, political philosophy, philosophy of culture, ontology and history of science. His most recent books are *Notate für eine künftige Kunst*/*Notes pour un art* *future* (Merve 2016/les presses du réel, 2019) and *Piktrale Evidenz* (W. Fink, 2015).

<a id="back-contrib-09-zh"></a>
**凯斯顿·萨瑟兰**是一位诗人，萨塞克斯大学诗学教授。他于2013年在加州大学伯克利分校任霍洛韦诗歌研究员，2016年在普林斯顿大学任贝恩-斯威格特诗歌教授。他著有多种诗集，包括《Whither Russia》（Barque，2017）、《Poetical Works 1999–2015》（Enitharmon Press，2015）与《The Odes to TL61P》（Enitharmon Press，2013），以及一本关于马克思与诗歌的书《Stupefaction》（Seagull，2011）。

<a id="back-contrib-09-en"></a>
**Keston Sutherland** is a poet and Professor of Poetics at the University of Sussex. He was Holloway Poetry Fellow at UC Berkeley in 2013, and in 2016 was the Bain-Swiggett Professor of Poetry at Princeton University. He is the author of many books of poetry, including *Whither* *Russia* (Barque, 2017), *Poetical Works 1999–2015* (Enitharmon Press, 2015) and *The Odes to TL61P* (Enitharmon Press, 2013), and a book on Marx and poetry, *Stupefaction* (Seagull, 2011).

<a id="back-contrib-10-zh"></a>
**乔万娜·扎佩里**是旅居巴黎的艺术史学者，图尔大学当代艺术史教授。她最新的著作考察艺术批评家、意大利激进女性主义者卡拉·隆齐的写作：《Carla Lonzi. Un’arte della vita》（《卡拉·隆齐：一种生活的艺术》，罗马，2017；法译本，第戎，2018）。她与娜塔莎·彼得雷辛-巴舍莱兹共同策划了2019—20年在马德里索菲亚王后博物馆举办的展览《Defiant Muses: Delphine Seyrig and Feminist Video Collectives in France, 1970s–1980s》。

<a id="back-contrib-10-en"></a>
**Giovanna Zapperi** is a Paris-based art historian and Professor of Contemporary Art History at Université de Tours. Her latest book examines the writings of art critic and radical Italian feminist Carla Lonzi: *Carla Lonzi. Un’arte della vita* (*Carla Lonzi: An Art of Life*, Rome, 2017; French translation, Dijon 2018). With Nataša Petrešin-Bachelez, she has curated the exhibition *Defiant Muses: Delphine Seyrig and Feminist Video* *Collectives in France, 1970s–1980s* at Museo Reina Sofia, Madrid, 2019–20.
