"""Deterministic source archive, with explicit inclusion and per-entry hashes."""
import hashlib,json,zipfile
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[2];O=P.parents[1]/'output/reviewed'
files=[P.parent/'source_units.jsonl',P/'bilingual-reader.js']
for name in ['translation_units.jsonl','navigation_structure.json','structure_overrides.json','editor_notes.json','term_decisions.json','whole_book_audit.json','output_audit.json','output_plan.json','build_outputs.py','audit_outputs.py','package_outputs.py','global_review_evidence.json','front_review_evidence.json','back_review_evidence.json']:
 files.append(P/name)
files+=sorted(P.glob('ch??_review_evidence.json'))
files+=sorted(P.glob('ch??_revisions.json'))
for name in ['thinking_art_zh.md','thinking_art_bilingual.md','thinking_art_zh.tex','thinking_art_bilingual.tex','index.html','bilingual-reader.js','build_manifest.json']:
 files.append(O/name)
files+=sorted((O/'webdata').glob('*.json'))
readme='''# Thinking Art 校订成果源码包

版本：2026-10-21。包含817个规范单元、298条原注；四部十章及前后材料。
未收入原索引（原PDF231—234页）；未复制原图版。原文PDF不包含在本包。
作者、出处、底本许可及本版说明保存在规范单元和阅读版中。底本为 CC BY-NC-ND 4.0；本版经委托用户确认可公开发表。

## 复现

保留解压后的目录结构。使用 Python 3.11+，安装 markdown-it-py 与 PyMuPDF；使用 TeX Live 2025（XeLaTeX、xeCJK、hyperref、xurl、fancyhdr、needspace）及 Windows 字体 Times New Roman / SimSun。

1. 在解压根目录运行：python -X utf8 "Thinking Art/work/review/build_outputs.py"
2. 进入 Thinking Art/output/reviewed，分别执行以下命令各两遍：
   xelatex -interaction=nonstopmode -halt-on-error thinking_art_zh.tex
   xelatex -interaction=nonstopmode -halt-on-error thinking_art_bilingual.tex
3. 回到解压根目录运行：python -X utf8 "Thinking Art/work/review/audit_outputs.py"
4. 在 Thinking Art/output/reviewed 运行 python -m http.server，浏览其 localhost 地址查看网页。

规范稿是后续编辑入口。不要从上游初稿重建或覆盖规范稿。build_outputs.py 复用已完成的语义校对证据，只生成阅读版。
字体和 TeX 版本变化会改变换行、页数及 PDF 哈希；PDF 编译时间也可能改变字节。相同输入文件的源码 ZIP 使用固定时间戳，可按字节复现。
SOURCE-MANIFEST.json 为包内各文件 SHA256。章级证据记录相应输入/输出版本；全书统检记录当前主文件版本。未收录庞大的中间快照或原始PDF。
'''
entries={str(f.relative_to(R)).replace('\\','/'):f.read_bytes() for f in files}
entries['README.md']=readme.encode('utf8')
entries['SOURCE-MANIFEST.json']=(json.dumps({k:hashlib.sha256(v).hexdigest() for k,v in sorted(entries.items())},ensure_ascii=False,indent=2)+'\n').encode('utf8')
target=O/'thinking_art_source.zip'
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(entries.items()):
  info=zipfile.ZipInfo(name,(2026,10,21,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o644<<16;z.writestr(info,data)
with zipfile.ZipFile(target) as z:
 assert z.testzip() is None
 checks=json.loads(z.read('SOURCE-MANIFEST.json'))
 assert all(hashlib.sha256(z.read(k)).hexdigest()==v for k,v in checks.items())
print(json.dumps({'file':str(target),'entries':len(entries),'sha256':hashlib.sha256(target.read_bytes()).hexdigest()},ensure_ascii=False))
