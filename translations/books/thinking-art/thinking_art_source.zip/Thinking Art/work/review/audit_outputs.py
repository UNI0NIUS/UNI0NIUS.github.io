"""Read-only generated edition checks; normalizes page furniture and hyphenation."""
import hashlib,json,re,unicodedata
from pathlib import Path
import pymupdf as fitz
P=Path(__file__).resolve().parent;O=P.parents[1]/'output/reviewed'
def norm(t):return re.sub(r'\s+','',unicodedata.normalize('NFKC',t)).replace('\u00ad','').replace('-','')
def parts(ts):
 for t in ts:
  if isinstance(t,str):yield t
  elif t['type'] not in ('note','break'):yield from parts(t.get('children',[]))
books=[json.loads((O/'webdata'/f'{x["id"]}.json').read_text(encoding='utf8')) for x in json.loads((O/'webdata/book-metadata.json').read_text(encoding='utf8'))['chapters']]
result={'master_sha256':hashlib.sha256((P/'translation_units.jsonl').read_bytes()).hexdigest(),'normalization':'NFKC, whitespace and discretionary/ASCII hyphen removal; crop running heads and footers; compare every text run in 35-character segments','editions':{}}
for stem in ['thinking_art_zh','thinking_art_bilingual']:
 d=fitz.open(O/(stem+'.pdf'));alltext=norm(''.join(x.get_text(clip=fitz.Rect(0,55,x.rect.width,x.rect.height-55)) for x in d));missing=[];count=0
 for b in books:
  for row in b['body']+list(b['notes'].values()):
   for lang in (['zh','en'] if 'bilingual' in stem else ['zh']):
    for s in parts(row[lang]):
     n=norm(s)
     for i in range(0,len(n),35):
      c=n[i:i+35]
      if len(c)>8:
       count+=1
       if c not in alltext:missing.append([row.get('id',row.get('unitId')),lang,c])
 text=(O/(stem+'.md')).read_text(encoding='utf8');anchors=re.findall(r'<a id="([^"]+)"',text);links=re.findall(r'\]\(#([^\)]+)\)',text)
 assert len(anchors)==len(set(anchors)), 'duplicate Markdown anchors'
 assert not set(links)-set(anchors), 'missing Markdown target'
 pdf_links=[link for p in d for link in p.get_links()]
 invalid=[x for x in pdf_links if x['kind']==fitz.LINK_GOTO and not 0<=x.get('page',-1)<len(d)]
 assert not missing and not invalid
 result['editions'][stem]={'sha256':hashlib.sha256((O/(stem+'.pdf')).read_bytes()).hexdigest(),'pages':len(d),'checked_text_segments':count,'missing_segments':missing,'toc_entries':len(d.get_toc()),'pdf_links':len(pdf_links),'invalid_internal_links':invalid,'markdown_anchors':len(anchors),'markdown_links':len(links)}
(P/'output_audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps(result,ensure_ascii=False,indent=2))
