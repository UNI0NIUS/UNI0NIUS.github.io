"""Build reading editions ONLY from the reviewed master. Never runs draft merger."""
import hashlib,json,re,shutil
from pathlib import Path
from markdown_it import MarkdownIt
P=Path(__file__).resolve().parent
O=P.parents[1]/'output/reviewed';O.mkdir(parents=True,exist_ok=True)
W=O/'webdata';W.mkdir(exist_ok=True)
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def lines(p):return [json.loads(l) for l in p.read_text(encoding='utf-8').splitlines()]
master=P/'translation_units.jsonl';digest=hashlib.sha256(master.read_bytes()).hexdigest()
assert digest==read(P/'whole_book_audit.json')['master_sha256']
src=lines(P.parent/'source_units.jsonl');zh=lines(master);source={x['id']:x for x in src}
assert all(x['semantic_review']=='reviewed' for x in zh)
md=MarkdownIt();joins=read(P/'structure_overrides.json')['paragraph_joins']
joinmap={x['units'][0]:x['units'] for x in joins};skip={i for x in joins for i in x['units'][1:]}
eds={x['unit_id']:x for x in read(P/'editor_notes.json')}
by={x['id']:x for x in zh};sections=['front','preface','ack','part1','ch01','ch02','part2','ch03','ch04','ch05','part3','ch06','ch07','ch08','part4','ch09','ch10','back']
titles={'front':'出版与丛书信息','preface':'序言','ack':'致谢','back':'图片来源与作者简介'}
structure=read(P/'navigation_structure.json')
partmap={p['id']:p for p in structure['parts']}
chapterpart={c:p['id'] for p in structure['parts'] for c in p['chapters']}
notice='校订阅读版 · 2026-10-21。依2020年CRMEP Books底本逐项校对817个单元，含298条原注。未收入原索引（PDF第231—234页），未复制原书17个含图片源页的图像，保留文字与图片来源说明。源页定位均指PDF文件页序，不是原书印刷页码。作者简介及“目前”等表述沿用原书出版时点。编者说明与原注分列。底本许可为CC BY-NC-ND 4.0；原著及图片权利归原权利人。'
def tokens(text,section,refs=True):
 text=text.strip()
 marker=text.startswith('* ')
 if marker:text='＊\n\n'+text[2:]
 # Source PDF line wraps are not paragraph breaks; retain deliberate indents/verse.
 text=re.sub(r'(?<!\n)\n(?!\n|\u2003|\u3000)',' ',text)
 text=re.sub(r'^(\*\*\*.+?\*\*\*)\s+',r'\1\n',text)
 root=[];stack=[root]
 for t in md.parseInline(text)[0].children or []:
  if t.type=='text':
   for part in re.split(r'(\[\d+\])',t.content):
    m=re.fullmatch(r'\[(\d+)\]',part)
    stack[-1].append({'type':'note','id':f'{section}-{int(m[1])}'} if m and refs else part)
  elif t.type in ('em_open','strong_open','link_open'):
   node={'type':t.type.split('_')[0],'children':[]}
   if t.type=='link_open':node['url']=t.attrGet('href')
   stack[-1].append(node);stack.append(node['children'])
  elif t.type in ('em_close','strong_close','link_close'):stack.pop()
  elif t.type in ('softbreak','hardbreak'):stack[-1].append({'type':'break'})
  elif t.type in ('code_inline','html_inline'):stack[-1].append(t.content)
  else:raise ValueError(t.type)
 assert len(stack)==1
 return root
def plain(ts):return ''.join(t if isinstance(t,str) else ('['+t['id'].split('-')[-1]+']') if t['type']=='note' else '\n' if t['type']=='break' else plain(t.get('children',[])) for t in ts)
def markdown(ts,lang):
 out=[]
 for t in ts:
  if isinstance(t,str):out.append(t.replace('\\','\\\\').replace('*',r'\*').replace('_',r'\_'))
  elif t['type']=='note':
   k=t['id'];out.append(f'<a id="ref-{lang}-{k}"></a>[{k.split("-")[-1]}](#note-{lang}-{k})')
  elif t['type']=='break':out.append('  \n')
  else:
   body=markdown(t['children'],lang)
   out.append('['+body+']('+t['url']+')' if t['type']=='link' else ('**' if t['type']=='strong' else '*')+body+('**' if t['type']=='strong' else '*'))
 return ''.join(out)
books=[]
for section in sections:
 rows=[x for x in zh if x['section']==section];body=[];notes={}
 title=next((x['text_zh'].replace('*','') for x in rows if x['type'] in ('title','part')),titles.get(section,section))
 for x in rows:
  uid=x['id'];kind=x['type']
  if uid in skip:continue
  ids=joinmap.get(uid,[uid]);zt=''.join(by[i]['text_zh'] for i in ids);et=' '.join(source[i]['text'] for i in ids)
  if kind=='note':
   key=f'{section}-{int(uid.rsplit("-n",1)[1])}'
   notes[key]={'zh':tokens(zt,section,False),'en':tokens(et,section,False),'unitId':uid}
   if uid in eds: notes[key]['review']=eds[uid]['text_zh']+' '+' '.join(v['url'] for v in eds[uid]['sources'])
   continue
  row={'id':uid,'type':{'title':'heading','part':'heading','body':'paragraph','author':'paragraph','attribution':'paragraph','contributor':'paragraph'}.get(kind,kind),'page':'PDF '+','.join(map(str,dict.fromkeys(r['pdf_page'] for i in ids for r in source[i]['source_refs']))),'pageKind':'pdf','zh':tokens(zt,section),'en':tokens(et,section),'sourceIds':ids}
  if uid in eds:row['review']=eds[uid]['text_zh']+' '+' '.join(v['url'] for v in eds[uid]['sources'])
  body.append(row)
  # Stable legacy/source IDs remain navigable even when their prose is merged.
  for alias in ids[1:]:body.append({'id':alias,'type':'paragraph','zh':[],'en':[],'aliasOf':uid})
 data={'id':section,'title':title,'body':body,'notes':notes,'sourceLanguage':'en','sourceLanguageLabel':'English'}
 (W/f'{section}.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');books.append(data)
meta={'id':'thinking-art','title':'思考艺术：唯物主义、劳动、形式','originalTitle':'Thinking Art: Materialisms, Labours, Forms','author':'Peter Osborne 编','language':'zh-CN','languagePair':'English → 中文','structured':True,'bilingual':True,'views':['parallel','zh','en'],'example':False,'description':'十章艺术理论文集，中文及中英逐段对照校订版。','editionNotice':notice,'chapters':[{'id':b['id'],'title':b['title'],'dataUrl':f'translations/books/thinking-art/{b["id"]}.json'} for b in books],'downloads':[{'label':'中文PDF','url':'translations/books/thinking-art/thinking_art_zh.pdf'},{'label':'双语PDF','url':'translations/books/thinking-art/thinking_art_bilingual.pdf'},{'label':'规范稿与源码包','url':'translations/books/thinking-art/thinking_art_source.zip'}]}
meta['parts']=[{k:v for k,v in p.items() if k!='chapters'} for p in structure['parts']]
for c in meta['chapters']:
 sec=c['id']
 originals=[x for x in src if x['section']==sec and x['type'] in ('title','part')]
 c['originalTitle']=plain(tokens(originals[0]['text'],sec)) if originals else {'front':'Publication information','preface':'Preface','ack':'Acknowledgements','back':'Back matter'}[sec]
 if sec in chapterpart:
  c['partId']=chapterpart[sec]
  c['title']=f'第{int(sec[2:])}章　'+c['title']
  c['originalTitle']=f'{int(sec[2:])}. '+c['originalTitle']
 elif sec in partmap:
  c.update(partId=sec,title=partmap[sec]['title'],originalTitle=partmap[sec]['originalTitle'],shortTitle='分部扉页',shortOriginalTitle='Part title page')
 elif sec=='back':c.update(title='书后材料',outline=structure['back_outline'])
(W/'book-metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def escape(s):
 return ''.join({'\\':r'\textbackslash{}','{':r'\{','}':r'\}','%':r'\%','&':r'\&','$':r'\$','#':r'\#','_':r'\_','~':r'\textasciitilde{}','^':r'\textasciicircum{}'}.get(c,c) for c in s)
def tex(ts,lang,section,refs=True):
 out=[]
 for t in ts:
  if isinstance(t,str):
   # Avoid overfull URL runs while retaining full text.
   for v in re.split(r'((?:https?://|www\.)[^\s\u3000-\u9fff\uff00-\uffef]+)',t):out.append(r'\url{'+v+'}' if re.match(r'(?:https?://|www\.)',v) else escape(v))
  elif t['type']=='note':
   k=t['id'];out.append(r'\hypertarget{ref-'+lang+'-'+k+r'}{}\hyperlink{note-'+lang+'-'+k+r'}{\textsuperscript{'+k.split('-')[-1]+'}}')
  elif t['type']=='break':out.append(r'\newline{}')
  else:
   cmd={'em':r'\emph','strong':r'\textbf','link':r'\textnormal'}[t['type']];out.append(cmd+'{'+tex(t['children'],lang,section,refs)+'}')
 return ''.join(out)
PRE=r'''\documentclass[11pt,a4paper]{article}
\usepackage{fontspec,xeCJK}
\setmainfont{Times New Roman}
\setCJKmainfont[AutoFakeBold=2,AutoFakeSlant=.2]{SimSun}
\setCJKmonofont{SimSun}
\usepackage[margin=23mm,top=24mm,bottom=24mm]{geometry}
\usepackage{xcolor,hyperref,xurl,fancyhdr,needspace}
\hypersetup{unicode=true,hidelinks,pdftitle={思考艺术},pdfauthor={Peter Osborne (ed.)}}
\setlength{\parindent}{0pt}\setlength{\parskip}{6pt}
\setlength{\emergencystretch}{4em}\tolerance=2500
\widowpenalty=10000\clubpenalty=10000
\pagestyle{fancy}\fancyhf{}\fancyhead[L]{\small 思考艺术}\fancyhead[R]{\small EDITION}\fancyfoot[C]{\thepage}
\setlength{\headheight}{15pt}
\renewcommand{\contentsname}{目录}
\begin{document}
\begin{titlepage}\vspace*{28mm}{\Huge\bfseries 思考艺术\par}\vspace{8mm}{\Large 唯物主义、劳动、形式\par}\vspace{10mm}Thinking Art: Materialisms, Labours, Forms\par\vspace{8mm}彼得·奥斯本 编\par\vspace{18mm}EDITION\par\vfill NOTICE\end{titlepage}
\tableofcontents\clearpage
'''
for bilingual in (False,True):
 edition='中英逐段对照校订阅读版' if bilingual else '中文校订阅读版';stem='thinking_art_bilingual' if bilingual else 'thinking_art_zh'
 out=[PRE.replace('EDITION',edition).replace('NOTICE',escape(notice))];ms=['# '+meta['title'],'',edition,'',notice,'']
 for b in books:
  sec=b['id'];entry=next(c for c in meta['chapters'] if c['id']==sec);heading=entry['title'];level='subsection' if sec in chapterpart else 'section';out += [r'\clearpage'+(r'\vspace*{50mm}' if sec in partmap else '')+r'\phantomsection'+'\\'+level+'*{'+escape(heading)+r'}\addcontentsline{toc}{'+level+'}{'+escape(heading)+'}'];ms += [('## ' if sec in chapterpart else '# ')+heading,'']
  for r in b['body']:
   for uid in r.get('sourceIds',[r['id']]):out.append(r'\hypertarget{'+uid+'}{}')
   if r.get('aliasOf'):continue
   # Chapter title is already typeset as the section title.
   title_row=r['id'].endswith('-title')
   if not title_row:out.append(r'{\scriptsize\color{gray} '+escape(r.get('page',''))+r'}\par')
   for lang in (['zh','en'] if bilingual else ['zh']):
    content=tex(r[lang],lang,sec)
    ms += ['<a id="'+uid+'-'+lang+'"></a>' for uid in r.get('sourceIds',[r['id']])]
    mcontent=markdown(r[lang],lang)
    if r['type']=='quote':mcontent='> '+mcontent.replace('\n','\n> ')
    elif r['type'] in ('heading','subheading'):mcontent='## '+mcontent
    ms += [mcontent,'']
    if title_row:
     if lang=='en':out.append(r'{\large '+content+r'}\par')
     continue
    if sec=='back' and r['type']=='heading':
     if lang=='zh':out.append(r'\phantomsection\subsection*{'+content+r'}\addcontentsline{toc}{subsection}{'+escape(plain(r[lang]))+'}')
     else:out.append(r'{\large '+content+r'}\par')
    elif r['type'] in ('heading','subheading'):
     out.append(r'\needspace{6\baselineskip}{\large\bfseries '+content+r'}\par')
    elif r['type']=='quote':out.append(r'\begin{quote}'+content+r'\end{quote}')
    else:out.append((r'{\color{black!75} ' if lang=='en' else '{')+content+r'\par}')
   if r.get('review'):
    out.append(r'{\small\color{blue!50!black} '+escape(r['review'])+r'\par}');ms += [r['review'],'']
  if b['notes']:
   notelevel='subsubsection' if sec in chapterpart else 'subsection';out.append('\\'+notelevel+r'*{原注}\addcontentsline{toc}{'+notelevel+r'}{原注}');ms += [('### ' if sec in chapterpart else '## ')+'原注','']
  for key,n in b['notes'].items():
   out.append(r'\hypertarget{'+n['unitId']+'}{}')
   for lang in (['zh','en'] if bilingual else ['zh']):
    out.append(r'\hypertarget{note-'+lang+'-'+key+r'}{}\noindent\textbf{'+key.split('-')[-1]+'.} '+tex(n[lang],lang,sec,False)+r' \hyperlink{ref-'+lang+'-'+key+r'}{[返回]}\par')
    ms += [f'<a id="{n["unitId"]}-{lang}"></a><a id="note-{lang}-{key}"></a>', '['+key.split('-')[-1]+'] '+markdown(n[lang],lang)+f' [返回](#ref-{lang}-{key})','']
   if n.get('review'):out.append(r'{\small\color{blue!50!black} '+escape(n['review'])+r'\par}');ms += [n['review'],'']
 out.append(r'\end{document}')
 (O/f'{stem}.tex').write_text('\n'.join(out),encoding='utf-8');(O/f'{stem}.md').write_text('\n'.join(ms),encoding='utf-8')
shutil.copy2(P/'bilingual-reader.js',O/'bilingual-reader.js')
html='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>思考艺术 · 校订版</title><style>
body{max-width:1100px;margin:40px auto;padding:0 22px;font-family:Georgia,"Microsoft YaHei",serif;line-height:1.85;color:#24272b;background:#faf9f5}h1{font-size:2rem}a{color:#31566a}nav{display:flex;gap:18px;flex-wrap:wrap}.parallel-row{display:grid;grid-template-columns:65px 1fr 1fr;gap:20px;border-top:1px solid #e4e1d9;padding:15px 0}.view-zh .parallel-row,.view-en .parallel-row{grid-template-columns:65px 1fr}.printed-page{font-size:12px;color:#777}.paragraph-footnote,.editorial-query{font-size:.85em;background:#eeece5;padding:12px;overflow-wrap:anywhere}blockquote{margin:12px 15px;border-left:2px solid #aaa;padding-left:15px}.reader-cell{min-width:0;overflow-wrap:anywhere}.edition-switcher{position:sticky;top:0;background:#faf9f5;padding:12px 0}.note-ref{margin:0 2px}p{margin:.5em 0}@media(max-width:680px){body{margin:20px auto;padding:0 14px}.parallel-row{display:block}.reader-en{border-left:2px solid #ddd;padding-left:12px;margin-top:15px}.column-labels{display:none}}
</style><h1>思考艺术</h1><p id="notice"></p><p><a href="thinking_art_zh.pdf">中文 PDF</a> · <a href="thinking_art_bilingual.pdf">双语 PDF</a> · <a href="thinking_art_source.zip">规范稿与源码包</a></p><details><summary>目录 · 四部十章</summary><nav><ol id="toc"></ol></nav></details><h2 id="title"></h2><main></main><script>function el(tag,text,cls){const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e}function safeUrl(u){try{let x=new URL(u,location.href);return ['http:','https:'].includes(x.protocol)?x.href:null}catch{return null}}</script><script src="bilingual-reader.js"></script><script>
async function run(){let m=await(await fetch('webdata/book-metadata.json')).json();document.querySelector('#notice').textContent=m.editionNotice;let q=new URLSearchParams(location.search),id=q.get('chapter')||'preface',v=q.get('view')||'parallel';let groups=new Map();for(let c of m.chapters){let parent=document.querySelector('#toc');if(c.partId){if(!groups.has(c.partId)){let part=m.parts.find(p=>p.id===c.partId),g=el('details');g.open=id===c.partId||m.chapters.find(x=>x.id===id)?.partId===c.partId;g.append(el('summary',v==='en'?part.originalTitle:part.title));let ol=el('ol');g.append(ol);parent.append(g);groups.set(c.partId,ol)}parent=groups.get(c.partId)}let item=el('li'),a=el('a',v==='en'?(c.shortOriginalTitle||c.originalTitle):(c.shortTitle||c.title));a.href='?chapter='+c.id+'&view='+v;item.append(a);if(c.outline){let ol=el('ol');for(let h of c.outline){let li=el('li'),link=el('a',v==='en'?h.originalTitle:h.title);link.href=a.href+'#'+h.anchor;li.append(link);ol.append(li)}item.append(ol)}parent.append(item)}let b=await(await fetch('webdata/'+id+'.json')).json();document.querySelector('#title').textContent=b.title;let main=document.querySelector('main');main.append(renderParallelBook.controls(v,b),renderParallelBook.content(b,v));for(let r of b.body.filter(r=>r.aliasOf)){let a=document.getElementById(r.id);if(a)a.style.cssText='display:block;height:0;padding:0;border:0';}for(let x of document.querySelectorAll('.editorial-query summary'))x.textContent='编者说明';if(location.hash)document.getElementById(decodeURIComponent(location.hash.slice(1)))?.scrollIntoView()}run();</script></html>'''
(O/'index.html').write_text(html,encoding='utf-8')
(O/'build_manifest.json').write_text(json.dumps({'master_sha256':digest,'chapters':len(books),'notes':sum(len(x['notes']) for x in books),'status':'generated_sources_not_yet_layout_verified','scope_notice':notice},ensure_ascii=False,indent=2),encoding='utf-8')
print('Generated sources, Markdown, webdata, local reader:',O)
