"""Independent canonical-to-output text readback; no renderer imports."""
from pathlib import Path
import json,re,unicodedata,html,hashlib,sys
import pymupdf
R=Path(__file__).resolve().parent;O=R.parents[1]/'output/reviewed'
def norm(t):
 t=re.sub(r'⟦p\.[^⟧]+⟧','',t)
 t=re.sub(r'〔原页\s*[^〕]+〕|\[S\.\s*[^\]]+\]','',t)
 t=t.replace(r'\Sigma','Σ').replace(r'\sqrt','').replace(r'\,','')
 t=unicodedata.normalize('NFKC',t)
 return ''.join(c for c in t if c.isalnum())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
us=[json.loads(x) for x in (R/'translation_units.jsonl').read_text('utf-8').splitlines()]+[u for g in json.loads((R/'front_matter.json').read_text('utf-8')) for u in g['units']]
expect=[]
for u in us:
 parts=u.get('note_parts',[u])
 for v in parts:
  de=v.get('source_display_text',v['source_text']);zh=v['translation']
  blocks=v.get('reading_blocks') or [dict(source_range=[0,len(de)],translation_range=[0,len(zh)])]
  for j,b in enumerate(blocks):expect.append(dict(id=b.get('id',v['id'] if len(blocks)==1 else v['id']+f'-b{j+1}'),de=de[slice(*b['source_range'])],zh=zh[slice(*b['translation_range'])]))
outputs={};texts={};reused=[]
previous=json.loads((R/'output_text_audit.json').read_text('utf-8')) if '--reuse-pdf' in sys.argv else None
if previous:assert previous['canonical_sha256']==sha(R/'translation_units.jsonl') and previous['front_matter_sha256']==sha(R/'front_matter.json')
for mode in ['zh','de','bilingual']:
 p=O/f'cohen_kte1885_{mode}.pdf'
 if previous:
  record=previous['outputs']['pdf-'+mode];assert record['sha256']==sha(p) and record['candidate_count']==0
  outputs['pdf-'+mode]=record;reused.append('pdf-'+mode);continue
 d=pymupdf.open(p);names=d.resolve_names();logs=p.with_suffix('.log').read_text('utf-8',errors='replace')
 ts=[];lanes={'zh':[],'de':[]}
 for page_index,page in enumerate(d):
  if mode=='zh':left=25/25.4*72;right=page.rect.width-left
  else:
   left=(20 if page_index%2==0 else 23)/25.4*72
   right=page.rect.width-(23 if page_index%2==0 else 20)/25.4*72
  ts.append(page.get_text('text',clip=pymupdf.Rect(left-.4,50,right+.4,page.rect.height-55),sort=True))
  if mode=='bilingual':
   middle=(left+right)/2
   lanes['zh'].append(page.get_text('text',clip=pymupdf.Rect(left-.4,50,middle,page.rect.height-55),sort=True))
   lanes['de'].append(page.get_text('text',clip=pymupdf.Rect(middle,50,right+.4,page.rect.height-55),sort=True))
 text='\n'.join(ts);texts['pdf-'+mode]={'all':norm(text),**{k:norm('\n'.join(v)) for k,v in lanes.items()}} if mode=='bilingual' else norm(text)
 outputs['pdf-'+mode]=dict(sha256=sha(p),pages=len(d),named_destinations=len(names),missing_characters=len(re.findall('Missing character:',logs)),overfull_boxes=len(re.findall('Overfull',logs)),undefined_destinations=len(re.findall('does not exist',logs)),candidates=[])
for lang in ['zh','de']:
 p=O/f'cohen_kte1885_{lang}.md';t=p.read_text('utf-8');t=re.sub(r'<[^>]+>','',t);t=html.unescape(t);t=re.sub(r'\[([^\]]*)\]\([^\)]*\)',r'\1',t);texts['md-'+lang]=norm(t);outputs['md-'+lang]=dict(sha256=sha(p),candidates=[])
for name,content in texts.items():
 langs=['zh','de'] if name=='pdf-bilingual' else [name.rsplit('-',1)[1]]
 for lang in langs:
  for e in expect:
   t=norm(e[lang])
   whole=content[lang] if isinstance(content,dict) else content
   found=t in whole
   if not found and isinstance(content,dict):found=t in content['all']
   if t and not found:outputs[name]['candidates'].append(dict(id=e['id'],lang=lang,length=len(t),start=e[lang][:130]))
 outputs[name]['checked_components_per_language']=len(expect)
 outputs[name]['candidate_count']=len(outputs[name]['candidates'])
report=dict(status='text_readback_candidates_pending' if any(v['candidates'] for v in outputs.values()) else 'canonical_text_readback_passed',canonical_sha256=sha(R/'translation_units.jsonl'),front_matter_sha256=sha(R/'front_matter.json'),normalization='NFKC/alphanumeric comparison; original-page metadata removed; PDF headers/footers/outer-page labels clipped. Mathematical sqrt/Σ syntax normalized. Each original note part and reading block checked independently. Bilingual columns compared separately, with full-width headings checked against the whole-page stream.',outputs=outputs)
(R/'output_text_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
if reused:
 report['reused_unchanged_pdf_outputs']=reused
 (R/'output_text_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
for name,v in outputs.items():print(name,{k:x for k,x in v.items() if k!='candidates'});print('sample',v['candidates'][:4])
