# 独立校对术语记录

适用：导论及第一至十章的已核语境。不是机械全局替换表；准确异译可按上下文保留。生产者原词表不改，跨章未决见 global_issues.json。

| 德文/原词 | 采用译词与区别 |
| --- | --- |
| a priori / apriorisch | 先天 / 先天的；不与 angeboren 混同 |
| angeboren | 天赋的；与 a priori 明确对举时统一保持区别 |
| transscendental / transscendent | 先验的 / 超验的 |
| ursprünglich / anfänglich | 源始的 / 开端的（时间上的初始）；第五章为核心区别 |
| Bewusstsein / Bewusstheit | 意识 / 意识性；后者是柯亨在第207页明定的特设用语 |
| Anschauung / Vorstellung / Empfindung | 直观 / 表象 / 感觉；不可互换 |
| Erscheinung / Schein | 显象 / 假象；后者按语境亦可作幻象 |
| constituirend / constitutiv | 构成的 / 构成性的；与数学建构区别。已读第五章修复，前章留全书统检 |
| construiren | 建构；数学的主动建构，不同于构成经验的条件 |
| Vermögen / Fähigkeit | 官能 / 能力；如表象官能、理性官能 |
| Evidenz / Apodikticität | 明证性 / 必然确实性；不均化为一般必然性 |
| Enargie | 鲜明性；第159页原印如此，不是 Energie |
| Bestimmtheit | 规定性 / 规定方式，依名词关系；不误为被规定的被动方式 |
| Realität / objective Gültigkeit / Idealität | 实在性 / 客观有效性 / 观念性，留意作者对术语的历史批评 |
| Noumenon / Noumena | 本体（沿生产者词表）；最终全书统一另验 |
| mundus intelligibilis | 理智世界 |
| bereit / fertig | 预备着 / 现成或完成；“先天地预备在心灵中”不等于现成器官 |
| Dynamik / Mechaniker | 动力学 / 力学家 |
| Artbegriff | 种概念 |
| physisch-psychische Organisation | 身心组织；第五章初出保留德词，衔接连字符批评 |
| Mehrheit von Elementen | 多个要素、复多性；不是多数对少数的比例 |
| Mannichfaltigkeit | 杂多性；黎曼语境初出保留德词，避免未经说明等同现代特定流形概念 |
| Function（ds、dx语境） | 函数，不作逻辑函项 |
| positiv / negativ（条件与规定） | 肯定的 / 否定的；不机械套入其他物理或日常语境 |
| Schulgebrauch / Schulsprache | 学派用法、学派用语或哲学用语，非学院机构的语言 |

第六章补充：

| 原词 | 采用译法及语境 |
| --- | --- |
| Hineindenken / hineingedacht | 将思维置入对象 / 由思维置入；不作深入思考 |
| Vereinigen / Vereinigung / Einheit | 统一起来（动词）/ 统一活动 / 统一性；第251—255页强调活动与结果区别 |
| Verknüpfung | 联结；不与Vereinigung的特定义混用 |
| ursprüngliche Erwerbung | 原始的获得；第253页自然法学术语，不机械译源始获得 |
| anerschaffen | 在创生时便一并赋予的；与心理活动后产生的表象不同 |

第七章补充：

| 原词 | 采用译法及语境 |
| --- | --- |
| einzelnes / besonderes / allgemeines Urtheil | 判断表量类为单称 / 特称 / 全称判断；不机械扩及日常的einzeln或besonders |
| Vielheit / Mehrheit | 本章均用复多性；非多数对少数的比例 |
| Position / Setzung | 设定；不是空间位置 |
| Sein / Dasein / Realität | 第283页特定义：存在 / 定在 / 实在性；其他普通语境按全书统检判定 |
| empirische Urtheile / Erfahrungsurtheile | 经验性判断 / 经验判断；第288页规定前后层次不可抹平 |
| Formeln / Formen | 公式 / 形式 |

第八章补充：

| 原词 | 采用译法及语境 |
| --- | --- |
| Gattungsausdruck / Art zur Gattung | 属概念表达 / 种对属的关系；p310及312指统觉、知性及诸概念之间的涵盖关系 |
| Vereinigung / Einheit / verbinden | 统一活动 / 统一性 / 联结；p321—325自我、概念和对象关系中保持行动与结果的区别 |
| Muss-können | 必须能够；官能为可能性的先验条件，不预设现实意识先于所有表象 |
| selbstgedachte erste Principien | 由自己思得的首要原则；不是以自己为对象的被思维原则 |

第九章补充：

| 原词 | 采用译法及语境 |
| --- | --- |
| materialer Idealismus / materialistische Denkweise | 质料唯心主义 / 唯物主义的思想方式；同章两者不能混淆 |
| Singular Ich | 单数形式的我；语法形式，不能译成单一实体 |
| eigentlich | 第346页严格说来，作者特别强调的限制，非时间上的本来 |
| Bestand / Entstehung der Erfahrung | 第348页经验的成立 / 经验的产生；Bestand保留德词，与心理发生有别，不机械改变空间共在等语境的持存 |
| daraus klug werden | 弄懂，从中获得明白的理解；非变得聪明 |

第十章补充：

| 原词 | 采用译法及语境 |
| --- | --- |
| Realdefinition / Nominaldefinition | 实在定义 / 名义定义；数学的Erklärungen在相关长引中也指此类定义 |
| Dianoiol.（Dianoiologie） | 思维论；Lambert《新工具论》第一部，非辩证术 |
| constituirbar / construirt | 可构成的 / 被建构的；范畴构成对象与空间直观建构不能互换 |
| auf- nnd in Schutz genommen（原印） | 按auf- und理解：接纳并加以庇护；两个动词共享genommen，保留原印nnd并说明 |

第十一章补充：

| 原词 | 采用译法及语境 |
| --- | --- |
| Kurzer Begriff dieser Deduction | 这一演绎的简要概述；康德总结一节的标题，此处非简短概念 |
| Recognition im Begriffe | 概念中的再认；与前章三重综合术语一致 |
| erste / ursprüngliche | 首要 / 源始；第378页并见两词，不混为源初 |
| aufgehoben als reines Bewusstsein | 失去作为纯粹意识的地位；第376页不作黑格尔意义扬弃 |
| Subject / Prädicat | 逻辑判断中主词 / 谓词，区别认识主体；第388页实体例亦为主词 |
| dürfen / müssen | 第388页可以超出图像 / 必须可图像化；不是两个不得不 |
| identische / nicht identische Urtheile | 同一 / 非同一判断；第394页不可擅换成分析 / 综合判断 |
| willkürliche Definition | 第392—393页约定的定义；名义规定不等于任意无据的判定 |
| positive / negative | 肯定 / 否定；与矛盾律的否定标准对举，不用积极 / 消极 |
| nach der Definition | 在定义之后；第399页先后关系，不是按照定义 |

第十二章补充：

| 原词 | 采用译法及语境 |
| --- | --- |
| Quantität / Grösse | 量的范畴 / 量或大小；412页逻辑分类以原词辅助区分，不能把Grösse的每次出现都机械替换 |
| extensive / intensive Grösse | 广延量 / 强度量（亦称内包量）；不混逻辑外延 |
| Quantum / Grad | 一个量 / 度；非现代量子、非分类等级 |
| Zahl-/Reiz-/Bewegungseinheit | 数单位 / 刺激单位 / 运动单位，区别意识统一性 |
| Moment | 第464页动因，因果作用之度；依据康德AA III153/179作语境释译，非时间瞬刻 |
| Consequenz / Function | 假言推承关系 / 逻辑功能；第448—453页不是后件命题或数学函数 |
| Handlung | 力和实体的作用；认识能力的活动。按语境区分，不一律译行动 |
| Wahrscheinlichkeit / problematisch | 第482页盖然性 / 或然模态；避免盖然判断作为或然判断的区别被同词抹平 |
| Gemeingebilde / Einzelgestalten | 普遍形态 / 个别形态 |
| realisiren / verwirklichen | 在相关论证中使内容获得实在性 / 使之成为现实；保持实在者与现实者之别 |
| Gemeinschaft / Wechselwirkung | 共联性 / 相互作用；第467页原文明确区分范畴名称与相互致因 |

原印异文在 source_display_text 中按证据保留；不凭常见拼写改书目或引文。德文分词须参照语境及原图，尤其多字母块、跨行断词与希腊文。

第十三章补充：

| 原词 | 采用译法及语境 |
| --- | --- |
| Grundsatz / Princip | 原理 / 原则；综合知性原理与理念的调节性原则分开 |
| Möglichkeit der Erfahrung / mögliche Erfahrung | 经验的可能性 / 可能经验，不能缩为同一短语 |
| beschränken / begrenzen | 限制 / 划界；划界具有积极的系统任务，不一律用限制 |
| intellectuale Anschauung / intuitiver Verstand | 智性直观 / 直观知性，避免互相倒置 |
| aus Begriffen / durch Begriffe | 出自概念 / 通过概念；本章强调二者区别 |
| mechanisch / maschinenartig | 本章力学的 / 机器式的；原文509明确区分两种因果性表述 |
| teleologisch / Zweckmässigkeit | 目的论的 / 合目的性，不把前者写作合目的论 |
| zeugen / Aufgabe | 519页知识有所生发 / 作为研究任务提出，非作证、非现成给予 |

第十四章补充：

| 原词 | 采用译法及语境 |
| --- | --- |
| a parte priori / posteriori | 时间序列的先行一侧 / 后续一侧；533—534非先验/后天 |
| Elementarsubstanz / erstes Subject | 基本实体 / 最初基体，544页非化学元素或认识主体 |
| Einwicklung | 547页无限嵌套，非展开；对应层层分节的有机体论证 |
| Materie / Masse | 物质 / 质量；550页质量构成是力学问题，不是质料 |
| Einheit | 量的测度中为单位；意识和系统语境为统一性 |
| Zweckprincip / Axiom / Postulat | 目的原则 / 公理 / 公设，各保留区别 |
| abgesetzt / beibehalten | 548页撤去实在性地位 / 保留调节理念，不能把前者反译为确立 |

第十五章补充：

| 原词 | 采用译法及语境 |
| --- | --- |
| aufgeben | 553页向知性提出任务；非放弃 |
| focus imaginarius | 虚焦点，光学比喻；非想象力官能的焦点 |
| Gleichartigkeit / collectiv / distributiv | 同类性 / 集合的 / 分配的 |
| Heautonomie / Autonomie | 自为立法 / 自律；判断力为自身反思立法，AA V185—186 |
| Casualität / Causalität | 偶然性 / 因果性；566页前者，已据原图及AA V391核实 |
| Endursachen / Revolutionen | 目的因 / 地质剧变（568页语境） |
| Mechanik / Mechanismus | 力学 / 力学机制或机械式解释，结合自然研究语境 |

第十六章补充：

| 原词 | 采用译法及语境 |
| --- | --- |
| Lehrsatz / Grundsatz | 学说命题 / 原理，575—578不可混同 |
| Borger / Bürger | 借用者 / 市民，588原印前者，非后者 |
| Person / Wesen | 伦理语境人格者 / 存在者，区别抽象人格与本质 |
| Aesthetik | 609—610与逻辑学对举为感性论；系统第三部分为美学 |
| Schranke / Grenze | 限制 / 界限，614—616明确对举；Begrenzung为划界 |
| Erzeugungs-Grösse | 生成量；与强度量、广延量相关，非量子 |
| für / in | 598为意识与感觉证成实在性 / 意识与感觉中的实体，保留对比 |
