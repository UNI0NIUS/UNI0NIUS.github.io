"""Export two complete Markdown editions from the common reading projection."""
from pathlib import Path
from collections import defaultdict
import json,re,hashlib,html
R=Path(__file__).resolve().parent;O=R.parents[1]/'output/reviewed'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
class MD:
 def __init__(self,d,lang):
  self.d=d;self.lang=lang;self.out=[];self.last=None;self.refs=set();self.note_ids=set();self.components_seen=[]
  self.byscope=defaultdict(list)
  for n in d['notes']:self.byscope[n['scope']].append(n)
 def text(self,s,pages=True):
  def pg(m):
   p=m.group()[3:-1]
   if not pages:return ''
   if self.last==p:return ''
   self.last=p;return '〔原页 '+p+'〕' if self.lang=='zh' else '[S. '+p+'] '
  return re.sub(r'⟦p\.[^⟧]+⟧',pg,s).replace('√Σdx²',r'$\sqrt{\Sigma\,dx^{2}}$')
 def runs(self,ts,lang=None,pages=True):
  lang=lang or self.lang;out=[]
  for t in ts:
   if t['type']=='text':out.append(self.text(t['text'],pages))
   else:
    self.refs.add(t['note_id']);out.append('<a id="ref-'+lang+'-'+t['ref_id']+'"></a><sup><a href="#note-'+t['note_id']+'">'+html.escape(t['label'])+'</a></sup>')
  return ''.join(out)
 def component(self,c,lang=None,pages=True):
  lang=lang or self.lang;prefix=''.join('<a id="'+lang+'-'+i+'"></a>' for i in c['anchor_ids'])
  self.components_seen.append((lang,c['id']))
  ts=c[lang+'_runs']
  if pages and c.get('page_label') and not(ts and ts[0]['type']=='text' and ts[0]['text'].startswith('⟦p.')):prefix+=self.text('⟦p.'+c['page_label']+'⟧')
  return prefix+self.runs(ts,lang,pages)
 def components(self,cs,lang=None,pages=True,paragraphs=False):
  lang=lang or self.lang
  return ''.join((('\n\n' if paragraphs else c['source_joiner' if lang=='de' else 'translation_joiner']) if i else '')+self.component(c,lang,pages) for i,c in enumerate(cs))
 def editorial(self,cs):
  for c in cs:
   for n in c['editorial_notes']:
    s=(n.get('zh') or n.get('translation')) if self.lang=='zh' else (n.get('de') or n.get('source'))
    self.out.append(('> 〔编者按〕' if self.lang=='zh' else '> [Redaktionelle Erläuterung] ')+s)
 def endnotes(self,scope):
  ns=self.byscope.get(scope,[])
  if not ns:return
  self.out.append('### '+('原注' if self.lang=='zh' else 'Anmerkungen'))
  for n in ns:
   self.note_ids.add(n['id']);ps=n['printed_pages'];pg=str(ps[0]) if len(ps)==1 else str(ps[0])+'–'+str(ps[-1])
   s='<a id="note-'+n['id']+'"></a><strong>[S. '+pg+'] '+html.escape(n['number'])+'</strong> '+self.components(n['components'],pages=False,paragraphs=True)
   s+=' <a href="#ref-'+self.lang+'-'+n['ref_id']+'">↑</a>'
   if self.lang=='zh':s+='\n\n原文：'+self.components(n['components'],'de',False,True)
   self.out.append(s);self.editorial(n['components'])
 def group(self,g):
  k=g['kind']
  if k=='toc_entry':
   e=g['entry'];self.out.append('**['+e['title_'+self.lang]+' '+str(e['original_target_page'])+'](#'+self.lang+'-'+e['target_unit_id']+')**\n\n'+self.text(e['summary_'+self.lang]));self.editorial(g['components']);return
  s=self.components(g['components'])
  if k.endswith('heading'):s=('# ' if k in ['chapter_heading','part_heading'] else '## ')+s
  self.out.append(s);self.editorial(g['components'])
 def render(self):
  self.out=['# '+('康德的经验理论' if self.lang=='zh' else 'Kants Theorie der Erfahrung'),'赫尔曼·柯亨 / Hermann Cohen\n\n1885年第二版 / Zweite neubearbeitete Auflage, Berlin 1885.',('原页码与阅读版页码分别处理；原注保留页内编号及返回链接，中文原注附德文全文。前置首叶未印罗马页码按后续印刷序列标识。' if self.lang=='zh' else 'Die Seitenverweise beziehen sich auf den Originaldruck. Originalanmerkungen behalten ihre seitenweise Nummerierung und Rückverweise. Ungedruckte römische Anfangsseiten sind aus der folgenden Druckfolge erschlossen.')]
  for f in self.d['front']:
   scope=None
   for g in f['groups']:
    if scope is not None and scope!=g['scope']:self.endnotes(scope)
    scope=g['scope'];self.group(g)
   if scope:self.endnotes(scope)
  scope=None
  for g in self.d['groups']:
   if scope is not None and scope!=g['scope']:self.endnotes(scope)
   scope=g['scope'];self.group(g)
  if scope:self.endnotes(scope)
  for c in self.d['colophons']:self.out.append(self.component(c,pages=False))
  expected={n['id'] for n in self.d['notes']};assert self.refs==self.note_ids==expected
  text='\n'.join(line.rstrip() for line in '\n\n'.join(self.out).splitlines())+'\n'
  ids=re.findall(r'<a id="([^"]+)"',text);assert len(ids)==len(set(ids))
  links=re.findall(r'(?:href="\#|\]\(\#)([^"\)]+)',text);assert set(links)<=set(ids),(set(links)-set(ids))
  assert not re.search('[⟦⟧]',text)
  return text
def main():
 d=json.loads((R/'reading_projection.json').read_text('utf-8'));assert d['canonical_sha256']==sha(R/'translation_units.jsonl') and d['front_matter_sha256']==sha(R/'front_matter.json')
 report={}
 for lang in ['zh','de']:
  md=MD(d,lang);text=md.render();p=O/f'cohen_kte1885_{lang}.md';p.write_text(text,encoding='utf-8',newline='\n')
  report[lang]=dict(sha256=sha(p),bytes=p.stat().st_size,notes=len(md.note_ids),unique_anchors=True,internal_links_resolve=True,components=len(md.components_seen))
 (R/'markdown_export_check.json').write_text(json.dumps(dict(status='exported_internal_structure_passed_pending_independent_text_readback',canonical_sha256=d['canonical_sha256'],front_matter_sha256=d['front_matter_sha256'],editions=report),ensure_ascii=False,indent=2)+'\n','utf-8')
 print(json.dumps(report,ensure_ascii=False))
if __name__=='__main__':main()
