"""Stage a union subset; never writes the shared live-site font."""
from pathlib import Path
import argparse,json,hashlib
from fontTools import subset
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont
R=Path(__file__).resolve().parent;O=R.parents[1]/'output/reviewed';W=O/'website_fonts'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--site-font',type=Path,required=True);ap.add_argument('--source-font',type=Path,required=True);a=ap.parse_args()
 current=TTFont(a.site_font);old=set(current.getBestCmap());text=''.join(p.read_text('utf-8') for p in (O/'webdata').glob('*.json'));book={ord(c) for c in text if ord(c)>=0x2e80 or 0x2100<=ord(c)<0x2300};needed=old|book
 source=TTFont(a.source_font);assert not(needed-set(source.getBestCmap()))
 opts=subset.Options();opts.name_IDs=['*'];opts.name_legacy=True;opts.name_languages=['*'];sub=subset.Subsetter(options=opts);sub.populate(unicodes=needed);sub.subset(source)
 axes={'wght':(400,400,600)}
 if any(x.axisTag=='wdth' for x in source['fvar'].axes):axes['wdth']=100
 instantiateVariableFont(source,axes,inplace=True);source.flavor='woff2';W.mkdir(exist_ok=True);dest=W/'reading-cjk.woff2';source.save(dest)
 got=TTFont(dest);cmap=got.getBestCmap();assert not(needed-set(cmap))
 # Advance widths for every existing encoded glyph must remain identical.
 previous=current.getBestCmap();metric_changes=[c for c in old if current['hmtx'].metrics[previous[c]][0]!=got['hmtx'].metrics[cmap[c]][0]]
 assert not metric_changes,metric_changes
 report=dict(status='union_subset_staged_pending_browser',prior_site_font_sha256=sha(a.site_font),source_font_sha256=sha(a.source_font),output_sha256=sha(dest),previous_glyphs=len(old),book_glyphs=len(book),new_glyphs=len(book-old),new_chars=''.join(map(chr,sorted(book-old))),output_glyphs=len(cmap),existing_glyphs_retained=True,existing_advance_widths_unchanged=True,weights=axes,license='SIL OFL 1.1; homepage-union/fonts/OFL-NotoSerifSC.txt',output='output/reviewed/website_fonts/reading-cjk.woff2')
 (R/'web_font_expansion.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8');print(json.dumps(report,ensure_ascii=False))
if __name__=='__main__':main()
