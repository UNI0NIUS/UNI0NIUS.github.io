# 独立校对术语决定

初译术语表冻结在 baseline/work/translation/glossary.md；以下仅列实际修订和适用语境，禁止机械全书替换。

| 原词 | 采用译法 | 适用范围及依据 |
| --- | --- | --- |
| sachlich | 实质性的 | 导论首节与historisch对举，标题与正文一致；非Stoff或materiell“质料的”。 |
| a priori / apriorisch | 先天 / 先天的 | 必须区别于transscendental“先验的”；导论末三页尤其讨论由形而上学的先天到先验的先天。 |
| Apriorismus | 先天论 | 导论75页，承认不可分析的先天要素，不直接等同先验方法。 |
| mechanisch / Mechaniker | 力学的 / 力学家 | 导论36—41页，涉及广延、力、无穷小及几何学与力学的科学分工，不把身份译为机械论者；其他语境另判。 |
| material（对formal） | 内容方面的 | 导论39页真理种类及40页逻辑的形式/内容，非物质性的；笛卡尔心理学的materiale Ideen另按语境保留。 |
| mundus intelligibilis | 理智世界 | 导论3及62—63页，与精神/目的王国或感性世界相对，不是泛指可知世界。 |
| impressionirend | 引起感觉印象的 | 感觉论语境中的事物作用，不是日常给人留下印象。 |
| hinreichende und nothwendige Bedingungen | 充分且必要的条件 | 导论77—79页，不能把notwendig改成某行为必然发生。 |

同一论文题名 Die systematischen Begriffe in Kants vorkritischen Schriften 统一作《康德批判前著作中的体系性概念》，保留德文与页码以供检索。

第一章：Fähigkeit／Vermögen在p108刻意区分，分别译“能力”／“官能”；sensual／sensitiv分别为“感觉的”／“感性的”，不把二者混同。intuitiv／discursiv在认识方式对举中用“直观”／“推论”。denken／vorstellen及各自排除式明确为“在思维中排除”／“在表象中排除”。既有stabilitas、denkliche与Jabob原印保留；p112法文异常另见双语校注。
