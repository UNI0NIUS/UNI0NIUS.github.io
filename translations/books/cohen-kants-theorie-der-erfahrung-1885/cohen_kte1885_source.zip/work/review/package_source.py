"""Package only accepted canonical inputs and non-destructive reading tools."""
from pathlib import Path,PurePosixPath
import json,hashlib,zipfile,subprocess,sys
R=Path(__file__).resolve().parent;B=R.parents[1];O=B/'output/reviewed';Z=O/'cohen_kte1885_source.zip'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(v):return (json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
files={}
def add(p):
 assert p.is_file(),p
 name=p.relative_to(B).as_posix();assert '_archive' not in name and '__pycache__' not in name
 files[name]=p.read_bytes()
for n in ['translation_units.jsonl','front_matter.json','reading_projection.json','build_reading_projection.py','build_reading_editions.py','export_markdown.py','export_web.py','audit_web.py','audit_output_text.py','prepare_cjk_font.py','package_source.py','template_reference.json','terminology.md','terminology_decisions.md','reading_projection_check.json','edition_build_manifest.json','output_text_audit.json','pdf_visual_check.json','markdown_export_check.json','web_export_check.json','web_text_readback.json','web_font_coverage.json','web_font_expansion.json','global_issues.json']:
 add(R/n)
for p in (R/'templates').glob('*.tex'):add(p)
for p in (R/'chapter_reports').glob('*.json'):add(p)
for folder,names in {'baseline':['manifest.json'],'front_review':['front_acceptance.json','prefaces_evidence.json','toc_evidence.json'],'global_review':['global_acceptance.json'],'source_audit':['body_coverage_acceptance.json','body_line_decisions.json','body_page_dependencies.json','front_back_inventory.json']}.items():
 for n in names:add(R/folder/n)
for mode in ['zh','de','bilingual']:add(O/f'cohen_kte1885_{mode}.tex')
for lang in ['zh','de']:add(O/f'cohen_kte1885_{lang}.md')
for p in (O/'webdata').glob('*.json'):
 add(p)
 if p.name=='book-metadata.json':
  generated_meta=json.loads(p.read_text('utf-8'));generated_meta['downloads']=[];files[p.relative_to(B).as_posix()]=dump(generated_meta)
add(O/'website_fonts/reading-cjk.woff2')
license=R.parents[3]/'homepage-union/fonts/OFL-NotoSerifSC.txt';files['output/reviewed/website_fonts/OFL-NotoSerifSC.txt']=license.read_bytes()
readme='''# 《康德的经验理论》1885第二版校订源码

作者 Hermann Cohen；原版 Berlin: Ferd. Dümmlers Verlagsbuchhandlung, 1885，重新修订第二版。

规范数据为 work/review/translation_units.jsonl（1950正文/原注父单元）和 front_matter.json（56前置单元）。原文、原注、来源范围、原页码、显示订正和编者按均保留；完整阅读共有404条实际原注、47个原作导航入口（25个子节）。中文原注附完整德文。

只从本包当前规范数据生成。包内不含生产者批次生成器、一次应用修订器、网站迁移器、凭据或其他书目。不要从历史批次重建或覆盖规范稿。JSON验收报告绑定各自实际输入版本，早期章报告中的待办不代表当前版本待办。图像目视证据保存在生产工作区；本包附报告，不冒称全书每页图像逐字核过。

## 重生成

Python 3.11或更新版本；生成器使用标准库。PDF独立回读另需PyMuPDF。字体重制另需FontTools与Brotli；通常直接复用已附WOFF2。工作目录设为本README所在的书目根目录，按序运行：

    python work/review/build_reading_projection.py
    python work/review/build_reading_editions.py
    python work/review/export_markdown.py
    python work/review/export_web.py
    python work/review/audit_web.py

三个TeX和两份Markdown生成到 output/reviewed；47章JSON及生成阶段book-metadata.json在其webdata/。网页依赖表站现用translations.js、bilingual-reader.js、translations.css及KaTeX，沿用en字段保存德文。生成阶段元数据downloads为空，由发布步骤填入六下载大小与哈希；本包不会内嵌自己的ZIP哈希。公开阅读地址 https://uni0nius.github.io/translations/book.html?id=cohen-kants-theorie-der-erfahrung-1885 。本次仅发布表站。

## PDF编译

安装XeLaTeX（TeX Live或MiKTeX）及模板所列宏包；正式字体为Times New Roman、SimSun；希腊文由主字体呈现，数学符号由TeX数学字体呈现。Windows字体按字体名称查找，无机器专用绝对路径。可给PDF生成命令追加 --compile，或在 output/reviewed 对三个tex分别运行xelatex两次以更新目录和跳转。正式版中文250页、德文251页、对照487页；纸张A4，中文11pt/25mm，德文与对照10pt、内20外23上21下23mm。原注在原作小节末；原书页码与阅读页码分列。PDF构建时间等元数据可能改变字节哈希，内容和版式验收需绑定实际输出。

## 原件与定位

原扫描件 Kants Theorie der Erfahrung 1885.pdf 保留在生产工作区，未重复放进源码ZIP；653个PDF页，24,061,713字节，SHA256 8d88e78b785a6974b7fc35c21c81427e2c618e0af455e62ead29e62501037992。
正文印刷1—616页对应PDF32—647页；该偏移仅适用于正文。前置罗马页与无页码扫描/馆藏附属页依front_back_inventory.json分别定位。规范单元保存原始来源定位及德文；疑点有定向重OCR和原图核实记录。body_coverage_acceptance.json验收24112条正文PDF文字层来源行，不能据此声称616页图像逐字目视。原目录误印348/554保留并双语披露，导航跳实际349/551页。

## 包完整性

source-manifest.json列出本包所有其他成员的字节数和SHA256。三份正式PDF分别作为网站下载提供，不重复收入源码ZIP；相关PDF验收报告保留。规范稿SHA、排版、语义、覆盖、网页回读分别记录。source_package_check.json在生产工作区另记打包后的完整读取和隔离复现结果。
'''
files['README.md']=readme.encode('utf-8')
manifest=dict(schema=1,canonical_sha256=sha(R/'translation_units.jsonl'),front_matter_sha256=sha(R/'front_matter.json'),members={n:dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest()) for n,b in sorted(files.items())})
files['source-manifest.json']=dump(manifest)
with zipfile.ZipFile(Z,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(files.items()):
  info=zipfile.ZipInfo(n,date_time=(2026,10,27,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,b)
with zipfile.ZipFile(Z) as z:
 assert z.testzip() is None
 for n,b in files.items():assert z.read(n)==b
 for n in z.namelist():assert not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts
 dest=R/('source_package_repro_'+hashlib.sha256(Z.read_bytes()).hexdigest()[:12]);assert not dest.exists(),'Reproduction evidence already exists for this exact package'
 z.extractall(dest)
logs={}
for n in ['build_reading_projection.py','build_reading_editions.py','export_markdown.py','export_web.py','audit_web.py']:
 cp=subprocess.run([sys.executable,'-X','utf8',str(dest/'work/review'/n)],cwd=dest,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 logs[n]=dict(returncode=cp.returncode,tail=cp.stdout.decode('utf-8',errors='replace')[-800:]);assert cp.returncode==0,logs[n]
same=[]
for n in [f'cohen_kte1885_{x}.tex' for x in ['zh','de','bilingual']]+[f'cohen_kte1885_{x}.md' for x in ['zh','de']]:
 assert sha(O/n)==sha(dest/'output/reviewed'/n),n;same.append(n)
for p in (O/'webdata').glob('*.json'):
 expected=json.loads(p.read_text('utf-8'))
 if p.name=='book-metadata.json':expected['downloads']=[]
 assert expected==json.loads((dest/'output/reviewed/webdata'/p.name).read_text('utf-8')),p.name
assert json.loads((R/'reading_projection.json').read_text('utf-8'))==json.loads((dest/'work/review/reading_projection.json').read_text('utf-8'))
report=dict(status='source_package_integrity_and_reproduction_passed',sha256=sha(Z),bytes=Z.stat().st_size,members=len(files),canonical_sha256=manifest['canonical_sha256'],front_matter_sha256=manifest['front_matter_sha256'],all_members_read_back=True,path_safety=True,isolated_reproduction=dict(projection_identical=True,TeX_and_Markdown_byte_identical=same,web_48_json_parsed_identical=True,logs=logs),pdf_recompilation='not repeated: accepted unchanged PDFs and TeX reused; generation parity proven in isolation')
(R/'source_package_check.json').write_bytes(dump(report));print(json.dumps({k:report[k] for k in ['status','sha256','bytes','members']},ensure_ascii=False))
