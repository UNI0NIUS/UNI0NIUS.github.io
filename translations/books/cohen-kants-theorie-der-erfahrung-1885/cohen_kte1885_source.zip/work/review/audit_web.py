"""Independent canonical-to-web text and link audit; no export imports."""
from pathlib import Path
import hashlib,json,re,unicodedata,sys
R=Path(__file__).resolve().parent
O=R.parents[1]/'output/reviewed'
W=Path(sys.argv[1]) if len(sys.argv)>1 else O/'webdata'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def norm(t):
 t=re.sub(r'⟦p\.[^⟧]+⟧|\[S\.\s*[^\]]+\]|\[原书第[^\]]+页\]','',t)
 t=t.replace(r'\Sigma','Σ').replace(r'\sqrt','').replace(r'\,','')
 return ''.join(c for c in unicodedata.normalize('NFKC',t) if c.isalnum())
def walk(ts):
 for t in ts:
  yield t
  if isinstance(t,dict):yield from walk(t.get('children',[]))
def plain(ts,notes):
 out=[]
 for t in ts:
  if isinstance(t,str):out.append(t)
  elif t.get('type')=='note':out.append(str(notes[t['id']]['number']))
  elif t.get('type')=='math':out.append(t['tex'])
  elif t.get('type') not in ['anchor','page']:out.append(plain(t.get('children',[]),notes))
 return ''.join(out)
meta=json.loads((W/'book-metadata.json').read_text('utf-8'));chapters={};texts={'zh':[],'de':[]};anchors={};links=[];notes=set()
for ch in meta['chapters']:
 d=json.loads((W/(ch['id']+'.json')).read_text('utf-8'));chapters[ch['id']]=d
 ids=[row['id'] for row in d['body']];assert len(ids)==len(set(ids))
 for lang,key in [('zh','zh'),('de','en')]:
  refs=set();a=set(ids)
  for row in d['body']+list(d['notes'].values()):
   texts[lang].append(plain(row[key],d['notes']))
   for t in walk(row[key]):
    if not isinstance(t,dict):continue
    if t.get('type')=='note':refs.add(t['id'])
    if t.get('type')=='anchor':a.add(t['id'])
    if t.get('type')=='link':links.append(t['url'])
  assert refs==set(d['notes']),(ch['id'],key,'note mismatch')
  anchors.setdefault(ch['id'],set()).update(a)
 notes.update(d['notes'])
assert len(chapters)==47 and len(notes)==404
for url in links:
 m=re.search(r'chapter=([^&#]+)#(.+)',url)
 if m:assert m[1] in anchors and m[2] in anchors[m[1]],url
units=[json.loads(s) for s in (R/'translation_units.jsonl').read_text('utf-8').splitlines()]
units += [u for f in json.loads((R/'front_matter.json').read_text('utf-8')) for u in f['units']]
expected=[]
for u in units:
 for v in u.get('note_parts',[u]):
  de=v.get('source_display_text',v['source_text']);zh=v['translation']
  for b in v.get('reading_blocks') or [dict(source_range=[0,len(de)],translation_range=[0,len(zh)])]:
   expected.append(dict(id=b.get('id',v['id']),de=de[slice(*b['source_range'])],zh=zh[slice(*b['translation_range'])]))
texts={k:norm(''.join(v)) for k,v in texts.items()};candidates=[]
for e in expected:
 for lang in ['zh','de']:
  t=norm(e[lang])
  if t and t not in texts[lang]:candidates.append(dict(id=e['id'],lang=lang,start=e[lang][:100]))
report=dict(status='web_canonical_text_readback_passed' if not candidates else 'candidates_pending',canonical_sha256=sha(R/'translation_units.jsonl'),front_matter_sha256=sha(R/'front_matter.json'),chapters=47,notes=404,checked_components_per_language=len(expected),candidates=candidates,links_resolve=True,files={p.name:sha(p) for p in W.glob('*.json')},normalization='NFKC/alphanumeric; original-page labels excluded, math TeX normalized; every original note part and reading block checked independently.')
(R/'web_text_readback.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='files'},ensure_ascii=False));assert not candidates
