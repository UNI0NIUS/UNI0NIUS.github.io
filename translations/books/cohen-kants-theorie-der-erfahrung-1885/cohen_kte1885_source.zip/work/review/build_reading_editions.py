"""Current reading PDF builder. Only consumes the accepted common projection."""
from pathlib import Path
from collections import defaultdict
import json,re,hashlib,subprocess,sys
R=Path(__file__).resolve().parent;O=R.parents[1]/'output/reviewed'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def esc(s):return ''.join({'\\':r'\textbackslash{}','&':r'\&','%':r'\%','$':r'\$','#':r'\#','_':r'\_','{':r'\{','}':r'\}','~':r'\textasciitilde{}','^':r'\textasciicircum{}'}.get(c,c) for c in str(s))
class Renderer:
 def __init__(self,d,mode,prototype=False):
  self.d=d;self.mode=mode;self.bi=mode=='bilingual';self.prototype=prototype;self.out=[];self.opened=False;self.last={'zh':None,'de':None};self.refs=defaultdict(set);self.labels=[]
  self.notes={n['id']:n for n in d['notes']};self.byscope=defaultdict(list)
  for n in d['notes']:self.byscope[n['scope']].append(n)
 def text(self,s,lang,pages=True):
  if lang=='de':s=re.sub(r'„\s+','„',re.sub(r'\s+“','“',s))
  out=[]
  for x in re.split(r'(⟦p\.[^⟧]+⟧|√Σdx²)',s):
   if x.startswith('⟦p.'):
    p=x[3:-1]
    if pages and p!=self.last[lang] and not(self.bi and lang=='de'):
     out.append(r'\sourcepage{'+esc(p)+'}');self.labels.append(p)
    if pages:self.last[lang]=p
   elif x=='√Σdx²':out.append(r'\(\sqrt{\Sigma\,dx^{2}}\)')
   else:
    v=esc(x).replace('\n\n',r'\par ').replace('\n',r'\newline ')
    if lang=='de':v=v.replace('„',r'\deopenquote{}').replace('“',r'\nobreak\declosequote{}')
    out.append(v)
  return ''.join(out)
 def runs(self,ts,lang,pages=True):
  out=[]
  for t in ts:
   if t['type']=='text':out.append(self.text(t['text'],lang,pages))
   else:
    nid=t['note_id'];ref=t['ref_id'];self.refs[lang].add(nid)
    out.append(r'\hypertarget{ref-'+lang+'-'+ref+r'}{}\hyperlink{note-'+nid+r'}{\textsuperscript{'+esc(t['label'])+'}}')
  return ''.join(out)
 def component(self,c,lang,pages=True):
  anchor=''.join(r'\hypertarget{'+lang+'-'+i+'}{}' for i in c['anchor_ids'])
  rs=c[lang+'_runs'];prefix=''
  if pages and c.get('page_label') and not (rs and rs[0]['type']=='text' and rs[0]['text'].startswith('⟦p.')):prefix=self.text('⟦p.'+c['page_label']+'⟧',lang,pages)
  return anchor+prefix+self.runs(rs,lang,pages)
 def components(self,cs,lang,pages=True):
  return ''.join((self.text(c['source_joiner' if lang=='de' else 'translation_joiner'],lang,False) if i else '')+self.component(c,lang,pages) for i,c in enumerate(cs))
 def note_components(self,cs,lang):
  return r'\par '.join(self.component(c,lang,False) for c in cs)
 def close(self):
  if self.opened:self.out.append(r'\end{paracol}');self.opened=False
 def pair(self,zh,de,small=False):
  if small:zh=r'{\small '+zh+'}';de=r'{\small '+de+'}'
  if self.bi:
   if not self.opened:self.out.append(r'\begin{paracol}{2}');self.opened=True
   self.out += [zh+r'\par',r'\switchcolumn',de+r'\par',r'\switchcolumn*']
  else:self.out.append((zh if self.mode=='zh' else de)+r'\par')
 def plain(self,zh,de,small=False,pages=False):self.pair(self.text(zh,'zh',pages),self.text(de,'de',pages),small)
 def editorial(self,cs):
  for c in cs:
   for n in c['editorial_notes']:
    zh=n.get('zh') or n.get('translation');de=n.get('de') or n.get('source');assert zh and de
    self.plain('〔编者按〕'+zh,'[Redaktionelle Erläuterung] '+de,True)
 def heading(self,g):
  self.close();kind=g['kind'];cs=g['components'];chapter=kind in ['chapter_heading','part_heading']
  if chapter:self.out.append(r'\clearpage')
  self.out.append(r'\needspace{7\baselineskip}')
  zh=self.components(cs,'zh');de=self.components(cs,'de');title=''.join(t.get('text','') for c in cs for t in c[('de' if self.mode=='de' else 'zh')+'_runs']).replace('\n',' ')
  title=re.sub(r'⟦p\.[^⟧]+⟧\s*','',title).strip()
  cmd='section' if chapter or kind=='section_heading' and str(g['scope']).startswith('front-') else 'subsection'
  self.out.append('\\'+cmd+'['+esc(title)+']{'+(zh+r'\\{\normalsize '+de+'}' if self.bi else zh if self.mode=='zh' else de)+'}')
  self.editorial(cs)
 def endnotes(self,scope):
  ns=self.byscope.get(scope,[])
  if self.prototype:
   selected=set(self.refs['de'])
   for n in ns:
    if n['id'] in selected:
     selected.update(t['note_id'] for c in n['components'] for t in c['de_runs'] if t['type']=='note_ref')
   ns=[n for n in ns if n['id'] in selected]
  if not ns:return
  self.close();self.out.append(r'\needspace{6\baselineskip}\subsection*{原注 / Anmerkungen}')
  for n in ns:
   nid=n['id'];ps=n['printed_pages'];label=str(ps[0]) if len(ps)==1 else str(ps[0])+'–'+str(ps[-1]);mark=r'{\small [S. '+esc(label)+r']} \textsuperscript{'+esc(n['number'])+'} '
   target=r'\hypertarget{note-'+nid+'}{}'
   zh=target+mark+self.note_components(n['components'],'zh')+r'~\hyperlink{ref-zh-'+n['ref_id']+r'}{\textsuperscript{↑}}'
   de=(target if self.mode=='de' else '')+mark+self.note_components(n['components'],'de')+r'~\hyperlink{ref-de-'+n['ref_id']+r'}{\textsuperscript{↑}}'
   if self.mode=='zh':zh+=r'\par{\small 原文：'+self.note_components(n['components'],'de')+'}'
   self.pair(zh,de,True);self.editorial(n['components'])
  self.close()
 def front(self):
  title=self.d['front'][0]['groups'][0]['components'][0]
  self.out += [r'\begin{titlepage}\centering\vspace*{25mm}{\Huge 康德的经验理论\par}\bigskip{\Large Kants Theorie der Erfahrung\par}\vspace{15mm}{\Large 赫尔曼·柯亨 / Hermann Cohen\par}\bigskip 第二版，重新修订 / Zweite neubearbeitete Auflage\par\vfill',self.text({'zh':'中文校订版','de':'Deutsche Leseausgabe','bilingual':'中德逐段对照版'}[self.mode]+(' · 排版试版 / Satzprobe' if self.prototype else ''),'zh',False),r'\par\bigskip Berlin: Ferd. Dümmlers Verlagsbuchhandlung, 1885\par\end{titlepage}']
  self.plain('页边“S.”为原书页码，页底为本版页码；对照版页标沿中文栏定位。序言和目录首页未印出的罗马页码依后续印刷序列标识。原注置于各原作小节末，保留原页码与页内编号，支持跳转和返回；中文原注附德文全文。编者说明与原注分列。','Die Randverweise „S.“ bezeichnen die Originalseiten; die Fußzeile zählt die Seiten dieser Ausgabe. In der zweisprachigen Ausgabe folgen die Randverweise der chinesischen Spalte. Nicht gedruckte römische Seitenzahlen am Anfang der Vorreden und des Inhaltsverzeichnisses sind aus der folgenden Druckfolge erschlossen. Originalanmerkungen stehen am Abschnittsende mit ursprünglicher Nummer und verknüpften Rückverweisen; redaktionelle Erläuterungen sind gesondert bezeichnet.')
  self.close();self.out.append(r'\clearpage\tableofcontents\clearpage')
  for f in self.d['front']:
   scope=None
   for g in f['groups']:
    if scope is not None and scope!=g['scope']:self.endnotes(scope)
    scope=g['scope'];kind=g['kind']
    if kind.endswith('heading'):self.heading(g)
    elif kind=='toc_entry':
     e=g['entry'];target=e['target_unit_id'];pg=str(e['original_target_page']);self.close()
     z=r'\hyperlink{zh-'+target+'}{'+self.text(e['title_zh']+'　'+pg,'zh',False)+'}'
     d=r'\hyperlink{de-'+target+'}{'+self.text(e['title_de']+'　'+pg,'de',False)+'}'
     self.pair(r'\needspace{4\baselineskip}\noindent\textbf{'+z+'}',r'\needspace{4\baselineskip}\noindent\textbf{'+d+'}')
     self.plain(e['summary_zh'],e['summary_de'],True);self.editorial(g['components'])
    else:self.pair(self.components(g['components'],'zh'),self.components(g['components'],'de'))
   if scope:self.endnotes(scope)
   self.close()
 def render(self):
  geo='a4paper,inner=20mm,outer=23mm,top=21mm,bottom=23mm' if self.bi or self.mode=='de' else 'a4paper,margin=25mm'
  pre=(R/'templates/reading_preamble.tex').read_text('utf-8').replace('SIZE','10pt' if self.bi or self.mode=='de' else '11pt').replace('GEOMETRY',geo+',marginparwidth=16mm,marginparsep=3mm')
  pre=pre.replace(r'\begin{document}',r'\newcommand{\deopenquote}{\leavevmode\begingroup\XeTeXinterchartokenstate=0\char"201E\endgroup}'+'\n'+r'\newcommand{\declosequote}{\leavevmode\begingroup\XeTeXinterchartokenstate=0\char"201C\endgroup}'+'\n'+r'\begin{document}')
  self.out=[pre];self.front();scope=None
  keep={'p063-u0189','p171-u0513','p225-u0682','p299-u0927','p405-n01','p438-u1365','p473-u1487','p540-u1691','p604-u1931','p607-u1943','p611-u1958','p613-u1961','p616-u1970'}
  for g in self.d['groups']:
   if self.prototype and not g['kind'].endswith('heading') and not any(c['unit_id'] in keep for c in g['components']):continue
   if scope is not None and scope!=g['scope']:self.endnotes(scope)
   scope=g['scope']
   if g['kind'].endswith('heading'):self.heading(g)
   else:
    zh=self.components(g['components'],'zh');de=self.components(g['components'],'de')
    if g['kind']=='list_item':zh=r'\noindent '+zh;de=r'\noindent '+de
    self.pair(zh,de);self.editorial(g['components'])
  if scope:self.endnotes(scope)
  self.close()
  for c in self.d['colophons']:self.plain(self.dtext(c,'zh'),self.dtext(c,'de'),True)
  self.close()
  self.out.append(r'\end{document}')
  if not self.prototype:
   for lang in (['zh','de'] if self.bi else [self.mode]):assert self.refs[lang]==set(self.notes),(lang,set(self.notes)^self.refs[lang])
  return '\n'.join(self.out)
 def dtext(self,c,lang):return ''.join(t.get('text','') for t in c[lang+'_runs'])
def main():
 d=json.loads((R/'reading_projection.json').read_text('utf-8'));assert d['canonical_sha256']==sha(R/'translation_units.jsonl') and d['front_matter_sha256']==sha(R/'front_matter.json')
 O.mkdir(parents=True,exist_ok=True);prototype='--prototype' in sys.argv;report={}
 if '--mode' in sys.argv:
  modes=[sys.argv[sys.argv.index('--mode')+1]];assert modes[0] in ['zh','de','bilingual']
  old=json.loads((R/'edition_build_manifest.json').read_text('utf-8'));assert old['canonical_sha256']==d['canonical_sha256'] and old['front_matter_sha256']==d['front_matter_sha256'];report=old['editions']
 else:modes=['bilingual'] if prototype else ['zh','de','bilingual']
 for mode in modes:
  renderer=Renderer(d,mode,prototype);tex=renderer.render();stem='cohen_kte1885_'+('prototype' if prototype else mode);p=O/(stem+'.tex');p.write_text(tex,'utf-8')
  report[mode]=dict(tex_sha256=sha(p),source_page_marks=len(renderer.labels),original_notes=404)
  if '--compile' in sys.argv:
   for n in [1,2]:
    cp=subprocess.run(['xelatex','-interaction=nonstopmode','-halt-on-error',p.name],cwd=O,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(R/f'compile_{stem}_{n}.log').write_bytes(cp.stdout)
    if cp.returncode:print(cp.stdout.decode('utf-8',errors='replace')[-3500:]);raise SystemExit(cp.returncode)
   report[mode]['pdf_sha256']=sha(O/(stem+'.pdf'));print(stem,'compiled',flush=True)
 out=dict(status='compiled_pending_visual_and_text_checks' if '--compile' in sys.argv else 'TeX_generated',canonical_sha256=d['canonical_sha256'],front_matter_sha256=d['front_matter_sha256'],projection_sha256=sha(R/'reading_projection.json'),template=json.loads((R/'template_reference.json').read_text('utf-8')),editions=report)
 (R/('prototype_build_manifest.json' if prototype else 'edition_build_manifest.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n','utf-8')
if __name__=='__main__':main()
