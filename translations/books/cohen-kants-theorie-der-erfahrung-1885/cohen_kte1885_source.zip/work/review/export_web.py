"""Stage outer-reader JSON only; never changes either site's working tree."""
from pathlib import Path
from collections import defaultdict
import json,re,hashlib
R=Path(__file__).resolve().parent;O=R.parents[1]/'output/reviewed';W=O/'webdata';BOOK='cohen-kants-theorie-der-erfahrung-1885'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
def plain(cs,lang):return re.sub(r'⟦p\.[^⟧]+⟧','', ''.join(t.get('text','') for c in cs for t in c[lang+'_runs'])).strip().replace('\n',' ')
class Web:
 def __init__(self,d):self.d=d;self.chapters=[];self.data={};self.scope_to_chapter={};self.id_to_chapter={}
 def chapter(self,cid,zh,de,parent=None):
  m=dict(id=cid,title=zh,originalTitle=de,dataUrl=f'translations/books/{BOOK}/{cid}.json')
  if parent:m['parentId']=parent
  self.chapters.append(m);self.data[cid]=dict(id=cid,title=zh,originalTitle=de,body=[],notes={},sourceLanguage='de',sourceLanguageLabel='Deutsch');return self.data[cid]
 def tokens(self,cs,lang,outer,page=None,original=False,paragraphs=False):
  key='zh' if lang=='zh' else 'de';ts=[];last=str(page) if page is not None else None;count=0
  for j,c in enumerate(cs):
   if j:
    if paragraphs:ts.append(dict(type='break'))
    else:ts.append(c['source_joiner' if key=='de' else 'translation_joiner'])
   prefix=('zh-original-en-' if original else lang+'-')
   ts.extend(dict(type='anchor',id=prefix+i) for i in c['anchor_ids'])
   runs=c[key+'_runs']
   if c.get('page_label') and not(runs and runs[0]['type']=='text' and runs[0]['text'].startswith('⟦p.')):runs=[dict(type='text',text='⟦p.'+c['page_label']+'⟧')]+runs
   for t in runs:
    if t['type']=='note_ref':
     ts.append(dict(type='sup',children=[t['label']]) if original else dict(type='note',id=t['note_id'],label=t['label']))
     continue
    for x in re.split(r'(⟦p\.[^⟧]+⟧|√Σdx²|\n)',t['text']):
     if not x:continue
     if x.startswith('⟦p.'):
      p=x[3:-1]
      if p!=last:
       count+=1;ts.append(dict(type='page',page=p,id=prefix+c['id']+'-page-'+str(count)));last=p
     elif x=='√Σdx²':ts.append(dict(type='math',tex=r'\sqrt{\Sigma\,dx^{2}}'))
     elif x=='\n':ts.append(dict(type='linebreak'))
     else:ts.append(x)
  return ts
 def editorials(self,cs,chapter):
  for c in cs:
   for n in c['editorial_notes']:
    chapter['body'].append(dict(id=n['id'],type='paragraph',page='',zh=[dict(type='block',kind='notice',children=['〔编者按〕'+(n.get('zh') or n.get('translation'))])],en=[dict(type='block',kind='notice',children=['[Redaktionelle Erläuterung] '+(n.get('de') or n.get('source'))])]))
 def group(self,g,chapter):
  self.scope_to_chapter[g['scope']]=chapter['id']
  for c in g['components']:
   self.id_to_chapter[c['unit_id']]=chapter['id']
   for uid in c['anchor_ids']:self.id_to_chapter[uid]=chapter['id']
  if g['kind']=='toc_entry':
   e=g['entry'];chapter['body'].append(dict(id=g['id'],type='paragraph',page=str(e['printed_pages'][0]),_toc=e));return
  cs=g['components'];page=cs[0].get('page_label') or ''
  kind='heading' if g['kind'] in ['part_heading','chapter_heading','section_heading'] else 'subheading' if g['kind']=='subsection_heading' else 'paragraph'
  chapter['body'].append(dict(id=g['id'],type=kind,page=page,zh=self.tokens(cs,'zh',chapter,page),en=self.tokens(cs,'en',chapter,page)))
  self.editorials(cs,chapter)
 def build(self):
  frontlabels=[('title-page','原扉页','Titelblatt'),('dedication','献词','Widmung'),('preface-first','第一版序言','Vorrede zur ersten Auflage'),('preface-second','第二版序言','Vorrede zur zweiten Auflage'),('original-toc','原书目录（含论题提要）','Inhalts-Verzeichniss')]
  for f,(cid,zh,de) in zip(self.d['front'],frontlabels):
   ch=self.chapter(cid,zh,de)
   for g in f['groups']:self.group(g,ch)
  current=None;parent=None;intro=0;sub=defaultdict(int)
  for g in self.d['groups']:
   k=g['kind'];zh=plain(g['components'],'zh');de=plain(g['components'],'de')
   if k=='part_heading':parent='intro';current=self.chapter(parent,zh,de)
   elif k=='chapter_heading':parent=f'chapter-{g["chapter"]:02}';current=self.chapter(parent,zh,de)
   elif k=='section_heading':intro+=1;current=self.chapter(f'intro-{intro:02}',zh,de,parent)
   elif k=='subsection_heading':sub[parent]+=1;current=self.chapter(parent+f'-section-{sub[parent]:02}',zh,de,parent)
   assert current is not None
   self.group(g,current)
  for c in self.d['colophons']:
   current['body'].append(dict(id=c['id'],type='paragraph',page=str(c['printed_pages'][0]),zh=self.tokens([c],'zh',current,None),en=self.tokens([c],'en',current,None)))
  for n in self.d['notes']:
   ch=self.data[self.scope_to_chapter[n['scope']]];ps=n['printed_pages'];pg=str(ps[0]) if len(ps)==1 else str(ps[0])+'–'+str(ps[-1]);cs=n['components']
   zh=['[原书第'+pg+'页] ']+self.tokens(cs,'zh',ch,ps[0],paragraphs=True)
   zh += [dict(type='break'),'原文：']+self.tokens(cs,'en',ch,ps[0],original=True,paragraphs=True)
   en=['[S. '+pg+'] ']+self.tokens(cs,'en',ch,ps[0],paragraphs=True)
   for c in cs:
    for e in c['editorial_notes']:
     zh += [dict(type='break'),'〔编者按〕'+(e.get('zh') or e.get('translation'))]
     en += [dict(type='break'),'[Redaktionelle Erläuterung] '+(e.get('de') or e.get('source'))]
   ch['notes'][n['id']]=dict(number=n['number'],sourcePrintedPage=pg,zh=zh,en=en,originalCitations=n['original_citations'])
  for ch in self.data.values():
   for row in ch['body']:
    if '_toc' not in row:continue
    e=row.pop('_toc');cid=self.id_to_chapter[e['target_unit_id']];url=f'translations/book.html?id={BOOK}&chapter={cid}#{e["target_unit_id"]}'
    row['zh']=[dict(type='link',url=url,children=[e['title_zh']+' — '+str(e['original_target_page'])]),dict(type='break'),e['summary_zh']]
    row['en']=[dict(type='link',url=url,children=[e['title_de']+' — '+str(e['original_target_page'])]),dict(type='break'),e['summary_de']]
    for note in e.get('editorial_notes',[]):
     row['zh'] += [dict(type='break'),'〔编者按〕'+note['translation']];row['en'] += [dict(type='break'),'[Redaktionelle Erläuterung] '+note['source']]
  return self
def walk(ts):
 for t in ts:
  yield t
  if isinstance(t,dict):yield from walk(t.get('children',[]))
def main():
 d=json.loads((R/'reading_projection.json').read_text('utf-8'));assert d['canonical_sha256']==sha(R/'translation_units.jsonl') and d['front_matter_sha256']==sha(R/'front_matter.json')
 w=Web(d).build();W.mkdir(exist_ok=True);allnotes=set();seenrows=[]
 for cid,ch in w.data.items():
  refs=set()
  for lang in ['zh','en']:
   anchors=[]
   for obj in ch['body']+list(ch['notes'].values()):
    for t in walk(obj[lang]):
     if isinstance(t,dict) and t.get('type')=='note':refs.add(t['id'])
     if isinstance(t,dict) and t.get('type')=='anchor':anchors.append(t['id'])
   assert len(anchors)==len(set(anchors)),(cid,lang,'duplicate anchors')
  assert refs==set(ch['notes']),(cid,refs^set(ch['notes']))
  allnotes.update(ch['notes']);seenrows += [x['id'] for x in ch['body']]
  dump(W/(cid+'.json'),ch)
 assert len(allnotes)==404 and len(seenrows)==len(set(seenrows))
 meta=dict(id=BOOK,title='康德的经验理论',originalTitle='Kants Theorie der Erfahrung',author='Hermann Cohen',authorZh='赫尔曼·柯亨',tags=['哲学','康德','认识论'],language='中文 / Deutsch',languagePair='中德双语',structured=True,bilingual=True,views=['parallel','zh','en'],sourceLanguage='de',sourceLanguageLabel='Deutsch',editionNotice='依据1885年重新修订第二版的完整校订译本；保留原注、原页码及含论题提要的原书目录，中文原注后附德文全文。',chapters=w.chapters,downloads=[],reviewedCanonicalSha256=d['canonical_sha256'],reviewedFrontMatterSha256=d['front_matter_sha256'],sourceEdition='Cohen, zweite neubearbeitete Auflage, Berlin 1885',readerUrl=f'https://uni0nius.github.io/translations/book.html?id={BOOK}')
 dump(W/'book-metadata.json',meta)
 report=dict(status='staged_structure_passed_pending_independent_content_and_browser_checks',book=BOOK,chapters=len(w.chapters),child_sections=sum('parentId' in x for x in w.chapters),body_rows=len(seenrows),notes=len(allnotes),unique_row_ids=True,note_refs_and_definitions_match=True,unique_language_anchors=True,canonical_sha256=d['canonical_sha256'],front_matter_sha256=d['front_matter_sha256'],files={p.name:sha(p) for p in W.glob('*.json')})
 dump(R/'web_export_check.json',report);print(json.dumps({k:report[k] for k in ['status','chapters','child_sections','body_rows','notes']},ensure_ascii=False))
if __name__=='__main__':main()
