"""Lossless reading projection, shared by PDF, Markdown and outer-site exports."""
from pathlib import Path
import json,hashlib,collections,re
R=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n','utf-8')
def source(u):return u.get('source_display_text',u['source_text'])
body=[json.loads(x) for x in (R/'translation_units.jsonl').read_text('utf-8').splitlines()]
front=json.loads((R/'front_matter.json').read_text('utf-8'))
notes={};ownership={};all_ids=[]
for u in body:
 if u['kind']=='note':
  for n in u.get('note_parts',[u]):notes[n['id']]=n;ownership[n['id']]=u['id']
for g in front:
 for u in g['units']:
  if u['kind']=='note':notes[u['id']]=u;ownership[u['id']]=u['id']
def label(n):return str(n.get('original_label') or n.get('note_label') or n.get('reviewed_note_index') or n.get('note_index'))
def runs(text,placements,lang,a,b):
 out=[];pos=a
 for p in placements:
  k='source' if lang=='de' else 'translation';offset=p[k+'_offset'];token=p[k+'_token']
  if not(a<=offset<b):continue
  assert offset+len(token)<=b
  if offset>pos:out.append(dict(type='text',text=text[pos:offset]))
  assert text[offset:offset+len(token)]==token
  out.append(dict(type='note_ref',note_id=p['note_id'],ref_id=p['ref_id'],label=label(notes[p['note_id']])))
  pos=offset+len(token)
 if pos<b:out.append(dict(type='text',text=text[pos:b]))
 assert ''.join(x.get('text',next((p[('source' if lang=='de' else 'translation')+'_token'] for p in placements if p['ref_id']==x.get('ref_id')),'')) for x in out)==text[a:b]
 return out
def components(u):
 de=source(u);zh=u['translation'];bs=u.get('reading_blocks') or [dict(kind=u.get('reviewed_kind',u['kind']),source_range=[0,len(de)],translation_range=[0,len(zh)])]
 out=[];ps=u.get('reviewed_printed_pages') or u['printed_pages']
 for j,b in enumerate(bs):
  c=dict(id=b.get('id',u['id'] if len(bs)==1 else u['id']+f'-block{j+1}'),unit_id=u['id'],kind=b['kind'],anchor_ids=[u['id']] if j==0 else [],de_runs=runs(de,u.get('note_placement',[]),'de',*b['source_range']),zh_runs=runs(zh,u.get('note_placement',[]),'zh',*b['translation_range']),source_range=b['source_range'],translation_range=b['translation_range'],printed_pages=ps,page_label=str(ps[0]) if j==0 and ps else None,source_joiner=u.get('source_joiner',' '),translation_joiner=u.get('translation_joiner',''),editorial_notes=[])
  if j==len(bs)-1:c['editorial_notes']=u.get('editorial_notes',[])
  out.append(c)
 return out
groups=[];frontgroups=[];note_records=[];colophons=[];scope=None;lastgroup=None
def add(u,container,prefix):
 global scope,lastgroup
 cs=components(u)
 for c in cs:
  kind=c['kind']
  if kind in ['part_heading','chapter_heading','section_heading','subsection_heading']:
   scope=c['id'];lastgroup=None
  if kind=='colophon':colophons.append(c);continue
  group=u.get('reading_group')
  if u.get('join_previous') and c is cs[0]:
   assert container and lastgroup==group and container[-1]['kind']==kind,(u['id'],'join discontinuity')
   container[-1]['components'].append(c)
  else:
   container.append(dict(id=c['id'],kind=kind,scope=scope,components=[c],chapter=u.get('chapter'),section=u.get('reviewed_section',u.get('section'))))
  lastgroup=group
for g in front:
 scope=g['id'];lastgroup=None;gs=[]
 for u in g['units']:
  if u['kind']=='note':continue
  if u['kind']=='toc_entry':
   gs.append(dict(id=u['id'],kind='toc_entry',scope=scope,entry=u,components=components(u)));lastgroup=None
  else:add(u,gs,'front')
 frontgroups.append(dict(id=g['id'],heading=g.get('heading'),heading_de=g.get('heading_de'),groups=gs))
scope=None;lastgroup=None
for u in body:
 if u['kind']!='note':add(u,groups,'body')
 else:
  for c in components(u):
   if c['kind']=='colophon':colophons.append(c)
refs=collections.defaultdict(list)
for g in [x for f in frontgroups for x in f['groups']]+groups:
 for c in g['components']:
  for t in c['de_runs']:
   if t['type']=='note_ref':refs[t['note_id']].append(dict(scope=g['scope'],body_unit_id=c['unit_id'],ref_id=t['ref_id']))
# A first-preface note itself refers to the second original note.
for nid,n in notes.items():
 for t in n.get('note_placement',[]):refs[t['note_id']].append(dict(scope=refs[nid][0]['scope'],body_unit_id=nid,ref_id=t['ref_id']))
assert set(refs)==set(notes),(set(refs)^set(notes))
for nid,n in notes.items():
 assert len(refs[nid])==1,(nid,refs[nid])
 cs=components(n);cs=[c for c in cs if c['kind']!='colophon']
 # First/second notes inside a merged parent have their own stable identity.
 note_records.append(dict(id=nid,number=label(n),scope=refs[nid][0]['scope'],body_unit_id=refs[nid][0]['body_unit_id'],ref_id=refs[nid][0]['ref_id'],printed_pages=n.get('reviewed_printed_pages') or n['printed_pages'],components=cs,original_citations=n.get('original_citations',[])))
assert len(notes)==404
allbody=[c['unit_id'] for g in groups for c in g['components']]
assert set(allbody)=={u['id'] for u in body if u['kind']!='note'}
for u in body:
 if u.get('reading_blocks'):
  de=source(u);zh=u['translation']
  for k,t in [('source',de),('translation',zh)]:assert ''.join(t[b[k+'_range'][0]:b[k+'_range'][1]] for b in u['reading_blocks'])==t
data=dict(schema_version=1,book_id='cohen-kants-theorie-der-erfahrung-1885',canonical_sha256=sha(R/'translation_units.jsonl'),front_matter_sha256=sha(R/'front_matter.json'),front=frontgroups,groups=groups,notes=note_records,colophons=colophons)
dump(R/'reading_projection.json',data)
report=dict(status='projection_structural_passed',canonical_sha256=data['canonical_sha256'],front_matter_sha256=data['front_matter_sha256'],body_units=1950,front_units=56,body_groups=len(groups),actual_notes=len(notes),colophons=len(colophons),types=dict(collections.Counter(g['kind'] for g in groups)),all_body_units_represented=True,note_refs_unique_and_complete=True,source_and_translation_spans_lossless=True,limitations='Projection structural verification; actual PDF/Markdown/web output checks remain separate.')
dump(R/'reading_projection_check.json',report);print(json.dumps(report,ensure_ascii=False))
