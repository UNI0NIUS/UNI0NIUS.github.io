# 《康德的经验理论》1885第二版校订源码

作者 Hermann Cohen；原版 Berlin: Ferd. Dümmlers Verlagsbuchhandlung, 1885，重新修订第二版。

规范数据为 work/review/translation_units.jsonl（1950正文/原注父单元）和 front_matter.json（56前置单元）。原文、原注、来源范围、原页码、显示订正和编者按均保留；完整阅读共有404条实际原注、47个原作导航入口（25个子节）。中文原注附完整德文。

只从本包当前规范数据生成。包内不含生产者批次生成器、一次应用修订器、网站迁移器、凭据或其他书目。不要从历史批次重建或覆盖规范稿。JSON验收报告绑定各自实际输入版本，早期章报告中的待办不代表当前版本待办。图像目视证据保存在生产工作区；本包附报告，不冒称全书每页图像逐字核过。

## 重生成

Python 3.11或更新版本；生成器使用标准库。PDF独立回读另需PyMuPDF。字体重制另需FontTools与Brotli；通常直接复用已附WOFF2。工作目录设为本README所在的书目根目录，按序运行：

    python work/review/build_reading_projection.py
    python work/review/build_reading_editions.py
    python work/review/export_markdown.py
    python work/review/export_web.py
    python work/review/audit_web.py

三个TeX和两份Markdown生成到 output/reviewed；47章JSON及生成阶段book-metadata.json在其webdata/。网页依赖表站现用translations.js、bilingual-reader.js、translations.css及KaTeX，沿用en字段保存德文。生成阶段元数据downloads为空，由发布步骤填入六下载大小与哈希；本包不会内嵌自己的ZIP哈希。公开阅读地址 https://uni0nius.github.io/translations/book.html?id=cohen-kants-theorie-der-erfahrung-1885 。本次仅发布表站。

## PDF编译

安装XeLaTeX（TeX Live或MiKTeX）及模板所列宏包；正式字体为Times New Roman、SimSun；希腊文由主字体呈现，数学符号由TeX数学字体呈现。Windows字体按字体名称查找，无机器专用绝对路径。可给PDF生成命令追加 --compile，或在 output/reviewed 对三个tex分别运行xelatex两次以更新目录和跳转。正式版中文250页、德文251页、对照487页；纸张A4，中文11pt/25mm，德文与对照10pt、内20外23上21下23mm。原注在原作小节末；原书页码与阅读页码分列。PDF构建时间等元数据可能改变字节哈希，内容和版式验收需绑定实际输出。

## 原件与定位

原扫描件 Kants Theorie der Erfahrung 1885.pdf 保留在生产工作区，未重复放进源码ZIP；653个PDF页，24,061,713字节，SHA256 8d88e78b785a6974b7fc35c21c81427e2c618e0af455e62ead29e62501037992。
正文印刷1—616页对应PDF32—647页；该偏移仅适用于正文。前置罗马页与无页码扫描/馆藏附属页依front_back_inventory.json分别定位。规范单元保存原始来源定位及德文；疑点有定向重OCR和原图核实记录。body_coverage_acceptance.json验收24112条正文PDF文字层来源行，不能据此声称616页图像逐字目视。原目录误印348/554保留并双语披露，导航跳实际349/551页。

## 包完整性

source-manifest.json列出本包所有其他成员的字节数和SHA256。三份正式PDF分别作为网站下载提供，不重复收入源码ZIP；相关PDF验收报告保留。规范稿SHA、排版、语义、覆盖、网页回读分别记录。source_package_check.json在生产工作区另记打包后的完整读取和隔离复现结果。
