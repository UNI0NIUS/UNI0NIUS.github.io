# “灭绝”部分外部核验

## 3.1

- [忧思科学家联盟2016年资料](https://www.ucs.org/resources/whats-driving-deforestation)：牛肉、大豆、棕榈油与木制品共同驱动超过一半热带毁林；约10%温室气体排放来自毁林总体。棕榈油“仅次于牛肉”的排放排序在该页主要毁林商品的语境中，不能扩展为全球全部变暖驱动因素排行。原书原25—26页的范围扩张已加校注，不静默替换原文。
- [IUCN2018年说明](https://iucn.org/resources/issues-brief/palm-oil-and-biodiversity)及[原报告发布说明](https://iucn.org/news/secretariat/201806/saying-no-palm-oil-would-likely-displace-not-halt-biodiversity-loss---iucn-report)：至少193种已受影响；54%／64%是油棕可能扩张区所容纳的受威胁哺乳动物／鸟类比例，具有潜在影响的含义。原26页将两组统计直接连接，译文保留，并明确差异。完整2018报告PDF尝试访问失败，不记为全文已核实。
- [WHO河盲症资料](https://www.who.int/news-room/fact-sheets/detail/onchocerciasis)：盘尾丝虫由感染的蚋传播，人类是宿主；原29页把蚋和人体均称为vector，译作较宽泛的“传播载体”，另注医学区分。
- [WRI研究团队关于南美大豆的文章](https://globalnaturewatch.org/blog/forest-insights/soy-production-forests-south-america/)检索可读：2001—2015年全球820万公顷森林被大豆替代，南美790万；其中直接替代与经过中间土地利用后替代应区分。本书数字保留，未把它解释成全部即时转换。
- [夏威夷大学植物病害资料](https://cms.ctahr.hawaii.edu/ckm/Home/Plant-Disease-Pathogens/Fungi/Fungi-genera-starting-with-E--H/Hemileia-vastatrix)及[美国植物病理学会原研究](https://apsjournals.apsnet.org/doi/10.1094/PDIS-05-21-1072-PDN)支持Hemileia vastatrix为咖啡叶锈病病原；[台湾香蕉研究所2019年产业季刊](https://www.banana.org.tw/upload/%E7%86%B1%E8%A8%8A-%E9%A6%99%E8%95%89%E7%94%A2%E6%A5%AD%E7%86%B1%E8%A8%8A%E7%AC%AC02%E6%9C%9F.pdf)检索内容采用“大米七”对应Gros Michel。未把学名与病名混为同义词。

尚待核对：15%与不足半数的脊椎动物统计样本；原生植被50%的地域／时间范围；各动物当时保护等级；2011年印度尼西亚森林／泥炭地许可暂停与油棕专项许可政策的区别；全部原著引文原页。原书政治叙述保持其2019／2025年的历史时态，不冒充当前法律或政职状况。
# 3.2—3.4补充核验

- Mathews2018，期刊原发表页：<https://anthrosource.onlinelibrary.wiley.com/doi/full/10.14506/ca33.3.05>，另见<https://journal.culanth.org/index.php/ca/article/view/ca33.3.05>。检索正文支持底本所述栗树病原传播的19世纪中叶至20世纪中叶，以及资本主义／工业化历史始于19世纪初。未把本次抽核说成全文史料复核。
- Chua等2021，<https://anthrosource.onlinelibrary.wiley.com/doi/10.1111/amet.13045>；剑桥作者文稿<https://api.repository.cam.ac.uk/server/api/core/bitstreams/5f2ba0bd-a62c-4d38-9529-0f07dae5b8d6/content>。标题、署名、370—385页以及救生衣引语存在已核。并未逐项核完所有地方个案材料。
- 底本原38页与参考文献均拼为Ovstehage。原发表平台<https://anthrowork.org/interventions/working-the-plantationocene/>及<https://saw.pubpub.org/pub/working-the-plantationocene/release/1>署名Andrew Ofstehage，DOI10.21428/1d6be30e.932d8ce0；保留底本拼写并加校注。
- 原36页猩猩十至二十年灭绝预测依原文翻译并标明其所引2011/2018年文献的时间背景；本次未核实预测的具体模型、适用种群与期限，不将其当作现时预报。
- haʔip、amai、dema、kesedihan、kering、kesendirian、sedih按底本保留；有关精灵、植物感受与亲属关系的表述始终归属于作者所述社群的观念，不改写成独立生物学结论。

