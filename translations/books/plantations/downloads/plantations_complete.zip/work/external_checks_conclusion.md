# 结论重点核验

- 原63页末段引注Césaire 1955:6保留。相同论点和引句可核于1956年10月24日《致莫里斯·多列士的信》，Chike Jeffers英译，Social Text 103（2010）152页，DOI 10.1215/01642472-2009-072。所见英译措辞enriched而本书引句rich，故仅注出处差异，未声称两个英译逐字相同。[原信英译PDF](https://abahlali.org/wp-content/uploads/2015/11/153945859-Aime-Cesaire-Letter-to-Maurice-Thorez-1956.pdf)
- Myers 2017的Planthroposcene与本书Plantationocene区分为植物人类世／种植园世。[作者论文出版信息](https://www.tandfonline.com/doi/abs/10.1080/02757206.2017.1289934)，297—301页；未声称已核全部本文内容。
- Bubandt等2026《Anthropologists Are Talking About Ecography》卷91期1，126—143页，2025年先行在线，2026卷期年份成立。[出版信息](https://www.tandfonline.com/doi/abs/10.1080/00141844.2025.2541773)
- 原60页less evenly shared futures目视存在；保留直译并注语义张力，不未经证据改成more。原61页a a重复、原59页non-humans’subjectivities缺空格保留。
- 本记录只说明以上重点核验；不代表已经逐一打开全书数百篇引用原作。
