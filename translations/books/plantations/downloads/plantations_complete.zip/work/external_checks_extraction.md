# “攫取”部分外部查证记录

本记录区分原书表述、已查明的差异及尚未核验的问题。译文保留原论述，校注不充当作者原注。未声称逐页核实全部参考文献。

- 原12页：正文Colchester, Chao and Anderson 2024；书末原67页及[Forest Peoples Programme原报告](https://www.forestpeoples.org/fileadmin/uploads/fpp/migration/publication/2014/12/assault-commons.pdf)版权页均为2014。该报告第15页把土地归属宣告定于1870，而本书正文为18世纪中叶。报告文本已读；远程截图工具失败，不记为逐页图像核验。[Jeffrey Neilson本人研究文章](https://gjia.georgetown.edu/society-culture/domein-verklaring-colonial-legal-legacies-and-community-access-to-land-in-indonesia/)亦说明1870年法令背景。
- 原13页：2022年材料为A. Missouri Sherman-Peter在[UN Chronicle的署名文章](https://www.un.org/en/un-chronicle/legacy-slavery-caribbean-and-journey-towards-justice)，包含原引句、1200万至2000万及20%数字。检索索引开篇可读；正文打开403。不能据署名评论单独认定该文字是决议或司法判决。
- 原15页：[Tanner等2011年原研究](https://pubmed.ncbi.nlm.nih.gov/21269927/)发现百草枯使用与帕金森病的相关性；[EPA资料页](https://www.epa.gov/ingredients-used-pesticide-products/paraquat-dichloride)说明研究结果不一致，未认定按标签使用暴露与帕金森病或癌症存在明确联系。保留原书“致癌”等判断，并说明关联不等于一致的因果定论，且不否定急性毒性。DBCP、十氯酮及各疾病范围尚未逐项完成原研究核验。
- 原18页：底本将仓鸮归在昼行鸟类清单内，写“nonoccluded RNA viruses”用于犀金龟防治。[ICTV官方分类说明](https://ictv.global/report/chapter/nudiviridae/nudiviridae)将Oryctes rhinoceros nudivirus列为dsDNA病毒。由于本书未明确写OrNV名称，不将RNA静默改成DNA；保留并提出待核。其他捕食者及受害虫态尚待对照Chao2021a。
- 原19页：“over90 per cent of local farms”“seed corporations companies”“GM soy’s growing herbicide resistance”均已对照原PDF图像。保留底本，不擅自改成棉田占比或杂草抗性。Aga2022、Leguizamón2020具体原页待核。
- 原20页：底本说2024年5月裁决。[PhilRice案件问答](https://www.philrice.gov.ph/golden-rice/qa/)检索正文载判决为4月17日；[2024年4月20日该所声明](https://www.philrice.gov.ph/philrice-acknowledges-court-of-appeals-decision-granting-the-writ-of-kalikasan-against-golden-rice-in-the-philippines/)载4月19日收件。问答直接打开报错，索引可读。此处只核对历史日期，不作现时法律状态判断；营养与生态主张均明确保留其归属。
- 原23页：13%—40%对应[Page等2002年Nature原研究](https://www.nature.com/articles/nature01131)摘要中的印度尼西亚全国1997年泥炭与植被火灾外推估算，不能缩成稻田计划单一区域的排放。已读摘要，未核对该研究付费正文全部数据表。Goldstein2016所引原页待核。

其余正文历史统计、迁移人数、作物生长周期、劳动法规及种子随逃奴传播等按原书翻译；未把未核实项目伪记为完成。长句中的立场、推测语气与不同争议方归属，已在译文中保持。
