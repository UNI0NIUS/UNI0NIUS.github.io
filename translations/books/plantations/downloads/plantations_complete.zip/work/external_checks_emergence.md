# 第4部分核验记录（进行中）

- 麻风病：WHO事实页<https://www.who.int/en/news-room/fact-sheets/detail/leprosy>及西太平洋区域页<https://www.who.int/westernpacific/health-topics/leprosy>。前者说明传播与未治疗患者长期密切接触相关，后者明确并非高度易传染。底本原42页“highly contagious”保留并加校注；没有把民族志中的禁忌病因观判作生物医学证实。
- 塔斯基吉：CDC<https://www.cdc.gov/tuskegee/about/timeline.html>及<https://www.cdc.gov/tuskegee/about/>支持1932—1972年、没有收集知情同意，以及未给予可用青霉素治疗等叙述。
- Flachs2024：原期刊<https://journals.sagepub.com/doi/10.1177/02780771241228068>署名Andrew Flachs、Cristiana Bastos、Deborah Heath、Sita Venkateswar。底本作Andrews，照录并注明。
- 大吉岭：地区政府网站<https://darjeeling.gov.in/>确认属于West Bengal，与本书3.3一致。4.2将其称为印度的邦为底本错误，照录并注明。
- 西姆斯任职时间在本次检索中有1875—1876两种表述；未取得美国医学会当年选举记录，未据二手结果改动底本1875年当选。妇科学会1879年任职亦未完成档案级核验。
- 植物药用用途为底本历史转述，不背书治疗效果。kola beads、korsu-wiwiri、usuwe、redi katun、Kapasi保留底本写法；通俗植物名的精确物种仍有待原民族植物学文献核对。
- 松茸价格表述为作者原句，不作实时价格排名；本次没有完整复核所有民族志、全部药用植物或参考文献。
# 4.3—4.5补充

- 原53页将Eric Garner与Michael Brown并称teenagers；美国国会H.Res.589提出文本<https://www.govinfo.gov/content/pkg/BILLS-114hres589ih/pdf/BILLS-114hres589ih.pdf>列Garner43岁、Brown18岁。按底本翻译并标注年龄错误；仅用提出文本核对所列年龄，不称其为通过的法律。
- 古根海姆博物馆<https://www.guggenheim.org/articles/checklist/the-artist-transforming-himself-into-a-monument-for-the-oppressed>记Carlos Martiel的Sabiduría为2007，描述以牙拔草；与底本1989、舌头刻画不同，保留底本并注明。未凭猜测把1989直接称作出生年。
- 原54页Aroisoaie与作者自述网站<https://www.aidaarosoaie.com/>署名Aida Arosoaie不符，注明拼写差异。
- Shooshie Sulaiman两件作品名称、年份2019和MACAN展览地点，可与代理画廊<https://www.tomiokoyamagallery.com/artists/sulaiman/>以及博物馆自编资料<https://assets.museummacan.org/2020/04/01/DDB%20MGC.pdf>检索条目对照；未逐页阅读展览资料，勿宣称全面核验。
- Roye作品查到Aperture原刊介绍<https://aperture.org/editorial/vision-justice-radcliffe-roye/>，尚未据此确定底本2016究竟为拍摄、发表还是获奖年份；保留底本并明确限制。
- Kara Walker装置可见项目组织者Creative Time提供的介绍<https://artsandculture.google.com/story/creative-time-presents-kara-walker%E2%80%99s-%E2%80%9Ca-subtlety%E2%80%9D-creative-time/zQXxxOVsvRwA8A?hl=en>，本次仅核作品/年份，未完整复核所有材料细节。
- 底本Afrikaans称人群、identifies、control of over、a histories照录且加注。艺术/文学中文题名是工作译名，不声称沿用正式中译名；其他引文、年代和人口数字尚待整体文献复核。

