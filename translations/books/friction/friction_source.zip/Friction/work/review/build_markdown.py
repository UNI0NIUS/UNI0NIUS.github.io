"""Generate Markdown from the same reviewed HTML, preserving IDs and line breaks."""
from pathlib import Path
from bs4 import BeautifulSoup
import subprocess,shutil,json,hashlib
from build_print import normalize_joins
ROOT=Path(__file__).resolve().parent
OUT=ROOT.parents[1]/'output'/'reviewed'
pandoc=shutil.which('pandoc') or r'C:\Users\Union\anaconda3\Library\bin\pandoc.exe'
reports=[]
for mode in ['zh','bilingual']:
 source=OUT/f'friction_{mode}.html';soup=BeautifulSoup(source.read_text(encoding='utf-8'),'html.parser')
 normalize_joins(soup)
 for paragraph in soup.select('p[id]'):
  wrapper=soup.new_tag('div',id=paragraph['id']);paragraph.attrs.pop('id');paragraph.wrap(wrapper)
 for node in list(soup.select('style,script,nav,.figure-key')):node.decompose()
 for node in soup.select('.quote,.interview'):node.name='blockquote'
 for verse in soup.select('.verse'):
  verse['class']=['line-block']
  for line in verse.find_all('div',recursive=False):
   old=line.get('class',[])
   if 'stanza-start' in old:line.insert_before(soup.new_tag('br'))
   line['class']=['line']
   if 'indented' in old:line.insert(0,'\u00a0\u00a0\u00a0\u00a0')
 for svg in list(soup.find_all('svg')):
  figure=svg.find_parent('figure');name=figure['id']+'.svg';assets=OUT/'figures';assets.mkdir(exist_ok=True)
  svg['xmlns']='http://www.w3.org/2000/svg';(assets/name).write_text(str(svg),encoding='utf-8')
  img=soup.new_tag('img',src='figures/'+name,alt=svg.get('aria-label','图示'));svg.replace_with(img)
 result=subprocess.run([pandoc,'--from=html','--to=markdown+native_divs+native_spans','--wrap=none'],input=str(soup),text=True,encoding='utf-8',capture_output=True,check=True)
 target=OUT/f'friction_{mode}.md';target.write_text(result.stdout,encoding='utf-8')
 reports.append(dict(mode=mode,bytes=target.stat().st_size,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),warnings=result.stderr))
(ROOT/'markdown_export_report.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(reports,ensure_ascii=False))
