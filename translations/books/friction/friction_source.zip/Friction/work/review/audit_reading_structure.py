"""Check explicit rendering invariants, independently of normalized body text."""
import json,re,hashlib
from bs4 import BeautifulSoup
from build_reading import ROOT,OUT,structures,sections,heads,sidebars,BY
reports=[]
for mode in ['zh','bilingual']:
 f=OUT/f'friction_{mode}.html';s=BeautifulSoup(f.read_text(encoding='utf-8'),'html.parser');errors=[]
 langs=['zh'] if mode=='zh' else ['en','zh']
 def check(ok,msg):
  if not ok:errors.append(msg)
 for lang in langs:
  for uid,h in heads.items():
   actual=s.find(id=f'heading-{uid}-{lang}')
   check(actual is not None and actual.name==f'h{h["heading_level"]+1}',f'{uid}/{lang}: heading level')
  poem=s.find(id='ch05-0002-'+lang)
  check(len(poem.select('.verse-line'))==28,f'{lang}: fifth chapter poem lines')
  check(len(poem.select('.stanza-start'))==4,f'{lang}: stanza breaks')
  check(len(poem.select('.indented'))==10,f'{lang}: alternating stanza indentation')
  check(len(poem.select('.attribution'))==1,f'{lang}: poem attribution')
  check(len(s.select('#figure1-'+lang))==1 and len(s.select('#figure2-'+lang))==1,f'{lang}: figures once')
  fig=s.find(id='figure1-'+lang)
  check(len(fig.select('svg g[stroke] path'))==3,f'{lang}: triangle double-ended edges')
  check(len(s.select('#figure2-'+lang+' .figure-boxes>div'))==2,f'{lang}: APHIDS boxes')
  slots=[]
  for uid in sorted(sidebars):
   unit=s.find(id=uid+'-'+lang)
   check(unit is not None,f'{uid}/{lang}: sidebar unit')
   if BY[uid]['kind']=='heading':check(unit.find('h3') is not None,f'{uid}/{lang}: sidebar title')
   for el in unit.select('.list-entry'):
    m=re.match(r'^\s*(\d+)(?:[–—-](\d+))?[.．、]',el.get_text())
    if m:slots.extend(range(int(m[1]),int(m[2] or m[1])+1))
  expected=list(range(1,122))+list(range(796,957))+list(range(676,732))
  check(slots==expected,f'{lang}: 338 original numbered slots/order')
  for uid in ['ch04-0128','ch04-0129','ch04-0130','ch04-0131','ch04-0132']:
   check(s.find(id=uid+'-'+lang).select_one('.quote') is not None,f'{uid}/{lang}: inner dialogue quote')
  unit=s.find(id='interlude_facilities-0008-'+lang)
  check(len(unit.select('.interview'))==1 and len(unit.select('.prose'))==1,f'{lang}: interview/author boundary')
 check(len(s.select('.joined'))==6,'six continuous paragraph groups')
 check(len(s.select('.join-tail'))==6*len(langs) and len(s.select('.join-head'))==6*len(langs),'continuation classes')
 reports.append(dict(mode=mode,status='passed_structural_invariants' if not errors else 'failed',errors=errors,source_slots_per_language=338,sha256=hashlib.sha256(f.read_bytes()).hexdigest(),scope='Explicit heading levels, chapter5 poem structure, diagram count/shape, list number slots, selected interview boundaries and six continuation groups; browser visual verification recorded separately.'))
(ROOT/'reading_structure_audit.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(reports,ensure_ascii=False,indent=2))
