"""Audit native chapter rows, complete text, footnotes and bookmark targets."""
from pathlib import Path
from bs4 import BeautifulSoup
import json,hashlib,re
from urllib.parse import urlparse,parse_qs
ROOT=Path(__file__).resolve().parent;OUT=ROOT.parents[1]/'output'/'reviewed';SITE=OUT/'site'
soup=BeautifulSoup((OUT/'friction_bilingual.html').read_text(encoding='utf-8'),'html.parser')
sections={n['id']:n for n in soup.main.find_all('section',recursive=False)}
front=soup.new_tag('section',id='front')
for n in list(soup.main.children):
 if getattr(n,'name',None) in ['header','div']:front.append(n.extract())
sections={'front':front,**sections}
metadata=json.loads((SITE/'book-metadata.json').read_text(encoding='utf-8'))
errors=[];ids={};links=[];note_count=0;row_count=0
norm=lambda s:re.sub(r'\s+','',s)
def plain(n):
 copy=BeautifulSoup(str(n),'html.parser')
 for x in copy.select('.source-page,svg'):x.decompose()
 return norm(copy.get_text())
def text(tokens):
 return ''.join(t if isinstance(t,str) else (str(t.get('label','')) if t['type']=='note' else text(t.get('children',[]))) for t in tokens)
def visit(tokens,sid,anchors):
 for t in tokens:
  if isinstance(t,str):continue
  assert t['type'] in ['anchor','note','image','linebreak','link','em','strong','sup','sub','block'],t
  if t['type']=='anchor':anchors.append(t['id'])
  if t['type']=='link' and t['url'].startswith('translations/book.html?'):
   u=urlparse(t['url']);links.append((sid,parse_qs(u.query)['chapter'][0],u.fragment))
  if t['type']=='image':assert (OUT/'figures'/Path(urlparse(t['src']).path).name).is_file()
  visit(t.get('children',[]),sid,anchors)
def refs(tokens):
 return [x for t in tokens if isinstance(t,dict) for x in ([t['id']] if t['type']=='note' else refs(t.get('children',[])))]
for ch in metadata['chapters']:
 sid=ch['id'];data=json.loads((SITE/(sid+'.json')).read_text(encoding='utf-8'))
 assert 'renderFormat' not in data and data['id']==sid
 nodes=sections[sid].find_all(recursive=False)
 if len(nodes)!=len(data['body']):errors.append('row count '+sid)
 anchors=[];used=set()
 for n,row in zip(nodes,data['body']):
  row_count+=1;anchors.append(row['id'])
  for lang in ['en','zh']:
   visit(row[lang],sid,anchors if not row.get('shared') or lang=='zh' else [])
   used.update(refs(row[lang]))
  if 'note' in n.get('class',[]):
   for lang in ['en','zh']:
    expected=n.strong.get_text()+'. '+n.select_one('.unit.'+lang).get_text()+next(a.get_text() for a in n.find_all('a',recursive=False) if a['href'].endswith('-'+lang))
    page=n.select_one('.unit.'+lang+' .source-page').get_text();expected=expected.replace(page,'',1)
    if norm(text(row[lang]))!=norm(expected):errors.append('note text '+row['id']+' '+lang)
  else:
   actual=text(row['zh']) if row.get('shared') else text(row['en'])+text(row['zh'])
   if norm(actual)!=plain(n):errors.append('body text '+row['id'])
 for nid,note in data['notes'].items():
  note_count+=1
  original=sections['notes'].find(attrs={'data-unit':nid}).find_parent(class_='note')
  for lang in ['en','zh']:
   if norm(text(note[lang]))!=plain(original.select_one('.unit.'+lang)):errors.append('inline note text '+nid)
   visit(note[lang],sid,anchors)
 if used!=set(data['notes']):errors.append('note coverage '+sid)
 if len(anchors)!=len(set(anchors)):errors.append('duplicate anchors '+sid)
 ids[sid]=set(anchors)|{sid}
 for h in ch.get('outline',[]):
  if h['anchor'] not in ids[sid]:errors.append('outline '+h['anchor'])
for origin,dest,target in links:
 if target not in ids[dest]:errors.append('broken link '+origin+' '+target)
assert note_count==218,note_count
report={'status':'passed_native_data_export' if not errors else 'failed','chapters':len(metadata['chapters']),'rows':row_count,'paragraph_notes':note_count,'internal_links':len(links),'errors':errors,'input_sha256':hashlib.sha256((OUT/'friction_bilingual.html').read_bytes()).hexdigest(),'chapter_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in SITE.glob('*.json')},'limits':'Complete normalized text and targets; browser layout and live publication checked separately.'}
(ROOT/'site_data_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='chapter_sha256'},ensure_ascii=False))
assert not errors,errors
