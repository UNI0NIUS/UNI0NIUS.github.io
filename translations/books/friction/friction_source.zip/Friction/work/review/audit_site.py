"""Validate the exported website tree against the reviewed reading HTML."""
from pathlib import Path
from bs4 import BeautifulSoup
import json,hashlib
ROOT=Path(__file__).resolve().parent;OUT=ROOT.parents[1]/'output'/'reviewed';SITE=OUT/'site'
source=BeautifulSoup((OUT/'friction_bilingual.html').read_text(encoding='utf-8'),'html.parser')
metadata=json.loads((SITE/'book-metadata.json').read_text(encoding='utf-8'))
ids={};links=[];errors=[];units=[];counts={};texts={}
def visit(node,sid):
 if isinstance(node,str):return node
 a=node.get('attrs',{})
 if a.get('id'):
  if a['id'] in ids:errors.append('duplicate '+a['id'])
  ids[a['id']]=sid
 if a.get('data-unit'):units.append((a['data-unit'],a.get('lang')))
 if a.get('href','').startswith('#'):links.append((sid,a['href'][1:],a.get('data-target-chapter')))
 return ''.join(visit(c,sid) for c in node.get('children',[]))
for ch in metadata['chapters']:
 sid=ch['id'];data=json.loads((SITE/(sid+'.json')).read_text(encoding='utf-8'));assert data['id']==sid
 actual=''.join(visit(n,sid) for n in data['body']);texts[sid]=actual
 if sid=='front':expected=source.main.header.get_text()+source.main.find('div',class_='notice').get_text()
 else:expected=source.find(id=sid).get_text()
 if actual!=expected:errors.append('text mismatch '+sid)
 for h in ch.get('outline',[]):
  if ids.get(h['anchor'])!=sid:errors.append('outline target '+h['anchor'])
for sid,target,destination in links:
 if ids.get(target)!=destination:errors.append('link target '+target)
expected_units=[(u['data-unit'],u.get('lang')) for u in source.select('[data-unit]')]
if sorted(units)!=sorted(expected_units):errors.append('unit coverage differs')
report={'status':'passed_data_export' if not errors else 'failed','chapters':len(metadata['chapters']),'language_units':len(units),'anchors':len(ids),'internal_links':len(links),'errors':errors,'input_sha256':hashlib.sha256((OUT/'friction_bilingual.html').read_bytes()).hexdigest(),'limits':'Exact DOM text/order and targets; browser layout, language switching, downloads and live publication are separate checks.'}
(ROOT/'site_data_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(report,ensure_ascii=False))
