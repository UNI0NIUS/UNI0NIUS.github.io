"""Compile current TeX, rerunning only until the table of contents stabilizes."""
from pathlib import Path
import subprocess,shutil,hashlib,json
ROOT=Path(__file__).resolve().parent
OUT=ROOT.parents[1]/'output'/'reviewed'
engine=shutil.which('xelatex') or r'C:\texlive\2025\bin\windows\xelatex.exe'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
reports=[]
for mode in ['zh','bilingual']:
 stem='friction_'+mode;toc=OUT/(stem+'.toc');runs=0
 for run in range(3):
  before=digest(toc)
  result=subprocess.run([engine,'-interaction=nonstopmode','-halt-on-error',stem+'.tex'],cwd=OUT,capture_output=True)
  (OUT/(stem+'.build.txt')).write_bytes(result.stdout+result.stderr)
  result.check_returncode();runs+=1
  if before==digest(toc):break
 else:raise RuntimeError('TOC failed to converge: '+mode)
 log=(OUT/(stem+'.log')).read_text(encoding='utf-8',errors='replace')
 reports.append(dict(mode=mode,runs=runs,pdf_sha256=digest(OUT/(stem+'.pdf')),tex_sha256=digest(OUT/(stem+'.tex')),toc_sha256=digest(toc),missing_glyphs=log.count('Missing character:'),overfull=log.count('Overfull '),status='compiled_not_visual_acceptance'))
(ROOT/'print_compile_report.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(reports,ensure_ascii=False))
