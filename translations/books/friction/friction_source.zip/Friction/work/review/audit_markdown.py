"""Round-trip Markdown text, IDs and local links against the reviewed HTML."""
from pathlib import Path
import subprocess,json,hashlib,shutil
from bs4 import BeautifulSoup
from build_print import normalize_joins
ROOT=Path(__file__).resolve().parent
OUT=ROOT.parents[1]/'output'/'reviewed'
pandoc=shutil.which('pandoc') or r'C:\Users\Union\anaconda3\Library\bin\pandoc.exe'
def norm(s):return ''.join(c for c in s if c.isalnum())
reports=[]
for mode in ['zh','bilingual']:
 p=OUT/f'friction_{mode}.md';s=BeautifulSoup((OUT/f'friction_{mode}.html').read_text(encoding='utf-8'),'html.parser');normalize_joins(s)
 for n in list(s.select('head,style,script,nav,.figure-key,svg')):n.decompose()
 result=subprocess.run([pandoc,str(p),'--from=markdown+native_divs+native_spans','--to=html'],capture_output=True,text=True,encoding='utf-8',check=True)
 t=BeautifulSoup(result.stdout,'html.parser')
 a=norm(s.get_text());b=norm(t.get_text());errors=[]
 if a!=b:
  i=next((i for i,(x,y) in enumerate(zip(a,b)) if x!=y),min(len(a),len(b)))
  errors.append(dict(kind='text',at=i,expected=a[max(0,i-40):i+120],actual=b[max(0,i-40):i+120],lengths=[len(a),len(b)]))
 ids=[n['id'] for n in t.select('[id]')];expected={n['id'] for n in s.select('[id]')}
 if expected-set(ids):errors.append(dict(kind='missing_ids',ids=sorted(expected-set(ids))))
 if len(ids)!=len(set(ids)):errors.append(dict(kind='duplicate_ids'))
 broken=[n['href'] for n in t.select('a[href^="#"]') if n['href'][1:] not in ids]
 if broken:errors.append(dict(kind='broken_links',links=broken))
 reports.append(dict(mode=mode,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),normalized_characters=len(a),anchors=len(ids),errors=errors,status='passed_roundtrip' if not errors else 'failed'))
(ROOT/'markdown_audit.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(reports,ensure_ascii=False))
