"""Export checked reading structure as data, without raw executable HTML.

Writes only output/reviewed/site. Installation into the shared website is a
separate explicit step, so other books and concurrent changes remain untouched.
"""
from pathlib import Path
from bs4 import BeautifulSoup,NavigableString
import json,hashlib
ROOT=Path(__file__).resolve().parent
OUT=ROOT.parents[1]/'output'/'reviewed'
SITE=OUT/'site';SITE.mkdir(exist_ok=True)
manifest=json.loads((ROOT/'book_manifest.json').read_text(encoding='utf-8'))
soup=BeautifulSoup((OUT/'friction_bilingual.html').read_text(encoding='utf-8'),'html.parser')
sections={n['id']:n for n in soup.main.find_all('section',recursive=False)}
front=soup.new_tag('section',id='front')
for n in list(soup.main.children):
 if getattr(n,'name',None) in ['header','div']:front.append(n.extract())
sections={'front':front,**sections}
# Stable language-neutral anchors for chapter outlines and language switches.
for section in sections.values():
 seen=set()
 for unit in section.select('[data-unit]'):
  uid=unit['data-unit']
  if uid in seen:continue
  seen.add(uid);wrapper=unit.find_parent(class_='pair') or unit.find_parent(class_='note')
  if wrapper:
   if not wrapper.get('id'):wrapper['id']=uid
   else:wrapper.insert(0,soup.new_tag('span',id=uid))
   if 'pair' in wrapper.get('class',[]):wrapper['class']=wrapper.get('class',[])+['parallel-row']
idmap={n['id']:sid for sid,sec in sections.items() for n in [sec,*sec.select('[id]')]}
allowed={'section','header','div','span','p','h1','h2','h3','h4','strong','em','i','b','sup','sub','a','br','ul','li','figure','figcaption','svg','defs','marker','path','g','text'}
attrs={'id','class','lang','href','role','aria-label','data-unit','data-joined-units','viewbox','refx','refy','markerwidth','markerheight','orient','d','fill','stroke','stroke-width','marker-start','marker-end','text-anchor','font-size','x','y'}
def encode(n):
 if isinstance(n,NavigableString):return str(n)
 assert n.name in allowed,n.name
 a={k:(' '.join(v) if isinstance(v,list) else v) for k,v in n.attrs.items() if k in attrs}
 if n.name=='a' and a.get('href','').startswith('#'):
  target=a['href'][1:];assert target in idmap,target
  a['data-target-chapter']=idmap[target]
  if n.get_text().startswith('↩'):
   a['class']=(a.get('class','')+' '+('en' if target.endswith('-en') else 'zh')).strip()
 return {'tag':n.name,'attrs':a,'children':[encode(c) for c in n.children]}
entries={x['id']:x for x in manifest['contents']}
entries['front']={'title':'版本与范围说明','title_source':'Edition and scope'}
entries['editorial-notes']={'title':'编者校注','title_source':'Editorial notes'}
chapters=[]
for sid,section in sections.items():
 entry=entries[sid];data={'id':sid,'renderFormat':'friction-v1','sourceLanguage':'en','sourceLanguageLabel':'English','body':[encode(section)]}
 path=SITE/(sid+'.json');path.write_text(json.dumps(data,ensure_ascii=False,separators=(',',':'))+'\n',encoding='utf-8')
 chapter={'id':sid,'title':entry['title'],'originalTitle':entry.get('title_source',entry['title']),'dataUrl':'translations/books/friction/'+path.name+'?v='+hashlib.sha256(path.read_bytes()).hexdigest()[:12]}
 if entry.get('parent'):chapter['partId']=entry['parent']
 if entry.get('kind')=='part':chapter['partId']=sid;chapter['title']+=' · 扉页'
 structure=ROOT/(sid+'_structure.json')
 if structure.exists():
  heads=json.loads(structure.read_text(encoding='utf-8')).get('headings',[])
  chapter['outline']=[{'anchor':h['unit_id'],'title':h['translation_heading'],'originalTitle':h['source_heading'],'level':h['heading_level']-1} for h in heads if h['heading_level']>1]
 chapters.append(chapter)
m=manifest['metadata']
metadata={'id':'friction','title':m['title'],'originalTitle':m['title_source'],'author':m['author'],'translator':'Xiaoyang Hao (AI-assisted translation and review)','language':'zh-CN','languagePair':'English / 中文','structured':True,'bilingual':True,'views':['zh','en','parallel'],'example':False,'description':'全球联结的民族志：中文校订稿与英汉对照，含原注、独立校注及参考文献。','editionNotice':m['edition_note']+' '+m['copyright_translation'],'parts':[{'id':x['id'],'title':x['title'],'originalTitle':x['title_source']} for x in manifest['contents'] if x['kind']=='part'],'chapters':chapters,'downloads':[]}
(SITE/'book-metadata.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(ROOT/'site_export_report.json').write_text(json.dumps({'status':'exported_not_browser_accepted','source_html_sha256':hashlib.sha256((OUT/'friction_bilingual.html').read_bytes()).hexdigest(),'chapters':len(chapters),'anchors':len(idmap),'files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in SITE.glob('*.json')}},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Exported',len(chapters),'sections and',len(idmap),'anchors.')
