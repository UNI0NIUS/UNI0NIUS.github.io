"""Export checked reading structure as data, without raw executable HTML.

Writes only output/reviewed/site. Installation into the shared website is a
separate explicit step, so other books and concurrent changes remain untouched.
"""
from pathlib import Path
from bs4 import BeautifulSoup,NavigableString
import json,hashlib
ROOT=Path(__file__).resolve().parent
OUT=ROOT.parents[1]/'output'/'reviewed'
SITE=OUT/'site';SITE.mkdir(exist_ok=True)
manifest=json.loads((ROOT/'book_manifest.json').read_text(encoding='utf-8'))
soup=BeautifulSoup((OUT/'friction_bilingual.html').read_text(encoding='utf-8'),'html.parser')
sections={n['id']:n for n in soup.main.find_all('section',recursive=False)}
front=soup.new_tag('section',id='front')
for n in list(soup.main.children):
 if getattr(n,'name',None) in ['header','div']:front.append(n.extract())
sections={'front':front,**sections}
# Use the site's native parallel rows and paragraph footnotes.
from build_print import normalize_joins
idmap={n['id']:sid for sid,sec in sections.items() for n in [sec,*sec.select('[id]')]}
joined_pages={n['data-joined-units']:n.select_one('.source-page').get_text().removeprefix('原页 ') for n in soup.select('[data-joined-units]')}
normalize_joins(soup)
BLOCKS={'quote','interview','verse','verse-line','attribution','subtitle','definition','vignette','sidebar','list-entry','section-break','notice','quote-date','figure-key','figure-boxes'}
def children(n,lang,skip_id=None):
 return [t for c in n.children for t in encode(c,lang,skip_id)]
def encode(n,lang,skip_id=None):
 if isinstance(n,NavigableString):return [str(n)]
 cls=set(n.get('class',[]));ident=n.get('id')
 if 'source-page' in cls:return []
 prefix=[{'type':'anchor','id':ident}] if ident and ident!=skip_id else []
 if n.name=='svg':
  return [{'type':'image','src':'translations/books/friction/figures/figure1-'+lang+'.svg?v='+hashlib.sha256((OUT/'figures'/('figure1-'+lang+'.svg')).read_bytes()).hexdigest()[:12],'alt':n.get('aria-label','')}]
 if n.name=='sup' and n.select_one('a.noteref'):
  a=n.a; nid=a['href'][1:].rsplit('-',1)[0]
  return [{'type':'anchor','id':a['id']},{'type':'note','id':nid,'label':a.get_text()}]
 c=children(n,lang,skip_id)
 if n.name=='a':
  url=n.get('href','')
  if url.startswith('#'):
   target=url[1:]; destination=idmap[target]
   targetlang=target.rsplit('-',1)[-1]
   view=targetlang if targetlang in ['en','zh'] else lang
   url='translations/book.html?id=friction&chapter='+destination+'&view='+view+'#'+target
  return prefix+[{'type':'link','url':url,'children':c}]
 if n.name in ['em','i','strong','b','sup','sub']:
  return prefix+[{'type':{'i':'em','b':'strong'}.get(n.name,n.name),'children':c}]
 if n.name=='br':return prefix+[{'type':'linebreak'}]
 if n.name in ['h1','h2','h3','h4']:
  return prefix+[{'type':'block','kind':'heading','level':max(2,int(n.name[1])),'children':c}]
 kind=next((k for k in ['verse-line','quote','interview','verse','attribution','subtitle','definition','vignette','sidebar','list-entry','section-break','notice','quote-date','figure-key','figure-boxes'] if k in cls),None)
 if n.name=='figure':kind='figure'
 if n.name=='figcaption':kind='caption'
 if n.name=='p' and not kind:kind='paragraph'
 if n.name in ['ul','li']:kind={'ul':'list','li':'item'}[n.name]
 if n.parent and 'figure-boxes' in n.parent.get('class',[]):kind='figure-box'
 if kind:
  t={'type':'block','kind':kind,'children':c}
  for flag in ['stanza-start','indented','attribution','verse-title']:
   if flag in cls:t[flag]=True
  return prefix+[t]
 return prefix+c

def page(n):
 p=n.select_one('.source-page');return p.get_text().removeprefix('原页 ') if p else ''
def note_tokens(n,lang):
 unit=n.select_one('.unit.'+lang)
 tokens=encode(unit,lang)
 # The common footnote renderer supplies the number before its first paragraph.
 for i,t in enumerate(tokens):
  if isinstance(t,dict) and t.get('type')=='block' and t.get('kind')=='paragraph':
   tokens[i:i+1]=t['children'];break
 return tokens
all_notes={n.select_one('[data-unit]')['data-unit']:{'number':n.strong.get_text(),**{lang:note_tokens(n,lang) for lang in ['en','zh']}} for n in sections['notes'].select('.note')}
def note_ids(tokens):
 for t in tokens:
  if isinstance(t,dict):
   if t['type']=='note':yield t['id']
   yield from note_ids(t.get('children',[]))
def rows(section,sid):
 result=[]
 for i,n in enumerate(section.find_all(recursive=False)):
  cls=set(n.get('class',[]))
  if 'pair' in cls or 'note' in cls:
   units=n.select('[data-unit]')
   uid=units[0]['data-unit'] if units else n.select_one('[id]')['id'].rsplit('-',1)[0]
   # Joined rows retain the first unit as their neutral bookmark.
   if 'joined' in cls:uid=n.get('data-joined-units','').split()[0] if n.get('data-joined-units') else n.select_one('[id]')['id'].rsplit('-',1)[0]
   row={'id':uid,'page':joined_pages.get(n.get('data-joined-units'),page(n)),'en':[],'zh':[]}
   for lang in ['en','zh']:
    selected=[c for c in n.find_all(recursive=False) if lang in c.get('class',[]) or c.get('lang')==lang or (c.name=='figure' and c.get('id','').endswith('-'+lang))]
    if not selected:
     selected=[c for c in n.find_all(recursive=False) if c.select_one('.unit.'+lang)]
    row[lang]=[t for c in selected for t in encode(c,lang)]
    if 'note' in cls:
     row[lang].insert(0,{'type':'strong','children':[n.strong.get_text()+'. ']})
     backlink=next(c for c in n.find_all('a',recursive=False) if c['href'].endswith('-'+lang))
     row[lang]+=encode(backlink,lang)
   if 'spaced' in cls:row['spaced']=True
  else:
   uid=n.get('id',sid+'-section-'+str(i+1))
   row={'id':uid,'shared':True,'en':encode(n,'en',uid),'zh':encode(n,'zh',uid)}
  result.append(row)
 return result
entries={x['id']:x for x in manifest['contents']}
entries['front']={'title':'版本与范围说明','title_source':'Edition and scope'}
entries['editorial-notes']={'title':'编者校注','title_source':'Editorial notes'}
chapters=[]
for sid,section in sections.items():
 entry=entries[sid];body=rows(section,sid)
 used=set(nid for row in body for lang in ['en','zh'] for nid in note_ids(row[lang]))
 data={'id':sid,'sourceLanguage':'en','sourceLanguageLabel':'English','body':body,'notes':{nid:all_notes[nid] for nid in sorted(used)}}
 path=SITE/(sid+'.json');path.write_text(json.dumps(data,ensure_ascii=False,separators=(',',':'))+'\n',encoding='utf-8')
 chapter={'id':sid,'title':entry['title'],'originalTitle':entry.get('title_source',entry['title']),'dataUrl':'translations/books/friction/'+path.name+'?v='+hashlib.sha256(path.read_bytes()).hexdigest()[:12]}
 if entry.get('parent'):chapter['partId']=entry['parent']
 if entry.get('kind')=='part':chapter['partId']=sid;chapter['title']+=' · 扉页'
 structure=ROOT/(sid+'_structure.json')
 if structure.exists():
  heads=json.loads(structure.read_text(encoding='utf-8')).get('headings',[])
  chapter['outline']=[{'anchor':h['unit_id'],'title':h['translation_heading'],'originalTitle':h['source_heading'],'level':h['heading_level']-1} for h in heads if h['heading_level']>1]
 chapters.append(chapter)
m=manifest['metadata']
metadata={'id':'friction','title':m['title'],'originalTitle':m['title_source'],'author':m['author'],'translator':'Xiaoyang Hao (AI-assisted translation and review)','language':'zh-CN','languagePair':'English / 中文','structured':True,'bilingual':True,'views':['zh','en','parallel'],'example':False,'description':'全球联结的民族志：中文校订稿与英汉对照，含原注、独立校注及参考文献。','editionNotice':m['edition_note']+' '+m['copyright_translation'],'parts':[{'id':x['id'],'title':x['title'],'originalTitle':x['title_source']} for x in manifest['contents'] if x['kind']=='part'],'chapters':chapters,'downloads':[]}
(SITE/'book-metadata.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(ROOT/'site_export_report.json').write_text(json.dumps({'status':'exported_not_browser_accepted','source_html_sha256':hashlib.sha256((OUT/'friction_bilingual.html').read_bytes()).hexdigest(),'chapters':len(chapters),'anchors':len(idmap),'files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in SITE.glob('*.json')}},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Exported',len(chapters),'sections and',len(idmap),'anchors.')
