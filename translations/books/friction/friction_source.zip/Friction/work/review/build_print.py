"""Export reviewed HTML into editable TeX; never edit canonical translation.

Run build_reading.py and its audits first. Compile the generated TeX twice with
XeLaTeX from output/reviewed. This renderer keeps checked joins as real paragraphs.
"""
from pathlib import Path
from bs4 import BeautifulSoup, NavigableString
import json, hashlib, re

ROOT=Path(__file__).resolve().parent
OUT=ROOT.parents[1]/'output'/'reviewed'
FIGS={f['id']:f for f in json.loads((ROOT/'ch02_figures.json').read_text(encoding='utf-8'))}
ESC={'\\':r'\textbackslash{}','&':r'\&','%':r'\%','$':r'\$','#':r'\#','_':r'\_','{':r'\{','}':r'\}','~':r'\textasciitilde{}','^':r'\textasciicircum{}'}
def esc(s): return ''.join(ESC.get(c,c) for c in s.replace('↩','返回'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

PREAMBLE=r'''\documentclass[11pt,a4paper,openany,oneside]{book}
\usepackage{fontspec,xeCJK}
\setmainfont{Times New Roman}
\setCJKmainfont{SimSun}[AutoFakeBold=2,AutoFakeSlant=.15]
\usepackage[margin=24mm,headheight=15pt]{geometry}
\usepackage{microtype,parskip,needspace,tikz}
\usepackage{xurl}
\urlstyle{same}
\usetikzlibrary{arrows.meta}
\usepackage[unicode,colorlinks=true,linkcolor=black,urlcolor=blue,bookmarksdepth=3]{hyperref}
\usepackage{bookmark}
\usepackage{fancyhdr}
\pagestyle{fancy}\fancyhf{}\fancyfoot[C]{\thepage}
\renewcommand{\headrulewidth}{0pt}
\setlength{\parindent}{0pt}\setlength{\parskip}{5pt plus 1pt minus 1pt}
\linespread{1.22}\emergencystretch=3em
\setcounter{secnumdepth}{-1}\setcounter{tocdepth}{2}
\renewcommand{\contentsname}{目录}
\newenvironment{readingquote}{\begin{list}{}{\setlength{\leftmargin}{1.5em}\setlength{\rightmargin}{1em}}\item\relax}{\end{list}}
\begin{document}
'''

def normalize_joins(soup):
    for group in soup.select('.joined-language'):
        # Preserve IDs where the second unit continues within the same paragraph.
        for unit in group.select('.unit'):
            marker=soup.new_tag('span',id=unit['id'])
            unit.insert(0,marker)
            unit.attrs.pop('id',None)
        for node in list(group.select('.source-page')): node.decompose()
        for node in list(group.select('.prose,.quote,.unit')): node.unwrap()
        for head in list(group.select('p.join-head')):
            tail=head.find_previous('p',class_='join-tail')
            assert tail is not None and tail in group.descendants
            # Move intervening ID markers into the continued paragraph.
            for item in list(tail.next_siblings):
                if item is head: break
                tail.append(item.extract())
            tail.append(' ')
            for child in list(head.contents): tail.append(child.extract())
            head.decompose()

class Renderer:
    def __init__(self,soup): self.first_heading=False; self.seen=[]; self.soup=soup; self.pending_anchor=''
    def children(self,n): return ''.join(self.render(c) for c in n.children)
    def diagram(self,n):
        fid,lang=n['id'].rsplit('-',1); f=FIGS[fid]
        if fid=='figure1':
            nodes=f['translation_nodes' if lang=='zh' else 'source_nodes']
            center=f['translation_center' if lang=='zh' else 'source_center']
            drawing=r'\begin{center}\begin{tikzpicture}[>=Stealth,every node/.style={align=center,font=\small}]'+'\n'
            for name,pos,label in zip(['a','b','c'],['(0,3)','(-4,0)','(4,0)'],nodes):
                drawing+=r'\node ('+name+') at '+pos+' {'+esc(label)+'};\n'
            drawing+=r'\node[text width=6cm] at (0,1.3) {'+esc(center)+r'};\draw[<->] (a) -- (b);\draw[<->] (b) -- (c);\draw[<->] (c) -- (a);\end{tikzpicture}\end{center}'+'\n'
        else:
            boxes=f['translation_boxes' if lang=='zh' else 'source_boxes']
            drawing=r'\begin{center}'+'\n'+''.join(r'\begin{tikzpicture}\node[draw,rounded corners=5pt,inner sep=8pt,text width=.8\linewidth,align=center] {'+esc(t)+r'};\end{tikzpicture}\par\medskip'+'\n' for t in boxes)+r'\end{center}'+'\n'
        return r'\par\noindent\begin{minipage}{\linewidth}'+drawing+self.render(n.find('figcaption'))+r'\end{minipage}\par'+'\n'
    def render(self,n):
        if isinstance(n,NavigableString):
            return ''.join((r'\url{'+p.rstrip('.')+'}'+('.' if p.endswith('.') else '')) if p.startswith(('http://','https://')) else esc(p) for p in re.split(r'(https?://[^\s<>\u3000-\u9fff\uff00-\uffef]+)',str(n)))
        if not getattr(n,'name',None): return ''
        cls=set(n.get('class',[])); uid=n.get('id')
        anchor=''
        if uid:
            assert uid not in self.seen,uid
            self.seen.append(uid);anchor=r'\hypertarget{'+uid+'}{}'
        if n.name in ['style','script','nav','svg']: return ''
        if 'figure-key' in cls:return ''
        if 'diagram' in cls:return anchor+self.diagram(n)
        if n.name=='section':
            if 'part' in cls:
                title=n.find('h1'); title.extract()
                return r'\part{'+self.children(title)+'}\n'+anchor+self.children(n)
            self.first_heading=True
            self.pending_anchor+=anchor
            return self.children(n)
        if 'unit' in cls and self.first_heading and n.find(re.compile('^h[1-6]$')):
            self.pending_anchor+=anchor
            return ''.join(self.render(c) for c in n.children if not getattr(c,'get',lambda *_:None)('class') or 'source-page' not in c.get('class',[]))
        if re.fullmatch('h[1-6]',n.name):
            label=self.children(n)
            if 'sidebar-title' in cls:
                unit=n.find_parent(attrs={'data-unit':True})
                other=self.soup.find(id=unit['data-unit']+'-en')
                if unit.get('lang')=='zh' and other:return anchor
                other=self.soup.find(id=unit['data-unit']+'-zh')
                if unit.get('lang')=='en' and other:label+=' / '+self.children(other.find(class_='sidebar-title'))
            if uid and uid.endswith('-zh') and self.soup.find(id=uid[:-3]+'-en'):
                return anchor
            if uid and uid.endswith('-en'):
                partner=self.soup.find(id=uid[:-3]+'-zh')
                if partner:label+=' / '+self.children(partner)
            if self.first_heading:
                command='chapter';self.first_heading=False
            else:command={'h1':'chapter','h2':'section','h3':'section','h4':'subsection'}.get(n.name,'subsubsection')
            pending=self.pending_anchor;self.pending_anchor=''
            return '\\'+command+'{'+label+'}\n'+pending+anchor
        if n.name=='a':
            href=n.get('href','');text=self.children(n)
            if href.startswith('#'):return anchor+r'\hyperlink{'+href[1:]+'}{'+text+'}'
            if href.startswith(('http://','https://')):return anchor+r'\href{'+esc(href)+'}{'+text+'}'
            return anchor+text
        if 'verse' in cls:
            groups=[]
            for line in n.find_all(class_='verse-line',recursive=False):
                if not groups or 'stanza-start' in line.get('class',[]):groups.append([])
                groups[-1].append(line)
            content=''.join(r'\needspace{'+str(round(len(group)*1.6,1))+r'\baselineskip}'+''.join(self.render(line) for line in group) for group in groups)
            return anchor+r'\begin{readingquote}'+content+r'\end{readingquote}'+'\n'
        content=self.children(n)
        if n.name=='p':
            if 'reference' in cls:return anchor+r'{\small\hangindent=1.5em\hangafter=1 '+content+'\n\\par}\n'
            return anchor+content+'\n\\par\n'
        if n.name=='br':return r'\newline{}'+'\n'
        if n.name in ['em','i']:return anchor+r'\emph{'+content+'}'
        if n.name in ['strong','b']:return anchor+r'\textbf{'+content+'}'
        if n.name=='sup':return anchor+r'\textsuperscript{'+content+'}'
        if n.name=='ul':return (anchor+r'\begin{itemize}'+content+r'\end{itemize}'+'\n') if n.find('li') else anchor
        if n.name=='li':return anchor+r'\item '+content+'\n'
        if 'source-page' in cls:return anchor+r'\par{\raggedleft\scriptsize '+content+r'\par}'+'\n'
        if 'verse-line' in cls:
            lead=r'\medskip ' if 'stanza-start' in cls else ''
            indent=r'\hspace*{2em}' if 'indented' in cls else ''
            if 'attribution' in cls:return anchor+r'{\raggedleft '+content+r'\par}'+'\n'
            return anchor+lead+r'\noindent '+indent+content+r'\par'+'\n'
        if 'verse' in cls:return anchor+r'\begin{readingquote}'+content+r'\end{readingquote}'+'\n'
        if cls & {'quote','interview','sidebar'}:return anchor+r'\begin{readingquote}'+content+r'\end{readingquote}'+'\n'
        if 'attribution' in cls:return anchor+r'{\raggedleft '+content+r'\par}'+'\n'
        if cls & {'subtitle','definition','vignette'}:return anchor+r'{\itshape '+content+r'\par}'+'\n'
        if 'section-break' in cls:return anchor+r'\begin{center}'+content+r'\end{center}'+'\n'
        if 'editorref' in cls:return anchor+r'\textsuperscript{'+content+'}'
        if 'pair' in cls:return anchor+content+'\n'
        if 'note' in cls:return anchor+r'\par\medskip\needspace{4\baselineskip}'+content+r'\par'+'\n'
        return anchor+content

def main():
    outputs=[]
    for mode in ['zh','bilingual']:
        source=OUT/f'friction_{mode}.html'
        soup=BeautifulSoup(source.read_text(encoding='utf-8'),'html.parser')
        normalize_joins(soup)
        renderer=Renderer(soup); main=soup.main
        header=main.find('header'); title=header.find('h1').get_text(); metadata=header.find('p').get_text(' / ')
        header.decompose()
        titlepage=r'\begin{titlepage}\centering\vspace*{35mm}{\Huge '+esc(title)+r'\par}\bigskip{\Large '+('中文校订稿' if mode=='zh' else '英汉对照校订稿')+r'\par}\vfill '+esc(metadata)+r'\par\bigskip 2026年10月校订版\end{titlepage}'+'\n'
        notice=main.find('div',class_='notice');front=renderer.render(notice);notice.decompose()
        text=PREAMBLE+titlepage+r'\frontmatter '+front+r'\tableofcontents\mainmatter'+'\n'+renderer.children(main)+r'\end{document}'+'\n'
        target=OUT/f'friction_{mode}.tex';target.write_text(text,encoding='utf-8')
        outputs.append(dict(mode=mode,html_sha256=sha(source),tex_sha256=sha(target),anchors=len(renderer.seen)))
    (ROOT/'print_export_report.json').write_text(json.dumps(dict(status='tex_generated_not_pdf_accepted',outputs=outputs),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(outputs,ensure_ascii=False))
if __name__=='__main__':main()
