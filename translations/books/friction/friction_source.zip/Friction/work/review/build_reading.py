"""Reproducible review HTML drafts from canonical bilingual data.

Only generated files under output/reviewed are written. Structural exceptions
remain explicit in rendering_report.json until their implementations are checked.
"""
from pathlib import Path
import json, re, hashlib, html
from collections import defaultdict
from bs4 import BeautifulSoup

ROOT=Path(__file__).resolve().parent
OUT=ROOT.parents[1]/'output'/'reviewed'
def read(name): return json.loads((ROOT/name).read_text(encoding='utf-8'))
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
rows=[json.loads(l) for l in (ROOT/'translation_units.jsonl').read_text(encoding='utf-8').splitlines()]
BY={r['id']:r for r in rows}
manifest=read('book_manifest.json')
assert manifest['canonical_sha256']==sha(ROOT/'translation_units.jsonl'),'Refresh book manifest after canonical edit'
sections=[x['id'] for x in manifest['contents'] if x['kind']=='section']
structures={s:read(s+'_structure.json') for s in sections}
links=read('note_links.json'); editor=read('editorial_notes.json')['notes']
LINKS=defaultdict(list); EDITOR=defaultdict(list)
for l in links: LINKS[l['unit_id']].append(l)
for n in editor:
 for uid in n['unit_ids']:EDITOR[uid].append(n)
heads={h['unit_id']:h for d in structures.values() for h in d.get('headings',[])}
cleanups=[]; issues=[]
def ids(values):return [x if isinstance(x,str) else x['unit_id'] for x in values]
def collect(key):return set(v for d in structures.values() for v in ids(d.get(key,[])))
verses=collect('verse_units')|collect('verse')
quotes=collect('quote_units')
for d in structures.values():
 for group in d.get('quote_groups',[]):quotes.update(group)
 for group in d.get('block_quotes',[]):quotes.update(group['units'])
definitions=collect('definitions')|collect('definition_units')
subtitles={d['subtitle']['unit_id'] for d in structures.values() if 'subtitle'in d}
subtitles.add('interlude_asia-0002')
attributions=collect('attributions')
italic_units=collect('italic_vignette_units')
breaks=collect('section_break_before')|collect('section_breaks_before')
for d in structures.values():
 for b in d.get('section_breaks',[]):
  if 'before_unit' in b:breaks.add(b['before_unit'])
spaces=collect('paragraph_spacing_before')|collect('paragraph_space_before')
sidebars=set(u for g in structures['interlude_earth']['sidebar_groups'] for u in g['unit_ids'])
FIGURES={f['id']:f for f in read('ch02_figures.json')}

def figure(fid,lang):
 f=FIGURES[fid];escape=html.escape
 if fid=='figure1':
  nodes=f['translation_nodes' if lang=='zh' else 'source_nodes'];center=f['translation_center' if lang=='zh' else 'source_center']
  # Six directed relationships, matching the checked diagram data.
  assert sorted(f['edges'])==sorted([[0,1],[1,0],[1,2],[2,1],[2,0],[0,2]])
  diagram=f'''<svg viewBox="0 0 720 300" role="img" aria-label="{escape(f['description'])}">
  <defs><marker id="arrow-{lang}" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="#416466"/></marker></defs>
  <g stroke="#416466" stroke-width="1.8" marker-start="url(#arrow-{lang})" marker-end="url(#arrow-{lang})"><path d="M 320 70 L 160 225"/><path d="M 400 70 L 560 225"/><path d="M 205 250 L 515 250"/></g>
  <g text-anchor="middle" fill="#243a3c" font-size="20"><text x="360" y="45">{escape(nodes[0])}</text><text x="145" y="283">{escape(nodes[1])}</text><text x="575" y="283">{escape(nodes[2])}</text><text x="360" y="182" font-size="17">{escape(center)}</text></g></svg>'''
  diagram+='<div class="figure-key">'+''.join('<p>'+escape(nodes[a])+' ↔ '+escape(nodes[b])+'</p>' for a,b in [(0,1),(1,2),(2,0)])+'<p>'+('中心：' if lang=='zh' else 'Centre: ')+escape(center)+'</p></div>'
 else:
  boxes=f['translation_boxes' if lang=='zh' else 'source_boxes']
  # Text wraps naturally on narrow screens; the two boxes carry no arrows.
  diagram='<div class="figure-boxes">'+''.join('<div>'+escape(t)+'</div>' for t in boxes)+'</div>'
 caption=render_unit(BY[f['unit_id']],lang)
 return f'<figure class="diagram" id="{fid}-{lang}">{diagram}<figcaption>{caption}</figcaption></figure>'

def prepare(r,lang):
 text=r['translation' if lang=='zh' else 'source_text']
 for l in LINKS[r['id']]:
  anchor=l['translation_anchor' if lang=='zh' else 'source_anchor']
  assert text.count(anchor)==1,(r['id'],lang,anchor)
  at=text.index(anchor)+len(anchor)
  if lang=='en':
   # This exact suffix inventory was reviewed; parentheses are never stripped.
   tail=re.match(r"[’'\"”*°!]+",text[at:])
   if tail and (l['note_id'].startswith(('note_introduction-','note_ch01-','note_ch02-','note_interlude_asia-'))):
    removed=tail.group();text=text[:at]+text[at+len(removed):]
    cleanups.append(dict(note_id=l['note_id'],unit_id=r['id'],removed=removed,anchor=anchor))
  token=f'⟦NOTE:{l["note_id"]}:{l["number"]}⟧'
  text=text[:at]+token+text[at:]
 # Explicit paragraph boundaries from source-checked sidecars.
 d=structures.get(r['section'],{})
 for b in d.get('paragraph_boundaries',[]) if isinstance(d.get('paragraph_boundaries'),list) else []:
  if b['unit_id']!=r['id']:continue
  before=b.get('translation_before' if lang=='zh' else 'source_before')
  if before and before in text:
   a,c=text.split(before,1);a=a.rstrip()
   if lang=='en' and b.get('source_separator_to_remove'):a=a.rstrip(' |')
   text=a+'\n\n'+before+c
 return text.strip()

def inline(text,lang,uid):
 text=html.escape(text)
 # The canonical Markdown uses asterisk emphasis; preserve all other punctuation.
 text=re.sub(r'\*\*([^*\n]+)\*\*',r'<strong>\1</strong>',text)
 text=re.sub(r'(?<!\*)\*([^*\n]+)\*(?!\*)',r'<em>\1</em>',text)
 def note(m):
  nid,num=m.groups()
  return f'<sup><a class="noteref" id="ref-{nid}-{lang}" href="#{nid}-{lang}">{num}</a></sup>'
 text=re.sub(r'⟦NOTE:([^:]+):(\d+)⟧',note,text)
 return text

def decorate(text,uid,lang):
 d=structures.get(BY[uid]['section'],{})
 for s in d.get('italic_spans',[]):
  if s['unit_id']!=uid:continue
  span=s.get('translation_span' if lang=='zh' else 'source_span',s.get('translation' if lang=='zh' else 'source'))
  if span and span in text and f'*{span}*' not in text:text=text.replace(span,f'*{span}*',1)
 for s in d.get('critical_italics',[]):
  if s['unit_id']==uid:
   for span in s['spans']:
    if span in text and f'*{span}*' not in text:text=text.replace(span,f'*{span}*',1)
 dated=d.get('dated_opening',{})
 if dated.get('unit_id')==uid:
  prefix=dated.get('translation_prefix' if lang=='zh' else 'source_prefix',dated.get('translation' if lang=='zh' else 'source'))
  if prefix and text.startswith(prefix):text='**'+prefix+'**'+text[len(prefix):]
 return text

def body(text,uid,lang,role=None):
 text=decorate(text,uid,lang)
 if not text:return ''
 if role is None:
  dialogue=structures['ch04']['nested_dialogue']
  if uid==dialogue['inner_start']['unit_id']:
   anchor=dialogue['inner_start']['translation_anchor' if lang=='zh' else 'source_anchor']
   assert anchor in text
   pre,post=text.split(anchor,1)
   return body(pre,uid,lang,'prose')+body(anchor+post,uid,lang,'quote')
  if uid==dialogue['inner_end']['unit_id']:
   anchor=dialogue['inner_end']['translation_anchor' if lang=='zh' else 'source_anchor']
   assert anchor in text
   pre,post=text.split(anchor,1)
   return body(pre+anchor,uid,lang,'quote')+body(post,uid,lang,'prose')
  if uid in dialogue['outer_units'][1:-1]:return body(text,uid,lang,'quote')
  if uid=='ch02-0066':
   rule=structures['ch02']['section_breaks'][0]
   anchor=rule['after_translation' if lang=='zh' else 'after_source']
   assert text.count(anchor)==1
   pre,post=text.split(anchor,1)
   return body(pre+anchor,uid,lang,'prose')+'<div class="section-break" aria-label="段间分隔">···</div>'+body(post,uid,lang,'prose')
  if uid=='interlude_asia-0011':
   pieces=re.split(r'\n\s*\n',text)
   assert len(pieces)==3,(uid,lang,len(pieces))
   return ''.join(body(t,uid,lang,'quote' if i==1 else 'prose') for i,t in enumerate(pieces))
  if uid in structures['interlude_facilities']['interview']['unit_ids']:
   pieces=re.split(r'\n\s*\n',text)
   return ''.join(body(t,uid,lang,'interview' if uid!='interlude_facilities-0008' or i==0 else 'prose') for i,t in enumerate(pieces))
  if uid=='ch07-0033':
   rule=structures['ch07']['interview'];anchor=rule['translation_start' if lang=='zh' else 'start_in_0033']
   assert anchor in text,(uid,lang,anchor)
   pre,post=text.split(anchor,1)
   return body(pre,uid,lang,'prose')+body(anchor+post,uid,lang,'quote')
  if uid=='ch07-0034':return body(text,uid,lang,'quote')
  if uid=='ch04-0045':
   rule=structures['ch04']['embedded_quote_blocks'][0];anchor=rule['translation_start' if lang=='zh' else 'source_start']
   assert anchor in text
   pre,post=text.split(anchor,1)
   return body(pre,uid,lang,'prose')+body(anchor+post,uid,lang,'quote')
  for a in structures['ch04']['embedded_attributions']:
   if a['unit_id']!=uid or uid in verses:continue
   anchor=a['translation_anchor' if lang=='zh' else 'source_anchor']
   assert anchor in text,(uid,lang,anchor)
   pre,post=text.split(anchor,1)
   return body(pre,uid,lang,'quote' if uid in quotes else 'prose')+body(anchor,uid,lang,'attribution')+body(post,uid,lang,'prose')
  if uid=='ch04-0090':return body(text,uid,lang,'quote')
  if uid=='ch04-0028':return body(text,uid,lang,'quote-date')
 role=role or ('verse' if uid in verses else 'subtitle' if uid in subtitles else 'definition' if uid in definitions else 'attribution' if uid in attributions else 'quote' if uid in quotes else 'sidebar' if uid in sidebars else 'vignette' if uid in italic_units else 'prose')
 if uid in sidebars:
  if BY[uid]['kind']=='heading':return '<h3 class="sidebar-title">'+inline(text,lang,uid)+'</h3>'
  return '<div class="sidebar">'+''.join('<p class="list-entry">'+inline(line,lang,uid)+'</p>' for line in text.splitlines() if line.strip())+'</div>'
 if role=='verse':
  lines=text.splitlines();line_html=[]
  for i,line in enumerate(lines,1):
   classes=['verse-line']
   if uid=='ch05-0002':
    if i in [5,9,15,21]:classes.append('stanza-start')
    if 5<=i<=8 or 15<=i<=20:classes.append('indented')
    if i==28:classes.append('attribution')
   elif uid=='ch06-0002' and i==8:classes.append('attribution')
   elif uid=='ch03-0002' and i==5:classes.append('attribution')
   elif uid=='ch07-0001':
    if i==1:classes.append('verse-title')
    if i==3:classes.append('attribution')
   if line.startswith(('—','——')):classes.append('attribution')
   if uid=='ch04-0002' and i==1:classes.append('verse-title')
   line_html.append('<div class="'+' '.join(classes)+'">'+inline(line,lang,uid)+'</div>')
  return '<div class="verse">'+''.join(line_html)+'</div>'
 paragraphs=re.split(r'\n\s*\n',text)
 contents=''.join('<p>'+inline(s,lang,uid).replace('\n','<br>')+'</p>' for s in paragraphs if s.strip())
 if role=='interview':
  contents=re.sub(r'<p>([^<:：]{1,60}[:：])',r'<p><span class="speaker">\1</span>',contents)
 return f'<div class="{role}">{contents}</div>'

def render_unit(r,lang):
 uid=r['id'];text=prepare(r,lang);h=heads.get(uid)
 if uid=='interlude_asia-0001':h=dict(heading_level=1,embedded_body=False,source_heading=text,translation_heading=text)
 if h:
  level=h['heading_level'];label=h['translation_heading' if lang=='zh' else 'source_heading']
  title=f'<h{level+1} id="heading-{uid}-{lang}">{inline(label,lang,uid)}</h{level+1}>'
  if not h['embedded_body']:
   # Heading sidecar is authoritative; no body is silently removed from an embedded heading.
   result=title
  elif label in text:
   pre,post=text.split(label,1)
   pre=re.sub(r'(?m)^\s*#{1,6}\s*$','',pre)
   if h.get('position')!='internal' and pre.strip(' \n“”\"'):issues.append(f'{uid}/{lang}: unexpected heading prefix {pre[:60]!r}')
   post=post.lstrip(' \n。')
   result=body(pre,uid,lang)+(figure('figure1',lang) if uid=='ch02-0015' else '')+title+body(post,uid,lang,'verse' if uid=='ch07-0001' else None)
  else:
   issues.append(f'{uid}/{lang}: embedded heading text missing')
   result=title+body(text,uid,lang)
 else:result=body(text,uid,lang)
 ed=''.join(f'<a class="editorref" href="#{n["id"]}">校注{int(n["id"].split("-")[1])}</a>' for n in EDITOR[uid])
 source=', '.join(str(x.get('printed_page') or x['pdf_page']) for x in r['source_refs'])
 return f'<div class="unit {lang}" id="{uid}-{lang}" data-unit="{uid}" lang="{lang}"><span class="source-page">原页 {html.escape(source)}</span>{result}{ed}</div>'

CSS='''
.diagram{margin:2em 0;padding:1em;border:1px solid #d6d9d5}.diagram svg{width:100%;height:auto}.diagram .unit{font-size:.8em}.figure-boxes{display:grid;gap:1.5em;max-width:650px;margin:0 auto}.figure-boxes>div{border:1px solid #416466;border-radius:14px;text-align:center;padding:1em;font-size:.9em}.stanza-start{margin-top:1em}.indented{padding-left:2em}.verse-title{font-weight:600;margin-bottom:.6em}.interview{font-style:italic;margin:1em 2em}.speaker{font-style:normal}.quote-date{margin:1em 2em 0;font-weight:600}.list-entry{padding-left:1.3em;text-indent:-1.3em;margin:.35em 0}.joined .unit,.joined .prose,.joined .quote{display:contents}.joined p.join-tail,.joined p.join-head{display:inline}.joined p.join-tail:after{content:" "}.joined .source-page{display:none}.joined-language{margin:.8em 0}.joined-language.quote{display:block}.joined-language.en{margin-bottom:1em}.joined .editorref{display:none}
:root{color-scheme:light;--ink:#202a2e;--muted:#6b7477;--line:#d6d9d5;--paper:#faf9f5}
*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font-family:Georgia,"Noto Serif CJK SC","SimSun",serif;font-size:18px;line-height:1.9}
main{max-width:960px;margin:0 auto;padding:48px 42px}a{color:#315e62;text-underline-offset:3px}h1,h2,h3,h4{line-height:1.45;font-weight:600;break-after:avoid}h1{font-size:2.1em;margin:1.4em 0 .4em}h2{font-size:1.6em;margin:2.3em 0 .8em}h3{font-size:1.25em;margin:1.8em 0 .5em}h4{font-size:1.1em}p{margin:.7em 0;overflow-wrap:anywhere}.unit{position:relative}.source-page{display:block;text-align:right;color:var(--muted);font-size:.65em;line-height:1.3}.en{color:#475359;font-size:.95em}.pair{border-bottom:1px solid #e5e6e2;padding:1em 0}.pair .en{margin-bottom:1em}.pair .zh{margin-top:1em}.subtitle,.definition{font-style:italic}.subtitle{text-align:center;margin-bottom:2em}.quote{border-left:2px solid var(--line);padding:.1em 1.4em;margin:1em}.verse{margin:1.5em 2em;line-height:1.75}.verse-line{min-height:1.5em}.attribution{text-align:right;font-size:.9em}.vignette{font-style:italic}.sidebar{border-left:3px solid #b9c8b6;padding:.2em 1em;font-size:.9em}.noteref{font-size:.8em;text-decoration:none;padding:0 .15em}.editorref{font-size:.7em;margin-right:.8em}.editor-note,.note{font-size:.9em;margin:1em 0}.section-break{text-align:center;letter-spacing:.6em;margin:2em 0;color:#8c9690}.part{padding:4em 0 2em;border-top:1px solid var(--line)}.part p{font-size:.9em;color:var(--muted)}nav{font-family:system-ui,sans-serif;font-size:.85em;border:1px solid var(--line);padding:1.5em}nav a{display:block}.toc-child{padding-left:1.5em}.notice{padding:1em 1.5em;background:#eef0e9;font-size:.85em}.reference{font-size:.85em;padding-left:1.5em;text-indent:-1.5em}.spaced{margin-top:2em}sup{line-height:0}
@media(max-width:640px){main{padding:24px 18px}body{font-size:17px}.quote{margin:1em 0;padding-left:1em}.verse{margin:1em}.pair{padding:1.3em 0}}
.figure-key{display:none}.figure-key p{font-size:.85em;margin:.25em 0}@media(max-width:640px){.figure-key{display:block}}
.joined .unit{display:inline}
.mode-zh .pair{border-bottom:0;padding:.35em 0}
@media print{body{background:white;font-size:11pt}main{max-width:none;padding:0}.part{break-before:page}nav{break-after:page}.source-page{font-size:7pt}a{color:inherit}.notice{background:white}h2{break-before:auto}}
'''

def document(mode):
 langs=['zh'] if mode=='zh' else ['en','zh'];m=manifest['metadata'];chunks=[]
 chunks.append('<header><h1>'+html.escape(m['title'])+'</h1><p><i>'+html.escape(m['title_source'])+'</i><br>'+html.escape(m['author'])+'</p></header>')
 chunks.append('<div class="notice"><p>校订阅读版 · 2026年10月</p><p>'+html.escape(m['edition_note'])+'</p><p>'+html.escape(m['copyright_translation'])+'</p>'+''.join('<p>'+html.escape(s)+'</p>' for s in m['scope_notes'])+'</div>')
 chunks.append('<nav aria-label="目录">'+''.join(f'<a class="{"toc-child" if x.get("parent") else ""}" href="#{x["id"]}">{html.escape(x["title"])}</a>' for x in manifest['contents'])+'</nav>')
 parts={x['before_section']:x for x in read('part_frontispieces.json')}
 for sec in sections:
  if sec in parts:
   part=parts[sec];chunks.append(f'<section class="part" id="{part["id"]}"><h1>{html.escape(part["title"])}</h1><p>{html.escape(part["caption_translation"])}</p><p>{html.escape(part["editor_note"])}</p></section>')
  chunks.append(f'<section id="{sec}">')
  for r in rows:
   if r['section']!=sec or r['status']!='translated':continue
   uid=r['id']
   if uid=='interlude_earth-0051':chunks.append('<div class="notice"><h2>原书边栏名录</h2><p>'+html.escape(structures['interlude_earth']['sidebar_rendering']['provenance'])+'</p></div>')
   if uid in ['ch02-0016','ch02-0070']:continue
   if uid=='ch02-0068':chunks.append('<div class="pair">'+''.join(figure('figure2',l) for l in langs)+'</div>')
   if uid in breaks:chunks.append('<div class="section-break" aria-label="段间分隔">···</div>')
   chunks.append(f'<div class="pair {"spaced" if uid in spaces else ""}">'+''.join(render_unit(r,l) for l in langs)+'</div>')
  chunks.append('</section>')
 chunks.append('<section id="notes"><h1>原注</h1>')
 group=None
 for r in rows:
  if r['kind']!='note':continue
  if group!=r['note_group']:
   group=r['note_group'];chunks.append('<h2>'+html.escape(r['note_group_title'])+'</h2>')
  chunks.append('<div class="note"><strong>'+str(r['note_number'])+'</strong>'+''.join(render_unit(r,l)+f'<a href="#ref-{r["id"]}-{l}" aria-label="返回正文">↩ {l}</a>' for l in langs)+'</div>')
 chunks.append('</section><section id="editorial-notes"><h1>编者校注</h1>')
 for n in editor:
  chunks.append(f'<div class="editor-note" id="{n["id"]}"><h3>校注{int(n["id"].split("-")[1])} · {html.escape(n["title"])}</h3><p>{html.escape(n["text"])}</p><ul>'+''.join(f'<li><a href="{html.escape(s["url"],quote=True)}">{html.escape(s["title"])}</a></li>' for s in n['sources'])+'</ul>'+''.join(f'<a href="#{u}-zh">返回相关段落</a> ' for u in n['unit_ids'])+'</div>')
 chunks.append('</section><section id="references"><h1>参考文献</h1>')
 for line in (ROOT/'references_entries.jsonl').read_text(encoding='utf-8').splitlines():
  r=json.loads(line);chunks.append(f'<p class="reference" id="{r["id"]}">{html.escape(r["source_text"])}</p>')
 chunks.append('</section>')
 result='<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>'+html.escape(m['title'])+'</title><style>'+CSS+'</style></head><body class="mode-'+mode+'"><main>'+''.join(chunks)+'</main></body></html>'
 return join_paragraphs(result,langs)

def join_paragraphs(document,langs):
 """Keep unit IDs and text ownership while suppressing checked paragraph breaks."""
 soup=BeautifulSoup(document,'html.parser')
 groups=structures['ch04']['continuous_paragraph_groups']+structures['ch07']['paragraph_join']+[structures['interlude_asia']['continued_inline_quote']]
 for group in groups:
  units=[soup.find(id=uid+'-'+langs[0]) for uid in group]
  pairs=[u.find_parent(class_='pair') for u in units]
  wrapper=soup.new_tag('div',attrs={'class':'pair joined','data-joined-units':' '.join(group)})
  pairs[0].insert_before(wrapper)
  for lang in langs:
   container=soup.new_tag('div',attrs={'class':'joined-language '+lang+(' quote' if group[0] in quotes or group[0]=='ch04-0129' else '')})
   selected=[soup.find(id=uid+'-'+lang) for uid in group]
   for left,right in zip(selected,selected[1:]):
    lp=left.find_all('p')[-1];rp=right.find_all('p')[0]
    lp['class']=lp.get('class',[])+['join-tail'];rp['class']=rp.get('class',[])+['join-head']
   for unit in selected:container.append(unit.extract())
   wrapper.append(container)
  for pair in pairs:pair.decompose()
 return str(soup)

def main():
 OUT.mkdir(parents=True,exist_ok=True)
 for mode in ['zh','bilingual']:(OUT/f'friction_{mode}.html').write_text(document(mode),encoding='utf-8')
 pending=['本次生成版本须由audit_reading和audit_reading_structure绑定验收','多格式交付与网站发布状态以各自证据为准']
 report=dict(status='draft_not_accepted',canonical_sha256=sha(ROOT/'translation_units.jsonl'),
 outputs={x.name:sha(x) for x in OUT.glob('*.html')},
 implemented=['17节目录及三部分部','规范段落与显式段界','原注双语精确锚点与返回链接','19条独立校注与出处','353参考文献','诗行/副标题/已列整体引语/斜体/日期前缀','两幅图示按核定文字关系重绘并原位插入，图注仅一次','第五章诗节交替缩进与开篇诗署名细分'],
 source_pseudo_markers_removed=list({(x['note_id'],x['removed']):x for x in cleanups}.values()),
 errors=list(dict.fromkeys(issues)),pending=pending)
 (ROOT/'rendering_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(dict(status=report['status'],errors=report['errors'],outputs=report['outputs'],pending=pending),ensure_ascii=False))
if __name__=='__main__':main()
