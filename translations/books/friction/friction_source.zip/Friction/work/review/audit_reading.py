"""Compare rendered HTML text against canonical units and check every local link."""
import json,re,hashlib
from collections import Counter
from bs4 import BeautifulSoup
from build_reading import ROOT,OUT,rows,prepare,editor
def norm(text):return ''.join(c for c in text if c.isalnum())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
reports=[]
for mode in ['zh','bilingual']:
 path=OUT/f'friction_{mode}.html';soup=BeautifulSoup(path.read_text(encoding='utf-8'),'html.parser')
 counts=Counter(x['id'] for x in soup.select('[id]'));errors=[];mismatches=[]
 for key,count in counts.items():
  if count!=1:errors.append(f'duplicate id {key}')
 for a in soup.select('a[href^="#"]'):
  if a['href'][1:] not in counts:errors.append(f'broken link {a["href"]}')
 checked=0
 for r in rows:
  if r['status']!='translated':continue
  for lang in ['zh'] if mode=='zh' else ['en','zh']:
   unit=soup.find(id=r['id']+'-'+lang)
   if unit is None:errors.append(f'missing {r["id"]}/{lang}');continue
   # Source labels, note numbers and editorial links are separately checked.
   clone=BeautifulSoup(str(unit),'html.parser')
   for node in clone.select('.source-page,sup,.editorref,.diagram'):node.decompose()
   actual=norm(clone.get_text())
   expected=norm(re.sub(r'⟦NOTE:[^⟧]+⟧','',prepare(r,lang)))
   if actual!=expected:
    first=next((i for i,(a,b) in enumerate(zip(actual,expected)) if a!=b),min(len(actual),len(expected)))
    mismatches.append(dict(id=r['id'],lang=lang,expected_chars=len(expected),actual_chars=len(actual),first_difference=first,expected_context=expected[max(0,first-30):first+70],actual_context=actual[max(0,first-30):first+70]))
   checked+=1
 refs=soup.select('.reference');assert len(refs)==353
 notes=soup.select('.editor-note');assert len(notes)==19
 reports.append(dict(mode=mode,sha256=sha(path),units_checked=checked,references=len(refs),editorial_notes=len(notes),errors=errors,text_mismatches=mismatches,status='passed_text_and_links' if not errors and not mismatches else 'needs_review',limitations='Alphanumeric normalization ignores punctuation and whitespace; does not prove typography, structure, source correctness or PDF/site delivery.'))
(ROOT/'reading_text_audit.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(reports,ensure_ascii=False,indent=2))
