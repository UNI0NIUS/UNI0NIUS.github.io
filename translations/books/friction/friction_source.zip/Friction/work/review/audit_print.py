"""PDF text/readability diagnostics; does not certify visual layout."""
from pathlib import Path
import json,re,hashlib
import pymupdf as fitz
from bs4 import BeautifulSoup
ROOT=Path(__file__).resolve().parent
OUT=ROOT.parents[1]/'output'/'reviewed'
def norm(s):return ''.join(c.lower() for c in s if c.isalnum())
reports=[]
for mode in ['zh','bilingual']:
 p=OUT/f'friction_{mode}.pdf';d=fitz.open(p);pages=[];outliers=[]
 for i,page in enumerate(d):
  fragments=[]
  for block in page.get_text('dict')['blocks']:
   for line in block.get('lines',[]):
    for span in line['spans']:
     x0,y0,x1,y1=span['bbox']
     if span['size']<8 or y0>page.rect.height-60:continue
     fragments.append(span['text'])
     if x0<30 or x1>page.rect.width-30:outliers.append(dict(page=i+1,text=span['text'],bbox=span['bbox']))
  pages.append(norm(''.join(fragments)))
 text=''.join(pages)
 soup=BeautifulSoup((OUT/f'friction_{mode}.html').read_text(encoding='utf-8'),'html.parser')
 for n in list(soup.select('sup,.source-page,.editorref,.figure-key,nav,svg')):n.decompose()
 missing=[];checked=0
 for n in soup.select('.unit p,.unit .verse-line,.reference,.editor-note p'):
  t=norm(n.get_text())
  if not t:continue
  checked+=1
  if t not in text:
   unit=n.find_parent(attrs={'data-unit':True})
   missing.append(dict(unit=unit.get('id') if unit else n.get('id'),text=n.get_text(),normalized_length=len(t)))
 log=(OUT/f'friction_{mode}.log').read_text(encoding='utf-8',errors='replace')
 headings=[n.get_text() for n in soup.select('.unit h2,.unit h3,.unit h4')]
 missing_headings=[s for s in headings if norm(s) not in text]
 names=d.resolve_names();langs=['zh'] if mode=='zh' else ['en','zh']
 links=json.loads((ROOT/'note_links.json').read_text(encoding='utf-8'))
 missing_anchors=[a for l in links for lang in langs for a in [l['note_id']+'-'+lang,'ref-'+l['note_id']+'-'+lang] if a not in names]
 bad_links=[dict(page=i+1,link=l) for i,page in enumerate(d) for l in page.get_links() if l['kind']==1 and not 0<=l['page']<len(d)]
 reports.append(dict(mode=mode,pages=len(d),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),paragraphs_checked=checked,missing=missing,headings_checked=len(headings),missing_headings=missing_headings,note_anchors_checked=len(links)*len(langs)*2,missing_note_anchors=missing_anchors,bad_internal_links=bad_links,margin_outliers=outliers,missing_glyphs=re.findall(r'Missing character:.*',log),overfull=re.findall(r'Overfull.*',log),bookmarks=len(d.get_toc()),status='diagnostic_not_acceptance'))
(ROOT/'print_text_audit.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps([{k:(len(v) if isinstance(v,list) else v) for k,v in r.items()} for r in reports],ensure_ascii=False))
