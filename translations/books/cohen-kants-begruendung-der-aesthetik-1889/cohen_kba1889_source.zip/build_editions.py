from pathlib import Path
import json,hashlib,re,subprocess,sys
R=Path(__file__).resolve().parent; W=R/'draft-webdata';O=R/'output';O.mkdir(exist_ok=True)
meta=json.loads((W/'book-metadata.json').read_text('utf8')); books={c['id']:json.loads((W/(c['id']+'.json')).read_text('utf8')) for c in meta['chapters']}
pre=(R/'templates/reading_preamble.tex').read_text('utf8').replace('Kants Theorie der Erfahrung / 康德的经验理论','Kants Begründung der Aesthetik / 康德美学的奠基').replace('Kants Theorie der Erfahrung','Kants Begründung der Aesthetik')
esc=lambda s:''.join({'\\':r'\textbackslash{}','&':r'\&','%':r'\%','$':r'\$','#':r'\#','_':r'\_','{':r'\{','}':r'\}','~':r'\textasciitilde{}','^':r'\textasciicircum{}'}.get(c,c) for c in str(s))
class Renderer:
 def __init__(self,mode):self.mode=mode;self.bi=mode=='bilingual';self.out=[];self.open=False;self.refs={'zh':set(),'en':set()};self.last={'zh':None,'en':None}
 def close(self):
  if self.open:self.out.append(r'\end{paracol}');self.open=False
 def page(self,p,lang):
  if not p or (self.bi and lang=='en') or self.last[lang]==p:return ''
  self.last[lang]=p;return r'\sourcepage{'+esc(p)+'}'
 def tokens(self,items,lang,notes=False):
  out=[]
  for t in items:
   if isinstance(t,str):out.append(esc(t).replace('\n',r'\newline '));continue
   typ=t['type']
   if typ=='anchor':out.append(r'\hypertarget{'+esc(t['id'])+'}{}')
   elif typ=='page':out.append(r'\hypertarget{'+esc(t['id'])+'}{}'+self.page(t['page'],lang))
   elif typ=='note':
    nid=t['id'];self.refs[lang].add(nid);out.append(r'\hypertarget{ref-'+lang+'-'+esc(nid)+r'}{}\hyperlink{note-'+esc(nid)+r'}{\textsuperscript{'+esc(t['label'])+'}}')
   elif typ in ('break','linebreak'):out.append(r'\par ' if typ=='break' else r'\newline ')
   elif typ=='link':
    target=t['url'].split('#')[-1];out.append(r'\hyperlink{'+esc(target)+'}{'+self.tokens(t['children'],lang)+'}')
   elif typ=='table':
    rows=[]
    for cells in t['rows']:rows.append(' & '.join(self.tokens(c,lang) for c in cells)+r' \\')
    out.append(r'\begin{center}\begin{tabular}{ll}'+''.join(rows)+r'\end{tabular}\end{center}')
   else:raise ValueError(typ)
  return ''.join(out)
 def pair(self,z,d,small=False):
  if small:z=r'{\small '+z+'}';d=r'{\small '+d+'}'
  if self.bi:
   if not self.open:self.out.append(r'\begin{paracol}{2}');self.open=True
   self.out.extend([z+r'\par',r'\switchcolumn',d+r'\par',r'\switchcolumn*'])
  else:self.out.append((z if self.mode=='zh' else d)+r'\par')
 def heading(self,row,cid):
  self.close(); z=self.tokens(row['zh'],'zh');d=self.tokens(row['en'],'en');pg=row.get('page');z=self.page(pg,'zh')+z;d=self.page(pg,'en')+d
  title=''.join(x for x in row['en' if self.mode=='de' else 'zh'] if isinstance(x,str)).strip() or '目录';cmd='subsection' if cid in ('nature','ethics','beauty','sublime') else 'section'; self.out.append(r'\needspace{7\baselineskip}\hypertarget{'+esc(row['id'])+'}{}'+'\\'+cmd+'['+esc(title)+']{'+(z+r'\\{\normalsize '+d+'}' if self.bi else z if self.mode=='zh' else d)+'}')
 def row(self,row):
  pg=row.get('page');z=r'\hypertarget{'+esc(row['id'])+'}{}'+self.page(pg,'zh')+self.tokens(row['zh'],'zh');d=(r'\hypertarget{'+esc(row['id'])+'}{}' if self.mode=='de' else '')+self.page(pg,'en')+self.tokens(row['en'],'en')
  self.pair(z,d,small=False)
 def endnotes(self,c):
  if not c['notes']:return
  self.close();self.out.append(r'\needspace{6\baselineskip}\subsection*{原注 / Anmerkungen}')
  for nid,n in c['notes'].items():
   mark=r'\textsuperscript{'+esc(n['number'])+'} ';target=r'\hypertarget{note-'+esc(nid)+'}{}';z=target+mark+self.tokens(n['zh'],'zh')+r'~\hyperlink{ref-zh-'+esc(nid)+r'}{\textsuperscript{↑}}';d=(target if self.mode=='de' else '')+mark+self.tokens(n['en'],'en')+r'~\hyperlink{ref-en-'+esc(nid)+r'}{\textsuperscript{↑}}';self.pair(z,d,True)
  self.close()
 def render(self):
  geo=('a4paper,inner=20mm,outer=23mm,top=21mm,bottom=23mm' if self.bi or self.mode=='de' else 'a4paper,margin=25mm')+',marginparwidth=16mm,marginparsep=3mm'
  self.out=[pre.replace('SIZE','10pt' if self.bi or self.mode=='de' else '11pt').replace('GEOMETRY',geo),r'\begin{titlepage}\centering\vspace*{25mm}{\Huge 康德美学的奠基\par}\bigskip{\Large Kants Begründung der Aesthetik\par}\vspace{15mm}{\Large 赫尔曼·柯亨 / Hermann Cohen\par}\vfill',esc({'zh':'中文校订版','de':'Deutsche Leseausgabe','bilingual':'中德逐段对照版'}[self.mode]),r'\par\bigskip Berlin: Ferd. Dümmlers Verlagsbuchhandlung, 1889\par\end{titlepage}']
  self.pair(esc('页边“S.”为原书页码，页底为本版页码；对照版页标沿中文栏定位。中文页界按语义就近对齐。原注置于各节末，保留原页码与页内编号，支持跳转和返回；中文原注附德文全文。'),esc('Die Randverweise „S.“ bezeichnen die Originalseiten; die Fußzeile zählt die Seiten dieser Ausgabe. In der zweisprachigen Ausgabe folgen die Randverweise der chinesischen Spalte. Die chinesischen Seitenübergänge sind sinngemäß angenähert. Originalanmerkungen stehen am Abschnittsende mit ursprünglicher Nummer und verknüpften Rückverweisen.'));self.close();self.out.append(r'\clearpage\tableofcontents\clearpage')
  for chapter in meta['chapters'][1:]:
   c=books[chapter['id']];self.close();self.out.append(r'\clearpage');
   if c['id'] in ('intro','original-toc'):self.out.append(r'\section{'+esc(c['title'] if self.mode!='de' else c['originalTitle'])+'}')
   for row in c['body']:
    if row['type'] in ('heading','subheading') and c['id']!='original-toc':self.heading(row,c['id'])
    else:self.row(row)
   self.endnotes(c)
  self.close();self.out.append(r'\end{document}')
  for lang in (['zh','en'] if self.bi else ['zh' if self.mode=='zh' else 'en']):assert len(self.refs[lang])==347,(lang,len(self.refs[lang]))
  return '\n'.join(self.out)
for mode in ('zh','de','bilingual'):
 renderer=Renderer(mode); tex=renderer.render();p=O/('cohen_kba1889_'+mode+'.tex');p.write_text(tex,encoding='utf8');print(mode,'TeX ready',flush=True)
 if '--compile' in sys.argv:
  for j in (1,2):
   q=subprocess.run(['xelatex','-interaction=nonstopmode','-halt-on-error',p.name],cwd=O,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(R/f'compile_{mode}_{j}.log').write_bytes(q.stdout)
   if q.returncode:print(q.stdout.decode('utf8','replace')[-4500:]);raise SystemExit(q.returncode)
  print(mode,'PDF compiled',flush=True)
