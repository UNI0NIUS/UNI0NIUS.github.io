"""Stage a review-only reader dataset. This script never touches a website.

Source-page labels on spanning paragraphs are approximate unless an audited
page_anchor exists. This draft must not be published as a final edition.
"""
from collections import defaultdict
from pathlib import Path
import hashlib, json, re

R=Path(__file__).resolve().parent
OUT=R/'draft-webdata'
BOOK='cohen-kants-begruendung-der-aesthetik-1889'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def load(name):return json.loads((R/name).read_text('utf8'))
def dump(name,value):
    (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf8')

d=load('reading_projection.json'); front=load('front_matter.json');toc=load('original_toc.json');front_pages=load('front_page_evidence.json')
assert d['canonical_sha256']==sha(R/'translation_units.jsonl')
assert d['front_matter_sha256']==sha(R/'front_matter.json')
assert d['original_toc_sha256']==sha(R/'original_toc.json')
assert d['structure_sha256']==sha(R/'structure_evidence.json')
assert front_pages['front_sha256']==sha(R/'front_matter.json')
spec=[('intro',1,5,None),('historical',6,91,'intro'),('system',92,101,'intro'),
      ('nature',102,126,'system'),('ethics',127,143,'system'),('chapter1',144,221,None),
      ('chapter2',222,263,None),('beauty',264,275,'chapter2'),('sublime',276,303,'chapter2'),
      ('chapter3',304,334,None),('chapter4',335,433,None)]
titles={s['id']:(s['zh'],s['de']) for s in toc['sections']}
titles.update(beauty=('美','Das Schöne'),sublime=('崇高','Das Erhabene'))
chapters=[];data={}
def chapter(cid,zh,de,parent=None):
    meta={'id':cid,'title':zh,'originalTitle':de,'dataUrl':f'translations/books/{BOOK}/{cid}.json'}
    if parent:meta['parentId']=parent
    chapters.append(meta);data[cid]={'id':cid,'title':zh,'originalTitle':de,'body':[], 'notes':{},'sourceLanguage':'de','sourceLanguageLabel':'Deutsch'}
    return data[cid]
chapter('title-page','原扉页','Titelblatt')
chapter('preface','序言','Vorwort')
chapter('original-toc','原书目录（含论题提要）','Inhalts-Verzeichniss')
for cid,a,b,parent in spec:chapter(cid,*titles[cid],parent)
def ch_for(page):
    matches=[cid for cid,a,b,_ in spec if a<=page<=b]
    assert len(matches)==1,(page,matches)
    return matches[0]

def plainrow(id,zh,de,typ='paragraph'):
    def lines(s):
        chunks=s.split('\n');out=[]
        for i,chunk in enumerate(chunks):
            if i:out.append({'type':'linebreak'})
            out.append(chunk)
        return out
    return {'id':id,'type':typ,'page':'','zh':lines(zh),'en':lines(de)}
t=front['title']
data['title-page']['body'].append(plainrow('title-page-text',t['zh']+'\n'+t['author_zh'],t['de']+'\n'+t['author'],'heading'))
data['title-page']['body'].append(plainrow('title-page-imprint',f"{t['place']}，{t['year']}",f"{t['publisher']}, {t['place']} {t['year']}"))
preface_title=plainrow('preface-title','序言','Vorwort','heading');preface_title['page']='III'
data['preface']['body'].append(preface_title)
transitions={x['unit_id']:x for x in front_pages['transitions']}
for u in front['preface']:
    row=plainrow(u['id'],u['zh'],u['source_text']);b=transitions.get(u['id'])
    if b:
        for lang,field,offset in [('zh','zh','zh_offset'),('de','en','de_offset')]:
            s=u['zh'] if lang=='zh' else u['source_text'];idx=b[offset]
            row[field]=[s[:idx],{'type':'page','page':b['original_page'],'id':f"{field}-{u['id']}-page-{b['original_page']}"},s[idx:]]
    data['preface']['body'].append(row)
data['preface']['body'].append(plainrow('preface-signature',front['signature']['zh'],front['signature']['de']))

groups=d['groups'];by_id={x['id']:x for x in groups};body_ch={};page_targets={};skipped=set()
heading_joins={
    'p144-0436':['p144-0437'], 'p222-0620':['p222-0621'],
    'p304-0825':['p304-0826','p304-0827'], 'p335-0930':['p335-0931','p335-0932'],
}
def tokens(group,lang):
    prefix='zh' if lang=='zh' else 'en';result=[{'type':'anchor','id':prefix+'-'+group['id']}]
    for i,r in enumerate(group[lang+'_runs']):
        kind=r['type']
        if kind=='text':
            value=re.sub(r'^⟦p\.[^⟧]+⟧\s*','',r['text']) if i==0 else r['text']
            if value:result.append(value)
        elif kind=='note_ref':result.append({'type':'note','id':r['note_id'],'label':r['label']})
        elif kind=='paragraph_break':result.append({'type':'break'})
        elif kind=='emphasis_line_break':result.append({'type':'linebreak'})
        elif kind=='page_anchor':result.append({'type':'page','page':str(r['page']),'id':f"{prefix}-{group['id']}-page-{r['page']}"})
        else:raise ValueError(kind)
    return result

for g in groups:
    if g['id'] in skipped:continue
    cid=ch_for(g['printed_pages'][0]);body_ch[g['id']]=cid
    row={'id':g['id'],'type':'heading' if g['kind']=='heading' else 'paragraph',
         'page':str(g['printed_pages'][0]),'zh':tokens(g,'zh'),'en':tokens(g,'de')}
    for extra_id in heading_joins.get(g['id'],[]):
        extra=by_id[extra_id];assert extra['kind']=='heading' and extra['printed_pages'][0]==g['printed_pages'][0]
        skipped.add(extra_id);body_ch[extra_id]=cid
        row['zh'] += [' ']+tokens(extra,'zh')
        row['en'] += [' ']+tokens(extra,'de')
    if g['kind']=='table':
        # Preserve the original two-column diagram as a real table in each view.
        row['type']='diagram'
        for language,field in [('zh','zh'),('de','en')]:
            text=''.join(x['text'] for x in g[language+'_runs'] if x['type']=='text')
            text=re.sub(r'^⟦p\.[^⟧]+⟧\s*','',text)
            rows=[[[cell] for cell in line.split('\t')] for line in text.strip().splitlines()]
            row[field]=[{'type':'table','rows':rows}]
    if g.get('join_next_unit'):
        nxt=by_id[g['join_next_unit']];skipped.add(nxt['id']);body_ch[nxt['id']]=cid
        for language,field in [('zh','zh'),('de','en')]:
            row[field]+=[{'type':'page','page':str(nxt['printed_pages'][0]),'id':f"{field}-{nxt['id']}-page"}]
            if language=='de':row[field].append(' ')
            row[field]+=tokens(nxt,language)
    data[cid]['body'].append(row)
    for p in g['printed_pages']:
        page_targets.setdefault(p,(cid,g['id']))
    for token in row['zh']:
        if isinstance(token,dict) and token.get('type')=='page':
            page_targets[int(token['page'])]=(cid,token['id'])
    if g.get('join_next_unit'):
        for p in nxt['printed_pages']:page_targets.setdefault(p,(cid,g['id']))

assert set(page_targets)==set(range(1,434)),sorted(set(range(1,434))-set(page_targets))
for n in d['notes']:
    cid=body_ch[n['body_id']];pg=str(n['printed_page'])
    data[cid]['notes'][n['id']]={'number':n['number'],'sourcePrintedPage':pg,
       'zh':[f'[原书第{pg}页] ',n['zh'],{'type':'break'},'原文：',n['de']],
       'en':[f'[S. {pg}] ',n['de']]}

heading_ids={'historical':'p006-0020','system':'p092-0295','nature':'p102-0319','ethics':'p127-0384', 'chapter1':'p144-0436','chapter2':'p222-0620','chapter3':'p304-0825','chapter4':'p335-0930', 'beauty':'p264-0729','sublime':'p276-0760'}
def heading_link(cid,text):
    target=heading_ids[cid]
    assert body_ch[target]==cid
    return {'type':'link','url':f'translations/book.html?id={BOOK}&chapter={cid}#{target}','children':[text]}
def topic_link(page,text,lang='zh'):
    cid,target=page_targets[page]
    if lang=='de' and target.startswith('zh-'):target='en-'+target[3:]
    return {'type':'link','url':f'translations/book.html?id={BOOK}&chapter={cid}#{target}','children':[text]}
for s in toc['sections']:
    body=data['original-toc']['body']; page=s.get('printed_page',s['navigation_page'])
    heading={'id':'toc-heading-'+s['id'],'type':'heading','page':'',
             'zh':[(heading_link(s['id'],s['zh']+' — '+str(page)) if s['id'] in heading_ids else topic_link(s['navigation_page'],s['zh']+' — '+str(page)))],
             'en':[(heading_link(s['id'],s['de']+' — '+str(page)) if s['id'] in heading_ids else topic_link(s['navigation_page'],s['de']+' — '+str(page), 'de'))]}
    if s.get('editor_note'):heading['zh'] += [{'type':'break'},'〔编者按〕'+s['editor_note']]
    body.append(heading)
    subs={x['before_page']:x for x in s.get('subheadings',[])}
    for e in s['entries']:
        if e['printed_page'] in subs:
            sub=subs.pop(e['printed_page']);p=sub['navigation_page']
            body.append({'id':'toc-sub-'+str(p),'type':'subheading','page':'',
                         'zh':[heading_link('beauty' if p==264 else 'sublime',sub['zh']+' — '+str(p))], 'en':[heading_link('beauty' if p==264 else 'sublime',sub['de']+' — '+str(p))]})
        p=e.get('navigation_page',e['printed_page']);label=str(e['printed_page'])
        row={'id':e['id'],'type':'paragraph','page':'',
             'zh':[topic_link(p,e['zh']+' — '+label)],'en':[topic_link(p,e['source_text']+' — '+label,'de')]}
        if e.get('editor_note'):row['zh'] += [{'type':'break'},'〔编者按〕'+e['editor_note']]
        body.append(row)

OUT.mkdir(exist_ok=True)
for cid,ch in data.items():dump(cid+'.json',ch)
meta={'id':BOOK,'title':t['zh'],'originalTitle':t['de'],'author':t['author'],'authorZh':t['author_zh'],
      'tags':['哲学','康德','美学'],'language':'中文 / Deutsch','languagePair':'中德双语',
      'structured':True,'bilingual':True,'views':['parallel','zh','en'],'sourceLanguage':'de',
      'sourceLanguageLabel':'Deutsch','chapters':chapters,'downloads':[],
      'sourceEdition':'Hermann Cohen, Berlin 1889','reviewedCanonicalSha256':d['canonical_sha256'],
      'readerUrl':f'https://uni0nius.github.io/translations/book.html?id={BOOK}',
      'draftNotice':'草稿：页界、原段、视觉排版和最终回读未全部验收；不可发布。'}
dump('book-metadata.json',meta)
refs=[]
for ch in data.values():
    for row in ch['body']:
        for tkn in row['zh']:
            if isinstance(tkn,dict) and tkn.get('type')=='note':refs.append((ch['id'],tkn['id']))
assert len(refs)==347 and len(set(refs))==347
assert all(nid in data[cid]['notes'] for cid,nid in refs)
assert sum(len(ch['notes']) for ch in data.values())==347
assert len([e for s in toc['sections'] for e in s['entries']])==426
dump('draft-report.json',{'status':'draft_not_publish_ready','chapters':len(chapters),'notes':len(refs),
     'toc_topics':426,'printed_pages_represented':len(page_targets),'warnings':d['warnings']})
print(json.dumps({'status':'draft_not_publish_ready','chapters':len(chapters),'notes':len(refs),
                  'toc_topics':426,'printed_pages_represented':len(page_targets)},ensure_ascii=False))
