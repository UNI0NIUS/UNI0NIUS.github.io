"""Check draft reader links, note coverage and stable anchors; not a release check."""
import json
from pathlib import Path
from urllib.parse import urlparse,parse_qs

R=Path(__file__).resolve().parent/'draft-webdata'
meta=json.loads((R/'book-metadata.json').read_text('utf8'))
data={m['id']:json.loads((R/(m['id']+'.json')).read_text('utf8')) for m in meta['chapters']}
ids={};all_rows=set();nrefs=0
for cid,ch in data.items():
    targets=set();refs={'zh':[],'en':[]}
    for row in ch['body']:
        assert row['id'] not in all_rows,row['id'];all_rows.add(row['id']);targets.add(row['id'])
        for lang in ('zh','en'):
            for token in row[lang]:
                if not isinstance(token,dict):continue
                typ=token.get('type')
                if typ in ('anchor','page'):
                    assert token['id'] not in targets,(cid,token['id']);targets.add(token['id'])
                if typ=='note':refs[lang].append(token['id'])
    assert len(refs['zh'])==len(set(refs['zh']))
    assert set(refs['zh'])==set(refs['en'])==set(ch['notes']),cid
    nrefs+=len(refs['zh']);ids[cid]=targets
links=0
for row in data['original-toc']['body']:
    for lang in ('zh','en'):
        for token in row[lang]:
            if not isinstance(token,dict) or token.get('type')!='link':continue
            parsed=urlparse(token['url']);cid=parse_qs(parsed.query)['chapter'][0]
            assert parsed.fragment in ids[cid],(cid,parsed.fragment)
            links+=1
assert nrefs==347 and len(meta['chapters'])==14
assert links==2*(426+9+2)
print(json.dumps({'status':'draft_internal_links_passed','chapters':len(data),'rows':len(all_rows),
                  'notes_per_language':nrefs,'toc_links':links,'browser_and_release_checks':'pending'}))
