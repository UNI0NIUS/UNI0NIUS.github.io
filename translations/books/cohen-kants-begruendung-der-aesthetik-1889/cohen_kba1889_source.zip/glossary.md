# 《康德美学的奠基》初译术语表

本表只服务于初译一致性与可检索性，不代替语义校对。原书用 19 世纪旧正字法（Aesthetik、Erkenntniss、Urtheil、Mannichfaltigkeit 等），译文按哲学史通行译法；必要时在首次出现处保留德文。表中“说明”用于区分中文里容易合并的概念。

## 一、核心概念

| 德文 | 中文 | 说明 |
| --- | --- | --- |
| Begründung | 奠基 / 论证 | 书名与篇章标题作“奠基”；具体论证过程可视语境作“论证” |
| Grund | 根据 / 根基 | 本书第一章辨析 Grund 的双重含义：Basis（基础）与 Grund und Boden（根基与地基） |
| Grundlage | 基础 | 与 Grund（根据）区分 |
| Basis | 基础 | 承托之意 |
| Boden | 地基 / 土壤 | “Grund und Boden”合译“根基与地基” |
| Fundament | 基石 | 建筑比喻 |
| Ableitung | 推导 | 从系统中引出 |
| Princip | 原则 | 也作“原理”，康德著作名与固定表述从通行译法 |
| System | 体系 | |
| systematisch | 系统的 / 体系性的 | |
| Aesthetik | 美学 | |
| ästhetisch | 审美的 | |
| Aestheticismus | 审美主义 | 指把美学原则绝对化 |
| Geschmack | 鉴赏 | |
| Geschmacksurtheil | 鉴赏判断 | |
| Urtheilskraft | 判断力 | 《判断力批判》= Kritik der Urtheilskraft |
| Urtheil | 判断 | |
| Wohlgefallen | 愉悦 | |
| Lust | 快乐 | |
| Unlust | 不快 | |
| Gefühl | 情感 / 感受 | 康德三大能力语境作“情感”；具体感觉状态作“感受” |
| Empfindung | 感觉 | |
| Empfindungsform | 感觉形式 | |
| Wahrnehmung | 知觉 | |
| Anschauung | 直观 | |
| Schau | 观照 / 直观 | 柏拉图的“看”；动词 schauen 作“观照” |
| Gesicht | 视象 / 直观 | 本书用以指“所见到者”，视上下文作“视象” |
| das Schöne | 美 | |
| das Erhabene | 崇高 | |
| Erhabenheit | 崇高性 | |
| Zweckmässigkeit | 合目的性 | |
| zweckmässig | 合目的的 | |
| Form | 形式 | |
| Stoff | 质料 | |
| Gehalt | 内容 | 与 Form 对举 |
| Inhalt | 内容 | 与 Gehalt 视语境区分：Inhalt 泛指内容 |
| Darstellung | 表现 | 也作“呈现”；康德“indirecte Darstellung”作“间接表现” |
| Ausdruck | 表达 | |
| Ideal | 理想 | |
| Idealität | 观念性 | |
| Realität | 实在性 | |
| Wirklichkeit | 现实性 | |
| Vollkommenheit | 完满性 | 历史导论中莱布尼茨、鲍姆加登与门德尔松概念统一；非术语用法按语境处理 |
| Möglichkeit | 可能性 | |
| Nothwendigkeit | 必然性 | |
| Natur | 自然 / 本性 | |
| Sittlichkeit | 道德性 / 伦理 | 与 Moral（道德）视语境区分 |
| sittlich | 道德的 | |
| Sittengesetz | 道德法则 | |
| Freiheit | 自由 | |
| Wille | 意志 | |
| Willkür | 任意 | |
| Wollen | 意愿 | |
| Trieb | 冲动 | |
| Spieltrieb | 游戏冲动 | 席勒术语 |
| Spiel | 游戏 / 活动 | 康德“freies Spiel der Kräfte”作“力的自由活动”；席勒语境作“游戏” |
| Kunst | 艺术 | |
| Künstler | 艺术家 | |
| Kunstwerk | 艺术作品 | |
| Genie | 天才 | |
| Einbildungskraft | 想象力 | |
| Verstand | 知性 | |
| Vernunft | 理性 | |
| Idee | 理念 | |
| ästhetische Idee | 审美理念 | |
| Symbol | 象征 | |
| symbolisch | 象征的 | |
| Analogie | 类比 | |
| Schein | 假象 | 与 Erscheinung（显象）区分 |
| Erscheinung | 显象 | |
| Bewusstsein | 意识 | |
| Bewusstheit | 意识性 | |
| Selbstbewusstsein | 自我意识 | |
| Gemeinsinn | 共通感 | |
| Mittheilbarkeit | 可传达性 | |
| Harmonie | 和谐 | |
| Stimmung | 情调 | “harmonische Stimmung”= 和谐情调 |
| Mannichfaltigkeit | 杂多 | |
| Einheit | 统一性 | |
| Zusammenhang | 联系 / 关联 | |
| Gemeinschaft | 共联性 / 共同体 | 康德范畴语境作“共联性” |
| Naturgesetz | 自然规律 | |
| Gesetzmässigkeit | 合规律性 | |
| transscendental | 先验的 | 与 transscendent（超验的）严格区分 |
| transscendent | 超验的 | |
| a priori | 先天 | |
| Erkenntniss | 认识 | |
| Erkenntnisskritik | 认识批判 | |
| Erkenntnisslehre | 认识学说 | |
| Wissenschaft | 科学 | |
| Erfahrung | 经验 | |
| Kritik | 批判 | |
| kritisch | 批判的 | |
| Metaphysik | 形而上学 | |
| Psychologie | 心理学 | |
| Anthropologie | 人类学 | |
| Logik | 逻辑学 | |
| Ethik | 伦理学 | |
| Teleologie | 目的论 | |
| Organismus | 有机体 | |
| Mechanik | 机械论 / 力学 | 康德语境“机械论” |
| Causalität | 因果性 | |
| Substanz | 实体 | |
| Hypothese / Hypothesis | 假设 | |
| Antinomie | 二律背反 | |
| Postulat | 公设 | |
| Axiom | 公理 | |

## 二、本书常用对举

| 德文 | 中文 |
| --- | --- |
| Form und Stoff | 形式与质料 |
| Idee und Erscheinung | 理念与显象 |
| Natur und Freiheit | 自然与自由 |
| Natur und Sittlichkeit | 自然与道德 |
| Erkennen und Fühlen | 认识与感受 |
| Verstand und Sinnlichkeit | 知性与感性 |
| Verstand und Einbildungskraft | 知性与想象力 |
| Anschauung und Begriff | 直观与概念 |
| Object und Subject | 客体与主体 |
| objectiv / subjectiv | 客观的 / 主观的 |
| Objectivität / Subjectivität | 客观性 / 主观性 |
| allgemein / besonders / einzeln | 普遍的 / 特殊的 / 单一的 |
| nothwendig / zufällig | 必然的 / 偶然的 |
| unendlich / endlich | 无限的 / 有限的 |
| übersinnlich | 超感性的 |
| sinnlich | 感性的 |
| intellectuell | 智性的 |
| intellectuale Anschauung | 智性直观 |
| intellectuelles Interesse | 智性兴趣 |
| uninteressirt | 无利害的 |
| interesselos | 无利害的 |

## 三、人名与书名

| 德文 | 中文 |
| --- | --- |
| Kant | 康德 |
| Platon | 柏拉图 |
| Aristoteles | 亚里士多德 |
| Sokrates | 苏格拉底 |
| Plotin | 普罗提诺 |
| Leibniz | 莱布尼茨 |
| Baumgarten | 鲍姆加登 |
| Winckelmann | 温克尔曼 |
| Lessing | 莱辛 |
| Herder | 赫尔德 |
| Schiller | 席勒 |
| Goethe | 歌德 |
| Rousseau | 卢梭 |
| Hume | 休谟 |
| Burke | 伯克 |
| Shaftesbury | 沙夫茨伯里 |
| Hutcheson | 哈奇森 |
| Mendelssohn | 门德尔松 |
| Hamann | 哈曼 |
| Jacobi | 雅可比 |
| Fichte | 费希特 |
| Schelling | 谢林 |
| Hegel | 黑格尔 |
| Herbart | 赫尔巴特 |
| Zeising | 蔡辛 |
| Kant, Kritik der reinen Vernunft | 康德《纯粹理性批判》 |
| Kant, Kritik der praktischen Vernunft | 康德《实践理性批判》 |
| Kant, Kritik der Urtheilskraft | 康德《判断力批判》 |
| Kant, Anthropologie | 康德《实用人类学》 |
| Kants Begründung der Ethik | 《康德伦理学的奠基》 | 柯亨本人的著作，非康德《道德形而上学奠基》 |
| Kants Theorie der Erfahrung | 《康德的经验理论》 |

## 四、旧正字法与 OCR 处理

- 原书拼写（Thätigkeit、Erkenntniss、Urtheil、Mannichfaltigkeit、Sittsamkeit 等）在源文层保留，不按现代德语改写；译文用现代汉语学术语。
- 原书用 Sperrsatz（字间加空）表示强调，OCR 会把一个词识别成用空格隔开的字母串。源文层须合并为一个词；确属强调处可在译文中用着重号或通过语序体现，不制造原文没有的断词。
- 原书跨行断词（如 “Zusammen- / fassung”）合并；复合词原有连字符（“Kultur-Erzeugungen”）保留。
- 希腊文、拉丁文引文保留原文；OCR 无法识别处回查页面图像，不凭猜测补写。
