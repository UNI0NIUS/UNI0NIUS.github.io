# 康德美学的奠基：校订阅读版源码

规范译文为 translation_units.jsonl，原始OCR保留在 units_normalized.jsonl 的 source_text_raw 字段。注号映射、结构证据、前置材料与阅读投影均随包附带。

本包可用 Python 3、XeLaTeX、Times New Roman 和 SimSun 重新生成阅读 PDF；运行 python build_editions.py --compile。运行 python export_markdown.py 生成两种 Markdown。网页数据由 export_web_draft.py 生成；应结合站点阅读器验收。

页码对应1889年原书；中文跨页位置按语义就近对齐。不要使用原项目 assemble_translation.py 重建本次校订数据。
