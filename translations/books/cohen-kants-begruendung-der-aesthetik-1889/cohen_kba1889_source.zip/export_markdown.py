from pathlib import Path
import json,re,html,hashlib
R=Path(__file__).resolve().parent;W=R/'draft-webdata';O=R/'output';m=json.loads((W/'book-metadata.json').read_text('utf8'));books={c['id']:json.loads((W/(c['id']+'.json')).read_text('utf8')) for c in m['chapters']}
class MD:
 def __init__(self,lang):self.lang=lang;self.field='zh' if lang=='zh' else 'en';self.last=None;self.refs=set();self.ids=set();self.out=[]
 def pg(self,p):
  if not p or p==self.last:return ''
  self.last=p;return ('〔原页 '+str(p)+'〕' if self.lang=='zh' else '[S. '+str(p)+'] ')
 def tokens(self,ts):
  out=[]
  for t in ts:
   if isinstance(t,str):out.append(t);continue
   ty=t['type']
   if ty=='anchor':out.append('<a id="'+t['id']+'"></a>')
   elif ty=='page':out.append('<a id="'+t['id']+'"></a>'+self.pg(t['page']))
   elif ty=='note':
    self.refs.add(t['id']);out.append('<a id="ref-'+t['id']+'"></a><sup><a href="#note-'+t['id']+'">'+html.escape(t['label'])+'</a></sup>')
   elif ty=='break':out.append('\n\n')
   elif ty=='linebreak':out.append('<br>')
   elif ty=='link':out.append('['+self.tokens(t['children'])+'](#'+t['url'].split('#')[-1]+')')
   elif ty=='table':out.append('\n\n'+'\n'.join('| '+' | '.join(self.tokens(x).replace('|',r'\|') for x in row)+' |' + ('\n| --- | --- |' if i==0 else '') for i,row in enumerate([r + [[]] * (max(map(len, t['rows'])) - len(r)) for r in t['rows']]))+'\n\n')
   else:raise ValueError(ty)
  return ''.join(out)
 def render(self):
  self.out=['# '+('康德美学的奠基' if self.lang=='zh' else 'Kants Begründung der Aesthetik'),'赫尔曼·柯亨 / Hermann Cohen\n\nBerlin: Ferd. Dümmlers Verlagsbuchhandlung, 1889.',('原页码按底本标识；中文页界按语义就近对齐。原注保留页内编号及返回链接，中文原注附德文全文。' if self.lang=='zh' else 'Die Seitenverweise beziehen sich auf den Originaldruck. Originalanmerkungen behalten ihre seitenweise Nummerierung und Rückverweise.')]
  for ch in m['chapters'][1:]:
   c=books[ch['id']]
   if c['id'] in ('original-toc','intro'):self.out.append('# '+(c['title'] if self.lang=='zh' else c['originalTitle']))
   for row in c['body']:
    s='<a id="'+row['id']+'"></a>'+self.pg(row.get('page'))+self.tokens(row[self.field]);
    if row['type'] in ('heading','subheading'):s=('## ' if c['id'] in ('nature','ethics','beauty','sublime','original-toc') else '# ')+s
    self.out.append(s)
   if c['notes']:
    self.out.append('### '+('原注' if self.lang=='zh' else 'Anmerkungen'))
    for nid,n in c['notes'].items():
     self.ids.add(nid);self.out.append('<a id="note-'+nid+'"></a>**'+str(n['number'])+'** '+self.tokens(n[self.field])+' <a href="#ref-'+nid+'">↑</a>')
  assert self.refs==self.ids and len(self.refs)==347
  text='\n\n'.join(self.out)+'\n';ids=re.findall(r'<a id="([^"]+)"',text);assert len(ids)==len(set(ids)),len(ids)-len(set(ids));links=re.findall(r'(?:href="#|\]\(#)([^"\)]+)',text);assert set(links)<=set(ids),set(links)-set(ids)
  return text
for lang in ('zh','de'):
 text=MD(lang).render();f=O/('cohen_kba1889_'+lang+'.md');f.write_text(text,encoding='utf8',newline='\n');print(lang,len(text),'characters; links valid')
