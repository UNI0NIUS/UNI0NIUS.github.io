"""Check draft preservation of text, references and audited break evidence."""
from pathlib import Path
from collections import Counter
import hashlib, json, re

R=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads((R/p).read_text('utf8'))
units={x['id']:x for x in map(json.loads,(R/'translation_units.jsonl').read_text('utf8').splitlines())}
normalized={x['id']:x for x in map(json.loads,(R/'units_normalized.jsonl').read_text('utf8').splitlines())}
projection=load('reading_projection.json');audit=load('source_note_anchor_audit.json');structure=load('structure_evidence.json')
assert projection['canonical_sha256']==sha(R/'translation_units.jsonl')
assert projection['structure_sha256']==sha(R/'structure_evidence.json')
assert all(normalized[k]['source_text']==u['source_text'] for k,u in units.items())
links={f"{x['unit_id']}-ref-{x['note_page']}-{x['number']}-{x['occurrence']}":x for x in audit['links']}
assert len(links)==347
sup=str.maketrans('0123456789','⁰¹²³⁴⁵⁶⁷⁸⁹')
note_ids={n['id'] for n in projection['notes']}
seen={'de':[], 'zh':[]}

def reconstruct(runs,lang):
    parts=[]
    for t in runs:
        if t['type']=='text': parts.append(t['text'])
        elif t['type']=='note_ref':
            assert t['note_id'] in note_ids
            seen[lang].append(t['ref_id'])
            parts.append(links[t['ref_id']]['verified_source_candidate']['token'] if lang=='de' else t['label'].translate(sup)+'⁾')
        else: assert t['type'] in ('paragraph_break','page_anchor','emphasis_line_break'), t
    return ''.join(parts)

for g in projection['groups']:
    u=units[g['id']]; de=u['source_text']; zh=u['zh']
    if u['id']=='p159-0479':
        a=de.index('1) Demgemäss ist die Ueberlegung')
        e='sei an diesem Einen Beispiele einmal eine Warnung verstattet.'
        b=de.index(e,a)+len(e)
        de=de[:a]+de[b:].replace(' tische','tische',1)
        zh=zh.split('\n\n1) ',1)[0]
    assert reconstruct(g['de_runs'],'de')==de, g['id']
    assert reconstruct(g['zh_runs'],'zh')==zh, g['id']
assert set(seen['de'])==set(seen['zh'])==set(links)
assert len(seen['de'])==len(seen['zh'])==347
assert len(note_ids)==347
counts=Counter(t['type'] for g in projection['groups'] for t in g['de_runs'])
assert counts['paragraph_break']==len(structure['paragraph_breaks'])==31
assert counts['page_anchor']==len(structure['page_breaks'])==377
assert counts['emphasis_line_break']==len(structure['de_emphasis_lines'])==16
print(json.dumps({'status':'draft_losslessness_checks_passed_not_publish_ready','groups':len(projection['groups']),
                  'notes':len(note_ids),'paragraph_breaks':counts['paragraph_break'],
                  'page_anchors':counts['page_anchor'],'emphasis_lines':counts['emphasis_line_break'],
                  'canonical_sha256':projection['canonical_sha256']},ensure_ascii=False))
