"""Create a draft, auditable reading projection from the reviewed canonical data.

This is not a publishing step. Page transitions and original paragraph boundaries
must be restored separately before these records are accepted for rendering.
"""
from collections import Counter, defaultdict
from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent
canonical = ROOT / 'translation_units.jsonl'
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
units = [json.loads(s) for s in canonical.read_text('utf-8').splitlines()]
by_id = {u['id']:u for u in units}
assert len(units) == len(by_id) == 1307
audit = json.loads((ROOT/'source_note_anchor_audit.json').read_text('utf-8'))
assert audit['translation_sha256'] == digest(canonical)
structure = json.loads((ROOT/'structure_evidence.json').read_text('utf-8'))
assert structure['canonical_sha256'] == digest(canonical)
assert all(x['status'] in ('visually_verified','bilingual_context_checked') for x in audit['links'])
audit_lookup = {(x['unit_id'],x['occurrence'],x['number'],x['note_page']):x for x in audit['links']}
links = []
for p in ROOT.glob('*注号映射.json'):
    mapping = json.loads(p.read_text('utf-8'))
    assert mapping['translation_sha256'] == digest(canonical)
    for link in mapping['links']:
        k = (link['unit_id'],link['occurrence'],link['number'],link['note_page'])
        assert k in audit_lookup
        links.append((link,audit_lookup[k]))
assert len(links) == len(audit_lookup) == 347

def strip_page(s):
    return re.sub(r'^⟦p\.[^⟧]+⟧\s*','',s)

def note_text(u, part=None):
    src = strip_page(u['source_text'])
    if part is not None:
        markers = list(re.finditer(r'(?<!\S)(\d+)\)\s*',src))
        selected = [i for i,m in enumerate(markers) if int(m.group(1)) == part]
        assert len(selected)==1,(u['id'],part,src)
        i = selected[0]
        src = src[markers[i].end():markers[i+1].start() if i+1<len(markers) else len(src)].strip()
        matching = [n for n in u['note_parts'] if n['no']==part]
        assert len(matching)==1,(u['id'],part)
        return src,matching[0]['zh']
    src = re.sub(r'^\d+\)\s*','',src).strip()
    return src,u['zh']

embedded = by_id['p159-0479']
embedded_de = embedded['source_text']
start = embedded_de.index('1) Demgemäss ist die Ueberlegung')
end_marker = 'sei an diesem Einen Beispiele einmal eine Warnung verstattet.'
end = embedded_de.index(end_marker,start)+len(end_marker)
embedded_note_de = embedded_de[start+3:end].strip()
assert embedded_de[start-5:start]=='ästhe' and embedded_de[end:].startswith(' tische')
embedded_body_de = embedded_de[:start]+embedded_de[end:].replace(' tische','tische',1)
embedded_body_zh, embedded_note_zh = embedded['zh'].split('\n\n1) ',1)

by_body = defaultdict(list)
notes = []
for link, check in links:
    u = by_id[link['unit_id']]
    token = str(link['number']).translate(str.maketrans('0123456789','⁰¹²³⁴⁵⁶⁷⁸⁹'))+'⁾'
    zh = embedded_body_zh if u['id']==embedded['id'] else u['zh']
    context = link['context']
    assert zh.count(context)==1 and context.endswith(token)
    zstart = zh.index(context)+len(context)-len(token)
    candidate = check['verified_source_candidate']
    de = embedded_body_de if u['id']==embedded['id'] else u['source_text']
    ds,de_end = candidate['start'],candidate['end']
    assert de[ds:de_end]==candidate['token'],(u['id'],candidate)
    nids = link.get('note_ids') or [link['note_id']]
    part = link.get('note_part')
    if link.get('note_kind')=='embedded':
        nid = u['id']+'-note'
        ns,nz = embedded_note_de,embedded_note_zh
    elif part is not None:
        nid = nids[0]+f'-part-{part}'
        ns,nz = note_text(by_id[nids[0]],part)
        assert nz==link['note_text']
    elif len(nids)>1:
        nid=nids[0]
        pieces=[note_text(by_id[i]) for i in nids]
        ns=' '.join(x[0] for x in pieces)
        nz=' '.join(x[1] for x in pieces)
    else:
        nid=nids[0]
        ns,nz=note_text(by_id[nid])
    refid=f"{u['id']}-ref-{link['note_page']}-{link['number']}-{link['occurrence']}"
    by_body[u['id']].append({'id':refid,'note_id':nid,'label':str(link['number']), 'note_number':link.get('note_number',link['number']), 'zh_start':zstart,'zh_end':zstart+len(token), 'source_start':ds,'source_end':de_end,'evidence':check['status']})
    notes.append({'id':nid,'number':link.get('note_number',link['number']), 'printed_label':link['number'], 'printed_page':link['note_page'], 'physical_ids':nids, 'part':part, 'zh':nz,'de':ns,'ref_id':refid,'body_id':u['id']})
assert len({x['id'] for x in notes}) == len(notes) == 347
assert len({x['ref_id'] for x in notes}) == 347

def runs(s, positions, lang, boundaries=()):
    a,b = ('zh_start','zh_end') if lang=='zh' else ('source_start','source_end')
    key='zh_offset' if lang=='zh' else 'de_offset'
    events=[(p[a], p[b], {'type':'note_ref','note_id':p['note_id'],'ref_id':p['id'],'label':p['label']}) for p in positions]
    for p in boundaries:
        if p['kind']=='emphasis_line':
            if lang=='zh':continue
            marker={'type':'emphasis_line_break'}
        elif p['kind']=='paragraph':marker={'type':'paragraph_break'}
        else:marker={'type':'page_anchor','page':p['printed_page'],'alignment':p['translation_alignment']}
        events.append((p[key],p[key],marker))
    events.sort(key=lambda x:(x[0],x[1]));out=[];last=0
    for start,end,event in events:
        assert start>=last and end<=len(s),(lang,start,end,last,len(s),event)
        if start>last:out.append({'type':'text','text':s[last:start]})
        out.append(event)
        last=end
    if last<len(s):out.append({'type':'text','text':s[last:]})
    return out

boundaries_by_id=defaultdict(list)
for boundary in structure['paragraph_breaks']+structure['page_breaks']+structure.get('de_emphasis_lines',[]):
    boundaries_by_id[boundary['unit_id']].append(boundary)
groups=[]
for u in units:
    if u['kind']=='note':continue
    de = embedded_body_de if u['id']==embedded['id'] else u['source_text']
    zh = embedded_body_zh if u['id']==embedded['id'] else u['zh']
    refs=by_body[u['id']]
    boundaries=boundaries_by_id[u['id']]
    if u['id']==embedded['id']:
        adjusted=[]
        for original in boundaries:
            p=dict(original);offset=p['de_offset']
            assert not start<=offset<end,('boundary inside embedded footnote',p)
            if offset>=end:p['de_offset']-=len(embedded_de)-len(embedded_body_de)
            assert p.get('zh_offset',0)<=len(zh),('boundary inside translated footnote',p)
            adjusted.append(p)
        boundaries=adjusted
    for boundary in boundaries:
        for language,s in [('de',de),('zh',zh)]:
            if language=='zh' and boundary['kind']=='emphasis_line':continue
            marker=boundary.get(language+'_projection_starts',boundary.get(language+'_starts'))
            if marker:assert s[boundary[language+'_offset']:].startswith(marker),(u['id'],language,boundary)
    row={'id':u['id'],'kind':u['kind'],'printed_pages':list(dict.fromkeys(u['printed_pages'])),'pdf_pages':list(dict.fromkeys(u['pdf_pages'])),'zh_runs':runs(zh,refs,'zh',boundaries),'de_runs':runs(de,refs,'de',boundaries)}
    if u['id']=='p429-1292':row['join_next_unit']='p430-1294'
    if u['id'] in ('p320-0874','p323-0882','p325-0888','p327-0901','p387-1138'):
        row['paragraph_boundaries_pending_review']=True
    groups.append(row)

physical={u['id'] for u in units if u['kind']=='note'}
represented={i for n in notes for i in n['physical_ids'] if i in physical}
assert represented==physical,(physical-represented,represented-physical)
projection={'status':'draft_structure_not_yet_accepted','canonical_sha256':digest(canonical),'front_matter_sha256':digest(ROOT/'front_matter.json'),'original_toc_sha256':digest(ROOT/'original_toc.json'),'audit_sha256':digest(ROOT/'source_note_anchor_audit.json'),'structure_sha256':digest(ROOT/'structure_evidence.json'),'groups':groups,'notes':notes,'warnings':['多数跨页精确页码及部分OCR合并自然段尚待还原；已恢复的中文页界是按意义就近对齐','p159嵌入注、p151—152续注及五组复合注已分拆为逻辑注，须输出回读','未生成、验收或发布成品']}
(ROOT/'reading_projection.json').write_text(json.dumps(projection,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':projection['status'],'groups':len(groups),'logical_notes':len(notes),'physical_notes':len(physical),'body_kinds':dict(Counter(x['kind'] for x in groups))},ensure_ascii=False))
