# 马克思主义视角下的哲学史

Alan Woods 著。基于用户提供的英文电子书和现成中文译稿逐段校对。

交付文件：中英对照 PDF、英文整理 PDF、独立中文 Markdown、术语表、校对记录和源码包。在线阅读版按原书章节组织，支持中英对照及原注跳转。

页边 PDF 数字是英文底本的 PDF 页序。所供电子书没有可沿用的独立印刷页码。原注中的引文页码则按其所引版本保留。原书没有索引，本版不虚构索引。

源码包以项目根目录为基准保留目录结构。`tools/render_philosophy.py --compile` 可重建两份 PDF；需要 Python、XeLaTeX、Times New Roman 和 SimSun。编译器路径可在脚本末尾按本机安装调整。网页数据由 `tools/export_philosophy_site.py` 从相同校对包生成。

`work/packets` 保存英文来源定位、原有中文、修订后的中文、具体改词和结构信息。`source_pages.json` 与 `supplied_translation_pages.json` 保存文本抽取及字体位置数据。校注不属于原书正文。

保留原书版权和出版信息。本中文稿为 AI 辅助校对工作译本，不是出版社授权的正式中文版本。
