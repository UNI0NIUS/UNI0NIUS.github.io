from philosophy_common import *
spec=[(rr(59,1,2),rr(21,15),'heading'),(rr(59,3),rr(21,16,18),'paragraph'),(rr(59,4),rr(21,19,24),'paragraph'),(rr(59,5)+rr(60,0),rr(21,25,28),'paragraph'),(rr(60,1),rr(21,29,31),'paragraph'),(rr(60,2),rr(21,32,34)+rr(22,0,1),'quote'),(rr(60,3)+rr(61,0),rr(22,2,5),'paragraph'),(rr(61,1),rr(22,6,10),'quote'),(rr(61,2),rr(22,11,15),'paragraph')]
fixes={105:[('甚至其是否曾存在都值得怀疑','甚至这些文字是否曾经存在都值得怀疑')],106:[('“暴君”','“僭主”'),('波利克拉特的庇护','波利克拉特斯的庇护'),('担任“智者”（philo-sophos）','作为一名“爱智慧者”（philo-sophos）活动')],108:[('以下几行诗句','以下文字')],109:[('无私的科学','不涉利害的科学研究')],110:[('克罗托内','克罗通')],111:[('对这些事物的正确理解，需要相当程度的智慧','能正确理解这些事物，便意味着具有相当的智慧')]}
rows=[]
for i,(refs,zrefs,kind) in enumerate(spec,104):
 old=extract(ZH,zrefs);zh=old
 for a,b in fixes.get(i,[]):
  assert a in zh,(i,a,zh)
  zh=zh.replace(a,b)
 row={'id':f'hp-ch01-{i:03}','kind':kind,'source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['PDF '+str(p) for p in dict.fromkeys(r[0] for r in refs)],'en':extract(EN,refs,True),'supplied_zh':old,'zh':zh,'status':'text_compared_layout_pending'}
 if zh!=old:row['revision_reason']='整节核对：明确失传文字的代词指向，补philo-sophos词义，修正lines误作诗句和disinterested误作无私，统一人名地名。'
 rows.append(row)
notes=[]
for n in [26,27]:
 refs=rr(72,n-10);zrefs=rr(27,n-22);old=extract(ZH,zrefs)
 notes.append({'id':f'hp-ch01-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['PDF 72'],'en':extract(EN,refs,True),'supplied_zh':old,'zh':old,'status':'text_compared_layout_pending'})
save('ch01i',rows,rr(59,1,5)+rr(60,0,3)+rr(61,0,2),notes,chapter='chapter1',reading_order=20)
(W/'checkpoint_ch01i.json').write_text(json.dumps({'next_source_pdf_page':62,'next_source_block':0,'next_supplied_pdf_page':22,'next_supplied_block':16,'next_unit':113,'next_chapter':'chapter1','full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
