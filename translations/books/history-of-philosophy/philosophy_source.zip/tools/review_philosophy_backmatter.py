from philosophy_packet import refs
from philosophy_common import *
units=[]
def add(kind,er,zr,zh=None,**meta):
 er=refs(EN,er);zr=refs(ZH,zr) if zr else []
 old=extract(ZH,zr) if zr else ''
 u={'id':f'hp-publisher-{len(units)+1:03}','kind':kind,'source_blocks':er,'supplied_translation_blocks':zr,'en':extract(EN,er,True),'supplied_zh':old,'zh':old if zh is None else zh,'printed_pages':['PDF '+str(p) for p in dict.fromkeys(r[0] for r in er)],'status':'text_compared_layout_pending'}
 u.update(meta);units.append(u);return u
add('heading','388:0-388:1','154:4')
add('paragraph','388:2','154:5-154:7')
u=add('list','388:3-389:6','154:8-156:8')
starts=['Anti-Dühring,','Bolshevism:','Chartist Revolution,','China: From','The Civil War in France,','The Class Struggles','The Classics of Marxism:','Dialectics of Nature,','The Eighteenth Brumaire','The First Five Years','The First World War:','Germany: From','Germany 1918-1933:','History of British','The History of Philosophy,','The History of the Russian Revolution:','The History of the Russian Revolution to','The Ideas of Karl Marx,','Imperialism:','In Defence of Marxism,','In the Cause of Labour,','Lenin and Trotsky:','Lenin, Trotsky and the Theory','Marxism and Anarchism,','Marxism and the USA,','Materialism and Empirio-criticism,','My Life,','Not Guilty,','The Origin of the Family,','The Permanent Revolution and Results','Permanent Revolution in Latin America,','Reason in Revolt,','Reformism or Revolution,','Revolution and Counter-Revolution in Spain,','The Revolution Betrayed,','The Revolutionary Philosophy of Marxism,','Russia: From','Spain’s Revolution Against Franco,','Stalin,','The State and Revolution,','Ted Grant:','Ted Grant Writings:','Thawra hatta’l nasr!','What Is Marxism?,','What Is to Be Done?,']
pos=[u['en'].index(s) for s in starts]+[len(u['en'])]
assert pos==sorted(pos)
u['items_en']=[u['en'][a:b].strip() for a,b in zip(pos,pos[1:])]
u['items_zh']=[extract(ZH,[r]) for r in u['supplied_translation_blocks']]
assert len(u['items_en'])==len(u['items_zh'])==45
u['items_zh']=[s.replace('《不断革命与结果与前景》','《不断革命与〈结果与前景〉》') for s in u['items_zh']]
u['zh']='\n'.join(u['items_zh'])
add('paragraph','389:7',None,'如需订购上述图书或了解韦尔雷德出版社的更多信息，请访问 wellredbooks.net，发送电子邮件至 books@wellredbooks.net，或致函：Wellred Books, PO Box 50525, London E14 6WG, United Kingdom。',editor_note='本段为原书出版时的订购信息，依底本保留。')
save('publisher',units,refs(EN,'388:0-389:7'),chapter='publisher',reading_order=140)
