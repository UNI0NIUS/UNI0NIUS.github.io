"""Source-preserving review helpers for Alan Woods's supplied ebook."""
from pathlib import Path
import json,re,unicodedata
from materialism_common import normzh
R=Path(__file__).resolve().parents[1];W=R/'The History of Philosophy A Marxist Perspective/work'
EN=json.loads((W/'source_pages.json').read_text('utf8'));ZH=json.loads((W/'supplied_translation_pages.json').read_text('utf8'))
def rr(p,a,z=None):return [[p,b] for b in range(a,(a if z is None else z)+1)]
def lines(pages,refs):
    for r in refs:
        p,b=r[:2];block=next(x for x in pages[p-1]['blocks'] if x['block']==b)
        for j in range(r[2] if len(r)>2 else 0,r[3] if len(r)>2 else len(block['lines'])):yield p,b,j,block['lines'][j]
def extract(pages,refs,english=False):
    s='\n'.join(''.join(x['text'] for x in l['spans']) for p,b,j,l in lines(pages,refs))
    if english:
        for a,b in [('ﬁ','fi'),('ﬀ','ff'),('ﬂ','fl'),('ﬃ','ffi'),('ﬄ','ffl')]:s=s.replace(a,b)
        s=re.sub(r'-\n','-',s);s=re.sub(r'\s+',' ',s).strip()
        return re.sub(r'\[(\d+)\]',r'[[\1]]',s)
    s=normzh(s)
    return re.sub(r'\[(\d+)\]',r'[[\1]]',s.replace('\n','').strip())
def save(name,units,expected,notes=None,chapter='introduction',reading_order=10):
    notes=notes or []
    used=[(p,b,j) for u in units for p,b,j,l in lines(EN,u['source_blocks'])]
    want={(p,b,j) for p,b,j,l in lines(EN,expected)}
    assert set(used)==want and len(used)==len(set(used))
    for u in units:assert re.findall(r'\[\[\d+\]\]',u['en'])==re.findall(r'\[\[\d+\]\]',u['zh']),u['id']
    calls={int(n) for u in units for n in re.findall(r'\[\[(\d+)\]\]',u['en'])}
    assert calls=={n['note_number'] for n in notes},(calls,notes)
    assert len(notes)==len(calls)
    for n in notes:
        assert n['en']==extract(EN,n['source_blocks'],True)
        assert n['en'].startswith('[['+str(n['note_number'])+']]')
        assert n['zh'].startswith('[['+str(n['note_number'])+']]')
    (W/'packets').mkdir(exist_ok=True)
    (W/'packets'/f'{name}.json').write_text(json.dumps({'packet':name,'chapter':chapter,'reading_order':reading_order,'units':units,'notes':notes,'full_book_complete':False,'layout_review':'pending'},ensure_ascii=False,indent=2),'utf8')
    audit={'packet':name,'units':len(units),'source_lines':len(used),'source_line_coverage':'pass','note_alignment':'pass','layout':'pending'}
    (W/f'{name}_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),'utf8');print(json.dumps(audit))
