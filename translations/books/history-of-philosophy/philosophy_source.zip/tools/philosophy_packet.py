"""Compact, reviewed-data authoring; never substitutes for bilingual reading.

Each unit: [kind, English inclusive range, Chinese inclusive range, optional edits,
optional metadata]. Range syntax: '93:1-94:2', or explicit reference arrays.
Edits are exact [old,new] pairs. Metadata may contain zh (full reviewed rewrite),
editor_note, supplied_excerpt, or structured layout fields. All source stays saved.
"""
from philosophy_common import *
from philosophy_review_bundle import span

def refs(pages,value):
 if isinstance(value,list):return value
 bounds=value.split('-');return span(pages,bounds[0],bounds[-1])

def build(name,chapter,start,spec,expected,note_spec,next_point):
 def row(kind,er,zr,edits=(),meta=None,id=None):
  er=refs(EN,er);zr=refs(ZH,zr);meta=dict(meta or {})
  old=extract(ZH,zr)
  if 'supplied_excerpt' in meta:
   excerpt=meta.pop('supplied_excerpt');assert excerpt in old
   old=excerpt
  zh=meta.pop('zh',old)
  for a,b in edits:
   assert a in zh,(id,a)
   zh=zh.replace(a,b)
  result={'id':id,'kind':kind,'source_blocks':er,'supplied_translation_blocks':zr,
   'printed_pages':['PDF '+str(p) for p in dict.fromkeys(r[0] for r in er)],
   'en':extract(EN,er,True),'supplied_zh':old,'zh':zh,'status':'text_compared_layout_pending'}
  if edits:result['revisions']=[{'from':a,'to':b} for a,b in edits]
  result.update(meta);return result
 units=[row(*s,id=f'hp-ch{chapter:02}-{i:03}') for i,s in enumerate(spec,start)]
 notes=[row('note',*s[1:],id=f'hp-ch{chapter:02}-note-{s[0]}')|{'note_number':s[0]} for s in note_spec]
 # Check exact English source preservation before writing canonical output.
 for u in units+notes:assert u['en']==extract(EN,u['source_blocks'],True)
 save(name,units,refs(EN,expected),notes,chapter=f'chapter{chapter}',reading_order=(chapter+1)*10)
 ep,eb,zp,zb=next_point
 checkpoint={'next_source_pdf_page':ep,'next_source_block':eb,'next_supplied_pdf_page':zp,
 'next_supplied_block':zb,'next_unit':start+len(units),'next_chapter':f'chapter{chapter}','full_book_complete':False}
 (W/f'checkpoint_{name}.json').write_text(json.dumps(checkpoint,ensure_ascii=False,indent=2),'utf8')
 (W/'current_checkpoint.json').write_text(json.dumps(checkpoint|{'packet':name},ensure_ascii=False,indent=2),'utf8')
