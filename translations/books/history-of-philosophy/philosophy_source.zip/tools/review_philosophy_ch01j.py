from philosophy_common import *
spec=[(rr(62,0,1),rr(22,16),'heading'),(rr(62,2),rr(22,17,20),'paragraph'),(rr(62,3),rr(22,21,22),'paragraph'),(rr(62,4),rr(22,23,25),'quote'),(rr(62,5)+rr(63,0),rr(22,26,30),'paragraph'),(rr(63,1),rr(22,31,34)+rr(23,0,1),'paragraph'),(rr(63,2),rr(23,2,5),'paragraph'),(rr(63,3),rr(23,6),'paragraph'),(rr(64,0),rr(23,7,10),'quote'),(rr(64,1),rr(23,11,14),'paragraph'),(rr(64,2),rr(23,15,19),'paragraph')]
fixes={116:[('物质的一般感性具体性','一般物质的感性具体形态'),('质性方面','质的方面'),('量性尺度与关系','量的尺度与关系')],118:[('等比数列','调和数列')],121:[('宇宙的“质”与“形”','宇宙的质料与形式')],123:[('最激烈的党派之争','极其强烈的派别立场')]}
rows=[]
for i,(refs,zrefs,kind) in enumerate(spec,113):
 old=extract(ZH,zrefs);zh=old
 for a,b in fixes.get(i,[]):
  assert a in zh,(i,a,zh)
  zh=zh.replace(a,b)
 row={'id':f'hp-ch01-{i:03}','kind':kind,'source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['PDF '+str(p) for p in dict.fromkeys(r[0] for r in refs)],'en':extract(EN,refs,True),'supplied_zh':old,'zh':zh,'status':'text_compared_layout_pending'}
 if zh!=old:row['revision_reason']='整节对照：harmonic progression为调和数列而非等比数列；matter/form明确为质料与形式，避免与质和量混淆；修正派别立场。'
 rows.append(row)
notes=[]
for n in [28,29,30]:
 refs=rr(72,n-10);zrefs=rr(27,n-22);old=extract(ZH,zrefs)
 notes.append({'id':f'hp-ch01-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['PDF 72'],'en':extract(EN,refs,True),'supplied_zh':old,'zh':old,'status':'text_compared_layout_pending'})
save('ch01j',rows,rr(62,0,5)+rr(63,0,3)+rr(64,0,2),notes,chapter='chapter1',reading_order=20)
(W/'checkpoint_ch01j.json').write_text(json.dumps({'next_source_pdf_page':65,'next_source_block':0,'next_supplied_pdf_page':23,'next_supplied_block':20,'next_unit':124,'next_chapter':'chapter1','full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
