"""Prepare reader data; publication registration is a separate final step."""
from philosophy_site_inline import *
import shutil
BOOK='history-of-philosophy';BASE='translations/books/'+BOOK+'/'
D=R/'github-sync'/BASE;D.mkdir(parents=True,exist_ok=True)
by={}
for p in sorted((json.loads(f.read_text('utf8')) for f in (W/'packets').glob('*.json')),key=lambda p:(p['reading_order'],p['packet'])):
 g=by.setdefault(p['chapter'],{'units':[],'notes':[]});g['units']+=p['units'];g['notes']+=p['notes']
def structured(u,lang,ch):
 if u.get('verse_lines_'+lang):
  parts=u['verse_lines_'+lang][:]
  if u.get('attribution_'+lang):parts.append(u['attribution_'+lang])
 elif u.get('items_'+lang):
  parts=u['items_'+lang][:]
  if re.match(r'^1[.)]',u['en']):parts=[str(i)+'. '+s for i,s in enumerate(parts,1)]
  elif not u.get('toc_targets'):parts=['• '+s for s in parts]
 else:
  s=u[lang];bounds=[s.index(t) for t in u.get('paragraph_starts_'+lang,[])];bounds=sorted(set([0]+bounds+[len(s)]));parts=[s[a:b].strip() for a,b in zip(bounds,bounds[1:]) if s[a:b].strip()]
  if not bounds or len(parts)==1:return inline(u,lang,ch)
 out=[]
 for i,s in enumerate(parts):
  if i:out.append({'type':'break'})
  tokens=inline(dict(u,**{lang:s}),lang,ch)
  if u.get('toc_targets'):
   target=u['toc_targets'][i];tokens=[{'type':'link','url':f'translations/book.html?id={BOOK}&chapter={target}#{by[target]["units"][0]["id"]}','children':tokens}]
  out+=tokens
 return out
desc=[];rowcount=0;notecount=0
for ch,g in by.items():
 first=g['units'][0];title,eng=(('封面、出版信息与原书目录','Cover, Publication Details and Original Contents') if ch=='frontmatter' else (first['zh'],first['en']))
 desc.append({'id':ch,'title':title,'originalTitle':eng,'dataUrl':BASE+ch+'.json'})
 rows=[]
 for i,u in enumerate(g['units']):
  row={'id':u['id'],'type':('heading' if i==0 and u['kind'] in ['heading','chapter'] else {'heading':'subheading','chapter':'heading','quote':'quote','figure':'figure'}.get(u['kind'],'paragraph')),'page':'–'.join(dict.fromkeys(u['printed_pages']))}
  for lang in ['zh','en']:row[lang]=structured(u,lang,ch)
  if u.get('image'):row['src']=BASE+u['image']
  if u.get('editor_note'):row['review']=u['editor_note']
  rows.append(row)
 notes={}
 for n in g['notes']:
  nn=dict(n)
  for lang in ['zh','en']:nn[lang]=re.sub(r'^\[\[\d+\]\]\s*','',n[lang])
  notes[f'hp-{ch}-{n["note_number"]}']={lang:inline(nn,lang,ch) for lang in ['zh','en']}
  if n.get('editor_note'):notes[f'hp-{ch}-{n["note_number"]}']['review']=n['editor_note']
 for lang in ['zh','en']:
  calls={x for row in rows for x in noteids(row[lang])};assert calls==set(notes),(ch,lang,calls^set(notes))
 (D/(ch+'.json')).write_text(json.dumps({'id':ch,'title':title,'originalTitle':eng,'sourceLanguage':'en','sourceLanguageLabel':'English','body':rows,'notes':notes},ensure_ascii=False,indent=2)+'\n','utf8')
 rowcount+=len(rows);notecount+=len(notes)
shutil.copytree(W.parent/'output/assets',D/'assets',dirs_exist_ok=True)
meta={'id':BOOK,'title':'马克思主义视角下的哲学史','originalTitle':'The History of Philosophy: A Marxist Perspective','author':'Alan Woods','translator':'Xiaoyang Hao (AI-assisted working translation)','languagePair':'English / 中文','language':'zh-CN','bilingual':True,'example':False,'description':'从古希腊到马克思的哲学史。含导论、十一章、316条原注、参考文献及完整前后置材料。','editionNotice':'全书中文校对工作译本。PDF数字为所供英文电子书的页序；原注随对应段落显示，校注明确区分原书疑点。','chapters':desc,'downloads':[{'label':label,'url':BASE+name} for label,name in [('中英对照 PDF','philosophy_bilingual.pdf'),('英文 PDF','philosophy_en.pdf'),('中文 Markdown','philosophy_zh.md'),('术语表','glossary.md'),('校对记录','review.md'),('源码包 ZIP','philosophy_source.zip')]]}
(W/'site_metadata_candidate.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),'utf8')
(W/'site_export_check.json').write_text(json.dumps({'rows':rowcount,'notes':notecount,'sections':len(desc),'note_reference_sets':'pass','publication':'not registered or published','browser_review':'pending'},indent=2),'utf8')
print(rowcount,'rows',notecount,'notes',len(desc),'sections')
