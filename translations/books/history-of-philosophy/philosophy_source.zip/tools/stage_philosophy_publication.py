"""Stage this verified edition in the existing site; does not commit or push."""
from philosophy_common import *
import shutil,hashlib
O=R/'The History of Philosophy A Marxist Perspective/output';S=R/'github-sync';D=S/'translations/books/history-of-philosophy'
book=json.loads((W/'site_metadata_candidate.json').read_text('utf8'))
manifest=json.loads((O/'manifest.json').read_text('utf8'))
for entry in book['downloads']:
    name=entry['url'].rsplit('/',1)[-1];src=O/name
    assert hashlib.sha256(src.read_bytes()).hexdigest()==manifest[name]['sha256']
    entry.update(manifest[name]);shutil.copy2(src,D/name)
(D/'book-metadata.json').write_text(json.dumps(book,ensure_ascii=False,indent=2)+'\n','utf8')
cat=S/'translations-data.js';prefix='window.TRANSLATIONS = '
data=json.loads(cat.read_text('utf8')[len(prefix):].strip().rstrip(';'))
old=next((b for b in data['books'] if b['id']==book['id']),None)
if old:data['books'][data['books'].index(old)]=book
else:data['books'].append(book)
cat.write_text(prefix+json.dumps(data,ensure_ascii=False,indent=2)+';\n','utf8')
for page in [S/'index.html',S/'translations/index.html',S/'translations/book.html']:
    text=page.read_text('utf8')
    for asset in ['translations-data.js','bilingual-reader.js','translations.css']:
        digest=hashlib.sha256((S/asset).read_bytes()).hexdigest()[:12]
        text=re.sub(re.escape(asset)+r'(?:\?v=[^"\s]+)?',asset+'?v='+digest,text)
    page.write_text(text,'utf8')
print('Staged 6 downloads and book metadata; not committed or published.')
