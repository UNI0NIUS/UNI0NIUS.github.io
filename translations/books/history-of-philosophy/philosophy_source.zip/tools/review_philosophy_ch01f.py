from philosophy_common import *
spec=[
 (rr(49,0),rr(17,21,25),'paragraph'),
 (rr(49,1),rr(17,26,29),'paragraph'),
 (rr(49,2)+rr(50,0),rr(17,30,35),'quote'),
 (rr(50,1),rr(18,0),'heading'),
 (rr(50,2),rr(18,1,3),'paragraph'),
 (rr(50,3),rr(18,4,6),'paragraph'),
 (rr(50,4),rr(18,7,9),'quote'),
 (rr(50,5)+rr(51,0),rr(18,10,14),'paragraph'),
 (rr(51,1),rr(18,15,20),'paragraph'),
 (rr(51,2),rr(18,21,25),'paragraph'),
 (rr(52,0),rr(18,26),'heading'),
 (rr(52,1),rr(18,27,31),'paragraph'),
]
fixes={
 73:[('伊奥尼亚希腊人','爱奥尼亚希腊人')],
 74:[('太阳蒸发水分','太阳把水吸上去')],
 76:[('自然、恒星、地球球体','自然、恒星、地球球体')],
 78:[('或任何类似的事物。它是','或任何类似的事物。……它是')],
 79:[('地球自由旋转','地球自由悬浮')],
 80:[('但我们无法确切','但我们没有得到明确的记载')],
 83:[('而“鼎盛”之时恰逢泰勒斯去世','而他自己的“鼎盛”之时恰逢泰勒斯去世')],
}
rows=[]
for i,(refs,zrefs,kind) in enumerate(spec,72):
 old=extract(ZH,zrefs);zh=old
 for a,b in fixes.get(i,[]):
  assert a in zh,(i,a,zh)
  zh=zh.replace(a,b)
 row={'id':f'hp-ch01-{i:03}','kind':kind,'source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['PDF '+str(p) for p in dict.fromkeys(r[0] for r in refs)],'en':extract(EN,refs,True),'supplied_zh':old,'zh':zh,'status':'text_compared_layout_pending'}
 if zh!=old:row['revision_reason']='逐段核对：恢复引文省略号与太阳吸水的原有表述，修正悬浮误作旋转、缺失的句尾及人称指向；统一爱奥尼亚译名。'
 if i==76:row['editor_note']='“来自萨摩斯岛”为本书原文的表述，译文照录。'
 if i==79:row['editor_note']='原文称希波利托斯为“另一位同时代人”，并作出本段天文学归属判断；这些均按底本保留。swings free译为自由悬浮，不据旧译增添旋转之意。'
 rows.append(row)
notes=[]
for n in range(18,21):
 refs=rr(72,n-10);zrefs=rr(26,n);old=extract(ZH,zrefs)
 notes.append({'id':f'hp-ch01-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['PDF 72'],'en':extract(EN,refs,True),'supplied_zh':old,'zh':old,'editor_note':'页码按英文原书所引版本保留。','status':'text_compared_layout_pending'})
save('ch01f',rows,rr(49,0,2)+rr(50,0,5)+rr(51,0,2)+rr(52,0,1),notes,chapter='chapter1',reading_order=20)
(W/'checkpoint_ch01f.json').write_text(json.dumps({'next_source_pdf_page':52,'next_source_block':2,'next_supplied_pdf_page':18,'next_supplied_block':32,'next_unit':84,'next_chapter':'chapter1','full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
