from philosophy_common import *
spec=[(rr(78,3)+rr(79,0),rr(30,8,13),'paragraph'),(rr(79,1),rr(30,14,16),'paragraph'),(rr(79,2)+rr(80,0),rr(30,17,31),'quote'),(rr(80,1),rr(30,32),'heading'),(rr(80,2)+rr(81,0),rr(30,33,34)+rr(31,0,5),'paragraph'),(rr(81,1),rr(31,6,11),'paragraph'),(rr(81,2)+rr(82,0),rr(31,12,16),'paragraph'),(rr(82,1),rr(31,17,19),'paragraph'),(rr(82,2),rr(31,20,22),'quote'),(rr(82,3),rr(31,23,26),'paragraph')]
fixes={30:[('目光短浅、只顾眼前利益','目光短浅')],31:[('而是从构成原子的基本单元中，创造出了更小的新单位——电子和质子','而是提出了构成原子的新的、更小的单位——电子和质子')],33:[('反动','反拨')],34:[('色诺芬尼','克塞诺芬尼'),('将除数以外的所有确定性属性从物质中抽象出来','从物质中抽去除数以外的一切确定属性'),('（即“成为”）','（即“生成”）')]}
rows=[]
for i,(refs,zrefs,kind) in enumerate(spec,29):
 old=extract(ZH,zrefs);zh=old
 for a,b in fixes.get(i,[]):
  assert a in zh,(i,a,zh)
  zh=zh.replace(a,b)
 row={'id':f'hp-ch02-{i:03}','kind':kind,'source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['PDF '+str(p) for p in dict.fromkeys(r[0] for r in refs)],'en':extract(EN,refs,True),'supplied_zh':old,'zh':zh,'status':'text_compared_layout_pending'}
 if zh!=old:row['revision_reason']='核对整段，修正抽去属性误作抽出属性、理论单位的提出误作创造实物，去除眼前利益的增译并统一人名与生成术语。'
 if i==31:
  row['editor_note']='本段为原书转引罗素的历史文字；质子与电子、行星起源及太阳寿命的表述均照底本保留，不作为当前科学结论。'
  row['paragraph_starts_en']=['Science, like philosophy','Nothing daunted','Passing from the small']
  row['paragraph_starts_zh']=['科学与哲学一样','物理学家们并未因此气馁','从微观转向宏观']
 if i==34:row['editor_note']='英文底本人名拼作Xenophones，译文沿用同书前文的克塞诺芬尼；芝诺出生年份照原书保留。'
 rows.append(row)
notes=[]
for n in [13,14]:
 refs=rr(119,n-13);zrefs=rr(45,n-1);old=extract(ZH,zrefs)
 notes.append({'id':f'hp-ch02-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['PDF 119'],'en':extract(EN,refs,True),'supplied_zh':old,'zh':old,'status':'text_compared_layout_pending'})
save('ch02c',rows,rr(78,3)+rr(79,0,2)+rr(80,0,2)+rr(81,0,2)+rr(82,0,3),notes,chapter='chapter2',reading_order=30)
(W/'checkpoint_ch02c.json').write_text(json.dumps({'next_source_pdf_page':83,'next_source_block':0,'next_supplied_pdf_page':31,'next_supplied_block':27,'next_unit':39,'next_chapter':'chapter2','full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
