from philosophy_common import *
spec=[(rr(55,0,1),rr(19,32),'heading'),(rr(55,2),rr(19,33,34)+rr(20,0,2),'paragraph'),(rr(55,3),rr(20,3,7),'paragraph'),(rr(55,4)+rr(56,0),rr(20,8,12),'paragraph'),(rr(56,1),rr(20,13,17),'paragraph'),(rr(56,2),rr(20,18,20),'quote'),(rr(56,3)+rr(57,0),rr(20,21,27),'paragraph'),(rr(57,1),rr(20,28,35),'paragraph'),(rr(57,2)+rr(58,0),rr(20,36)+rr(21,0,2),'paragraph'),(rr(58,1),rr(21,3,6),'paragraph'),(rr(58,2),rr(21,7,8),'quote'),(rr(58,3)+rr(59,0),rr(21,9,14),'paragraph')]
fixes={93:[('正如社会中常有的那样','正如社会中一贯如此')],98:[('他一无所有','他什么也不是')],99:[('男女都有两种选择','人们都有两种选择'),('接受无路可走的事实','认定无路可走'),('导致了一种内向和悲观的情绪','导致了某种向内退缩与悲观的倾向')],101:[('“暴君”','“僭主”')],102:[('甚至将流经城址的河流改道','将当地河流改道，使其流经城址')],103:[('神秘主义和智性主义性质','秘传性和智性特征')]}
rows=[]
for i,(refs,zrefs,kind) in enumerate(spec,92):
 old=extract(ZH,zrefs);zh=old
 for a,b in fixes.get(i,[]):
  assert a in zh,(i,a,zh)
  zh=zh.replace(a,b)
 row={'id':f'hp-ch01-{i:03}','kind':kind,'source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['PDF '+str(p) for p in dict.fromkeys(r[0] for r in refs)],'en':extract(EN,refs,True),'supplied_zh':old,'zh':zh,'status':'text_compared_layout_pending'}
 if zh!=old:row['revision_reason']='整节对照，修正奴隶被否定人格误作无财产、主观认定误作客观事实，以及河流改道方向；统一僭主术语。'
 rows.append(row)
notes=[]
for n in [24,25]:
 refs=rr(72,n-10);zrefs=rr(27,n-22);old=extract(ZH,zrefs)
 notes.append({'id':f'hp-ch01-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['PDF 72'],'en':extract(EN,refs,True),'supplied_zh':old,'zh':old,'status':'text_compared_layout_pending'})
save('ch01h',rows,rr(55,0,4)+rr(56,0,3)+rr(57,0,2)+rr(58,0,3)+rr(59,0),notes,chapter='chapter1',reading_order=20)
(W/'checkpoint_ch01h.json').write_text(json.dumps({'next_source_pdf_page':59,'next_source_block':1,'next_supplied_pdf_page':21,'next_supplied_block':15,'next_unit':104,'next_chapter':'chapter1','full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
