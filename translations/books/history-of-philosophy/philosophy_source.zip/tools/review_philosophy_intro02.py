from philosophy_common import *
spec=[
 (rr(10,0),rr(3,9,12),'paragraph'),
 (rr(10,1),rr(3,13,16),'paragraph'),
 (rr(10,2),rr(3,17,19),'paragraph'),
 (rr(11,0,1),rr(3,20),'heading'),
 (rr(11,2),rr(3,21,23),'paragraph'),
 (rr(11,3),rr(3,24,28),'paragraph'),
 (rr(11,4),rr(3,29,31),'paragraph'),
 (rr(11,5)+rr(12,0),rr(3,32,33)+rr(4,0),'paragraph'),
 (rr(12,1),rr(4,1,3),'paragraph'),
 (rr(12,2),rr(4,4,7),'quote'),
 (rr(12,3),rr(4,8),'paragraph'),
 (rr(12,4)+rr(13,0),rr(4,9,11),'quote'),
 (rr(13,1),rr(4,12,14),'paragraph'),
 (rr(13,2,4),rr(4,15),'heading'),
 (rr(13,5),rr(4,16,20),'paragraph'),
]
fixes={
 26:[('太多自诩为马克思主义者的人，却满足于重复几个基本观点，却从未思考过','太多自认为是马克思主义者的人满足于重复几个基本观点，却从未思考过')],
 27:[('他们可以预设当时的受过教育的读者至少具备哲学史的基本知识','他们可以预设，至少当时受过教育的读者具备哲学史的基本知识')],
 30:[('《简明逻辑》','《小逻辑》'),('这部杰作的副本','这部杰作')],
 32:[('贯穿他所有著作的辩证法','贯穿他所有著作的辩证方法')],
 34:[('虚假的存在［形式］','虚假的定在［形式］')],
 37:[('列宁曾对罗莎·卢森堡所写的话','列宁曾论及罗莎·卢森堡时写下的话')],
 39:[('通常意义上的哲学史','经验性意义上的哲学史'),('严肃的公共参考图书馆','正规的公共参考图书馆'),('这是一部本质上的哲学史','这是一部把握哲学史本质的著作')],
}
rows=[]
for i,(refs,zrefs,kind) in enumerate(spec,25):
 old=extract(ZH,zrefs);zh=old
 for a,b in fixes.get(i,[]):
  assert a in zh,(i,a,zh)
  zh=zh.replace(a,b)
 row={'id':f'hp-intro-{i:03}','kind':kind,'source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['PDF '+str(p) for p in dict.fromkeys(r[0] for r in refs)],'en':extract(EN,refs,True),'supplied_zh':old,'zh':zh,'status':'text_compared_layout_pending'}
 if zh!=old:row['revision_reason']='逐段核对英文，修正限定范围、哲学术语、书名及引语所指；保持作者原有论断。'
 rows.append(row)
notes=[]
for n,refs,zrefs in [(1,rr(26,5),rr(9,11)),(2,rr(26,6),rr(9,12,13)),(3,rr(26,7),rr(9,14))]:
 old=extract(ZH,zrefs)
 notes.append({'id':f'hp-intro-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['PDF 26'],'en':extract(EN,refs,True),'supplied_zh':old,'zh':old,'editor_note':'卷页信息按英文原书所引版本保留，不能据此定位中文版本。','status':'text_compared_layout_pending'})
save('intro02',rows,rr(10,0,2)+rr(11,0,5)+rr(12,0,4)+rr(13,0,5),notes)
(W/'checkpoint_intro02.json').write_text(json.dumps({'next_source_pdf_page':13,'next_source_block':6,'next_supplied_pdf_page':4,'next_supplied_block':21,'next_unit':40,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
