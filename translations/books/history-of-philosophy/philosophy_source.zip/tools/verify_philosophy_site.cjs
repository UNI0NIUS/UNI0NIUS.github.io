const fs=require('fs'),path=require('path'),http=require('http'),assert=require('assert/strict');
const {chromium}=require('C:/Users/Union/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const root=path.resolve(__dirname,'../github-sync'),work=path.resolve(__dirname,'../The History of Philosophy A Marxist Perspective/work');
const book=JSON.parse(fs.readFileSync(path.join(work,'site_metadata_candidate.json')));
const server=http.createServer((req,res)=>{
 const p=path.resolve(root,'.'+decodeURIComponent(new URL(req.url,'http://localhost').pathname));
 if(!p.startsWith(root+path.sep)){res.writeHead(403).end();return;}
 res.setHeader('Content-Type',({'.html':'text/html','.js':'text/javascript','.css':'text/css','.json':'application/json','.svg':'image/svg+xml','.png':'image/png','.jpeg':'image/jpeg','.woff2':'font/woff2'})[path.extname(p)]||'application/octet-stream');
 fs.readFile(p,(e,d)=>{if(e){res.writeHead(404).end();return;}if(p.endsWith('translations-data.js'))d=Buffer.from(d.toString()+'\nwindow.TRANSLATIONS.books.push('+JSON.stringify(book)+');');res.end(d);});
});
(async()=>{
 const live=!!process.env.SITE_BASE;
 if(!live)await new Promise(r=>server.listen(0,'127.0.0.1',r));const base=process.env.SITE_BASE||'http://127.0.0.1:'+server.address().port;
 const browser=await chromium.launch({headless:true,channel:'msedge',...(live?{proxy:{server:'http://127.0.0.1:7897'}}:{})});
 const report={views:[],errors:[]};
 try{
  const page=await browser.newPage();page.on('pageerror',e=>report.errors.push(e.message));
  const samples=process.argv.includes('--samples');
  for(const width of [1440,390])for(const ch of book.chapters.filter(c=>!samples||['chapter2','chapter7','chapter11','frontmatter'].includes(c.id)))for(const view of (samples?['parallel']:['parallel','zh','en'])){
   await page.setViewportSize({width,height:1000});await page.goto(`${base}/translations/book.html?id=${book.id}&chapter=${ch.id}&view=${view}`);await page.waitForSelector('.parallel-body');
   const data=JSON.parse(fs.readFileSync(path.join(root,ch.dataUrl)));
   const result=await page.evaluate(()=>({rows:document.querySelectorAll('.parallel-row[id]').length,mathErrors:[...document.querySelectorAll('.math-error')].map(n=>n.textContent),missing:[...document.querySelectorAll('.note-ref a,.note-backlink')].filter(a=>!document.getElementById(a.hash.slice(1))).map(a=>a.href),overflow:document.documentElement.scrollWidth>innerWidth,math:document.querySelectorAll('.katex').length,ids:[...document.querySelectorAll('[id]')].map(n=>n.id)}));
   assert.equal(result.rows,data.body.length);assert.deepEqual(result.mathErrors,[]);assert.deepEqual(result.missing,[]);assert.equal(result.ids.length,new Set(result.ids).size);assert(!result.overflow,`${ch.id} ${view} ${width} horizontal overflow`);
   for(const img of await page.locator('.reader-cell img').all()){await img.scrollIntoViewIfNeeded();await img.evaluate(n=>n.decode());}
   report.views.push({section:ch.id,view,width,rows:result.rows,math:result.math});
   if(view==='parallel'&&['chapter2','chapter11','frontmatter'].includes(ch.id)){await page.evaluate(()=>scrollTo(0,0));await page.screenshot({path:path.join(work,`site-${ch.id}-${width}.png`)});}
   if(samples)for(const [name,selector] of [['formula','.source-math'],['table','.source-table-wrap'],['code','.reader-cell pre']]){
    const target=page.locator(selector).first();if(await target.count()){await target.scrollIntoViewIfNeeded();await page.screenshot({path:path.join(work,`sample-${ch.id}-${name}-${width}.png`)});}
   }
  }
  assert.deepEqual(report.errors,[]);report.status='pass';
 }finally{report.live=live;fs.writeFileSync(path.join(work,live?'site_live_browser_audit.json':process.argv.includes('--samples')?'site_sample_audit.json':'site_browser_audit.json'),JSON.stringify(report,null,2));await browser.close();if(server.listening)server.close();}
 console.log('Passed',report.views.length,'desktop/mobile/language views');
})().catch(e=>{console.error(e);server.close();process.exitCode=1;});
