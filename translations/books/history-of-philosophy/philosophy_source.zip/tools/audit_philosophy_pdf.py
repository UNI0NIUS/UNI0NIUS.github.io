from philosophy_common import *
import sys,unicodedata
sys.path.insert(0,str(R/'tools/python_libs'))
import pymupdf
O=W.parent/'output';V=W/'render_review';V.mkdir(exist_ok=True)
def norm(s):return ''.join(c.lower() for c in unicodedata.normalize('NFKC',s) if c.isalnum())
ps=[json.loads(p.read_text('utf8')) for p in sorted((W/'packets').glob('*.json'))]
units=[u for p in ps for u in p['units']+p['notes']]
report={}
for kind,lang in [('en','en'),('bilingual','zh')]:
 d=pymupdf.open(O/f'philosophy_{kind}.pdf');texts=[];badlinks=[];outside=[]
 for i,p in enumerate(d):
  texts.append(''.join(s['text'] for b in p.get_text('dict')['blocks'] if 'lines' in b for l in b['lines'] for s in l['spans'] if s['size']>=8 and s['bbox'][1]>50 and s['bbox'][3]<790 and (lang=='en' or s['bbox'][0]<295)))
  for l in p.get_links():
   if l['kind']==1 and not 0<=l['page']<len(d):badlinks.append(i+1)
  for b in p.get_text('blocks'):
   if b[4].strip() and (b[0]<0 or b[1]<0 or b[2]>p.rect.width+1 or b[3]>p.rect.height+1):outside.append(i+1)
 joined=norm(''.join(texts));miss=[];count=0
 for u in units:
  if u['kind']=='figure':continue
  # Chinese column extraction interleaves English at paragraph boundaries;
  # compare short overlapping samples within each unit, not across units.
  s=norm(re.sub(r'\[\[\d+\]\]','',u[lang]));size=45 if lang=='zh' else 65
  samples=[s[i:i+size] for i in range(0,len(s),size) if len(s[i:i+size])>=15];count+=len(samples)
  bad=[x for x in samples if x not in joined]
  if bad:miss.append({'id':u['id'],'samples':bad})
 report[kind]={'pages':len(d),'bookmarks':len(d.get_toc()),'links':sum(len(p.get_links()) for p in d),'invalid_links':badlinks,'outside_page':outside,'text_samples':count,'sample_misses':miss}
 # Render pages containing structured poems, numbered lists, long quotations,
 # and chapter openings for directed visual review.
 targets=set()
 for u in units:
  if 'verse_lines_en' in u or u['id'] in ['hp-ch02-018','hp-ch03-008','hp-ch11-066']:
   needle=norm(u.get('verse_lines_en',[u['en']])[0])[:45]
   for i,p in enumerate(d):
    if needle in norm(p.get_text()):targets.add(i)
 for level,title,page in d.get_toc():
  if level==1:targets.add(page-1)
 for i in sorted(targets):d[i].get_pixmap(matrix=pymupdf.Matrix(1,1)).save(str(V/f'{kind}-{i+1}.png'))
 report[kind]['rendered_review_pages']=[i+1 for i in sorted(targets)]
 print(kind,'pages',len(d),'samples',count,'flagged units',len(miss),'review pages',report[kind]['rendered_review_pages'])
(W/'pdf_content_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8')
