from philosophy_common import *
spec=[(rr(28,0),rr(9,19),'chapter'),(rr(28,1),rr(9,20,23),'paragraph'),(rr(28,2),rr(9,24,29),'paragraph'),(rr(28,3)+rr(29,0),rr(10,0,3),'paragraph'),(rr(29,1),rr(10,4,9),'paragraph'),(rr(29,2),rr(10,10,12),'paragraph'),(rr(29,3)+rr(30,0),rr(10,13,17),'paragraph'),(rr(30,1),rr(10,18,22),'paragraph'),(rr(30,2),rr(10,23,27),'paragraph')]
fixes={
 2:[('才能过好日常生活','才能处理日常生活事务')],
 3:[('伊拉克和阿富汗的自相残杀','伊拉克和阿富汗同胞相残的战争')],
 4:[('自然厌恶真空，据说','据说，自然厌恶真空'),('从报纸、电视、讲坛和教室中','从报纸、电视、布道坛和课堂上')],
 5:[('日常生存的琐碎问题','日常生活中眼前的问题')],
 9:[('从而掌握世界的主宰权','从而获得支配世界的力量'),('在现实意义上（而非法律意义上）','在实际意义上（而非法律形式的意义上）')],
}
rows=[]
for i,(refs,zrefs,kind) in enumerate(spec,1):
 old=extract(ZH,zrefs);zh=old
 for a,b in fixes.get(i,[]):
  assert a in zh,(i,a,zh)
  zh=zh.replace(a,b)
 row={'id':f'hp-ch01-{i:03}','kind':kind,'source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['PDF '+str(p) for p in dict.fromkeys(r[0] for r in refs)],'en':extract(EN,refs,True),'supplied_zh':old,'zh':zh,'status':'text_compared_layout_pending'}
 if zh!=old:row['revision_reason']='逐段核对：补明战争所指，修正布道坛、眼前问题及法律形式等词义，去除旧译增添的价值判断。'
 rows.append(row)
save('ch01a',rows,rr(28,0,3)+rr(29,0,3)+rr(30,0,2),chapter='chapter1',reading_order=20)
(W/'checkpoint_ch01a.json').write_text(json.dumps({'next_source_pdf_page':31,'next_source_block':0,'next_supplied_pdf_page':10,'next_supplied_block':28,'next_unit':10,'next_chapter':'chapter1','full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
