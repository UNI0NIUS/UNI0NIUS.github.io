from philosophy_common import *
spec=[
 (rr(45,3,4),rr(16,11),'heading'),
 (rr(45,5)+rr(46,0),rr(16,12,15),'paragraph'),
 (rr(46,1),rr(16,15,17),'paragraph'),
 (rr(46,2),rr(16,18,20),'paragraph'),
 (rr(46,3),rr(16,21),'paragraph'),
 (rr(46,4)+rr(47,0),rr(16,22,27),'quote'),
 (rr(47,1),rr(16,28),'paragraph'),
 (rr(47,2),rr(16,29,31),'paragraph'),
 (rr(47,3),rr(17,0,4),'paragraph'),
 (rr(47,4)+rr(48,0),rr(17,5,10),'paragraph'),
 (rr(48,1),rr(17,11,16),'paragraph'),
 (rr(48,2),rr(17,17),'paragraph'),
 (rr(48,3),rr(17,18,20),'quote'),
]
fixes={
 60:[('爱琴海早期那片湛蓝的天空之下','早期爱琴海时代那片晴朗湛蓝的天空之下')],
 62:[('“暴君”','“僭主”'),('持不同政见者中的贵族','持异议的贵族本人')],
 64:[('债权人对无力偿还债务的债务人最后的补救措施','债权人对无力偿还债务的债务人所能采取的最后手段')],
 65:[('已成为谚语','已成为严刑峻法的代称')],
 69:[('就认为他们是宗教信仰','就认为他们信奉宗教'),('“永恒的”、“不朽的”','“不衰老的”、“不朽的”')],
 71:[('首先吸引了人们的好奇心','首先唤起了探究精神')],
}
rows=[]
for i,(refs,zrefs,kind) in enumerate(spec,59):
 old=extract(ZH,zrefs)
 if i==60:old=old.split('最早的希腊哲学')[0]
 if i==61:old='最早的希腊哲学'+old.split('最早的希腊哲学',1)[1]
 zh=old
 for a,b in fixes.get(i,[]):
  assert a in zh,(i,a,zh)
  zh=zh.replace(a,b)
 row={'id':f'hp-ch01-{i:03}','kind':kind,'source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['PDF '+str(p) for p in dict.fromkeys(r[0] for r in refs)],'en':extract(EN,refs,True),'supplied_zh':old,'zh':zh,'status':'text_compared_layout_pending'}
 if zh!=old:row['revision_reason']='逐段核对英文，修正古希腊僭主术语、宗教信仰语病、荷马修饰语及经济史引文的措辞。'
 if i in (60,61):row['supplied_excerpt_boundary']='中文第16页第15块在“最早的希腊哲学”前分段，以恢复英文原段落。'
 if i==64:row['editor_note']='英文底本写作“the debtor’s last recourse against the insolvent debtor”，前一个debtor疑为creditor之误。此处按语境及已有译稿译为“债权人”，英文照录，特此说明。'
 rows.append(row)
notes=[]
for n in range(15,18):
 refs=rr(72,n-10);zrefs=rr(26,n);old=extract(ZH,zrefs)
 notes.append({'id':f'hp-ch01-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['PDF 72'],'en':extract(EN,refs,True),'supplied_zh':old,'zh':old,'editor_note':'页码按英文原书所引版本保留。','status':'text_compared_layout_pending'})
save('ch01e',rows,rr(45,3,5)+rr(46,0,4)+rr(47,0,4)+rr(48,0,3),notes,chapter='chapter1',reading_order=20)
(W/'checkpoint_ch01e.json').write_text(json.dumps({'next_source_pdf_page':49,'next_source_block':0,'next_supplied_pdf_page':17,'next_supplied_block':21,'next_unit':72,'next_chapter':'chapter1','full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
