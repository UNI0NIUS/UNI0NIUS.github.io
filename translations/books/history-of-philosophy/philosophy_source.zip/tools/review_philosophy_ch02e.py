from philosophy_common import *
spec=[(rr(87,1),rr(33,15),'heading'),(rr(87,2),rr(33,16,21),'paragraph'),(rr(87,3),rr(33,22,25),'paragraph'),(rr(87,4)+rr(88,0),rr(33,26,29),'paragraph'),(rr(88,1),rr(33,30,34)+rr(34,0,1),'paragraph'),(rr(88,2)+rr(89,0),rr(34,2,7),'paragraph'),(rr(89,1),rr(34,8,14),'paragraph'),(rr(89,2)+rr(90,0),rr(34,15,21),'paragraph'),(rr(90,1),rr(34,22),'paragraph'),(rr(90,2),rr(34,23,26),'quote'),(rr(90,3),rr(34,27),'paragraph'),(rr(90,4)+rr(91,0),rr(34,28,35)+rr(35,0,5),'quote'),(rr(91,1)+rr(92,0),rr(35,6,10),'paragraph'),(rr(92,1),rr(35,11,15),'paragraph'),(rr(92,2),rr(35,16,20),'paragraph'),(rr(92,3)+rr(93,0),rr(35,21,28),'paragraph')]
fixes={63:[('首席唯心主义者','彻底的唯心主义者'),('形式和定义','形式和规定性')],66:[('在数量上不同','在量上不同')],68:[('相距稍远时','相距不远时')],69:[('再举一例','他又说')],70:[('如果这堆原子中没有两个是完全相同的','如果这堆原子的排列并非处处重复相同模式')],71:[('如同同类相吸','同类与同类结合')],74:[('真理的先驱','真实的传报者')]}
rows=[]
for i,(refs,zrefs,kind) in enumerate(spec,59):
 old=extract(ZH,zrefs);zh=old
 for a,b in fixes.get(i,[]):
  assert a in zh,(i,a,zh)
  zh=zh.replace(a,b)
 row={'id':f'hp-ch02-{i:03}','kind':kind,'source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['PDF '+str(p) for p in dict.fromkeys(r[0] for r in refs)],'en':extract(EN,refs,True),'supplied_zh':old,'zh':zh,'status':'text_compared_layout_pending'}
 if zh!=old:row['revision_reason']='整节对照，纠正费曼引文的原子排列不重复误作原子彼此不同，区分量与数量、结合与吸引，修正arch-及definition语义。'
 if i==70:
  row['paragraph_starts_en']=['Everything is made of atoms.','If a piece of steel']
  row['paragraph_starts_zh']=['万物皆由原子构成。','如果一块钢']
 rows.append(row)
notes=[]
for n in range(22,30):
 refs=rr(119,n-13);zrefs=rr(45,21) if n==22 else rr(46,n-23 if n<29 else 7)
 if n==28:zrefs=rr(46,5,6)
 old=extract(ZH,zrefs);zh=old
 if n==26:zh=zh.replace('第1—2 页','第1–2页')
 if n==27:zh=zh.replace('第1—8 页、第1—9 页','第1–8、1–9页')
 row={'id':f'hp-ch02-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['PDF 119'],'en':extract(EN,refs,True),'supplied_zh':old,'zh':zh,'status':'text_compared_layout_pending'}
 if n in (26,27):row['editor_note']='保留原注带连接号的页码1–2／1–8／1–9，不将其改写为起讫页范围。'
 notes.append(row)
save('ch02e',rows,rr(87,1,4)+rr(88,0,2)+rr(89,0,2)+rr(90,0,4)+rr(91,0,1)+rr(92,0,3)+rr(93,0),notes,chapter='chapter2',reading_order=30)
(W/'checkpoint_ch02e.json').write_text(json.dumps({'next_source_pdf_page':93,'next_source_block':1,'next_supplied_pdf_page':35,'next_supplied_block':29,'next_unit':75,'next_chapter':'chapter2','full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
