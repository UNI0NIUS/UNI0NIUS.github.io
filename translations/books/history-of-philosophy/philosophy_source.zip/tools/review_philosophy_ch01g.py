from philosophy_common import *
spec=[(rr(52,2),rr(18,32)+rr(19,0),'paragraph'),(rr(52,3),rr(19,1,5),'paragraph'),(rr(52,4)+rr(53,0),rr(19,6,11),'quote'),(rr(53,1),rr(19,12,16),'paragraph'),(rr(53,2)+rr(54,0),rr(19,17,22),'paragraph'),(rr(54,1),rr(19,23,26),'paragraph'),(rr(54,2),rr(19,27,28),'paragraph'),(rr(54,3),rr(19,29,31),'quote')]
fixes={84:[('一大进步','向前迈进了一步')],85:[('普遍本质','普遍实体'),('凝结','凝聚')],86:[('第一原理','第一本原'),('凝结','凝聚')],88:[('基于远更高水平的发展','以远更高水平的科学技术发展为基础')],89:[('亚历山大的希腊思想家','亚历山大里亚的希腊思想家')],90:[('稀薄与凝结','稀化与凝聚')],91:[('仅凭这一点，它无法引领任何方向；也无法据此采取任何具体行动','仅靠它本身，无法取得进一步进展，也无法做出任何具体成果')]}
rows=[]
for i,(refs,zrefs,kind) in enumerate(spec,84):
 old=extract(ZH,zrefs);zh=old
 for a,b in fixes.get(i,[]):
  assert a in zh,(i,a,zh)
  zh=zh.replace(a,b)
 row={'id':f'hp-ch01-{i:03}','kind':kind,'source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['PDF '+str(p) for p in dict.fromkeys(r[0] for r in refs)],'en':extract(EN,refs,True),'supplied_zh':old,'zh':zh,'status':'text_compared_layout_pending'}
 if zh!=old:row['revision_reason']='整节对照，统一稀化／凝聚及本原术语，修正实体误作本质、亚历山大里亚地名，补足科学技术发展限定。'
 rows.append(row)
notes=[]
for n,zrefs in [(21,rr(26,21)),(22,rr(27,0)),(23,rr(27,1))]:
 refs=rr(72,n-10);old=extract(ZH,zrefs)
 notes.append({'id':f'hp-ch01-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['PDF 72'],'en':extract(EN,refs,True),'supplied_zh':old,'zh':old,'status':'text_compared_layout_pending'})
save('ch01g',rows,rr(52,2,4)+rr(53,0,2)+rr(54,0,3),notes,chapter='chapter1',reading_order=20)
(W/'checkpoint_ch01g.json').write_text(json.dumps({'next_source_pdf_page':55,'next_source_block':0,'next_supplied_pdf_page':19,'next_supplied_block':32,'next_unit':92,'next_chapter':'chapter1','full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
