from philosophy_common import *
spec=[(rr(73,0),rr(27,14),'chapter'),(rr(73,1),rr(27,15,17),'paragraph'),(rr(73,2),rr(27,18),'paragraph'),(rr(73,3),rr(27,19,23),'paragraph'),(rr(73,4),rr(27,24),'paragraph'),(rr(73,5)+rr(74,0),rr(28,0,2),'quote'),(rr(74,1),rr(28,3,4),'paragraph'),(rr(74,2),rr(28,5,8),'paragraph'),(rr(74,3),rr(28,9),'paragraph'),(rr(74,4)+rr(75,0),rr(28,10,15),'quote'),(rr(75,1),rr(28,16,17),'paragraph'),(rr(75,2),rr(28,18,19),'quote'),(rr(75,3),rr(28,20,21),'paragraph'),(rr(75,4),rr(28,22),'quote'),(rr(75,5),rr(28,23,24),'paragraph'),(rr(75,6),rr(28,25),'paragraph'),(rr(75,7),rr(28,26),'paragraph')]
fixes={2:[('在达尔文之后的一百多年里','在达尔文之后一百多年的今天')],4:[('如下诗句','如下文字')],6:[('我们踏入同一条溪流，却又未曾踏入','我们踏入而又不踏入同一条溪流')],8:[('苏格拉底曾讥讽地评论道','苏格拉底曾诙谐地评论道')],10:[('关系与反应','联系与相互作用'),('原始的、天真的但本质上正确','原始的、朴素的但本质上正确')],12:[('使一些人受束缚','使一些人成为奴隶')]}
rows=[]
for i,(refs,zrefs,kind) in enumerate(spec,1):
 old=extract(ZH,zrefs);zh=old
 for a,b in fixes.get(i,[]):
  assert a in zh,(i,a,zh)
  zh=zh.replace(a,b)
 row={'id':f'hp-ch02-{i:03}','kind':kind,'source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['PDF '+str(p) for p in dict.fromkeys(r[0] for r in refs)],'en':extract(EN,refs,True),'supplied_zh':old,'zh':zh,'status':'text_compared_layout_pending'}
 if zh!=old:row['revision_reason']='逐段核对：修正历史时间范围、同时肯定与否定误作先后经历、bond的奴隶身份及naive的哲学语境。'
 rows.append(row)
notes=[]
for n in range(1,8):
 refs=rr(118,n+3);zrefs=rr(45,n-1);old=extract(ZH,zrefs)
 notes.append({'id':f'hp-ch02-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['PDF 118'],'en':extract(EN,refs,True),'supplied_zh':old,'zh':old,'status':'text_compared_layout_pending'})
save('ch02a',rows,rr(73,0,5)+rr(74,0,4)+rr(75,0,7),notes,chapter='chapter2',reading_order=30)
(W/'checkpoint_ch02a.json').write_text(json.dumps({'next_source_pdf_page':75,'next_source_block':8,'next_supplied_pdf_page':28,'next_supplied_block':27,'next_unit':18,'next_chapter':'chapter2','full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
