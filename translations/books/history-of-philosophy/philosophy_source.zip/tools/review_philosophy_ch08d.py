from philosophy_packet import build
spec=[
 ['heading','271:1','106:7'],
 ['quote','271:2','106:8-106:10',[],{'zh':'在一粒沙中看见一个世界，\n在一朵野花中看见一片天堂，\n把无限握在你的掌心，\n将永恒容于一小时。\n（威廉·布莱克，《纯真预言》）','verse_lines_en':['To see a World in a Grain of Sand,','And a heaven in a Wild Flower,','Hold Infinity in the palm of your hand,','And Eternity in an hour.'],'verse_lines_zh':['在一粒沙中看见一个世界，','在一朵野花中看见一片天堂，','把无限握在你的掌心，','将永恒容于一小时。'],'attribution_en':'William Blake, Auguries of Innocence','attribution_zh':'威廉·布莱克，《纯真预言》'}],
 ['paragraph','271:3-272:0','106:11-106:14'],
 ['paragraph','272:1','106:15-106:24'],
 ['paragraph','272:2-273:0','106:25-106:31',[['一个单细胞','一个单独的细胞'],['马克思将资本主义的所有矛盾都归结于一个“单细胞”——商品','马克思从一个单独的细胞——商品——推导出资本主义的所有矛盾']]],
 ['paragraph','273:1','106:32-107:1'],
 ['paragraph','273:2-274:0','107:2-107:8'],
 ['paragraph','274:1','107:9-107:10'],
 ['paragraph','274:2','107:11-107:15'],
 ['quote','274:3-275:0','107:16-107:24',[['某些‘发现’','发现']],{'paragraph_starts_en':['The rationalistic systems','So, the connection'],'paragraph_starts_zh':['笛卡尔、莱布尼茨和斯宾诺莎','因此，形而上学']}],
]
notes=[[n,f'276:{n-7}',f'108:{n-7}'] for n in range(24,29)]+[[29,'276:22','109:0'],[30,'277:0','109:1'],[31,'277:1','109:2']]
build('ch08d',8,66,spec,'271:1-275:0',notes,[278,0,109,3])
