from philosophy_common import *
spec=[
 (rr(35,3)+rr(36,0),rr(12,19,23),'paragraph'),
 (rr(36,1),rr(12,24,30),'paragraph'),
 (rr(36,2),rr(12,31),'paragraph'),
 (rr(36,3)+rr(37,0),rr(12,32,35)+rr(13,0,1),'quote'),
 (rr(37,1),rr(13,2,7),'paragraph'),
 (rr(37,2),rr(13,8,11),'paragraph'),
 (rr(37,3)+rr(38,0),rr(13,12,17),'paragraph'),
 (rr(38,1),rr(13,18,21),'paragraph'),
 (rr(38,2),rr(13,22),'heading'),
 (rr(38,3),rr(13,23),'paragraph'),
 (rr(38,4)+rr(39,0),rr(13,24,29),'quote'),
 (rr(39,1),rr(13,30,35),'paragraph'),
 (rr(39,2)+rr(40,0),rr(14,0,4),'quote'),
 (rr(40,1),rr(14,5,6),'paragraph'),
 (rr(40,2),rr(14,7,8),'quote'),
 (rr(40,3),rr(14,9,12),'paragraph'),
 (rr(40,4),rr(14,13,14),'quote'),
]
fixes={
 25:[('人们区分了直接体验，并从中看到了与之完全不同的东西','人们把直接经验与某种完全不同于它的东西区分开来，并认识到后者')],
 26:[('如今已远去，无法追忆','如今已经一去不复返')],
 27:[('魔法与宗教','巫术与宗教')],
 29:[('“死亡是睡眠的第二重身”','睡眠是“死亡的另一个自身”'),('灵魂却能永存','灵魂却继续存在')],
 30:[('宗教（魔法）','宗教（巫术）'),('魔法交流','巫术交往')],
 31:[('神灵和图腾','神灵和崇拜物'),('⻤魂','鬼魂')],
 32:[('男女的心灵','人们的头脑'),('已被半数遗忘','已被遗忘大半')],
 35:[('原本由所有人共同承担','原本人人都做'),('最古老的人为或职业阶层','最古老的人为形成的阶层或职业阶层')],
 37:[('无私的喜悦与激情','不涉利害的喜悦与激情')],
 40:[('泛滥成灾','漫过河岸')],
 41:[('将魔法与理性元素','将巫术与理性因素')],
}
rows=[]
for i,(refs,zrefs,kind) in enumerate(spec,25):
 old=extract(ZH,zrefs);zh=old
 for a,b in fixes.get(i,[]):
  assert a in zh,(i,a,zh)
  zh=zh.replace(a,b)
 row={'id':f'hp-ch01-{i:03}','kind':kind,'source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['PDF '+str(p) for p in dict.fromkeys(r[0] for r in refs)],'en':extract(EN,refs,True),'supplied_zh':old,'zh':zh,'status':'text_compared_layout_pending'}
 if zh!=old:row['revision_reason']='逐段核对：纠正莎士比亚引语的比喻方向、fetish与totem的混淆、half-forgotten的误读及disinterested的利害含义；统一magic为巫术。'
 rows.append(row)
notes=[]
for n in range(5,10):
 refs=rr(71,n+2);zrefs=rr(26,n);old=extract(ZH,zrefs)
 notes.append({'id':f'hp-ch01-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['PDF 71'],'en':extract(EN,refs,True),'supplied_zh':old,'zh':old,'editor_note':'页码按英文原书所引版本保留；注6“同上”指注5《金枝》。' if n==6 else '作者缩写、书名及页码按英文原书所引版本保留。','status':'text_compared_layout_pending'})
save('ch01c',rows,rr(35,3)+rr(36,0,3)+rr(37,0,3)+rr(38,0,4)+rr(39,0,2)+rr(40,0,4),notes,chapter='chapter1',reading_order=20)
(W/'checkpoint_ch01c.json').write_text(json.dumps({'next_source_pdf_page':40,'next_source_block':5,'next_supplied_pdf_page':14,'next_supplied_block':15,'next_unit':42,'next_chapter':'chapter1','full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
