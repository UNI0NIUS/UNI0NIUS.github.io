from philosophy_common import *
spec=[(rr(75,8)+rr(76,0),rr(28,27,30)+rr(29,0,5),'list'),(rr(76,1),rr(29,6,8),'paragraph'),(rr(76,2),rr(29,9,10),'quote'),(rr(76,3),rr(29,11),'paragraph'),(rr(76,4),rr(29,12,13),'quote'),(rr(76,5),rr(29,14,15),'paragraph'),(rr(76,6)+rr(77,0),rr(29,16,21),'quote'),(rr(77,1),rr(29,22,28),'paragraph'),(rr(77,2)+rr(78,0),rr(29,29,32),'paragraph'),(rr(78,1),rr(30,0,4),'paragraph'),(rr(78,2),rr(30,5,7),'paragraph')]
fixes={19:[('它们并非由毕达哥拉斯学派所发展出来的','毕达哥拉斯学派却没有将它们进一步发展')],20:[('就像弓与竖琴之间的协调一样','就像弓和里拉琴各自体现的协调一样')],24:[('正如他们在睡梦中会忘记自己的所作所为','正如他们会忘记自己在睡梦中的所作所为')],25:[('“万物归一”','“万物皆一”')],27:[('所谓的“既定事实”和“事实”','所谓“所与”和“事实”')]}
rows=[]
for i,(refs,zrefs,kind) in enumerate(spec,18):
 old=extract(ZH,zrefs);zh=old
 for a,b in fixes.get(i,[]):
  assert a in zh,(i,a,zh)
  zh=zh.replace(a,b)
 row={'id':f'hp-ch02-{i:03}','kind':kind,'source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['PDF '+str(p) for p in dict.fromkeys(r[0] for r in refs)],'en':extract(EN,refs,True),'supplied_zh':old,'zh':zh,'status':'text_compared_layout_pending'}
 if zh!=old:row['revision_reason']='核对概念与引文：未进一步发展不等于并非由该学派提出；弓与琴的比喻指各自内部张力，非二者之间的协调；修正睡梦记忆及所与术语。'
 if i==18:
  row['items_en']=[re.sub(r'^\d+\.\s*','',x).strip() for x in re.split(r'(?=\b\d+\. )',row['en']) if x.strip()]
  row['items_zh']=[re.sub(r'^\d+\.\s*','',extract(ZH,[r])).strip() for r in zrefs]
  assert len(row['items_en'])==len(row['items_zh'])==10
 rows.append(row)
notes=[]
for n in range(8,13):
 refs=rr(118,n+3);zrefs=rr(45,n-1);old=extract(ZH,zrefs)
 notes.append({'id':f'hp-ch02-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['PDF 118'],'en':extract(EN,refs,True),'supplied_zh':old,'zh':old,'status':'text_compared_layout_pending'})
save('ch02b',rows,rr(75,8)+rr(76,0,6)+rr(77,0,2)+rr(78,0,2),notes,chapter='chapter2',reading_order=30)
(W/'checkpoint_ch02b.json').write_text(json.dumps({'next_source_pdf_page':78,'next_source_block':3,'next_supplied_pdf_page':30,'next_supplied_block':8,'next_unit':29,'next_chapter':'chapter2','full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
