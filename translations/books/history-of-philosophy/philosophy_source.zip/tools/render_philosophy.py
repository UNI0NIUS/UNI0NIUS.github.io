"""Render reviewed philosophy packets without discarding structured content."""
from philosophy_common import *
import sys,subprocess
O=W.parent/'output';O.mkdir(exist_ok=True)
groups={}
for p in sorted((json.loads(f.read_text('utf8')) for f in sorted((W/'packets').glob('*.json'))),key=lambda p:p['reading_order']):
 g=groups.setdefault(p['chapter'],{'units':[],'notes':[]})
 g['units']+=p['units'];g['notes']+=p['notes']
def plain(s):
 return ''.join({'\\':r'\textbackslash{}','&':r'\&','%':r'\%','$':r'\$','#':r'\#','_':r'\_','{':r'\{','}':r'\}','~':r'\textasciitilde{}','^':r'\textasciicircum{}'}.get(c,c) for c in s)
def esc(s,ch):
 out=[];last=0
 for m in re.finditer(r'\[\[(\d+)\]\]|https?://[^\s。；，（）\u4e00-\u9fff]+',s):
  out.append(plain(s[last:m.start()]))
  if m[1]:out.append(r'\hyperlink{note-'+ch+'-'+m[1]+r'}{\textsuperscript{'+m[1]+'}}')
  else:
   url=m[0].rstrip('.,;)');out.append(r'\url{'+url+'}'+plain(m[0][len(url):]))
  last=m.end()
 out.append(plain(s[last:]));return ''.join(out)
def english(s,u,ch):
 # Preserve source emphasis where exact contiguous spans can be located.
 runs=[]
 for p,b,j,l in lines(EN,u['source_blocks']):
  for sp in l['spans']:
   if sp['flags']&2:
    term=re.sub(r'\s+',' ',sp['text']).strip()
    if len(term)>1:
     for m in re.finditer(re.escape(term),s):
      if not any(a<m.end() and m.start()<b for a,b in runs):runs.append((m.start(),m.end()))
 runs.sort();out=[];last=0
 for a,b in runs:
  if '[[' in s[a:b] or 'http' in s[a:b]:continue
  out.extend([esc(s[last:a],ch),r'\emph{'+esc(s[a:b],ch)+'}']);last=b
 out.append(esc(s[last:],ch));return ''.join(out)
def paragraphs(u,lang):
 s=u[lang];starts=u.get('paragraph_starts_'+lang,[])
 pos=[]
 for t in starts:
  assert t in s,(u['id'],t)
  pos.append(s.index(t))
 assert pos==sorted(pos),(u['id'],pos)
 cuts=sorted(set([0]+pos+[len(s)]))
 return [s[a:b].strip() for a,b in zip(cuts,cuts[1:]) if s[a:b].strip()]
def body(u,lang,ch,note=False):
 fmt=lambda s:english(s,u,ch) if lang=='en' else esc(s,ch)
 if 'verse_lines_'+lang in u:
  s=r'\\'.join(fmt(x) for x in u['verse_lines_'+lang])
  if u.get('attribution_'+lang):s+=r'\\[3pt]\hfill '+fmt(u['attribution_'+lang])
 elif 'items_'+lang in u:
  items=u['items_'+lang]
  if u.get('toc_targets'):
   s=r'\par '.join(r'\noindent\hyperlink{chapter-'+c+'}{'+fmt(x)+'}' for x,c in zip(items,u['toc_targets']))
  else:s=r'\par '.join(r'\noindent\textbullet\ '+fmt(x) for x in items)
 else:s=r'\par '.join(fmt(x).replace('\n',r'\newline ') for x in paragraphs(u,lang))
 if note:
  s=re.sub(r'^\\hyperlink\{note-[^}]+\}\{\\textsuperscript\{(\d+)\}\}',lambda m:r'\textsuperscript{'+m[1]+'}',s)
 if lang=='zh' and u.get('editor_note'):s+=r'\par {\footnotesize\color{black!65}〔校注：'+esc(u['editor_note'],ch)+r'〕}'
 return s
PRE=r'''\documentclass[10pt,a4paper,twoside]{article}
\usepackage{fontspec,xeCJK}
\setmainfont{Times New Roman}
\setCJKmainfont[AutoFakeBold=2,AutoFakeSlant=.2]{SimSun}
\usepackage[a4paper,inner=20mm,outer=23mm,top=21mm,bottom=23mm,marginparwidth=16mm,marginparsep=3mm]{geometry}
\usepackage{xcolor,paracol,fancyhdr,hyperref,graphicx,needspace,xurl,amsmath}
\hypersetup{unicode=true,hidelinks,pdftitle={The History of Philosophy: A Marxist Perspective},pdfauthor={Alan Woods}}
\setlength{\parindent}{1em}\setlength{\parskip}{5pt}\setlength{\columnsep}{8mm}\setlength{\emergencystretch}{3em}
\tolerance=2000\widowpenalty=10000\clubpenalty=10000
\pagestyle{fancy}\fancyhf{}\fancyhead[LE,RO]{\small The History of Philosophy}
\fancyhead[LO,RE]{\small Alan Woods}\fancyfoot[C]{\thepage}\setlength{\headheight}{14pt}
\newcommand{\sourcepage}[1]{\marginpar{\raggedleft\scriptsize\color{gray}#1}}
\twosided[pm]\marginparthreshold{0}
\begin{document}
'''
def render(bi):
 out=[PRE];opened=False
 def close():
  nonlocal opened
  if opened:out.append(r'\end{paracol}');opened=False
 def pair(zh,en,mark='',small=False):
  nonlocal opened
  if bi:
   if not opened:out.append(r'\begin{paracol}{2}');opened=True
   if small:zh=r'{\small '+zh+'}';en=r'{\small '+en+'}'
   out.extend([r'\leavevmode{}'+mark+zh+r'\par',r'\switchcolumn',en+r'\par',r'\switchcolumn*'])
  else:out.append(r'\leavevmode{}'+mark+(r'{\small '+en+'}' if small else en)+r'\par')
 cover=groups['frontmatter']['units'][0]
 out.append(r'\thispagestyle{empty}\begin{center}\includegraphics[width=\textwidth,height=.94\textheight,keepaspectratio]{'+cover['image']+r'}\end{center}\clearpage')
 out.append(r'\begin{center}{\Large\bfseries '+('马克思主义视角下的哲学史' if bi else 'The History of Philosophy: A Marxist Perspective')+r'}\par\medskip Alan Woods / 艾伦·伍兹\end{center}')
 notice='全书中英逐段对照校对版。左栏中文，右栏英文。页边“PDF”数字指所供英文原书的PDF页序；原书电子版无印刷页码。原注保留原编号，置于各章末，支持跳转及返回。原书疑点另列校注。' if bi else 'Complete English reading edition. Margin labels refer to the supplied source PDF page sequence, not printed pagination. Original endnotes retain their numbers and are linked to the text. Source wording is preserved.'
 out.append(r'\noindent '+plain(notice)+r'\par\bigskip')
 if bi:out.append(esc(cover['zh'],'frontmatter')+r'\par')
 for ch,g in groups.items():
  close();lastpage=None
  if ch!='frontmatter':out.extend([r'\clearpage',r'\hypertarget{chapter-'+ch+'}{}'])
  for i,u in enumerate(g['units']):
   if u is cover:continue
   out.append('% UNIT '+u['id'])
   kind=u['kind'];zh=body(u,'zh',ch);en=body(u,'en',ch)
   label='--'.join(dict.fromkeys([u['printed_pages'][0],u['printed_pages'][-1]])) if u['printed_pages'] else ''
   mark=(r'\sourcepage{'+plain(label)+'}') if label and label!=lastpage else ''
   if kind in ['chapter','heading']:
    close();top=i==0 and ch!='frontmatter'
    if ch=='frontmatter' and u['en']=='Table of Contents':out.append(r'\clearpage')
    reserve=12 if i+1<len(g['units']) and g['units'][i+1].get('verse_lines_en') else 7
    out.append(r'\needspace{'+str(reserve)+r'\baselineskip}')
    out.append(r'\pdfbookmark['+('0' if top else '1')+']{'+plain(u['zh'] if bi else u['en'])+'}{'+u['id']+'}')
    out.append((r'\section*' if top else r'\subsection*')+'{'+(zh+r'\\[3pt]{\normalsize '+en+'}' if bi else en)+'}');continue
   lastpage=label
   if kind=='figure':
    close();out.append(r'\begin{center}\includegraphics[width=.15\textwidth,height=.12\textheight,keepaspectratio]{'+u['image']+r'}\end{center}');continue
   if kind=='separator':close();out.append(r'\medskip\hrule\medskip');continue
   if u.get('verse_lines_en'):
    close();out.append(r'\needspace{'+str(len(u['verse_lines_en'])+3)+r'\baselineskip}')
   calls=re.findall(r'\[\[(\d+)\]\]',u['en'])
   mark+=''.join(r'\hypertarget{ref-'+ch+'-'+n+'}{}' for n in dict.fromkeys(calls))
   if u.get('items_en') and not u.get('toc_targets'):
    assert len(u['items_en'])==len(u['items_zh'])
    for j,(ze,ee) in enumerate(zip(u['items_zh'],u['items_en'])):
     bullet=(str(j+1)+'. ') if re.match(r'^1[.)]',u['en']) else r'\textbullet\ '
     pair(r'\noindent '+bullet+esc(ze,ch),r'\noindent '+bullet+english(ee,u,ch),mark if j==0 else '')
    if bi and u.get('editor_note'):pair(r'{\footnotesize\color{black!65}〔校注：'+esc(u['editor_note'],ch)+'〕}', '')
    continue
   pair(zh,en,mark,kind=='quote')
  close()
  if g['notes']:
   out.extend([r'\clearpage',r'\subsection*{'+('原注 / ' if bi else '')+'Notes}',r'\pdfbookmark[1]{'+('原注' if bi else 'Notes')+'}{notes-'+ch+'}'])
   for u in g['notes']:
    num=str(u['note_number']);mark=r'\hypertarget{note-'+ch+'-'+num+r'}{}\hyperlink{ref-'+ch+'-'+num+r'}{\textsuperscript{$\uparrow$}}'
    pair(body(u,'zh',ch,True),body(u,'en',ch,True),mark,True)
   close()
 out.append(r'\end{document}');return '\n'.join(out)
def markdown():
 out=['# 马克思主义视角下的哲学史','艾伦·伍兹著。中文校对稿；页码标注采用英文原书PDF页序。']
 for ch,g in groups.items():
  out.append('<a id="chapter-'+ch+'"></a>')
  for i,u in enumerate(g['units']):
   out.append('<!-- '+u['id']+' -->')
   if u['printed_pages']:out.append('〔原书 '+'—'.join(dict.fromkeys(u['printed_pages']))+'〕')
   conv=lambda s:re.sub(r'\[\[(\d+)\]\]',lambda m:f'[^'+ch+'-'+m[1]+']',s)
   if 'verse_lines_zh' in u:s='  \n'.join(u['verse_lines_zh'])+('  \n'+u['attribution_zh'] if u.get('attribution_zh') else '')
   elif 'items_zh' in u:s='\n'.join((str(j+1)+'. ' if re.match(r'^1[.)]',u['en']) else '- ')+x for j,x in enumerate(u['items_zh']))
   else:s='\n\n'.join(paragraphs(u,'zh'))
   if u['kind'] in ['heading','chapter']:s=('# ' if i==0 else '## ')+s
   elif u['kind']=='quote':s='\n'.join('> '+x for x in s.splitlines())
   out.append(conv(s))
   if u.get('image'):out.append('!['+('原书封面' if i==0 else '出版社标志')+']('+u['image']+')')
   if u.get('editor_note'):out.append('> 校注：'+u['editor_note'])
  for n in g['notes']:
   text=re.sub(r'^\[\[\d+\]\]\s*','',n['zh'])
   if n.get('editor_note'):text+='〔校注：'+n['editor_note']+'〕'
   out.append(f'[^'+ch+'-'+str(n['note_number'])+']: '+text)
 return '\n\n'.join(out)+'\n'
for k,bi in [('bilingual',True),('en',False)]: (O/f'philosophy_{k}.tex').write_text(render(bi),'utf8')
(O/'philosophy_zh.md').write_text(markdown(),'utf8')
if '--compile' in sys.argv:
 for k in ['bilingual','en']:
  for i in [1,2]:
   p=subprocess.run(['C:/texlive/2025/bin/windows/xelatex.exe','-interaction=nonstopmode','-halt-on-error',f'philosophy_{k}.tex'],cwd=O,capture_output=True)
   (W/f'compile_{k}_{i}.log').write_bytes(p.stdout+p.stderr)
   if p.returncode:print(p.stdout.decode('utf8',errors='replace')[-3500:]);raise SystemExit(p.returncode)
  print(k,'compiled',flush=True)
