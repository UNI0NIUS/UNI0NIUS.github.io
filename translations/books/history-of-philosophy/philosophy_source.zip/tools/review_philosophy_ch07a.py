from philosophy_packet import build,extract,refs,ZH
spec=[
 ['heading','200:0','78:1'],
 ['quote','200:1','78:2-78:5',[],{'zh':'那时我仿佛一位守望苍穹的人，\n当一颗新行星游入他的视野；\n又仿佛勇毅的科尔特斯，以鹰隼般的目光\n凝望太平洋——他的全体部下\n带着狂放的猜想彼此相望——\n静立于达里恩的一座山巅。\n（约翰·济慈，《初读查普曼译〈荷马〉》）','verse_lines_en':['Then felt I like some watcher of the skies','When a new planet swims into his ken;','Or like stout Cortez when with eagle eyes','He stared at the Pacific – and all his men','Look’d at each other with a wild surmise –','Silent, upon a peak in Darien.'],'verse_lines_zh':['那时我仿佛一位守望苍穹的人，','当一颗新行星游入他的视野；','又仿佛勇毅的科尔特斯，以鹰隼般的目光','凝望太平洋——他的全体部下','带着狂放的猜想彼此相望——','静立于达里恩的一座山巅。'],'attribution_en':'John Keats, On First Looking into Chapman’s Homer','attribution_zh':'约翰·济慈，《初读查普曼译〈荷马〉》'}],
 ['quote','200:2','78:6-78:7'],
 ['paragraph','200:3','78:8-78:11'],
 ['paragraph','200:4','78:12-78:13'],
 ['quote','200:5-201:0','78:14-78:16',[['它被绝大多数日耳曼民族直接抛弃，转而信奉新教','绝大多数日耳曼民族直接摆脱了这种统治，转而信奉新教']]],
 ['paragraph','201:1','78:17-78:19'],
 ['paragraph','201:2','78:20-78:22'],
 ['paragraph','201:3','78:23-78:26'],
 ['paragraph','201:4-202:0','78:27-78:29',[['“无中生有”','“无不能生有”'],['宇宙自古以来就存在','宇宙始终存在']]],
 ['paragraph','202:1','79:0-79:6',[['魔⻤','魔鬼'],['七个水晶球体','七重水晶天球'],['这七个球体','这七重天球']]],
 ['paragraph','202:2','79:7-79:10'],
 ['paragraph','202:3-203:0','79:11-79:15'],
 ['paragraph','203:1','79:16-79:20'],
 ['paragraph','203:2','79:21-79:24'],
 ['paragraph','203:3-204:0','79:25-79:28'],
 ['heading','204:1','79:29'],
 ['paragraph','204:2','79:30-79:35',[],{'editor_note':'原文写“Venus had phases like the sun”（金星像太阳一样有盈亏变化），此处照译；作为相位变化的比较对象，这里应为月亮。'}],
]
a=extract(ZH,refs(ZH,'80:0-80:2'));cut=a.index(' 1993')
spec.append(['paragraph','204:3','80:0-80:2',[],{'supplied_excerpt':a[:cut]}])
a=extract(ZH,refs(ZH,'80:2-80:5'));cut=a.index('1993')
spec.append(['paragraph','204:4-205:0','80:2-80:5',[['唯一的原因是为了确保他的著作能在一个非常安全的地方——墓地——面世','唯一的原因是确保自己的著作面世时，他本人已经身处一个非常安全的地方——墓地']],{'supplied_excerpt':a[cut:]}])
spec += [
 ['paragraph','205:1','80:6-80:9'],
 ['paragraph','205:2','80:10-80:15'],
 ['paragraph','205:3-206:0','80:16-80:17'],
 ['quote','206:1','80:18-80:22'],
 ['paragraph','206:2','80:23-80:26',[['正是科学的发现，而非哲学家的逻辑辩论，使得旧有观点难以维系','科学的发现比哲学家的逻辑辩论更有力地使旧有观点难以维系']]],
]
notes=[[1,'247:2','96:0'],[2,'247:3','96:1'],[3,'248:0','96:2'],[4,'248:1','96:3']]
build('ch07a',7,1,spec,'200:0-206:2',notes,[206,3,80,27])
