"""Read one review span and its original notes in a single, bounded call.

Example: --en 52:2 55:4 --zh 18:32 20:10 --notes-en 71 72 --notes-zh 26 27
Endpoints are inclusive PDF-page:block references. This prepares evidence only;
it never marks text reviewed or changes canonical packets.
"""
import argparse
from philosophy_common import *

def span(pages,start,end):
 a=tuple(map(int,start.split(':')));z=tuple(map(int,end.split(':')))
 return [[p,b['block']] for p in range(a[0],z[0]+1) for b in pages[p-1]['blocks'] if a<=(p,b['block'])<=z]

def emit(pages,refs,label):
 print('\n'+label)
 for ref in refs:print(f'{ref[0]}:{ref[1]} '+extract(pages,[ref],pages is EN))

def note_refs(pages,page_numbers,needed):
 groups={};current=None
 for p in page_numbers:
  for b in pages[p-1]['blocks']:
   ref=[p,b['block']];s=extract(pages,[ref],pages is EN)
   m=re.match(r'^\[\[(\d+)\]\]',s)
   if m:
    current=int(m[1]);groups[current]=[ref]
   elif re.match(r'^\d+\.\s',s):current=None
   elif current is not None:groups[current].append(ref)
 return [r for n in sorted(needed) for r in groups.get(n,[])],sorted(needed-set(groups))

if __name__=='__main__':
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--en',nargs=2,required=True);ap.add_argument('--zh',nargs=2,required=True)
 ap.add_argument('--notes-en',nargs='*',type=int,default=[]);ap.add_argument('--notes-zh',nargs='*',type=int,default=[])
 args=ap.parse_args();er=span(EN,*args.en);zr=span(ZH,*args.zh)
 emit(EN,er,'EN');emit(ZH,zr,'SUPPLIED ZH')
 needed={int(n) for n in re.findall(r'\[\[(\d+)\]\]',extract(EN,er,True))}
 for pages,ps,label in [(EN,args.notes_en,'ORIGINAL NOTES'),(ZH,args.notes_zh,'SUPPLIED NOTES')]:
  refs,missing=note_refs(pages,ps,needed);emit(pages,refs,label)
  if missing:print('NOTES NOT FOUND:',missing)
