from philosophy_common import *
spec=[
 (rr(18,0),rr(6,5,7),'paragraph'),
 (rr(18,1),rr(6,8,13),'paragraph'),
 (rr(18,2)+rr(19,0),rr(6,14,18),'paragraph'),
 (rr(19,1,3),rr(6,19),'heading'),
 (rr(19,4),rr(6,20,23),'paragraph'),
 (rr(19,5),rr(6,22,25),'paragraph'),
 (rr(19,6),rr(6,26,27),'paragraph'),
 (rr(20,0),rr(6,28),'heading'),
 (rr(20,1),rr(6,29,30),'paragraph'),
 (rr(20,2),rr(6,31,33),'paragraph'),
 (rr(20,3),rr(7,0,4),'paragraph'),
 (rr(20,4),rr(7,5,6),'paragraph'),
 (rr(21,0),rr(7,7),'paragraph'),
 (rr(21,1),rr(7,8,11),'quote'),
 (rr(21,2),rr(7,12),'heading'),
 (rr(21,3),rr(7,13,15),'paragraph'),
 (rr(21,4)+rr(22,0),rr(7,16,20),'paragraph'),
 (rr(22,1),rr(7,21,22),'paragraph'),
 (rr(22,2,4),rr(7,23),'heading'),
 (rr(22,5),rr(7,24,26),'paragraph'),
]
fixes={
 51:[('它不再拥有积极的支持、尊重或权威','它不再能赢得积极的支持、尊重或权威')],
 58:[('大学里那些聪明人','大学里那些自作聪明的人')],
 60:[('党派观点','有倾向性的观点')],
 61:[('一场没有规则的战斗','一场不择手段的战斗')],
 63:[('一般意义上的思维不是沉思的，而是积极的','认识性思维一般说来不是静观的，而是能动的'),('以严格的良心','以严谨负责的态度')],
 66:[('他们会试图通过翻查旧文本，证明毕竟黑就是白、白就是黑','他们会翻查旧文本，试图证明黑就是白、白就是黑，以此反驳我的论点')],
 69:[('而是反对社会主义的保障','而是防范社会主义的屏障')],
}
rows=[]
for i,(refs,zrefs,kind) in enumerate(spec,50):
 old=extract(ZH,zrefs)
 if i==54:old=old.split('这是对黑格尔思想')[0]
 if i==55:old='这是对黑格尔思想'+old.split('这是对黑格尔思想',1)[1]
 zh=old
 for a,b in fixes.get(i,[]):
  assert a in zh,(i,a,zh)
  zh=zh.replace(a,b)
 row={'id':f'hp-intro-{i:03}','kind':kind,'source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['PDF '+str(p) for p in dict.fromkeys(r[0] for r in refs)],'en':extract(EN,refs,True),'supplied_zh':old,'zh':zh,'status':'text_compared_layout_pending'}
 if i in (54,55):row['supplied_excerpt_boundary']='共享中文第6页第22—23块，在跨行的“这是对黑格尔思想”前分段，以恢复英文原段落。'
 if zh!=old:row['revision_reason']='核对原文段落，修正思维能动性、严谨态度、修辞和遗漏的反驳关系。'
 if i==54:row['editor_note']='本段对译本的批评及对德文词的解释均为原作者的论断，按原书保留。'
 rows.append(row)
notes=[]
for n,refs,zrefs in [(5,rr(27,1),rr(9,17)),(6,rr(27,2),rr(9,18))]:
 old=extract(ZH,zrefs)
 notes.append({'id':f'hp-intro-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['PDF 27'],'en':extract(EN,refs,True),'supplied_zh':old,'zh':old,'editor_note':'页码按英文原书所引版本保留。','status':'text_compared_layout_pending'})
save('intro04',rows,rr(18,0,2)+rr(19,0,6)+rr(20,0,4)+rr(21,0,4)+rr(22,0,5),notes)
(W/'checkpoint_intro04.json').write_text(json.dumps({'next_source_pdf_page':22,'next_source_block':6,'next_supplied_pdf_page':7,'next_supplied_block':27,'next_unit':70,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
