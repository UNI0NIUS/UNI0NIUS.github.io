from philosophy_common import *
spec=[(rr(4,0),rr(1,1),'chapter'),(rr(4,1),rr(1,2),'heading'),(rr(4,2),rr(1,3,5),'paragraph'),(rr(4,3),rr(1,6,9),'paragraph'),(rr(4,4),rr(1,10,13),'paragraph'),(rr(5,0),rr(1,14,16),'paragraph'),(rr(5,1),rr(1,17,19),'paragraph'),(rr(5,2),rr(1,20,23),'paragraph'),(rr(5,3)+rr(6,0),rr(1,24,28),'paragraph'),(rr(6,1),rr(1,29),'heading'),(rr(6,2),rr(1,30,31),'paragraph'),(rr(6,3),rr(2,0,2),'paragraph'),(rr(6,4),rr(2,3,4),'paragraph'),(rr(6,5),rr(2,5,7),'paragraph'),(rr(7,0),rr(2,8,9),'paragraph'),(rr(7,1,2),rr(2,10),'heading'),(rr(7,3),rr(2,11,14),'paragraph'),(rr(7,4),rr(2,15,18),'paragraph'),(rr(8,0),rr(2,19,21),'paragraph'),(rr(8,1),rr(2,22,27),'paragraph'),(rr(8,2)+rr(9,0),rr(2,28,33),'paragraph'),(rr(9,1),rr(3,0,2),'paragraph'),(rr(9,2),rr(3,3,7),'paragraph'),(rr(9,3,4),rr(3,8),'heading')]
fixes={
 4:[('任由老鼠啃噬','任由老鼠的牙齿去批判')],
 5:[('在打击资产阶级意识形态','在反对资产阶级意识形态'),('终极危机','走向终结的危机')],
 7:[('新章节——尤其是关于中世纪的那一章——','新的小节，尤其是在论述中世纪的那一章中，')],
 9:[('要公正对待那个主题','要充分论述那个主题'),('一卷或多卷额外卷册','另外一卷或多卷著作')],
 20:[('他的辩证法包含着','他的辩证方法包含着')],
 21:[('直接导致了马克思的剩余价值理论','直接通向马克思的剩余价值理论')],
}
rows=[]
for i,(refs,zrefs,kind) in enumerate(spec,1):
    old=extract(ZH,zrefs);zh=old
    for a,b in fixes.get(i,[]):assert a in zh,(i,a,zh);zh=zh.replace(a,b)
    row={'id':f'hp-intro-{i:03}','kind':kind,'source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['PDF '+str(p) for p in dict.fromkeys(r[0] for r in refs)],'en':extract(EN,refs,True),'supplied_zh':old,'zh':zh,'status':'text_compared_layout_pending'}
    if zh!=old:row['revision_reason']='对照英文修正引语、层级或语义，保留作者立场。'
    rows.append(row)
save('intro01',rows,rr(4,0,4)+rr(5,0,3)+rr(6,0,5)+rr(7,0,4)+rr(8,0,2)+rr(9,0,4))
(W/'checkpoint_intro01.json').write_text(json.dumps({'next_source_pdf_page':10,'next_supplied_pdf_page':3,'next_supplied_block':9,'next_unit':25,'page_basis':'supplied ebook PDF pages; no printed page numbers detected','full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
