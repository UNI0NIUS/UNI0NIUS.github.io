from philosophy_common import *
packets=[json.loads((W/'packets'/f'intro{i:02}.json').read_text('utf8')) for i in range(1,6)]
units=[u for p in packets for u in p['units']]
notes=[n for p in packets for n in p['notes']]
refs=[r for u in units+notes for r in u['source_blocks']]
used=[(p,b,j) for p,b,j,l in lines(EN,refs)]
expected=[(p,b['block'],j) for p in range(4,28) for b in EN[p-1]['blocks'] for j,l in enumerate(b['lines']) if (p,b['block'])!=(26,4)]
assert set(used)==set(expected)
assert len(used)==len(set(used))
assert len({u['id'] for u in units+notes})==len(units+notes)
assert [n['note_number'] for n in notes]==list(range(1,7))
for u in units+notes:
 assert extract(EN,u['source_blocks'],True)==u['en'],u['id']
 assert re.findall(r'\[\[\d+\]\]',u['en'])==re.findall(r'\[\[\d+\]\]',u['zh']),u['id']
assert [u['id'] for u in units]==[f'hp-intro-{i:03}' for i in range(1,83)]
report={'scope':'Introduction only, PDF pages 4–27','units':len(units),'notes':len(notes),'source_lines':len(used),'missing_source_lines':[],'duplicate_source_lines':[],'excluded_heading':{'source_blocks':rr(26,4),'en':extract(EN,rr(26,4),True),'reason':'Notes heading will be generated above the original-note section.'},'source_text_preservation':'pass','note_alignment':'pass','layout_review':'pending','full_book_complete':False}
(W/'introduction_coverage_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8')
print(json.dumps(report,ensure_ascii=False))
