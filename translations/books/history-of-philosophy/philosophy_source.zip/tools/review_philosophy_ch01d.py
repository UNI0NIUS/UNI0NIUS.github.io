from philosophy_common import *
spec=[
 (rr(40,5)+rr(41,0),rr(14,15,19),'paragraph'),
 (rr(41,1),rr(14,20,21),'paragraph'),
 (rr(41,2)+rr(42,0),rr(14,22,29)+rr(15,0,1),'quote'),
 (rr(42,1),rr(15,2),'paragraph'),
 (rr(42,2),rr(15,3,6),'quote'),
 (rr(42,3),rr(15,7,8),'paragraph'),
 (rr(42,4),rr(15,9,10),'paragraph'),
 (rr(43,0),rr(15,11,13),'quote'),
 (rr(43,1),rr(15,14),'paragraph'),
 (rr(43,2),rr(15,15,17),'quote'),
 (rr(43,3),rr(15,18,20),'paragraph'),
 (rr(43,4)+rr(44,0),rr(15,21,28),'quote'),
 (rr(44,1),rr(15,29,33),'paragraph'),
 (rr(44,2,3),rr(16,0),'heading'),
 (rr(44,4)+rr(45,0),rr(16,1,4),'paragraph'),
 (rr(45,1),rr(16,5,7),'paragraph'),
 (rr(45,2),rr(16,8,10),'paragraph'),
]
fixes={
 42:[('他们嫉妒地守护着自己的秘密','他们严密地守护着自己的秘密')],
 43:[('抄写员','书吏')],
 44:[('抄写员','书吏'),('我已将它们摆在','我［已将它们摆］在')],
 46:[('所谓“机械技艺”','所谓“手工技艺”'),('机械手工业','手工业')],
 48:[('是男人和女人按照自己的形象和模样创造了神','是人们按照自己的形象和模样创造了诸神')],
 51:[('都归咎于诸神','都赋予了诸神')],
 52:[('无形的泥土','尚未成形的泥土')],
 53:[('便是建在一片由芦苇交错铺设在冲积泥土上的平台上','便建在一种由芦苇交错铺在冲积泥土上形成的平台上')],
 57:[('这些发现在一千五百年间都未曾有重大突破','此后一千五百年间，人们在这些发现的基础上都未能取得多大进展')],
}
rows=[]
for i,(refs,zrefs,kind) in enumerate(spec,42):
 old=extract(ZH,zrefs);zh=old
 for a,b in fixes.get(i,[]):
  assert a in zh,(i,a,zh)
  zh=zh.replace(a,b)
 row={'id':f'hp-ch01-{i:03}','kind':kind,'source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['PDF '+str(p) for p in dict.fromkeys(r[0] for r in refs)],'en':extract(EN,refs,True),'supplied_zh':old,'zh':zh,'status':'text_compared_layout_pending'}
 if zh!=old:row['revision_reason']='逐段对照：修正jealously、mechanical arts、ascribed及formless的语义，统一scribe为书吏，恢复引文方括号。'
 if i==44:
  row['editor_note']='原文将泥工与 vines or pigs 相比，其中 vines（葡萄藤）照录；[sic!]及其他方括号来自英文底本。'
  row['paragraph_starts_en']=['I have seen how','I have seen the metalworker','The small building contractor','The arrow-maker','The laundry man','Behold, there is no profession','Behold, there is no scribe']
  row['paragraph_starts_zh']=['我曾目睹劳苦之人','我曾目睹金属匠','小建筑承包商','制箭匠','洗衣工','看哪，没有哪种职业','看哪，没有哪位书吏']
 if i==52:row['editor_note']='英文底本写作“the first book of Genesis”，译文保留其“《创世记》第一卷”的表述。'
 rows.append(row)
notes=[]
for n in range(10,15):
 refs=rr(72,n-10);zrefs=rr(26,n);old=extract(ZH,zrefs)
 notes.append({'id':f'hp-ch01-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['PDF 72'],'en':extract(EN,refs,True),'supplied_zh':old,'zh':old,'editor_note':'页码按英文原书所引版本保留。','status':'text_compared_layout_pending'})
save('ch01d',rows,rr(40,5)+rr(41,0,2)+rr(42,0,4)+rr(43,0,4)+rr(44,0,4)+rr(45,0,2),notes,chapter='chapter1',reading_order=20)
(W/'checkpoint_ch01d.json').write_text(json.dumps({'next_source_pdf_page':45,'next_source_block':3,'next_supplied_pdf_page':16,'next_supplied_block':11,'next_unit':59,'next_chapter':'chapter1','full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
