from philosophy_common import *
spec=[
 (rr(31,0),rr(10,28),'heading'),
 (rr(31,1),rr(10,29),'quote'),
 (rr(31,2),rr(10,30,31),'quote'),
 (rr(31,3),rr(10,32,33)+rr(11,0,2),'paragraph'),
 (rr(31,4),rr(11,3,7),'paragraph'),
 (rr(32,0),rr(11,8,12),'paragraph'),
 (rr(32,1),rr(11,13,17),'paragraph'),
 (rr(32,2)+rr(33,0),rr(11,18,23),'paragraph'),
 (rr(33,1),rr(11,24,26),'paragraph'),
 (rr(33,2),rr(11,27,30),'paragraph'),
 (rr(33,3)+rr(34,0),rr(11,31,36)+rr(12,0,1),'paragraph'),
 (rr(34,1),rr(12,2),'paragraph'),
 (rr(34,2)+rr(35,0),rr(12,3,9),'quote'),
 (rr(35,1),rr(12,10,15),'paragraph'),
 (rr(35,2),rr(12,16,18),'paragraph'),
]
fixes={
 13:[('2\\%','2%'),('一股反驳之声','一种反对意见')],
 14:[('2\\%','2%')],
 15:[('促成了大脑的发育','促成了大脑体积的增大')],
 16:[('厚皮动物尸体','皮厚的动物的尸体')],
 17:[('（即使是最进化的猿类）','（即使是最高等的猿类）')],
 22:[('由此可见，被称为语言的社会工具为人类从具体事物的束缚中解放出来作出了贡献','由此可见，被称为语言的社会工具，促成了那个被冠以宏大名称的过程——“人类从具体事物的束缚中解放出来”')],
 23:[('我们实际上永远无法将“植物”本身与具体的花朵或灌木区分开来','我们实际上永远看不到一种与具体花朵或灌木相区别的“植物本身”')],
}
rows=[]
for i,(refs,zrefs,kind) in enumerate(spec,10):
 old=extract(ZH,zrefs);zh=old
 for a,b in fixes.get(i,[]):
  assert a in zh,(i,a,zh)
  zh=zh.replace(a,b)
 row={'id':f'hp-ch01-{i:03}','kind':kind,'source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['PDF '+str(p) for p in dict.fromkeys(r[0] for r in refs)],'en':extract(EN,refs,True),'supplied_zh':old,'zh':zh,'status':'text_compared_layout_pending'}
 if zh!=old:row['revision_reason']='逐段核对原文，修复百分号转义残留、大脑增大及抽象概念的语义，补回引文的修辞限定。'
 rows.append(row)
notes=[]
for n in range(1,5):
 refs=rr(71,n+2);zrefs=rr(26,n);old=extract(ZH,zrefs);zh=old
 if n==1:zh=zh.replace('蒙田','M. 德·蒙田')
 if n==2:zh=zh.replace('《经济学手稿》','《政治经济学批判大纲》（Grundrisse）')
 if n==3:zh=zh.replace('《历史发生了什么》','《历史发生了什么》（What Happened in History）')
 notes.append({'id':f'hp-ch01-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['PDF 71'],'en':extract(EN,refs,True),'supplied_zh':old,'zh':zh,'editor_note':'页码按原书所引版本保留；注4“同上”承接注3的柴尔德著作。' if n==4 else '页码按英文原书所引版本保留。','status':'text_compared_layout_pending'})
save('ch01b',rows,rr(31,0,4)+rr(32,0,2)+rr(33,0,3)+rr(34,0,2)+rr(35,0,2),notes,chapter='chapter1',reading_order=20)
(W/'checkpoint_ch01b.json').write_text(json.dumps({'next_source_pdf_page':35,'next_source_block':3,'next_supplied_pdf_page':12,'next_supplied_block':19,'next_unit':25,'next_chapter':'chapter1','full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
