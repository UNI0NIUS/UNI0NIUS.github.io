from philosophy_packet import refs
from philosophy_common import *
# Reviewed entry starts. Two source lines join adjacent entries; retain those
# pairs together so every original line remains covered exactly once.
mapping='''383:0:0|150:7
383:1:0|150:8
383:2:1|150:9
383:3:1|150:10
383:3:2|150:11
383:4:1|150:12
383:5:1|150:13
383:6:1|150:14
383:7:1|150:15
383:8:1|150:16
383:9:1|150:17
383:10:1|150:18
383:10:2|150:19
383:11:1|151:0
383:12:1|151:1
383:13:1|151:2
383:14:1|151:3
384:0:0|151:4
384:1:1|151:5
384:2:1|151:6
384:3:1|151:7
384:3:7|151:8
384:3:8|151:9
384:3:9|151:10
384:3:10|151:11
384:3:17|151:12
384:3:18|151:13
384:4:1|151:14-151:15
384:5:8|151:16
384:5:9|151:17
384:6:1|151:18
384:7:1|151:19
384:8:1|151:20
384:8:2|151:21
384:9:1|152:0
385:0:0|152:1
385:0:1|152:2
385:1:1|152:3
385:2:1|152:4
385:2:2|152:5
385:2:3|152:6
385:2:4|152:7
385:3:1|152:8
385:4:1|152:9
385:5:1|152:10
385:6:1|152:11
385:7:1|152:12
385:7:2|152:13
385:8:2|152:14
385:9:1|152:15
385:10:1|152:16
385:10:2|152:17
385:11:1|152:18
385:12:1|152:19
386:0:0|152:20
386:1:1|152:21
386:2:1|153:0
386:2:10|153:1
386:3:1|153:2
386:4:1|153:3
386:5:1|153:4
386:5:2|153:5
386:5:3|153:6
386:6:1|153:7
386:6:2|153:8-153:9
386:7:1|153:10
386:7:8|153:11
386:7:16|153:12
386:8:1|153:13
386:8:2|153:14
386:9:1|153:15
386:9:2|153:16
386:10:1|153:17
387:0:0|153:18
387:1:1|153:19
387:2:1|153:20
387:2:2|153:21
387:2:3|153:22
387:3:1|154:0-154:1
387:4:9|154:2'''
edits={
'150:15':[('巴尔克，A. P.','安蒂，巴尔克，P.（底本署名：Antti, Balk, P,.）')],
'150:17':[('1954 年。','1954 年，第122页。')],
'151:5':[('《方法论》','《谈谈方法》')],
'151:14-151:15':[('2019 年1 月16 日。','2019 年1 月16 日。网址：https://www.laphamsquarterly.org/roundtable/killing-hypatia（访问日期：2021年8月20日）。\n')],
'152:2':[('第一卷：逻辑','第一部：《逻辑学》')],
'152:3':[('《我的过去与思想》','《往事与随想》')],
'152:13':[('莱布尼茨，G. W. 冯','莱布尼茨，G. W. 冯男爵'),('1916 年。','1916 年，第256页。')],
'152:14':[('《列宁全集》','《列宁全集》（英文版）')],
'152:15':[('卢克莱修，','卢克莱修，提图斯·C.，')],
'152:16':[('《经济学手稿》','《政治经济学批判大纲》')],
'152:17':[('《马克思恩格斯全集》','《马克思恩格斯全集》（英文版）')],
'152:18':[('《马克思恩格斯书信选集，1846—1895》','《马克思恩格斯通信选集，1846—1895》（英文版）')],
'153:0':[('1981 年。','1981 年，第293—294页。')],
'153:22':[('《德国反法西斯斗争》','《在德国反对法西斯的斗争》')],
'154:0-154:1':[('昂格尔','昂格'),('2014 年6 月30 日。','2014 年6 月30 日。网址：https://3quarksdaily.com/3quarksdaily/2014/06/a-little-taste-of-some-empty-ideas.html（访问日期：2021年8月20日）。\n')],
}
allrefs=refs(EN,'383:0-387:5')
keys=[(p,b,j) for p,b,j,l in lines(EN,allrefs)]
rows=[x.split('|') for x in mapping.splitlines()]
starts=[keys.index(tuple(map(int,r[0].split(':')))) for r in rows]+[len(keys)]
units=[]
for i,(_,zr) in enumerate(rows):
 er=[]
 for p,b,j in keys[starts[i]:starts[i+1]]:
  if er and er[-1][:2]==[p,b] and er[-1][3]==j:er[-1][3]+=1
  else:er.append([p,b,j,j+1])
 zrefs=refs(ZH,zr);old=extract(ZH,zrefs);zh=old
 for a,b in edits.get(zr,[]):
  assert a in zh,(zr,a)
  zh=zh.replace(a,b)
 u={'id':f'hp-bib-{i+1:03}','kind':'heading' if i==0 else 'paragraph','source_blocks':er,'supplied_translation_blocks':zrefs,'en':extract(EN,er,True),'supplied_zh':old,'zh':zh,'printed_pages':['PDF '+str(p) for p in dict.fromkeys(r[0] for r in er)],'status':'text_compared_layout_pending'}
 if zr in edits:u['revisions']=[{'from':a,'to':b} for a,b in edits[zr]]
 if zr=='151:14-151:15':u.update(paragraph_starts_en=['Fiorio,','Forbes,'],paragraph_starts_zh=['菲奥里奥，','福布斯，'])
 if zr=='154:0-154:1':u.update(paragraph_starts_en=['Unger,','White,'],paragraph_starts_zh=['昂格，','怀特，'])
 units.append(u)
save('bibliography',units,allrefs,chapter='bibliography',reading_order=130)
