from philosophy_common import *
from philosophy_packet import refs
import sys
sys.path.insert(0,str(R/'tools/python_libs'))
import pymupdf
O=W.parent/'output';A=O/'assets';A.mkdir(parents=True,exist_ok=True)
d=pymupdf.open(W.parent/'The History of Philosophy A Marxist Perspective (Alan Woods).pdf')
for p,name in [(1,'source_cover'),(2,'publisher_logo')]:
 xref=d[p-1].get_images()[0][0];im=d.extract_image(xref)
 (A/(name+'.'+im['ext'])).write_bytes(im['image'])
d[1].get_pixmap(matrix=pymupdf.Matrix(2,2),clip=d[1].get_image_rects(d[1].get_images()[0][0])[0],alpha=False).save(str(A/'publisher_logo.png'))
units=[]
def add(kind,er,zh,**meta):
 er=refs(EN,er) if er else []
 u={'id':f'hp-front-{len(units)+1:03}','kind':kind,'source_blocks':er,'en':extract(EN,er,True) if er else '', 'zh':zh,'printed_pages':['PDF '+str(p) for p in dict.fromkeys(r[0] for r in er)],'status':'text_compared_layout_pending'}
 u.update(meta);units.append(u);return u
cover=next(A.glob('source_cover.*'));logo=A/'publisher_logo.png'
add('figure',None,'原书封面：《马克思主义视角下的哲学史》，艾伦·伍兹著。封面书名自上而下为：《理想国》《尼各马可伦理学》《物性论》《形而上学论》《人性论》《第一哲学沉思集》《纯粹理性批判》《伦理学》《精神现象学》《资本论》。',image='assets/'+cover.name,en='Original book cover: The History of Philosophy: A Marxist Perspective, by Alan Woods.',printed_pages=['PDF 1'],caption_is_editorial=True)
add('figure',None,'韦尔雷德出版社标志。',image='assets/'+logo.name,en='Wellred Books publisher logo.',printed_pages=['PDF 2'],caption_is_editorial=True)
add('paragraph','2:1','《马克思主义视角下的哲学史》\n艾伦·伍兹\n版权 © 韦尔雷德出版社\n保留所有权利。')
add('paragraph','2:2','英国发行：Wellred Books，wellredbooks.net\nPO Box 50525\nLondon, E14 6WG\nbooks@wellredbooks.net')
add('paragraph','2:3','美国发行：Marxist Books，marxistbooks.com\nWR Books\n250 44th Street #208\nBrooklyn\nNew York, NY 11232\nsales@marxistbooks.com')
add('paragraph','2:4','封面由杰西·默里-迪恩（Jesse Murray-Dean）设计，基于埃尔·利西茨基（El Lissitzky）的《无题，1919—1920》（公有领域作品）。电子书由马丁·斯韦恩（Martin Swayne）制作，2021年9月出版。')
add('heading','3:0','原书目录')
chs=[]
for ch in ['introduction']+[f'chapter{i}' for i in range(1,12)]+['bibliography']:
 ps=[json.loads(p.read_text('utf8')) for p in sorted((W/'packets').glob('*.json'))]
 p=next(p for p in ps if p['chapter']==ch)
 u=p['units'][0];chs.append((u['en'],u['zh'],ch))
u=add('list','3:1','\n'.join(z for e,z,ch in chs),items_en=[e for e,z,ch in chs],items_zh=[z for e,z,ch in chs],toc_targets=[ch for e,z,ch in chs])
save('frontmatter',units,refs(EN,'2:1-3:1'),chapter='frontmatter',reading_order=0)
(W/'source_visual_review.json').write_text(json.dumps({'reviewed_source_pages':[1,2,3],'image_pages':[1,2],'images_preserved':[cover.name,logo.name],'notes':'封面、版权页及目录已目视；源PDF仅这两页含栅格图片，正文版式仍需最终输出验收。'},ensure_ascii=False,indent=2),'utf8')
