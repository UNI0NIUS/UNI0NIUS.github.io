from philosophy_common import *
spec=[
 (rr(22,6)+rr(23,0),rr(7,27,31),'paragraph'),
 (rr(23,1),rr(8,0,3),'paragraph'),
 (rr(23,2),rr(8,4,8),'paragraph'),
 (rr(24,0),rr(8,9,12),'paragraph'),
 (rr(24,1),rr(8,13),'separator'),
 (rr(24,2),rr(8,14),'heading'),
 (rr(24,3),rr(8,15,18),'paragraph'),
 (rr(24,4)+rr(25,0),rr(8,19,24),'paragraph'),
 (rr(25,1),rr(8,25,27),'paragraph'),
 (rr(25,2)+rr(26,0),rr(8,28,34)+rr(9,0,2),'paragraph'),
 (rr(26,1),rr(9,3,6),'paragraph'),
 (rr(26,2),rr(9,7,8),'paragraph'),
 (rr(26,3),rr(9,9),'paragraph'),
]
fixes={
 71:[('旧的唯心主义哲学顽固地维持其对社会生活的想象性独立','旧的唯心主义哲学顽固地维持着一种想象中的、独立于社会生活的地位'),('对现存社会的伪装辩护','对现存社会略加掩饰的辩护')],
 76:[('一部公正地享有盛誉的研究','一部享有盛誉、实至名归的研究著作')],
 78:[('成为我们家的坚定朋友','成为我们家的挚友')],
 79:[('几封信','两封信'),('他问我苏塞克斯大学的学习情况','他问起我在苏塞克斯大学的学业')],
 80:[('一个在生活中真正的例外','一个在现实生活中实属罕见的人')],
}
rows=[]
for i,(refs,zrefs,kind) in enumerate(spec,70):
 old=extract(ZH,zrefs);zh=old
 for a,b in fixes.get(i,[]):
  assert a in zh,(i,a,zh)
  zh=zh.replace(a,b)
 if kind=='separator':zh='* * *'
 row={'id':f'hp-intro-{i:03}','kind':kind,'source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['PDF '+str(p) for p in dict.fromkeys(r[0] for r in refs)],'en':extract(EN,refs,True),'supplied_zh':old,'zh':zh,'status':'text_compared_layout_pending'}
 if zh!=old:row['revision_reason']='核对英文，修正直译造成的歧义、习语及数量，恢复原分隔符。'
 rows.append(row)
save('intro05',rows,rr(22,6)+rr(23,0,2)+rr(24,0,4)+rr(25,0,2)+rr(26,0,3))
(W/'checkpoint_intro05.json').write_text(json.dumps({'next_source_pdf_page':28,'next_source_block':0,'next_supplied_pdf_page':9,'next_supplied_block':19,'next_unit':1,'next_chapter':'chapter1','introduction_text_compared':True,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
