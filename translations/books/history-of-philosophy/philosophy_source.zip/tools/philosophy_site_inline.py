from philosophy_common import *

def raw(s,ch):
    out=[];last=0
    pattern=r'\[\[(\d+)\]\]|\$([^$]+)\$|(?:https?|ttps)://[^\s。；，（）\u4e00-\u9fff]+|\n\n'
    for m in re.finditer(pattern,s):
        if m.start()>last:out.append(s[last:m.start()])
        if m[1]:out.append({'type':'note','id':f'hp-{ch}-{m[1]}'})
        elif m[2]:out.append({'type':'math','tex':m[2]})
        elif m[0]=='\n\n':out.append({'type':'break'})
        else:
            url=m[0].rstrip('.,;)');out.append({'type':'link','url':url.replace('\u200b',''),'children':[url]})
            if len(url)<len(m[0]):out.append(m[0][len(url):])
        last=m.end()
    if last<len(s):out.append(s[last:])
    return out
def inline(u,lang,ch):
    s=u[lang]
    if lang!='en':return raw(s,ch)
    runs=[];styles=[]
    for p,b,j,l in lines(EN,u['source_blocks']):
        for span in l['spans']:
            if span['flags']&1:continue
            style=bool(span['flags']&2)
            if styles and styles[-1][0]==style:styles[-1]=(style,styles[-1][1]+span['text'])
            else:styles.append((style,span['text']))
        if styles:styles[-1]=(styles[-1][0],styles[-1][1]+' ')
    protected=[m.span() for m in re.finditer(r'\$[^$]+\$|\[\[\d+\]\]|(?:https?|ttps)://\S+',s)]
    for style,t in styles:
        t=re.sub(r'\s+',' ',t).strip()
        if style and t:
            for m in re.finditer(r'(?<!\w)'+re.escape(t)+r'(?!\w)',s):
                if not any(m.start()<b and m.end()>a for a,b in protected):runs.append(m.span())
    out=[];last=0
    for a,b in sorted(set(runs)):
        if a<last:continue
        out+=raw(s[last:a],ch);out.append({'type':'em','children':raw(s[a:b],ch)});last=b
    return out+raw(s[last:],ch)
def flat(ts):
    return ''.join(t if isinstance(t,str) else '[['+t['id'].split('-')[-1]+']]' if t['type']=='note' else '$'+t['tex']+'$' if t['type']=='math' else '\n\n' if t['type']=='break' else flat(t.get('children',[])) for t in ts)
def noteids(ts):
    return [n for t in ts if isinstance(t,dict) for n in ([t['id']] if t['type']=='note' else noteids(t.get('children',[]))+[x for row in t.get('rows',[]) for cell in row for x in noteids(cell)])]
