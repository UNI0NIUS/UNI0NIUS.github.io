from philosophy_common import *
spec=[
 (rr(13,6)+rr(14,0),rr(4,21,24),'paragraph'),
 (rr(14,1),rr(4,25,27),'paragraph'),
 (rr(14,2),rr(4,28),'paragraph'),
 (rr(14,3),rr(4,29,32)+rr(5,0,2),'quote'),
 (rr(15,0)+rr(16,0),rr(5,3,24),'quote'),
 (rr(16,1),rr(5,25,26),'paragraph'),
 (rr(16,2)+rr(17,0),rr(5,27,30),'paragraph'),
 (rr(17,1,3),rr(5,31),'heading'),
 (rr(17,4),rr(5,32)+rr(6,0,1),'paragraph'),
 (rr(17,5),rr(6,2,4),'paragraph'),
]
fixes={
 40:[('国家、政权和帝国','国度、国家和帝国')],
 41:[('然而，正因为哲学家（如同其他人一样）会受到','不过，哲学家（如同其他人一样）可能受到'),('的影响，因此在某些阶段','的影响；就此而言，在某些阶段')],
 43:[('它们有一个史前时期的库存，是在历史时期已经被发现并继承下来的，即我们今天会称之为“胡说八道”的东西','它们有一批史前遗留下来的材料，在进入历史时期时就已存在并被继承下来，即我们今天会称之为“胡说八道”的东西'),('⻤神','鬼神'),('消极的经济基础','否定性的经济基础')],
 44:[('因此他本人是一个绝对主义者','而他本人是一个君主专制主义者'),('在哲学上演奏第一小提琴','在哲学上起主导作用'),('以及一般的发展','以及当时文学的普遍繁荣'),('我认为，经济发展在这些领域中也最终确立了至高无上的地位','我认为，经济发展在这些领域中也具有最终的支配作用，这一点是确定的'),('整个宏大过程','整个广大的发展过程')],
 46:[('不是断言并仅仅剖析曾经存在过的每一个思想学派','不是肯定并仅仅剖析曾经存在过的每一个思想学派')],
 47:[('无知即福，自作聪明实为愚蠢','若无知是福，明智便是愚蠢')],
}
rows=[]
for i,(refs,zrefs,kind) in enumerate(spec,40):
 old=extract(ZH,zrefs);zh=old
 for a,b in fixes.get(i,[]):
  assert a in zh,(i,a,zh)
  zh=zh.replace(a,b)
 row={'id':f'hp-intro-{i:03}','kind':kind,'source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['PDF '+str(p) for p in dict.fromkeys(r[0] for r in refs)],'en':extract(EN,refs,True),'supplied_zh':old,'zh':zh,'status':'text_compared_layout_pending'}
 if zh!=old:row['revision_reason']='逐段核对英文：补回文学繁荣的漏译，修正哲学主导地位的习语、君主专制术语、条件关系和标题语义。'
 if i==43:row['editor_note']='“否定性的经济基础”对应原文 negative economic basis，紧接着的原文将它与史前经济发展的低下水平联系起来。'
 if i==46:row['editor_note']='原文使用 assert and merely dissect，措辞略显生硬；译文保留其肯定／剖析的表述。'
 rows.append(row)
zrefs=rr(9,15,16);old=extract(ZH,zrefs)
notes=[{'id':'hp-intro-note-4','kind':'note','note_number':4,'source_blocks':rr(27,0),'supplied_translation_blocks':zrefs,'printed_pages':['PDF 27'],'en':extract(EN,rr(27,0),True),'supplied_zh':old,'zh':old,'editor_note':'卷页信息按英文原书所引版本保留，不能据此定位中文版本。','status':'text_compared_layout_pending'}]
save('intro03',rows,rr(13,6)+rr(14,0,3)+rr(15,0)+rr(16,0,2)+rr(17,0,5),notes)
(W/'checkpoint_intro03.json').write_text(json.dumps({'next_source_pdf_page':18,'next_source_block':0,'next_supplied_pdf_page':6,'next_supplied_block':5,'next_unit':50,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
