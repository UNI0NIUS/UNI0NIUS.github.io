"""Canonical source references for proofreading the supplied translation."""
from pathlib import Path
import json,re,unicodedata
R=Path(__file__).resolve().parents[1];W=R/'Defending Materialism/work'
EN=json.loads((W/'source_pages.json').read_text('utf8'))
ZH=json.loads((W/'supplied_translation_pages.json').read_text('utf8'))
RADICALS={'⻔':'门','⻅':'见','⻓':'长','⻄':'西','⻙':'韦','⻢':'马','⻬':'齐','⻝':'食','⻩':'黄','⻨':'麦','⻛':'风','⻰':'龙','⻳':'龟','⻚':'页','⻘':'青','⺠':'民'}
RADICALS.update({'⺎':'兀','⻁':'虎','⻆':'角','⻉':'贝','⻋':'车','⻜':'飞','⻣':'骨','⻥':'鱼','⻦':'鸟','⻮':'齿'})
def normzh(s):
    return ''.join(RADICALS.get(c,unicodedata.normalize('NFKC',c)) if '\u2e80'<=c<='\u2fff' else c for c in s)
def block(pages,p,b):return next(x for x in pages[p-1]['blocks'] if x['block']==b)
def lines(pages,refs):
    for ref in refs:
        p,b=ref[:2];ls=block(pages,p,b)['lines']
        for j in range(ref[2] if len(ref)>2 else 0,ref[3] if len(ref)>2 else len(ls)):yield p,b,j,ls[j]
def extract(pages,refs,english=False):
    out=[]
    for p,b,j,l in lines(pages,refs):
        ss=[]
        for s in l['spans']:
            t=s['text']
            if english and s['flags']&1 and t.isdigit():
                t='[[2]][[3]]' if (p,b,t)==(17,2,'23') else '[['+t+']]'
            ss.append(t)
        out.append(''.join(ss))
    t='\n'.join(out)
    if english:
        # These wraps retain a lexical hyphen; all others remain auditable verbatim.
        t=re.sub(r'-\n', '-',t)
        return re.sub(r'\s+',' ',t).strip().lstrip('● ')
    t=normzh(t)
    t=re.sub(r'([⁰¹²³⁴⁵⁶⁷⁸⁹]+)',lambda m:'[['+unicodedata.normalize('NFKC',m[1])+']]',t)
    return t.replace('\n','').strip().lstrip('• ')
def rr(p,a,z=None):return [[p,b] for b in range(a,(z if z is not None else a)+1)]
def note_groups(refs):
    groups=[];cur=[];number=None
    for p,b,j,l in lines(EN,refs):
        # Actual note labels are followed by a tab. A wrapped volume/issue
        # number or a mathematical numeral followed by a space is not a label.
        text=''.join(s['text'] for s in l['spans']);m=re.match(r'^(\d+)\t',text)
        if m:
            if cur:groups.append((number,cur))
            number=int(m[1]);cur=[]
        cur.append([p,b,j,j+1])
    if cur:groups.append((number,cur))
    return groups
def save(name,chapter,units,notes,expected):
    used=[(p,b,j) for u in units for p,b,j,l in lines(EN,u['source_blocks'])]
    want={(p,b,j) for p,b,j,l in lines(EN,expected)}
    assert set(used)==want,(want-set(used),set(used)-want)
    assert len(used)==len(set(used)),'Duplicate source lines'
    refs=[]
    for u in units:
        a=re.findall(r'\[\[(\d+)\]\]',u['en']);b=re.findall(r'\[\[(\d+)\]\]',u['zh'])
        assert a==b,(u['id'],a,b)
        refs+=a
    assert sorted(set(map(int,refs)))==[n['note_number'] for n in notes]
    data={'packet':name,'chapter':str(chapter),'reading_order':chapter*10,'units':units,'notes':notes,'full_book_complete':False,'layout_review':'pending'}
    (W/'packets'/f'{name}.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),'utf8')
    audit={'scope':name,'units':len(units),'source_lines':len(used),'notes':len(notes),'source_line_coverage':'pass','note_marker_alignment':'pass','layout':'pending','full_book_complete':False}
    (W/f'{name}_text_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),'utf8')
    print(json.dumps(audit))
