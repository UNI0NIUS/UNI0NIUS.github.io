from philosophy_common import *
spec=[(rr(65,0,1),rr(23,20),'heading'),(rr(65,2),rr(23,21,23),'paragraph'),(rr(65,3),rr(23,24,27),'paragraph'),(rr(65,4)+rr(66,0),rr(23,28,32),'paragraph'),(rr(66,1),rr(23,33)+rr(24,0,6),'paragraph'),(rr(66,2),rr(24,7),'paragraph'),(rr(66,3),rr(24,8,9),'quote'),(rr(67,0),rr(24,10),'paragraph'),(rr(67,1),rr(24,11),'quote'),(rr(67,2),rr(24,12,13),'quote'),(rr(67,3),rr(24,14,19),'paragraph'),(rr(67,4),rr(24,20),'paragraph'),(rr(67,5)+rr(68,0),rr(24,21,23),'quote'),(rr(68,1),rr(24,24),'paragraph'),(rr(68,2),rr(24,25,27),'quote'),(rr(68,3),rr(24,28,32),'paragraph'),(rr(68,4)+rr(69,0),rr(25,0,5),'paragraph'),(rr(69,1),rr(25,6,8),'paragraph'),(rr(69,2),rr(25,9,12),'paragraph'),(rr(69,3)+rr(70,0),rr(25,13,17),'paragraph'),(rr(70,1),rr(25,18,21),'paragraph'),(rr(70,2),rr(25,22,25),'paragraph'),(rr(70,3)+rr(71,0),rr(25,26,31),'paragraph'),(rr(71,1),rr(25,32,34),'paragraph')]
fixes={
125:[('在科学仍与宗教纠缠不清的当下','在这里所讨论的科学仍与宗教纠缠不清的情形中')],
127:[('科学之王','科学的女王'),('而仅仅是旨在对相应现象进行更便捷、更有用的描述','而是任意约定，旨在对相应现象作出更便捷、更“有用”的描述')],
133:[('我们没有任何由线、面或点构成的经验','我们没有经验到任何仅由线、面或点构成的东西'),('在定义上或许先于实体，但因此并不意味着它们在实体上先于实体','在定义上或许先于物体，但并不因此就在实体上先于物体')],
134:[('唯一的例外','例外'),('“一超过”','“多出一”')],
138:[('数字音节','数字发音')],
140:[('“计算”一词由此衍生','英语calculate（计算）由此衍生')],
141:[('+ 和-','+ 和−')],
146:[('2 的平方根无法用任何整数表示','2 的平方根无法用任何数表示')],
}
rows=[]
for i,(refs,zrefs,kind) in enumerate(spec,124):
 old=extract(ZH,zrefs);zh=old
 for a,b in fixes.get(i,[]):
  assert a in zh,(i,a,zh)
  zh=zh.replace(a,b)
 row={'id':f'hp-ch01-{i:03}','kind':kind,'source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['PDF '+str(p) for p in dict.fromkeys(r[0] for r in refs)],'en':extract(EN,refs,True),'supplied_zh':old,'zh':zh,'status':'text_compared_layout_pending'}
 if zh!=old:row['revision_reason']='整节对照，补arbitrary conventions漏译，区分物体与实体，修正历史语境误作当下，保留并说明原书数学措辞问题。'
 if i==128:row['editor_note']='原文将点称为single-dimensional（一维的），这里照录；通常几何学中的点没有维度。'
 if i==146:row['editor_note']='底本写作Hippius，旧译作希帕索斯，沿用旧译名并保留英文。原文“平方根2无法用任何数表示”措辞不确切；按紧邻的整数比及无理数讨论，应理解为不能表示为两个整数之比。译文照录原句，不以旧译的“整数”替代。'
 rows.append(row)
notes=[]
for n in range(31,36):
 refs=rr(72,n-10);zrefs=rr(27,n-22);old=extract(ZH,zrefs)
 notes.append({'id':f'hp-ch01-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['PDF 72'],'en':extract(EN,refs,True),'supplied_zh':old,'zh':old,'status':'text_compared_layout_pending'})
save('ch01k',rows,rr(65,0,4)+rr(66,0,3)+rr(67,0,5)+rr(68,0,4)+rr(69,0,3)+rr(70,0,3)+rr(71,0,1),notes,chapter='chapter1',reading_order=20)
(W/'checkpoint_ch01k.json').write_text(json.dumps({'next_source_pdf_page':73,'next_source_block':0,'next_supplied_pdf_page':27,'next_supplied_block':14,'next_unit':1,'next_chapter':'chapter2','chapter1_text_compared':True,'full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
