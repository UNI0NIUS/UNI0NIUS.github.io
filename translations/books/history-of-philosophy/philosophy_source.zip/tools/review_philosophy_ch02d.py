from philosophy_common import *
spec=[(rr(83,0),rr(31,27),'heading'),(rr(83,1),rr(31,28,34),'paragraph'),(rr(83,2),rr(31,35)+rr(32,0),'paragraph'),(rr(83,3),rr(32,1),'paragraph'),(rr(83,4),rr(32,2,3),'quote'),(rr(83,5),rr(32,4),'paragraph'),(rr(84,0),rr(32,5),'quote'),(rr(84,1),rr(32,6,10),'paragraph'),(rr(84,2),rr(32,11,12),'quote'),(rr(84,3),rr(32,13,15),'paragraph'),(rr(84,4)+rr(85,0),rr(32,16,19),'paragraph'),(rr(85,1),rr(32,20,23),'paragraph'),(rr(85,2),rr(32,24,26),'paragraph'),(rr(85,3),rr(32,27),'paragraph'),(rr(85,4),rr(32,28,29),'quote'),(rr(85,5)+rr(86,0),rr(32,30)+rr(33,0,1),'paragraph'),(rr(86,1),rr(33,2,4),'paragraph'),(rr(86,2),rr(33,5,10),'paragraph'),(rr(86,3),rr(33,11),'paragraph'),(rr(86,4)+rr(87,0),rr(33,12,14),'quote')]
fixes={40:[('后面的物体与前面的物体保持固定距离并运动得更快','后面的物体起初与前面的物体相隔一定距离，且运动得更快')],43:[('它们在彼此之间是有限的','它们彼此限定')],45:[('相反，当我们承认','……相反，当我们承认')],47:[('可以求出几何级数无限级数','可以求出无穷等比级数之和')],49:[('2 的平方根无法用一个整数表示','2 的平方根无法用一个数表示'),('结果总是介于两个数之间','结果总是处于两个数的中间')]}
rows=[]
for i,(refs,zrefs,kind) in enumerate(spec,39):
 old=extract(ZH,zrefs);zh=old
 for a,b in fixes.get(i,[]):
  assert a in zh,(i,a,zh)
  zh=zh.replace(a,b)
 row={'id':f'hp-ch02-{i:03}','kind':kind,'source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['PDF '+str(p) for p in dict.fromkeys(r[0] for r in refs)],'en':extract(EN,refs,True),'supplied_zh':old,'zh':zh,'status':'text_compared_layout_pending'}
 if zh!=old:row['revision_reason']='整节核对：明确起初间距而非运动中保持间距，补回级数求和之“和”及引文省略号；原书数学问题照录另注。'
 if i==40:row['editor_note']='原文由领先100米直接写到1米，译文照录。按本段十倍速度的设定，阿基里斯再跑100米时，乌龟应再前进10米，故该步应为领先10米，下一步才为1米。'
 if i==47:row['editor_note']='此处引文以公比小于1描述收敛条件，按原文保留；一般实数等比级数的收敛条件为公比绝对值小于1。'
 if i==49:row['editor_note']='原文先写as a number，段末又写in a whole number，均照录。无理数的关键在于不能表示为两个整数之比，而不是不能表示为数或整数；“总在两数中间”也是底本表述。'
 rows.append(row)
notes=[]
for n in range(15,22):
 refs=rr(119,n-13);zrefs=rr(45,n-1);old=extract(ZH,zrefs)
 notes.append({'id':f'hp-ch02-note-{n}','kind':'note','note_number':n,'source_blocks':refs,'supplied_translation_blocks':zrefs,'printed_pages':['PDF 119'],'en':extract(EN,refs,True),'supplied_zh':old,'zh':old,'status':'text_compared_layout_pending'})
save('ch02d',rows,rr(83,0,5)+rr(84,0,4)+rr(85,0,5)+rr(86,0,4)+rr(87,0),notes,chapter='chapter2',reading_order=30)
(W/'checkpoint_ch02d.json').write_text(json.dumps({'next_source_pdf_page':87,'next_source_block':1,'next_supplied_pdf_page':33,'next_supplied_block':15,'next_unit':59,'next_chapter':'chapter2','full_book_complete':False},ensure_ascii=False,indent=2),'utf8')
