## 图片来源

〔原书第365页〕

以下条目按图片所在页码排列。

- **12**　19世纪晚期照片。
- **16**　《未来的大教堂；魏玛国立包豪斯宣言与纲领》（*Kathedrale der Zukunft, Manifest und Programm des Staatlichen Bauhauses in Weimar*）, Berlin, 1919。
- **21**　Victor Hugo, 《巴黎圣母院》（*Notre-Dame de Paris*）, Paris, 1831。
- **27**　Augustus W. N. Pugin, 《对比：十四、十五世纪的高贵建筑与当代同类建筑的比较，展示当今品味的衰落，并配以相应文字》（*Contrasts: Or, A Parallel Between the Noble Edifices of the Fourteenth and Fifteenth Centuries and Similar Buildings of the Present Day. Shewing the Present Decay of Taste. Accompanied by Appropriate Text*）, 自费出版，第1版，伦敦, 1836。
- **31**　Paul Schmitthenner, 《德国住宅》（*Das deutsche Wohnhaus*）, 《建筑造型》（*Baugestaltung*）第I卷, Wittwer, Stuttgart, 1932。
- **38**　乌古尔·坦耶利（Uğur Tanyeli）档案，无日期，可能印制于1909—1928年间的文件。
- **49**　摄影：乌古尔·坦耶利（Uğur Tanyeli）。
- **53**　Johann Fischer von Erlach, 《历史建筑设计纲要：依据史书、纪念币、遗迹及取得的可靠图样，呈示古代与异域民族的各类著名建筑。第一书：为时间湮没的古代犹太人、埃及人、叙利亚人、波斯人与希腊人的建筑方式；第二书：鲜为人知的古罗马建筑；第三书：欧洲内外的异域建筑，如阿拉伯、土耳其及较新的波斯、暹罗、中国与日本建筑；第四书：作者构思并绘制的若干建筑》（*Entwurff einer historischen Architectur: in Abbildung unterschiedener berühmten Gebäude, des Alterthums, und fremder Völcker, umb aus den Geschicht-Büchern. Gedächtnüss-Müntzen. Ruinen, und eingeholten wahrhafften Abrissen, vor Augen zu stellen. in dem ersten Buche. Die von der Zeit vergrabene Bau-Arten der alten Jüden, Egyptier, Syrer, Perser, und Griechen. in dem andren. Alte unbekante römische. in dem dritten. Einige fremde in- und ausser-europäische, als der Araber, und Türcken, etc. auch neue persianische, siamitische, sinesische und japonesische Gebäude. in dem vierten. Einige Gebäude von des Autoris Erfindung und Zeichnung*）, 维也纳, 1721。
- **57**　摄影：乌古尔·坦耶利（Uğur Tanyeli）。
- **64**　Jean Rondelet, 《建造艺术的理论与实践论》（*Traité théorique et pratique de l'art de bâtir*）, 第5卷, Paris, 1817。
- **70**　摄影：乌古尔·坦耶利（Uğur Tanyeli）。
- **83**　https://www.pagethink.com/media/uploads/news-images/lg_hbj_architecture_firm_rankings.jpg
- **86**　《魏玛国立包豪斯，1919—1923》（*Staatliches Bauhaus in Weimar 1919–1923*）, Bauhaus Verlag, F. Bruckmann, 1923。

〔原书第366页〕

- **87**　http://4.bp.blogspot.com/wa69sAoiMXY/VCQRmZOBUSI/AAAAAAAAAiQ/4Rfyyycz8U4/s1600/peter%2Beisenman.jpg
- **96**　Edhem Paşa 等，《奥斯曼建筑原理》（*Usul-i Mi'mari-i Osmani / L'architecture ottomane / Die ottomanische Baukunst*）, L'Imprimerie et lithographie centrales, İstanbul, 1873。
- **99**　摄影：乌古尔·坦耶利（Uğur Tanyeli）。
- **100**　Gottfried Semper, 《技术与构造艺术中的风格，或实用美学》（*Style in the Technical and Tectonic Arts, or, Practical Aesthetics*）, Harry Francis Mallgrave、Michael Robinson译，导论：Harry Francis Mallgrave，Getty Research Institute Texts & Documents，第666页。
- **105**　摄影：乌古尔·坦耶利（Uğur Tanyeli）。
- **108**　《最低生存标准的住宅》（*Die Wohnung für das Existenzminimum*），展览海报，1929年。
- **117**　Ludwig Hilberseimer, 《大都市建筑》（*Großstadtarchitektur*）, Stuttgart, 1927。
- **123**　Moisei Ginzburg, 《风格与时代》（*Stil' i epokha*）, Gosizdat, 莫斯科, 1924。
- **127**　Karel Teige, 《最小住宅》（*Nejmenší byt*）, 布拉格, 1932。
- **138**　Andrea Memmo, 《已故卡洛·德·孔蒂·洛多利修士构思并仅以口头即兴讲给友人的寓言》（*Apologhi immaginati, e sol estemporeamente in voce esposti agli amici suoi dal fu Fra Carlo De Conti Lodoli*）, Bassano, 1787，卷首插图。
- **141**　http://teachmiddleeast.lib.uchicago.edu/foundations/golden-age-islam/images/islam-08.jpg
- **143**　摄影：乌古尔·坦耶利（Uğur Tanyeli）。
- **145**　19世纪晚期照片。
- **146**　《弗兰克·劳埃德·赖特的建成作品与设计》（*Ausgeführte Bauten und Entwürfe von Frank Lloyd Wright*）, Ernst Wasmuth A.-G., Berlin, 1910。
- **148**　https://ksamedia.osu.edu/sites/default/files/originals/boston-cambridge_ma_mit_chapel_eero_sarrinen_1955_2.jpg
- **149**　© Tadao Ando Architect & Associates。
- **159**　Bruno Munari，〈在一把不舒适的扶手椅上寻找舒适〉（Ricerca di comodità in una poltrona scomoda），*Domus*, 202，1944年10月。
- **162**　http://www.casa-in-italia.com/artpx/ignazio/ignazio.htm
- **165**　Johann Winckelmann, 《古代艺术史》（*Geschichte der Kunst des Alterthums*）, 第1卷, Dresden, 1764。
- **172**　摄影：Gülsün Tanyeli。
- **173**　摄影：Gülsün Tanyeli。
- **183**　*AU*, 91/09，第57页。
- **186**　摄影：乌古尔·坦耶利（Uğur Tanyeli）。
- **192**　摄影：Guillaume Berggren。
- **199**　Eugène Viollet-le-Duc, 《十一至十六世纪法国建筑详解辞典》（*Dictionnaire raisonné de l'architecture française du XIe au XVIe siècle*）, 第1卷, Édition Bance-Morel, Paris, 1854。

〔原书第367页〕

- **209**　Hermann Muthesius, 《风格建筑与营造艺术：十九世纪建筑的变迁及其当下立场》（*Stilarchitektur und Baukunst. Wandlungen der Architektur im XIX. Jahrhundert und ihr heutiger Standpunkt*）, K. Schimmelpfeng, Mülheim/Ruhr, 1901。
- **214**　摄影：乌古尔·坦耶利（Uğur Tanyeli）。
- **218**　Sebastiano Serlio, 《建筑五种样式的一般规则：托斯卡纳式、多立克式、爱奥尼式、科林斯式与混合式，附大体符合维特鲁威学说的古代范例》（*Regole generali di architettura sopra le cinque maniere de gli edifici: cioè, thoscano, dorico, ionico, corinthio, et composito, con gli essempi dell'antiquità, che per la magior parte concordano con la dottrina di Vitruvio*）, 第4卷, 威尼斯，1587年。（校注：图源表底本记为1587年，但第218页所印标题页的罗马数字M.D.XXXVII为1537年；保留原表记录，并提示这一冲突。）
- **225**　Giacomo Barozzi da Vignola, 《建筑五种柱式规则》（*Regola delli cinque ordini d'architettura*）, Siena, 1635？
- **226**　*AU*, 1978/5，《查尔斯·摩尔的作品》（*The Work of Charles Moore*），第293页。
- **228**　Atelier Lefebvre et Mommerque，1734—1737。
- **231**　Antoine Ignace Melling, 《君士坦丁堡与博斯普鲁斯海峡两岸风景游记》（*Voyage pittoresque de Constantinople et des rives du Bosphore*）, Treuttel et Würtz, Paris, 1819。
- **233**　19世纪晚期明信片。
- **242**　Hans Holbein，《大使们》（Elçiler），1533年，英国国家美术馆，伦敦。（校注：底本此处标作242页；实际插图位于244页。）
- **247**　Kenzo Tange, Walter Gropius（导论）, Yasuhiro Ishimoto（摄影）, 《桂离宫：日本建筑中的传统与创造》（*Katsura: Tradition and Creation in Japanese Architecture*）, Yale University Press, New Haven, 1960。
- **260**　摄影：乌古尔·坦耶利（Uğur Tanyeli）。
- **263**　1930年代宣传明信片。
- **265**　19世纪晚期手工上色版画。
- **269**　Paul Schultze-Naumburg, 《艺术与种族》（*Kunst und Rasse*）, J. F. Lehmanns Verlag, Berlin，第1版，1928年。
- **270**　同上。
- **275**　Guy Debord，〈巴黎心理地理指南〉（Guide psychogéographique de Paris），1957年。
- **278**　摄影：乌古尔·坦耶利（Uğur Tanyeli）。
- **281**　Dino Alfieri、Luigi Freddi（编），《法西斯革命展览：国家法西斯党进军罗马十周年》（*Mostra della rivoluzione fascista: Partito Nazionale Fascista primo decennale della Marcia su Roma*）, Direttorio Nazionale del Partito Nazionale Fascista, Roma, 1933。
- **287**　http://www.ucesinsaat.com.tr/proje/1
- **288**　Augustus Welby Northmore Pugin, 《英国教会建筑的现状》（*The Present State of Ecclesiastical Architecture in England*）, C. Dolman, 1843，第1图版。
- **294**　Jean Baptiste Vanmour，〈帕特罗纳·哈利勒〉（Patrona Halil），荷兰国立博物馆, Amsterdam。
- **298**　https://www.6sqft.com/wp-content/uploads/2015/11/hooverville-22.jpg
- **300**　伊斯坦布尔大学图书馆。
- **306**　摄影：Jeff Widener。
- **307**　摄影：乌古尔·坦耶利（Uğur Tanyeli）。

〔原书第368页〕

- **310**　摄影：Ela Tusavul。
- **319**　Robert Venturi, Denise Scott Brown, Steven Izenour, 《向拉斯维加斯学习》（*Learning from Las Vegas*）, MIT Press, Cambridge, Mass., 1972。
- **325**　摄影：Ela Tusavul。
- **330**　Bruno Taut, 《一座住宅》（*Ein Wohnhaus*）, Frankh'sche Verlagshandlung W. Keller & Co., Stuttgart, 1927。
- **335**　Robert Kerr, 《绅士之家；或，从牧师住宅到宫殿，如何规划英国住宅》（*The Gentleman's House, or How to Plan English Residences from the Parsonage to the Palace*）, John Murray, 伦敦, 1865。
- **336**　Hermann Muthesius, 《英国住宅：发展、条件、布局、建造、陈设与室内空间》（*Das englische Haus: Entwicklung, Bedingungen, Anlage, Aufbau, Einrichtung und Innenraum*）, 3卷, Ernst Wasmuth, Berlin, 1908–1911。
- **338**　阿道夫·路斯出版的《他者》（Das Andere）杂志首页。
- **341**　http://dirty-furniture.com/wp-content/uploads/2015/10/Kitchen-Debate.jpg
- **344**　摄影：乌古尔·坦耶利（Uğur Tanyeli）。
- **347**　佩罗夫的陀思妥耶夫斯基肖像，莫斯科国立特列季亚科夫画廊；以及瓦西里·马特的普希金版画。
- **352**　美国国会图书馆收藏，华盛顿特区。
