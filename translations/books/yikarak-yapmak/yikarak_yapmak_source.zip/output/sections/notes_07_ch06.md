## VI

[1] 夏尔·波德莱尔，〈1855年世界博览会，美术〉（"Exposition universelle, 1855, beaux arts"），载《夏尔·波德莱尔全集》第2卷，《美学珍玩》（*Oeuvres complètes de Charles Baudelaire, II, Curiosités esthétiques*），巴黎：Michel Lévy Frères，1868年，第213页。

[2] 以上内容参见鲍里斯·亨尼希，〈四因说〉（"The Four Causes"），《哲学杂志》（*The Journal of Philosophy*），第106卷第3期，2009年，第137—160页。维特鲁威与这些原因之间的关系，是我自己界定的。

[3] 实际上，关于这个问题已有若干严肃研究。例如，爱德华·罗伯特·德·祖尔科，《功能主义理论的起源》（*Origins of Functionalist Theory*），纽约：哥伦比亚大学出版社，1957年。

[4] 乌古尔·坦耶利，〈阅读城市历史地层——一位建筑史学家的意见〉（"Reading Urban Historical Strata – An Architectural Historian's Opinion"），载《城市历史地层：从士麦那到伊兹密尔》（*Urban Historical Stratum: From Smyrna to İzmir*），A. E. 格克苏与 Ş. 格克琴·敦达尔编，伊兹密尔：多库兹埃于尔大学，2010年，第14—19页。

[5] 路易斯·H. 沙利文，《一种观念的自传》（*The Autobiography of an Idea*），纽约：多佛出版社，1956年（初版由AIA出版，1924年），第258页。

[6] 仅从风格问题的语境来接近这个主题，就已经很有启发性。早在1820年代，一场围绕“我们应当以哪种风格建造？”（"in welchem Stil sollen wir bauen?"）这一问题的讨论，就在整个欧洲、尤其在德国变得至关重要。关于这场讨论的原始文本，参见海因里希·许布施等，《我们应当以何种风格建造？德国建筑风格之争》（*In What Style Should We Build? The German Debate on Architectural Style*），沃尔夫冈·赫尔曼导论并翻译，洛杉矶：盖蒂出版社，1992年。

[7] 祖尔科，同上书；他应当是最早区分功能主义两条路线（依托机械类比与生物类比）的研究者。罗泽玛丽·哈格·布莱特也同意他的看法：罗泽玛丽·哈格·布莱特，〈导论〉（"Introduction"），载阿道夫·贝内，《现代功能建筑》（*The Modern Functional Building*），迈克尔·罗宾逊译，洛杉矶：盖蒂研究所，1996年，第9页及以下。

[8] 彼得·柯林斯，《现代建筑中的观念变迁，1750—1950》（*Changing Ideals in Modern Architecture, 1750–1950*），伦敦：Faber and Faber，1965年，第149—182页。

[9] 福特也提出了类似的三重表述：阿德里安·福特，《词语与建筑：现代建筑词汇》（*Words and Buildings: A Vocabulary of Modern Architecture*），伦敦：Thames & Hudson，2000年，第174—195页（“功能”一章）。

[10] 据我所知，福特是第一位论及数学类比的作者。参见同上书，第174—175页。

[11] 关于数学中函数概念的简史，参见若昂·佩德罗·蓬特，〈函数概念的历史及其若干教育意涵〉（"The History of the Concept of Function and Some Educational Implications"），*The Mathematics*（校注：完整刊名为[*The Mathematics Educator*](https://repositorio.ulisboa.pt/entities/publication/1ae258f5-f4f0-465a-8700-b3b104958c29)），第3卷第2期。core.ac.uk/download/files/489/12423242.pdf（访问日期：2016年7月26日）。

[12] 最早主张洛多利把“功能”取自数学的人：约瑟夫·里克沃特，〈洛多利论功能与再现〉（"Lodoli on Function and Representation"），《建筑评论》（*Architectural Review*），第161卷，1976年7月。重印于：约瑟夫·里克沃特，《技艺的必然性》（*Necessity of Artifice*），伦敦：Academy Editions，1982年，第115—121页。

[13] 一项聚焦于视觉性之客观建构的全面历史分析：洛兰·达斯顿与彼得·加利森，《客观性》（*Objectivity*），纽约：Zone Books，2010年。

[14] 布鲁诺·穆纳里，《在不舒服的扶手椅中寻找舒适／Seeking Comfort in an Uncomfortable Chair》（*Ricerca della comodità in una poltrona scomoda*），伊莎贝尔·巴特斯译，曼托瓦：Maurizio Corraini s.r.l.，2014年。最初以文章形式发表于《Domus》第202期，1944年10月。
