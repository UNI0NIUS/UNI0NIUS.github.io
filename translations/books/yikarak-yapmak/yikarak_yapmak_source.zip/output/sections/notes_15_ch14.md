## XIV

[1] 莱夫·杰拉姆，《街头生活：欧洲二十世纪未被讲述的历史》（*Streetlife, The Untold History of Europe's Twentieth Century*），牛津：牛津大学出版社，2011年，第385页。

[2] 参见一位重要奥斯曼史家杰马尔·卡法达尔的一份易读的通俗评述：Esra Yalçınalp（访谈），〈发动政变的是苏丹，而非禁卫军〉（"Yeniçeri Değil Padişah Darbeci"），《阿特拉斯历史》（*Atlas Tarih*），第20期，2013年6—7月，第54—63页，尤其第62页。

[3] ephemeralnewyork.wordpress.com/2008/10/08/the-hoovervilles-of-new-york-city/（访问日期：2013年6月17日）。

[4] 谢姆达尼扎德·苏莱曼，《历史之镜》（*Müriyü't-Tevarih*），贝亚泽特国家图书馆，第344a叶；转引自穆尼尔·阿克特佩，《帕特罗纳起义（1730）》（*Patrona İsyanı (1730)*），伊斯坦布尔，1958年，第44页。

[5] 佚名，18世纪，《伊斯坦布尔奇谈书》（*İstanbul'a Dair Risale-i Garibe*），哈亚蒂·德韦利编，伊斯坦布尔：Kitabevi，1998年。

[6] 转引自 希琳·哈马德，《城市的欢愉：十八世纪的伊斯坦布尔》（*The City's Pleasures, Istanbul in the Eighteenth Century*），西雅图、伦敦：华盛顿大学出版社，2008年，第33—34页；土耳其语译本：《欢愉之城：十八世纪的伊斯坦布尔》（*Şehr-i Sefa: 18. Yüzyılda İstanbul*），伊尔克努尔·居泽尔译，伊斯坦布尔：İletişim，2010年。原注出自谢姆达尼扎德，同上。两百年之后，哈马德还能说这位奥斯曼批评者的想法也许是对的，这表明当下的奥斯曼史学今天仍受同样的堵塞之苦。

[7] 毛拉·达武特扎德·穆斯塔法·纳齐姆·埃尔祖鲁米，《梦中进步与伊斯兰文明之景象》（*Rüyada Terakki ve Medeniyet-i İslamiyeyi Rüyet*），恩金·克勒奇编，伊斯坦布尔：海峡大学出版社，2012年，第216页及以下。
