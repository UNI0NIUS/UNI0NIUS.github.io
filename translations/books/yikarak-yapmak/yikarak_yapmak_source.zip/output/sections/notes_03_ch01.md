## II

[1] 理查德·森内特，《外国人：关于流亡的两篇文章》（*The Foreigner: Two Essays on Exile*），伦敦：Notting Hill Editions，2011年，第viii页；土耳其语译本：《外国人：关于流亡的两篇文章》（*Yabancı: Sürgün Üzerine İki Deneme*），T. Birkan译，伊斯坦布尔：Metis，2014年。

[2] 拉里·希纳，《艺术的发明：一部文化史》（*The Invention of Art: A Cultural History*），芝加哥与伦敦：芝加哥大学出版社，2001年；土耳其语译本：《艺术的发明：一部文化史》（*Sanatın İcadı: Bir Kültür Tarihi*），İsmail Türkmen译，伊斯坦布尔：Ayrıntı，2004年。

[3] 无论是arkhitekton与architectura，还是（比前者更甚的）mi‘mar与mi‘mari，其语义变迁史都尚未得到充分研究。但可以确定的是，二者都经历了从“做事者”到“事”的语言学形成过程。阿拉伯语中的经历则因今天使用muhandis而非mi‘mar来对应architect而更加混乱。mi‘mar（拼写为mim、ayn、mim、elif、re）的起源也与流行的通俗信念相反，并不明确。从结构上看，“mi‘mar”一词与“makbul”（被接受的）、“maktul”（被杀的）、“menkul”（被转移的）等词有共同之处。这些词分别具有“被接受者”“被杀害者”“被转移者”等含义。它们显然不符合“mi‘mar”的意义结构。如果它与“amir”（拼写为ayn、elif、mim、re）——意为“处于良好、受照料状态”——有亲缘关系，那么“mi‘mar”在词源上可能意为“使某物保持受照料状态者”。无论如何，这个词的词源仍需研究。关于欧洲的历程，参见斯蒂芬·帕塞尔，《建筑的四个历史定义》（*Four Historical Definitions of Architecture*），蒙特利尔：麦吉尔—皇后大学出版社，2012年。这最后一本书从事的工作与我在本文中试图做的相似，但在方法语境中与我的并不重合，甚至不属于类似性质。

[4] 伊丽莎白·L. 艾森斯坦，《早期现代欧洲的印刷革命》（*The Printing Revolution in Early Modern Europe*），剑桥：剑桥大学出版社，Canto版，1993年，第53—55页；以及马里奥·卡尔波，《印刷时代的建筑：建筑理论史中的口头性、书写、活字印刷与印刷图像》（*Architecture in the Age of Printing: Orality, Writing, Typography, and Printed Images in the History of Architectural Theory*），S. Benson译，剑桥（马萨诸塞）与伦敦：MIT Press，2001年。

[5] “空范畴”一词是我借用吉登斯的“emptying space and time”（空间与时间的虚空化）概念衍生出来的：安东尼·吉登斯，《现代性的后果》（*The Consequences of Modernity*），牛津：Polity Press，1990年，第18页及以下；土耳其语译本：《现代性的后果》（*Modernliğin Sonuçları*），Ersin Kuşdil译，伊斯坦布尔：Ayrıntı，1994年。

[6] 以下基于istibdal记录的研究包含大量相关数据：H. 格克琴·厄兹卡亚，《18世纪伊斯坦布尔的房屋：建筑、租金、舒适、隐私》（*18. Yüzyılda İstanbul Evleri: Mimarlık, Rant, Konfor, Mahremiyet*），伊斯坦布尔：伊斯坦布尔研究院，2016年。

[7] 瓦尔特·泰加（编），《波吉宫博物馆指南：科学与艺术》（*Guide to the Museo di Palazzo Poggi, Science and Art*），博洛尼亚，第2版：2001年，第8页。

[8] 土耳其语版本：《围城之艺：攻城、防御、要塞与堡垒作战》（*Fenn-i Muhasara, Darben ve Def'an Muhasara ve Muharebe-i Kıl'a ve Husun*），康斯坦丁·伊普西兰蒂译，伊斯坦布尔：拉希德·埃芬迪印刷所，1209年（1794年）。

[9] 这份小册子的部分影印本：《方法的凯旋：国王工程师沃邦先生的筑城进攻论》（*Le Triomphe de la méthode, traité de l'attaque des places de Monsieur de Vauban ingénieur du roi*），N. Faucherre与P. Prost编，巴黎：Découvertes Gallimard Albums，1992年。原版：塞巴斯蒂安·勒普雷斯特·德·沃邦，《筑城地域的进攻与防御论；附地雷实践论》（*Traité de l'attaque et de la défense des places; avec un traité de la pratique des mines*），2卷，海牙：De Hondt，1737—1742年。

[10] 关于这些，参见西尔维奥·莱迪，〈军事建筑厅的防御工事模型〉（“I modelli di fortificazione della camera dell'architettura militare”），载《武器的科学：路易吉·费迪南多·马尔西利1658—1730》（*La scienza delle armi, Luigi Ferdinando Marsili 1658-1730*），博洛尼亚：Pendragon，2012年，第155—165页。

[11] 书名足以表达其内容和方法：约翰·菲舍尔·冯·埃尔拉赫，《历史建筑草图：以若干著名古代建筑与异民族建筑的图像，并借助史书、纪念章、废墟以及实地获取的真实图样，将之呈现于眼前。第一书：古代犹太人、埃及人、叙利亚人、波斯人和希腊人被时间掩埋的建筑方式。第二书：古老而未知的罗马建筑。第三书：若干欧洲内外的异民族建筑，如阿拉伯人和土耳其人等，以及新的波斯、暹罗、中国乃至日本建筑。第四书：若干由作者发明并绘制的建筑》（*Entwurff einer historischen Architectur*），维也纳，1721年。书名虽为德语，正文却是法语。

[12] 关于该词存在的理由，参见〈伊东忠太关于选择“建筑”一词的日译并据此更改造家学会名称的提议〉（“Chuta Ito's Proposal to Choose the Japanese Translation of the Word 'Architecture' and Rename Zoka Gakkai Accordingly”）以及中谷礼仁，〈作为“Architecture”含混译名的Kenchiku或Zoka〉（“Kenchiku or Zoka as Vague Translation of 'Architecture'”），载《Round：亚洲现代建筑选集》（*Round, Selected Writings on Modern Architecture from Asia*），Ol Jewels，Yasushi Zenno与Jagan Shah编，大阪，2006年，第24—28、29—32页。

[13] 参见渡边俊夫，〈日本帝国建筑：从托马斯·罗杰·史密斯到伊东忠太〉（“Japanese Imperial Architecture: From Thomas Roger Smith to Ito Chuta”），载《挑战过去与现在：十九世纪日本艺术的蜕变》（*Challenging Past and Present: The Metamorphosis of Nineteenth-Century Japanese Art*），Ellen P. Conant编，檀香山：夏威夷大学出版社，2006年，第249页。

[14] 关于建筑博物馆最早的一些尝试及其在法国——此类尝试的故乡——的历史，参见维尔纳·赞比恩，《建筑博物馆》（*Le Musée d'architecture*），巴黎：Picard，1988年。

[15] 索恩收藏品的主要部分属于16—19世纪；不过，我说的是一个总体收藏，其时间跨度一般可上溯至古埃及。关于这一收藏及其空间，参见蒂姆·诺克斯，《伦敦约翰·索恩爵士博物馆》（*Sir John Soane's Museum, London*），摄影：德里·摩尔，伦敦：Merrell，2009年。

[16] 关于约翰·赫伊杜克在扩展建筑内容方面的贡献，参见其以下书籍与装置作品：《制造》（*Fabrications*），1974年；《美杜莎面具》（*Mask of Medusa*），1985年；《博维萨》（*Bovisa*），1987年；《里加项目》（*The Riga Project*），1989年；《符拉迪沃斯托克》（*Vladivostok*），1989年；《实践》（*Prace / Practice*），1991年；《柏林之夜》（*Berlin Night*），1993年；《测深》（*Soundings*），1993年；《调整地基》（*Adjusting Foundations*），1995年；《恋爱中的建筑》（*Architectures in Love*），1995年；《安全》（*Security*），1995年；《锡翼、金角、石幕：深紫红房间里的婚礼》（*Pewter Wings Golden Horns Stone Veils: Wedding in a Dark Plum Room*），1997年。

[17] 关于三年展的图示汇编：亚历山德罗·罗卡，《三年展图集：米兰三年展》（*Atlante della Triennale. Triennale di Milano*），米兰：Charta，1999年。

[18] 建筑师关于此事的文本：弗里德里希·基斯勒，〈生命建筑—空间城市—功能性建筑〉（“Vitalbau-Raumstadt Funktionelle Architektur”），《风格》（*De Stijl*），第6卷第10—11期，1925年，第141页及以下。

[19] 展览图录：萨尔基斯，《Cage/Ryoanji的诠释》（*Interpretation of Cage/Ryoanji*），İlkay Baliç编，设计：埃森·卡罗尔，ARTER，伊斯坦布尔，2013年。

[20] 我档案中的这份四页文书（64×31厘米）可惜没有日期。不过，其中一张平面图把塞利米耶兵营的一个立面称为“学院立面”，据此可以说它属于军医学校（Tıbbiye）迁至海达尔帕夏（1903）并改称学院（1909）之后的时期。因此，该文书可能编制于阿拉伯文字被废弃的1928年之前最多19年。

[21] 理查德·斯通，《1650—1900年英国社会科学中的若干经验主义者》（*Some British Empiricists in the Social Sciences 1650-1900*），剑桥：拉法埃莱·马蒂奥利基金会与剑桥大学出版社，1997年，第209页及以下。

[22] 同上书，第240页及以下。

[23] 关于极其丰富的泰勒主义文献，一个快速入门：毛罗·F. 吉连，《机械的泰勒化之美：科学管理与现代主义建筑的兴起》（*The Taylorized Beauty of the Mechanical: Scientific Management and the Rise of Modernist Architecture*），普林斯顿与牛津：普林斯顿大学出版社，2006年。

[24] 安托万·皮孔，〈铁结构建造的第一步：引入一种新建筑材料所提出的问题〉（“The First Step of Construction in Iron: Problems Posed by the Introduction of a New Construction Material”），载《钢铁之前：结构铁材的引入及其后果》（*Before Steel: The Introduction of Structural Iron and Its Consequences*），M. Rinke、J. Schwartz编，苏黎世：Niggli，2010年，第52页。

[25] 雷蒙·威廉斯，《关键词：文化与社会的词汇》（*Keywords: A Vocabulary of Culture and Society*），伦敦：Fontana Press，1976年，第201—202、315—316页；土耳其语译本：《关键词：文化与社会的词汇》（*Anahtar Sözcükler: Kültür ve Toplumun Sözvarlığı*），Savaş Kılıç译，伊斯坦布尔：İletişim，2005年。

[26] 尼古劳斯·佩夫斯纳，《欧洲建筑纲要》（*An Outline of European Architecture*），伦敦：John Murray，初版1942年，第23页。
