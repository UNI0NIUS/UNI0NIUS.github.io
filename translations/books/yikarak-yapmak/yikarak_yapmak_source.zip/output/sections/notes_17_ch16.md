## XVI

[1] Norbert Elias, 《文明的进程：社会发生与心理发生研究》（*Uygarlık Süreci: Sosyo-Oluşumsal ve Psiko-Oluşumsal İncelemeler*）, 2卷，trans. E. Ateşman, E. Özbek, İstanbul: İletişim, 2000, 2002。

[2] 例如，尼古拉·勒卡米斯·德·梅济耶尔（Nicolas Le Camus de Mézières）初版于1780年的著作。英文新版：《建筑的精神：或论建筑艺术与我们感官的类比》（*The Genius of Architecture; or, The Analogy of That Art With Our Sensations*）, trans. D. Britt, Santa Monica: Getty Center, 1992。

[3] Henry-Russell Hitchcock, 《美国建筑书籍：1895年前在美国出版的建筑及相关主题书籍、图集与小册子目录》（*American Architectural Books: A List of Books, Portfolios, and Pamphlets on Architecture and Related Subjects Published in America before 1895*）, Minneapolis: University of Minnesota Press，第3版，1946年，第iii页。（校注：版次与年份沿底本保留，尚未据该版本实物核定；不能仅因另有1962年修订版记录便改写此处。）

[4] Robert Kerr, 《绅士之家；或，从牧师住宅到宫殿，如何规划英国住宅》（*The Gentleman's House; or, How to Plan English Residences, from the Parsonage to the Palace*）, London: John Murray, 1865。

[5] Hermann Muthesius, 《英国住宅：发展、条件、布局、建造、陈设与室内空间》（*Das englische Haus. Entwicklung, Bedingungen, Anlage, Aufbau, Einrichtung und Innenraum*）, 3卷，Berlin: Ernst Wasmuth, 1908–11。

[6] 这是他1903年只能出版两期的杂志的副标题：《他者：将西方文化引入奥地利的刊物》（*Das Andere: Ein Blatt zur Einführung abendländischer Kultur in Österreich*）。

[7] 他的观点作为短篇文集首次出版：Adolf Loos, 《向虚空言说，1897—1900》（*Ins Leere gesprochen 1897–1900*）, Paris and Zürich: Éditions Georges Crès, 1921。

[8] 对这一取向，在当时最重要人物的参与下编纂而成的最佳、最精炼的原始文献：佚名，《最低生存标准的住宅》（*Die Wohnung für das Existenzminimum*）, Frankfurt a.M.: Englert und Schlosser, 1930。

[9] 一份易于获取的英文资料：Selim O. Khan-Magomedov, 《苏联建筑的先驱：1920与1930年代对新方案的探索》（*Pioneers of Soviet Architecture: The Search for New Solutions in the 1920s and 1930s*）, London: Thames and Hudson, 1987, pp. 341–98。

[10] 关于他的住宅观点：Paul Schmitthenner, 《建筑造型，第一辑：德国住宅》（*Baugestaltung, erste Folge: Das deutsche Wohnhaus*）, Stuttgart: Konrad Wittwer Verlag, 1932。

[11] 例如参见 Mauro F. Guillén, 《机械的泰勒化之美：科学管理与现代主义建筑的兴起》（*The Taylorized Beauty of the Mechanical: Scientific Management and the Rise of Modernist Architecture*）, Princeton and Oxford: Princeton University Press, 2006。（校注：本注底本将作者中间名首字母记为G.；此处据[普林斯顿大学出版社目录](https://assets.press.princeton.edu/catalogs/art09.pdf)及本书前引同一著作统一为F.。）

[12] 例如展览就承担了这一功能。参见 Andrew James Wulf, 《冷战时期美国的国际展览：通过文化外交赢得人心》（*U.S. International Exhibitions during the Cold War: Winning Hearts and Minds through Cultural Diplomacy*）, Lanham, Boulder, London, New York: Rowman & Littlefield Publishers, 2015。

[13] N. John Habraken, 《支撑体：大规模住宅的另一种选择》（*Supports: An Alternative to Mass Housing*）, London: Architectural Press, 1972；荷兰语初版：1961年。

[14] 第一个这样营销的住宅小区，是贝赫鲁兹·奇尼吉（Behruz Çinici）在1990年代临近结束时在乌卢斯（Ulus）规划的“铂金”（Platin）。但它也成为“建筑师不做广告”这类批评的目标。参见 Uğur Tanyeli, 〈建筑师做广告吗？〉（Mimarlar Reklam Yapar mı?），*Arredamento Mimarlık*, 100+34, March 2001, p. 7。

[15] 关于客观性的一份总体性历史诠释——它使人想到可能的、但尚未被进行的建筑阅读——参见 Lorraine Daston and Peter Galison, 《客观性》（*Objectivity*）, New York: Zone Books, 2010。
