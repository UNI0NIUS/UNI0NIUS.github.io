## III

[1] 乌古尔·坦耶利，〈没有建筑师，只有建筑师们〉（“Mimar Yoktur, Mimarlar Vardır”），哈克·耶尔特勒哲访谈，《新建筑师》（*Yeni Mimar*），2007年8月；网络版：www.mekanar.com/tr（访问日期：2014年9月17日）。

[2] 奥古斯都·韦尔比·诺斯莫尔·普金，《对比：或十四、十五世纪的高贵建筑与当代同类建筑之间的平行比较，显示当今趣味的衰败》（*Contrasts: Or, A Parallel Between the Noble Edifices of the Fourteenth and Fifteenth Centuries and Similar Buildings of the Present Day. Shewing the Present Decay of Taste*），伦敦，1836年。

[3] 卡米洛·西特，《根据艺术原则进行的城市建造》（*Der Städtebau nach seinen künstlerischen Grundsätzen*），维也纳，第4版即最终版，1909年。

[4] 保罗·梅贝斯，《约1800年：其传统发展最后一百年中的建筑与手工艺》（*Um 1800. Architektur und Handwerk im letzten Jahrhundert ihrer traditionellen Entwicklung*），2卷，慕尼黑：Bruckmann，1908年。

[5] 坚吉兹·奥尔洪卢，〈城市建筑师〉（“Şehir Mimarları”），《奥斯曼研究》（*Osmanlı Araştırmaları*），第2卷，1981年，第1—30页。

[6] 马克斯·韦伯，〈官僚制〉（“Bureaucracy”），载《韦伯的理性主义与现代社会：政治、官僚制与社会分层新译》（*Weber's Rationalism and Modern Society: New Translations on Politics, Bureaucracy, and Social Stratification*），Tony Waters与Dagmar Waters编并译，纽约：Palgrave MacMillan，2015年，第73—127页。

[7] 例如，SOM的合伙人之一在回忆录中一次也没有把自己称为明星：纳撒尼尔·亚历山大·奥因斯，《中间的空间：一位建筑师的旅程》（*The Spaces in Between: An Architect's Journey*），波士顿：Houghton Mifflin Company，1973年。

[8] 劳伦·索思，〈勒·柯布西耶的客户及其1920年代的巴黎住宅〉（“Le Corbusier's Client and Their Parisian Houses of the 1920s”），《艺术史》（*Art History*），第6卷第2期，1983年6月，第188—198页。

[9] 这一可能大概是由赖特的妻子奥尔吉瓦娜（Olgivanna）在1930年代初经济危机时期发现并提出的。“塔里埃森学徒团”（Taliesin Fellowship）这一学徒制度的起源就在这里。参见布伦丹·吉尔，《许多面具：弗兰克·劳埃德·赖特传》（*Many Masks: A Life of Frank Lloyd Wright*），纽约：G. P. Putnam's Sons，1987年，第326页及以下。

[10] 玛丽·麦克劳德，〈建筑还是革命：泰勒主义、技术官僚主义与社会变革〉（“Architecture or Revolution: Taylorism, Technocracy, and Social Change”），《艺术杂志》（*Art Journal*），第43卷第2期（“修正现代主义历史：1920年代与1930年代建筑”专辑），1983年夏季，第132—147页。

[11] 乌古尔·坦耶利，〈建筑师作者的发明、职业的征服、民族的建构〉（“Mimar Müellifin İcadı, Mesleğin Fethi, Ulusun İnşası”），《社会历史》（*Toplumsal Tarih*），第189期，2009年9月，第73—74页。

[12] 克里斯托弗·朗，《洛斯楼》（*The Looshaus*），纽黑文与伦敦：耶鲁大学出版社，2012年。
