## IX

[1] 参见特奥多尔·W. 阿多诺与马克斯·霍克海默，《启蒙辩证法》（*Dialectic of Enlightenment*），J. 卡明译，伦敦与纽约：Verso Classics，1997年，第120—167页，“文化工业：作为大众欺骗的启蒙”一章；土耳其语版：“文化工业：作为大众欺骗的启蒙”，载《启蒙辩证法》，奥乌兹·厄兹居尔译，伊斯坦布尔：Kabalcı，2010年。

[2] 例如参见约翰·布伦克曼，〈大众媒体：从集体经验到私有化文化〉（"Mass Media: From Collective Experience to the Culture of Privatization"），《社会文本》（*Social Text*），第1期，1979年冬，第101页。

[3] 齐格弗里德·克拉考尔，〈旅行与舞蹈〉（"Travel and Dance"），载《大众装饰：魏玛随笔》（*The Mass Ornament: Weimar Essays*），T. Y. 莱文编并译，马萨诸塞州剑桥与伦敦：哈佛大学出版社，第65页及以下；土耳其语版：〈旅行与舞蹈〉，载《大众装饰》，奥尔罕·克勒奇译，伊斯坦布尔：Metis，2011年。

[4] 克里斯托弗·威尔克，《马塞尔·布罗伊尔：家具与室内》（*Marcel Breuer: Furniture and Interiors*），纽约：现代艺术博物馆，1981年，第15页。

[5] 贾科莫·巴罗齐·达·维尼奥拉，《五种建筑柱式通则》（*Regola delli cinque ordini d'architettura*），罗马：Camera Apostolica，1562年（？）。

[6] 参见詹姆斯·S. 阿克曼，〈模仿〉（"Imitation"），载《起源、模仿、惯例：视觉艺术中的再现》（*Origins, Imitation, Conventions: Representation in the Visual Arts*），马萨诸塞州剑桥与伦敦：MIT出版社，2002年，第125—141页。
