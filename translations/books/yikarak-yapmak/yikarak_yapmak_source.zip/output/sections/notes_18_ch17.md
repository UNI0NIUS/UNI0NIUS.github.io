## XVII

[1] 陀思妥耶夫斯基，《关于普希金的三篇讲话》（*Puşkin Üzerine Üç Konuşma*），Ö. Üner译，伊斯坦布尔：Dedalus，2014年。

[2] 勒·柯布西耶，《直角之诗》（*Le poème de l’angle droit*），巴黎：Éditions Tériade，1955年。

[3] 关于埃尔德姆的无所归属，参见乌古尔·坦耶利，〈青年塞达德·哈克·埃尔德姆：一种跨文化身份的建构〉（Genç Sedad Hakkı Eldem: Kültürlerarası Bir Kimlik İnşası），载《塞达德·哈克·埃尔德姆Ⅰ：青年岁月》（*Sedad Hakkı Eldem 1, Gençlik Yılları*），E. Eldem、B. Tanju、U. Tanyeli编，伊斯坦布尔：奥斯曼银行档案与研究中心，2008年，第45—46页。
