## XI

[1] Hyunjoon Yoo，《现代主义：东西方文化的混血儿》（*Modernism: A Hybrid of Eastern and Western Culture*），上海：同济大学出版社，2012年。

[2] 丹下健三，《桂：日本建筑中的传统与创造》（*Katsura: Tradition and Creation in Japanese Architecture*），瓦尔特·格罗皮乌斯序，纽黑文：耶鲁大学出版社，1960年。

[3] 关于此点，参见中森康文，《桂：日本建筑中的现代主义图景。石元泰博摄影》（*Katsura: Picturing Modernism in Japanese Architecture. Photographs by Ishimoto Yasuhiro*），休斯敦：休斯敦美术馆，2010年，第31页及以下。

[4] 乔纳森·M. 雷诺兹，〈伊势神宫与日本传统的现代主义建构〉（"Ise Shrine and a Modernist Construction of Japanese Tradition"），《艺术通报》（*The Art Bulletin*），第83卷第2期，2001年6月，第316—341页，尤其第324页及以下。

[5] 布鲁诺·陶特，《1934年京都桂离宫访问后的思考》（*Gedanken nach dem Besuch in Katsura, Kioto, 1934*），东京：岩波书店，1934年。新版缩印本收入：曼弗雷德·施派德尔，《布鲁诺·陶特：从阿尔卑斯建筑到桂离宫》（*Bruno Taut: From Alpine Architecture to Katsura Villa*，展览图录），东京：Watari Um，2007年，第154—171页。

[6] 中森康文，同上，第36—37页“丹下的裁剪”（"Tange's Croppings"）以及第37—42页“丹下的编辑工作与拜尔的书设计”（"Tange's Editorship and Bayer's Book Design"）两节。

[7] 一位工程学校教师所写的这类早期尝试：齐亚·科贾伊南，《锡南建筑师与20世纪建筑》，伊斯坦布尔：Kenan Basımevi，1939年。

[8] 关于阿利居尔·艾韦尔迪（1935—1986）：他是伊斯坦布尔技术大学建筑学院教师，其博士论文《日本建筑的空间，尤其对室内空间构造的探讨》（伊斯坦布尔：伊斯坦布尔技术大学建筑学院出版社，1972年）也以这一课题为主题。他还有相关研究：〈从广岛和平纪念堂到东京国立体育馆……关于丹下健三与当代日本建筑的一篇论文〉，《建筑》（*Mimarlık*），第10期，1965年，第22—25页。值得在此记下一处反讽：阿利居尔·艾韦尔迪正是“向他者学习”最激烈的反对者之一埃克雷姆·哈基·艾韦尔迪的儿子。

[9] 埃尼斯·科尔坦，《从勒·柯布西耶眼中看土耳其建筑与城市主义》（*Le Corbusier Gözüyle Türk Mimarlığı ve Şehirciliği*），伊斯坦布尔：Boyut，1983年。

[10] 关于这次旅行，参见勒·柯布西耶，《东方之旅》（*Le voyage d'Orient*），让·珀蒂编，巴黎：Edition Forces Vives，1966年；以及朱利亚诺·格雷斯莱里编，《勒·柯布西耶，东方之旅：夏尔·爱德华·让纳雷的未刊摄影与写作》（*Le Corbusier, viaggio in Oriente: gli inediti di Charles Edouard Jeanneret, fotografo e scrittore*），威尼斯：Marsilio，1984年。

[11] 阿道夫·马克斯·福格特，《勒·柯布西耶，高贵的野蛮人：走向现代主义的考古学》（*Le Corbusier, the Noble Savage: Toward an Archaeology of Modernism*），拉德卡·唐奈尔译，马萨诸塞州剑桥与伦敦：MIT出版社，1998年。

[12] 贝德里·拜卡姆，《猴子有权作画：一场为争取非西方艺术家权利的文化游击战，以及新现成品艺术的空虚世界》（*Monkeys' Right to Paint: The Fight of a Cultural Guerilla for the Rights of Non-Western Artists and the Empty World of Neo-Ready-Mades*），伊斯坦布尔：Literatür，1994年。

[13] 霍米·K. 巴巴，《文化的定位》（*The Location of Culture*），伦敦：Routledge，初版1994年。

[14] 关于此事，我不知道有详尽研究。但18世纪奥斯曼文献中充斥着无数源于欧洲的织物、玻璃与瓷器家用品。例如，从一份1732年的记录可以看出，奥斯曼商人马纳塞斯·阿塔诺（Manasses Athano）向迈森订购了2000打杯子，两年后这一数量提高到3000打。见M. 巴哈·坦曼（编），《埃克雷姆·哈基·艾韦尔迪（1899—1984）：建筑史家、修复师、收藏家》，伊斯坦布尔：伊斯坦布尔研究院，2014年，第306页。遗憾的是，该出版物未说明这一信息的来源。

[15] 参见佩兰·斯坦，《18世纪法国艺术中的土耳其风尚》（*Turquerie in Eighteenth Century French Art*），纽约：纽约大学出版社，1997年；土耳其语版：《土耳其风尚：18世纪欧洲的土耳其时尚》，努雷丁·埃尔·于塞尼译，伊斯坦布尔：YKY，2015年。内巴哈特·阿夫哲奥卢，《土耳其风尚与再现政治，1728—1876》（*Turquerie and the Politics of Representation, 1728–1876*），伦敦：Routledge，2011年；海登·威廉斯，《土耳其风尚：一种18世纪欧洲幻想》（*Turquerie: An Eighteenth-Century European Fantasy*），伦敦：Thames & Hudson，2014年。
