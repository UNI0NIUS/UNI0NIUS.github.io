## X

[1] 高坂正显（编），《明治时代的日本思想》（*Japanese Thought in the Meiji Era*），D. 阿博施译，东京：泛太平洋出版社，1958年，第220页；转引自马里乌斯·B. 詹森，〈19世纪日本的文化变化〉（"Cultural Change in Nineteenth-Century Japan"），载E. P. 科南特（编），《挑战过去与现在：19世纪日本艺术的蜕变》（*Challenging Past and Present: The Metamorphosis of Nineteenth Century Japanese Art*），檀香山：夏威夷大学出版社，2006年，第32页。

[2] 法特玛·米盖·格切克，《东方与西方相遇：18世纪的法国与奥斯曼帝国》（*East Encounters West: France and the Ottoman Empire in the Eighteenth Century*），牛津：牛津大学出版社，1987年，第72页。

[3] 爱德华·W. 萨义德，《东方学：西方对东方的观念》（*Orientalism, Western Conceptions of the Orient*），伦敦：Routledge & Kegan Paul，1978年（初版）；土耳其语版：《东方学：西方对东方的理解》，贝尔娜·于尔纳译，伊斯坦布尔：Metis，1999年。

[4] 参见图莱·阿尔坦，〈作为收藏者的18世纪奥斯曼公主：从中国瓷器到欧洲瓷器〉（"Eighteenth-Century Ottoman Princesses as Collectors: From Chinese to European Porcelain"），载N. 阿夫哲奥卢与F. B. 弗拉德（编），《全球化文化：18世纪的艺术与流动性》（*Globalizing Cultures: Art and Mobility in the Eighteenth Century*），《东方艺术》（*Ars Orientalis*）特刊，华盛顿特区：史密森学会，2011年。

[5] 关于哈蒂杰苏丹与A. I. 梅林的关系，参见弗雷德里克·希策尔、雅克·佩罗、罗伯特·安赫格尔，《哈蒂杰苏丹与梅林师傅：书信集》（*Hatice Sultan ile Melling Kalfa, Mektuplar*），E. 居尔泰金译，伊斯坦布尔：历史基金会尤尔特出版社奥斯曼研究丛书，2001年。

[6] 关于这座亭阁的一幅图像，参见安托万·伊尼亚斯·梅林，《君士坦丁堡与博斯普鲁斯两岸如画旅行》（*Voyages pittoresques de Constantinople et des rives du Bosphore*），巴黎，1819年，第30图版。

[7] 关于这一点，参见乌古尔·坦耶利，《追寻奥斯曼空间：15—19世纪的越界文本》（*Osmanlı Mekanının Peşinde: Sınıraşımı Metinleri 15–19. Yüzyıllar*），伊斯坦布尔：Akın Nalça Kitaplığı，2015年，第95页及以下。

[8] 简要信息参见阿里·盖萨里，《20世纪伊朗知识分子》（*Iranian Intellectuals in the 20th Century*），奥斯汀：得克萨斯大学出版社，1998年，第88页及以下。

[9] 在庞大的后殖民文献中只提及这两位，是因为我赋予他们在历史书写上的特殊重要性：霍米·巴巴，《文化的定位》（*The Location of Culture*），伦敦：Routledge Classics，1994年；迪佩什·查克拉巴蒂，《将欧洲地方化：后殖民思想与历史差异》（*Provincializing Europe: Postcolonial Thought and Historical Difference*），普林斯顿：普林斯顿大学出版社，2000年；土耳其语版：《将欧洲地方化：后殖民思想与历史差异》，伊尔凯尔·朱吕特译，伊斯坦布尔：海峡大学出版社，2012年。

[10] 全诗参见阿萨夫·哈莱特·切莱比，《迪万诗歌中的伊斯坦布尔》，安卡拉：Hece，2002年，第232—233页。

[11] 阿尔君·阿帕杜莱，《物的社会生命：文化视角中的商品》（*The Social Life of Things: Commodities in Cultural Perspective*），剑桥：剑桥大学出版社，1986年。

[12] 埃丝特·帕斯托里，《与物一起思考：走向一种新的艺术观》（*Thinking with Things: Toward a New Vision of Art*），奥斯汀：得克萨斯大学出版社，2005年。

[13] 阿米里亚·J. 赫纳雷、马丁·霍尔布拉德与萨里·瓦斯泰尔（编），《通过物思考：以民族志方式理论化人工物》（*Thinking Through Things: Theorising Artefacts Ethnographically*），伦敦：Routledge，2007年。

[14] 一项较新的研究：莉泽洛特·E. 绍尔马-耶尔奇与A. 艾森拜斯（编），《物的权力与文化转化的流动》（*The Power of Things and the Flow of Cultural Transformations*），柏林、慕尼黑：Deutscher Kunstverlag，2010年。
