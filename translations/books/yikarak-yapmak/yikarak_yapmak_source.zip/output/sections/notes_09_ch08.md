## VIII

[1] 阿扬扎德·比雷吉克利·埃克雷姆，《日本人》（*Japonlar*），伊斯坦布尔：妇女专刊报印刷所，1906年，第21页。

[2] 卡蒂普·切莱比，《真理之衡：择取至真》（*Mizanü'l-Hak fî İhtiyarü'l-Ahak*），O. Ş. 格克亚伊编，伊斯坦布尔：MEB出版社，1993年，第65—66页。

[3] 阿里·耶尔德勒姆，〈卡米对迪万诗歌与诗人的看法〉（"Kami'nin Divan Şiiri ve Şairi Hakkındaki Düşünceleri"），《菲拉特大学社会科学学报》（*Fırat Üniversitesi Sosyal Bilimler Dergisi / Fırat University Journal of Social Science*），第11卷第2期，2001年，第188—189页。

[4] 同上文，第188页。按今天语言的表述：“说我们的诗属波斯风格的是那心怀恶意之人／号角之声，无法与管风琴的旋律相和谐。”

[5] 同上文，第189页。按今天语言的表述：“卡米啊，如今诗歌只剩下空洞的辞句／没有人能用精炼的新意（mazmun）写出一首加扎勒。”

[6] 阿萨夫·哈莱特·切莱比，《迪万诗歌中的伊斯坦布尔（选集）》（*Divan Şiirinde İstanbul (Seçki)*），伊斯坦布尔：Hece，2002年，第115页。

[7] 同上，第123页。

[8] 同上，第125页。

[9] 同上，第187页。

[10] 巴哈·特夫菲克，《科学与文学的新生：关于心理学、道德、逻辑与文学的最新理论》（*Teceddüd-i İlmi ve Edebi, Psikolojiye, Ahlaka, Mantığa ve Edebiyata Da'ir En Son Nazariyeler*），伊斯坦布尔：Dersaadet书店老板阿尔森，1911年。该书也已以拉丁字母出版：巴哈·特夫菲克，《科学与文学的新生》，韦利·克勒查尔斯兰简化并编，科尼亚：Çizgi，奥斯曼哲学研究，2016年。

[11] 新版：同前，第29页。

[12] A. 法伊克·蒂尔克曼，《国民与军事道德》（*Milli ve Askeri Ahlak*），伊斯坦布尔：军事高中出版社，1943年，第229页。

[13] 雷蒙·威廉斯，《关键词：文化与社会的词汇》（*Keywords, A Vocabulary of Culture and Society*），伦敦：Fontana Press，1976年，第82—84页。

[14] 舍姆塞丁·萨米，《法语辞典：法土插图词典》（*Kamus-i Fransevi, Fransızcadan Türkçeye Lugat / Dictionnaire français-turc illustré*），伊斯坦布尔：Mihran，第4版，1905年，第654页。

[15] 雷蒙·威廉斯，同前，第102—104页。

[16] 同上，第120—123页。

[17] J. W. 雷德豪斯，《英语—土耳其语词典》（*A Lexicon, English and Turkish*），伊斯坦布尔，1860年，第301页。

[18] 舍姆塞丁·萨米，同前，第1003页。

[19] 雷蒙·威廉斯，同前，第160—161页。

[20] 同上，第230—231页。

[21] 舍姆塞丁·萨米，同前，第1587页。

[22] 同上。

[23] 雷蒙·威廉斯，同前，第243—245页。

[24] 雷德豪斯，同前，第602页。

[25] 舍姆塞丁·萨米，同前，第1775页。

[26] 参见 www.ekultursanat.com/siir/eser-623-0ndokuzuncu-Asir-Sadullah Pasa（访问日期：2016年10月28日）。

[27] “Tarz-ı cedid”（新风格）这一术语从1880年代起频繁见于文本，但其指涉始终模糊。该术语可以指涉任何欧洲起源的建筑形式。

[28] 弗朗索瓦丝·舒瓦，《规则与模型：建筑与城市主义理论论集》（*The Rule and the Model: On the Theory of Architecture and Urbanism*），D. 布拉顿译，马萨诸塞州剑桥与伦敦：MIT出版社，1977年，尤其第5、6章。（校注：底本年份作1977；[MIT出版社书目](https://mitpress.mit.edu/9780262032261/the-rule-and-the-model/)载该英译本出版于1997年。）

[29] 该书有很多新版。其一：乔纳森·斯威夫特，《一个木桶的故事，附〈书的战争〉与〈精神之机械运作〉》（*A Tale of a Tub, to which is Added the Battle of the Books and the Mechanical Operation of the Spirit*），A. C. 格思凯尔奇与D. 尼科尔·史密斯编，牛津：克拉伦登出版社，1920年。

[30] 约翰·约阿希姆·温克尔曼，《古代艺术史》（*Geschichte der Kunst des Alterthums*），德累斯顿：Waltherischen Hof-Buchhandlung，1764年，第359—360页。

[31] 关于这一贡献，参见恩斯特·H. 贡布里希，《进步观念及其对艺术的影响》（*The Ideas of Progress and Their Impact on Art*），纽约：库珀联盟艺术与建筑学院，1971年。

[32] 关于18、19世纪的建筑理性主义，参见彼得·柯林斯，《现代建筑中的观念变迁，1750—1950》（*Changing Ideals in Modern Architecture, 1750–1950*），伦敦：Faber and Faber，1965年，第198—217页；约瑟夫·里克沃特，《最初的现代人》（*The First Moderns*），马萨诸塞州剑桥与伦敦：MIT出版社，1980年。

[33] 关于这场争论，参见乔瓦尼·巴蒂斯塔·皮拉内西，《对马里耶特先生来信的观察：附关于建筑的意见，以及一篇关于美术在古代欧洲的传入与发展的新论著的序言》（*Observations on the Letter of Monsieur Mariette: With Opinions on Architecture, and a Preface to a New Treatise on the Introduction and Progress of the Fine Arts in Europe in Ancient Times*），约翰·威尔顿-伊利导论，卡罗琳·贝尔尼什与大卫·布里特译，洛杉矶：盖蒂出版社，2002年，尤其导论。

[34] 关于德语国家的非常有用、全面的概述：海因里希·许布施等，《我们应当以何种风格建造？德国建筑风格之争》（*In What Style Should We Build? The German Debate on Architectural Style*），沃尔夫冈·赫尔曼译并导论，洛杉矶：盖蒂出版社，1992年。

[35] 雷纳托·波焦利，《先锋理论》（*The Theory of the Avant-Garde*），杰拉尔德·菲茨杰拉德译，马萨诸塞州剑桥：哈佛大学出版社Belknap出版社，1968年。

[36] 参见赫尔曼·穆特修斯，《风格建筑与建造艺术》（*Stilarchitektur und Baukunst*），米尔海姆-鲁尔：K. Schimmelpfeng出版社，1902年；英文版：《风格建筑与建造艺术：19世纪建筑的转变及其现状》（*Style-Architecture and Building Art: Transformations of Architecture in the Nineteenth Century and Its Present Condition*），斯坦福·安德森译并导论，洛杉矶：盖蒂出版社，1994年。

[37] 尤其是该书第一部分，示范了连续性与发展、创新概念近乎机械论的解释：勒·柯布西耶，《现代建筑年历》（*Almanach d'architecture moderne*），巴黎：G. Crès et Cie，1925年，第6—15页（“建筑年历”一章）。

[38] 转引自彼得·比尔格，《先锋理论》（*Theory of the Avant-Garde*），迈克尔·肖译，约亨·舒尔特-萨斯序，明尼阿波利斯：曼彻斯特大学出版社／明尼苏达大学出版社，1984年，第61页。

[39] 埃里克·J. 霍布斯鲍姆，《落后于时代：20世纪先锋派的衰落与失败》（*Behind the Times: The Decline and Fall of the Twentieth-Century Avant-Gardes*），沃尔特·纽拉特纪念讲座，伦敦：Thames & Hudson，1999年。

[40] 参见理查德·墨菲，《卡洛·斯卡帕与卡斯泰尔韦基奥》（*Carlo Scarpa and the Castelvecchio*），伦敦：Architectural Press，1991年。
