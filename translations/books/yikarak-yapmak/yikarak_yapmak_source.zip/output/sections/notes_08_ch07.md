## VII

[1] 参见马歇尔·麦克卢汉，《谷登堡星汉：印刷人的形成》（*The Gutenberg Galaxy: The Making of Typographic Man*），多伦多：多伦多大学出版社，1962年；土耳其语版：《谷登堡星汉：印刷人的形成》（*Gutenberg Galaksisi: Tipografik İnsanın Oluşumu*），居尔·恰阿勒·居文译，伊斯坦布尔：YKY，2001年。

[2] 让-巴蒂斯特·杜博，《诗歌与绘画的批判性思考》（*Réflexions critiques sur la poésie et sur la peinture*），巴黎：Jean Mariette，1719年。我没有见过这本书。转引自：亚历克斯·波茨，〈导论〉（"Introduction"），载约翰·约阿希姆·温克尔曼，《古代艺术史》（*History of the Art of Antiquity*），H. F. 马尔格雷夫译，洛杉矶：盖蒂研究所，2006年，第40页注12；土耳其语版：《古代艺术史》（*Antikçağ Sanat Tarihi*），奥乌兹·厄兹居尔译，伊斯坦布尔：Say，2012年。

[3] 孟德斯鸠，《论法的精神，或法律与每一政府的宪制、风俗、气候、宗教、商业等之关系；作者另附关于罗马继承法、法国法及封建法的新研究》（*De l'esprit des loix ou du rapport que les loix doivent avoir avec la constitution de chaque gouvernement, les moeurs, le climat, la religion, le commerce, &c. à quoi l'auteur a ajouté des recherches nouvelles sur les loix romaines touchant les successions, sur les loix françaises, & sur les loix féodales*），日内瓦［巴黎］：Chez Barrillot & Fils，初版未署日期（1748年）。

[4] 初版：约翰·约阿希姆·温克尔曼，《古代艺术史》（*Geschichte der Kunst des Alterthums*），德累斯顿：Waltherischen Hof-Buchhandlung，1764年，第25—30页。较易获得的英文版：J. J. 温克尔曼，同上书。

[5] 赖特生前出版的一部非常重要的回顾性专著也使用这个名称：亨利-拉塞尔·希区柯克，《材料的本性：弗兰克·劳埃德·赖特的建筑，1887—1941》（*In the Nature of Materials: The Buildings of Frank Lloyd Wright 1887–1941*），纽约：Duell, Sloan and Pearce，1942年。

[6] www.brainyquote.com/quotes/authors/l/louis_kahn.html（访问日期：2016年9月6日）。

[7] 我曾详细研究过这一问题：乌古尔·坦耶利，〈16世纪奥斯曼建筑的技术背景：空间的数学化理解〉（"16. Yüzyıl Osmanlı Mimarlığının Teknolojik Arka Planı: Mekanın Matematiksel Kavranışı"），《社会历史》（*Toplumsal Tarih*），第258期，2015年6月，第20—34页。

[8] 例如，参见埃莱娜·韦兰，〈沃邦时代工程师技术理性的条件〉（"Les conditions de la rationalité technique des ingénieurs au temps de Vauban"），载蒂埃里·马丁与米歇尔·维罗尔（编），《沃邦：现代性的建筑师？》（*Vauban, architecte de la modernité?*），贝桑松：弗朗什-孔泰大学出版社，2008年，第73—85页。

[9] 即使在可以说较为晚近的研究中，这种取向仍在延续。例如，罗伯特·希伦布兰德，《伊斯兰建筑：形式、功能与意义》（*Islamic Architecture: Form, Function and Meaning*），爱丁堡：爱丁堡大学出版社，1994年，第24页，把伊斯兰传统中形式与装饰里的含混性（ambiguity）与错觉主义（illusionism）称为基本特征。

[10] 多安·库班的全部研究都旨在把理性主义归给奥斯曼建筑。我曾在以下著作中简短讨论：乌古尔·坦耶利，《建筑的行动者，土耳其1900—2000》（*Mimarlığın Aktörleri, Türkiye 1900–2000*），伊斯坦布尔：GG，2007年，第326—327页。

[11] 弗朗切斯科·阿尔加罗蒂，《建筑论》（*Saggio sopra l'architettura*；初版收入作者《各类作品集》[*Opere varie*]，1757年），首个单行本：威尼斯：Nella Stamperia Graziosi，1784年。马可·安托万·洛吉耶神父，《建筑观察》（*Observations sur l'architecture*），海牙与巴黎：Desaint，1765年。安德烈亚·梅莫，《洛多利式建筑要素，或以科学之坚固与非任性之优雅建造的艺术》（*Elementi d'architettura lodoliana, ossia l'arte del fabbricare con solidità scientifica e con eleganza non capricciosa*），2卷，罗马：Pagliarini，1786年。弗朗切斯科·米利齐亚，《民用建筑原理》（*Principi di architettura civile*），3卷，Stamperia di Jacopo de' Rossi，初版1781年。与这一年代顺序相反，该领域的先驱是从1740年代开始公开提出自己观点、但没有将其出版的卡洛·洛多利（1690—1761）；因此，他的观点先通过阿尔加罗蒂的书、随后又主要通过梅莫的书而得以付印。

[12] 关于原始棚屋，参见约瑟夫·里克沃特，《论天堂中亚当的房屋：建筑史中的原始棚屋观念》（*On Adam's House in Paradise: The Idea of the Primitive Hut in Architectural History*），纽约：现代艺术博物馆，初版1972年。

[13] 例如，他写下了这部纪念碑式的著作：欧仁-埃马纽埃尔·维奥莱-勒-杜克，《11至16世纪法国建筑理性辞典》（*Dictionnaire raisonné de l'architecture française du XIe au XVIe siècle*），10卷，巴黎：Morel et Cie.，1875年。

[14] 卡尔·戈特利布·威廉·伯蒂歇尔，《希腊人的建筑术》（*Die Tektonik der Hellenen*），2卷，波茨坦：Ferdinand Riegel，1844年。

[15] 例如：凯·K. 古乔，〈重构建筑史：卡尔·伯蒂歇尔建筑术理论中的历史主义〉（"Restructuring Architecture's History: Historicism in Karl Bötticher's Theory of Tectonics"），载《（重新）审视建筑术：建筑／技术／生产》（*(Re)viewing the Tectonic: Architecture/Technology/Production*），ACSA东中部地区会议，密歇根大学，2000年秋；repository.cmu.edu/cgi/viewcontent.cgi?article=1036&context=architecture（访问日期：2016年8月3日）。

[16] 关于这些以及物质决定论理论后来的德语区代表，参见索克拉蒂斯·乔治亚迪斯，〈导论〉（"Introduction"），载西格弗里德·吉迪恩，《在法国建造，用铁建造，用钢筋混凝土建造》（*Building in France, Building in Iron, Building in Ferro-Concrete*），J. 邓肯·贝里译，洛杉矶：盖蒂，1995年，第1—78页。

[17] 从他第一部重要的现代主义文本开始，他就把技术与材料的作用置于中心：西格弗里德·吉迪恩，《在法国建造。用铁建造。用钢筋混凝土建造》（*Bauen in Frankreich. Bauen in Eisen. Bauen in Eisenbeton*），莱比锡：Klinkhardt & Biermann Verlag，1928年。

[18] 这座建筑在构造机体上的这种复杂性，在其最近一次修复中明显地显露出来。关于这一点，参见格哈德·皮希勒，〈建筑构造，或者：为什么爱因斯坦塔始终是一个需要照管的案例？〉（"Die Baukonstruktion, oder: Warum bleibt der Einsteinturm ein Pflegefall?"），载诺贝特·胡泽（编），《门德尔松。爱因斯坦塔：一次修复的历史》（*Mendelsohn. Der Einsteinturm, Die Geschichte einer Instandsetzung*），斯图加特与苏黎世：Karl Kraemer Verlag，2000年，第91—101页，尤其是第92—93页的构造分析图。

[19] 例如，维尔纳·黑格曼，〈斯图加特市府的蠢行与1930年柏林建筑展〉（"Stuttgarter Schildbürgerstreiche und berliner Bauausstellung 1930"），《Wasmuths Monatshefte für Baukunst》，第XII卷第1期，1928年，第8—12页。尤其第9页图1的说明颇为有趣：“斯图加特制造联盟建筑展览会上，一座住宅施工期间。‘不当拼装、连接在一起的铁构件、实心混凝土、空心混凝土、木框架、木板、屋面板、浮石混凝土、灰泥……的混乱共存，简直是外行的胡乱拼凑。’”

[20] 戈特弗里德·森佩尔，〈建筑的四要素〉（"The Four Elements of Architecture"），载《建筑的四要素及其他著作》（*The Four Elements of Architecture and Other Writings*），H. F. 马尔格雷夫与W. 赫尔曼译，剑桥：剑桥大学出版社，1989年，第102页。此文本还有一个粗疏且极难使用的土耳其语译本：《建筑的四要素与两场演讲》（*Mimarlığın Dört Öğesi ve İki Konferans*），阿尔普·蒂梅尔特金、尼哈特·于尔纳译，伊斯坦布尔：Janus，2015年。

[21] 戈特弗里德·森佩尔，《技术艺术与建筑术艺术中的风格，或实践美学。技术家、艺术家与艺术之友手册。第一卷：织物艺术自身及其与建筑艺术的关系。——第二卷：陶艺、建筑术、切石术、金属技术，自身及其与建筑艺术的关系》（*Der Stil in den technischen und tektonischen Künsten oder praktische Aesthetik. Ein Handbuch für Techniker, Künstler und Kunstfreunde. Erster Band: Die Textile Kunst für sich betrachtet und in Beziehung zur Baukunst. — Zweiter Band: Keramik, Tektonik, Stereotomie, Metallotechnik, für sich betrachtet und in Beziehung zur Baukunst*），2卷，美因河畔法兰克福与慕尼黑：Verlag für Kunst und Wissenschaft与Friedrich Bruckmann，1860—1863年。

[22] 阿洛伊斯·里格尔，《根据奥匈帝国出土物所见的晚期罗马艺术工业》（*Die spätrömische Kunstindustrie nach den Funden in Österreich-Ungarn*），2卷，维也纳：Staatsdruckerei，1901年、1923年。

[23] 玛格丽特·艾弗森，《阿洛伊斯·里格尔：艺术史与理论》（*Alois Riegl: Art History and Theory*），马萨诸塞州剑桥与伦敦：MIT Press，1993年，第72页。

[24] 阿莫斯·拉波波特在其颇具影响力的《住宅形式与文化》（*House Form and Culture*，恩格尔伍德克利夫斯，新泽西：Prentice-Hall Inc.，1969年）中，把气候、构造、材料与技术描述为修正性（modifying）因素时，也许是接近森佩尔理论最多的研究者之一。

[25] 保罗·施米特亨纳，《建筑塑造。第一辑：德国住宅》（*Baugestaltung. Erste Folge: Das deutsche Wohnhaus*），斯图加特：Konrad Wittwer，1934年，第5页。
