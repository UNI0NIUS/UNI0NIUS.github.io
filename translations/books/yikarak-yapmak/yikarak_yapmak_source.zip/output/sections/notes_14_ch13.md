## XIII

[1] 关于宗教如何失去其作为共同归属标识的旧含义，并在现代世界获得作为信仰体系的、新的规范性、僵化含义：Peter van der Veer, 《帝国相遇：印度与英国的宗教和现代性》（*Imperial Encounters: Religion and Modernity in India and Britain*）, 普林斯顿：普林斯顿大学出版社, 2001。已知19世纪晚期奥斯曼政府曾对它所认为“不够”穆斯林的一些群体展开某种内部传教活动，以使他们改信正确信仰；关于此事与同一变化的关系，参见 Marc David Baer, 《转宗者：犹太改宗者、穆斯林革命者与世俗土耳其人》（*The Dönme: Jewish Converts, Muslim Revolutionaries, and Secular Turks*）, 加利福尼亚州斯坦福：斯坦福大学出版社, 2010, 第20—21页及第272页注94；土耳其语译本：《萨洛尼卡转宗者：犹太改宗者、穆斯林革命者与世俗土耳其人》（*Selanikli Dönmeler: Musevilikten Dönenler, Müslüman Devrimciler ve Laik Türkler*）, 译者：Sevinç Kayır, 伊斯坦布尔： Doğan Kitap, 2011。

[2] 参见 Georges Duby, 《骑士、贵妇与教士：中世纪法国现代婚姻的形成》（*The Knight, the Lady and the Priest: The Making of Modern Marriage in Medieval France*）, 译者：Barbara Bray, 芝加哥：芝加哥大学出版社, 1983；土耳其语译本：《骑士、女性与教士：封建法国的婚姻》（*Şövalye, Kadın ve Rahip: Feodal Fransa'da Evlilik*）, 译者：Mehmet Ali Kılıçbay, 伊斯坦布尔： Ayrıntı, 1991。

[3] 一位观察者的证词：Ruy Gonzalez de Clavijo, 《出使帖木儿记，1403—1406》（*Embassy to Tamerlane 1403–1406*）, 译者：Guy Le Strange, 伦敦： Routledge, 1928。

[4] 16世纪法官阿希克·切莱比（Aşık Çelebi）的同性爱情生活，在此语境中具有启发性。参见 Jan Schmidt, 〈爱情、爱人和被爱者：《诗人感知录》中的爱情关系〉（"Aşk, Aşıklar ve Maşuklar: Meşa'irü'ş-Şu'ara'da Aşk İlişkileri"），《阿希克·切莱比及其诗人传研究文集》（*Aşık Çelebi ve Şairler Tezkiresi Üzerine Yazılar*）, 编者：Hatice Aynur, Aslı Niyazioğlu, 伊斯坦布尔： 科奇大学出版社, 2011, 第103—113页。关于此题的一般性论述，参见 Dror Ze'evi, 《奥斯曼穆斯林社会中的欲望与爱情，1500—1900》（*Müslüman Osmanlı Toplumunda Arzu ve Aşk 1500–1900*）, 译者：F. Aytuna, 伊斯坦布尔： Kitap, 2007。

[5] Marc David Baer, 《转宗者……》（*The Dönme...*）, 同上书。

[6] Abdurrahman Küçük, 〈转宗者〉（"Dönme"），《土耳其宗教事务基金会伊斯兰百科全书》（*Türkiye Diyanet Vakfı İslam Ansiklopedisi*）, 第9卷, 伊斯坦布尔， 1994, 第518页。

[7] 关于法西斯主义之现代性的阅读：Roger Griffin, 《现代主义与法西斯主义：墨索里尼与希特勒统治下的开端感》（*Modernism and Fascism: The Sense of a Beginning under Mussolini and Hitler*）, Palgrave Macmillan, 2007。

[8] 报道：《自由报》（*Hürriyet*）, 2016年2月12日。

[9] www.hassa.com/tr/proje/atasehir-mimar-sinan-camii（访问日期：2016年2月18日）。

[10] A. Welby Pugin, 《对比：十四与十五世纪的宏伟建筑与当今同类建筑的比较，揭示当今趣味的衰退》（*Contrasts: Or, a Parallel Between the Noble Edifices of the Fourteenth and Fifteenth Centuries and Similar Buildings of the Present Day, Shewing the Present Decay of Taste*）, 伦敦： Charles Dolman, 1836。

[11] A. Welby Pugin, 《英格兰教会建筑的现状》（*The Present State of Ecclesiastical Architecture in England*）, 伦敦： Charles Dolman, 1843, 第5页。
