## XV

[1] Mark Wigley, 〈文字排印的智慧〉（Typographic Intelligence），Ben van Berkel & Caroline Bos，《UN Studio展开》（*UN Studio Unfold*），鹿特丹：NAi Publishers，2002年，第122页。

[2] Le Corbusier, 《光辉城市》（*La ville radieuse*）, Paris: Vincent, Fréal & Cie., 1933；英文版：《光辉城市》（*The Radiant City*）, London: Faber & Faber, 1967, p. 127。（校注：底本将法文版记为1933年；[勒·柯布西耶基金会的书目](https://www.fondationlecorbusier.fr/oeuvre-livre/la-ville-radieuse-le-corbusier-1935/)所列该书出版年为1935年。）

[3] 参见 Zygmunt Bauman, 《立法者与阐释者：论现代性、后现代性与知识分子》（*Yasa Koyucular ile Yorumcular: Modernite, Postmodernite ve Entelektüeller Üzerine*）, trans. K. Atakay, İstanbul: Metis, 1996。

[4] 自文艺复兴开始、以比例为核心的论述，其最后一个重要版本出自勒·柯布西耶：Le Corbusier, 《模度：可普遍应用于建筑与机械的人体尺度和谐测量研究》（*Le Modulor. Essai sur une mesure harmonique à l'échelle humaine applicable universellement à l'architecture et à la mécanique*）, 第1、2卷，Boulogne: Éditions de l'Architecture d'aujourd'hui, 1950, 1955。

[5] 19世纪的建筑环境以无数历史主义取向为特征。对此的整体概观，参见 Hanno-Walter Kruft, 《建筑理论史：从维特鲁威至今》（*A History of Architectural Theory from Vitruvius to the Present*）, trans. R. Taylor, E. Callender, A. Wood, London and New York: Zwemmer and Princeton Architectural Press, 1994，多处，尤其第323页及以下（第23章，〈十九世纪的英国〉（England in the Nineteenth Century））。

[6] 关于这一吸引了大量文献的问题，参见 Mauro F. Guillén, 《机械的泰勒化之美：科学管理与现代主义建筑的兴起》（*The Taylorized Beauty of the Mechanical, Scientific Management and the Rise of Modernist Architecture*）, Princeton and Oxford: Princeton University Press, 2006。

[7] 例如 Christopher Alexander, 《形式综合论札记》（*Notes on the Synthesis of Form*）, Cambridge, Mass.: Harvard University Press, 1964。

[8] 这一观点最有力的倡导者是瓦尔特·格罗皮乌斯。他曾无数次阐述自己的想法。例如 Walter Gropius, 《民主中的阿波罗：建筑师的文化义务》（*Apollo in the Democracy: The Cultural Obligation of the Architect*） 中的〈建筑师在现代社会中的角色〉（The Role of the Architect in Modern Society）一章，New York, Toronto, London, Sydney: McGraw-Hill Book Company, 1968, pp. 43–55。

[9] Reyner Banham, 《洛杉矶：四种生态的建筑》（*Los Angeles: The Architecture of Four Ecologies*）, Harmondsworth: Allen Lane The Penguin Press, 1971。

[10] Robert Venturi, Denise Scott Brown and Steven Izenour, 《向拉斯维加斯学习：被遗忘的建筑形式象征主义》（*Learning from Las Vegas: The Forgotten Symbolism of Architectural Form*）, Cambridge, Mass.: MIT Press，初版1968年。（校注：底本如此；[MIT出版社的版本说明](https://mitpress.mit.edu/9780262036962/learning-from-las-vegas/)记载本书初版于1972年出版。）

[11] Rem Koolhaas, 《癫狂的纽约：曼哈顿的追溯宣言》（*Delirious New York. A Retroactive Manifesto for Manhattan*）, New York: Oxford University Press，初版1978年。

[12] 关于勒·柯布西耶自己的“光辉城市”方案与纽约的比较，参见 Le Corbusier, 《光辉城市》（*The Radiant City*）, 前引书，第202页。

[13] 参见 David Jacobson, 《美国的地方与归属》（*Place and Belonging in America*）, Baltimore and London: The Johns Hopkins University Press, 2002。尤其从第127页开始的最后三章聚焦于当代美国。虽然本书的轴心不是建筑，但它对归属之象征形式的关注，使这项研究也可以直接放在建筑语境中阅读。

[14] 我曾在那里较详细地讨论过这一问题：Uğur Tanyeli, 〈地方、非地方、纳粹、奥热及其引发的思考〉（Yer, Yer-olmayan, Naziler, Auge ve Akla Getirdikleri），*Arredamento Mimarlık*, 257, May 2012, pp. 106–11。另见本书第十二章。

[15] David Jacobson, 前引书，pp. 133–43。

[16] Gil Garcetti, 《钢铁：沃尔特·迪士尼音乐厅的建造》（*Iron: Erecting the Walt Disney Concert Hall*）, Los Angeles: Balcony Press, 2002，Frank O. Gehry 的〈前言〉，pp. 6–8。

[17] Ben van Berkel and Caroline Bos, 〈从图解到设计模型〉（From Diagram to Design Model），《UN Studio：空间的演化》（*UN Studio: Evolution of Space / Entwicklung des Raums*）, ed. P. Cachola Schmal, Frankfurt: DAM, p. 24。

[18] 同上，第25页。

[19] 这里有必要特别指出并纠正一个错误观念：非标准几何并不是欧几里得几何的替代选项。在建筑语境中，它们不只定义曲线或“皱褶”形式。一切使用数字技术的设计工具都依赖一种非欧几里得的几何基础设施。因此，电脑屏幕上的那些熟悉的基本几何形状，按其数学定义也是非标准几何的产物。（校注：本注将数字表示、非标准形式与非欧几里得几何混为一谈。采用参数曲线或NURBS并不意味着放弃欧几里得几何；[Rhino官方数学文档](https://developer.rhino3d.com/en/guides/general/essential-mathematics/parametric-curves-surfaces/)即在通常的三维坐标中说明直线、圆及NURBS曲线的表示。因此，“一切”数字设计工具均依赖非欧几里得几何的说法不成立。）

[20] Gianni Vattimo, 《现代性的终结：后现代文化中的虚无主义与阐释学》（*The End of Modernity. Nihilism and Hermeneutics in Post-Modern Culture*）, trans. and intro. J. N. Snyder, Cambridge: Polity Press, 1991, p. xx。这段简短说明出自译者导言。（校注：底本译者缩写作J. N. Snyder；[庞培法布拉大学瓦蒂莫档案书目](https://www.upf.edu/documents/83895855/215819426/Arxiu%2BGianni%2BVattimo%2B-%2BFitxa%2Bde%2BFons.pdf/2c966408-c107-9870-cf3b-8abccca52504)所列该版译者为John R. Snyder，故此处首字母有误。）

[21] 同上，pp. 51–64（〈艺术的死亡或衰落〉（The Death or Decline of Art）一章）。

[22] 关于这一点，参见 Andreas Huyssen, 《大分裂之后：现代主义、大众文化与后现代主义》（*After the Great Divide: Modernism, Mass Culture, Postmodernism*）, Bloomington and Indianapolis: Indiana University Press, 1986, p. 16及以下。

[23] Uğur Tanyeli, 〈这次实验的语境：设计过程而非结果形式〉（Bu Deneyin Bağlamı: Sonuç-Biçim Yerine Süreci Tasarlamak），Kozikoğlu, Pasquero, Poletto, 《纤维之室：探索结构逻辑》（*Lifli Oda, Strüktürel Mantığı Araştırmak / Fibrous Room. Evolving Structural Logic*）, İstanbul: GG, 2008年1月5日—3月8日，无页码（宣传册）。
