## IV

[1] 沃恩·哈特与彼得·希克斯（编），《塞巴斯蒂亚诺·塞利奥论建筑》第一卷：《建筑与透视全集》第1—5卷（*Sebastiano Serlio on Architecture Volume One: Books 1–5 of "Tutte l'Opere d'Architettura et Prospetiva"*），纽黑文与伦敦：耶鲁大学出版社，1996年，第xxvi页。

[2] 塞巴斯蒂亚诺·塞利奥，《论建筑的普遍规则：论五种建筑方式——托斯卡纳式、多立克式、爱奥尼式、科林斯式与混合式，附古代实例，其大部分与维特鲁威学说相符》（*Regole generali di architetura sopra le cinque maniere de gli edifici: cioe, thoscano, dorico, ionico, corinthio, et composito, con gli essempi dell'antiquita, che per la magior parte concordano con la dottrina di Vitruuio*），第4卷，威尼斯，1537年。

[3] 贾科莫·巴罗齐·达·维尼奥拉，《建筑五柱式规则》（*Regola delli cinque ordini d'architettura*），罗马，初版1562年。

[4] 伊丽莎白·艾森斯坦，《早期近代欧洲的印刷革命》（*The Printing Revolution in Early Modern Europe*），剑桥：剑桥大学出版社，Canto丛书，1983年，第53—55页。该书是同一作者《作为变革动因的印刷机：早期近代欧洲的传播与文化变革》（*The Printing Press as an Agent of Change: Communications and Cultural Transformations in Early Modern Europe*）两卷本的缩编版，剑桥大学出版社，1979年。

[5] J. N. L. 杜朗，《在巴黎理工学院讲授的建筑学课程纲要》（*Précis des leçons d'architecture données à l'École Polytechnique*），2卷，巴黎，1802年。

[6] 参见约瑟夫·里克沃特，《论天堂中亚当的房屋：建筑史中的原始棚屋观念》（*On Adam's House in Paradise: The Idea of the Primitive Hut in Architectural History*），纽约：现代艺术博物馆，1972年。

[7] 戈特弗里德·森佩尔，〈建筑的四种要素〉（"The Four Elements of Architecture"），载《建筑的四种要素及其他文稿》（*The Four Elements of Architecture and Other Writings*），H. F. 马尔格雷夫与 W. 赫尔曼译，剑桥：剑桥大学出版社，1989年，第101—126页（第五章）。

[8] 埃德海姆帕夏等，《奥斯曼建筑术》／《奥斯曼建筑》／《奥斯曼建筑艺术》（*Usul-i Mi'mari-i Osmani / L'architecture ottomane / Die ottomanische Baukunst*），伊斯坦布尔：中央印刷与石印局，1873年。

[9] 蒂图斯·布尔克哈特，《伊斯兰艺术：语言与意义》（*Art of Islam: Language and Meaning*），彼得·霍布森译，伦敦：Islamic Festival Trust Ltd.，1976年；土耳其语版：《伊斯兰艺术：语言与意义》（*İslam Sanatı: Dil ve Anlam*），图兰·科奇译，伊斯坦布尔：Klasik，2006年。

[10] 参见莫伊谢·金兹堡，《风格与时代》（*Стиль и эпоха*，*Stil' i epokha*），莫斯科：Gosizdat，1924年。英文版：《风格与时代》（*Style and Epoch*），阿纳托尔·森克维奇二世导读并翻译，剑桥（马萨诸塞）与伦敦：Opposition Books，MIT Press，1982年。

[11] Folly可以定义为一种没有任何具体实用性的建筑。它通常是18世纪与19世纪初园林设计的组成部分。例如，在这一时期的英格兰、法国和意大利，可以见到建成城堡废墟、古代神庙遗迹乃至奥斯曼帐篷形式的构筑物。关于这个主题有无数著作，几乎都包含视觉实例，却很少涉及理论讨论。快速浏览可参见：en.wikipedia.org/wiki/Folly（访问日期：2016年10月21日）。
