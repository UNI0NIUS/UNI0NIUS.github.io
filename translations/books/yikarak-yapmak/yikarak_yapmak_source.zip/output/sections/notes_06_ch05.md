## V

[1] R. 菲舍尔、H. F. 马尔格雷夫与 E. 伊科诺穆，《共情、形式与空间：德国美学问题，1873—1893》（*Empathy, Form, and Space: Problems in German Aesthetics 1873–1893*），"导论"，圣莫尼卡：盖蒂出版社，1994年，第10页。

[2] 路德维希·希尔伯塞默，《国际新建筑》（*Internationale neue Baukunst*），斯图加特：Verlag Julius Hoffmann，1927年，第5页。

[3] 彼得·斯塔基，《俄罗斯之春》（*Russian Spring*），伦敦：Selwyn & Blount，1937年，第198—199页。

[4] 勒·柯布西耶，《联合国总部》（*UN Headquarters*），纽约：Reinhold Publishing Corporation，1947年，第79页。

[5] 关于这一概念，参见《最低生存》（*Existenzminimum*），斯图加特：Verlag Julius Hoffmann，1933年。

[6] 路德维希·希尔伯塞默，《大都市建筑》（*Großstadtarchitektur*），斯图加特：Verlag Julius Hoffmann，1927年，第22页。

[7] 勒·柯布西耶，《走向建筑》（*Vers une architecture*），巴黎：Les Éditions G. Crès et Cie.，增订新版，无出版年，第49—64页。

[8] 勒·柯布西耶，《模度》第1、2卷（*Le Modulor*），巴黎：Éditions de l'Architecture d'Aujourd'hui，1948年、1955年；土耳其语版：《模度》（*Modulor*），阿齐兹·乌富克·克勒奇译，伊斯坦布尔：YEM，2014年。

[9] 克里斯托弗·亚历山大，《形式综合论》（*Notes on the Synthesis of Form*），剑桥（马萨诸塞）：哈佛大学出版社，1964年。

[10] 同上书，第134页。

[11] 转引自曼弗雷德·施派德尔（编），《布鲁诺·陶特：自然与幻想》（*Bruno Taut: Natur und Fantasie*），柏林，1995年，第116—117页。

[12] 布鲁诺·陶特，《建筑知识》（*Mimari Bilgisi*），A. 科拉坦译，伊斯坦布尔：美术学院出版社，1938年，第75页。（校注：底本原注印作“The Doom Manifesto”，原页已核；该宣言通称“The Doorn Manifesto”，参见[代尔夫特理工大学所存研究](https://research.tudelft.nl/files/157405461/Habitat_EcologyThinking_introductie_ISSUU_nai010.pdf)。此处保留底本原题并注明。）

[13] 据英译本转译：勒·柯布西耶，《模度》第1卷（*The Modulor*），P. de Francia、A. Bostock译，伦敦：Faber and Faber，1961年，第192—197页及以下。

[14] 勒·柯布西耶，《雅典宪章》（*Atina Anlaşması*），A. 约吕坎译，安卡拉：重建与安置部住房总局，1969年，第47页。

[15] 费奥多尔·陀思妥耶夫斯基，《地下室手记》（*Yeraltından Notlar*），M. 厄兹居尔译，伊斯坦布尔：İletişim，2000年，第43页。

[16] 同上书，第49页。

[17] 莫伊谢·金兹堡，《风格与时代》（*Стиль и эпоха*，*Stil' i epokha*），莫斯科，1924年；英文版：《风格与时代》（*Style and Epoch*），A. 森克维奇译，剑桥（马萨诸塞）与伦敦：MIT Press，1983年。

[18] 安东尼·吉登斯，《现代性的后果》（*The Consequences of Modernity*），剑桥：Polity Press，1991年，第18页；土耳其语版：《现代性的后果》（*Modernliğin Sonuçları*），埃尔辛·库什迪尔译，伊斯坦布尔：Ayrıntı，1994年。

[19] 西格弗里德·吉迪恩，《在法国建造：铁建造，钢筋混凝土建造》（*Bauen in Frankreich. Bauen in Eisen, Bauen in Eisenbeton*），莱比锡：Klinkhardt & Biermann，1928年；英文版：《在法国建造：铁建造，钢筋混凝土建造》（*Building in France, Building in Iron, Building in Ferro-Concrete*），J. D. 贝里译，圣莫尼卡：盖蒂出版社，1995年。

[20] 西格弗里德·吉迪恩，《空间、时间与建筑》（*Space, Time and Architecture*），剑桥（马萨诸塞）：哈佛大学出版社，1947年。仅凭这本书成为畅销书、重印数十次这一点，就足以说明历史主义在现代主义内部的力量与扩散程度。

[21] 陀思妥耶夫斯基，同上书，第49—50页。

[22] 卡雷尔·泰格，〈构成主义理论〉（"The Theory of Constructivism"），载《形式追随科学：泰格、吉拉尔与欧洲科学功能主义，1922—1948》（*Forma sleduje vědu: Teige, Gillar a evropský vědecký funkcionalismus 1922–1948 / Form Follows Science: Teige, Gillar, and European Scientific Functionalism, 1922–1948*），布拉格，2000年，第208页。

[23] 就这两位人物的思想，我不知道有西方语言写成的全面研究。简短提及可参见：谢利姆·O. 汉-马戈梅多夫，《苏联建筑的先驱者：1920—1930年代对新解决方案的探索》（*Pioneers of Soviet Architecture: The Search for New Solutions in the 1920s and 1930s*），伦敦：Thames and Hudson，1987年，第143—144页。更详尽的信息参见：谢利姆·O. 汉-马戈梅多夫，《苏联先锋派建筑》第1卷（*Arkhitektura sovetskogo avangarda*），莫斯科：Stroyizdat，1996年，第236—258页。

[24] 德特勒夫·梅尔廷斯，〈生活在丛林中：密斯、有机建筑与城市建造的艺术〉（"Living in a Jungle: Mies, Organic Architecture, and the Art of City Building"），载菲利斯·兰伯特（编），《密斯在美国》（*Mies in America*），纽约：CCA、惠特尼美术馆、Abrams，第591—641页。

[25] 弗兰克·劳埃德·赖特，《一种美国建筑》（*An American Architecture*），埃德加·考夫曼编，纽约：Horizon Press，1955年，第23—28页。

[26] 就土耳其的具体情况，我曾在以下文章中简要谈及这一点：乌古尔·坦耶利，〈"城市规划科学原则"的神话〉（"'Şehircilik Biliminin İlkeleri' Efsanesi"），载《梦、建造、异议：建筑批评文集》（*Rüya, İnşa, İtiraz: Mimari Eleştiri Metinleri*），伊斯坦布尔：Boyut，2013年，第401—404页。

[27] 勒·柯布西耶，《飞机》（*Aircraft*），伦敦：The Studio Ltd.，1935年，无页码，文字位于第61号图片上。

[28] 勒·柯布西耶，《今日装饰艺术》（*L'Art décoratif d'aujourd'hui*），巴黎：Éditions G. Crès，1925年。据英译本转译：《今日装饰艺术》（*The Decorative Art of Today*），J. I. 邓尼特译，剑桥（马萨诸塞）与伦敦：MIT Press，1987年，第74页。

[29] 曼弗雷多·塔夫里，《建筑与乌托邦：设计与资本主义发展》（*Architecture and Utopia: Design and Capitalist Development*），B. L. 拉彭塔译，剑桥（马萨诸塞）与伦敦：MIT Press，1979年，第119页。

[30] 亚历克斯·舒马托夫，《希望之都：巴西利亚及其人民》（*The Capital of Hope: Brasilia and Its People*），纽约：Vintage Books，1980年，第36页。

[31] 〈杜恩宣言〉（"The Doom Manifesto"），载艾莉森·史密森（编），《团队十读本》（*Team 10 Primer*），剑桥（马萨诸塞）与伦敦：MIT Press，1974年，第75页。（校注：底本原注印作“The Doom Manifesto”，原页已核；该宣言通称“The Doorn Manifesto”，参见[代尔夫特理工大学所存研究](https://research.tudelft.nl/files/157405461/Habitat_EcologyThinking_introductie_ISSUU_nai010.pdf)。此处保留底本原题并注明。）

[32] 艾莉森·史密森与彼得·史密森，《平凡与光：1952—1960年的城市理论及其在1963—1970年一个建筑项目中的应用》（*Ordinariness and Light: Urban Theories 1952–1960 and Their Application in a Building Project 1963–1970*），伦敦：Faber and Faber，1970年，第34页。

[33] 马丁·布伯，《我与你》（*Ich und Du*），柏林，1923年。关于范·艾克与这本书的思想联系：利亚娜·勒费夫尔与亚历山大·佐尼斯，《阿尔多·范·艾克：人文主义反叛者，战后世界中的居中》（*Aldo van Eyck: Humanist Rebel, Inbetweening in a Postwar World*），鹿特丹：010 Publishers，1999年，第62页及以下。

[34] 同上书，多处，尤其第131页及以下。
