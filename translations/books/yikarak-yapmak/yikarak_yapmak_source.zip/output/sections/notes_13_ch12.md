## XII

[1] 关于地方问题、本书在此尝试全面阐述的观点，我最初于2011年12月22日在马尔特佩大学发表。该演讲的录音整理稿发表于：乌古尔·坦耶利，〈建筑从来不是普遍的；它在每个被创造的情境中都是特定的……〉，载尼尔·艾纳勒、阿里·帕沙奥卢（编），《工厂》（*Fabrika*），伊斯坦布尔：EAA，2012年，第41—53页。2012年4月6日，我又在米马尔·希南美术大学建筑学院的“星期三研讨课”范围内，以〈作为险恶建筑概念的地方〉为题发表演讲。本文包含这些演讲所表达的内容，但比它们都更全面。

[2] www.livius.org/da-dd/darius/darius_i_t03.html（访问日期：2012年4月16日）。

[3] 多丽丝·贝伦斯—阿布赛义夫，《开罗的伊斯兰建筑：导论》（*Islamic Architecture of Cairo: An Introduction*），开罗：美国开罗大学出版社，1989年，第100页。

[4] 一个非常有趣的新哥特式位移例子是伊斯坦布尔的克里米亚教堂（Kırım Kilisesi）。关于其设计与建造历程，参见马克·克林森，《帝国建造：东方主义与维多利亚建筑》（*Empire Building: Orientalism & Victorian Architecture*），伦敦与纽约：Routledge，1996年，第136—166页。

[5] 关于这个如今已有庞大文献的题目，一份深入的概览性资料：彼得·斯克里弗、维克拉姆阿迪蒂亚·普拉卡什（编），《殖民现代性：英属印度与锡兰的建造、居住与建筑》（*Colonial Modernities: Building, Dwelling and Architecture in British India and Ceylon*），伦敦与纽约：Routledge，2007年。

[6] 就欧洲与美国建筑被直接位移的例子而言，日本比19世纪的奥斯曼帝国提供了更明确的忠于根源的基础。作为一部易于获取但缺少细节和深度的出版物：戴维·B. 斯图尔特，《现代日本建筑的生成：从奠基者到篠原一男与矶崎新》（*The Making of Modern Japanese Architecture: From the Founders to Shinohara and Isozaki*），东京、纽约、伦敦：讲谈社国际，2002年，第13—62页。

[7] 这种强迫劳动力迁移的实践在奥斯曼历史中也有一个有趣的例子。已知在塞利姆二世征服埃及后（校注：底本作II. Selim；征服埃及者实为塞利姆一世，见[埃及旅游与文物部历史介绍](https://egymonuments.gov.eg/en/historical-periods/ottoman-period/)），曾从那里向伊斯坦布尔带来强制征用的工人和专家，以及建筑材料。参见米夏埃尔·迈内克，〈奥斯曼土耳其的马穆鲁克大理石装饰〉（"Memlukischen Marmordekorationen in der osmanischen Türkei"），《德国考古研究所通报，开罗分部》（*Mitteilungen des Deutschen Archäologischen Instituts, Abteilung Kairo*），1971年。

[8] 例如，关于作为拜占庭原始资料的《记述》（*Diegesis*），参见特奥多尔·普雷格（编），《君士坦丁堡起源作家集》（*Scriptores originum Constantinopolitanarum*），第1卷，莱比锡，1902年，第74—108页。

[9] 安东尼·卡特勒，〈从战利品到学术：意大利对拜占庭文物反应方式的变迁〉（"From Loot to Scholarship: Changing Modes in the Italian Response to Byzantine Artifacts"），《敦巴顿橡树园文集》（*Dumbarton Oaks Papers*），卷次XVIX，1995年，第337—338页。（校注：底本卷次和页码如此。[期刊目录](https://www.jstor.org/stable/i255270)所载该文为第49卷，即XLIX，1995年，第237—267页；底本所引337—338页不在该文范围内，确切引页未能据此确定。）

[10] 这位作者的全部著作都关于对折衷主义的否定。最重要的是：西格弗里德·吉迪恩，《空间、时间与建筑：一种新传统的成长》（*Space Time and Architecture: The Growth of a New Tradition*），马萨诸塞州剑桥：哈佛大学出版社，初版1941年。

[11] 图片见：〈纽约长老会教堂，纽约州纽约市〉（"New York Presbyterian Church, New York, NY"），《现代钢结构》（*Modern Steel Construction*），2002年6月。

[12] 塞达·卡伊姆，《1920—1960：伊斯坦布尔—斯图加特线路，通过凯马利·瑟伊莱梅佐卢的职业生涯阅读土耳其—德国建筑关系》，耶尔德兹技术大学自然科学研究院建筑系建筑史与理论项目，未刊硕士论文，伊斯坦布尔，2010年。这项研究是关于斯图加特—伊斯坦布尔建筑线路何等繁忙的唯一一项具体而详尽的分析。

[13] 关于舒尔策—瑙姆堡：诺贝特·博尔曼，《保罗·舒尔策—瑙姆堡，1869—1949：画家、政论家、建筑师》，埃森：R. Bacht，1989年。

[14] 关于施米特亨纳：沃尔夫冈·福伊格特、哈特穆特·弗兰克（编），《保罗·施米特亨纳，1884—1972》，图宾根、柏林：Ernst Wasmuth Verlag，2003年。其观点最全面的表述见：保罗·施米特亨纳，《建筑塑造，第一辑：德国住宅》，斯图加特：Verlag Konrad Wittwer，1932年。

[15] 例如，塞达德·哈克·埃尔德姆，〈民族建筑问题〉（"Milli Mimari Meselesi"），《建筑师》（*Arkitekt*），第9—10期，1939年，第220—223页。

[16] 《空间、时间与建筑》1962年出版的第四版中新增的导论，第xxxvi页及以下。

[17] 其博士论文的印刷版为：比伦特·厄泽尔，《区域主义、普遍主义与我们的当代建筑：一篇尝试》，伊斯坦布尔：伊斯坦布尔技术大学建筑学院，1964年。

[18] 马克·奥热，《非地方：超现代性人类学导论》（*Non-lieux, Introduction à une anthropologie de la surmodernité*），巴黎：Seuil出版社，1992年；英文版：《非地方：超现代性人类学导论》（*Non-Places: Introduction to an Anthropology of Supermodernity*），J. 豪译，伦敦、纽约：Verso，1995年。

[19] 同上，第54页及以下。

[20] 同上，第101页及以下。

[21] 我曾在以下文章中更全面地讨论此点：乌古尔·坦耶利，〈建筑师的记忆与被压扁的过去〉（"Mimarların Hafızası ve Yassıltılmış Geçmiş"），载阿伊谢·申图雷尔、沙法克·乌拉尔、厄兹莱姆·贝尔贝尔、丰达·乌兹·索恩梅兹（编），《时间—空间》，伊斯坦布尔：YEM，2008年，第216—223页。

[22] 以下著作相当成功地描述了德波与约恩，以及情境主义者整体在界定地方与城市问题的新视角方面的作用。有趣的是——正如该群体首批理论性建筑评价的出版日期所表明——建筑界几乎过了半个世纪才注意到这一问题：西蒙·萨德勒，《情境主义城市》（*The Situationist City*），马萨诸塞州剑桥、伦敦：MIT出版社，1998年。关于城市的基本情境主义文本汇编：汤姆·麦克多诺（编），《情境主义者与城市》（*The Situationists and the City*），纽约、伦敦：Verso，2009年。

[23] 这是一份包括网络在内都很容易获取的视觉文献。我使用的是：西蒙·萨德勒，同上，第60页，图1.32。

[24] 居伊·德波，《回忆录：阿斯格·约恩的承重结构，本书完全由预制构件组成》（*Mémoires, Structures portantes d'Asger Jorn, Cet ouvrage est entièrement composé d'éléments préfabriqués*），哥本哈根：Permild & Rosengreen，1959年。
