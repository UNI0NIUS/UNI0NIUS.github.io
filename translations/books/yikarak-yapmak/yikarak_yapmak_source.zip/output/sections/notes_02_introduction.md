## I

[1] 弗里德里希·尼采，《偶像的黄昏，或怎样用锤子从事哲学》（*Götzen-Dämmerung, oder wie man mit dem Hammer philosophiert*），莱比锡：C. G. Naumann，初版1889年；“箴言与箭”章，第26条。

[2] 这场讨论的两篇先驱文本有易于获取的英译本：罗兰·巴特，〈作者的死亡〉（“Death of the Author”），载《图像—音乐—文本》（*Image-Music-Text*），S. Heath译，伦敦：Fontana，1977年，第142—148页（法文原版1967年）；米歇尔·福柯，〈作者是什么？〉（“What Is an Author?”），载《语言、反记忆、实践：米歇尔·福柯访谈与文选》（*Language, Counter-Memory, Practice: Selected Essays and Interviews by Michel Foucault*），D. F. Bouchard编，D. F. Bouchard与S. Simon译，伊萨卡：康奈尔大学出版社，1977年，第113—138页（1969年首次以法文发表演讲）。

[3] 仅建筑师—作者神话在土耳其的建造历程，就足以表明世界上这一领域曾想象出许多彼此并不相似的行动者形象，并使人们有可能怀疑“作者”的权力。参见乌古尔·坦耶利，〈建筑师作者的发明、职业的征服、民族的建构〉（“Mimar Müellifin İcadı, Mesleğin Fethi, Ulusun İnşası”），《社会历史》（*Toplumsal Tarih*），第189期，2009年9月，第68—74页。

[4] 第一份包豪斯宣言以文本和图像两种方式表达了这一点。文本见：www.dnk.de/_uploads/media/186_1919_Bauhaus.pdf（访问日期：2016年8月18日）。

[5] 参见吉奥乔·阿甘本，《渎神》（*Profanations*），Jeff Fort译，纽约：Zone Books，2007年，第9—18页。

[6] 柄谷行人，《作为隐喻的建筑：语言、数、货币》（*Metafor Olarak Mimari: Dil, Sayı, Para*），Barış Yıldırım译，伊斯坦布尔：Metis，2006年。

[7] 维克多·雨果，《巴黎圣母院，1482》（*Notre-Dame de Paris. 1482*），巴黎，1831年，第5卷第2章。土耳其文译本：《巴黎圣母院》（*Notre Dame'ın Kamburu*），V. Yalçıntoklu译，伊斯坦布尔：İş Kültür，2014年。

[8] 例如，几年前巴黎蓬皮杜中心曾就此举行一场公开座谈：“Ceci tuera cela? L'édition d'architecture comme contre-archive”，*Paroles*，2013年11月7日。参见 www.centrepompidou.fr/cpv/resource/cMdkayx/ryj1.1!10R（访问日期：2016年9月2日）。

[9] 米歇尔·福柯，《古典时代疯狂史——疯狂与不理性》（*Histoire de la folie à l'âge classique – Folie et déraison*），巴黎：Plon，1961年。

[10] 米歇尔·福柯，《规训与惩罚》（*Surveiller et punir*），巴黎：Gallimard，1975年。

[11] 亨利·列斐伏尔，《空间的生产》（*La production de l'espace*），巴黎：Anthropos，1974年；土耳其文译本：《空间的生产》（*Mekânın Üretimi*），Işık Ergüden译，伊斯坦布尔：Sel，2014年。

[12] 乔治·巴塔耶，〈建筑〉（“Architecture”），《全集》（*Œuvres complètes*），第1卷，巴黎：Gallimard，1971年，第171—172页。

[13] 德尼·奥利耶，《反对建筑：乔治·巴塔耶的写作》（*Against Architecture: The Writings of Georges Bataille*），B. Wing译，剑桥（马萨诸塞）与伦敦：October Books、MIT Press，1992年，第47—51页。

[14] 参见乌古尔·坦耶利，〈作为一种现代性问题的死亡审美化与土耳其〉（“Bir Modernlik Sorunsalı Olarak Ölümü Estetize Etmek ve Türkiye”），《死亡、艺术与空间研讨会》（*Ölüm Sanat ve Mekân Sempozyumu*），2010年11月4—5日，MSGSÜ，Gevher Gökçe Acar编，伊斯坦布尔：Dakam，2011年，第73页及以下。

[15] www.parliament.uk/about/living-heritage/transformingsociety/livinglearning/19thcentury/keydates/（访问日期：2016年9月8日）。

[16] 弗里德里希·恩格斯，《英国工人阶级状况》（*Die Lage der arbeitenden Klasse in England*），莱比锡，1845年；土耳其文译本：《英国工人阶级状况》（*İngiltere'de Emekçi Sınıfların Durumu*），Oktay Emre译，伊斯坦布尔：Ayrıntı，2013年。

[17] 奥古斯都·W. N. 普金，《对比：或十四、十五世纪的高贵建筑与当代类似建筑之平行比较，展示当今趣味的衰败，并附相应文本》（*Contrasts: Or, A Parallel Between the Noble Edifices of the Fourteenth and Fifteenth Centuries and Similar Buildings of the Present Day. Shewing the Present Decay of Taste. Accompanied by Appropriate Text*），作者自印，伦敦，1836年。

[18] 他的著作中，《不把穹顶放在地上》（*Kubbeyi Yere Koymamak*）、《奥斯曼城市》（*Osmanlı Şehri*）、《理解伊斯坦布尔》（*İstanbul'u Anlamak*）、《伊斯兰中的城市与建筑》（*İslam'da Şehir ve Mimari*）等书由不同出版社多次再版。

[19] 保罗·梅贝斯，《约1800年：在其传统发展最后一百年中的建筑与手工艺》（*Um 1800. Architektur und Handwerk im letzten Jahrhundert ihrer traditionellen Entwicklung*），2卷，慕尼黑：Bruckmann，1908年。

[20] 保罗·舒尔策-瑙姆堡在这一主题上最重要的作品是“文化工作”（*Kulturarbeiten*）丛书。这套九卷本包括：第1卷：*Hausbau*，1901年；第2卷：*Gärten*，1902年；第3卷：*Dörfer und Kolonien*，1904年；第4卷：*Städtebau*，1906年；第5卷：*Das Kleinbürgerhaus*，1907年；第6卷：*Das Schloß*，1910年；第7—9卷：*Die Gestaltung der Landschaft durch den Menschen*：第7卷：第一部分，I. *Wege und Strassen*；II. *Die Pflanzenwelt und ihre Bedeutung im Landschaftsbilde*，1916年；第8卷：第二部分，III. *Der geologische Aufbau der Landschaft und die Nutzbarmachung der Mineralien*；IV. *Wasserwirtschaft*，1916年；第9卷：第三部分，V. *Industrie*；VI. *Siedlungen*，1917年。均由慕尼黑G. D. W. Callwey出版。

[21] 保罗·舒尔策-瑙姆堡，《艺术与种族》（*Kunst und Rasse*），慕尼黑：Lehmann，1928年。

[22] 他的两部书尤为重要：保罗·施米特亨纳，《德国住宅》（*Das deutsche Wohnhaus*），第1卷《建筑造型》（*Baugestaltung*），斯图加特：Wittwer，1932年；《艺术中的温柔法则，特别是建筑艺术中的温柔法则。演讲》（*Das sanfte Gesetz in der Kunst, in Sonderheit in der Baukunst. Rede*），斯特拉斯堡：Hünenburg，1943年。

[23] 参见埃米内·塞达·卡伊姆，《1920—1960：沿伊斯坦布尔—斯图加特线路，从凯马利·瑟伊莱梅佐卢的职业生涯解读土耳其—德国建筑关系》（*1920-1960: İstanbul-Stuttgart Hattı Kemali Söylemezoğlu'nun Kariyeri Üzerinden Türk-Alman Mimarlık İlişkilerini Okumak*），未刊硕士学位论文，伊斯坦布尔：耶尔德兹技术大学，2010年。

[24] 例如参见塞达德·哈克·埃尔德姆，〈走向本土建筑〉（“Yerli Mimariye Doğru”），《建筑师》（*Arkitekt*）10/3—4，1940年，第69—74页。关于新版及评价：比伦特·坦朱，《犹豫与重复：建筑与城市文本，1873—1960》（*Tereddüt ve Tekerrür: Mimarlık ve Kent Üzerine Metinler 1873-1960*），伊斯坦布尔：Akın Nalça Kitapları，2008年，第284页及以下。

[25] 我曾在此前文章中也提及埃尔德姆、詹塞维尔与德国的联系：乌古尔·坦耶利，〈重新审视詹塞维尔的建筑与思想：一幅世俗肖像〉（“Cansever'in Mimarisine ve Düşüncesine Yeniden Bakmak: Sektiler Bir Portre”），《Arredamento Mimarlık》，第278期，2014年4月，第64—65页。

[26] 乔治·西美尔，《现代文化的冲突。一次演讲》（*Der Konflikt der modernen Kultur. Ein Vortrag*），慕尼黑与莱比锡：Verlag Duncker & Humblot，1918年；土耳其文译本：乔治·西美尔，《现代文化中的冲突》内（*Modern Kültürde Çatışma*），Tanıl Bora译，伊斯坦布尔：İletişim，2004年；socio.ch/sim/verschiedenes/1918/kultur.htm（访问日期：2016年8月15日）。不过，西美尔仍然相信，他所说的无形式状态终将结束，有一天会抵达一个新的形式生产阶段，因为在上文所引表述之后紧接着的句子是：“然而，由于这一事件的范围尚未使这种冲动集中于新形式的创造，它几乎从必然性中造出美德，并使自己不得不仅仅因为形式是形式而与之斗争。”

[27] 乔治·西美尔，《现代文化的冲突。一次演讲》。第二篇文章见：乔治·西美尔，《社会学：关于社会关联化形式的研究》（*Soziologie: Untersuchungen über die Formen der Vergesellschaftung*），Verlag Duncker & Humblot，柏林，1908年，“第4章：斗争”（“Kapitel IV: Der Streit”），第186—255页。

[28] 最后三段取自拙文：乌古尔·坦耶利，〈专题：禁令！〉（“Dosya: Yasak!”），《Arredamento Mimarlık》，第245期，2011年4月，第66—67页。
