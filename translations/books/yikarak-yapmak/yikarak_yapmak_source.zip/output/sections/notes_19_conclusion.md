## 代结论

[1] 叶夫根尼·扎米亚京，《我们》（*Biz*），Ömer Ertan Yurtsever译，伊斯坦布尔：Aylak Adam，2016年，第43页。

[2] www.finnisharchitecture.fi/2016/06/venice-biennale-searching-for-architectural-solutions-to-support-migrants-and-refugees/（访问日期：2016年11月5日）。

[3] 荷兰籍设计师：eia@td-architects.eu；项目网站：www.europeinafrica.com/（访问日期：2016年11月5日）。
