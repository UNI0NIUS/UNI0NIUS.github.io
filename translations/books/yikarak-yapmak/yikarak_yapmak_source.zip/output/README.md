# 破而后立：为一种无政府主义建筑理论作预备

作者：Uğur Tanyeli。土耳其语底本：Metis，2017年4月首版。
中文工作译本：AI辅助翻译、逐章语义校对及全书一致性检查。

## 使用

- 中文阅读PDF另行下载（yikarak_yapmak_zh.pdf）：202页，目录和原注可跳转；不重复收入源码包。
- output/yikarak_yapmak_zh.md：含74张插图的中文合并稿；图片相对路径应保持不变。
- output/sections：43份规范正文与原注文件。先改此处，再生成成果。
- output/figures.json、output/images：插图来源页、裁切区域、哈希及图像。
- work/review：与版本绑定的校对和验收证据。原注311条；原作者论断并非全部独立事实查证。

## 重建

需要Python 3、markdown-it-py、Pandoc、XeLaTeX（TeX Live 2025）；本版使用Times New Roman、SimSun、Microsoft YaHei，字体未打包。
在书根运行：

    python work/build_final.py
    python work/build_print.py
    python work/build_web.py
    cd output
    xelatex -interaction=nonstopmode -halt-on-error yikarak_yapmak_zh.tex

目录/交叉引用变化时再编译一次。打印生成脚本仅产生Markdown和TeX，不会自动调用XeLaTeX。
校对哈希不匹配会停止生成；修改规范稿后先更新与实际审阅相符的增量证据，不要跳过检查。不要重跑历史初稿生成器。

## 来源与授权记录

底本由用户提供，原PDF未收入此下载包。原文与插图版权归原作者及相应权利人；本任务已获用户明确授权制作并发布至其个人主页，未据此声称拥有另行授予的开放许可或权利人许可文件。
原始PDF SHA256：1bba1e379f7a8434be35d240a780a74ab14d07543e67bd481ee913452a67d1b5。
原书页码、原注、校注与输出页码分开保留。图源242标号的《大使们》实际在244页，已校注。

## 2026-10-20 书名与术语修订

书名采用《破而后立：为一种无政府主义建筑理论作预备》。“破而后立”是意译；原文强调破坏与建构交织，新事物产生于旧事物留下的语境，详见前置译名说明。本轮涉及14分节，页码、311原注与74插图不变，修订报告为work/review/title_terms_20261020.json；对应PDF与网页验收记录为title_terms_pdf_gate.json和title_terms_web_gate.json。完整术语表见terminology_decisions.json。
