# 破而后立：为一种无政府主义建筑理论作预备

作者：Uğur Tanyeli。土耳其语底本：Metis，2017年4月首版。
中文工作译本：AI辅助翻译、逐章语义校对及全书一致性检查。

## 使用

- 中文阅读PDF另行下载（yikarak_yapmak_zh.pdf）：187页（2026-10-21续段修复版），目录和原注可跳转；不重复收入源码包。
- output/yikarak_yapmak_zh.md：含74张插图的中文合并稿；图片相对路径应保持不变。
- output/sections：43份规范正文与原注文件。先改此处，再生成成果。
- output/figures.json、output/images：插图来源页、裁切区域、哈希及图像。
- work/review：与版本绑定的校对和验收证据。原注311条；原作者论断并非全部独立事实查证。

## 重建

需要Python 3、markdown-it-py、Pandoc、XeLaTeX（TeX Live 2025）；本版使用Times New Roman、SimSun、Microsoft YaHei，字体未打包。
在书根运行：

    python work/build_final.py
    python work/build_print.py
    python work/build_web.py
    cd output
    xelatex -interaction=nonstopmode -halt-on-error yikarak_yapmak_zh.tex

目录/交叉引用变化时再编译一次。打印生成脚本仅产生Markdown和TeX，不会自动调用XeLaTeX。
校对哈希不匹配会停止生成；修改规范稿后先更新与实际审阅相符的增量证据，不要跳过检查。不要重跑历史初稿生成器。

## 来源与授权记录

底本由用户提供；2026-10-21土耳其语补充版已将原始PDF收入源码包，以复现原文页影及对照版。原文与插图版权归原作者及相应权利人；本任务已获用户明确授权制作并发布至其个人主页，未据此声称拥有另行授予的开放许可或权利人许可文件。
原始PDF SHA256：1bba1e379f7a8434be35d240a780a74ab14d07543e67bd481ee913452a67d1b5。
原书页码、原注、校注与输出页码分开保留。图源242标号的《大使们》实际在244页，已校注。

## 2026-10-20 书名与术语修订

书名采用《破而后立：为一种无政府主义建筑理论作预备》。“破而后立”是意译；原文强调破坏与建构交织，新事物产生于旧事物留下的语境，详见前置译名说明。本轮涉及14分节，页码、311原注与74插图不变，修订报告为work/review/title_terms_20261020.json；对应PDF与网页验收记录为title_terms_pdf_gate.json和title_terms_web_gate.json。完整术语表见terminology_decisions.json。

## 2026-10-21 土耳其语与中土对照

网页提供中文、Türkçe、中土对照三种视图。土耳其语以用户提供的扫描PDF原页影为准，完整保留原注、插图、空白页和书前封底。折叠OCR文字直接保留PDF隐藏文字层，仅供检索，未宣称为已校正的土耳其语全文。中土对照按底本页序配对，保留原中文段落ID；这不是逐句对齐。

- yikarak_yapmak_tr.pdf：369页原始土耳其语PDF，字节与用户底本一致。
- yikarak_yapmak_bilingual.pdf：371页中土对照PDF，左为中文及中文原注，右为完整土耳其语底本页。第366、367源页各有一页中文续排，原页随续排重复呈现。中文插图可直接对照右侧原页；中文图文PDF也已按用户追加要求重排为187页，另行下载。
- output/source_pages.json：369页的来源、尺寸、页影哈希、原始OCR文字；页影本身可由脚本重建，不重复收入源码包。
- work/review/turkish_pdf_page_map.json：底本页与对照PDF页的映射。

新增依赖为PyMuPDF、Pillow。先按原步骤生成中文网页，再在书根运行：

    python work/build_source_editions.py
    python work/verify_source_editions.py

该脚本不会重写中文规范分节或中文PDF；中文续段排版另由build_final.py、build_print.py及下述规范映射控制。保留原始PDF在书根（文件名保持不变）。如仅重建网页，可加 --web-only；已有规范source_pages.json时，build_web.py会自动补充原文网页数据。

packaging脚本work/package_source_editions.py用于本工作区发布暂存，默认寻找同级homepage-union；独立阅读或重建PDF无需运行它。下载包不重复收入生成PDF。

## 跨底本页的续段（2026-10-21用户追加要求）

output/paragraph_continuations.json是与43份分节共同使用的规范结构映射，保存251处经核对的跨页续段、76个独立图注/图注校注ID、原段MD绑定，以及接页时人为插入的破折号修正。分节保留来源片段以便定位；合并Markdown、中文PDF和网页阅读时按照该映射恢复连续段落。真正换段、标题、引文和图注不因此合并。原页码在续段内保留，旧网页锚点变为相应段内定位点。

维护时先核对分节和结构映射；不要仅按句末标点或全局删除换行。work/paragraph_continuations.py是重建所需依赖。网页土耳其语页影按关联的原书页组合展示；原扫描件的物理分页当然保留。中土对照PDF以底本物理页为面对页定位；连续阅读可使用已恢复段落的187页中文PDF。

检查证据：continued_chinese_pdf_gate.json（4574片段）、turkish_pdf_text_gate.json（4648片段）、turkish_browser_gate.json（25章×3视图×桌面/390px）、turkish_visual_gate.json。详细跨页边界证据见paragraph_boundary_review.json。
