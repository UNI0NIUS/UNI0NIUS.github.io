"""Version-bound coverage and PDF text checks for the source supplement."""
import datetime, hashlib, json, re, sys, unicodedata
from pathlib import Path
import pymupdf as fitz

sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'output'; REVIEW=ROOT/'work/review'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def norm(s):
    s=unicodedata.normalize('NFKC',s)
    return re.sub(r'[\s\u00ad\u200b-]+','',s).translate(str.maketrans({'‘':"'",'’':"'",'“':'"','”':'"'}))
def strings(tokens):
    for t in tokens:
        if isinstance(t,str):yield t
        elif t['type']!='note':yield from strings(t.get('children',[]))

before_path=REVIEW/'turkish_20261021_status.json'
before=read(before_path) if before_path.exists() else read(REVIEW/'book_text_gate.json')
assert {p.name:sha(p) for p in (OUT/'sections').glob('*.md')}==before['canonical_sha256']
chinese_pdf_unchanged=sha(OUT/'yikarak_yapmak_zh.pdf')==before.get('chinese_pdf_sha256')
manifest=read(OUT/'source_pages.json')
assert sha(OUT/'yikarak_yapmak_tr.pdf')==manifest['source_pdf_sha256']
assert len(manifest['pages'])==369
for p in manifest['pages']:assert sha(OUT/p['file'])==p['sha256']
mapping=read(REVIEW/'turkish_pdf_page_map.json')
doc=fitz.open(OUT/'yikarak_yapmak_bilingual.pdf')
assert len(doc)==mapping['output_pages']
text_by_source={n:'' for n in range(1,370)}
outside=[]
for item in mapping['mapping']:
    page=doc[item['output_page']-1]
    text_by_source[item['source_pdf_page']]+=page.get_text(clip=fitz.Rect(0,40,595,805))
    for b in page.get_text('dict')['blocks']:
        for line in b.get('lines',[]):
            for s in line['spans']:
                if s['text'].strip() and (s['bbox'][0]<0 or s['bbox'][1]<0 or s['bbox'][2]>1190.1 or s['bbox'][3]>842.1):outside.append(item['output_page'])
assert not outside,outside
text_by_source={n:norm(t) for n,t in text_by_source.items()}
checked=0;failures=[];notes=set();rows=0
metadata=read(OUT/'webdata/book-metadata.json')
for chapter in metadata['chapters']:
    data=read(OUT/'webdata'/f"{chapter['id']}.json")
    groups={rid:int(g['page']) for g in data['facsimilePages'] for rid in g['rows']}
    for row in data['body']:
        from paragraph_continuations import adjusted_row
        row=adjusted_row(row,data)
        rows+=1;n=groups[row['id']]
        for text in strings(row['zh']):
            text=norm(text)
            for i in range(0,len(text),70):
                chunk=text[i:i+70]
                if len(chunk)<8:continue
                checked+=1
                if chunk not in text_by_source[n]:failures.append({'row':row['id'],'page':n,'chunk':chunk})
        def refs(ts):
            for t in ts:
                if isinstance(t,dict):
                    if t['type']=='note':yield t['id']
                    yield from refs(t.get('children',[]))
        for nid in refs(row['zh']):
            notes.add(nid)
            for text in strings(data['notes'][nid]['zh']):
                text=norm(text)
                for i in range(0,len(text),70):
                    chunk=text[i:i+70]
                    if len(chunk)<8:continue
                    checked+=1
                    if chunk not in text_by_source[n]:failures.append({'note':nid,'page':n,'chunk':chunk})
assert len(notes)==311
gate={'checked_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
      'passed':not failures,'source_pages':369,'pdf_pages':len(doc),'preserved_chinese_rows':rows,
      'original_notes':len(notes),'checked_text_chunks':checked,'failures':failures,
      'outside_page_text':outside,'source_pdf_sha256':sha(OUT/'yikarak_yapmak_tr.pdf'),
      'bilingual_pdf_sha256':sha(OUT/'yikarak_yapmak_bilingual.pdf'),
      'chinese_pdf_unchanged':chinese_pdf_unchanged,'canonical_chinese_unchanged':True,
      'chinese_pdf_revision':'User additionally required removal of paragraph breaks caused by source pagination; reviewed continuation map now normalizes reading outputs.',
      'method':'369 source-page groups; left-column extraction only, NFKC, whitespace/hyphen/quote normalization; Chinese body and notes checked as 70-character chunks.'}
(REVIEW/'turkish_pdf_text_gate.json').write_text(json.dumps(gate,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in gate.items() if k!='failures'},ensure_ascii=False))
print('Failures:',len(failures),str(failures[:4]))
assert not failures
