"""Add faithful Turkish facsimiles and page-aligned Chinese/Turkish editions.

The supplied scan is authoritative. Its hidden OCR is retained verbatim as
search assistance, not silently promoted to a corrected Turkish transcription.
Chinese sections and the approved Chinese PDF are never rewritten here.
"""
from pathlib import Path
import datetime, hashlib, html, io, json, shutil, sys
import pymupdf as fitz
from PIL import Image

sys.stdout.reconfigure(encoding='utf-8')
ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'output'
REVIEW = ROOT / 'work/review'
SOURCE = ROOT / 'Yıkarak Yapmak Anarşist Bir Mimarlık Kuramı İçin Altlık Uğur Tanyeli.pdf'
SOURCE_HASH = '1bba1e379f7a8434be35d240a780a74ab14d07543e67bd481ee913452a67d1b5'

def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p, d): p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def prepare_source():
    assert digest(SOURCE) == SOURCE_HASH
    pages_dir = OUT / 'source-pages'
    pages_dir.mkdir(exist_ok=True)
    doc = fitz.open(SOURCE)
    pages = []
    assert len(doc) == 369
    for n, page in enumerate(doc,1):
        target = pages_dir / f'page-{n:03}.webp'
        if not target.exists():
            cached_jpeg=pages_dir/f'page-{n:03}.jpg'
            if cached_jpeg.exists(): image=Image.open(cached_jpeg)
            else:
                pix = page.get_pixmap(matrix=fitz.Matrix(1440/page.rect.width,1440/page.rect.width),alpha=False)
                image=Image.frombytes('RGB',(pix.width,pix.height),pix.samples)
            image.save(target,format='WEBP',quality=88,method=4)
        image = Image.open(target)
        pages.append({'pdf_page':n,'printed_page':str(n) if 9 <= n <= 368 else None,
                      'file':f'source-pages/{target.name}','sha256':digest(target),
                      'width':image.width,'height':image.height,
                      'ocr_blocks':[b[4].strip() for b in page.get_text('blocks',sort=True) if b[6]==0 and b[4].strip()]})
    manifest={'source_pdf_sha256':SOURCE_HASH,'page_count':369,
              'authority':'Original scan facsimile; OCR blocks are uncorrected search assistance.',
              'pages':pages}
    save(OUT/'source_pages.json',manifest)
    shutil.copy2(SOURCE,OUT/'yikarak_yapmak_tr.pdf')
    return manifest

def enrich_web(manifest):
    web = OUT/'webdata'
    metadata=json.loads((web/'book-metadata.json').read_text(encoding='utf-8'))
    sections=json.loads((ROOT/'work/clean_source.json').read_text(encoding='utf-8'))
    # Canonical web order incorporates the unnumbered plate at PDF p.228 into IX.
    source_sections=[s for s in sections if s['slug']!='plate228']
    assert len(source_sections)==len(metadata['chapters'])==25
    all_rows=[]; all_pages=[]
    for chapter, source in zip(metadata['chapters'],source_sections):
        data=json.loads((web/f"{chapter['id']}.json").read_text(encoding='utf-8'))
        start,end=source['start_pdf_page'],source['end_pdf_page']
        if source['slug']=='preface':end=11
        if source['slug']=='ch01':start=12
        if source['slug']=='ch09':end=228
        title=source['title_tr'] or ('Ön sayfalar' if source['slug']=='front' else 'Arka kapak')
        chapter['originalTitle']=title
        data['originalTitle']=title
        data['sourceMode']='facsimile'
        data['sourcePdf']='translations/books/yikarak-yapmak/yikarak_yapmak_tr.pdf'
        groups={n:[] for n in range(start,end+1)}
        for row in data['body']:
            n=int(row['page']) if row.get('page') else start
            assert n in groups,(chapter['id'],row['id'],n,start,end)
            groups[n].append(row['id'])
            all_rows.append(row['id'])
        data['facsimilePages']=[]
        for n, ids in groups.items():
            p=manifest['pages'][n-1]
            data['facsimilePages'].append({'id':f'yy-source-{n:03}', 'page':str(n),
                'pageKind':'printed' if p['printed_page'] else 'pdf',
                'src':f"translations/books/yikarak-yapmak/{p['file']}",
                'width':p['width'],'height':p['height'],'rows':ids,'ocrBlocks':p['ocr_blocks']})
            all_pages.append(n)
        save(web/f"{chapter['id']}.json",data)
    assert len(all_rows)==len(set(all_rows))==970
    assert all_pages==list(range(1,370))
    metadata.update({'bilingual':True,'views':['zh','en','parallel'],
        'sourceLanguage':'tr','sourceLanguageLabel':'Türkçe','languagePair':'Türkçe / 中文',
        'description':'建筑理论、现代性与无政府主义。中文校订稿、土耳其语原书页影及按原书页码配对的中土对照，含原注与插图。',
        'editionNotice':'中文据2017年土耳其语底本校订。中土对照按底本页码配对，保留中文段落链接；土耳其语以原书页影为准，页影含原注及插图。折叠的OCR文字仅供检索，识别有误时请核对页影。书前、封底无印刷页码处标底本页序。',
        'downloads':[
            {'label':'中土对照PDF','url':'translations/books/yikarak-yapmak/yikarak_yapmak_bilingual.pdf'},
            {'label':'土耳其语原书PDF','url':'translations/books/yikarak-yapmak/yikarak_yapmak_tr.pdf'},
            {'label':'中文PDF','url':'translations/books/yikarak-yapmak/yikarak_yapmak_zh.pdf'},
            {'label':'中文Markdown','url':'translations/books/yikarak-yapmak/yikarak_yapmak_zh.md'},
            {'label':'规范稿与源码包','url':'translations/books/yikarak-yapmak/yikarak_yapmak_source.zip'}]})
    save(web/'book-metadata.json',metadata)
    save(REVIEW/'turkish_web_data_gate.json',{'passed':True,'source_sha256':SOURCE_HASH,
        'pages':369,'chapters':25,'preserved_chinese_rows':970,'alignment':'source page',
        'chapter_sha256':{p.name:digest(p) for p in web.glob('*.json')}})

def tokens_html(tokens):
    result=''
    for t in tokens or []:
        if isinstance(t,str): result+=html.escape(t)
        elif t['type']=='note':result+=f"<sup>[{t['id'].split('-')[-1]}]</sup>"
        elif t['type']=='break':result+='<br>'
        elif t['type'] in ('em','strong','sup','sub'):
            tag=t['type']; result+=f'<{tag}>'+tokens_html(t['children'])+f'</{tag}>'
        elif t['type']=='link':result+=tokens_html(t['children'])
        else:raise ValueError(t)
    return result

def build_parallel_pdf():
    source=fitz.open(OUT/'yikarak_yapmak_tr.pdf')
    result=fitz.open()
    metadata=json.loads((OUT/'webdata/book-metadata.json').read_text(encoding='utf-8'))
    toc=[]; mapping=[]
    buffer=io.BytesIO();writer=fitz.DocumentWriter(buffer)
    for chapter in metadata['chapters']:
        data=json.loads((OUT/'webdata'/f"{chapter['id']}.json").read_text(encoding='utf-8'))
        rows={r['id']:r for r in data['body']}
        toc.append([1,chapter['title'],len(mapping)+1])
        for group in data['facsimilePages']:
            n=int(group['page']);parts=[];seen_notes=set()
            for rid in group['rows']:
                from paragraph_continuations import adjusted_row
                row=adjusted_row(rows[rid],data)
                if row['type']=='figure':
                    # The full source image is already present in the facing column.
                    parts.append('<p class="caption">'+tokens_html(row['zh'])+'</p>')
                    continue
                tag='h2' if row['type']=='heading' else 'h3' if row['type']=='subheading' else 'p'
                parts.append(f'<{tag}>'+tokens_html(row['zh'])+f'</{tag}>')
                def walk(ts):
                    for t in ts:
                        if isinstance(t,dict):
                            if t['type']=='note':yield t['id']
                            yield from walk(t.get('children',[]))
                for note_id in walk(row['zh']):
                    if note_id not in seen_notes:
                        seen_notes.add(note_id)
                        parts.append('<p class="note">['+note_id.split('-')[-1]+'] '+tokens_html(data['notes'][note_id]['zh'])+'</p>')
            if not parts:parts=['<p>本页无独立中文正文，见右侧底本原页。</p>']
            # Story paginates at a fixed readable size, rather than shrinking long notes.
            story=fitz.Story(html=''.join(parts),user_css='body{font-family:sans-serif;font-size:11pt;line-height:1.55}h2{font-size:16pt}h3{font-size:13pt}.note{font-size:9pt;color:#444}.caption{font-size:9pt;color:#666}p{margin:0 0 9pt}',em=11)
            more=True; first=len(mapping)
            while more:
                device=writer.begin_page(fitz.Rect(0,0,595,842))
                more,_=story.place(fitz.Rect(38,50,557,795))
                story.draw(device);writer.end_page()
                mapping.append({'output_page':len(mapping)+1,'source_pdf_page':n,'continuation':len(mapping)-first+1})
            for item in mapping[first:]:item['parts']=len(mapping)-first
        print('PDF chapter complete:',chapter['id'],flush=True)
    writer.close()
    chinese=fitz.open(stream=buffer.getvalue(),filetype='pdf')
    for k,item in enumerate(mapping):
        n=item['source_pdf_page']
        page=result.new_page(width=1190,height=842)
        page.show_pdf_page(fitz.Rect(0,0,595,842),chinese,k)
        page.show_pdf_page(fitz.Rect(610,48,1170,795),source,n-1)
        label=f'Yikarak Yapmak | source p. {n} | Chinese / Turkce'
        if item['parts']>1:label+=f" | {item['continuation']}/{item['parts']}"
        page.insert_text((38,27),label,fontsize=9,color=(.35,.35,.35))
        page.insert_text((1120,823),str(k+1),fontsize=9)
    result.set_toc(toc)
    result.set_metadata({'title':metadata['title']+' / Yıkarak Yapmak','author':'Uğur Tanyeli','subject':'Chinese / Turkish page-aligned facsimile edition; unmodified source scan and reviewed Chinese translation.'})
    result.save(OUT/'yikarak_yapmak_bilingual.pdf',garbage=4,deflate=True)
    save(REVIEW/'turkish_pdf_page_map.json',{'source_pages':369,'output_pages':len(result),'mapping':mapping})

if __name__=='__main__':
    manifest=prepare_source()
    # build_web.py calls enrich_web after exporting the unchanged Chinese data.
    import subprocess
    subprocess.run([sys.executable,str(ROOT/'work/build_web.py')],check=True)
    if '--web-only' not in sys.argv:build_parallel_pdf()
