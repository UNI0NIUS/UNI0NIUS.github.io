#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Assemble the translated sections and endnotes into the local Markdown book.

Structural checks only: page markers, note/reference sequences, headings and
encoding. No semantic proofreading is performed by this script.
"""
from __future__ import annotations

import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SECTIONS = ROOT / "output" / "sections"
OUT = ROOT / "output" / "yikarak_yapmak_zh.md"
AUDIT = ROOT / "work" / "final_audit.json"

SECTION_ORDER = [
    "00_front.md",
    "01_preface.md",
    "02_introduction.md",
    "03_ch01.md",
    "04_ch02.md",
    "04a_part01.md",
    "05_ch03.md",
    "06_ch05.md",
    "07_ch06.md",
    "08_ch07.md",
    "09_ch08.md",
    "09a_part02.md",
    "10_ch09.md",
    "11_ch10.md",
    "12_ch11.md",
    "13_ch12.md",
    "14_ch13.md",
    "14a_part03.md",
    "15_ch14.md",
    "16_ch15.md",
    "17_ch16.md",
    "18_ch17.md",
    "19_conclusion.md",
    "20_image_credits.md",
    "21_back_cover.md",
]

NOTE_ORDER = [
    "notes_02_introduction.md",
    "notes_03_ch01.md",
    "notes_04_ch02.md",
    "notes_05_ch03.md",
    "notes_06_ch05.md",
    "notes_07_ch06.md",
    "notes_08_ch07.md",
    "notes_09_ch08.md",
    "notes_10_ch09.md",
    "notes_11_ch10.md",
    "notes_12_ch11.md",
    "notes_13_ch12.md",
    "notes_14_ch13.md",
    "notes_15_ch14.md",
    "notes_16_ch15.md",
    "notes_17_ch16.md",
    "notes_18_ch17.md",
    "notes_19_conclusion.md",
]

NOTE_PAIRS = [
    ("02_introduction.md", "notes_02_introduction.md"),
    ("03_ch01.md", "notes_03_ch01.md"),
    ("04_ch02.md", "notes_04_ch02.md"),
    ("05_ch03.md", "notes_05_ch03.md"),
    ("06_ch05.md", "notes_06_ch05.md"),
    ("07_ch06.md", "notes_07_ch06.md"),
    ("08_ch07.md", "notes_08_ch07.md"),
    ("09_ch08.md", "notes_09_ch08.md"),
    ("10_ch09.md", "notes_10_ch09.md"),
    ("11_ch10.md", "notes_11_ch10.md"),
    ("12_ch11.md", "notes_12_ch11.md"),
    ("13_ch12.md", "notes_13_ch12.md"),
    ("14_ch13.md", "notes_14_ch13.md"),
    ("15_ch14.md", "notes_15_ch14.md"),
    ("16_ch15.md", "notes_16_ch15.md"),
    ("17_ch16.md", "notes_17_ch16.md"),
    ("18_ch17.md", "notes_18_ch17.md"),
    ("19_conclusion.md", "notes_19_conclusion.md"),
]


def read(name: str) -> str:
    return (SECTIONS / name).read_text(encoding="utf-8").strip()


def page_markers(text: str) -> list[int]:
    return [int(x) for x in re.findall(r"〔原书第(\d+)页〕", text)]


def refs(text: str) -> list[int]:
    return [int(x) for x in re.findall(r"\[(\d+)\]", text)]


def note_numbers(text: str) -> list[int]:
    return [int(x) for x in re.findall(r"^\[(\d+)\]", text, re.M)]


def main() -> None:
    evidence_path = ROOT / "work" / "review" / "book_text_gate.json"
    evidence = json.loads(evidence_path.read_text(encoding="utf-8"))
    for name, expected in evidence["canonical_sha256"].items():
        assert hashlib.sha256((SECTIONS / name).read_bytes()).hexdigest().lower() == expected.lower(), f"review evidence stale: {name}"
    body_parts = [read(name) for name in SECTION_ORDER]
    note_parts = [read(name) for name in NOTE_ORDER]

    pages: list[int] = []
    section_stats = {}
    for name, text in zip(SECTION_ORDER, body_parts):
        ps = page_markers(text)
        section_stats[name] = {
            "pages": ps,
            "page_count": len(ps),
            "refs": len(refs(text)),
            "bytes": len(text.encode("utf-8")),
            "chars": len(text),
        }
        pages.extend(ps)

    assert pages == list(range(1, 370)), "page markers must cover 1..369 exactly"
    assert all("原书第" not in line or re.fullmatch(r"〔原书第\d+页〕", line.strip())
               for text in body_parts for line in text.splitlines()), "nonstandard page marker"

    note_counts = {}
    total_notes = 0
    for name, text in zip(NOTE_ORDER, note_parts):
        ns = note_numbers(text)
        assert ns == list(range(1, len(ns) + 1)), f"note sequence broken: {name}"
        note_counts[name] = len(ns)
        total_notes += len(ns)

    for body_name, note_name in NOTE_PAIRS:
        body = read(body_name)
        rs = refs(body)
        ns = note_numbers(read(note_name))
        assert rs == list(range(1, len(rs) + 1)), f"ref sequence broken: {body_name}"
        assert len(rs) == len(ns), (body_name, len(rs), len(ns))
    assert total_notes == 311, total_notes

    document = "\n\n".join(body_parts)
    figures_path = ROOT / "output" / "figures.json"
    figures = json.loads(figures_path.read_text(encoding="utf-8"))
    assert len(figures["entries"]) == 74
    for figure in figures["entries"]:
        asset = ROOT / "output" / figure["file"]
        assert hashlib.sha256(asset.read_bytes()).hexdigest() == figure["sha256"]
        assert figure["status"] == "crop_visual_passed"
        marker = f'〔原书第{figure["source_page"]}页〕'
        assert document.count(marker) == 1
        document = document.replace(marker, marker + f'\n\n![{figure["alt"]}]({figure["file"]})')
    from paragraph_continuations import apply_markdown
    normalized_parts=[]
    for name,part in zip(SECTION_ORDER,body_parts):
        for figure in figures['entries']:
            marker=f'〔原书第{figure["source_page"]}页〕'
            if marker in part:part=part.replace(marker,marker+f'\n\n![{figure["alt"]}]({figure["file"]})')
        normalized_parts.append(apply_markdown(part,Path(name).stem))
    document='\n\n'.join(normalized_parts)
    document += "\n\n# 原注\n\n" + "\n\n".join(note_parts) + "\n"

    final_pages = page_markers(document)
    headings = [line for line in document.splitlines() if line.startswith("#")]
    assert len(final_pages) == 369
    assert final_pages == sorted(final_pages)
    assert "�" not in document
    assert document.count("# 原注") == 1

    raw = document.encode("utf-8")
    assert b"\r\n" not in raw, "output must use LF newlines"

    # TOC/heading and image-credit checks are structural only.
    front = read("00_front.md")
    toc_text = front[front.index("## 目录"):]
    toc_entries = []
    for line in toc_text.splitlines():
        m = re.match(r"^(.*?)[　\s]+(\d+)$", line.strip())
        if m and not line.startswith("#"):
            toc_entries.append((m.group(1).strip(), int(m.group(2))))
    heading_set = set(re.findall(r"^## (.+)$", document, re.M))
    assert len(toc_entries) == 20
    assert all(title in heading_set for title, _ in toc_entries)

    credit_keys = [int(x) for x in re.findall(
        r"^- \*\*(\d+)\*\*", read("20_image_credits.md"), re.M)]
    assert len(credit_keys) == 74
    assert credit_keys == sorted(set(credit_keys))

    xi_pages = page_markers(read("12_ch11.md"))
    xi_refs = len(refs(read("12_ch11.md")))
    xi_notes = len(note_numbers(read("notes_12_ch11.md")))
    assert (xi_pages[0], xi_pages[-1], len(xi_pages)) == (245, 260, 16)
    assert xi_refs == xi_notes == 15

    audit = {
        "toc_entries": len(toc_entries),
        "toc_matches_headings": True,
        "image_credit_entries": len(credit_keys),
        "image_credit_keys_sorted_unique": True,
        "body_section_files": len(SECTION_ORDER),
        "note_section_files": len(NOTE_ORDER),
        "chapter_XI_check": {
            "pages": [xi_pages[0], xi_pages[-1]],
            "page_markers": len(xi_pages),
            "refs": xi_refs,
            "notes": xi_notes,
        },
        "output_file": OUT.name,
        "bytes": len(raw),
        "chars": len(document),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "page_markers": len(final_pages),
        "pages_first_last": [final_pages[0], final_pages[-1]],
        "missing_pages": [n for n in range(1, 370) if n not in final_pages],
        "duplicate_pages": sorted({n for n in final_pages if final_pages.count(n) > 1}),
        "ascending_pages": final_pages == sorted(final_pages),
        "notes_total": total_notes,
        "note_groups": len(NOTE_ORDER),
        "notes_per_group": note_counts,
        "headings": headings,
        "section_stats": section_stats,
        "status": {
            "source_coverage": "complete: printed pages 1-369 accounted for",
            "translation": "complete: reviewed canonical text assembled",
            "semantic_review": evidence["status"],
            "layout": "not performed",
            "web_export": "not performed",
            "publication": "not performed",
            "online_verification": "not performed",
        },
    }
    audit["review_evidence"] = "review/book_text_gate.json"
    audit["embedded_illustrations"] = len(figures["entries"])
    audit["figure_manifest_sha256"] = hashlib.sha256(figures_path.read_bytes()).hexdigest()
    audit["review_evidence_sha256"] = hashlib.sha256(evidence_path.read_bytes()).hexdigest()
    with OUT.open("w", encoding="utf-8", newline="\n") as fh:
        fh.write(document)
    with AUDIT.open("w", encoding="utf-8", newline="\n") as fh:
        fh.write(json.dumps(audit, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({k: audit[k] for k in (
        "bytes", "chars", "sha256", "page_markers", "missing_pages",
        "duplicate_pages", "notes_total", "note_groups")}, ensure_ascii=False, indent=2))
    print("wrote", OUT)
    print("wrote", AUDIT)


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main()
