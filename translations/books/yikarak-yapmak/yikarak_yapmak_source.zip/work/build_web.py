"""Export Chinese reading data for the site's structured reader."""
import hashlib, json, re, sys
from pathlib import Path
from markdown_it import MarkdownIt
from build_final import ROOT, SECTION_ORDER, NOTE_PAIRS

sys.stdout.reconfigure(encoding='utf-8')
out = ROOT/'output'
dest = out/'webdata'
dest.mkdir(exist_ok=True)
md = MarkdownIt()
note_pairs = dict(NOTE_PAIRS)
figures = json.loads((out/'figures.json').read_text(encoding='utf-8'))['entries']
figures = {x['source_page']: x for x in figures}
gate = json.loads((ROOT/'work/review/book_text_gate.json').read_text(encoding='utf-8'))
for name, digest in gate['canonical_sha256'].items():
    assert hashlib.sha256((out/'sections'/name).read_bytes()).hexdigest() == digest

def inline(children, prefix, refs=True):
    root = []; stack = [root]
    for t in children or []:
        if t.type == 'text':
            for x in re.split(r'(\[\d+\])', t.content):
                m = re.fullmatch(r'\[(\d+)\]', x)
                stack[-1].append({'type':'note','id':f'{prefix}-{m[1]}'} if m and refs else x)
        elif t.type in ('em_open','strong_open','link_open'):
            node = {'type':t.type.split('_')[0], 'children':[]}
            if t.type == 'link_open': node['url'] = t.attrGet('href')
            stack[-1].append(node); stack.append(node['children'])
        elif t.type in ('em_close','strong_close','link_close'): stack.pop()
        elif t.type in ('softbreak','hardbreak'): stack[-1].append({'type':'break'})
        elif t.type == 'code_inline': stack[-1].append(t.content)
        else: raise ValueError(f'Unsupported inline: {t.type}')
    assert len(stack) == 1
    return root

metadata = {'id':'yikarak-yapmak','title':'破而后立：为一种无政府主义建筑理论作预备',
    'originalTitle':'Yıkarak Yapmak: Anarşist Bir Mimarlık Kuramı İçin Altlık',
    'author':'Uğur Tanyeli','translator':'Xiaoyang Hao (AI-assisted working translation)',
    'language':'zh-CN','languagePair':'Türkçe → 中文',
    'structured':True,'bilingual':False,'views':['zh'],'example':False,
    'description':'建筑理论、现代性与无政府主义。全书中文校订译稿，含原注、插图及原书页码定位。',
    'editionNotice':'据2017年土耳其语底本校订；页码指原书页码。原注随正文显示，新增说明标为校注。',
    'downloads':[
        {'label':'中文PDF','url':'translations/books/yikarak-yapmak/yikarak_yapmak_zh.pdf'},
        {'label':'规范稿与源码包','url':'translations/books/yikarak-yapmak/yikarak_yapmak_source.zip'}],
    'chapters':[]}
total_notes = 0; total_figures = 0
for index, name in enumerate(SECTION_ORDER):
    sid = Path(name).stem
    prefix = f'yy-{sid}'
    text = (out/'sections'/name).read_text(encoding='utf-8')
    # A page marker is a structural boundary even without surrounding blank lines.
    text = re.sub(r'(?m)^(〔原书第\d+页〕)$', r'\n\1\n', text)
    notes = {}
    if name in note_pairs:
        nt = (out/'sections'/note_pairs[name]).read_text(encoding='utf-8')
        for n, content in re.findall(r'^\[(\d+)\]\s*(.*?)(?=^\[\d+\]|\Z)',nt,re.M|re.S):
            notes[f'{prefix}-{n}'] = {'zh':inline(md.parseInline(content.strip())[0].children,prefix,False)}
    body = []; page = ''; quote_depth = 0; list_depth = 0; heading = None
    inserted_editorial_rows = 0
    for token in md.parse(text):
        if token.type == 'blockquote_open': quote_depth += 1
        elif token.type == 'blockquote_close': quote_depth -= 1
        elif token.type in ('bullet_list_open','ordered_list_open'): list_depth += 1
        elif token.type in ('bullet_list_close','ordered_list_close'): list_depth -= 1
        elif token.type == 'heading_open': heading = token.tag
        elif token.type == 'heading_close': heading = None
        elif token.type == 'inline':
            marker = re.fullmatch(r'〔原书第(\d+)页〕',token.content)
            if marker:
                page = marker[1]
                if int(page) in figures:
                    fig = figures[int(page)]
                    body.append({'id':f'{prefix}-figure-{page}','type':'figure','page':page,
                                 'src':f'translations/books/yikarak-yapmak/{fig["file"]}', 'zh':[fig['alt']]})
                    total_figures += 1
                continue
            kind = 'heading' if heading in ('h1','h2') else 'subheading' if heading else 'quote' if quote_depth else 'paragraph'
            tokens = inline(token.children,prefix)
            if list_depth: tokens.insert(0,'• ')
            if sid == '00_front' and token.content.startswith('**译名与术语说明（非原书文字）**'):
                row_id = f'{prefix}-terms-note-20261020'
                inserted_editorial_rows += 1
            else:
                row_id = f'{prefix}-{len(body)+1-inserted_editorial_rows:04d}'
            body.append({'id':row_id,'type':kind,'page':page,'zh':tokens})
        elif token.type not in ('paragraph_open','paragraph_close','list_item_open','list_item_close'):
            raise ValueError(f'Unsupported block: {token.type}')
    title = next((t.content for t in md.parse(text) if t.type=='inline'),'')
    data = {'id':sid,'title':title,'body':body,'notes':notes,'sourceLanguage':'tr','sourceLanguageLabel':'Türkçe'}
    from paragraph_continuations import annotate_web
    annotate_web(data)
    (dest/f'{sid}.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    metadata['chapters'].append({'id':sid,'title':title,'dataUrl':f'translations/books/yikarak-yapmak/{sid}.json'})
    total_notes += len(notes)
assert total_notes == 311 and total_figures == 74
(dest/'book-metadata.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(f'Exported {len(SECTION_ORDER)} sections, {total_notes} notes, {total_figures} figures.')
if (out/'source_pages.json').exists():
    from build_source_editions import enrich_web
    enrich_web(json.loads((out/'source_pages.json').read_text(encoding='utf-8')))
