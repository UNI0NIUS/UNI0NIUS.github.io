"""Build the print edition from reviewed sections and the figure manifest."""
from pathlib import Path
import json, re, subprocess, sys
from build_final import ROOT, SECTION_ORDER, NOTE_PAIRS

sys.stdout.reconfigure(encoding='utf-8')
out = ROOT / 'output'
evidence = json.loads((ROOT/'work/review/book_text_gate.json').read_text(encoding='utf-8'))
import hashlib
for name, digest in evidence['canonical_sha256'].items():
    assert hashlib.sha256((out/'sections'/name).read_bytes()).hexdigest() == digest
figures = json.loads((out/'figures.json').read_text(encoding='utf-8'))
notes = dict(NOTE_PAIRS)
parts = []
definitions = []
for index, name in enumerate(SECTION_ORDER):
    body = (out/'sections'/name).read_text(encoding='utf-8').strip()
    if name in notes:
        nt = (out/'sections'/notes[name]).read_text(encoding='utf-8')
        entries = re.findall(r'^\[(\d+)\]\s*(.*?)(?=^\[\d+\]|\Z)', nt, re.M|re.S)
        for number, content in entries:
            key = f'c{index}-{number}'
            content = content.strip().replace('\n', '\n    ')
            definitions.append(f'[^{key}]: {content}')
        body = re.sub(r'\[(\d+)\]', lambda m: f'[^c{index}-{m[1]}]', body)
    for fig in figures['entries']:
        marker = f'〔原书第{fig["source_page"]}页〕'
        if marker in body:
            assert hashlib.sha256((out/fig['file']).read_bytes()).hexdigest() == fig['sha256']
            body = body.replace(marker, marker + f'\n\n![]({fig["file"]}){{width=85%}}')
    body = '\\clearpage\n\\setcounter{footnote}{0}\n\n' + body
    parts.append(body)
assert len(definitions) == 311
header = '''---
title: "破坏中建造"
subtitle: "一种无政府主义建筑理论的底衬"
author: "乌古尔·坦耶利（Uğur Tanyeli）"
lang: zh-CN
documentclass: article
classoption: [a4paper,11pt,titlepage]
mainfont: Times New Roman
CJKmainfont: SimSun
CJKsansfont: Microsoft YaHei
CJKmonofont: SimSun
CJKoptions: [AutoFakeBold=true, AutoFakeSlant=true]
geometry: [margin=25mm]
colorlinks: true
linkcolor: black
urlcolor: blue
toc: true
toc-depth: 2
header-includes:
  - \\usepackage{xeCJK}
  - \\usepackage{fvextra}
  - \\usepackage{xurl}
  - \\setlength{\\emergencystretch}{3em}
  - \\widowpenalty=10000
  - \\clubpenalty=10000
  - \\renewcommand{\\contentsname}{目录}
---

'''
(out/'print.md').write_text(header+'\n\n'.join(parts)+'\n\n'+'\n\n'.join(definitions)+'\n', encoding='utf-8')
subprocess.run(['pandoc','print.md','--standalone','--from=markdown+footnotes+implicit_figures+autolink_bare_uris','--to=latex','--output=yikarak_yapmak_zh.tex'],cwd=out,check=True)
print('Print Markdown and LaTeX generated; 311 linked footnotes.')
