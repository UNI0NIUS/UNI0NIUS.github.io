"""Reviewed logical paragraphs, independent of the source's physical pages."""
from pathlib import Path
import copy, json, re

ROOT=Path(__file__).resolve().parent.parent
MAP=ROOT/'output/paragraph_continuations.json'
def spec():return json.loads(MAP.read_text(encoding='utf-8')) if MAP.exists() else {'links':[],'bindings':{}}

def apply_markdown(text,chapter):
    data=spec();edges={x['from']:x for x in data['links'] if x['chapter']==chapter}
    consumed={x['to'] for x in edges.values()}
    replacements=[]; pages=[]
    for start in edges:
        if start in consumed:continue
        ids=[start];cur=start;content=data['bindings'][start]['md']
        while cur in edges:
            edge=edges[cur];nxt=edge['to'];ids.append(nxt);pages.append(edge['page'])
            if edge['trim_end']:
                assert content.endswith(edge['trim_end']),(cur,content[-40:])
                content=content[:-len(edge['trim_end'])]
            tail=data['bindings'][nxt]['md']
            if edge['trim_start']:
                assert tail.startswith(edge['trim_start']);tail=tail[len(edge['trim_start']):]
            content+=edge['joiner']+f"〔原书第{edge['page']}页〕"+tail
            cur=nxt
        if data['bindings'][start]['kind']=='quote':content='> '+content.replace('\n','\n> ')
        for i,rid in enumerate(ids):
            block=data['bindings'][rid]['block']
            assert text.count(block)==1,(rid,text.count(block))
            a=text.index(block);replacements.append((a,a+len(block),content if i==0 else ''))
    for a,b,value in sorted(replacements,reverse=True):text=text[:a]+value+text[b:]
    for page in pages:text=re.sub(rf'(?m)^〔原书第{page}页〕\s*\n','',text)
    return re.sub(r'\n{3,}','\n\n',text)

def annotate_web(data):
    rules=spec();data['paragraphLinks']=[x for x in rules['links'] if x['chapter']==data['id']]
    data['captionIds']=[x for x in rules.get('caption_ids',[]) if x.startswith(f"yy-{data['id']}-")]
    return data

def trim_tokens(tokens,edge):
    tokens=copy.deepcopy(tokens)
    if edge.get('trim_end'):
        assert isinstance(tokens[-1],str) and tokens[-1].endswith(edge['trim_end'])
        tokens[-1]=tokens[-1][:-len(edge['trim_end'])]
    return tokens

def adjusted_row(row,data):
    row=copy.deepcopy(row)
    for edge in data.get('paragraphLinks',[]):
        if row['id']==edge['from']:
            row['zh']=trim_tokens(row['zh'],edge)
            if edge['joiner']:row['zh'].append(edge['joiner'])
        if row['id']==edge['to'] and edge['trim_start']:
            assert row['zh'][0].startswith(edge['trim_start'])
            row['zh'][0]=row['zh'][0][len(edge['trim_start']):]
    return row
