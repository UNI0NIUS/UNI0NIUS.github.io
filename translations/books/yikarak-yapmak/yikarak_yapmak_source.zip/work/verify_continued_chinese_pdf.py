"""Read back body and note streams after the pagination/paragraph repair."""
from pathlib import Path
import datetime,hashlib,json,re,sys,unicodedata
import pymupdf as fitz

sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parent.parent;OUT=ROOT/'output';REVIEW=ROOT/'work/review'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def norm(s):
    s=re.sub(r'〔原书第\d+页〕','',s)
    return re.sub(r'[\s\u00ad\u200b-]+','',unicodedata.normalize('NFKC',s)).translate(str.maketrans({'‘':"'",'’':"'",'“':'"','”':'"'}))
def strings(tokens):
    for t in tokens:
        if isinstance(t,str):yield t
        elif t['type']!='note':yield from strings(t.get('children',[]))
pdf=OUT/'yikarak_yapmak_zh.pdf';doc=fitz.open(pdf)
body=[];notes=[];outside=[]
for i,page in enumerate(doc,1):
    for b in page.get_text('dict')['blocks']:
        for l in b.get('lines',[]):
            for s in l['spans']:
                text=s['text']
                if text.strip() and (s['bbox'][0]<0 or s['bbox'][1]<0 or s['bbox'][2]>page.rect.width+.2 or s['bbox'][3]>page.rect.height+.2):outside.append(i)
                if s['bbox'][1]>775 and text.strip().isdigit():continue
                if s['size']>=10:body.append(text)
                elif s['size']>=8:notes.append(text)
streams=[norm(''.join(body)),norm(''.join(notes))]
failures=[];count=0
from paragraph_continuations import adjusted_row
for c in read(OUT/'webdata/book-metadata.json')['chapters']:
    data=read(OUT/'webdata'/f"{c['id']}.json")
    entries=[]
    for row in data['body']:
        if row['type']=='figure':continue # generic web alt labels are not print captions
        row=adjusted_row(row,data)
        entries.extend((row['id'],x) for x in strings(row['zh']))
    for nid,note in data['notes'].items():entries.extend((nid,x) for x in strings(note['zh']))
    for rid,text in entries:
        text=norm(text)
        for i in range(0,len(text),70):
            chunk=text[i:i+70]
            if len(chunk)<8:continue
            count+=1
            if not any(chunk in stream for stream in streams):failures.append({'id':rid,'text':chunk})
report={'checked_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':not failures and not outside,
    'pages':len(doc),'checked_text_chunks':count,'failures':failures,'outside_page_text':outside,
    'pdf_sha256':hashlib.sha256(pdf.read_bytes()).hexdigest(),
    'paragraph_map_sha256':hashlib.sha256((OUT/'paragraph_continuations.json').read_bytes()).hexdigest(),
    'illustration_check':'74 images retained by unchanged build_print figure manifest; generic web image alt labels excluded from print text checks. Actual translated captions are ordinary body entries and remain checked.',
    'normalization':'Separate body >=10pt and notes 8–10pt; remove page markers, whitespace/hyphens; NFKC and quote normalization. 70-character chunks from all original body/notes with reviewed boundary dash adjustments.'}
(REVIEW/'continued_chinese_pdf_gate.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='failures'},ensure_ascii=False));print('failures',len(failures),str(failures[:4]));assert report['passed']
