"""Package and stage the source supplement without rebuilding Chinese assets."""
from pathlib import Path
import datetime, hashlib, json, re, shutil, sys, zipfile

sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parent.parent;OUT=ROOT/'output';REVIEW=ROOT/'work/review'
SITE=ROOT.parent/'homepage-union';DEST=SITE/'translations/books/yikarak-yapmak'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

assert read(REVIEW/'turkish_pdf_text_gate.json')['passed']
metadata=read(OUT/'webdata/book-metadata.json')
archive_entry=next(x for x in metadata['downloads'] if '.zip' in x['url'])
archive_entry['url']=archive_entry['url'].split('?')[0]
archive_entry.pop('bytes',None);archive_entry.pop('sha256',None)
for c in metadata['chapters']:
    p=OUT/'webdata'/f"{c['id']}.json"
    c['dataUrl']=c['dataUrl'].split('?')[0]+'?v='+sha(p)[:12]
for file in metadata['downloads']:
    if file['url'].endswith('.zip'):continue
    p=OUT/Path(file['url']).name
    file.update({'bytes':p.stat().st_size,'sha256':sha(p)})
    file['url']=file['url'].split('?')[0]+'?v='+sha(p)[:12]
save(OUT/'webdata/book-metadata.json',metadata)

package=OUT/'yikarak_yapmak_source.zip'
with zipfile.ZipFile(package) as z:names=z.namelist()
names=list(dict.fromkeys(names+[
    'work/build_source_editions.py','work/package_source_editions.py','work/verify_source_editions.py',
    'work/paragraph_continuations.py','output/paragraph_continuations.json',
    'work/review/paragraph_boundary_review.json',
    'work/verify_continued_chinese_pdf.py','work/review/continued_chinese_pdf_gate.json',
    'work/review/turkish_browser_gate.json','work/review/turkish_visual_gate.json',
    'work/clean_source.json','output/source_pages.json',
    'work/review/turkish_pdf_text_gate.json','work/review/turkish_web_data_gate.json',
    'work/review/turkish_pdf_page_map.json',
    'Yıkarak Yapmak Anarşist Bir Mimarlık Kuramı İçin Altlık Uğur Tanyeli.pdf']))
temp=OUT/'yikarak_yapmak_source.new.zip'
with zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED) as z:
    for name in names:
        p=ROOT/name;assert p.is_file(),p
        z.write(p,name)
with zipfile.ZipFile(temp) as z:
    assert z.testzip() is None
    for name in names:assert hashlib.sha256(z.read(name)).hexdigest()==sha(ROOT/name)
temp.replace(package)
# Keep the archive free of a circular self-hash: its embedded metadata has
# the stable archive URL, while public metadata adds the finalized hash.
file=next(x for x in metadata['downloads'] if '.zip' in x['url'])
file.update({'bytes':package.stat().st_size,'sha256':sha(package)})
file['url']=file['url'].split('?')[0]+'?v='+sha(package)[:12]
save(OUT/'webdata/book-metadata.json',metadata)
downloads={Path(x['url'].split('?')[0]).name:{k:x[k] for k in ['bytes','sha256']} for x in metadata['downloads']}
save(OUT/'downloads.json',downloads)
DEST.mkdir(exist_ok=True)
for p in (OUT/'webdata').glob('*.json'):shutil.copy2(p,DEST/p.name)
for name in downloads:shutil.copy2(OUT/name,DEST/name)
for p in read(OUT/'source_pages.json')['pages']:
    target=DEST/p['file'];target.parent.mkdir(exist_ok=True)
    shutil.copy2(OUT/p['file'],target)

data_path=SITE/'translations-data.js'
old=data_path.read_text(encoding='utf-8');prefix='window.TRANSLATIONS = '
data=json.loads(old[len(prefix):].strip().rstrip(';'))
for i,b in enumerate(data['books']):
    if b['id']=='yikarak-yapmak':data['books'][i]=metadata;break
else:raise ValueError('Existing book entry not found')
data_path.write_text(prefix+json.dumps(data,ensure_ascii=False,indent=2)+';\n',encoding='utf-8')
for relative in ['translations/book.html','translations/index.html']:
    path=SITE/relative;text=path.read_text(encoding='utf-8')
    for name in ['translations-data.js','bilingual-reader.js','translations.css']:
        digest=sha(SITE/name)[:12]
        text=re.sub(re.escape(name)+r'\?v=[a-z0-9]+',name+'?v='+digest,text)
    path.write_text(text,encoding='utf-8')
save(REVIEW/'turkish_package_gate.json',{'passed':True,'members':len(names),'bytes':package.stat().st_size,
    'sha256':sha(package),'downloads':downloads,
    'embedded_metadata':'Stable source ZIP URL without circular archive hash; public metadata adds the finalized archive digest.',
    'source_pages':'Original PDF and image-generation recipe included; derived WebP page images are regenerated, not duplicated in the ZIP.'})
print(json.dumps({'members':len(names),'downloads':downloads},ensure_ascii=False))
