#!/usr/bin/env python3
"""Book-specific TeX editions from the reviewed, hash-bound projection.

--prototype is deliberately incomplete and must never be published.
"""
import argparse
import hashlib
import json
import re
import subprocess
from collections import defaultdict
from pathlib import Path

R = Path(__file__).resolve().parents[1]
OUT = R / 'editions'
PROJECTION = R / 'reading_projection.json'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def esc(text):
    return ''.join({'\\': r'\textbackslash{}', '&': r'\&', '%': r'\%', '$': r'\$', '#': r'\#',
                    '_': r'\_', '{': r'\{', '}': r'\}', '~': r'\textasciitilde{}',
                    '^': r'\textasciicircum{}'}.get(c, c) for c in text)


PREAMBLE = r'''\documentclass[SIZE,a4paper,twoside]{article}
\usepackage{fontspec,xeCJK}
\setmainfont{Times New Roman}
\setCJKmainfont[AutoFakeBold=2,AutoFakeSlant=.2]{SimSun}
\usepackage[GEOMETRY,marginparwidth=16mm,marginparsep=3mm]{geometry}
\usepackage{xcolor,paracol,fancyhdr,hyperref,needspace,xurl,amsmath}
\hypersetup{unicode=true,hidelinks,pdftitle={System der Philosophie I / 哲学体系第一部},pdfauthor={Hermann Cohen}}
\setlength{\parindent}{1em}\setlength{\parskip}{5pt}\setlength{\columnsep}{8mm}\setlength{\emergencystretch}{3em}
\tolerance=2000\widowpenalty=10000\clubpenalty=10000
\pagestyle{fancy}\fancyhf{}\fancyhead[LE,RO]{\small Logik der reinen Erkenntniss}
\fancyhead[LO,RE]{\small Hermann Cohen}\fancyfoot[C]{\thepage}\setlength{\headheight}{14pt}
\DeclareRobustCommand{\sourcepage}[1]{\marginpar{\raggedleft\fontsize{8}{10}\selectfont\color{black!65}S.\ #1}}
\twosided[pm]\marginparthreshold{0}
\setcounter{tocdepth}{2}\setcounter{secnumdepth}{-1}
\renewcommand{\contentsname}{本版目录 / Inhalt dieser Ausgabe}
\begin{document}
'''


class Renderer:
    def __init__(self, projection, mode, prototype):
        self.d = projection
        self.mode = mode
        self.bi = mode == 'bilingual'
        self.prototype = prototype
        self.units = {x['id']: x for x in projection['units']}
        self.entries = {x['id']: x for x in projection['toc']['entries']}
        self.first_pages = {str(refs[0].get('display_printed_page') or refs[0].get('printed_page'))
                            for u in projection['units'] if (refs := u['mapped_source_refs'])
                            and (refs[0].get('display_printed_page') or refs[0].get('printed_page')) is not None}
        self.out = []
        self.opened = False
        self.last_page = None
        self.notes = defaultdict(list)
        self.note_refs = defaultdict(set)
        self.emitted_units = set()

    def close(self):
        if self.opened:
            self.out.append(r'\end{paracol}')
            self.opened = False

    def pair(self, zh, de, small=False):
        if self.bi:
            if not self.opened:
                self.out.append(r'\begin{paracol}{2}')
                self.opened = True
            if small:
                zh, de = r'{\small ' + zh + '}', r'{\small ' + de + '}'
            self.out.extend([zh + r'\par', r'\switchcolumn', de + r'\par', r'\switchcolumn*'])
        else:
            text = zh if self.mode == 'zh' else de
            self.out.append((r'{\small ' + text + '}' if small else text) + r'\par')

    def page_command(self, label):
        if label is None or str(label) == self.last_page:
            return ''
        self.last_page = str(label)
        return r'\sourcepage{' + esc(str(label)) + '}'

    def component(self, unit, lang):
        text = unit['translation'] if lang == 'zh' else unit['source_text']
        if text is None:
            return ''
        anchors = defaultdict(list)
        consumed = {}
        if lang == 'de' and self.mode == 'de':
            for ref in unit['mapped_source_refs']:
                label = ref.get('display_printed_page', ref.get('printed_page'))
                offset = ref['unit_start']
                if label is not None and 0 < offset < len(text) and text[offset-1].isalpha() and text[offset].isalpha():
                    while offset < len(text) and text[offset].isalpha():
                        offset += 1
                if label is not None:
                    anchors[offset].append(('page', label))
        if lang == 'zh' and (self.mode == 'zh' or self.bi):
            refs = unit['mapped_source_refs']
            if refs:
                label = refs[0].get('display_printed_page', refs[0].get('printed_page'))
                if label is not None:
                    anchors[0].append(('page', label))
                # Pages lying entirely within one long original paragraph have
                # no next Chinese paragraph at which to place a marker. Put
                # those labels at the paragraph end, an explicitly approximate
                # position, rather than inventing a translated sentence offset.
                for ref in refs[1:]:
                    label = ref.get('display_printed_page', ref.get('printed_page'))
                    if label is not None and str(label) not in self.first_pages and ('page', label) not in anchors[len(text)]:
                        anchors[len(text)].append(('page', label))
        for note in unit.get('original_notes', []):
            after = note['anchor_translation_after' if lang == 'zh' else 'anchor_source_after']
            offset = text.index(after) + len(after)
            anchors[offset].append(('note', note['id']))
            if lang == 'de':
                marker = note['source_marker']
                if text[offset:offset+len(marker)] != marker:
                    raise ValueError(f"{unit['id']}: source marker does not follow anchor")
                consumed[offset] = len(marker)
        emphasis = unit['source_emphasis'] if lang == 'de' else []
        positions = set(anchors) | {0, len(text)}
        positions.update(x for span in emphasis for x in (span['start'], span['end']))
        positions.update(k + n for k, n in consumed.items())
        positions = sorted(positions)
        result = [r'\hypertarget{' + lang + '-' + unit['id'] + '}{}']
        for i, pos in enumerate(positions[:-1]):
            for kind, val in anchors.get(pos, []):
                if kind == 'page':
                    result.append(self.page_command(val))
                else:
                    self.note_refs[lang].add(val)
                    result.append(r'\hypertarget{ref-' + lang + '-' + val + r'}{}\hyperlink{note-' + val + r'}{\textsuperscript{1}}')
            next_pos = positions[i+1]
            if any(start <= pos < start+n for start, n in consumed.items()):
                continue
            part = esc(text[pos:next_pos])
            if any(s['start'] <= pos and next_pos <= s['end'] for s in emphasis):
                part = r'\emph{' + part + '}'
            result.append(part)
        for kind, val in anchors.get(len(text), []):
            if kind == 'page':
                result.append(self.page_command(val))
            else:
                self.note_refs[lang].add(val)
                result.append(r'\hypertarget{ref-' + lang + '-' + val + r'}{}\hyperlink{note-' + val + r'}{\textsuperscript{1}}')
        return ''.join(result)

    def heading(self, unit):
        self.close()
        level = unit.get('heading_level') or 2
        if level == 1:
            self.out.append(r'\clearpage')
        self.out.append(r'\needspace{7\baselineskip}')
        # Use a plain, stable bookmark title; source markers and hyperlinks
        # are included only in the visible title, never in PDF metadata.
        title = unit['source_text'] if self.mode == 'de' else unit['translation']
        zh = self.component(unit, 'zh') if self.mode != 'de' else ''
        de = self.component(unit, 'de') if self.mode != 'zh' else ''
        shown = zh + r'\\{\normalsize ' + de + '}' if self.bi else (zh if self.mode == 'zh' else de)
        self.out.append(('\\section' if level == 1 else '\\subsection') + '[' + esc(title) + ']{' + shown + '}')
        self.emitted_units.add(unit['id'])

    def editorial(self, unit):
        for note in unit.get('editorial_notes', []):
            zh = note.get('text_zh') or note.get('zh')
            de = note.get('text_de') or note.get('de')
            if not zh or not de:
                raise ValueError(f"{unit['id']}: missing bilingual editorial explanation")
            self.pair(esc('〔编者按〕' + zh), esc('[Redaktionelle Erläuterung] ' + de), small=True)

    def endnotes(self, section):
        notes = self.notes.get(section, [])
        if not notes:
            return
        self.close()
        self.out.append(r'\needspace{6\baselineskip}\subsection*{原注 / Anmerkungen}')
        for note in notes:
            nid = note['id']
            tag = r'\hypertarget{note-' + nid + r'}{}'
            label = r'{\small [S. 86]} \textsuperscript{1} '
            zh = tag + label + esc(note['zh']) + r'\par{\small 原文：' + esc(note['de']) + r'}~\hyperlink{ref-zh-' + nid + r'}{\textsuperscript{↑}}'
            de = (tag if self.mode == 'de' else '') + label + esc(note['de']) + r'~\hyperlink{ref-de-' + nid + r'}{\textsuperscript{↑}}'
            self.pair(zh, de, small=True)
        self.close()

    def titlepage(self):
        texts = [self.units[f'part001-u{i:03}'] for i in range(1, 8)]
        self.emitted_units.update(x['id'] for x in texts)
        self.out.append(r'\begin{titlepage}\centering\vspace*{25mm}')
        for i, unit in enumerate(texts):
            zh, de = esc(unit['translation']), esc(unit['source_text'])
            content = zh if zh == de else zh + r'\\' + de
            self.out.append(('{\\Huge ' if i == 0 else '{\\Large ' if i < 3 else '{') + content + r'\par}\bigskip')
        self.out.append(r'\vfill ' + esc('排版试版 / Satzprobe' if self.prototype else {'zh':'中文校订版','de':'Deutsche Leseausgabe','bilingual':'中德逐段对照版'}[self.mode]) + r'\par\end{titlepage}')
        self.pair(esc('页边“S.”为原书印刷页码，页底为本版页码；对照版页标沿中文栏定位。原注置于所属节末，中文原注附德文原文。'), esc('Die Randverweise „S.“ bezeichnen die Seiten des Originals; die Fußzeile zählt die Seiten dieser Ausgabe. Die Originalanmerkung steht am Abschnittsende.'))
        self.close()
        # The original-sized generated TOC left its final one to three
        # entries alone on a nearly empty page. Keep its established design
        # while using compact local leading for the contents only.
        self.out.append(r'\bigskip{\small\setlength{\parskip}{0pt}\tableofcontents}\clearpage')

    def original_toc(self):
        self.close()
        self.out.append(r'\clearpage\begingroup\setlength{\parskip}{2pt}\section{原书目录 / Inhalt des Originals}')
        anomaly_zh = '原目录将序言标为第 I 页；所存底本的序言首页未印页码，后续页为 VI–IX。'
        anomaly_de = 'Das Originalverzeichnis nennt für die Vorrede Seite I; die erste Vorredenseite trägt keine sichtbare Zahl, die folgenden Seiten VI–IX.'
        self.pair(esc('〔编者按〕' + anomaly_zh), esc('[Redaktionelle Erläuterung] ' + anomaly_de), small=True)
        entries = self.d['toc']['entries']
        # Canonical storage groups all root entries before body children;
        # the printed original interleaves each parent and its children.
        ordered = []
        for root in (e for e in entries if e['parent'] is None):
            ordered.append(root)
            ordered.extend(e for e in entries if e['parent'] == root['id'])
        if len(ordered) != len(entries):
            raise ValueError('Original TOC contains an unhandled nested entry')
        for e in ordered:
            prefix = '' if e['parent'] is None else '　'
            number = (str(e['original_toc_number']) + '. ') if e.get('original_toc_number') else ''
            # Root headings have inferred target pages in canonical metadata,
            # but the printed TOC gives a number only for the preface and
            # leaf entries; do not present inferred values as printed.
            page = str(e.get('target_printed_page') or '') if e['parent'] or e['id'] == 'preface' else ''
            zh = prefix + number + e['title_zh'] + '　' + page
            de = prefix + number + e['title_de'] + '  ' + page
            self.pair(esc(zh), esc(de), small=True)
            detail = e.get('detailed_topics')
            if detail:
                self.pair(esc('　　' + detail['zh']), esc('  ' + detail['de']), small=True)
        self.close()
        self.out.append(r'\endgroup')

    def render(self):
        geo = 'a4paper,inner=20mm,outer=23mm,top=21mm,bottom=23mm' if self.bi or self.mode == 'de' else 'a4paper,margin=25mm'
        self.out = [PREAMBLE.replace('SIZE', '10pt' if self.bi or self.mode == 'de' else '11pt').replace('GEOMETRY', geo)]
        self.titlepage()
        sample = {'part001-u009','part001-u010','part001-u018','part001-u019',
                  'part002-u001','part002-u002','part002-u003',
                  'part013-u001','part013-u002','part014-u001','part014-u025',
                  'part018-u060','part020-u001','part020-u002','part020-u070',
                  'part023-u026','part024-u001','part024-u002','part024-u084',
                  'part025-u001','part025-u010','part025-u011','part028-u001','part028-u002','part028-u043'}
        groups = [g for g in self.d['groups'] if not self.prototype or any(i in sample for i in g['unit_ids'])]
        scope = None
        toc_inserted = False
        for group in groups:
            selected = [self.units[i] for i in group['unit_ids']]
            if all(u['id'].startswith('part001-u00') and int(u['id'][-3:]) <= 8 for u in selected):
                continue
            first = selected[0]
            if first['source_text'] is None:
                continue
            if first['section_id'] == 'introduction' and not toc_inserted:
                if scope:
                    self.endnotes(scope)
                self.original_toc()
                toc_inserted = True
            if scope is not None and scope != first['section_id']:
                self.endnotes(scope)
            scope = first['section_id']
            if first['kind'] == 'heading':
                self.heading(first)
            else:
                for u in selected:
                    self.notes[scope].extend(u.get('original_notes', []))
                    self.emitted_units.add(u['id'])
                zh = ''.join(self.component(u, 'zh') for u in selected) if self.mode != 'de' else ''
                de = ' '.join(self.component(u, 'de') for u in selected) if self.mode != 'zh' else ''
                self.pair(zh, de)
                for u in selected:
                    self.editorial(u)
        if scope:
            self.endnotes(scope)
        self.close()
        self.out.append(r'\end{document}')
        all_notes = {n['id'] for ns in self.notes.values() for n in ns}
        for lang in (['zh', 'de'] if self.bi else [self.mode]):
            if self.note_refs[lang] != all_notes:
                raise ValueError(f'{lang}: original note and anchor sets differ')
        return '\n'.join(self.out)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--prototype', action='store_true')
    parser.add_argument('--compile', action='store_true')
    parser.add_argument('--reuse-unchanged', action='store_true', help='Reuse a previously verified PDF only when its TeX and PDF bytes are unchanged')
    args = parser.parse_args()
    data = json.loads(PROJECTION.read_text(encoding='utf-8'))
    for name in ('source_units.jsonl', 'translation_units.jsonl', 'original_toc.json'):
        if sha(R / name) != data['inputs_sha256'][name]:
            raise ValueError(f'Projection is stale: {name}')
    OUT.mkdir(exist_ok=True)
    results = {}
    previous_path = R / 'checks' / ('prototype_build.json' if args.prototype else 'edition_build.json')
    previous = json.loads(previous_path.read_text(encoding='utf-8')) if previous_path.exists() else {}
    for mode in (['bilingual'] if args.prototype else ['zh', 'de', 'bilingual']):
        renderer = Renderer(data, mode, args.prototype)
        tex = renderer.render()
        stem = 'cohen_system_1_' + ('prototype' if args.prototype else mode)
        path = OUT / (stem + '.tex')
        pdf = OUT / (stem + '.pdf')
        old = previous.get('editions', {}).get(mode, {})
        reusable = (args.reuse_unchanged and path.exists() and pdf.exists()
                    and sha(path) == old.get('tex_sha256') and sha(pdf) == old.get('pdf_sha256')
                    and path.read_text(encoding='utf-8') == tex)
        path.write_text(tex, encoding='utf-8')
        item = {'tex': str(path), 'tex_sha256': sha(path), 'emitted_units': len(renderer.emitted_units)}
        if args.compile:
            if not reusable:
                for i in (1, 2):
                    proc = subprocess.run(['xelatex', '-interaction=nonstopmode', '-halt-on-error', path.name], cwd=OUT,
                                          stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
                    (R / 'checks' / f'compile_{stem}_{i}.log').write_bytes(proc.stdout)
                    if proc.returncode:
                        print(proc.stdout.decode('utf-8', errors='replace')[-5000:])
                        raise SystemExit(proc.returncode)
            item['pdf_sha256'] = sha(pdf)
            item['pdf_action'] = 'reused_unchanged_tex_and_pdf' if reusable else 'compiled_twice'
        results[mode] = item
        print(stem, item.get('pdf_action', 'generated'), flush=True)
    report = {'status':'prototype_pending_visual_qa' if args.prototype else 'generated_pending_visual_qa',
              'prototype':args.prototype, 'projection_sha256':sha(PROJECTION), 'builder_sha256':sha(Path(__file__)), 'editions':results}
    (R / 'checks' / ('prototype_build.json' if args.prototype else 'edition_build.json')).write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')


if __name__ == '__main__':
    main()
