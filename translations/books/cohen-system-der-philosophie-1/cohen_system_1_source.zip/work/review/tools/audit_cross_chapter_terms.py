"""Record bounded cross-chapter terminology screening and reviewed exceptions."""
import hashlib,json,re
from pathlib import Path
R=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
units=[json.loads(x) for x in (R/'translation_units.jsonl').read_text(encoding='utf8').splitlines()]
tests=[
 ('Vereinigung',r'\bVereinigung(?:en|s)?\b',['结合','统一','联合','集合','合一']),
 ('Verbindung',r'\bVerbindung(?:en|s)?\b',['联结','结合','联系','连接','关联','联合','组合','相连','联络']),
 ('Zusammenhalt',r'\bZusammenhalt(?:es|s)?\b',['维系','保持','联系','凝聚','维持','联结']),
 ('Zusammenhang',r'\bZusammenhang(?:e|s|es|en)?\b',['联系','关联','关系','连贯','相关','连接','联结','关涉','相连','结合']),
 ('Einigung',r'\bEinigung(?:en|s)?\b',['统一','合一','结合','联合','团结','达成一致']),
 ('Erhaltung',r'\bErhaltung(?:s|en)?\b',['保持','保存','守恒','维护','保全','维持']),
 ('Beharrung',r'\bBeharrung(?:s|en)?\b',['持存','持续','存续','不变','保持']),
 ('Beharrlichkeit',r'\bBeharrlichkeit(?:s)?\b',['持存','持续','不变','恒常']),
 ('Trägheit',r'\bTrägheit(?:s|en)?\b',['惯性','惰性']),
 ('Verwandlung',r'\bVerwandlung(?:en|s)?\b',['转化','变换','变化','转换','变形','转变']),
 ('Wandel',r'\bWandel(?:s)?\b',['转变','变化','变迁','变换']),
 ('Wechsel',r'\bWechsel(?:s|n)?\b',['交替','变换','变化','转变','更替','更换','交换','变动']),
 ('Gliederung',r'\bGliederung(?:en|s)?\b',['分节','结构','组织','构造','环节','划分','分化']),
 ('Eintheilung',r'\bEintheilung(?:en|s)?\b',['划分','分类','分割','分节','区分','分配']),
 ('Empfindung',r'\bEmpfindung(?:en|s)?\b',['感觉','感受','感性','知觉']),
 ('Gefühl',r'\bGefühl(?:e|es|s|en)?\b',['情感','感情','感觉','感受','情绪','感触','体会','情操','人性之情']),
 ('Bewusstheit',r'\bBewusstheit\b',['意识性','意识']),
 ('Unbewusstheit',r'\bUnbewusstheit\b',['无意识性']),
 ('Unbewusstsein',r'\bUnbewusstsein\b',['无意识']),
 ('Spiritismus',r'\bSpiritismus\b',['通灵']),
 ('Spiritualismus',r'\bSpiritualismus\b',['唯灵']),
 ('Potentialität',r'\bPotentialität\b',['潜在','可能','潜能']),
 ('Potenz',r'\bPotenz(?:en)?\b',['力量','能力','幂','势','潜能','权力']),
 ('Spannung',r'\b(?:An)?Spannung(?:en|s)?\b',['张力','紧张','拉力','强度']),
 ('Fluxion',r'\bFluxion(?:en)?\b',['流数']),
 ('Fluente',r'\bFluent(?:e|en|enrechnung)\b',['流变量','流数']),
 ('Werthigkeit',r'\bWerthigkeit\b',['化合价','价值']),
 ('Dasein',r'\bDasein(?:s)?\b',['定在','此在','存在','生存','实存','存在者']),
 ('Existenz',r'\bExistenz(?:en)?\b',['实存','存在','生存','存有','实在']),
 ('Wirklichkeit',r'\bWirklichkeit(?:en|s)?\b',['现实','实在','实际','实现']),
 ('Realität',r'\bRealität(?:en|s)?\b',['实在','现实','实际','真实']),
 ('Allheit',r'\bAllheit(?:s)?\b',['总体性','总体','全体']),
 ('Mehrheit',r'\bMehrheit(?:en|s)?\b',['多数性','多数','多样性','多项']),
 ('Gewissheit',r'\bGewissheit(?:s)?\b',['确定','确实','确信','可靠','确切']),
]
exceptions={'Zusammenhang':{'part015-u032':'上下文中“在关于认识确定性的研究中”保留了论述关联，不强插术语。'}}
summary=[]
for name,pat,targets in tests:
 hits=[u for u in units if re.search(pat,u.get('source_text') or '',re.I)]
 candidates=[u['id'] for u in hits if not any(t in (u.get('translation') or '') for t in targets)]
 unexpected=set(candidates)-set(exceptions.get(name,{}))
 if unexpected:raise ValueError(f'{name}: unreviewed candidates {sorted(unexpected)}')
 summary.append({'term':name,'unit_hits':len(hits),'screened_exceptions':candidates})
report={'status':'bounded_cross_chapter_review_passed','translation_sha256':sha(R/'translation_units.jsonl'),
        'source_sha256':sha(R/'source_units.jsonl'),'glossary_sha256':sha(R/'glossary_decisions.json'),
        'terms':summary,'exceptions':exceptions,'contextual_pair_review':['part014-u016','part015-u013','part023-u018','part025-u068',
        'part020-u080','part020-u081','part021-u002','part002-u009','part024-u046','part023-u121','part025-u053',
        'part020-u067','part020-u068','part021-u014','part021-u052','part021-u072','part017-u058','part025-u054','part025-u055'],
        'edits':'reviews/034_cross_chapter_terms.json',
        'scope':'Unit-level presence screening is a candidate-finding aid; it does not verify every occurrence or require mechanical one-word translation. Pair contexts were read individually; other chapter checks remain the basis for semantic coverage.'}
(R/'checks/cross_chapter_term_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'status':report['status'],'terms':len(summary),'hits':sum(x['unit_hits'] for x in summary),'exceptions':exceptions},ensure_ascii=False))
