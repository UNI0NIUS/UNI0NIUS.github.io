#!/usr/bin/env python3
"""Generate standalone Chinese and German reading Markdown from one projection."""
import hashlib
import html
import json
from collections import defaultdict
from pathlib import Path

R = Path(__file__).resolve().parents[1]
OUT = R / 'editions'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def escape(s):
    # Markdown prose may contain source punctuation; HTML escaping prevents
    # accidental tags while leaving historical spelling and accents intact.
    return html.escape(s, quote=False).replace('\\', '&#92;').replace('*', '&#42;').replace('_', '&#95;')


class Markdown:
    def __init__(self, data, lang):
        self.data, self.lang = data, lang
        self.units = {u['id']: u for u in data['units']}
        self.last_page = None
        self.references = set()
        self.notes = defaultdict(list)
        self.first_pages = {str(refs[0].get('display_printed_page') or refs[0].get('printed_page'))
                            for u in data['units'] if (refs := u['mapped_source_refs'])
                            and (refs[0].get('display_printed_page') or refs[0].get('printed_page')) is not None}
        self.emitted = set()

    def component(self, unit):
        text = unit['translation' if self.lang == 'zh' else 'source_text']
        if text is None:
            return ''
        events = defaultdict(list)
        consumed = {}
        refs = unit['mapped_source_refs']
        if self.lang == 'de':
            for ref in refs:
                label = ref.get('display_printed_page', ref.get('printed_page'))
                pos = ref['unit_start']
                if label is not None and 0 < pos < len(text) and text[pos-1].isalpha() and text[pos].isalpha():
                    while pos < len(text) and text[pos].isalpha():
                        pos += 1
                if label is not None:
                    events[pos].append(('page', str(label)))
        elif refs:
            label = refs[0].get('display_printed_page', refs[0].get('printed_page'))
            if label is not None:
                events[0].append(('page', str(label)))
            for ref in refs[1:]:
                label = ref.get('display_printed_page', ref.get('printed_page'))
                if label is not None and str(label) not in self.first_pages and ('page', str(label)) not in events[len(text)]:
                    events[len(text)].append(('page', str(label)))
        for n in unit.get('original_notes', []):
            anchor = n['anchor_translation_after' if self.lang == 'zh' else 'anchor_source_after']
            pos = text.index(anchor) + len(anchor)
            events[pos].append(('note', n['id']))
            if self.lang == 'de':
                marker = n['source_marker']
                if text[pos:pos+len(marker)] != marker:
                    raise ValueError(f"{unit['id']}: note marker mismatch")
                consumed[pos] = len(marker)
        spans = unit['source_emphasis'] if self.lang == 'de' else []
        boundaries = {0, len(text)} | set(events)
        boundaries.update(v for s in spans for v in (s['start'], s['end']))
        boundaries.update(k + v for k, v in consumed.items())
        boundaries = sorted(boundaries)
        result = [f'<a id="unit-{unit["id"]}"></a>']
        for i, pos in enumerate(boundaries):
            for kind, value in events.get(pos, []):
                if kind == 'page':
                    if self.last_page != value:
                        result.append(f'<span class="source-page">〔S. {escape(value)}〕</span>')
                        self.last_page = value
                else:
                    self.references.add(value)
                    result.append(f'<a id="ref-{value}" href="#note-{value}"><sup>1</sup></a>')
            if i == len(boundaries)-1:
                break
            nxt = boundaries[i+1]
            if any(start <= pos < start + length for start, length in consumed.items()):
                continue
            part = escape(text[pos:nxt])
            if any(span['start'] <= pos and nxt <= span['end'] for span in spans):
                part = '<em>' + part + '</em>'
            result.append(part)
        return ''.join(result)

    def toc(self):
        lines = ['## 原书目录 / Inhalt des Originals', '']
        if self.lang == 'zh':
            lines.extend(['〔编者按〕原目录将序言标为第 I 页；所存底本的序言首页未印页码，后续页为 VI–IX。', ''])
        else:
            lines.extend(['[Redaktionelle Erläuterung] Das Originalverzeichnis nennt für die Vorrede Seite I; die erste Vorredenseite trägt keine sichtbare Zahl, die folgenden Seiten VI–IX.', ''])
        entries = self.data['toc']['entries']
        ordered = []
        for root in (e for e in entries if e['parent'] is None):
            ordered.append(root)
            ordered.extend(e for e in entries if e['parent'] == root['id'])
        if len(ordered) != len(entries):
            raise ValueError('Unmapped nested TOC entry')
        for e in ordered:
            title = e['title_zh' if self.lang == 'zh' else 'title_de']
            number = f"{e['original_toc_number']}. " if e.get('original_toc_number') else ''
            page = str(e.get('target_printed_page') or '') if e['parent'] or e['id'] == 'preface' else ''
            lines.append(('  ' if e['parent'] else '') + '- [' + escape(number + title) + '](#section-' + e['id'] + ')' + (' — ' + escape(page) if page else ''))
            detail = e.get('detailed_topics')
            if detail:
                lines.append('  ' + escape(detail[self.lang]))
        return '\n'.join(lines) + '\n'

    def endnotes(self, scope):
        notes = self.notes.get(scope, [])
        if not notes:
            return []
        lines = ['### 原注 / Anmerkungen', '']
        for n in notes:
            text = escape(n[self.lang])
            if self.lang == 'zh':
                text += '<br>原文：' + escape(n['de'])
            lines.extend([f'<a id="note-{n["id"]}"></a>〔S. 86〕 <sup>1</sup> {text} <a href="#ref-{n["id"]}">↑</a>', ''])
        return lines

    def render(self):
        name = '哲学体系第一部：纯粹认识的逻辑' if self.lang == 'zh' else 'System der Philosophie. Erster Theil: Logik der reinen Erkenntniss'
        out = ['# ' + name, '', '赫尔曼·柯亨 / Hermann Cohen', '',
               '〔S.〕标记为原书印刷页码。' if self.lang == 'zh' else 'Die Markierungen „S.“ bezeichnen die Druckseiten des Originals.', '']
        scope = None
        toc_done = False
        for group in self.data['groups']:
            units = [self.units[x] for x in group['unit_ids']]
            u = units[0]
            if u['source_text'] is None:
                continue
            new_scope = u['section_id']
            if new_scope == 'introduction' and not toc_done:
                if scope:
                    out.extend(self.endnotes(scope))
                out.extend([self.toc(), ''])
                toc_done = True
            if scope is not None and scope != new_scope:
                out.extend(self.endnotes(scope))
            scope = new_scope
            self.emitted.update(x['id'] for x in units)
            for x in units:
                self.notes[scope].extend(x.get('original_notes', []))
            if u['kind'] == 'heading':
                heading = self.component(u)
                out.extend([f'<a id="section-{scope}"></a>' if scope != 'front-matter' else '',
                            ('## ' if u.get('heading_level') == 1 else '### ') + heading, ''])
            else:
                out.extend([('' if self.lang == 'zh' else ' ').join(self.component(x) for x in units), ''])
                for x in units:
                    for n in x.get('editorial_notes', []):
                        message = n.get('text_' + self.lang) or n.get(self.lang)
                        if not message:
                            raise ValueError(f"{x['id']}: missing editorial note")
                        prefix = '〔编者按〕' if self.lang == 'zh' else '[Redaktionelle Erläuterung] '
                        out.extend(['> ' + escape(prefix + message), ''])
        if scope:
            out.extend(self.endnotes(scope))
        expected_notes = {n['id'] for ns in self.notes.values() for n in ns}
        if self.references != expected_notes:
            raise ValueError('Original note references and targets differ')
        expected_units = {u['id'] for u in self.data['units'] if u['source_text'] is not None}
        if self.emitted != expected_units:
            raise ValueError('Missing content units')
        return '\n'.join(out)


def main():
    projection_path = R / 'reading_projection.json'
    data = json.loads(projection_path.read_text(encoding='utf-8'))
    for name in ('source_units.jsonl', 'translation_units.jsonl', 'original_toc.json'):
        if sha(R / name) != data['inputs_sha256'][name]:
            raise ValueError(f'Stale projection: {name}')
    OUT.mkdir(exist_ok=True)
    files = {}
    for lang in ('zh', 'de'):
        md = Markdown(data, lang)
        text = md.render()
        path = OUT / f'cohen_system_1_{lang}.md'
        # Git Pages normalizes tracked text to LF. Emit LF at the source so
        # published downloads match the recorded byte hashes exactly.
        path.write_text(text, encoding='utf-8', newline='\n')
        files[lang] = {'path': str(path), 'sha256': sha(path), 'emitted_units': len(md.emitted)}
    report = {'status': 'generated_pending_content_and_render_qa', 'projection_sha256': sha(projection_path),
              'builder_sha256': sha(Path(__file__)), 'files': files}
    (R / 'checks' / 'markdown_build.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
