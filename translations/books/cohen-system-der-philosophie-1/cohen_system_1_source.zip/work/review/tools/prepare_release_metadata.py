#!/usr/bin/env python3
"""Bind download hashes outside the source ZIP to avoid a self-hash cycle."""
import hashlib
import json
from pathlib import Path

R=Path(__file__).resolve().parents[1]
O=R/'editions'
BOOK='cohen-system-der-philosophie-1'
BASE='translations/books/'+BOOK+'/'


def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    metadata=json.loads((O/'webdata'/'book-metadata.json').read_text(encoding='utf-8'))
    assert metadata['id']==BOOK and not metadata['downloads']
    assets=[('中德对照版 PDF','cohen_system_1_bilingual.pdf'),('中文阅读版 PDF','cohen_system_1_zh.pdf'),
            ('德文原文版 PDF','cohen_system_1_de.pdf'),('中文 Markdown','cohen_system_1_zh.md'),
            ('德文 Markdown','cohen_system_1_de.md'),('可编辑源码包','cohen_system_1_source.zip')]
    metadata['downloads']=[]
    for label,name in assets:
        path=O/name; digest=sha(path)
        metadata['downloads'].append({'label':label,'url':BASE+name+'?v='+digest[:12],'bytes':path.stat().st_size,'sha256':digest})
    metadata['reviewedCanonicalSha256']=sha(R/'translation_units.jsonl')
    metadata['sourceEdition']='Cohen, Berlin, Bruno Cassirer, 1902'
    metadata['readerUrl']='https://uni0nius.github.io/translations/book.html?id='+BOOK
    assert 'innerReaderUrl' not in metadata
    path=O/'release-metadata.json';path.write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    report={'status':'download_metadata_prepared_pending_acceptance','metadata_sha256':sha(path),
            'projection_sha256':sha(R/'reading_projection.json'),'download_count':len(assets),
            'source_package_sha256':sha(O/'cohen_system_1_source.zip'),'inner_site_fields':False}
    (R/'checks/release_metadata.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))


if __name__=='__main__': main()
