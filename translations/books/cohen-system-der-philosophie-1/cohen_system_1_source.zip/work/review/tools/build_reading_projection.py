#!/usr/bin/env python3
"""Create a lossless, auditable reading projection from reviewed canonical data.

This is an intermediate representation, not a final layout or a publication.
Character offsets are Python Unicode offsets in each translation unit's text.
"""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'source_units.jsonl'
TRANSLATION = ROOT / 'translation_units.jsonl'
TOC = ROOT / 'original_toc.json'
OUTPUT = ROOT / 'reading_projection.json'
CHECK = ROOT / 'checks' / 'reading_projection_check.json'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def lines(path):
    return [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line.strip()]


def map_unit(unit, sources):
    text = unit['source_text']
    if text is None:
        if unit.get('source_refs'):
            raise ValueError(f"{unit['id']}: source refs without source text")
        return [], []
    position = 0
    refs = []
    spans = []
    for index, ref in enumerate(unit.get('source_refs', [])):
        block = sources[ref['source_unit_id']]
        start, end = ref['source_char_start'], ref['source_char_end']
        raw = block['source_text'][start:end]
        left = len(raw) - len(raw.lstrip())
        right = len(raw.rstrip())
        fragment = raw.strip()
        while position < len(text) and text[position].isspace():
            position += 1
        choices = [fragment]
        if fragment.endswith('-') and index + 1 < len(unit['source_refs']):
            choices.append(fragment[:-1])
        matches = [v for v in choices if text.startswith(v, position)]
        if not matches:
            raise ValueError(f"{unit['id']}: cannot align {ref['source_unit_id']} at {position}")
        chosen = matches[0]
        mapped_start = start + left
        mapped_end = mapped_start + len(chosen)
        if mapped_end > start + right:
            raise ValueError(f"{unit['id']}: source range exceeds trimmed fragment")
        refs.append({'source_unit_id': ref['source_unit_id'], 'pdf_page': ref['pdf_page'],
                     'printed_page': ref.get('printed_page'), 'source_start': mapped_start,
                     'source_end': mapped_end, 'unit_start': position,
                     'unit_end': position + len(chosen), 'removed_end_hyphen': chosen != fragment})
        for em in block.get('source_emphasis', []):
            if block['source_text'][em['start']:em['end']] != em['text']:
                raise ValueError(f"{block['id']}: stale emphasis text")
            lo, hi = max(em['start'], mapped_start), min(em['end'], mapped_end)
            if lo < hi:
                spans.append({'start': position + lo - mapped_start,
                              'end': position + hi - mapped_start,
                              'source_unit_id': block['id'], 'type': em['type']})
        position += len(chosen)
    if text[position:].strip():
        raise ValueError(f"{unit['id']}: unmatched source tail {text[position:position+50]!r}")
    merged = []
    for span in sorted(spans, key=lambda a: (a['start'], a['end'])):
        if merged and span['start'] < merged[-1]['end']:
            merged[-1]['end'] = max(merged[-1]['end'], span['end'])
            merged[-1]['source_unit_ids'] = sorted(set(merged[-1]['source_unit_ids'] + [span['source_unit_id']]))
            merged[-1]['overlapping_source_annotations'] += 1
        else:
            merged.append({'start': span['start'], 'end': span['end'], 'type': span['type'],
                           'source_unit_ids': [span['source_unit_id']], 'overlapping_source_annotations': 0})
    for span in merged:
        span['text'] = text[span['start']:span['end']]
    return refs, merged


def main():
    source = lines(SOURCE)
    units = lines(TRANSLATION)
    sources = {x['id']: x for x in source}
    if len(sources) != len(source) or len({u['id'] for u in units}) != len(units):
        raise ValueError('Duplicate canonical ID')
    toc = json.loads(TOC.read_text(encoding='utf-8'))
    # The introduction TOC predates title_unit_id capture; bind its actual
    # printed headings explicitly, including the two headings in producer part 5.
    intro_titles = ['part002-u002', 'part003-u001', 'part004-u001', 'part005-u001',
                    'part005-u004', 'part006-u001', 'part007-u001', 'part008-u001',
                    'part009-u001', 'part010-u001', 'part011-u001', 'part012-u001']
    title_to_section = {'part001-u009': 'preface', 'part002-u001': 'introduction'}
    title_to_section.update({unit_id: f'intro-{i:02}' for i, unit_id in enumerate(intro_titles, 1)})
    title_to_section.update({entry['title_unit_id']: entry['id'] for entry in toc['entries'] if entry.get('title_unit_id')})
    if set(title_to_section.values()) != {entry['id'] for entry in toc['entries']}:
        raise ValueError('Section headings do not cover the original TOC')
    section = 'front-matter'
    routes = {'front-matter': []}
    result = []
    groups = []
    seen_groups = set()
    for unit in units:
        if unit['id'] in title_to_section:
            if unit['kind'] != 'heading' or not unit.get('source_text'):
                raise ValueError(f"{unit['id']}: section title is not a content heading")
            section = title_to_section[unit['id']]
            routes[section] = []
        refs, emphasis = map_unit(unit, sources)
        record = {k: unit[k] for k in ('id', 'kind', 'heading_level', 'source_text', 'translation',
                  'review_status', 'reading_group', 'join_previous', 'original_notes', 'editorial_notes') if k in unit}
        record['mapped_source_refs'] = refs
        # The opening of class 3 suppresses its running folio. Its original
        # TOC and adjacent pages identify it as 179; retain the missing
        # printed label separately from the evidence-based display label.
        for ref in refs:
            if ref['pdf_page'] == 207 and ref['printed_page'] is None:
                entries = [e for e in toc['entries'] if e['id'] in ('class-3', 'class-3-1')]
                if len(entries) != 2 or any(str(e['target_printed_page']) != '179' or e['target_pdf_page'] != 207 for e in entries):
                    raise ValueError('Page 179 inference lost its TOC evidence')
                ref['display_printed_page'] = '179'
                ref['page_label_basis'] = 'original TOC; adjacent printed pages 178 and 180; folio suppressed on chapter opening'
        record['source_emphasis'] = emphasis
        record['section_id'] = section
        routes[section].append(unit['id'])
        for note in record.get('original_notes', []):
            marker = note['source_marker']
            source_anchor = note['anchor_source_after'] + marker
            if record['source_text'].count(source_anchor) != 1 or record['translation'].count(note['anchor_translation_after']) != 1:
                raise ValueError(f"{unit['id']}: ambiguous original note anchor")
        for note in record.get('editorial_notes', []):
            for lang, field in [('source_text', 'anchor_source_after'), ('translation', 'anchor_translation_after')]:
                if field in note and record[lang].count(note[field]) != 1:
                    raise ValueError(f"{unit['id']}: ambiguous editorial note anchor {field}")
        group = unit.get('reading_group')
        if unit.get('join_previous'):
            if not groups or not group or groups[-1]['reading_group'] != group or groups[-1]['section_id'] != section:
                raise ValueError(f"{unit['id']}: join_previous is not contiguous")
            groups[-1]['unit_ids'].append(unit['id'])
        else:
            if group and group in seen_groups:
                raise ValueError(f"{unit['id']}: reading group reused non-contiguously")
            if group:
                seen_groups.add(group)
            groups.append({'reading_group': group, 'section_id': section, 'unit_ids': [unit['id']]})
        result.append(record)
    hashes = {'source_units.jsonl': sha(SOURCE), 'translation_units.jsonl': sha(TRANSLATION),
              'original_toc.json': sha(TOC), 'builder': sha(Path(__file__))}
    projection = {'schema_version': 1, 'status': 'intermediate_not_final', 'inputs_sha256': hashes,
                  'toc': toc, 'sections': routes, 'groups': groups, 'units': result}
    OUTPUT.write_text(json.dumps(projection, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    report = {'status': 'passed', 'inputs_sha256': hashes, 'projection_sha256': sha(OUTPUT),
              'units': len(result), 'groups': len(groups), 'joined_units': sum(len(g['unit_ids'])-1 for g in groups),
              'sections_including_front_matter': len(routes),
              'mapped_refs': sum(len(u['mapped_source_refs']) for u in result),
              'mapped_emphasis_ranges': sum(len(u['source_emphasis']) for u in result),
              'overlapping_annotations_merged': sum(e['overlapping_source_annotations'] for u in result for e in u['source_emphasis']),
              'original_notes': sum(len(u.get('original_notes', [])) for u in result),
              'editorial_notes': sum(len(u.get('editorial_notes', [])) for u in result),
              'scope': 'Mechanical alignment and anchor uniqueness only; does not establish semantic or visual acceptance.'}
    CHECK.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
