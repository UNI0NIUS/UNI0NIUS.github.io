"""Screen every PDF page for intersecting body lines and sparse pages."""
import hashlib,json,re
from pathlib import Path
import fitz
R=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
report={'scope':'All PDF pages, extracted text geometry only; does not replace visual inspection. Margin labels, headers and footers are excluded.','editions':{}}
for mode in ('zh','de','bilingual'):
 path=R/'editions'/f'cohen_system_1_{mode}.pdf';doc=fitz.open(path);overlaps=[];sparse=[]
 for n,page in enumerate(doc,1):
  lines=[];characters=0
  for block in page.get_text('dict')['blocks']:
   for line in block.get('lines',[]):
    spans=[s for s in line['spans'] if s['text'].strip() and 55<=s['bbox'][1]<=780 and not re.fullmatch(r'S\.\s*(?:\d+|[IVXLCDM]+)',s['text'].strip())]
    if not spans:continue
    x0=min(s['bbox'][0] for s in spans);y0=min(s['bbox'][1] for s in spans)
    x1=max(s['bbox'][2] for s in spans);y1=max(s['bbox'][3] for s in spans)
    text=''.join(s['text'] for s in spans).strip();lines.append((x0,y0,x1,y1,text));characters+=len(text)
  if characters<180:sparse.append({'page':n,'body_characters':characters,'sample':' '.join(x[4] for x in lines)[:160]})
  lines.sort(key=lambda x:x[1])
  for i,a in enumerate(lines):
   for b in lines[i+1:]:
    if b[1]>=a[3]-1:break
    dx=min(a[2],b[2])-max(a[0],b[0]);dy=min(a[3],b[3])-max(a[1],b[1])
    if dx>5 and dy>3 and abs(a[1]-b[1])>2:
     overlaps.append({'page':n,'x_overlap':round(dx,2),'y_overlap':round(dy,2),'samples':[a[4][:60],b[4][:60]]})
 report['editions'][mode]={'pdf_sha256':sha(path),'pages_screened':len(doc),'overlap_candidates':overlaps,'sparse_pages':sparse}
 if overlaps:raise ValueError(f'{mode}: unresolved line-overlap candidates')
report['status']='all_pages_geometry_screened_sparse_pages_require_visual_classification'
(R/'checks/layout_geometry.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps(report,ensure_ascii=False,indent=2))
