#!/usr/bin/env python3
"""Export outer-site bilingual reader data from the reviewed projection."""
import hashlib
import json
from collections import defaultdict, Counter
from pathlib import Path

R = Path(__file__).resolve().parents[1]
O = R / 'editions' / 'webdata'
BOOK = 'cohen-system-der-philosophie-1'
BASE = 'translations/books/' + BOOK + '/'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def plain(tokens, lang):
    out = []
    for t in tokens:
        if isinstance(t, str): out.append(t)
        elif t['type'] == 'em': out.append(plain(t['children'], lang))
        elif t['type'] == 'note' and lang == 'en': out.append('¹)')
    return ''.join(out)


class Export:
    def __init__(self, data):
        self.data = data
        self.units = {u['id']:u for u in data['units']}
        self.sections = {}
        self.ids = []
        self.reference_count = Counter()
        self.first_pages = {str(refs[0].get('display_printed_page') or refs[0].get('printed_page'))
                            for u in data['units'] if (refs := u['mapped_source_refs'])
                            and (refs[0].get('display_printed_page') or refs[0].get('printed_page')) is not None}

    def component(self, unit, lang):
        text = unit['translation' if lang == 'zh' else 'source_text']
        if text is None: return []
        events = defaultdict(list)
        consumed = {}
        refs = unit['mapped_source_refs']
        if lang == 'en':
            previous = None
            for ref in refs:
                label = ref.get('display_printed_page', ref.get('printed_page'))
                if label is None or str(label) == previous: continue
                label = str(label); previous = label
                pos = ref['unit_start']
                anchor_id = f'en-{unit["id"]}-page-{ref["pdf_page"]}'
                if 0 < pos < len(text) and text[pos-1].isalpha() and text[pos].isalpha():
                    # The silent anchor remains at the exact source boundary;
                    # the visible marker follows the rest of the same word.
                    events[pos].append({'type':'anchor','id':anchor_id})
                    while pos < len(text) and text[pos].isalpha(): pos += 1
                    events[pos].append({'type':'page','page':label,'id':anchor_id+'-label'})
                else:
                    events[pos].append({'type':'anchor' if pos == 0 else 'page','id':anchor_id, **({} if pos == 0 else {'page':label})})
        elif refs:
            for ref in refs[1:]:
                label = ref.get('display_printed_page', ref.get('printed_page'))
                if label is None or str(label) in self.first_pages: continue
                token = {'type':'page','page':str(label),'id':f'zh-{unit["id"]}-page-{ref["pdf_page"]}'}
                if token not in events[len(text)]: events[len(text)].append(token)
        for n in unit.get('original_notes', []):
            anchor = n['anchor_translation_after' if lang == 'zh' else 'anchor_source_after']
            pos = text.index(anchor) + len(anchor)
            events[pos].append({'type':'note','id':n['id'],'label':'1'})
            self.reference_count[lang,n['id']] += 1
            if lang == 'en':
                if text[pos:pos+len(n['source_marker'])] != n['source_marker']: raise ValueError('Note marker mismatch')
                consumed[pos] = len(n['source_marker'])
        spans = unit['source_emphasis'] if lang == 'en' else []
        boundaries = {0,len(text)} | set(events)
        boundaries.update(k+v for k,v in consumed.items())
        boundaries.update(v for span in spans for v in (span['start'],span['end']))
        boundaries = sorted(boundaries)
        anchor = {'type':'anchor','id':f'{lang}-{unit["id"]}'}
        out = [anchor]; self.ids.append(anchor['id'])
        for i,pos in enumerate(boundaries):
            for token in events.get(pos, []):
                out.append(token)
                if token['type'] in ('anchor','page'): self.ids.append(token['id'])
            if i == len(boundaries)-1: break
            end = boundaries[i+1]
            if any(start <= pos < start+length for start,length in consumed.items()): continue
            content = text[pos:end]
            if not content: continue
            if any(s['start'] <= pos and end <= s['end'] for s in spans):
                out.append({'type':'em','children':[content]})
            else: out.append(content)
        if plain(out, lang) != text:
            raise ValueError(f'{unit["id"]}: {lang} source text does not round-trip')
        return out

    def chapter(self, sid, zh, de, parent=None):
        section = {'id':sid,'title':zh,'originalTitle':de,'body':[],'notes':{},'sourceLanguage':'de','sourceLanguageLabel':'Deutsch'}
        if parent: section['parentId'] = parent
        self.sections[sid] = section
        return section

    def row(self, ident, kind, page, zh, en, **extra):
        return {'id':ident,'type':kind,'page':page,'zh':zh,'en':en,**extra}

    def render(self):
        entries = {e['id']:e for e in self.data['toc']['entries']}
        for sid in self.data['sections']:
            if sid == 'front-matter': self.chapter(sid,'书前材料','Titelei'); continue
            e = entries[sid]
            self.chapter(sid,e['title_zh'],e['title_de'],e['parent'])
        self.chapter('original-toc','原书目录（原书页码）','Inhalt des Originals (Originalseiten)')
        for group in self.data['groups']:
            units = [self.units[i] for i in group['unit_ids']]
            first = units[0]
            if first['source_text'] is None: continue
            section = self.sections[group['section_id']]
            zh, en = [], []
            pages = []
            for i,u in enumerate(units):
                if i: en.append(' ')
                zh.extend(self.component(u,'zh')); en.extend(self.component(u,'en'))
                for ref in u['mapped_source_refs']:
                    label = ref.get('display_printed_page',ref.get('printed_page'))
                    item = {'pdf_page':ref['pdf_page'],'printed_page':ref.get('printed_page'),'display_printed_page':label}
                    if item not in pages: pages.append(item)
            page = str(pages[0]['display_printed_page'] or '') if pages else ''
            section['body'].append(self.row(first['id'],'heading' if first['kind']=='heading' else 'paragraph',page,zh,en,sourcePages=pages))
            for u in units:
                for n in u.get('editorial_notes',[]):
                    z = n.get('text_zh') or n.get('zh'); de = n.get('text_de') or n.get('de')
                    if not z or not de: raise ValueError('Editorial note missing translation')
                    section['body'].append(self.row(n['id'],'paragraph','',[{'type':'block','kind':'notice','children':['〔编者按〕'+z]}],[{'type':'block','kind':'notice','children':['[Redaktionelle Erläuterung] '+de]}]))
                for n in u.get('original_notes',[]):
                    section['notes'][n['id']] = {'number':'1','sourcePrintedPage':'86','sourcePdfPage':114,
                      'zh':['[原书第86页] ',n['zh'],{'type':'break'},'原文：',n['de']],
                      'en':['[S. 86] ',n['de']]}
        toc = self.sections['original-toc']
        toc['body'].append(self.row('toc-heading','heading','', ['原书目录（原书页码）'],['Inhalt des Originals (Originalseiten)']))
        toc['body'].append(self.row('toc-preface-anomaly','paragraph','',
          [{'type':'block','kind':'notice','children':['〔编者按〕原目录将序言标为第 I 页；所存底本的序言首页未印页码，后续页为 VI–IX。']}],
          [{'type':'block','kind':'notice','children':['[Redaktionelle Erläuterung] Das Originalverzeichnis nennt für die Vorrede Seite I; die erste Vorredenseite trägt keine sichtbare Zahl, die folgenden Seiten VI–IX.']}]))
        original = self.data['toc']['entries']; ordered = []
        for root in (e for e in original if e['parent'] is None):
            ordered.append(root); ordered.extend(e for e in original if e['parent']==root['id'])
        if len(ordered) != len(original): raise ValueError('Unsupported original TOC hierarchy')
        for e in ordered:
            sid = e['id']; unit_id = self.data['sections'][sid][0]
            # Reader safeUrl resolves relative to the site root, not the
            # current /translations/ document directory.
            url = f'translations/book.html?id={BOOK}&chapter={sid}#{unit_id}'
            num = f"{e['original_toc_number']}. " if e.get('original_toc_number') else ''
            p = str(e.get('target_printed_page') or '') if e['parent'] or sid == 'preface' else ''
            suffix = (' — '+p) if p else ''
            toc['body'].append(self.row('toc-'+sid,'paragraph','',
              [{'type':'link','url':url,'children':[num+e['title_zh']+suffix]}],
              [{'type':'link','url':url,'children':[num+e['title_de']+suffix]}],indent=bool(e['parent'])))
            if e.get('detailed_topics'):
                toc['body'].append(self.row('toc-detail-'+sid,'paragraph','',[e['detailed_topics']['zh']],[e['detailed_topics']['de']],indent=True))
        if len(self.ids) != len(set(self.ids)): raise ValueError('Duplicate inline source anchors')
        if self.reference_count != Counter({('zh','orig-p114-n01'):1,('en','orig-p114-n01'):1}): raise ValueError('Incorrect original note references')
        order = list(self.data['sections']); order.insert(order.index('introduction'),'original-toc')
        meta = {'id':BOOK,'title':'哲学体系第一部：纯粹认识的逻辑','originalTitle':'System der Philosophie. Erster Theil: Logik der reinen Erkenntniss',
                'author':'Hermann Cohen','authorZh':'赫尔曼·柯亨','tags':['哲学 Philosophy','认识论 Epistemology'],
                'language':'zh-CN','languagePair':'Deutsch / 中文','structured':True,'bilingual':True,'views':['zh','en','parallel'],
                'sourceLanguage':'de','sourceLanguageLabel':'Deutsch',
                'editionNotice':'依据1902年柏林版校订。保留原书目录和印刷页码；原注附德文原文。', 'chapters':[], 'downloads':[]}
        O.mkdir(parents=True, exist_ok=True)
        for sid in order:
            s = self.sections[sid]
            meta['chapters'].append({'id':sid,'title':s['title'],'originalTitle':s['originalTitle'],'dataUrl':BASE+sid+'.json',
                                     **({'parentId':s['parentId']} if s.get('parentId') else {})})
            dump(O/(sid+'.json'),{k:v for k,v in s.items() if k!='parentId'})
        dump(O/'book-metadata.json',meta)
        return {'status':'exported_pending_browser_and_narrow_screen_qa','projection_sha256':sha(R/'reading_projection.json'),
                'builder_sha256':sha(Path(__file__)),'sections':len(order),'rows':sum(len(s['body']) for s in self.sections.values()),
                'source_anchors':len(self.ids),'note_references':dict((lang+':'+id,count) for (lang,id),count in self.reference_count.items()),
                'files':{f.name:sha(f) for f in sorted(O.glob('*.json'))}}


def main():
    d = json.loads((R/'reading_projection.json').read_text(encoding='utf-8'))
    for name in ('source_units.jsonl','translation_units.jsonl','original_toc.json'):
        if sha(R/name) != d['inputs_sha256'][name]: raise ValueError('Stale projection: '+name)
    report = Export(d).render()
    dump(R/'checks/web_export.json',report)
    print(json.dumps({k:v for k,v in report.items() if k!='files'},ensure_ascii=False,indent=2))


if __name__ == '__main__': main()
