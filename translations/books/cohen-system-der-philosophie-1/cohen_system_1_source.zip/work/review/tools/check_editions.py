#!/usr/bin/env python3
"""Bounded mechanical PDF/Markdown checks; visual acceptance is separate."""
import hashlib
import json
import re
import unicodedata
from collections import Counter
from pathlib import Path
import fitz

R = Path(__file__).resolve().parents[1]
O = R / 'editions'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def norm(s):
    return ''.join(c for c in unicodedata.normalize('NFKC', s).casefold() if c.isalnum())


def main():
    d = json.loads((R / 'reading_projection.json').read_text(encoding='utf-8'))
    result = {'projection_sha256': sha(R / 'reading_projection.json'), 'scope': 'mechanical extraction, source labels, glyph log, destinations and page bounds; not semantic or visual acceptance', 'pdf': {}, 'markdown': {}}
    for mode in ('zh', 'de', 'bilingual'):
        path = O / f'cohen_system_1_{mode}.pdf'
        doc = fitz.open(path)
        log = (O / f'cohen_system_1_{mode}.log').read_text(encoding='utf-8', errors='replace')
        bad_glyphs = len(re.findall(r'Missing character:', log))
        overfull = len(re.findall(r'Overfull \\hbox', log))
        moved = len(re.findall(r'Marginpar on page \d+ moved', log))
        labels = set()
        outliers = []
        parts = []
        links = []
        for page_number, page in enumerate(doc, 1):
            labels.update(map(int, re.findall(r'\bS\.\s*(\d+)\b', page.get_text())))
            links.extend(page.get_links())
            for block in page.get_text('dict')['blocks']:
                for line in block.get('lines', []):
                    for span in line['spans']:
                        x0,y0,x1,y1=span['bbox']
                        if x0 < 0 or y0 < 0 or x1 > page.rect.width or y1 > page.rect.height:
                            outliers.append({'page': page_number, 'text': span['text'][:80], 'bbox': span['bbox']})
                        text = span['text'].strip()
                        if y0 < 55 or y0 > 785 or re.fullmatch(r'S\.\s*(?:\d+|[IVXLCDM]+)', text):
                            continue
                        parts.append(span['text'])
        missing_labels = sorted(set(range(1,521))-labels)
        bad_links = [link for link in links if link.get('page', 0) < 0 or link.get('page', 0) >= len(doc)]
        destinations = [link.get('nameddest', '') for link in links]
        required = ['note-orig-p114-n01'] + [f'ref-{lang}-orig-p114-n01' for lang in (['zh','de'] if mode == 'bilingual' else [mode])]
        missing_links = [dest for dest in required if dest not in destinations]
        excerpts_missing = []
        if mode in ('zh','de'):
            raw = norm(' '.join(parts))
            for unit in d['units']:
                if unit['source_text'] is None:
                    continue
                source = unit['translation' if mode == 'zh' else 'source_text']
                normalized = norm(source)
                length = min(20, len(normalized))
                for place, fragment in [('start', normalized[:length]), ('end', normalized[-length:])]:
                    if fragment not in raw:
                        excerpts_missing.append({'id':unit['id'], 'position':place})
        item = {'sha256':sha(path), 'pages':len(doc), 'bookmarks':len(doc.get_toc()), 'source_pages_missing':missing_labels,
                'missing_glyph_warnings':bad_glyphs, 'overfull_hboxes':overfull, 'moved_margin_warnings':moved,
                'out_of_page_spans':outliers, 'bad_link_targets':bad_links, 'missing_note_link_destinations':missing_links,
                'content_unit_start_end_excerpts_missing':excerpts_missing}
        if missing_labels or bad_glyphs or overfull or outliers or bad_links or missing_links or excerpts_missing:
            raise ValueError(f'{mode}: unresolved mechanical failures: {item}')
        result['pdf'][mode] = item
    for mode in ('zh','de'):
        path = O / f'cohen_system_1_{mode}.md'
        text = path.read_text(encoding='utf-8')
        ids = re.findall(r'<a id="([^"]+)"', text)
        duplicates = [name for name, count in Counter(ids).items() if count > 1]
        targets = re.findall(r'href="#([^"]+)"|\]\(#([^\)]+)\)', text)
        missing = sorted({a or b for a,b in targets} - set(ids))
        if duplicates or missing:
            raise ValueError(f'{mode} Markdown anchor failures: {duplicates}, {missing}')
        result['markdown'][mode] = {'sha256':sha(path), 'anchor_count':len(ids), 'duplicate_ids':duplicates, 'missing_link_targets':missing}
    result['status'] = 'mechanical_checks_passed_visual_acceptance_pending'
    (R / 'checks' / 'edition_mechanical_check.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
