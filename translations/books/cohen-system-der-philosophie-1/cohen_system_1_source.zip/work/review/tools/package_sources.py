#!/usr/bin/env python3
"""Build and independently re-generate the portable outer-edition source bundle."""
import hashlib
import json
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

R = Path(__file__).resolve().parents[1]
O = R / 'editions'
ZIP = O / 'cohen_system_1_source.zip'


def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()


README = '''# System der Philosophie I：校订阅读版源码

底本：Hermann Cohen, System der Philosophie, Erster Theil: Logik der reinen Erkenntniss, Berlin: Bruno Cassirer, 1902。译文与源文规范数据位于 work/review；原始扫描 PDF 及局部 OCR 图像未收入本压缩包，完整证据留在制作工作区。

此包是可编辑、可复现的工作源码。章节校对、最终版面和网站验收状态见随包 checks；生成成功不等于终校通过。源页号、原注及编者说明须保留。不要运行生产者早期批次生成器，也不要覆盖本规范稿。

## 输入与入口

- `source_units.jsonl`、`translation_units.jsonl`、`original_toc.json` 是规范数据；`reading_projection.json` 是由它们生成并绑定哈希的中间层。
- 在 `work/review` 下执行 `python tools/build_reading_projection.py`、`python tools/build_editions.py --compile`、`python tools/build_markdown.py`、`python tools/build_web.py`，依次生成三种 PDF、TeX、两种 Markdown 及表站 JSON。
- 脚本需要 Python 3.11+；PDF 使用 XeLaTeX、fontspec、xeCJK、paracol、hyperref，以及 Times New Roman 和 SimSun。系统须安装这些字体和 TeX 包。PDF 编译两遍以更新目录和交叉引用。
- `tools/check_editions.py` 需安装 PyMuPDF，检查页码、摘录、边界和注释链接；实际版面与网页仍须另行核验。`glossary_decisions.json`、`reviews/` 保存术语和审校决策，`checks/` 是对应输入版本的检查记录。
- 网页依赖既有表站阅读器。`website_fonts/reading-cjk.woff2` 为在当时表站字库基础上扩充本书缺字的 Noto Serif SC 子集，遵守随附 SIL OFL 1.1；发布前须检查正式站当前字库是否已被其他任务更新，并保留全部已有字形。

原注置于 PDF 所属节末，中文注释附德文原文；网页由既有阅读器提供注释往返。源页号与输出 PDF 页码是不同的编号系统。原目录对序言的页码与扫描所见不一致，成果中有专门说明。PDF207 章首页未印页码，标记179依据原目录及相邻页推定。
'''


def main():
    (O/'README-source.md').write_text(README,encoding='utf-8')
    files = [R/x for x in ('source_units.jsonl','translation_units.jsonl','original_toc.json','front_matter.json',
                            'structure.json','glossary_decisions.json','reading_projection.json')]
    files += [R/'tools'/x for x in ('build_reading_projection.py','build_editions.py','build_markdown.py','build_web.py','check_editions.py',
                                    'check_layout_geometry.py','audit_cross_chapter_terms.py','package_sources.py','prepare_release_metadata.py')]
    files += [R/'checks'/x for x in ('reading_projection_check.json','whole_book_integrated_audit.json','whole_book_word_split_audit.json',
              'format_reference_manifest.json','edition_build.json','markdown_build.json','edition_mechanical_check.json',
              'edition_visual_progress.json','web_export.json','cjk_font_expansion.json','cjk_incremental_check.json',
              'cross_chapter_term_audit.json','layout_geometry.json','local_browser_check.json','browser_incremental_034.json')]
    files += sorted((R/'reviews').glob('*.json'))
    files += [O/'README-source.md'] + [O/f'cohen_system_1_{m}.tex' for m in ('zh','de','bilingual')] + [O/f'cohen_system_1_{m}.md' for m in ('zh','de')]
    files += sorted((O/'webdata').glob('*.json'))
    font=O/'website_fonts'/'reading-cjk.woff2'
    if font.exists(): files.append(font)
    license_path=R/'local_preview'/'fonts'/'OFL-NotoSerifSC.txt'
    if license_path.exists(): files.append(license_path)
    files = sorted(set(files))
    if any(not p.is_file() for p in files): raise ValueError('Required source file missing')
    names={p:'work/review/'+p.relative_to(R).as_posix() for p in files}
    if license_path in names: names[license_path] = 'work/review/editions/website_fonts/OFL-NotoSerifSC.txt'
    with zipfile.ZipFile(ZIP,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as archive:
        for p,name in names.items(): archive.write(p,name)
    with zipfile.ZipFile(ZIP) as archive:
        bad=archive.testzip()
        if bad: raise ValueError('Damaged archive member '+bad)
        if len(archive.namelist()) != len(set(archive.namelist())): raise ValueError('Duplicate archive member')
        dest=Path(tempfile.mkdtemp(prefix='cohen-source-rebuild-',dir=R/'checks'))
        archive.extractall(dest)
    root=dest/'work'/'review'
    for script in ('build_reading_projection.py','build_editions.py','build_markdown.py','build_web.py'):
        proc=subprocess.run([sys.executable,'-X','utf8',str(root/'tools'/script)],cwd=root,capture_output=True,text=True,encoding='utf-8')
        if proc.returncode: raise ValueError(f'{script} rebuild failed: {proc.stdout} {proc.stderr}')
    compare = ['reading_projection.json'] + [f'editions/cohen_system_1_{x}.tex' for x in ('zh','de','bilingual')] + [f'editions/cohen_system_1_{x}.md' for x in ('zh','de')]
    compare += ['editions/webdata/'+p.name for p in sorted((O/'webdata').glob('*.json'))]
    changed=[name for name in compare if sha(R/name)!=sha(root/name)]
    if changed: raise ValueError('Source rebuild not byte-identical: '+repr(changed))
    report={'status':'source_package_rebuild_passed_pending_final_acceptance','zip':str(ZIP),'sha256':sha(ZIP),'bytes':ZIP.stat().st_size,
            'members':len(files),'rebuild_directory':str(dest),'verified_byte_identical_files':len(compare),
            'projection_sha256':sha(R/'reading_projection.json'),'scans_omitted':'Original PDF and OCR image evidence remain in the source workspace; not needed to compile the reading editions.'}
    (R/'checks/source_package_check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))


if __name__=='__main__': main()
