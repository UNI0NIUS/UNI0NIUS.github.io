# System der Philosophie I：校订阅读版源码

底本：Hermann Cohen, System der Philosophie, Erster Theil: Logik der reinen Erkenntniss, Berlin: Bruno Cassirer, 1902。译文与源文规范数据位于 work/review；原始扫描 PDF 及局部 OCR 图像未收入本压缩包，完整证据留在制作工作区。

此包是可编辑、可复现的工作源码。章节校对、最终版面和网站验收状态见随包 checks；生成成功不等于终校通过。源页号、原注及编者说明须保留。不要运行生产者早期批次生成器，也不要覆盖本规范稿。

## 输入与入口

- `source_units.jsonl`、`translation_units.jsonl`、`original_toc.json` 是规范数据；`reading_projection.json` 是由它们生成并绑定哈希的中间层。
- 在 `work/review` 下执行 `python tools/build_reading_projection.py`、`python tools/build_editions.py --compile`、`python tools/build_markdown.py`、`python tools/build_web.py`，依次生成三种 PDF、TeX、两种 Markdown 及表站 JSON。
- 脚本需要 Python 3.11+；PDF 使用 XeLaTeX、fontspec、xeCJK、paracol、hyperref，以及 Times New Roman 和 SimSun。系统须安装这些字体和 TeX 包。PDF 编译两遍以更新目录和交叉引用。
- `tools/check_editions.py` 需安装 PyMuPDF，检查页码、摘录、边界和注释链接；实际版面与网页仍须另行核验。`glossary_decisions.json`、`reviews/` 保存术语和审校决策，`checks/` 是对应输入版本的检查记录。
- 网页依赖既有表站阅读器。`website_fonts/reading-cjk.woff2` 为在当时表站字库基础上扩充本书缺字的 Noto Serif SC 子集，遵守随附 SIL OFL 1.1；发布前须检查正式站当前字库是否已被其他任务更新，并保留全部已有字形。

原注置于 PDF 所属节末，中文注释附德文原文；网页由既有阅读器提供注释往返。源页号与输出 PDF 页码是不同的编号系统。原目录对序言的页码与扫描所见不一致，成果中有专门说明。PDF207 章首页未印页码，标记179依据原目录及相邻页推定。
