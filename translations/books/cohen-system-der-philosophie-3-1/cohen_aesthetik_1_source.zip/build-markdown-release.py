"""Generate Markdown from the same source as the PDF editions."""
import html,json
from pathlib import Path
import source_emphasis

book=json.loads(Path('book-projection-draft.json').read_text(encoding='utf8'))
pref=json.loads(Path('preface-reading-units.json').read_text(encoding='utf8'))
toc=json.loads(Path('original-contents.json').read_text(encoding='utf8'))
variants=sorted(json.loads(Path('editorial-variants.json').read_text(encoding='utf8'))['items'],key=lambda v:v['printed_page'])
emphasis=source_emphasis.load();out=Path('release-editions');out.mkdir(exist_ok=True)
def printed(n):return {11:'VII',12:'VIII',13:'IX',14:'X',15:'XI',16:'XII',17:'XIII',18:'XIV'}.get(n,str(n-30))
def anchors(row):return ''.join(f'<a id="unit-{html.escape(a["id"],quote=True)}"></a>' for a in row.get('anchor_positions',[{'id':row['id']}]))
def de_text(row):
    return ''.join(html.escape(t) if isinstance(t,str) else '<em>'+html.escape(''.join(t['children']))+'</em>' for t in source_emphasis.tokens(row,emphasis))
def mark(row,last):
    labels=[]
    for p in row['source_pdf_pages']:
        if p!=last:labels.append(printed(p));last=p
    return (''.join(f'<span class="source-page">〔S. {html.escape(x)}〕</span>' for x in labels),last)
for lang in ('zh','de'):
    title='哲学体系第三部：纯粹情感的美学（第一卷）' if lang=='zh' else 'System der Philosophie. Dritter Teil: Ästhetik des reinen Gefühls. Erster Band'
    lines=[f'# {title}','','赫尔曼·柯亨 / Hermann Cohen','','依据 1912 年柏林版 / Nach der Berliner Ausgabe von 1912','','“S.”为原书印刷页码；跨页段落页码按段落定位。' if lang=='zh' else '„S.“ bezeichnet die Druckseite des Originals; Seitenverweise bei übergreifenden Absätzen stehen am Absatz.','','## 序言' if lang=='zh' else '## Vorrede','']
    last=None
    for row in pref['units']:
        marker,last=mark(row,last);lines.extend([anchors(row)+marker+(html.escape(row['translation']) if lang=='zh' else de_text(row)),''])
    lines.extend(['## 编校说明' if lang=='zh' else '## Editorische Hinweise','',('以下记录本版相对于所用 1912 年底本的部分补正及保留的疑似印刷异常，并非全部印刷异文。' if lang=='zh' else 'Die folgenden Hinweise dokumentieren einzelne Eingriffe und beibehaltene mutmaßliche Druckfehler des verwendeten Drucks von 1912; sie sind keine vollständige Liste aller Druckvarianten.'),''])
    for v in variants:
        page=str(v['printed_page']);before=v['original'];after=v['edition']
        reading=before+(f' → {after}' if before!=after else '')
        lines.extend([f'- 原书第 {page} 页：{reading}。{v["explanation_zh"]}' if lang=='zh' else f'- Original S. {page}: {reading}. {v["explanation_de"]}'])
    lines.append('')
    lines.extend(['## 原书目录（原书页码）' if lang=='zh' else '## Inhaltsverzeichnis des Originals',''])
    for chapter in range(1,7):
        h=next(x for x in book['items'] if x['kind']=='chapter' and x['chapter']==chapter)
        lines.extend(['### '+(h['translation'] if lang=='zh' else h['source_text']),''])
        for entry in (e for e in toc['entries'] if e['chapter']==chapter):
            number=entry['printed_toc_page_number'];page='' if number is None else f'　{number}'
            lines.extend(['- '+(entry['zh_heading'] if lang=='zh' else entry['de_heading'])+page])
            topic=entry['zh_topics'] if lang=='zh' else entry['de_topics']
            if topic:
                extra='　'+str(entry['extra_printed_toc_number_after_topics']) if 'extra_printed_toc_number_after_topics' in entry else ''
                lines.extend(['  '+topic+extra])
        lines.append('')
    lines.extend(['## 第一部分　系统美学的奠基' if lang=='zh' else '## Erster Teil. Die Grundlegung der systematischen Ästhetik',''])
    last=None
    for row in book['items']:
        if row['kind'] in ('chapter','heading'):
            content=row['translation'] if lang=='zh' else row['source_text'];level='##' if row['kind']=='chapter' else '###'
            lines.extend([level+' <a id="unit-'+html.escape(row['id'],quote=True)+'"></a>'+html.escape(content),''])
            if row['kind']=='chapter' and row['chapter']==6:
                lines.extend([('〔编者按〕'+book['editorial_note_zh']) if lang=='zh' else ('[Redaktionelle Erläuterung] '+book['editorial_note_de']),''])
        else:
            marker,last=mark(row,last);lines.extend([anchors(row)+marker+(html.escape(row['translation']) if lang=='zh' else de_text(row)),''])
    path=out/f'cohen_aesthetik_1_{lang}.md';path.write_text('\n'.join(lines).rstrip()+'\n',encoding='utf8',newline='\n');print('Generated',path)
