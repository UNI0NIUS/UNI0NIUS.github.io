"""Add only missing Han glyphs via a separate font, retaining the existing font unchanged."""
from pathlib import Path
import hashlib,json
from fontTools import subset
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont

old_path=Path(r'C:\Users\Union\Documents\Codex\2026-10-25\co\release-site\fonts\reading-cjk.woff2')
source_path=Path(r'C:\Windows\Fonts\NotoSerifSC-VF.ttf');out=Path('draft-font');out.mkdir(exist_ok=True)
old=TTFont(old_path);oldmap=old.getBestCmap();chars=set()
def collect(v):
 if isinstance(v,str):chars.update(ord(c) for c in v if '\u3400'<=c<='\u9fff' or '\uf900'<=c<='\ufaff' or 0x20000<=ord(c)<=0x3134f)
 elif isinstance(v,list):
  for x in v:collect(x)
 elif isinstance(v,dict):
  for x in v.values():collect(x)
for p in [Path('draft-web-metadata.json')]+list(Path('draft-web').glob('*.json')):
 data=json.loads(p.read_text(encoding='utf8'))
 if 'body' in data:
  for row in data['body']:collect(row.get('zh',[]))
 else:collect(data)
needed=chars-set(oldmap);assert needed
font=TTFont(source_path);assert needed<=set(font.getBestCmap())
opts=subset.Options();opts.name_IDs=['*'];opts.name_legacy=True;opts.name_languages=['*']
sub=subset.Subsetter(options=opts);sub.populate(unicodes=needed);sub.subset(font)
axes={'wght':(400,400,600)}
if any(a.axisTag=='wdth' for a in font['fvar'].axes):axes['wdth']=100
instantiateVariableFont(font,axes,inplace=True);font.flavor='woff2'
path=out/'reading-cjk-cohen-aesthetik-supplement.woff2';font.save(path)
new=TTFont(path);newmap=new.getBestCmap();assert needed<=set(newmap) and not(set(newmap)&set(oldmap))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report={'status':'supplement_generated_pending_actual_browser_review','source_font':str(source_path),'source_sha256':sha(source_path),'existing_font_sha256':sha(old_path),'supplement_sha256':sha(path),'existing_codepoints':len(oldmap),'supplement_codepoints':len(newmap),'missing_han':''.join(map(chr,sorted(needed))),'overlap_with_existing':len(set(newmap)&set(oldmap)),'uncovered_book_han':len(chars-(set(newmap)|set(oldmap))),'scope':'Existing font remains byte-identical; the supplemental font covers only codepoints absent from it. Browser fallback and weight rendering remain to be checked.'}
(out/'supplement-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print('supplement',len(newmap),'glyph codepoints, overlap with old',report['overlap_with_existing'])
