"""Hash-bound original emphasis shared by the provisional output builders."""
import hashlib,json
from pathlib import Path

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_text(encoding='utf8'))

def load():
    book_path='book-projection-draft.json';pre_path='preface-reading-units.json'
    book=read(book_path);pre=read(pre_path)
    by={x['id']:x for x in pre['units']+[x for x in book['items'] if x['kind']=='paragraph']}
    result={}
    for ch in range(1,7):
        p=f'letterspacing-chapter{ch}-full.json';d=read(p)
        assert d['projection_sha256']==sha(book_path),p
        for a in d['annotations']:result.setdefault(a['id'],[]).append(a)
    d=read('letterspacing-preface-full.json');assert d['preface_units_sha256']==sha(pre_path)
    for a in d['annotations']:result.setdefault(a['id'],[]).append(a)
    for ident,rows in result.items():
        rows.sort(key=lambda a:a['start']);text=by[ident]['source_text'];end=0
        for a in rows:
            assert a['start']>=end and text[a['start']:a['end']]==a['text'],(ident,a)
            end=a['end']
    return result

def tokens(row,annotations):
    text=row['source_text'];result=[];pos=0
    for a in annotations.get(row['id'],[]):
        if a['start']>pos:result.append(text[pos:a['start']])
        result.append({'type':'em','children':[text[a['start']:a['end']]]})
        pos=a['end']
    if pos<len(text):result.append(text[pos:])
    assert ''.join(t if isinstance(t,str) else ''.join(t['children']) for t in result)==text
    return result

def tex(row,annotations,escape,markers=()):
    """Render page marks at source offsets; split emphasis if a mark lies inside it."""
    text=row['source_text'];rows=annotations.get(row['id'],[])
    marker_map={}
    for pos,mark in markers:marker_map.setdefault(pos,[]).append(mark)
    points=sorted({0,len(text),*marker_map,*[x for a in rows for x in (a['start'],a['end'])]})
    result=[]
    for i,pos in enumerate(points):
        result.extend(marker_map.get(pos,[]))
        if i+1==len(points):break
        end=points[i+1];segment=escape(text[pos:end]);active=any(a['start']<=pos and end<=a['end'] for a in rows)
        result.append(r'\emph{'+segment+'}' if active else segment)
    return ''.join(result)
