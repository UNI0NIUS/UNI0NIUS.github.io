<!-- part 006: S. 100–135 -->

<!-- pdf:130 S.100 -->

wird, dann wird man ebenso erwarten müssen, daß erst das reine Gefühl der Ästhetik der Psychologie Belehrung geben kann über das reine Gefühl. Schon die Ausdrücke des sinnlichen Gefühls und des geistigen Gefühls involvieren diese systematische Abhängigkeit.

Bevor wir nun aber an diesen Aufbau des reinen Gefühls herangehen, werde zuvörderst eine Auseinandersetzung mit Kant nicht umgangen.

## 8. Kants Grundbestimmungen

Wir haben gesehen, daß er das Gefühl als Lebensgefühl und als Gefühl von Lust und Unlust bezeichnet. Aber wie Mendelssohn „alle Seelenkräfte“, „die Vollkommenheit“ derselben anruft, so bezeichnet auch Kant das neue Gefühl als „das ganze Vermögen der Vorstellungen“. Die „Vorstellungen“ enthalten die Gefahr einer Einschränkung des „ganzen Vermögens“ in sich. Es entsteht die Besorgnis, daß nicht alle Seelenkräfte ins Spiel treten könnten. Dieses Bedenken ist begründet. Das ganze Vermögen wird von Kant in das Verhältnis zwischen Einbildungskraft und Verstand gelegt. Was wird aber dabei aus dem Willen und seinem Gebiete des Sittlichen, das doch sicherlich ebenso das ästhetische Gefühl mitbilden muß, wie das Erkenntnisgebiet? Die Antwort auf diese Frage wird später zu erwägen sein.

Es ist sehr wohl verständlich, daß Kant bei der Entdeckung des ästhetischen A priori vorab auf die Festlegung des intellektuellen Fundaments bedacht sein mußte; aber für das Fundament selbst bedarf die intellektuelle Begründung der Ergänzung durch das Moment der Sittlichkeit. Und diese Ergänzung ist schon für die Bestimmung des reinen Gefühls unentbehrlich.

Kant bezeichnet das Gefühl als „die Empfindung der sich wechselseitig belebenden Einbildungskraft in ihrer Freiheit und des Verstandes in seiner Gesetzmäßigkeit“. So treten nur Einbildungskraft und Verstand in ein wechselseitiges

<!-- pdf:131 S.101 -->

Verhältnis. Und wir wissen bereits, daß die Einbildungskraft bei Kant ein eminenter Faktor innerhalb der Erkenntnistätigkeit ist. Dieses intellektuelle Verhältnis schränkt daher sogleich die Eigenart des Gefühls ein, welches unter der Hand zur „Beurteilung“ wird, nämlich des Gegenstandes, nach der Zweckmäßigkeit seiner Vorstellung für die Beförderung des „freien Spiels“ der Erkenntnisvermögen.

Es sind mithin drei Momente bei dieser Bestimmung in Wirksamkeit gekommen: 1. Das Gefühl. 2. Die Beurteilung einer Zweckmäßigkeit. 3. Diese Zweckmäßigkeit selbst, als freies Spiel der Erkenntnisvermögen. Alle diese Momente betreffen den Zusammenhang und die Unterscheidung von Erkenntnisbewußtsein und ästhetischem Bewußtsein. Die Unterscheidung ist wichtig und erfolgreich genug. Das ästhetische Urteil subsumiert nicht unter einen Begriff. Dennoch aber bleibt dieses neue Gefühl ein Urteil, eine Beurteilung der Zweckmäßigkeit.

Auch der Gesichtspunkt der Zweckmäßigkeit hat die wichtigsten Folgen. Sie wird erkannt als „die subjektive formale Bedingung eines Urteils überhaupt“. Und diese Bedingung wird ausgeführt zum „Prinzip der allgemeinen Mitteilbarkeit“. Aber so sehr und so prägnant dadurch das ästhetische Gefühl universalisiert wird, so wird es dadurch nur um so genauer und fester intellektuiert. Die ästhetische Zweckmäßigkeit wird so zu einer logischen, und zwar zur Voraussetzung alles Denkens überhaupt, sofern es die Mitteilung zum immanenten Zweck hat. Dennoch aber wurde hieraus die Konsequenz unaufhaltsam, die in der Loslösung des ästhetischen Urteils von der Subsumtion unter einen bestimmten Begriff begründet wurde. Die Subsumtion bei dieser Art von Urteil bezieht sich jetzt nicht auf einzelne Begriffe, sondern sie wird zum Problem gemacht zwischen den beiden Vermögen, die in Frage gekommen sind, zwischen Einbildungskraft und Verstand. Immer aber bleibt die Beurteilung für diese Subsumtion bestimmend; sie wird auf die Erwägung gerichtet: „sofern das erstere in seiner Freiheit mit dem letztern in seiner Gesetzmäßigkeit zusammenstimmt“. Der Subsumtion wird damit

<!-- pdf:132 S.102 -->

ein neuer Inhalt gegeben, und ebenso auch der Zweckmäßigkeit und dem freien Spiele.

So tritt ein viertes Moment für den Begriff des Gefühls ein: die Zusammenstimmung, als nähere Bestimmung der Zweckmäßigkeit.

Durch diese Zusammenstimmung aber wird das Gefühl von der intellektuellen Grundlage abgelenkt, und auf Lust und Unlust hin zur Ausweichung gebracht. Zweckmäßigkeit ist Sache der Beurteilung; Zusammenstimmung klingt an Lust und Unlust an. Damit resultiert auch erst das Spiel als freies Spiel. Diese Freiheit, wie diese Zusammenstimmung, resultiert in der Lust. Die Lust am Schönen ist weder eine Lust des Genusses, noch einer gesetzlichen Tätigkeit, auch nicht der voraufgehenden Kontemplation nach Ideen, sondern der bloßen Reflexion. Die Reflexion aber ist nur auf das Spiel der Vorstellungskräfte bezogen.

Der Satz lautet weiter: die Reflexion begleitet die Lust „durch ein Verfahren der Urteilskraft, welches sie auch zum Behuf der gemeinsten Erfahrung ausüben muß“. Wie bei dem Prinzip der allgemeinen Mitteilbarkeit, ist Kant auch hier bemüht, die begleitende Reflexion als ein allgemeines Verfahren der Urteilskraft zu beleuchten; dennoch aber wird die Spezialisierung dabei nur um so prägnanter. Hier geht dieses Verfahren nur darauf aus, „die Angemessenheit der Vorstellung zur harmonischen . . Beschäftigung beider Erkenntnisvermögen . . wahrzunehmen, d. i. seinen Vorstellungszustand mit Lust zu empfinden“. So wird die Lust selbst als das Verfahren der Urteilskraft bestimmt. Denn sie ist ja das Symptom der Zusammenstimmung, zu welcher die Zweckmäßigkeit sich präzisiert hat. Sie ist das Verfahren der Urteilskraft, jene Angemessenheit der Vorstellung zum harmonischen und deshalb freien Spiele der Erkenntnisvermögen zum Inhalt des Bewußtseins zu machen, diesen Inhalt zu erobern und in ihm eine neue Wurzelkraft des Bewußtseins festzugraben. Solche grundlegende Bedeutung hat die Zusammenstimmung.

Indessen die Zusammenstimmung hat ihr Widerspiel. Ihrer Zweckmäßigkeit gesellt sich eine Zweckwidrigkeit. So

<!-- pdf:133 S.103 -->

gesellt sich hier zum Schönen das Erhabene. Aber diese Koordination ist nicht allein die formale Folge von der Zweckmäßigkeit und der Zusammenstimmung. Die Einschränkung auf die Erkenntnisvermögen kann nicht ohne Bedenken bleiben.

Schon die Unterscheidung der Lust des Gefühls von der „vernünftelnden Kontemplation nach Ideen“ spielt hinüber auf das Gebiet des Sittlichen. So konnte es auch nicht ausbleiben, daß Kant nicht allein beim Erhabenen, sondern schon beim Schönen auf die Mitwirkung der sittlichen Erkenntnis Rücksicht nehmen mußte. „Nun sage ich: das Schöne ist das Symbol des Sittlichen, und nur in dieser Rücksicht gefällt es, mit einem Anspruch auf Jedermanns Beistimmung“. Nur in der sittlichen Rücksicht also soll dem Schönen der Wert einer apriorischen Geltung zustehen? Damit aber würde ja das ästhetische A priori in das ethische A priori aufgehoben. Und nur „Symbol“ soll das Schöne sein? Damit wird ihm ja aber der Eigenwert eines Inhalts entzogen, und somit der Eigenwert des ästhetischen Inhalts aufgehoben.

In diese verhängnisvolle Konsequenz wird Kant getrieben, indem er hinterher auf die Sittlichkeit diejenige Rücksicht zur Bestimmung des Schönen nehmen muß, die er bei der Grundlegung des Gefühls nicht genommen hatte. Das Schöne verschwindet, als eigener Gegenstand: es wird zum Symbol. Wovon auch immer, der Begriff des Symbols stellt einen Gegensatz auf zum Gegenstande in seinem Eigenwerte und seiner Selbständigkeit. Indessen das Sittliche forderte gewaltsam diesen Umsturz. Das Schöne wird zum Symbol des Sittlichen. „Das ist das Intelligible, worauf der Geschmack hinaussieht“. Bedenkt man, daß das Intelligible bei Kant gleichbedeutend ist mit dem Ding an sich, so wird jetzt das Schöne herabgedrückt zur Erscheinung und das Sittliche wird ihr Ding an sich.

Oder bedenkt man ferner, daß das Ding an sich gleichbedeutend ist mit der Idee, so droht hiernach dem Schönen ein Doppelwert, ein Doppelsinn. An und für sich ist es ein Einzelgegenstand der Erkenntnis, der Erfahrung, erst vom

<!-- pdf:134 S.104 -->

Sittlichen aus kann ihm der Wertbegriff der Idee zuwachsen. Wenngleich nun zwar die Idee mit dem Gegenstande und seiner Erkenntnis methodisch zusammenhängt, so wird dieser Zusammenhang gerade durch die Unterscheidung des Sittlichen vom Schönen durchbrochen. Das Schöne muß dahingegen ein vollwertiger Ausdruck seiner selbst sein.

Das Symbol wird in Kants Terminologie vom Schema unterschieden. Es bedeutet immer einen grundsätzlichen Mangel in der Anschauung und der Darstellung. Diese Insuffizienz wird aber unvermeidlich, da das Sittliche in der ästhetischen Darstellung zum Vorschein kommen muß, hier jedoch als ein fremdes Problem nachträglich hinzugezogen wird. Dieser Begriff des Symbols bleibt ein Verhängnis für die Ästhetik. Das Schöne muß vielmehr in selbständiger Darstellung der Inhalt des ästhetischen Problems werden.

Daß Kant die Unterscheidung von Schön und Erhaben angenommen hat, möchte auch hauptsächlich hierin seinen Grund haben. Erstlich zog die Zweckmäßigkeit die Zweckwidrigkeit nach sich, und die Zusammenstimmung den Widerspruch. Sodann aber wurde die Tragweite der Subjektivierung dadurch ausgedehnter. Es genügte nicht, das Werk des Genies von dem Einzelobjekt des Kunstwerks zu unterscheiden, und ebenso wenig die Subsumtion des ästhetischen Urteils von der unter einen bestimmten Begriff. Die Subjektivierung, welche für die Bestimmung des Gefühls sich als notwendig erwies, konnte erst durch das Erhabene zur erschöpfenden Ausführung kommen. Das Erhabene liegt überhaupt nicht im Objekt, sondern im Subjekt; daher auch nicht in der Natur, sondern allein im Menschen selbst.

Diese Verlegung des Erhabenen in den Menschen ist nur die Folge von der Rücksicht, zu welcher das Erhabene hinterher auf die Sittlichkeit nötigte. Indessen darf auch das Erhabene nicht anders in uns liegen als auch das Schöne, wenn anders beide Momente des ästhetischen Bewußtseins, des ästhetischen Gefühls sein sollen. So hat die Unterscheidung des Erhabenen vom Schönen, welche Kant rezipiert hat, zu einer Befestigung des Grundfehlers geführt, der in der

<!-- pdf:135 S.105 -->

nachträglichen Verbindung liegt, welche zwischen dem Ästhetischen und dem Ethischen herzustellen er sich gezwungen sah.

Wir müssen jedoch die Einwände gegen Kants Formulierung des ästhetischen Gefühls noch von anderer Seite, unserer systematischen Erwägung gemäß, in Betracht ziehen.

1. Das Gefühl wird bestimmt unter Einschränkung auf die Erkenntniskräfte, bei Ausschluß des Willens. Durch das Symbol kommt das Sittliche hinterher zur Mitberücksichtigung. Wir haben gesehen, daß das Symbol keine Korrektur zu bilden vermag, daß es vielmehr sogar die Beziehung auf die unerläßliche intellektuelle Grundlage abschwächt.

2. Dadurch kommt aber das Sittliche nicht nur hinterher, sondern nebenher, wie zutällig und sekundär zur Nachwirkung. Die Systematik des ästhetischen Gefühls erfordert dagegen, daß es als mitwirkende Bewußtseinskraft im Spiel des ästhetischen Bewußtseins von Anfang an und von Grund aus, wie bis zu seiner Vollendung hin, in Kraft tritt und bleibt. Das Gleichgewicht des ästhetischen Bewußtseins wird dadurch erst herstellbar. Das Gleichgewicht hat ja seinen systematischen Schwerpunkt, in dem allein es beruht und besteht.

Durch diese Mitwirkung des Willens bei der Entstehung des ästhetischen Gefühls wird nicht etwa dem intellektuellen Moment sein angemessener Spielraum entzogen oder eingeschränkt; denn das Urteil der Zweckmäßigkeit vollzieht sich ja ebenso im Willen, wie im Denken der Erkenntnis. Vielmehr wird dem reinen Willen durch seine Ausschließung hier auch sein intellektueller Mitwert gefährdet; und dies rächt sich für die Konstruktion des ästhetischen Gefühls. Denn da Wille und Sittlichkeit dem ästhetischen Gebiete doch nun einmal nicht entrückt werden können, so tritt die Moral von außen her in das freie Spiel der Kräfte ein. Diese Gefahr bildet für die Kunst, wie für das ästhetische Problem der Symbolismus, der den Schwerpunkt in die traditionellen Formen und Gedanken der Sittlichkeit, insbesondere in ihrer religiösen Spezialisierung, für die Kunst und ihre Aufnahme verlegt. So erlangt das Sittliche, anstatt auf ein Maß

<!-- pdf:136 S.106 -->

seiner Mitwirkung eingeschränkt zu werden, allmählich die unumschränkte Oberherrschaft.

3. Die ausschließliche Heranziehung der intellektuellen Bedingungen tut nicht einmal der Erkenntnis der Natur in ihrer Gesetzlichkeit Genüge, insofern diese intellektuellen Bedingungen an der Zweckmäßigkeit in Vollzug treten. Die Zweckmäßigkeit ist zwar das richtige Erkenntnisprinzip für die hier gesuchte Gesetzlichkeit. Aber sie muß sich auch auf den Willen erstrecken: innerhalb der Erkenntnisvorgänge allein kann sie die Wirksamkeit des ästhetischen Gefühls nicht zur Folge haben. Die logische Zweckmäßigkeit ist zwar die Voraussetzung für die Erkenntnis der Natur in ihrer biologischen Morphologie. Aber diese Natur ist ja noch lange nicht die ästhetische Natur, die Natur als Kunst. Und auch für diese muß die intellektuelle Bedeutung der Zweckmäßigkeit in Kraft treten; auf diesen Zweck hin muß sie ihre Mitwirkung richten.

4. Die Zweckmäßigkeit der Erkenntnisbedingungen geht von der Rezeptivität des ästhetischen Gefühls aus; nicht von seiner Produktivität. Die Ästhetik soll zwar auch dieses zur Erklärung bringen, aber keineswegs von ihm ausgehen. Das Hauptproblem bildet das Kunstschaffen selbst, dessen Nacherzeugung erst das richtige Kunsterleben wird. Für den Künstler kann es nun aber nicht genügen, diese subjektive Zweckmäßigkeit der Harmonie seiner Erkenntniskräfte zu gewahren, und in ihr den Urquell seiner Produktivität zu erkennen. Mit dieser Zweckmäßigkeit in seinem intellektuellen Verhalten allein kann er nicht glauben, das Problem der Natur zu bewältigen, nicht einmal insofern sie in ihrer theoretischen Gesetzlichkeit, als Vorbedingung des Kunstschaffens, zu gelten hat. Dafür müssen vielmehr die positiven Erkenntnisbedingungen selbst in ihren methodischen Werten zu Erfüllung kommen; das Prinzip der Zweckmäßigkeit kann dieser Voraufgabe der Kunst nicht Genüge leisten. Daher kann auch diese subjektive Zweckmäßigkeit, als Gefühl, nicht produktiv werden; nicht zur Produktion befähigen. Und so wird damit auch die ästhetische Reproduktion nicht hinreichend erklärt und begründet.

<!-- pdf:137 S.107 -->

So läßt es sich verstehen, daß diesem Teleologismus des subjektiven Gefühls gegenüber der sogenannte Verismus auftritt, der in jenem den Idealismus der klassischen Ästhetik bekämpfen zu müssen glaubt. In seiner These liegt die Behauptung, daß durch jene subjektive Methodik, wenngleich sie auf die intellektuellen Tätigkeiten des Bewußtseins eingeschränkt wird, dennoch dem Gegenstande der Erkenntnis der Natur, als dem fundamentalsten Vorwurf der Kunst, nicht die sachgemäße Zurüstung geleistet wird.

In der Tat unterscheidet Kant ja das Ideal von der Normalidee. Und den Kanon des Polyklet setzt er herab gegen das Ideal. Also der Kanon, insofern er gleichsam der Inbegriff der Erkenntnisbedingungen ist, stellt nur eine Vorstufe dar, nur Vorbedingungen des Ästhetischen. Das Ideal erst bringt die Vollendung. Aber auf Grund welcher Zweckmäßigkeit? Entbehrt etwa die Normalidee überhaupt jener Zweckmäßigkeit der intellektuellen Kräfte?

Auch in der Natur unterscheidet Kant das Interesse an ihren Formen von dem intellektuellen Interesse, welches sie erweckt. Dieses intellektuelle Interesse müßte nun eigentlich in jener intellektuellen Zweckmäßigkeit zur Befriedigung kommen. Es findet sich aber in den Stellen in der Kritik der Urteilskraft, welche besonders durch Schillers Anknüpfung an sie bekannt geworden sind, die merkwürdige Konsequenz, daß dieses intellektuelle Interesse als dem moralischen verwandt bezeichnet wird. Also ist es nicht eigentlich ein intellektuelles. Und so wird auch hier die Moral hinterher herangezogen.

Wir sehen jetzt davon ab, daß durch diesen Rekurs des intellektuellen auf das moralische Interesse die Selbständigkeit des ästhetischen Gefühls immer mehr zurückgeschoben, und seine Begründung in der Zweckmäßigkeit der intellektuellen Kräfte in Frage gestellt, oder geradezu aufgegeben wird. Wir beachten jetzt nur die hier vorliegende Gefahr für die Erkenntnis der Natur, als unerläßliche Vorbedingung für alle Kunst. Sie wird herbeigeführt durch die Herabsetzung der Normalidee gegen das Ideal, während die Normalidee

<!-- pdf:138 S.108 -->

als unerläßliche Vorbedingung des Ideals selbst in vollen Ehren gehalten werden müßte.

Kant steigert diese Geringschätzung der Normalidee in dem Urteil seiner Ironie: man hätte ebenso, wie den Doryphoros des Polyklet, auch die Kuh Myrons zum Kanon machen können. Das Ideal dagegen besteht im Ausdruck des Sittlichen. Wir gehen hier nicht darauf ein, daß die Kunst auch in der Darstellung der Kuh vielleicht nicht gänzlich dem Problem des Sittlichen entrückt sei, wie sie demselben nach der systematischen Grundforderung sich niemals entziehen kann. Vielleicht enthält auch das Tier Ahnungen des Sittlichen für die Kunst. Wir beachten an dieser Ironie nur die Verschärfung des Unterschiedes zwischen Normalidee und Ideal. So wird im Kanon der Kuh die Gesetzlichkeit der Natur vom Ideal ausgeschlossen, weil das Ideal allein Ausdruck desjenigen Inhalts sei, der doch bisher von der intellektuellen Zweckmäßigkeit gänzlich unberücksichtigt blieb. In dieser der systematischen Methodik nicht angemessenen Scheidung von Normalidee und Ideal rächt sich die Ausschaltung des Willens aus der Zweckmäßigkeit des ästhetischen Bewußtseins.

5. Dieses Ideal ist nicht das Ideal der Linie Winckelmanns. Das Ideal der Linie ist das Ideal der Natur; das Ideal für die methodische Erzeugung der Natur in der Linie, als Vorbedingung der ästhetischen Erzeugung der Natur im Kunstwerk. Daher darf das Ideal der Gesetzlichkeit der Natur nicht entfremdet, nicht ihr entgegengestellt werden, so daß es seine Höhe einem andern Begriffe allein zu verdanken hätte. Die Natur in ihrer reinen Gesetzlichkeit darf nicht jenem auf der Sittlichkeit gegründeten Ideal gegenüber zur Norm und zum Kanon erniedrigt werden. Der Kanon darf nicht der Sittlichkeit beraubt; das Ideal nicht der Natur entäußert werden.

Auch hier ist die Konsequenz von Kant nicht vermieden. Er spricht es aus, daß das Ideal „niemals rein ästhetisch sein könne“. Damit ist jedoch der ganze Begriff des Ideals, mit dessen methodischer Begründung Winckelmann die Entstehung des ästhetischen Problems herbeigeführt hatte, für

<!-- pdf:139 S.109 -->

die Ästhetik aufgegeben. Nur wenn das Ideal „rein ästhetisch“ sein kann, nur unter dieser Bedingung kann es als reiner Inhalt des ästhetischen Bewußtseins zulässig sein. Als ein Mischbegriff wird es für die Reinheit des ästhetischen Gefühls unbrauchbar. Das Sittliche, welches aus der intellektuellen Bestimmung des Gefühls ausgeschlossen wurde, bringt jetzt in diesem lediglich im Sittlichen begründeten Ideal das ganze Problem ins Wanken. Die intellektuellen Bedingungen, auf die allein in der ursprünglichen Disposition Rücksicht genommen wurde, werden nun nachträglich in diesem sittlichen Idealbegriffe vernachlässigt und verleugnet. Und so entsteht der Verdacht gegen diesen Idealismus, als Symbolismus, gegen den sich der Verismus zur Wehr setzt.

6. Aber auch das Sittliche selbst wird durch das Ideal, als Ausdruck des Sittlichen, nicht hinlänglich als Vorbedingung anerkannt, noch als Inhalt bestimmt. Der Ausdruck wird ja später zum Symbol. Das Symbol aber ist kein sich in der Darstellung erschöpfender Ausdruck, sondern nur ein andeutender, auszudeutender. Der Ausdruck wird durch das Symbol sonach verengt und beschränkt. Damit aber wird das Sittliche verkürzt und verschränkt. Polyklet soll in seinem Kanon keinen Anteil an diesem Ausdruck haben; denn der Kanon ist nicht das Ideal. Aber das Ideal selbst ist ja nur Symbol, also nicht voller, adäquater Ausdruck. Wir haben die von Kant selbst gezogene Konsequenz schon beachtet, daß das Ideal „niemals rein ästhetisch sein könne“. Damals schien dieser Ausspruch durch die nachträgliche Bevorzugung des Sittlichen vor der Erkenntnis begründet. Jetzt aber wird im Sittlichen selbst die Gefahr erkennbar. Der nur andeutende Ausdruck ist nicht Ausdruck. Die Kunst kann nur den Ausdruck als ihr reines Erzeugnis bezwecken.

Der Widerspruch im Begriffe des Ideals läßt sich auch in anderer Betrachtung erkennen. Die menschliche Gestalt soll nach Kant allein des Ideals fähig sein. Im Kanon des Polyklet ist ja aber die menschliche Gestalt zur Darstellung gekommen. Und doch soll der Kanon kein Ideal sein. So kann denn das Ideal nicht ein reines, aus-

<!-- pdf:140 S.110 -->

schließliches Erzeugnis der Kunst sein. Womöglich hat erst der Beschauer das Ideal in das Kunstwerk hineinzulegen, also er selbst erst kraft seiner Sittlichkeit das Ideal zu erzeugen. Eine solche Konsequenz schimmert durch den Satz hindurch, daß das Ideal gar nicht rein ästhetisch sei. So wird im Ideal nicht allein die Erkenntnis der Natur, sondern nicht minder auch das Sittliche und sein Quell und Inhalt, der Mensch, in ein falsches Licht und auf eine schiefe Grundlinie gebracht.

An diesem Punkte scheint eine bekannte Einseitigkeit Winckelmanns Kant ungünstig beeinflußt zu haben. Winckelmann hatte das Charakteristische des Ausdrucks von der hohen Kunst ausgeschlossen. Ihm erzeugt die Linie nicht nur methodisch und erkenntnismäßig das Ideal, sondern in der Linie sieht er auch das Bild der Ruhe und den Zug der Hoheit. So wird die Linie ihm zugleich zum methodischen Element des Sittlichen; das Charakteristische aber entfernt sich von dem Grundmaß der Linie; sein Übermaß wird daher zu einem Mißgriff am Sittlichen.

Dieser Paradoxie wollte Kant vielleicht entgegenwirken, indem er durchaus und schlechthin das Ideal zum Ausdruck des Sittlichen machte. Aber wie der Verismus gegen die theoretischen Übergriffe und gegen die Zweckmäßigkeitsformel sich erhob, so wird der Impressionismus verständlich gegenüber diesem Symbolismus des Sittlichen. Das Sittliche selbst ist ein so schwieriges Problem, und alle seine Gestaltungen in Religion und Recht und Staat bilden allenthalben die gefährlichsten Fragezeichen der Kultur: wie sollte der Künstler da für seine Aufgaben und seine Gegenstände sich zurechtfinden können, wenn er von jenem so fragwürdigen Sittlichen immerfort Symbole schaffen soll. Solcher Zweideutigkeit gegenüber wird die Parole verständlich: l’art pour l’art.

7. Bedenken wir, daß mit allen diesen Bestimmungen Ein Problem zur Entfaltung kommen soll: die Eigenart des ästhetischen Bewußtseins, als Gefühl. Das Gefühl soll zwar nicht lediglich Lust und Unlust bleiben; denn es soll vielmehr das Spiel aller Erkenntnisvermögen werden. Sein Bestand

<!-- pdf:141 S.111 -->

wird ihm gegeben in dem teleologischen Urteil der Harmonie der Erkenntniskräfte. Die Harmonie ist das einzig Vitale dabei; sie ist der Rest, der von Lust und Unlust übrig geblieben ist. Die Harmonie vollzieht sich aber nur innerhalb des Intellektuellen, nicht zugleich am Willen. Daher verlautet dieses Gefühl mehr als Beifall, denn als Wohlgefallen. Seine intellektuelle Grundlage bleibt in ungeschwächter Nachwirkung.

Indessen genügt für das ästhetische Gefühl nicht einmal das bloße Wohlgefallen: woher sollen die Erschütterungen ableitbar werden, welche die Energie des ästhetischen Bewußtseins erfüllen? Und woraus sollen die Entzückungen quellen, in denen der ästhetische Jubel seine Triumphe begeht? Kann die teleologische Urteilslust der Zweckmäßigkeit als hinlänglicher Urquell gedacht werden für jene unbeschreibliche Mannigfaltigkeit der Erhebungen, welche das ästhetische Gefühl auszeichnet? Auch die Harmonie ist nicht ausreichend. Auch die Disharmonie kann das Fundament nicht breiter machen. Die Harmonie muß vielstimmiger werden, wenn sie das Gefühl als Eigenart des ästhetischen Bewußtseins soll bestimmen können.

8. Der Gegensatz von Harmonie und Disharmonie hat auch die Rezeption des Erhabenen neben dem Schönen begünstigt. Und alle die Momente, welche wir bisher bei der nachträglichen Heranziehung des Sittlichen beachtet haben, kommen ganz besonders nachdrücklich beim Erhabenen zur Geltung. Und hinwiederum soll das Erhabene, wie das Schöne, nur als Inhalt des ästhetischen Gefühls in Betracht kommen.

Hier macht sich nun aber die Qualifikation des Gefühls im Widerspiel von Lust und Unlust spürbar, und zwar nach der Seite der Unlust. Es muß die Frage entstehen, ob es ein methodisch richtiger Weg ist, der Unlust, der Disharmonie, ein solches Eigengewicht, einen solchen Ausschlag einzuräumen im ästhetischen Gefühle. Die Bestimmung kommt beim Erhabenen von dem intellektuellen Verhältnis her, das in ihm sich bildet. Darin liegt ein Erklärungsgrund, aber keine sachliche Rechtfertigung. Und wenn nun vollends

<!-- pdf:142 S.112 -->

im Erhabenen nichtsdestoweniger das Sittliche mit seiner ganzen bisher verhaltenen Macht hereinbricht, und als Disharmonie zu seiner gewaltigen Wirkung kommt, so erhebt sich von hier aus wieder die Frage gegen das hier angewandte Prinzip der Zweckmäßigkeit, ob es in seinem Widerpart die Probe besteht für seine methodische Richtigkeit. Ist etwa das ästhetische Gefühl ebenso sehr bewährt durch die Zerrissenheit, die es über das menschliche Bewußtsein bringt, wie durch die Harmonie und die Ebenmäßigkeit und den friedlichen Einklang seines Verhaltens?

Und die Frage geht von der Zweckmäßigkeit hinüber nach der Unterscheidung und Trennung des Schönen und Erhabenen überhaupt: ob sie für die Entdeckung und Begründung des ästhetischen Gefühls angemessen und einwandfrei sei; ob die Relativität, welche dadurch gemäß derjenigen in Lust und Unlust, dem ästhetischen Gefühle überhaupt zuerteilt wird, als eine methodisch richtige Grundlage für die Inhalte des Gefühls und somit für den Begriff des Gefühls selbst sich bewähre. So führt die Begründung des Gefühls auf das Urteil der Zweckmäßigkeit auch zur Frage gegen die Unterscheidung von Schön und Erhaben.

9. Das Bedenken gegen die Zweckmäßigkeit verstärkt sich noch tiefer gegen seine Zulässigkeit. Wir haben die intellektuelle Zweideutigkeit, die in ihm steckt, schon mehrfach erwogen. Ein intellektuelles Urteil scheint doch immer jene teleologische Beurteilung zu bleiben. Sie soll das Gefühl vollziehen. Sie soll durchaus nicht Erkenntnis sein, noch solche erzeugen. Es sei zugegeben, daß in diesem Spiel der Zweckmäßigkeit das theoretische Bewußtsein sich in Gefühl verwandle.

Jetzt aber entsteht die neue schwere Frage: kann dieses Gefühl, welches sonach als das Geschöpf einer Verwandlung erkennbar wird, einer Verwandlung, welche das Bewußtsein nicht sowohl an seinen Inhalten, als vielmehr an seinen Tätigkeitsweisen selbst vollzieht, kann das Werk einer solchen Verwandlung gleichbedeutend sein mit der reinen Erzeugung, welche doch das ästhetische Gefühl, seiner

<!-- pdf:143 S.113 -->

systematischen Bestimmung gemäß, zu bedeuten hat? Lassen wir selbst den Unterschied zwischen dem Werk der Verwandlung und der Erzeugung fallen, so bleibt doch der Widerspruch zwischen der Verwandlung und der reinen Erzeugung bestehen.

Man könnte einwenden, die Verwandlung sei selbst vielleicht reine Erzeugung. Denn sie muß doch bewirkt werden, und vielleicht sei diese Erwirkung die reine Erzeugung. Indessen ist der Gesichtspunkt der Zweckmäßigkeit hiergegen ein Hemmnis. In der Beurteilung der Zweckmäßigkeit liegt die reine Erzeugung, sie ist der Faktor der Verwandlung. Somit ergibt sich erstlich die reine Erzeugung doch nur als ein intellektueller Akt. Aber dies sei nicht weiter urgiert. Dagegen ist eine andere Konsequenz jetzt zu erwägen.

Die teleologische Beurteilung, welche die Verwandlung ins Gefühl, mithin die Erzeugung des reinen Gefühls bewirken soll, macht notwendigerweise dieses zu einer Nachwirkung, zu einem Nachklang. Das dürfte unvermeidlich sein bei dem teleologischen Gesichtspunkt. Er bezieht bei günstigster Deutung das neue Gefühl auf das Spiel der Erkenntnisvermögen, und auf die sich dabei für das Bewußtsein einstellende Zweckmäßigkeit der Harmonie. Man mag diesem neuen Bewußtsein noch so sehr eine aktive Potenz zuerteilen, dennoch erscheint sie nur als eine Resultante jener sich kreuzenden Bewegungen. Die Harmonie erscheint als Resonanz. Diese Identität jedoch widerspricht der ästhetischen Bedeutung der Harmonie, und wenn sie noch so sehr ihrer lediglich physikalischen Bedeutung entsprechen möchte. So wird der neue Einwand vielleicht gerade durch dieses Gleichnis besonders deutlich.

Die Zweckmäßigkeit hebt den schöpferischen Charakter der Aktivität, der für das neue Bewußtsein gefordert wird, nicht prägnant hervor. Die Aktivität allein genügt nicht; die Neuheit und Eigenart wird durch die schöpferische Aktivität bedingt. Diese aber ist nicht in der Zweckmäßigkeit gesichert. Daher wird sie, und die Verwandlung in ihr der reinen Erzeugung nicht gerecht.

<!-- pdf:144 S.114 -->

Auch hier können wir den Grund des Mangels darauf zurückführen, daß Kant, obwohl er die Kunst als die des Genies begreift, dennoch in der Begründung vorwiegend von der ästhetischen Rezeptivität ausgeht, und nicht von der schöpferischen Aktivität des Künstlers. Das ist der Schatten bei dem Licht der neuen Lehre, daß die Kunst die Kunst des Genies sei. Die systematische Bedingung der Methodik der reinen Erzeugung tritt daher zurück, während doch die neue Art des A priori zur Entdeckung kommen soll. Das Distanzgefühl von der Pedanterie, die das Wunder des Kunstwerks restlos erklären zu können meint, hat die Grenzen der reinen Erzeugung zu eng ziehen lassen. Freilich muß der Künstler selbst bei seiner Arbeit immer wieder auch prüfender Beschauer sein. Dennoch läßt sich aus dem Standort des Genießenden die volle Reinheit des Erzeugens nicht gewinnen.

Noch bei einer andern Unterscheidung von epochemachender Wichtigkeit ist ein Nachteil in dieser Hinsicht entstanden: bei der entscheidenden, lichtbringenden Charakteristik des ästhetischen A priori, als einer subjektiven Gesetzlichkeit. Es gibt kein objektives Gesetz des Geschmacks. Dieser grundlegende Gedanke ist daraus erwachsen. So erst konnte der die neue Bewußtseinsart suchende Gedanke auf das Gefühl hingelenkt werden. Aber diese den Boden der Ästhetik urbar machende Bestimmung setzt dennoch den methodischen Charakter dieses A priori in Gefahr. Diese Subjektivität mag allenfalls passend sein für ein teleologisches Harmoniegefühl: ist sie damit aber auch der methodischen Apriorität überhaupt gewachsen? Genügt auch nur die Apriorität des teleologischen Urteils für die Apriorität der geforderten neuen Bewußtseinsart? Das teleologische Urteil ist bekanntlich keine neue Bewußtseinsart, sondern es schließt sich dem Urteil der Erkenntnis an, und macht sich ihm zugehörig. Immerhin macht sich sogar in diesem Zusammenhange eine Unterscheidung in der Qualität des apriorischen Urteils erforderlich: die zwischen dem konstitutiven und dem regulativen Grundsatz. Hier jedoch soll es sich überhaupt nicht mehr um Er-

<!-- pdf:145 S.115 -->

kenntnis, sondern um etwas ganz Neues handeln. Diese Neuheit beruht auf der Eigenart, welche allein durch eine der strengen Methodik gemäße reine Erzeugung möglich wird.

10. Hier sehen wir endlich auch den Nachteil wieder, der in der Bestimmung des Gefühls als Lust und Unlust liegt. Der ästhetische Genuß mag allenfalls auf diesem Wege erklärbar werden; die produktive Eigenart der künstlerischen Schöpfung kann dadurch nicht der methodischen Bedingung der reinen Erzeugung gemäß faßbar werden. Man müßte denn den Schwerpunkt in die Unlust verlegen wollen, die als Unruhe immerhin ein treibendes Moment in ihm sein könnte; ein treibendes, aber auch ein schöpferisches?

Die Lust dagegen kann doch wohl immer nur eine Nachwirkung sein. Oder höchstens könnte sie bei ihrer Verwachsenheit mit der Unlust ein Vorstadium des künstlerischen Bewußtseins bezeichnen, etwa wie Schiller eine musikalische Stimmung als seine Disposition zur poetischen Arbeit an sich erprobt haben wollte. Diese Disposition ist aber noch lange nicht mit der reinen Erzeugung gleichzusetzen, wenn selbst sie als Vorbedingung für jene allgemein gelten dürfte. Der Begriff der reinen Erzeugung muß der ganzen Strenge und Sicherheit der apriorischen Methodik gemäß zur Entdeckung und zur Bestimmung gebracht werden. Lust und Unlust, als Harmoniegefühl der Zweckmäßigkeit, sind dieser Genauigkeit nicht gewachsen. Der Begriff des reinen Gefühls muß die neue Art von Reinheit, als die neue Art eines schöpferischen Bewußtseins, zur Erzeugung bringen.

Die Strenge der Methodik ist begründet und wird erfüllbar durch die systematische Bedeutung dieser Methodik. Wie die Kunst eine Eigenart der Kultur darstellt, nicht eine Abart der Erkenntnis, noch auch der sittlichen Kultur, so muß auch eine wahrhafte Eigenart des ästhetischen Bewußtseins für sie gefordert werden; und nur in solcher Entdeckung kann die neue Art der reinen Erzeugung wirksam werden. Das Gefühl ist der Wegweiser in das neue Land. Aber weder Lust und Unlust, noch die Totalität der

<!-- pdf:146 S.116 -->

Erkenntnisvermögen, noch die teleologische Beurteilung des freien Spiels derselben sind sichere, vor jeder Irreführung geschützte Etappen auf dem Entdeckungswege in das neue Land. Wir müssen andere Schritte versuchen, um dahin zu gelangen; immer aber vom richtigen Wegweiser des Gefühls geleitet, wenngleich nicht schlechthin des Gefühls von Lust und Unlust, noch auch des Lebensgefühls. Welcher Art kann nun das neue Gefühl sein, als reines Gefühl, als reines ästhetisches Bewußtsein?

Nicht also das Gefühl allein darf uns der Wegweiser sein, sondern das reine Gefühl, das Gefühl der reinen Erzeugung des eigenen Inhalts, den die Kunst zum Problem der systematischen Philosophie macht.

<!-- pdf:147 S.117 -->

# Drittes Kapitel. Die Gesetzlichkeit des reinen Gefühls

Wenn das Gefühl, als eine neue Art des Bewußtseins, geltend gemacht wird, so wird unverkennbar freilich damit der Zusammenhang mit Lust und Unlust festgehalten; und dies scheint einen unausgleichbaren Widerspruch zur Reinheit des Gefühls zu bilden.

## 1. Lust und Unlust

Lust und Unlust dürfen daher nicht schlechthin gleichzusetzen sein mit dem Gefühl. Sie dürfen die Eigenart des Gefühls nicht bestimmen. Sie dürfen den Inhalt des reinen Gefühls nicht bilden.

1. Lust und Unlust sind in der Erkenntnis und im Willen enthalten. Jede Tätigkeit in allen Richtungen des Bewußtseins wird von Lust und Unlust begleitet. Sie wirken schon mit in den Bewegungen des Instinkts, im Geschlechtstrieb, und ebenso auch schon qualifiziert im Rhythmus der Arbeit. Sie könnten daher nur als universelle Faktoren des Bewußtseins auch für das ästhetische angesprochen werden.

Es ist aus dem Gesichtspunkte der Universalität auch zu beachten, daß diese von Lust und Unlust getriebenen Instinkte auch schon in den primitivsten Formen des ästhetischen Bewußtseins zur Mitwirkung kommen. In ihnen entsteht der Tanz, das Singen, die Musik überhaupt, wie andererseits auch die primitivste Plastik der menschlichen Körperformen und der menschlichen Gestalt, wie auch der tierischen überhaupt. Der Zusammenhang von Lust und Unlust mit dem ästhetischen Gefühle wird durch die Instinktbewegungen also nur noch inniger vermittelt. Aber

<!-- pdf:148 S.118 -->

durch diesen innigern Zusammenhang wird die Reinheit des ästhetischen Gefühls noch mehr in Frage gestellt.

Auch beim Willen, nicht nur bei der Begierde, sind Lust und Unlust im Willensmomente des Affektes mitgegeben: in Heiterkeit und Traurigkeit, in Rührung und Aufregung und Empörung. Diese Affektmomente von Lust und Unlust können daher nicht Zeugen des ästhetischen Bewußtseins sein; sie können nicht seine Erzeuger sein, wenngleich unbestritten bleibt, daß sie im ästhetischen Bewußtsein mitwirken. Welcher Art diese Mitwirkung sei, das ist die Frage. Und diese Frage kann erst aus dem Begriffe des reinen Gefühls zur Lösung kommen. Sie kann aber nicht lösbar werden, wenn die Elemente, deren Art der Mitwirkung problematisch ist, anstatt als in dem Problem des reinen Gefühls enthalten, von vornherein als die unzweifelhaften Grundelemente des Gefühls betrachtet werden, auf denen seine Eigenart beruhe.

Auch für diese Frage muß die Orientierung der Grundfrage entnommen werden: in welchem Verhältnis stehen Lust und Unlust zur Reinheit des ästhetischen Bewußtseins? Ist ihre Wirksamkeit im ästhetischen Bewußtsein als reine Erzeugung bestimmbar? Sie dürfen nicht an sich selber Inhalt zu bedeuten haben. Als solcher könnten sie keine Eigenart feststellen. Ihr positiver Eigenwert ist abhängig zu machen von ihrem methodischen Werte: reiner Erzeugung dienstbar zu werden.

2. Lust und Unlust sind als Bestimmungen eines Inhalts schlechthin fallen zu lassen.

Sie bilden keinen begrifflichen Inhalt, keinen wissenschaftlich zu bestimmenden, daher auch keinen wissenschaftlich zu gebrauchenden Inhalt. Es könnte der Anschein entstehen, als ob die soeben angegebene Spezialisierung der Affekte, wie Heiterkeit und Traurigkeit, solchen Inhalt in Lust und Unlust zur Bestimmung brächten. Indessen sie ersetzen vielmehr nur den Mangel einer Inhaltsbestimmung in Lust und Unlust. Eine bestimmte Abgrenzung ist weder bei der Heiterkeit, noch bei der Traurigkeit durchzuführen; sie können daher den Mangel an Inhalt auch

<!-- pdf:149 S.119 -->

nicht eigentlich ersetzen; sie sind nur Versuche dazu. Und auch diese Versuche können nur das subjektive Verhalten des Bewußtseins beschreiben, nicht aber das Verhältnis zu einem Inhalt.

Sie sind daher, wie Lust und Unlust überhaupt, als Hemmnisse der Gesetzlichkeit, und insbesondere der ästhetischen, in Verdacht zu nehmen. Lust und Unlust gehören nun einmal dem Gebiete der elementaren Organempfindungen und der Gemeinempfindungen an. Sie stehen mindestens im Gegensatze zu der methodischen Reinheit. Aber für das ästhetische Bewußtsein enthalten sie noch eine besondere Gefahr in sich.

Sie scheinen nämlich die Ansicht zu bestätigen, daß das ästhetische Bewußtsein gar nicht als eine neue, eigene Art zu suchen sei, sondern daß es eine homogene Fortsetzung des allgemeinen Bewußtseins sei. Darin liegt freilich schon eine Zweideutigkeit. Das allgemeine Bewußtsein ist ja bisher schon zwiefach. Von welchem seiner beiden Teile soll nun die neue Art die gleichartige Fortsetzung sein, von der Erkenntnis oder vom Willen? Oder aber etwa von beiden? Dann muß aber die Gleichartigkeit aufhören, da doch die Ausgangslinien schon ungleichartig sind. Schon aus dieser Betrachtung allein ergibt sich als unausweichbare Folgerung, daß das ästhetische Bewußtsein von neuer eigener Art sein muß. Lust und Unlust aber lenken von dieser eigenen Spur ab.

Was für ihre Annahme spricht, die ihnen beiwohnende Urkraft, Impulsivität und Unmittelbarkeit, das hält nicht Stand vor der Bedingung der Reinheit. Und wenn wir die terminologische Bedingung an der Aufgabe der Kunst, nicht allein an der Schöpfung, sondern auch an der Gestaltung und Durchführung uns anschaulich machen: können Lust und Unlust als sachliche Mittel gelten, die Bestimmtheit und Deutlichkeit des Inhalts zu erzeugen, welche die Wahrzeichen der echten Kunst sind? Es ist nicht einmal nur die Deutlichkeit, welche die Unterscheidung von anderen Kunstwerken möglich macht, welche daher erst die Isolierung des Kunstwerks ermöglicht, so daß es eine selbständige Welt für sich zu bilden scheint, durch Lust und

<!-- pdf:150 S.120 -->

Unlust herstellbar. Auch die Klarheit würde so unmöglich werden, die andere Bedingung zur Selbständigkeit des Kunstwerks. Sie beruht auf der Durchsichtigkeit aller Teile und Momente, die das Ganze, nach der Terminologie unserer Logik wäre zu sagen, die die Allheit des Kunstwerks bilden.

Diese Durchsichtigkeit kann nicht der Abklatsch von Lust und Unlust sein. Sie bedarf der Gliederung, und diese wieder kann nur in der reinen Erzeugung sich vollziehen. Lust und Unlust können die Selbständigkeit des ästhetischen Bewußtseins nicht erzeugen, daher auch nicht den Inhalt eines solchen nach der Fülle seiner Qualitäten. Sie sind selbst kein Inhalt; wie sollten sie bei der Erzeugung eines solchen, auch nur vermittelnd, mitwirken können? Sie sind Ausdrücke für ein Etwas, das einen Gegensatz zum Inhalt bildet. Worauf beruht dies? Was ist dieses Etwas?

3. Lust und Unlust sind Ausdrücke für die Frage der Bewußtheit.

Die Logik der reinen Erkenntnis hat Bewußtsein und Bewußtheit unterschieden. Und die Ethik des reinen Willens hat diese Unterscheidung weitergeführt. Die Bewußtheit ist das Rätsel, mit dessen Aufstellung die theoretische Kultur beginnt. Der Mythos ist noch im Wunder des Bewußtseins befangen. Daher beseelt und begeistet er die Bäume und die Flüsse, wie die Tiere. Mit dem Beginn der theoretischen Kultur wird das Wunder in ein Rätsel verwandelt. Der spekulierende Mensch, und er ist der denkende, gibt sich das Rätsel des Bewußtseins, vielmehr der Bewußtheit auf. Ihm genügt der Monismus nicht: überall ist Seele. Er stellt sich die Frage nach der Möglichkeit, nach der Begreiflichkeit dieser allgemeinen Seele.

Und indem er diese Frage sich stellt, macht er aus dem Wunder das Rätsel, aus dem Mythos die theoretische Kultur — aus der Bewußtheit das Bewußtsein.

Das Wunder wird dadurch nicht erklärbar. Das Wunder ist überhaupt nicht erklärbar. Seine Annahme widerstreitet und widerspricht der Erklärung. Das Wunder

<!-- pdf:151 S.121 -->

will selbst Erklärung sein, weil die richtige Erklärung ihm nimmermehr als rechte einleuchtet. Das Rätsel dagegen setzt die Möglichkeit einer Erklärung, einer Auflösung voraus; und in dieser Selbstaufhebung des Rätsels allein erwartet es die Lösung. Dadurch ist dieses vom Wunder sich ablösende Bewußtsein genötigt, die Frage gänzlich von der Bewußtheit abzulenken: auf welchen Punkt hin aber kann sie sonst gerichtet werden?

Hier wird der Unterschied zwischen Bewußtheit und Bewußtsein einleuchtend: der Inhalt vollzieht ihn. Die Bewußtheit ist kein Inhalt; sie bezeichnet nur die Tatsache, daß es ein Bewußtsein gebe. Diese Tatsache bezeichnet aber noch nicht den Inhalt des Bewußtseins. Sie bezeichnet eben nur das unerklärbare Wunder. Wenn nun das Wunder zum Rätsel werden soll, so richtet sich die Frage auf den Inhalt des Bewußtseins. Sie macht sich los von dem Anstaunen der Tatsache, daß die Seele die Dinge der Wahrnehmung belebe; die Dinge der Wahrnehmung selbst treten als Problem hervor: und daß Bewußtsein in ihnen sich abspiele, diese Tatsache tritt dagegen zurück. Es ist mithin der Inhalt, der das Bewußtsein von der Bewußtheit unterscheidet.

Lust und Unlust mögen ein Gehalt des Bewußtseins sein, insofern sie eine Macht in ihm bilden und eine Energie, die bis zur Vernichtung sich steigern kann: darum aber sind sie noch nicht Inhalt. Der Inhalt entsteht erst durch die Dinge der Wahrnehmung, mithin durch die Projektion des Bewußtseins nach einer Außenwelt. Lust und Unlust bezeichnen immer nur ein Verharren des Bewußtseins in seiner eigenen Immanenz und Reflexibilität, die noch keineswegs ein Inneres zu erzeugen vermögen; geschweige denn ein Äußeres.

Lust und Unlust, wir werden es noch genauer zu zeigen haben, mögen eine Voraussetzung für die Inhaltsbildung des Bewußtseins sein; das Bewußtsein selbst ist dadurch bedingt, daß von jener Voraussetzung ein Inhalt sich ablöst. Die Bewußtheit besagt: ein Bewußtsein findet statt. Das Bewußtsein bedeutet: aus der Bewußtheit tritt ein Inhalt hervor. Ein

<!-- pdf:152 S.122 -->

solcher Inhalt wird nicht durch Lust und Unlust erzeugt, die vielmehr nur das Stattfinden des Bewußtseins bezeichnen.

Daher können Lust und Unlust nicht dem reinen Gefühle gleichgesetzt werden. Die Reinheit fordert allgemein die Erzeugung eines Inhalts. Und das ästhetische Gefühl ist die Erzeugung des ästhetischen Inhalts. Lust und Unlust können nur in der verworrensten Illusion als ein Inhalt des ästhetischen Bewußtseins gelten. Was sie dabei mitzubedeuten haben, bleibe hier außer Betracht. Nur den eigentlichen, den reinen Inhalt können sie in ihm nicht erzeugen, und nicht zu bedeuten haben.

Die Meinung, daß sie ein integrierender ästhetischer Faktor wären, beruht schließlich auf der Meinung, daß im ästhetischen Verhalten, wie im Schaffen, im letzten Grunde doch alles nur auf die Naturgewalt der Kunst, auf die unbegreifliche Willkür und Macht des Genius ankomme. So wird Lust und Unlust zum Analogon des Wunders; die ästhetische Kultur erscheint als Mythos der Bewußtheit. Das Interesse am Inhalt tritt zurück gegen das Wunder, nicht sowohl in seiner Erzeugung, als vielmehr in der Tatsache seines Stattfindens.

4. Als Urlaute der Bewußtheit bilden Lust und Unlust Urelemente des Bewußtseins. Wir werden dies später genauer zu erörtern haben. Hier soll nur dem störenden Einwurf begegnet werden, als ob Lust und Unlust, weil sie des Inhaltswertes ermangeln, aus dem Inhalt des Bewußtseins auszutilgen wären. Diese Folgerung ist ein Irrtum. Lust und Unlust können negative Bedingungen werden, wie die Bewußtheit überhaupt eine solche für das positive Bewußtsein ist.

Wenn nun Lust und Unlust als Urelemente des Bewußtseins anerkannt bleiben, so werden sie als solche anerkannt für diejenige Art des Bewußtseins, welche nach der hergebrachten Terminologie das Gefühl bezeichnet; das Gemeingefühl, das Lebensgefühl. Das ist das Gefühl von Lust und Unlust. Ist dieses Lebensgefühl auch das Bewußtsein des ästhetischen Gefühls? Widerstreitet dies nicht dem Grundbegriffe der Reinheit? Möchte man die Urelemente des Bewußtseins, als

<!-- pdf:153 S.123 -->

welche Lust und Unlust anerkannt seien, noch so sehr schon als Inhalt anerkennen, nimmermehr könnte dieser Inhalt doch als ein reiner gelten. Da aber nur der reine Inhalt das reine Gefühl bestimmen kann, so können Lust und Unlust nicht Inhaltsbestimmungen des ästhetischen Gefühls sein.

Es kann die Frage immer wieder auftauchen: wie kommt es, daß mit jeder Tätigkeit des Bewußtseins, mit der der Empfindung und der des Denkens, wie mit der der Begierde, Lust und Unlust wie verwachsen sind? Diese Frage wird uns später beschäftigen.

Hier darf uns nur die Gegenfrage angehen: wie kommt es, daß Lust und Unlust, obwohl sie im Intellekt und in der Begierde dem Menschen und dem Tiere gemeinsam sind, ein ästhetisches Bewußtsein, ein ästhetisches Gefühl dennoch nur im Menschen zur Entwickelung bringen. Die Antwort kann nur sein: das ästhetische Gefühl wird durch die Reinheit der Erzeugung bedingt. Und diese Reinheit der Erzeugung beschränkt sich keineswegs auf die intellektuelle Vorbedingung der Kunst. Die Technik der Kunst haben auch die Bienen; aber sie haben kein Kunstgefühl, obschon sie gewiß auch die Lust bei ihrer Technik haben werden. Die Reinheit erweist sich deutlich als die Ursache des ästhetischen Gefühls. Nicht die Lust also, obwohl Urbestandteil des Bewußtseins überhaupt, ist damit zugleich als das positiv bestimmende Grundelement des ästhetischen Gefühls erwiesen.

Immer deutlicher wird die sachliche Bedeutung in der Methodik der Reinheit. Und besonders lehrreich wird diese Bedeutung an dem Problem des Gefühls, das der Reinheit zu widerstehen scheint. Das ästhetische Gefühl bezeichnet einen neuen Kulturinhalt. Das Gefühl von Lust und Unlust dagegen bleibt stehen bei dem Wunder der Bewußtheit; denn es ist nur eine Qualifikation im Stattfinden des Bewußtseins, nicht eine Qualifikation in seinen Inhalten.

5. Indem Lust und Unlust als Bewußtheit erkannt werden, wird das Unbewußte als ästhetisches Fundament abgelehnt.

Wie es zugeht, daß ein ästhetisches Bewußtsein sich regen könne, das ist ebenso sehr eine unzulässige Frage der Be-

<!-- pdf:154 S.124 -->

wußtheit, wie die nach der Möglichkeit des Stattfindens des theoretischen oder des ethischen Bewußtseins. Auf dieses Stattfinden darf die ästhetische Gesetzlichkeit nicht gerichtet werden. Daher darf auch das Unbewußte nicht als Lösungsversuch eintreten. Die Bewußtheit wird als Macht gedacht, ebenso für die Helle des Bewußtseins, wie auch für seinen finstern dunklen Schoß. In letzterem Sinne entfaltet sich besonders gefährlich die Bewußtheit des Unbewußten. Und diese Gefahr wird besonders verhängnisvoll für die Ästhetik. Die finstere Seite des Bewußtseins ist das Böse, das wie eine dämonische Zaubermacht wirkt. Im Schicksal wird es zu einem schwierigen Problem für das Drama.

Noch schwieriger stellt sich dieses Dunkel des Unbewußtseins im Häßlichen dar. Ist es etwa schlechterdings ein Widerspruch zum Schönen, weil es, in Lust und Unlust wurzelnd, als eine selbständige Urform des Bewußtseins, als das Unbewußte gedeutet wird? Worin ist denn das Urbild des Häßlichen gegeben, in der Natur, oder in der Kunst? Als ein Unbewußtes gedacht, wird es in der Natur ursprünglich angenommen, und erst von der Natur aus in die Kunst hinübergetragen. Man sieht dabei nicht, daß man dem Häßlichen seine ästhetische Urbedeutung hinwegnimmt, wenn man sie aus der Natur herleitet. Man sieht nicht, daß das Häßliche auch für die Natur nur ein ästhetisches Kriterium ist.

Von dieser ausschließlich ästhetischen Bedeutung sieht man ab, oder aber man ist für sie in der Illusion des Unbewußten befangen, wenn man nur an die Macht denkt, welche das Häßliche für das Bewußtsein ausübt. Man unterscheidet nicht, aus welcher Art und Richtung des reinen Bewußtseins diese Macht ausgeübt wird. Man unterscheidet hierfür nicht das ästhetische Bewußtsein von dem sittlichen, weil man es nicht unterscheiden will von dem Erkenntnisbewußtsein. Das Häßliche erscheint im Zwerg. Der aber ist ein Dämon, also eine Macht, nicht lediglich des Bösen, sondern eine Naturgewalt. Und so wird er unversehens zum Giganten, zum Titanen. Mithin ist er an sich ein Gegenstand der Naturerkenntnis, nicht allein der sittlichen, im Kampfe der Götter.

<!-- pdf:155 S.125 -->

So wirkt das Häßliche kraft der Macht des Unbewußten, die in ihm erblickt wird. Und diese Macht beruht auf der Urform der Bewußtheit, welche das Häßliche in Lust und Unlust erregt.

Es ist außer Zweifel, daß das Häßliche dem ästhetischen Problem zugehörig ist. In dieser Hinsicht steht es jetzt nicht zur Erwägung. In dieser Hinsicht gehört es zum Problem des ästhetischen Inhalts, und wird als eine Stufe im Prozeß dieses Inhalts nachzuweisen sein. Niemals aber darf es als ein selbständiger Inhalt zum Problem werden. Es kann immer nur Moment sein, immer nur eine Seite am ästhetischen Inhalt, immer nur ein Mittel für die Erzeugung desselben sein. Wo es als ein selbständiger, abgeschlossener ästhetischer Inhalt aufgestellt wird, da wird es eben als ein Gegenstand von Lust und Unlust, also nur als ein Gegenstand der Bewußtheit gedacht, nicht als eine Stufe in der Erzeugung des reinen ästhetischen Bewußtseins. Und nur im reinen Bewußtsein kann Inhalt des Bewußtseins erkannt werden. Der Gegenstand der Bewußtheit ist ein sich selbst widersprechender Begriff.

Es ist also auch der Gegensatz zum reinen Inhalt, der sich wiederum in dieser Fassung des Unbewußten am Problem des Häßlichen dartut. Und so bleibt es beim Gegensatz zum Inhalt, der überall in Lust und Unlust erkennbar wird, welche nicht als Grundelemente des reinen ästhetischen Gefühls gedacht werden dürfen.

## 2. Der Aufbau ästhetischen Bewußtseins

Der Aufbau des ästhetischen Bewußtseins, auf Grund der systematischen Methodik, erweist sich schon gegenüber der Annahme des Unbewußten förderlich.

Der systematische Fehler Schellings, der schon hervorgehoben wurde, hat seinen Grund letztlich in jener Annahme. Darum soll die Philosophie wieder in die Poesie einmünden, weil sie aus ihr erflossen sei. Und die Poesie ist deshalb der Urquell der Erkenntnis, weil sie die Urkraft alles Bewußtseins

<!-- pdf:156 S.126 -->

sei. Sie ist dies aber deshalb, weil sie allem Bewußtsein gegenüber das Unbewußte ist. Alles eigentliche Bewußtsein, insbesondere das der Erkenntnis, ist abgeleitet und vermittelt. Die Kunst allein ist ursprünglich, daher bezeugt sie das Bewußtsein in seiner Grundgestalt, und zwar als das Unbewußte. Dieses Bewußtsein des Unbewußten aber nennen wir dagegen Bewußtheit.

Ist es nur der ästhetische Enthusiasmus in seinem Überschwange, wie er der Romantik eigen ist, der dem ästhetischen Bewußtsein diese fundamentale und elementare Bedeutung zuspricht? Sicherlich hat er allezeit dabei den Ausschlag gegeben; aber ein theoretischer Grund darf hierfür doch nicht verkannt werden. Er möchte darin liegen, daß im ästhetischen Bewußtsein alle anderen Arten des Bewußtseins zugleich in Wirksamkeit treten, keineswegs etwa nach einander in die Entwickelung eintreten; und daß sie in dieser gleichzeitigen Zusammenwirkung dennoch eine jede in ihrer Eigenart wirksam sind. Diese Simultaneität der Gesamtwirkung des Bewußtseins in der Kunst zeigt sich ebensowohl im Individuum des Künstlers, wie in der Geschichte der ästhetischen Kultur. Auf dieser Einheitlichkeit beruht der Schein des Elementaren, das der Kunst eigen sei.

Singen und Sprechen entstehen zusammen. Nach der einen Ansicht ist das Sprechen, nach der andern aber das Singen früher. Wir werden zu entwickeln haben, daß beide Tätigkeitsweisen zugleich entstehen können, weil sie innerlich zusammenhängen. Chronologisch läßt sich die Gleichzeitigkeit freilich nicht bestimmen, wohl aber als ein sachlicher Zusammenhang, als eine Zusammenwirkung.

Nicht anders steht es mit Schreiben und Zeichnen. Nur daß die Zeichnung als die primitive Form nachweisbar wird. Indessen beweist dies nicht etwa die Primitivität der ästhetischen Zeichnung; denn die ursprüngliche Zeichnung ist Mitteilung, mithin eine Art der Schrift. Wenn in den Fels gezeichnet wird, so soll der Stammesgenosse dadurch eine Mitteilung erfahren, ebenso wie das Singen nicht ausschließlich ästhetische Tat ist, sondern ebenfalls Mitteilung

<!-- pdf:157 S.127 -->

oder Lockung, wie auch die Tiere in solcher Bedeutung das Singen pflegen, als einen Ersatz der Sprache.

Man nennt diese ursprünglichen Tätigkeitsweisen Ausdrucksbewegungen. Aber beide Teile dieses zusammengesetzten Wortes bedürfen der Erklärung. Der Ausdruck verlegt das Interesse nach Außen, in das Zeichen, welches hervorgebracht wird. Und mit dieser Äußerung scheint die Bewegung übereinzustimmen, welche auch nur auf die äußere Erscheinung und Betätigung bezogen wird.

Indessen liegt doch das eigentliche Problem in dem Innern, aus welchem die Bewegung und der Ausdruck hervorgehen. Dem Ausdruck entspricht doch nicht etwa der Eindruck, etwa nach dem alten Bilde die Wachstafel, sondern vielmehr der Urquell des Innern. Im Ausdruck wiederholt sich an der Tätigkeit des Bewußtseins die Korrelation von Innerem und Äußerem, und zwar genauer und richtiger als am Eindruck, der das Äußere voraussetzt, während der Ausdruck das Innere fordert. Mithin aber stammt der Ausdruck aus dem Innern, so daß er auch das Äußere dem Innern homogen zu machen vermag. Wir werden das Augenmerk darauf zu richten haben, daß auch der Bewegung diese Korrelation zwischen dem Innern und dem Äußern eigentümlich sei. Auch die Bewegung stammt aus dem Innern, und nur deshalb erzeugt sie den Ausdruck.

Der Fehler, den die Psychologie machen muß, sofern sie sich nicht von der systematischen Methodik leiten läßt, besteht darin, daß sie für die Entwicklung des Bewußtseins den Ausgang von der Empfindung nimmt. Damit nimmt sie ihn vom Äußern, anstatt vom Innern. Freilich ist auch ihr die Empfindung ein inneres Geschehen, aber das ist sie ihr nur als Reaktion auf einen Reiz von Außen. So ist das Außen vor dem Innen da.

In gleicher Weise wird auch die Bewegung hintangestellt gegen die Empfindung. Das Bewußtsein einer Bewegung wird immer nur gedacht als die Empfindung einer solchen. Die Empfindung einer Bewegung ist keine andere

<!-- pdf:158 S.128 -->

Art der Empfindung, als die Empfindung überhaupt ist. Wie daher die Empfindung schon die Außenwelt voraussetzt, so setzt auch die Bewegung die materielle Bewegung voraus, von der sie als ein Abbild zur Empfindung kommt. Die Frage bleibt dabei ganz außer Betracht: wie entsteht die materielle Bewegung selbst? Logisch präzisiert; wie entsteht in der reinen Erkenntnis das Problem und der Begriff der Bewegung?

Von dieser methodischen Leitung aus kann erst in der Psychologie die Frage gestellt werden: wie entsteht die Empfindung der Bewegung? Wie kann das Äußere durch die Bewegung erzeugt werden? Diese Frage aber nach der Erzeugbarkeit des Äußern kann nicht anders zur Beantwortung kommen als durch die Bestimmung des Innern, auf Grund welcher in seiner reinen Erzeugung auch die des Äußern vollzogen wird. So gehören der Ausdruck und die Bewegung in der Tat zusammen, so daß nun auch der Terminus der Ausdrucksbewegung eine methodische Rechtfertigung erlangt.

Wir waren schon darauf aufmerksam geworden, daß mit der Entstehung des ästhetischen Problems die Einführung des Gefühls, als einer besondern psychischen Qualität, erfolgt ist. In seinen „Versuchen über die menschliche Natur“ welche eine Art von physiologischer Psychologie sind, unterscheidet Nicolaus Tetens die Empfindnis von der Empfindung. Diese Empfindnis soll der Empfindung gegenüber das Gefühl auszeichnen. Man sieht, daß bei Tetens die Empfindung immer das Erste bleibt. Aus ihr wird die Empfindnis hergeleitet. Es ist dagegen eine wichtige Korrektur, daß Mendelssohn mit dem Terminus des Gefühls, als eines neuen Seelenvermögens, den Zusammenhang mit der Empfindung gänzlich aufhebt. Dadurch erst kann das Gefühl mehr als Neuheit, nämlich Selbständigkeit erlangen.

Wie der Zusammenhang zwischen Gefühl und Empfindung, der freilich bestehen muß, sonst herstellbar wird, das ist jetzt nicht zu fragen. Jetzt gilt es zu erwägen, daß dieser Zusammenhang die Selbständigkeit des Gefühls aufhebt, oder nicht

<!-- pdf:159 S.129 -->

genügend zur Geltung bringt, wenn es als eine Modifikation der Empfindung bezeichnet wird.

Dies möchte auch der Mangel in der modernen Terminologie der betonten Empfindung sein. Auch dabei bleibt das Gefühl, welches als Betonung der Empfindung bezeichnet wird, ein Anhängsel der Empfindung. Der von Kant gebrauchte Ausdruck „Ton der Empfindung“ gibt diesem Irrtum weniger Raum, da der Ton hier nach der ursprünglichen Bedeutung als Spannung gedacht, übrigens auch so bezeichnet wird, während die Betonung nur die musikalische Färbung bezeichnen will. Die Spannung dagegen kann, oder muß vielleicht sogar als voraufgehend gedacht werden, da sie sonst doch Abspannung wäre. Wenn das Gefühl aber, als Spannung, der Empfindung voraufgeht, so wird damit der Gedanke nahegelegt, daß sie selbst etwa auch bei der Erzeugung der Empfindung mitzuwirken haben möchte, und daß sie in diesem bedeutungsvollen Sinne als ein Merkmal der Empfindung geltend zu machen sei.

Wenn das Gefühl, als ein ursprünglicher Faktor des Bewußtseins, für die reine Gesetzlichkeit des ästhetischen Bewußtseins ergründet werden soll, so muß jeder Schein und jede dahin gehende Bestimmung beseitigt werden, als ob das Gefühl nur eine Resultante wäre. Es nützt aber hierfür nichts, sich etwa auf Lust und Unlust zu berufen, als auf eine vermeintliche Urquelle alles Inhalts und daher alles Bewußtseins. Wir haben erkannt, daß dadurch nur das Unbewußte zum Grunde des Bewußtseins gesetzt würde, also nur die Bewußtheit an Stelle des Bewußtseins. Aus der systematischen Methodik heraus allein kann auch diese Erörterung geleitet werden, sofern sie als eine systematische gedacht wird. Und es ist keine geringe Probe für diese Methodik, wenn der methodische Grundbegriff der reinen Logik bei diesem systematischen Problem der Ästhetik zu einer entscheidenden Anwendung kommt. So wird es deutlich, daß dieses Problem gar nicht in erster Instanz der Psychologie angehört, sondern daß das Problem des Gefühls, an dem ästhetischen Gefühl erwachsen, von der systematischen Ästhetik entdeckt, und der Psychologie überliefert wird.

<!-- pdf:160 S.130 -->

Wir haben schon erwogen, daß im ästhetischen Bewußtsein der gesamte Apparat des Bewußtseins von Anfang an in Mitwirkung tritt. Diesen universellen Charakter des Kunstbewußtseins legt in lehrreicher Bedeutsamkeit die neuere Kunstgeschichte dar, wie sie sich bewußter Weise zur Kunstwissenschaft entwickelt.

Aus den Körperformen des Menschen, aus seinen elementaren Bewegungsformen und Bewegungsrichtungen, auf Grund dieser aber aus seinem gesamten psychischen Leben und Tun sucht die neuere Kunstwissenschaft die Kunst aus ihren Grundformen abzuleiten; aus denjenigen Grundformen, welche dies ebensosehr sachlich, wie historisch sind. So die Symmetrie, die Proportionalität und der Rhythmus. So auch die Dimensionen des Raumes. Aber auch auf die Denkformen wird dabei Bedacht genommen, auf die der Mehrheit, und ebenso auch auf den Begriff der Zeit. Auch auf den Willen wird Rücksicht genommen für die Erzeugung der Raumgestaltung, damit aber auch auf die Richtungen der Bewegung.

Wir sehen sonach, daß die neuere Kunstwissenschaft auf die Grundform der Bewegung zurückgeht; das will aber sagen: auf die Bewegung, als die Grundtätigkeit des Bewußtseins. Die Fruchtbarkeit dieses methodischen Ansatzes erhellt schon aus der Analogie der Physik. Die Physik ist nicht nur darum die Lehre von der Bewegung, weil alle Körper der Physik Formen der Bewegung sind, sondern vielmehr darum, weil sie alle Erzeugung der Bewegungsformen aus dem reinen Begriffe der Bewegung vollzieht. Diesen großen methodischen Sinn hat ihre moderne Entstehung in der Dynamik Galileis, im Unterschiede von der antiken Statik. Wie die Bewegung das Grundproblem der Naturwissenschaft ist, so darf von ihr auch erwartet werden, daß sie sich auch an den systematischen Problemen des Bewußtseins

<!-- pdf:161 S.131 -->

in ihrer Methodik bewähren werde, so weit diese Methodik die systematische Anwendung zuläßt.

Nun entsteht freilich insofern hier eine Schwierigkeit, als zwei Gesichtspunkte für die Konstituierung des ästhetischen Bewußtseins sich aufzustellen scheinen: der der Bewegung, daneben aber der des Gefühls. Und es entsteht die große Frage, ob sie beide sich vereinigen lassen; genauer, ob das Gefühl derselben Methodik zugänglich wird, welche an der Bewegung sich bewährt. Denn daran darf nicht gerüttelt werden, daß die Eigenart des ästhetischen Bewußtseins als Gefühl zur Erweisung kommen muß. Welche andere Art könnte sich ausdenken lassen, da Erkenntnis und Wille besetzt sind? An der Hand der Kunstgeschichte ist die Ästhetik erwachsen: und als Gefühl ist sie erstanden. Wir sind demnach auf den Versuch hingewiesen, das Gefühl mit der Bewegung zu vereinbaren; das Element der reinen Erzeugung, welches der Bewegung einwohnt, in analoger Weise auch für das Gefühl zu entdecken, und zur methodischen Bestimmung zu bringen.

Die Logik der reinen Erkenntnis hat sich auf dem Prinzip des Ursprungs aufgebaut. Alle Urteilsarten, alle Kategorien haben sich als Abwandelungen jenes Urmotivs aufzeigen lassen. Auch die Bewegung ist aus solchen Variationen des Ursprungs herleitbar und bestimmbar geworden. Der methodische Leitgedanke ist dabei: die Bewegung muß reine Erzeugung sein; mithin darf sie nicht Nachahmung sein, nicht Nachbildung, die nicht Erzeugung wäre. Diese Grundbestimmung ist wie für die Kunst geschaffen. Wenn sie Bewegung, Ausdrucksbewegung ist, so darf diese nicht Nachahmung sein. Der Ursprung, als Leitbegriff für die Methodik einer jeden systematischen Bewußtseinsart, muß auch für die Bewegung gelten; nicht minder für die Kunstbewegung, wie für die der Physik.

So enthüllt sich der schwere methodische Fehler in der alten Ansicht von der Nachahmung, die nicht aussterben zu können scheint. Nicht einmal die physikalische Be-

<!-- pdf:162 S.132 -->

wegung darf als Nachahmung der Empfindung der Bewegung gedacht werden; nicht so ist sie zur wissenschaftlichen Erkenntnis gekommen: geschweige daß die spontane Bewegung des Künstlers als Nachahmung auch nur Problem werden könnte.

Und wenn anders nun die Bewegung der Kunst zugleich reines Gefühl sein muß, so muß diese Reinheit auch für das Gefühl allen Nachklang beseitigen, als ob darin die Eigenart des Gefühls bestimmbar werden könnte. Der Ursprung muß auch zum Leitbegriff für das ästhetische Gefühl gemacht werden. Und es bleibt zu beachten, daß das ästhetische Bewußtsein in der Gesamtheit des Bewußtseins zur Entwicklung, schon zur ersten Entstehung kommt.

Der systematischen Methodik wegen sei hier der Mangel in einem historischen Moment hervorgehoben, welches sonst einen wichtigen Erfolg bedeutet. Seit der Publikation des Reisejournals wissen wir, daß Herder die Kunst der Plastik aus dem Getast hergeleitet hat. Und schon im Sinne der neuern Kunstwissenschaft erläutert er die Entstehung und Entwicklung der plastischen Kunst an dem Zusammenhange, in dem sie mit der Entwicklung des Bewußtseins überhaupt steht. So macht er, nach dem Vorgange des Anaxagoras und des Aristoteles, das Getast zur Grundbedingung der Empfindung. Wie die moderne Entwicklungslehre der Sinnesorgane es dartut, sieht er daher das Auge als antizipierendes Tastorgan an. Und dieser universellen Natur des Tastsinnes gemäß wird die Plastik zum Urelement der bildenden Kunst.

So lichtvoll dieser alte und durch die neuere Forschung neu bestätigte Gedanke nun auch im allgemeinen und für die Kunst selbst ist, so bedarf er doch der ergänzenden Bestimmung, um methodischen Irrtum fernzuhalten. Ohne solche Einschränkung würde die Kunst zur Nachahmung werden müssen, wenn sie schlechthin eine Ausbildung des Tastsinns wäre. Das Getast hat notwendigerweise die Tastflächen des Objekts zu seiner Voraussetzung; mithin das Objekt

<!-- pdf:163 S.133 -->

selbst. Und wenngleich die Tiefe jener Ansicht darin besteht, daß das Objekt vermittels der Tastflächen erst zur Entdeckung, erst zur Ertastung kommen soll, so kann diese Ertastung doch nimmermehr Erzeugung sein.

Der Weg der Erzeugung wird dabei verfolgt, aber er wird nicht gefunden. Die Einstellung auf ihn ist nicht erlangt worden. Die Empfindung, die Tastempfindung wird als Ziel gesetzt, mithin wird sie auch als das Erste gedacht, von dem die Kunsttätigkeit, wie alle Bewußtseinstätigkeit, auszugehen habe. Es ist also in dem Ausgehen von der Empfindung der allgemeine Fehler auch hier zu erkennen. Und er wiederholt sich an der Bewegung, als welche die Tastempfindung richtig erkannt wird. Damit aber wird nicht geholfen, daß die Empfindung als Bewegung erkannt wird; denn dabei bleibt die Gefahr bestehen, daß die Bewegung als Empfindung gedacht wird. Damit wird sie aber als Nachahmung für die Kunst festgehalten, wie für das Bewußtsein überhaupt als Nachempfindung.

Aus allen diesen Erwägungen ergibt es sich, daß wir den Leitbegriff des Ursprungs ebenso auf die Erzeugung der Bewegung, wie auf die des Gefühls anzuwenden haben. Das ästhetische Gefühl hat sich aber in seiner Eigenart zugleich als Gesamtwirkung der beiden ersten Bewußtseinsarten herausgestellt. Daraus ergibt sich ferner, daß der Leitbegriff des Ursprungs die gesamte Methodik bei dem systematischen Aufbau des Bewußtseins zu durchdringen hat.

Demgemäß haben wir bereits in der Ethik des reinen Willens diesen Aufbau versucht, auch dort schon mit Rücksicht zwar nicht auf das ästhetische Gefühl, aber auf das Gefühl von Lust und Unlust. Und wir konnten uns dort auf die „Notwendigen Vorbegriffe“ von Johannes Müller berufen. Sie bestehen in dem Grundgedanken, daß man das Bewußtsein nicht lediglich als Reaktion der Reize bestimmen darf; daß vielmehr die Disposition zu solcher Reaktion als Urbestand des Bewußtseins angenommen werden muß. Die Reize dürfen mithin nicht das Erste bleiben; in ihnen stecken die Gegenstände,

<!-- pdf:164 S.134 -->

die man nicht von vornherein als gegeben annehmen darf. Die Disposition innerhalb des Nervensystems für die Aufnahme von Reizen muß als „Vorbegriff“ zugrunde gelegt werden, damit diese nicht als äußere Ursachen das Erste bleiben, sondern gleichsam nur eine Fortsetzung bilden. So wird das Prinzip des Ursprungs bei diesem Begründer der neuern Physiologie wirksam gemacht.

Wenn nun aber Johannes Müller für die spezifischen Sinnesempfindungen in den Sinnesnerven die Disposition annimmt, wie das Eigenlicht im Sehnerv, so dürfen wir über das spezifische Sinnesgebiet hinaus diese Disposition zugrunde legen. Und die Bewegung selbst eignet sich zu dieser Grundlegung. Die Tätigkeit, welche das Leben bedingt, die Athmung, ist Bewegung. Sie wird schon im Embryo anerkannt. Sie ist nicht allein die Urtätigkeit der Sinnlichkeit, welche die Tastempfindung bildet; denn zu dieser wird auch die Druckempfindung und die Temperaturempfindung gerechnet. Mit der letztern aber ist nicht nur ein Zentrum der Lebenstätigkeit, wie es die Atmung bildet, gewonnen, sondern zugleich ein Zentrum für das Bewußtsein. Das Bewußtsein, sofern es nicht lediglich als Stattfinden gedacht werden darf, ist immer durch einen Zusammenhang mit der Umwelt bedingt. Nur in diesem Zusammenhange mit der umgebenden Natur vollzieht sich die eigene Natur des Bewußtseins, wie vermittelst des Stoffwechsels dadurch auch die Einheit des Individuums.

<!-- pdf:165 S.135 -->

# Viertes Kapitel. Der Aufbau des Bewußtseins

Wenn wir demnach mit der Temperatur den Aufbau des Bewußtseins beginnen, so zielen wir dabei schon auf die beiden Arten des Inhalts ab, auf die das Bewußtsein sich erstreckt: auf die Natur und auf das Ich. Wir müssen nun aber an der Temperatur den kritischen Anfang ansetzen. Die Temperaturempfindung setzt den Reiz voraus, auf den sie die Antwort ist. Es muss daher ein Ursprung des Bewußtseins für diese Empfindung vorausgesetzt werden. Die „notwendigen Vorbegriffe“ enthalten diese Weisung für das Nervensystem. Dieses hat eine eigene Temperatur in seiner vitalen Tätigkeit des Stoffwechsels. Analog derselben ist mithin auch ein Ursprung im Bewußtsein der Temperatur anzunehmen.

Wie ist dieser Ursprung zu bezeichnen, da die Empfindung ausgeschlossen ist? Die Frage wird nicht im Sinne der Bewußtheit gestellt, sondern in der Richtung auf die Erzeugung des Bewußtseins. Bewußtsein setzt freilich den Inhalt voraus. Aber der Ursprung des Bewußtseins darf nicht selbst schon Inhalt sein, sondern auch nur Ursprung des Inhalts. Gehalt mag ihm beiwohnen, daher etwa auch Lust und Unlust, aber Gehalt ist nicht Inhalt. Der Gehalt besteht in dem Gehaben des Bewußtseins als Stattfinden, als Verharren in sich selbst, in der Bewegung, in welcher dieses Gehaben, dieses Stattfinden besteht. Der Urtätigkeit des Nervensystems selbst soll diese Urtätigkeit im Bewußtsein analog sein. Und dazu eignet sich die Temperatur besonders; denn sie bezieht sich unmittelbar auf den Zusammenhang mit der umgebenden Natur. In diesem latenten Zusammenhange ist daher auch die

