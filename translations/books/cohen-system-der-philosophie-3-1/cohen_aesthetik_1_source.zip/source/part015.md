<!-- part 015: S. 373–401 -->

<!-- pdf:403 S.373 -->

auch die Begriffe zu seiner Vorbedingung hat, so sind dessen Erzeugnisse ihm ja nur Stoffe, die es umzuschaffen hat; wozu aber umzuschaffen? Zum reinen Gefühl. Das ist eine systematische Methode, eine eigene Erzeugungsweise. Was bedeutet diese aber, als Inhalt gedacht, gegenüber den Inhalten der Erkenntnis?

## 10. Der einige Inhalt der Poesie

Wie die Inhalte, die Gegenstände der Erkenntnis, in der Einheit der Natur objektiv vereinigt werden, so objektiviert sich das reine Gefühl im Selbstgefühle, im Selbst, als Inhalt des Gefühls. Der Welt der Objekte, der Natur wird somit systematisch koordiniert eine Welt der Innerlichkeit, das Selbst als Innerlichkeit. Und wenn die Begriffe auf den Zusammenhang der Natur hin kontrolliert werden, so bildet die Innenwelt des einen Selbst nunmehr die Kontrollinstanz für die Begriffswortgefühle in der Sprache der Poesie. Hier waltet daher die Vergleichung, wie dort die Identität.

Die Wortgefühle entquellen dieser Innerlichkeit, die nicht schlechthin gegeben ist, die ja die große allgemeine Aufgabe des reinen Gefühls, als des Selbstgefühls, bildet. Die Wortgefühle der poetischen Sprache graben daher diese Innenwelt ebenso sehr erst aus, wie sie sie auch ausfüllen. Alle Mittel des Denkens und der Sprache müssen in dieses Quellgebiet des poetischen Denkens einströmen. Dieses Flußgebiet bildet den eigentlichen Inhalt der Poesie. In diesen Inhalt der Innerlichkeit, des Selbst, werden alle sonstigen Inhalte, als Stoffe, umgewandelt und verwandelt.

Hier eröffnet sich eine nicht unwichtige Einsicht in eine Forderung, die wir der Methode des reinen Gefühls gestellt haben. Die Bedingungen der reinen Erkenntnis und der reinen Sittlichkeit sollen Vorbedingungen für das reine Gefühl werden, und diese Vorbedingungen beziehen sich nicht allein auf die Inhalte als Stoffe, sondern, der Rein-

<!-- pdf:404 S.374 -->

heit gemäß, auch auf die Methoden. Jetzt zeigt sich nun, wie diese beiden Arten von Bedingungen zur Verbindung kommen können, wie sie es müssen im reinen Gefühl. Es bleibt dem reinen Gefühl nicht schlechterdings überlassen, erstlich diese Verbindung zu vollbringen, und sodann sie wieder in das reine Gefühl umzuschmieden. Beides wäre notwendig; denn die Verbindung selbst vollzieht nicht etwa an sich schon die Erzeugung des reinen Gefühls. Die Verbindung selbst muß also auch noch nur eine Vorbedingung sein.

Jetzt sehen wir nun, wie die Wortgefühle diese Verbindung herstellen. Die Begriffsworte der Erkenntnis widersetzen sich zwar in ihrer Tendenz den Gefühlsannexen; gänzlich aber können sie derselben sich doch nicht begeben. Dagegen sollen die Begriffsworte der sittlichen Erkenntnis zwar auch der strengen Reinheit zustreben, und daher nicht in ihren Gefühlsannexen schwelgen; bei ihnen aber ist der Gefühlswert doch nicht nur vom Übel, sondern er weiß sich hier ein legitimes Anrecht zu behaupten, und insbesondere in den Tugendbegriffen wird dieses Recht unbestreitbar. So begünstigen die sittlichen Begriffsworte in ihren Wortgefühlen die geforderte Verbindung mit den Begriffsworten der Erkenntnis, und ermöglichen auch der letztern Beseelung mit ihren Gefühlsannexen.

Wenn die Poesie selbst noch nicht schon bei dieser Beseelung als wirksam gedacht wird, so ist es doch als eine Vorarbeit zu erkennen, wie gleichsam die schlummernden Gefühlskräfte in den Begriffsworten zu ihrer Verbindung mit den sittlichen Begriffsworten auferweckt, und ihrer starren Begriffswerte entkleidet und entäußert werden, um so für die Umschaffung in die Gefühlswelt des Selbst zubereitet zu werden. Diese Umschaffung bedarf einer Vermittlung. Die neue Methode des reinen Gefühls bedarf daher auch einer solchen Ergänzung der Vorbedingungen, wie sie durch die Verbindung der beiden Methoden gefordert, und durch deren Vollzug in den gemeinsamen Wortgefühlen geleistet wird.

<!-- pdf:405 S.375 -->

Auf der innerlichen Durchführung dieser Verbindung beruht die Entwicklung der Poesie zu ihren hohen klassischen Formen. Diese Verbindung vollzieht sich in der immer innerlichern Durchführung der urgesetzlichen Form der Vergleichung. Die höhere Geistesform der Poesie erweist sich darin, daß sie Denkgebilde und Denkreihen in Verbindung bringt, welche den beiden Gebieten der Erkenntnis und der Sittlichkeit angehören, und welche in beiden Gebieten nicht etwa auf der Oberfläche liegen, sondern den innersten methodischen Zentren beider Gebiete entstammen. Sie gehen vermittelterweise aus diesen Zentren hervor, und sie streben in sie zurück; dennoch aber bleibt diese Verbindung keine abstrakte, keine den Interessen der beiden Gebiete dienende; dann ergäbe diese Verbindung nicht Poesie; dann führte diese Verbindung nicht zur Umschaffung ins reine Gefühl. Wie kann nun aber diese Verbindung zustande kommen?

Sie könnte es in der Tat nicht; sie würde nur eine mechanische Forderung bleiben, wenn die Worte nur Begriffsworte, wenn sie nicht auch Gefühlsworte wären und Wortgefühle in sich enthielten. Auf Grund dieses psychologischen Tatbestandes vermag sich die klassische Form der Poesie zu der Leistung zu erheben, daß sie, die scheinbar abstraktesten Problemworte der beiderseitigen Erkenntnis in ihren Dienst nehmend, die Wortgefühle zu einer gegenseitigen Durchdringung bringt, und in dieser Durchdringung, besser mit ihr, die Erzeugung des reinen Gefühls ins Werk setzt.

Warum ist Schillers Poesie nicht etwa nur Gedankenpoesie? Das wäre ein Widerspruch. Warum bleibt seine Poesie nicht in der Abstraktion der Gedanken hängen, und wird vielmehr durch die Höhe der Gedanken zur innerlichern Kraft des Gefühls beschwingt? Weil er in den Gefühlsannexen der Begriffsworte beide Welten miteinander in Verbindung bringt, um eine neue Welt aus dieser Verbindung zu erschaffen. Daß Goethe vielleicht in noch höherem Grade dies bewirken mag, kann hier außer

<!-- pdf:406 S.376 -->

Betracht bleiben. An unserm Beispiel schon können wir es bei Schiller uns klarmachen; und Schiller stellt immerhin in seiner Gedankenpoesie das gefährlichere Problem dar, während bei Goethe die Schwierigkeit überhaupt so sehr überwunden ist, daß sie erledigt und illusorisch scheint.

Schiller macht aus den Helden der Sonnenbahn die Brüder auf der Bahn der Menschheit. Mit den Brüdern öffnet sich der Himmel der Sittlichkeit dem Sonnenhimmel der Natur entgegen. Ist das etwa ein Verlassen der Poesie, eine Aufhebung derselben in die Sittlichkeit? Dann hätte freilich die Gedankenpoesie diesen aufhebenden Sinn. Wir haben aber gesehen, daß darin nicht einmal ein Verlassen des Mythos vorliegt; denn die Freude verbindet diese neue Menschenbahn der Brüder mit dem alten Sonnenhelden und dem Bräutigam. Es ist nicht die abstrakte Sittlichkeit, die hier gepredigt wird; der Bruder tritt in der Freude seiner Bahn auf. So verbindet sich in der Bahn die Sonnenbahn mit der Bahn der Menschheit.

So erweist sich die Vergleichung, so zu sagen, nicht als ein spontaner Akt, der seiner selbst wegen geschieht; und auch ihr Zweck und Ziel, das reine Gefühl, greift nicht unmittelbar in dieses Spiel hinein, sondern die Verbindung der beiden Grundbedingungen geht vorauf, und auf ihr erst erhebt sich die Vergleichung. Der Sonnenheld wird zum Bruder. So verbinden sich Naturerkenntnis und Sittlichkeit, und diese Verbindung ist der Hebel der Vergleichung.

Da sonach die Vergleichung ein konstruktives Mittel wird, als Vorarbeit für die Methodik des reinen Gefühls, so wird von hier aus nun auch die methodische Vorbedingung verständlich, welche die Poesie für alle Künste bildet. Diese auf der Verbindung der beiden Vormethoden begründete Vergleichung, diese poetische Apperzeption ist die Vorbedingung, ist das engere Sprachmittel aller Kunst. Um als Gegenstände der Kunst erzeugbar zu werden, beruhen die Gegenstände in jeder Kunst auf dieser

<!-- pdf:407 S.377 -->

poetischen Urform der Vergleichung auf Grund jener Verbindung.

Man könnte denken, diese Voraussetzung der Poesie für alle Künste beschränke sich darauf, daß alle Gegenstände ja gedacht werden müssen, und daß sie nicht allein begrifflich gedacht werden dürfen, sondern zugleich in den Wortgefühlen dieser Begriffsworte. So wichtig und grundlegend in dieser Hinsicht schon die Voraussetzung ist, welche die Poesie bildet, so erschöpft sich darin doch nicht ihre Bedeutung. Die Vergleichung greift über die poetische Wortbildung und Satzbildung hinaus; sie erweitert sich zu einem allgemeinen Mittel des reinen Gefühls.

Die bildende Kunst entnimmt doch nicht ausschließlich dem Mythos ihre Gegenstände; mithin hat der Mythos ihnen nicht immer die Vorweihe gegeben, so daß auch die poetische Zubereitung bei ihnen vermißt werden könnte. Dennoch bleibt die letztere in Kraft, weil sie sich nicht in den Sprachgefühlen erschöpft, mit denen die Vorstellungen in der bildenden Kunst apperzipiert werden müssen. Was ist denn nun das noch intimere Mittel, das in der Poesie enthalten ist, das, abgesehen von der Vergleichung, ihre innerlichste Verbindung mit allen Künsten bedingt?

## 11. Die Poesie und das Mal

Der Anfang der bildenden Kunst liegt in der Auszeichnung eines Mals, in der Bildung eines Schmucks. Die Male und die Schmuckgegenstände entsprechen den Wort- und Satzgefühlen der Poesie. Jene Gegenstände im Beginne der bildenden Kunst sind eben so wenig bloße Gegenstände des Schaffens, oder der Sichtbarkeit, wie die Worte der Poesie nicht lediglich Begriffsworte, sondern Verbindungen derselben mit ihren annexen Gefühlen sind. Die Vergleichung fehlt auch hier nicht, wenngleich sie nicht als solche ausgedrückt wird. Die Kunst befindet sich hier noch auf der Vorstufe des Mythos; sie hat die Identität noch

<!-- pdf:408 S.378 -->

nicht in die Vergleichung umgewandelt. Dennoch tritt die Kunst ins Werk; sie kann mithin nicht in der Befangenheit des Mythos stehen geblieben sein: worin zeigt sich dennoch die Vermittlung, welche die Poesie zu leisten hat? Wir werden sehen, daß die Vergleichung in eine höhere Form für die Erzeugung des reinen Gefühls eintritt.

Was ist der Zweck und Sinn bei der Aufstellung eines Mals, bei der Auszeichnung einer Person durch einen Schmuck? Man wird nicht antworten wollen, diese Auszeichnung sei selbst ein abschließender Zweck. Das mag für gesellschaftliche, politische oder sonstige Beziehungen so erscheinen, aber damit ist die ästhetische Frage nicht erledigt; wir fragen nach dem ästhetischen Zwecke, nach dem ästhetischen Grunde dieser Auszeichnung. Die ästhetische Begründung fragt nach dem Sinn dieses Hokuspokus für den Kulturwert des reinen Gefühls. Aus diesem Gesichtspunkte aber genügt keineswegs die Beziehung auf die Schmückung der Person.

Das reine Gefühl kann erst dann in Vollzug kommen, wenn die Person, welche geschmückt wird, in Beziehung tritt mit der schmückenden Person. Und die schmückende Person braucht nicht eine isolierte Einzelperson zu sein; sie kann sich zu einem Kreis von Personen ausdehnen, von denen die Absicht und die Handlung der Schmückung ausgeht. So tritt der zu schmückende Gegenstand von vornherein in die Korrelation mit der schmückenden Person ein; er wird gleichsam nur zu einem Vordergliede derselben; der Zielpunkt der Korrelation liegt aber in dem letzten Gliede und seinem Kreise.

Wir können jetzt diese Korrelation bestimmter ausdrücken in Gemäßheit der Bestimmung des reinen Gefühls. Bei diesem kommt es letztlich auf das Selbst an. Alle Gegenstände sind nur Stoffe, methodische Stoffe zur methodischen Erzeugung des Selbst. So ist es ganz in der Ordnung, daß auch die zu schmückende Person gar nicht die Hauptsache bleibt, sondern nur der Anlaß ist für die schmückende Person, die ihr Selbst dabei zur Erzeugung bringen will.

<!-- pdf:409 S.379 -->

## 12. Die Verinnerlichung

Und demgemäß können wir nun auch die Vergleichung erweitern und tiefer fassen als die Verinnerlichung, welche das Wesen aller Kunst ist. Die Vergleichung ist nichts als Verinnerlichung. So ist die Poesie in der Vergleichung das Instrument aller Kunst. Die Vermittlung des Mythos ist daher keineswegs unerläßlich; die Vermittlung der Poesie wird darum doch nicht ausgeschaltet, wo der Mythos nicht den bewußten Ausgang bildet. Die Verinnerlichung arbeitet mit den in jedem Gegenstande, in jeder Person latenten Sprachgefühlen. Kein Gegenstand des Schmuckes kann allein in seinem Begriffswort apperzipiert werden; die Wortgefühle müssen in ihm mitschwingen. Wenn also auch die Vergleichung in der primitiven bildenden Kunst übersprungen wird, so wirkt sie doch in der Verinnerlichung fort. Es kommt in der Tat nicht eigentlich auf das Gleichnis an, welches das Mal bildet, welches den Schmuck mit der geschmückten Person in Vergleichung bringt, sondern es kommt vielmehr auf die Beziehung zur schmückenden Person an, auf deren Verinnerlichung bei dieser Schmückung.

Zu dieser Verinnerlichung bleibt die Vorbedingung bestehen, welche die Verbindung der beiden Methoden bildet. Mit der Auszeichnung des Helden allein ist es nicht abgetan; das wäre eine politische Handlung, nicht eine ästhetische Erzeugung. Die letztere hat immer das Selbst zum eigentlichen Gegenstande, mithin die Verinnerlichung, die Ansprache des zu schmückenden Gegenstands aus dem Zentrum des Selbst.

So ist die Vergleichung zur Verinnerlichung geworden. Und als Verinnerlichung ist so die Poesie die verbindende Grundlage der Kunst geblieben. Diese Verbindung erstreckt sich auf alle Zweckbeziehungen der Kunst, wie die Verinnerlichung auch das maßgebende Prinzip bleibt für alle Zweckbeziehungen der Poesie. Ist die Mitteilung der eigentliche Zweck, oder die Beschreibung bei der Poesie, wie bei aller Kunst? Die Beschreibung würde die andere Frage herausfordern: was ist

<!-- pdf:410 S.380 -->

der Zweck und Sinn von ihr selbst? Muß die Beschreibung nicht vielmehr der Mitteilung dienen?

Die Mitteilung darf aber nicht so eng gefaßt werden, daß sie nur auf die Menschen bezogen wird, an welche sie ergeht; sie muß an erster, wie an letzter Stelle auf das Selbst gerichtet werden. Mit diesem unumgänglichen Ziel der Mitteilung tritt die Beschreibung in den Dienst eines Mittels zurück, und die Mitteilung wird nur eine Weise der Verinnerlichung; sie bezeichnet genauer die Richtung, welche die Verinnerlichung einzuschlagen, in welcher sie sich zu vollziehen hat. Die zu schmückende Person wird in Mitteilung an die schmückende und umgekehrt gesetzt. Die Mitteilung ist die Anteilnahme des Selbst an dem Dasein und Geschick der auszuzeichnenden, oder der poetisch darzustellenden Person. Nicht ihre Beschreibung ist letzter Zweck, sondern diese ist lediglich Mittel der Mitteilung der Verinnerlichung.

In neuerer Zeit ist die Frage einsichtig verhandelt worden, ob der Zweck der Poesie die Anschauung und die Anschaulichmachung sei. Die Antwort kann hiernach bündig gegeben werden: Er ist es, so weit die Verinnerlichung nicht durch die Veranschaulichung geschädigt, so weit die Verinnerlichung durch die Veranschaulichung gefördert wird. Die Verinnerlichung ist und bleibt der entscheidende Zweck. Die Veranschaulichung ist die Beschreibung, ist die Veräußerlichung. Die äußere Darstellung, die Beschreibung ist ein notwendiges Mittel, aber nicht mehr als Mittel. Und wenn eine Kollision zwischen dem Mittel und dem Zweck eintreten sollte, wie sie ja häufig stattfindet, so darf nicht dem Mittel die Entscheidung zugesprochen werden. Hier liegen die Gefahren für die sogenannterweise naive oder gegenständliche Poesie, wie für die Beschreibung und Veranschaulichung in der Kunst überhaupt.

Diese Gefahren sind doppelter Art. Einmal kann die Übertreibung der Veranschaulichung den Verfall in die Prosa herbeiführen, sofern die Verinnerlichung nicht das leitende Ziel bleibt. Dagegen kann aber auch die Vergegen-

<!-- pdf:411 S.381 -->

ständlichung so gesteigert werden, daß auch die Verinnerlichung dadurch gesteigert wird. Das ist die klassische Form der gegenständlichen Poesie, der Typus Goethes.

Die Veranschaulichung kann aber überreizt und verstiegen werden, ohne darum platt zu werden, ohne das Ziel der Verinnerlichung aufzugeben. Dann könnte das Moment des Erhabenen in Kraft treten. Aber dieses ist nur ein Moment. Und wenn das Moment des Humors zur Ergänzung in die so gesteigerte Veranschaulichung mit eintritt, so erhöht sich die Verinnerlichung; geschieht dies dagegen nicht, so entsteht für eine solche Darstellung des Erhabenen die Gefahr, das Ideal der Vollendung zu verfehlen. Die klassische Poesie und Kunst geht daher bei aller ihrer großen Veranschaulichungskraft unverkennbar immer von der Verinnerlichung aus. Nur den Allergrößten ist es verliehen, bei Überspannung der Anschauung selbst, die Verinnerlichung festzuhalten, und als das eigentliche Ziel klarzustellen. Nicht das Erhabene ist der absolute Gegenstand, ebenso wenig, wie der Humor: das Schöne allein ist der Gegenstand der Kunst, die Einheit von Seele und Leib. Sie ist die Natur des Menschen, welche der Gegenstand der Menschenliebe des reinen Gefühls ist.

Weder der Schaffende, noch der Beschauer sieht als letzten Zweck den beschriebenen Körper, die veranschaulichte Sache an, sondern allein deren Beziehung, deren Mitteilung an das Selbst. Es gibt eigentlich gar keinen Gegenstand, kein Ding und keine Person für die Kunst; das Selbst ist und bleibt die einzige Person, auf die es ankommt; und jede Sache und jeder Körper muß in diese Personifikation eintreten, um Gegenstand der Kunst zu werden. Diese Bedeutung der Verinnerlichung wird durch die Poesie zur Evidenz gebracht. Auch dadurch wird die Voraussetzung immer deutlicher, welche sie für alle Kunst bildet. Was ist Hekuba? Es kommt auf mich selbst an. So wird die Grenzbestimmung für die Beschreibung und Veranschaulichung durch die Poesie getroffen; das Werk der bildenden Kunst könnte den Anschein eines Selbstzwecks haben; die poetische Beschreibung dagegen kann nur ein Mittel sein. Wenn sie als solches aber ein Mittel der Mitteilung

<!-- pdf:412 S.382 -->

sein muß, so hat sich diese als Verinnerlichung herausgestellt. Und diese Verinnerlichung gibt nun auch dem allgemeinen Vehikel der poetischen Sprachform, als dem Instrument aller Kunst, eine tiefere Bedeutung.

Unter den Bedenken, welche immerfort gegen das Recht der Kunst, gegen den Ernst des ästhetischen Bewußtseins von jeher erhoben worden, hat die Poesie alle Zeit den größten Anstoß gegeben. Die bildenden Künste entziehen sich dieser Frage halbwegs durch ihren Nutzen, der so vielseitig ist; die Poesie dagegen scheint lediglich Spiel zu sein, zur Mitteilung, als Unterhaltung. Daher beurteilt man aus diesem Zwecke heraus die Lossagung von der Sittlichkeit, welche die Poesie in der Souveränität ihrer Phantasiemacht sich anmaßt, und sich zum Geschäft zu machen scheint. Und so scheint um so mehr berechtigt der Kampf, den der Intellektualismus von alters her gegen die Kunst geführt hat, die Auflehnung Platons gegen seinen geliebten Homer selbst.

Das Prinzip des reinen Gefühls kann die Losung l’art pour l’art nur als ein vorübergehendes Stichwort im Kampf der Parteien halten. Keine Kunst steht für sich allein; die Poesie steht für sie alle ein. Wäre der Poesie der Ernst abzusprechen, so würde allen Künsten das Fundament entzogen. Die Verinnerlichung ist der allgemeine Sinn der Kunst. Und die Poesie legt den Grund, den allgemeinen Grund der Verinnerlichung für alle Künste. Sie ist die Sprache der Kunst, die zweite Sprache der Kunst.

## 13. Die Poesie als zweite innere Sprachform

Die erste Sprache ist geistige Verinnerlichung, Verinnerlichung zum Zwecke des Geistes, der Erkenntnis. Die zweite Sprache ergibt erst die echte Verinnerlichung, die des Selbst. Die erste Sprache ist die Begriffssprache, durch welche die Gegenstände gedacht und erdacht werden. Diese sind nur die Stoffe des reinen Gefühls. Die zweite Sprache ist die Sprache dieses reinen Gefühls. In ihr vollzieht sich die

<!-- pdf:413 S.383 -->

echte Verinnerlichung, für welche der Geist selbst zum Stoffe herabsinkt; in welcher das Selbst allein zum Gegenstande wird, zum alleinigen Gegenstand. Jeder andere Gegenstand ist nur ein Körper, eine Sache und am Menschen nur der Leib. Die Verinnerlichung erst erzeugt die Natur des Menschen, die Einheit von Leib und Seele.

Die zweite Sprache ist nicht etwa ein Gleichnis; aber freilich bedarf sie, als Terminus, noch genauerer Bestimmung. Wie die Sprache überhaupt, nach Wilhelm von Humboldts Terminologie, innere Sprachform ist, so ist die zweite Sprache, als welche wir hier die Poesie erkennen, genauer die zweite innere Sprachform. Und diese Sprachform ist noch mehr eine innere als die erste, die, als solche, nur von der äußern Lautform unterschieden wird. Sonst aber besteht ihre Innerlichkeit nur in der Erzeugung der Satzbegriffe, und sie bedarf hierzu und für die Erhaltung dieser begrifflichen Einheiten der Fernhaltung aller Gefühlsannexe dieser Begriffsworte.

Die zweite innere Sprachform dagegen setzt sich das Innere zu einer komplizierten Aufgabe, insofern sie die begrifflichen Worte festhalten muß, aber von ihren Gefühlsannexen sie nicht ablösen darf. So wird das Innere hier ein zweiseitiges und ein höheres, weil die Begriffsworte und deren Wortgefühle und Satzgefühle einschließendes. Darin besteht die höhere Aufgabe der Poesie: daß sie, wenngleich nicht so unübersehbare Gedankenketten, so doch die heterogensten Elemente, die Begriffsinhalte und die Gefühlsbegleitungen zusammenzuschließen hat. Und während die erste Sprachform Entselbstung fordert, um dafür die Welt gewinnen zu können, scheint hier das Selbst der alleinige Zweck und Inhalt der Verinnerlichung zu sein.

Indessen ist damit die Verinnerlichung noch keineswegs erfüllt, und so ist auch die Bedeutung der zweiten innern Sprachform mit dem Innern selbst noch nicht erschöpft. Nicht das Innere allein ist das Erzeugnis der Verinnerlichung, so daß die Objekte schlechthin nur Stoffe wären; sondern, da diese Stoffe rein erzeugt werden müssen, muß die Verinnerlichung sich auch auf sie erstrecken, und muß die zweite

<!-- pdf:414 S.384 -->

innere Sprachform auch das erzeugende Organ der Objekte, wie des Innern werden.

Und nicht allein die Gegenstände selbst sind zu erzeugen von ihr, sondern die Gesamtheit ihrer Zusammenhänge, die natürlichen, die geistigen, die geschichtlichen aller Art. So wird die Poesie in buchstäblicher Bestimmtheit eine zweite Ursprache, eine eigene Erzeugung, Entdeckung, Bestimmung ebenso sehr der Gegenstände, wie vermittelst ihrer zugleich des Innern, welches der Brennpunkt der Verinnerlichung ist. Nicht allein der Bruder wird aus dem Sonnenhelden umgeschaffen, sondern die Sonne selbst wird in dieser poetischen Personifikation nunmehr gedacht; sie bleibt nicht die astronomische, die wahrnehmbare Sonne, sie wird das Zentrum einer neuen Welt. Aber nicht allein die neue Welt ist das Ergebnis dieser Verinnerlichung, sondern von Anfang an nicht minder auch die Sonne selbst. Eine solche Urkraft der Apperzeption besitzt die zweite innere Sprachform. Man unterschätzt die Ursprünglichkeit und den Umfang der poetischen Schöpferkraft, wenn man der Verinnerlichung diese Erstreckung auf das Objekt in eigener Erzeugung abnimmt.

Indem wir die Verinnerlichung in dieser Bedeutung fassen, erledigt sich auch die Frage: ob das Innere als Äußeres, oder das Äußere als Inneres zur Darstellung zu bringen, Aufgabe der Poesie sei. Beide Aufgaben fallen offenbar zusammen. Es gibt gar kein Äußeres in aparter Selbständigkeit, so wenig als ein Inneres ohne die selbsterzeugte Vermittlung des Äußern. Verinnerlichung bedeutet Einheit von Seele und Leib. Wie die Seele nicht ohne den Leib apperzipiert werden kann, so besteht der Leib nicht für die Poesie, außer sofern die Seele sich seiner bemächtigt. Und diese Bemächtigung erfolgt durch die Sprache der Poesie, als die zweite innere Sprachform.

So wäre denn die Seele und das Innere schon vorhanden, um das Äußere sich aneignen zu können? Stände es so, so würde die Verinnerlichung nicht die Reinheit des ästhetischen Gefühls bedeuten können, so würde das Selbst nicht ein reines Erzeugnis sein. So wäre aber auch keine wahrhafte Einheit

<!-- pdf:415 S.385 -->

von Leib und Seele vollziehbar. Die Einheit fordert, daß ihre beiden Elemente durch sie zur Erzeugung gelangen. Die Seele darf nicht schon vor der Einheit fertig und gegeben sein. Es wird mithin nicht allein das Äußere durch die Poesie verinnerlicht, sondern es wird am Äußern zugleich das Innere erzeugt. Die Verinnerlichung bedeutet die Erzeugung des Innern, der ästhetischen Seele, des Selbstgefühls.

Wir haben die Vergleichung als Verinnerlichung erkannt. Man darf daher nicht fragen: wozu die Vergleichung? Wozu die Metapher? Ist sie nicht vielleicht doch ein Umweg, ein überkommener Kunstgriff, durch den die Poesie nur den Schein von Mitteln an sich zieht, die ihr an sich versagt sind? Sie kann nicht beschreiben und veranschaulichen, wie es die Plastik und die Malerei vermag, daher entlehnt sie als Bilder, was ihr an Abbildern abgeht und versagt ist. Es ist falsch, daß die Metapher nur ein angemaßter, nur ein rhetorischer Schmuck wäre, ein Ballast, der in dem poetischen Gedankenfluge auch abgeworfen werden könnte. Wir haben erwogen, daß dieser vermeintliche Schmuck ebenso instrumental ist, wie der Schmuck im bildnerischen Mal. Wir haben erkannt, daß der Bedeutung des Mals die zweite innere Sprachform durchaus entspricht. Wie durch das Mal das Selbst mit der geschmückten Person in Beziehung gesetzt wird, so durch die poetische Sprache der Gegenstand, als ein Zubehör des Selbst.

So ist die Vergleichung so wenig nebensächlich, daß sie vielmehr diese zweite innere Sprachform selbst ist. Mit den Gefühlsannexen wird das Begriffswort apperzipiert, und in das Innere des Selbst verwandelt. Die Sonne ist nicht nur nicht mehr der Sonnenheld, sondern sie wird zum Gleichnis für den Bruder. Auch die Brüder laufen, wie die Sonnen fliegen. Aber das Gleichnis hat den Gegenstand dennoch aus dieser ganzen Sphäre herausgehoben. Die Metapher ist nicht eine Nebensache, aber durch sie ist die Sonne zur Nebensache geworden. Und doch ist nicht etwa der Bruder zur Hauptsache geworden; auch er ist nur Mittelsperson. Der erzielte Gegenstand ist allein das Selbst. Wir betreten feuertrunken

<!-- pdf:416 S.386 -->

das Heiligtum der Freude. Die Freude ist das Heiligtum des reinen Selbst. Das Selbst ist die Einheit, welche die Sprache der Poesie vollzieht.

Wir sehen hier wieder an der Sonne, in welchem genauen Sinne die Natur, als Gegenstand des Schönen, das Erzeugnis der Kunst und zuvörderst der Poesie ist. Nicht etwa die bildende Kunst vermag allein und ursprünglich die Natur zu entdecken, und zur Verinnerlichung zu bringen. Auch sie bedarf der Krücke der Vergleichung; auch sie darf die Vergleichung nicht nur als Krücke behandeln. Innere Sprachform aber ist die Vergleichung nur in der Poesie.

Wenn daher die Landschaft das eminente Problem der modernen Kunst geworden ist, so werden wir zu erwägen haben, welcher Zusammenhang zwischen dieser Entwicklung und der Entwicklung der neuern Poesie besteht. Wir dürfen nicht von vornherein annehmen, daß die Selbständigkeit der Malerei es mit sich bringe und erfordere, daß durch sie die Beobachtung und die Entdeckung der Natur ohne alle weitere Voraussetzung von statten gehen müsse. Vielmehr werden wir ihre Reinheit als bedingt erkennen müssen, wie schon durch die Vorbedingung der Erkenntnis, so nicht minder auch durch die Poesie, als den Oberbegriff der Kunst. Die Naturmalerei muß sonach die Naturpoesie zur Voraussetzung haben. Wenn sich nun aber zeigen sollte, daß diese Naturpoesie nicht in der poetischen Naturbeschreibung besteht, sondern vielmehr in der Lyrik, so wird dadurch wieder die Einheit von Seele und Leib lebendig, und die Verinnerlichung kommt zu einer neuen prägnanten Bedeutung. An der Lyrik hat die Malerei die Landschaft zur Erzeugung gebracht.

So macht die Poesie, und zwar für alle Künste, die Natur zur schönen Natur, gleichsam zum Kunstwerk des Schönen. Dies sind mithin die beiden Pole der Poesie: die Natur und das Selbst. Die Zueignung hat aus dem Verhältnis zur Natur und zur Erkenntnis die Poesie bestimmt. „Aus Morgenduft gewebt und

<!-- pdf:417 S.387 -->

Sonnenklarheit, der Dichtung Schleier aus der Hand der Wahrheit.“ Die Hand der Wahrheit ist der Mythos, die Erkenntnis im Morgendufte. Aber der Schleier der Dichtung ist zugleich auch aus Sonnenklarheit gewebt, mithin aus der gereiften Erkenntnis. Und es ist nicht Erkenntnis schlechthin, sondern die Natur selbst gleichsam webt den Schleier; sie ist im Morgenduft und in der Sonnenklarheit das unmittelbare Objekt der Dichtung. Aber die Dichtung bleibt ein Schleier aller Erkenntnis. Nicht der Erkenntnis; denn diese empfängt sie aus der Hand der Wahrheit. Was sie verschleiert, was sie vielmehr nur im Schleier enthüllt, das ist die Dichtung selbst, das ist das Selbst des reinen Gefühls.

## 14. Die Bilder und die Schatten

In dem Schleier ist die Selbstanklage und Rechtfertigung zu erkennen, die allen großen Dichtern am Herzen liegt. „Das Beste in dieser Art ist nur Schattenspiel, und das Schlechteste ist nicht Schlechteres, wenn die Einbildungskraft nachhilft.“ So wehrt sich Shakespeare gegen die Skepsis, daß alle Poesie nur eitel Schein und Blendwerk sei. Allerdings nur Schattenspiel, aber die Einbildungskraft ist die Sonne dabei. Schatten ist das alte idealistische Gleichnis. Schatten sind die Bilder, die von der Höhle im weltgeschichtlichen Gleichnis Platons reflektiert werden; die Schatten, als die Bilder der Dinge, die das wahre Sein ausmachen. Dieses wahre Sein aber besteht auch nur in dem reinen Denken, dem reinen Schauen. Die Bilder sind daher nicht schlechthin Abbilder; denn die Urbilder bestehen auch nur im reinen Schauen. Die Bilder sind zwar nicht Scheinbilder, aber Erscheinungen; und den Erscheinungen sind nicht etwa Urbilder, Urdinge, Dinge an sich korrelativ, sondern Gebilde des reinen Denkens, Noumena. Alles Sein hat seinen letzten Grund im Denken. Und das Denken hat seinen tiefsten Ausdruck im Verinnern (ἐννοεῖν).

So geht im Verinnern das reine Denken, als reines Schauen, mit dem reinen Schaffen der Poesie zusammen. Verinnerlichung

<!-- pdf:418 S.388 -->

ist die gemeinsame Methodik alles geistigen Schaffens. Nur der Begriff und das seines Gefühlsannexes entblößte Begriffswort macht den Einschnitt in das geistige Wesen, so daß auf die eine Seite die Welt der wissenschaftlichen Erscheinungen, und auf die andere die der Schattenspielbilder fällt. Bilder sind die Objekte auf beiden Seiten, Schattenbilder. Nur das Spiel stellt sich dem Begriff entgegen, das Schattenspiel dem Schattenbegriff. Und das Spiel bringt die Umkehr in der Korrelation hervor; nicht die Dinge sind die Urbilder, sondern das Innere ist das Ding an sich, und alle Dinge, die Natur selbst, sie ist nur Spiegelung des Innern, aus dem Brennpunkte des Selbst gehen sie als Strahlungen hervor. Wie aber so das Schattenspiel und der Schleier der Poesie aus der allgemeinen Lösung des Idealismus bestimmbar werden, so ist dadurch wiederum auch das Grundverhältnis bestätigt, welches zwischen der Poesie und allen anderen Künsten besteht.

## 15. Die Natur und die Kultur

Wir haben bisher das Verhältnis der Poesie zur Natur betrachtet, und an diesem Grundverhältnis, welches bestehen bleibt in aller Entwicklung und für alle Beziehungen der Poesie, hat sich auch die Voraussetzung feststellen lassen, welche die Poesie für alle Künste bildet. Indessen bleibt die Natur nicht das einzige Objekt, als Problem der Verinnerlichung: die Formen der Kultur nehmen eine ähnliche Objektivität an, wie die Natur. Schon die elementaren Formen des gesellschaftlichen und des politischen Lebens unter den Menschen der Urzeit streben eine Stabilierung und auf dem Wege der Anerkennung, eine Befestigung dieser Einrichtungen an, als ob die Anerkennung bewirken sollte, diese menschlichen Einrichtungen zu Gebilden der Natur umzuprägen.

Es bleibt aber nicht bei dem Gegensatz zwischen Menschenwerk und Naturprodukt; bald treten zu diesen Unterschieden die Werke der bildenden Künste hinzu. Sie sind Menschen-

<!-- pdf:419 S.389 -->

werke, erheben aber auch den Anspruch, ebenso den Wert und den Charakter von Naturgebilden zu verdienen, wie die Einrichtungen der sonstigen menschlichen Gesellschaft. Nicht einmal die Einrichtungen der Religion brauchen davon ausgenommen zu werden; sollen ja doch die Tempel der Götter ursprünglich nur verwandelte Paläste der Fürsten sein. So wächst die Kunst aus der politischen Kultur heraus. Und je mehr die Ansprüche der Mächtigen gesteigert und erweitert werden, und je gefügiger die Schwächeren gegen die Macht werden, desto mehr wird dadurch nicht nur der Kultus unterstützt, sondern mit diesem zugleich auch die Kultur der Kunst. Diese Beziehung zur Kunst ist urwüchsig in der politischen Kultur. Denn die sozialen und politischen Differenzierungen in der Urform der menschlichen Gesellschaft müssen an sich selbst eine Verinnerlichung anstreben, damit sie nicht als eine unmotivierte, lediglich auf Macht und Willkür beruhende Wirklichkeit zu gelten brauchen. Diese Verinnerlichung lenkt auf die Bahn der Kunst hin.

Einem solchen Fürstensitz ist gewöhnlich ein Kampf vorausgegangen; er ist der Siegespreis nach diesem Kampfe. Der Kampf wird von Stämmen geführt, und ein Stamm hat den Sieg errungen. Der Fürst bleibt nicht ein Einzelner, oder vielmehr er ist dies nicht gewesen, aber er bleibt es auch nicht, sondern sein Anhang bildet einen Kreis um ihn. In diesem ist der Fürst der Mittelpunkt, aber zu ihm gehört der Kreis. Dieser sein Anhang, sein Stamm verwächst mit dem Fürsten und mit seiner Geschichte. Seine Geschichte ist die Geschichte seines Stammes, der seine Kreise in dieser seiner Geschichte immer mehr erweitert. Solche Begebenheiten im Wechsel der sozialen und politischen Machtverhältnisse in einem Stamme und alsbald auch im Wechselverkehr der Stämme erwecken das Interesse an ihrer Verinnerlichung. Wir wissen ja jetzt, daß die poetische Verinnerlichung kein willkürlicher Umweg, sondern vielmehr das unausweichliche Mittel ist zur geistigen Mitteilung, mithin zur Darstellung und zur Aufbewahrung.

<!-- pdf:420 S.390 -->

Als Gedächtnis (μνήμη) ist das Bewußtsein bei den Griechen entstanden. Die Aufbewahrung im Gedächtnis ist der erste Akt der Verinnerlichung. So entstehen, als Urform der Poesie, die „Ruhmestaten der Männer“ (κλέα ἀνδρῶν). So entsteht ein Berufsstand wandernder Sänger. In diesen Urformen der Poesie liegen die Urformen des Epos.

## 16. Die zweite innere Sprachform und die Arten der Poesie

Die literarischen Grundformen der Poesie sind zwar ebenso sehr als geschichtliche Fakta anzunehmen, wie auch die Arten der Künste solche Faktizität in Anspruch nehmen; dennoch aber sind auch sie, der Voraussetzung ihrer Einheit gemäß, aus dieser heraus zu deduzieren, wie ja auch die Poesie selbst für alle Künste diese Ursprungsbedeutung der Einheit hat. Was für alle Arten der Kunst gilt, muß erst recht für die Arten der Poesie anzusprechen sein. Es ist mithin ein Gattungscharakter, wie Schiller sagte, für die Poesie vorauszusetzen.

Worein wollen wir nun diesen Gattungscharakter setzen? Nach den voraufgehenden Erörterungen haben wir ihn in der Verinnerlichung zu erkennen, welche für alle Künste das Ziel ist, auf welches die innere Sprachform der Poesie hinsteuert. Sie ist das Aneignungs- und Eroberungsmittel aller Art von Inhalt und Objekt für die Innenwelt des Selbst. Die Korrelation des zu erzeugenden Objekts mit dem Selbst muß immer der ästhetische Leitgedanke sein für alle Grundlegungen und für alle Einteilungen.

Diese Korrelation erfordert selbst aber immer wieder neue Bestimmungen, und zwar für die beiden Glieder derselben, für das Objekt, wie für das Subjekt.

Erinnern wir uns immer wieder, daß es sich in aller Kunst um die Einheit in der Natur des Menschen und mit dem Menschen der Natur handelt. Während

<!-- pdf:421 S.391 -->

aber die Natur des Menschen nur die Einheit von Leib und Seele vertritt, erweitert sich für den Menschen der Natur der Horizont des Individuums auf das Universum.

Ohnehin bahnt sich auch in der Natur des Menschen durch das Moment der Seele schon diese Erweiterung in einem größern Umfange an. Denn die Seele enthebt das Individuum schließlich seiner Naturschranken, und ordnet den Einzelmenschen in ein neues Universum ein, in das der Geschichte.

Die Verinnerlichung würde äußerlich bleiben, wenn sie das Individuum nicht auf das Universum der Geschichte zu projizieren vermöchte. Und die innere Sprachform der Poesie würde nicht Vernunftsprache sein, und immer reicher und tiefer zu einer solchen auswachsen, wenn sie nicht ebenso das Subjekt, wie das Objekt, im geschichtlichen Sinne zur Verinnerlichung bringen könnte.

Es ist aus diesem unserm Grundbegriffe durchaus zu verstehen, daß das Epos die Urform der Poesie ist. Unsere Betrachtungen haben uns schon auf den politischen Ursinn des Epos geführt, und wir werden diese geschichtliche Grundkraft des Epos genauer zu betrachten haben. Hier genügt es, auf das historische Gepräge hinzuweisen, welches dem Epos eigen ist, ohne welches sein Inhalt nicht gedacht werden kann. Es wächst aus dem Mythos heraus, wie das Volk aus dem Chaos einer Völkerwanderung herauftaucht, eine Urform der politischen Geschichte, eine Urform, in welcher Völkerstämme zu einer Einheit zu verschmelzen streben, durch Kriege zum Frieden einer Einheit. Diese Vereinheitlichung ist die Grundform der poetischen Verinnerlichung. Nicht Länder und Flüsse, nicht Berge und Bäume sind das eigentliche Objekt, auf dessen Verinnerlichung und poetische Aneignung es hier ankommt; sondern die Menschen, die Völker und die Helden sind die Objekte, in deren Aneignung die Verinnerlichung sich vollzieht. So bildet sich hier die Korrelation zwischen Objekt und Subjekt schon dadurch, daß es Subjekte sind, welche zu Objekten der Verinnerlichung werden.

<!-- pdf:422 S.392 -->

Aber diese Subjekte liegen immerhin noch auf der Seite des Objekts. Wie steht es aber um das Selbst des reinen Gefühls, welches eigentlich erst das poetische Subjekt ausmachen kann? Erst mit Rücksicht auf dieses Selbst kann es doch zu einer poetischen Grundform, also zum Epos kommen. Die Verinnerlichung muß selbst noch eine Spezialisierung erfahren.

Diese Spezialisierung der epischen Poesie bildet die Erzählung. Die Natur dieser Sujets ist die Geschichte. Und die Geschichte hat diesen Doppelsinn, daß sie zugleich das Objekt und seine Darstellung bedeutet. Diese Darstellung wird nun hier reine Erzeugung. Aber die Erzählung ist der Stilcharakter dieser Darstellung. Es handelt sich um Begebenheiten; im Grunde jedoch so wenig um diese selbst, wie um die Völker und die Helden. Denn den eigentlichen Drehpunkt bildet einzig und allein das reine Selbst. Dennoch ist die Erzählung das erzeugende Mittel, welches zur poetischen Grundform werden muß.

Die Erzählung ist sonach nicht die äußerliche Form einer Darstellungsweise, die auch verändert werden könnte, sondern sie ist die reine Erzeugungsweise dieses spezifischen Inhalts, dieser Begebenheiten, welche die Urform der Geschichte sind, Und in dieser erzählenden Erzeugung werden die Begebenheiten verinnerlicht durch die Taten der Völker, und diese wiederum durch die Taten der Helden. Und doch kommt es gar nicht auf diese Begebenheiten, diese Völker und diese Helden an, sondern im letzten Grunde nur auf das reine Selbst, welches den Zielpunkt der Verinnerlichung bildet. Aber dieses reine Selbst erzeugt sich in der Korrelation mit jenem Chaos von Menschengestalten.

Anders verhält es sich in der zweiten Grundform, welche die Lyrik bildet. In ihr gibt es keine Völker und keine Helden mehr; der Mensch steht hier isoliert im Zeichen des Individuums. Zwar sind es unmittelbar zwei Individuen, die ihr Spiel miteinander treiben, aber sie betrachten sich gar nicht als zwei; sie streben zu einer Einheit zusammen,

<!-- pdf:423 S.393 -->

Die Einheit von Leib und Seele wird hier ganz der Seele übertragen. Der Mensch hört auf, Mensch der Natur zu sein; und auch die Natur des Menschen wird gar nicht mehr in Spaltung von Leib und Seele gedacht, sondern nur als seelische Einheit: zwei Herzen, ein Schlag. Das ist unbezweifelbar eine Grundform, welche aus dem Gattungscharakter der Poesie hervortritt; sie scheint die Hauptform der Verinnerlichung zu vertreten. Was im Epos die Begebenheit bedeutet, das bedeutet hier das Erlebnis. Wie die Seele die Einheit des Lebens ist, so die Liebe die Einheit des Lebens; die Wurzel und die Blüte des Lebens. Die Innenwelt ist die Schöpfung der Verinnerlichung; und könnte es eine Innenwelt geben ohne die Grundkraft der Liebe?

Das reine Gefühl haben wir als die Liebe bestimmt, als die Liebe zur einheitlichen Natur des Menschen. Schon in dieser allgemeinen Grundbestimmung des ästhetischen Bewußtseins haben wir daher die lyrische Form der Poesie vorausgesetzt. Was sonst in aller Kunst die Bedeutsamkeit der Liebe haben mag, kommt erst in der Lyrik zur Bestimmtheit und zur reinen Ausprägung.

Daher ist auch die Stilform der Lyrik charakteristisch für dieses innerlichste Erleben, das Erlebnis der Liebe. Die Erzählung verblaßt hier, und sie wird zu einem unzulänglichen, unpersönlichen, daher unwürdigen Auskunftsmittel. An ihre Stelle tritt das Bekenntnis.

Das Bekenntnis bezieht sich zwar im lateinischen Ausdruck des Wortes auf das Handwerk, aber auch nur im Sinne des Lebensberufes. Und als solcher höchster Beruf des Menschenlebens erscheint die Liebe in der Lyrik. Da tritt der Mensch mit seinem ganzen Werte ein; er fordert sein Schicksal in die Schranken. Wenn es irgendwie möglich und zulässig ist, den ganzen Lebenswert in eine Summe zusammenzufassen, so ist die Liebe diese Summe des Lebenswertes. Und diesen Lebenswert gilt es, im Liebesliede zu bekennen. Wenn es keinen Beruf sonst für die Lebensarbeit des Menschen gäbe, und wenn es keine Religion auf Erden gäbe: durch die Liebe müßte der Mensch zum Bekenner werden. Im Be-

<!-- pdf:424 S.394 -->

kenntnis der Liebe vollzieht sich die innerlichste Verinnerlichung, welche der Poesie zusteht.

In der Lyrik ist alles nur Innenwelt. Alle Objekte und Begebenheiten treten zurück, und werden wie nur zu einer Staffage des Vordergrundes, den diese absonderliche Subjektivität allein bildet. Daher hört hier auch der Unterschied auf, den die Erzählung bedingt. Die ganze Umwelt verschwindet; sie kommt eigentlich gar nicht für die Mitteilung in Frage; im Liebesliede gilt es nur das Bekenntnis. Und dieses spricht ein einsamer Mensch aus; er würde es aussprechen, auch wenn er ganz allein in der Welt wäre. Das Bekenntnis nimmt hier den Charakter einer Unmittelbarkeit an, dem sogar die Mitteilung fremd bleibt.

Und wie der Bekenner einsam für sich dasteht, so vereinigt er sich mit dem reinen Gefühle, welches sein Bekenntnis aufnimmt, und an ihm sich aufrichtet. So stellt die Lyrik eine innigste Verinnerlichung dar, die Erzeugung eines reinen Selbst, in welchem der Bekenner zusammenschmilzt mit dem Nachfühlenden, dem Mitfühlenden, in dem das Erlebnis der Liebe sich erneut, sich wiederholt; in dem das Bekenntnis selbst zu einer höhern Weihe, zu einer neuen Geschlossenheit sich umprägt.

So ist die Lyrik eine neue Form der Verinnerlichung, eine neue Erzeugung des reinen Selbst. Es entsteht so auch eine neue Natur des Menschen, und ein neuer Mensch der Natur; ein neuer Begriff der Natur, als Innenwelt.

Eine dritte Grundform bildet das Drama.

Was ist der Begriff der Handlung in dieser neuen Problemform? Worin unterscheidet sie sich von der Begebenheit und vom Erlebnis? Und was tritt in ihr und durch sie an die Stelle der Erzählung und des Bekenntnisses? Welche höhere Stufe der Verinnerlichung wird durch die Handlung beschritten?

Knüpfen wir wiederum an die Korrelation von Subjekt und Objekt an, so wird zunächst evident, daß das Objekt ebenso in Schatten gestellt wird, wie die Begebenheit; höchstens das

<!-- pdf:425 S.395 -->

Erlebnis könnte hier wieder auftreten wollen. Aber da es sich beim Erlebnis nur um die Liebe handelt, so belehrt die dürftigste dramatische Erfahrung darüber, daß diese im echten Drama zu einer bloßen Episode wird. Also auch das Erlebnis wird zurückgestellt, ebenso wie die Begebenheit: was gibt der Handlung nun ihren unterscheidenden Charakter, so daß alle Objektivität vor ihr ein Ende nimmt, und einzig und allein das Subjekt den Angelpunkt der neuen poetischen Form bildet?

Das Wort Handlung gemahnt uns an einen Grundbegriff der Ethik, und damit an die ethische Vorbedingung des reinen Gefühls. Mit der Handlung tritt daher die Poesie im Drama auf eine neue hohe Stufe der Kultur. Es kann sich nicht mehr schlechthin um Objekte und um Begebenheiten drehen, wo die Handlung zum Problem wird.

Die Ethik des reinen Willens hat gelehrt, daß der Begriff der Handlung auf der Einheit der Handlung beruht, und daß die Einheit der Handlung die Einheit des handelnden Subjektes, als des Rechtssubjektes und als der sittlichen Person, zur Voraussetzung hat. So ergibt schon das Wort Handlung für die Grundform des Dramas die schweren Komplikationen, welche ihm gestellt sind.

Indessen betrifft dies alles nur die Vorbedingungen, noch nicht aber die reine ästhetische Erzeugung. Es darf für die dramatische Handlung nicht verbleiben bei der sittlichen Einheit der Handlung, noch bei der Einheit der sittlichen Person. Welchen andern Umfang aber könnte denn die Einheit der Handlung erlangen, um den neuen Charakter der ästhetischen Handlung anzunehmen?

Wiederum müssen wir uns an der Korrelation von Objekt und Subjekt orientieren. Dem reinen Gefühl gegenüber ist die Handlung, die sich auf der Bühne begiebt, nichts mehr als ein Objekt, das nur in ethischer Hinsicht von einer Begebenheit unterschieden wird. Und so sind auch für das reine Gefühl die auf der Bühne agierenden Personen ebenfalls nur Objekte; denn was sie mehr sind, geht nur die sittliche Vorbedingung an. Wenn sie dagegen für das reine Gefühl selbst

<!-- pdf:426 S.396 -->

positiv werden wollen, so muß die Handlung und ihre Einheit sich auf das reine Selbstgefühl erstrecken; so darf sie nicht beschränkt bleiben auf die agierenden Subjekte, die für das Selbstgefühl nur vorbedingende Objekte sind.

Das Drama stellt daher als ein ganz neues Problem die Forderung einer Einheit der Handlung auf, welche gleichsam die Bühne mit dem Zuschauerraum verbindet. Nicht der Schauspieler allein bleibt der Handelnde; nicht die von ihm ausgehende, durch ihn vollführte Handlung kann die Einheit vollziehen; nicht die Einheit, welche der dramatische Held zu vollziehen hat, ist die dramatische Einheit der Handlung, sondern diese fordert die Vereinigung der Bühnenhandlung mit dem Zuschauer: der für diese Einheit keineswegs müßig bleibt, so wenig er, was gewiß nicht bezweifelt wird, überflüssig ist.

Die dramatische Einheit besteht in derjenigen Einheit, welche überall die Einheit des ästhetischen Bewußtseins erfordert: die Vereinigung mit dem Subjekte, das man gemeinhin als das rezeptive zu bezeichnen pflegt, welches aber, als das reine Selbst, an der reinen Erzeugung aktiven Anteil gewinnen muß.

So bildet das Drama einen neuen, einen höchsten Grad der Verinnerlichung, weil der Vereinheitlichung. Das ästhetische Problem läßt sich nicht schärfer zusammenfassen als in dem Gedanken: daß die Subjekte zur Vereinigung kommen: das schaffende und das erlebende. Das Kunstwerk bleibt tot, wenn es nur als eine Schöpfung, als ein Geschöpf gedacht wird; lebendige Schöpfung wird es erst, wenn es das Leben des reinen Gefühls zu erwecken vermag in dem Miterlebenden, der keineswegs nur ein Genießender ist.

Bei keiner Form der Poesie, vielleicht bei keiner Kunstform überhaupt, kommt es so deutlich an den Tag, daß die reine ästhetische Erzeugung eine Korrelation auch in der Erzeugung ist eine Korrelation daher nicht nur zwischen Objekt und Subjekt, sondern auch zwischen Subjekt

<!-- pdf:427 S.397 -->

und Subjekt, zwischen dem schaffenden Genie und dem Mitfühlenden.

Das reine Selbstgefühl schließt nicht etwa ab mit dem schaffenden Subjekte, sondern es vollzieht sich erst im Nacherleben und Miterleben. Man könnte dies paradox dahin ausdrücken: daß der Künstler selbst zur bloßen Vorbedingung wird, daß er selbst sich erst aus seinem Status des Schaffens und der Arbeit herausversetzen, und zum Standpunkt des Genießenden erheben muß; daß er daher die Differenz zwischen dem Urheber und dem Beschauer in sich aufheben, und daher auch sie überhaupt nivellieren muß.

Diese Quintessenz des reinen Gefühls bringt die dramatische Einheit zur Evidenz. Mit dem Kunstwerk allein ist es nicht getan, und auch nicht einmal mit seinem Urheber; der Zuschauer gehört auch dazu. Die Einheit der dramatischen Handlung muß auf der Verknüpfung mit dem Zuschauer ebenso, wie mit dem Bühnenhelden, beruhen, in ihr bestehen. So stellt das Drama den Grundgedanken des ästhetischen Bewußtseins klar, daß das reine Selbst die höhere Korrelation der Subjekte zur Voraussetzung hat.

Und daher erscheint das Drama als die höchste Form der Verinnerlichung; denn sie übertrifft alle sonstige Aneignung von Objekten, Begebenheiten und Erlebnissen: sie geht auf die Handlung, auf die Einheit der Handlung, auf die Einheit des handelnden Subjektes. Sie bearbeitet demnach die sittliche Vorbedingung in ihren Schwerpunkten, und bringt sie zu derjenigen Verwandlung, welche das reine Selbst erfordert, welche das reine Gefühl bezeugt. Das Drama gilt daher mit Recht als die höchste Form der Poesie und als eine höchste Kunstform überhaupt.

Es ist die Frage, ob die Ästhetik auf den Gedanken einer neuen poetischen Grundform hätte kommen können, wenn nicht die neueren Völker den Roman zur Ausgestaltung gebracht hätten. Indessen muß doch auch das Symptom beachtet werden, daß schon das Altertum und zumal in seiner Nachblüte, in der das Individuum subjek-

<!-- pdf:428 S.398 -->

tiver hervortritt, den Vorwurf des Romans aufgenommen hat. Und gerade dieser antike Roman stellt es bei aller seiner Mangelhaftigkeit doch außer Zweifel, daß es sich im Roman um nichts anderes als um die Liebe handelt.

Nochmals um die Liebe, nachdem sie schon das Problem der Lyrik war? Will der Roman etwa eine neue Form, eine Umformung der Lyrik sein? Oder will er etwa als eine Mischform sein Daseinsrecht begründen, indem er von allen anderen Grundformen etwas aufnimmt? Und was ist das Neue, das er selbst hinzubringt?

Eines stellt schon die historische Entstehung fest: daß der Roman durchaus nicht eine Fortsetzung des Epos ist. Wie kann er aber das lyrische Problem von einer neuen Seite zu fassen haben?

Halten wir uns wiederum an den historischen Fingerzeig, den die Entstehung des antiken Romans darbietet, so erkennen wir, daß es die Komplikationen der Kultur sind, welche eine neue Behandlungsweise der Liebe erforderlich machten. Die Liebe, als das Erlebnis der Lyrik, ist gleichsam eine Robinsonade. Für sie existiert die ganze übrige Welt nicht. Der Mensch der Natur schrumpft ihr zusammen zur Natur des Menschen. Und das Universum der Kultur bleibt ihr mit einem dichten Schleier bedeckt.

Es gehört aber zum Amt der Poesie, auch diesen Schleier zu lüften, und die Komplikationen in ihr Zauberreich hereinzuziehen, welche der einsamen Liebe in den Verwicklungen der Kultur unentrinnbar werden. So wird es auch methodisch verständlich, daß der Roman entstehen mußte, daß die Poesie mit der Lyrik ihr Werk an der Liebe nicht als vollführt ansehen konnte.

Der Liebende bleibt nicht der Schäfer auf der Heide; er wird aus dem Paradies des Hains in die weite Welt der sittlichen Kultur vertrieben; und er muß in ihr sein Herz zu wahren lernen; er darf es nicht in ihr verlieren, noch gar verloren geben. Im Kampfe mit den Hemmnissen, welche selbst die Rüstzeuge der sittlichen Kultur bilden, muß er seine Liebe behaupten; freilich auch diese Behauptung mit seinem Kopfe bezahlen.

<!-- pdf:429 S.399 -->

Die Liebe wird daher ein neuer Lebenswert im Leben der Kultur. Sie bleibt nicht das Erlebnis des Einsamen, für den es keine andere Welt gibt; sie wird ein Kampfpreis von ganz anderer Art, als dies die Siegespreise der epischen Heldenliebe sind. Der neue Lebenswert der Liebe ist ebenso sehr ein Lohn der Entsagung, wie der Beglückung. Der neue Lebenswert der Liebe entspricht eben dem neuen Begriffe des Lebenswertes der Kultur. Da waltet nicht nur das Wechselspiel von Freud und Leid; sondern da gilt es, das Leiden selbst als die Summe des Lebenswertes zu ziehen: in das Leiden selbst die reinsten Lebensfreuden einzurechnen.

Das ist der ethische Sinn des Lebenswertes der Kultur. Sollte er nicht auch eine sittliche Vorbedingung der Poesie werden müssen?

Auch aus dem Begriffe des reinen Gefühls und des reinen Selbst werden wir somit auf die Grundform des Romans geführt. Sogar mit dem Drama bliebe die Verinnerlichung, trotz aller Höhe, die sie in ihm erreicht, doch noch auf die Wege ihres Vollzuges eingeschränkt. Sie sucht nur die Spitzen zu verbinden; aber sie läßt die Niederungen unbeleuchtet, durch welche sich die Verinnerlichung hindurchzusetzen hat.

Man denke nur an die Grundpfeiler, welche in der sittlichen Kultur die Liebe und die Ehe bilden: sind sie etwa identisch? gibt es einen Satz der Identität für die reine Ethik und für ihre Anwendungen in der Welt der sozialen und politischen Verhältnisse?

Was tut nun aber die Ethik, um die Antinomie zwischen Liebe und Ehe auszugleichen? Die größte ihrer Leistungen in dieser Hinsicht ist die Zulassung, die sie dem Eherechte in der Scheidung gewährt. Positiveres vermag sie nicht zu leisten für diesen unaufhörlichen Konflikt.

Sollte es die Poesie aber bei diesem Konflikt bewenden lassen? Hier muß ihr nichts Geringeres in Gefahr kommen als das reine Gefühl selbst und das reine Selbst. Sie blieben hohl und unwahrhaftig, wenn das liebende Individuum in diesen

<!-- pdf:430 S.400 -->

schwierigsten Bedrängnissen des sittlichen Erdenlebens im Stiche gelassen würde.

Es ist ein neues Richteramt, zu dem sie sich hier berufen fühlen muß; eines Amtes der Gnade eben so sehr, wie der Verdammnis. Es wäre schlimm, wenn sie sich von der Hand der sittlichen Vorbedingung um Haaresbreite ablenken ließe. Es wäre aber auch um die Poesie schlimm bestellt, wenn sie es bei dem Spruche der Vorbedingung bewenden ließe. Die Verinnerlichung, die ihr obliegt, muß ein neues reines Selbst zur Wiedergeburt bringen vermöge des reinen Gefühls, welches nur ihr Werk ist, ihr reines eigenes, selbständiges Erzeugnis.

So läßt es sich verstehen, daß der Roman eine Mischform zu sein scheint, während er vielmehr seine Eigenart nicht herausbilden könnte, wenn er nicht mit den vorausgegangenen Formen der Poesie operieren dürfte. Er macht aber keineswegs einen Zusatz zur Lyrik, so wenig als zur Epik. Und er bedient sich auch nicht der dialektischen Kunstgriffe des Dramas; sondern die Abhängigkeit von den poetischen Vorformen ist nur eine scheinbare. Er ist nicht von ihnen selbst abhängig, sondern vielmehr nur von den sittlichen Problemen, welche auch dort die Vorbedingungen sind. Er ist das ästhetische Produkt komplizierter Kulturperioden; und die Komplikation ist allerdings bei ihm größer als selbst beim Drama. Aber der Zusammenhang mit den sittlichen Problemen ist, als sittliche Vorbedingung, für die primitivste poetische Form schon unerläßlich. So ergibt sich auch der Roman aus unseren methodischen Bestimmungen.

In allen diesen Grundformen hat sich nun die Poesie als die zweite innere Sprachform bewährt. Und da diese, als Gefühlssprache, der metrischen Elemente sich bedient, so ist zunächst ihr Zusammenhang mit der Musik in natürlicher Weise hergestellt. Worin diese selbständig wird, das ist durch die zweite Begriffssprache bedingt, welche in den Tonwerten begründet wird. Diese selbst sind zwar auch schon mit Gefühlsannexen begabt; aber die Grundlage, welche die Poesie auch für die Musik

<!-- pdf:431 S.401 -->

bildet, vollzieht sich in den Zusammenhängen, die sich zwischen dem Epos und dem Oratorium, der Lyrik und dem Liede, und endlich zwischen dem Drama und der Oper bilden.

Es ist allerdings charakteristisch für den Begriff des Romans, daß zwischen ihm und der Musik keine Verbindung denkbar scheint. Hieran ist nicht so sehr die Prosaform des Romans schuld, als vielmehr seine Kompliziertheit mit den sittlichen Vorbedingungen.

Die Poesie ist aber auch das Sprachgefühl der bildenden Künste. Wiefern dies auch für die Baukunst zutrifft, dürfte sich an dieser Stelle nicht gut erörtern lassen. Dagegen wird es unmittelbar klar bei der Plastik und der Malerei; und diese Klarheit des Zusammenhanges bezieht sich auch auf die poetischen Grundformen, bei der Malerei sogar auch einschließlich des Romans.

Es dürfte nun nicht unwichtig sein, diese Zusammenhänge bei der Plastik und der Malerei mit den Grundformen der Poesie festzustellen, und nicht unmittelbar mit den sittlichen Problemen selbst.

Die poetische Verinnerlichung muß vorangegangen sein, wenn die der bildenden Künste zu einer neuen Stufe der Reinheit emporsteigen soll. Die sittlichen Vorbedingungen aller Künste müssen erst im Schmelztiegel der Poesie ihre Läuterung durchmachen. In diesem gesteigerten Sinne wird die Poesie zur zweiten innern Sprachform aller Künste.
