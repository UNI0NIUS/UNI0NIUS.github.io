<!-- part 007: S. 136–167 -->

<!-- pdf:166 S.136 -->

Urform des Inhalts in der Urform des Bewußtseins anzusprechen.

Und die ganze Doppelheit des Inhalts kommt hier sogleich zum Vorschein. Wie die Umwelt vorausgesetzt wird, so wird die eigene Welt des Innern durch das Bewußtsein der Temperatur zugrunde gelegt. Es ist nicht zunächst der Inhalt des Äußern, der hiermit gesetzt wird, sondern vielmehr ausdrücklich zunächst das Innere selbst. Daher kommen auch Lust und Unlust hier schon zur Anlage, wenngleich auch nur in der Urform der Regung. Wie soll man nun diese Urform benennen?

## 1. Das Fühlen

Schon in unseren ersten Arbeiten zur Psychologie, in den sechziger Jahren des vorigen Jahrhunderts, haben wir den Terminus gewählt, den wir fortan beibehalten, und auch in der Ethik des reinen Willens begründet haben. Wir nennen diese Urform des Bewußtseins Fühlen.

Das Fühlen ist die Disposition des Bewußtseins, als solches, die zum Inhalt, wie die zum Innern. Der Inhalt selbst darf im Fühlen noch nicht vollzogen, sondern nur angelegt sein, wie etwa in Lust und Unlust, die nur hinsichtlich des Innern die Richtung auf den Inhalt bezeichnen. Da nun aber dieser Ursprung an der Temperatur angenommen wird, so ist das Fühlen das Fühlen der Temperatur. Die Temperatur aber ist eine Urform in der Bewegung des Nervensystems und des Organismus. So ist also das Fühlen der Temperatur die Urform des Bewußtseins, als Bewegung. Die Bewegung wird im Fühlen der Temperatur zur Urform des Bewußtseins.

Damit ist zuvörderst das Vorurteil zurückgeschlagen, daß nur die Empfindung das Erste des Bewußtseins sein könne, und daß, wenn Empfindung Bewegung sei, auch die Bewegung nur als Empfindung das Erste sein könne. Die Bewegung ist Fühlen. Das ist das Erste. Und damit wird auch für das Innere, sowie weiterhin für das Kunstgefühl sogleich ein anderer Ausgang eingeführt.

<!-- pdf:167 S.137 -->

Wenn die Kunst nur auf Empfindung beruhte, so müßte sie Nachahmung sein, und sie wäre dann nur, wie Croce die Formulierung nicht scheut: „Ausdruck des Eindrucks“. Sofern wir sie dagegen als Gefühl suchen, suchen wir sie zuvörderst als Ausdruck, als Entfaltung, als Enthüllung und Gestaltung des Innern. In diese Tragweite hinaus trifft die Urform des Fühlens bereits Vorsorge. Nicht Empfindung, sondern Fühlen ist das Erste. Und alle Entwicklung, nach allen Seiten des Bewußtseins hin, muß in dieser Urform die Anlage haben.

Wiederum bemerken wir, wie das Fühlen der Temperatur auch die Bewegung als Urform des Bewußtseins ansetzt. Und wie die reine Bewegung für die Physik reine Erzeugung ist, in analoger Weise bestimmt sie sich auch im Fühlen. Dieses ist freilich an und für sich ein bloßes Gehaben, aber dieses Gehaben entspricht ja den Eigenbewegungen des Nervensystems: mithin muß es ein Analogon zu diesen Bewegungen in sich selbst auch bedeuten.

Im Fühlen arbeitet sich der bloße Gehalt des Gehabens zu der Urform des Inhalts empor.

Es bildet sich hier eine Analogie zur reinen Erzeugung. Was ist diese erste Form des Inhalts, die sich aus dem Fühlen an den Tag ringt? Das ist eben die Bewegung. In ihr schafft sich das Fühlen seinen ersten Inhalt, die bloße Anlage zum Inhalt. In ihr entwickelt sich, vollzieht sich das Fühlen als Bewußtsein. Der Doppelsinn des Inhalts, das Äußere und das Innere, stellt sich in aller Deutlichkeit sogleich an der Bewegung dar. Sie schafft das Äußere, und sie schafft auch das Innere. Sie ist die Urform des Äußern, und ebenso auch die Urform des Innern.

So erzeugt das Fühlen das Bewußtsein, als Bewegung. So erzeugt das Fühlen auch die Bewegung, als Bewußtsein. Und der zweite Satz ist besonders für die Ästhetik ebenso grundlegend, wie der erste dies für die Logik ist. Wenn alle Kunsttätigkeit in Bewegungen sich vollziehen muß, so sind diese an sich Betätigungen des Bewußtseins. Bewegung waltet in allen Lebensgrundlagen des Bewußtseins, wie in der

<!-- pdf:168 S.138 -->

Atmung, so im Wachstum. Die Bewegung qualifiziert sich zur automatischen, zur Triebbewegung, zur Reflexbewegung, und sie geht endlich in die Willenshandlung ein.

Wir kennen schon von der Ethik des reinen Willens her die Frage: Wie kann diese Bewegung erzeugbar werden? Sie wird nicht gestellt im Sinne der Bewußtheit, sondern für die reine Erzeugung des Bewußtseins. Wie kann diese Bewegung als reine Erzeugung gedacht werden? Es genügt daher hierfür die Antwort nicht: sie rührt vom motorischen Zentrum her. Damit wird die Frage nur zurückgeschoben. Was nützt die Unterscheidung zwischen dem sensibeln und dem motorischen Zentrum, wenngleich sie anatomisch begründet sein mag; sofern sie auf den Ursprung der Bewegung gerichtet wird?

Beim sensibeln Zentrum beruhigt man sich doch nicht schlechthin für die Entstehung des Bewußtseins, sofern man nicht den Materialismus schlechthin annimmt, bei dem Begriffe des Zentrums, sondern man betrachtet dies nur als die negative, materielle Vorbedingung. Aber nun erst beginnt das Ressort des Bewußtseins, zu dem das sensible Zentrum nur hinzuleiten hat. Ebenso darf auch das motorische Zentrum nichts mehr zu bedeuten haben als diese Vorbedingung für die Aufnahme der Anregung zur Bewegung. Die Innervation kann nicht als die erste Anregung gelten; sonst müsste die Aufnahme der Reizbewegung im sensibeln Zentrum als die letzte gelten. Mithin kann das motorische Zentrum nicht den Ursprung des Bewußtseins der Bewegung zu vertreten haben. Als Bewußtsein kann die Bewegung ihren Ursprung nur im Bewußtsein selbst haben. Nur vom Bewußtsein aus kann die Bewegung auf das motorische Zentrum übergeleitet werden.

So bewährt sich am Fühlen der Temperatur die Bewegung als Urform des Bewußtseins. Die Bewegung wird an ihr als Erzeugung der Bewegung bestätigt. Und an der Erzeugung der Bewegung bewährt sich die Erzeugung des Bewußtseins im Fühlen.

<!-- pdf:169 S.139 -->

Bewußtsein ist Bewußtsein des Inhalts. Bewegung, als Bewußtsein erkannt, läßt die Bewegung als ersten Inhalt des Bewußtseins erscheinen, als Erzeugung des Inhalts; denn Bewußtsein ist Erzeugung des Inhalts. Bewegung ist der erste Inhalt, weil er der reine Inhalt ist; der keinen Inhalt zur eigenen Voraussetzung hat, sondern nur die Disposition zum Inhalt, welche das Fühlen bildet. Freilich ist die Eigentemperatur des Nervensystems und demgemäß das Fühlen von dem Zusammenhange mit der umgebenden Natur abhängig, aber die notwendigen Vorbegriffe enthalten die Anweisung, von diesem Zusammenhange abzusehen, um in den eigenen Bewegungen der Nerven eine Grundlage zu gewinnen für die Analogieform des Fühlens.

Diese Anlage zum Inhalt ist indessen noch nicht ein eigentlicher Inhalt. Wie er für das Innere nur ein Gehaben bedeutet, so für den äußern Inhalt nur eine Aktivität, aber nicht einen Erfolg, einen Ertrag derselben. Im Fühlen, zumal in seinem sich Emporringen zur Bewegung geht ein Hinstreben zum Inhalt vor sich, ein sich Entfalten, sich Erleben als Inhalt. All dies ist aber noch nicht der Inhalt selbst.

Ehe wir jedoch den eigentlichen Inhalt gewinnen können, müssen wir hier schon fragen: Was wird aus diesem Fühlen, wenn es sich zur Bewegung qualifiziert, und den ersten Ansatz zum Inhalt in ihr vollzogen hat? Wir dürfen doch diese Qualifikation des Bewußtseins, als Bewegung, mit Rücksicht auf die Erzeugung des Inhalts annehmen. Dies widerspricht nicht dem Gedanken, von dem wir ausgehen, daß das Bewußtsein Bewegung und daß die Bewegung Bewußtsein sei. Das Bewußtsein ist zu allererst aber Fühlen. Bewegung dagegen geht nach Außen. Aber sie geht eben von Innen aus, vom Fühlen.

So ist nur in der Qualifikation des ersten Inhalts die Bewegung vom Bewußtsein selbst zu unterscheiden; und nur in diesem Sinne stellen wir die Frage: Was wird aus dem Fühlen, wenn es sich als Bewegung qualifiziert hat? Die Frage geht nicht sowohl auf das Fühlen, als vielmehr auf die Bewegung: was wird aus der Bewegung, wenn sie als Anlage zum Inhalt des Bewußtseins im Fühlen sich qualifiziert hat?

<!-- pdf:170 S.140 -->

Man könnte die Antwort versuchen: Diese erste Anlage des Inhalts, welche die Bewegung bildet, bleibt bestehen. Diese Antwort enthielte jedoch einen Irrtum. Sie würde das Bewußtsein in seiner Erzeugung zugleich zur Auflösung bringen. Denn das Verharren dieses Ansatzes würde ja den Ansatz selbst vernichten, weil der eigentliche Inhalt doch eine Veränderung zur Voraussetzung haben muß. Diese aber kann nur von auswärts erfolgen. Wir fragen hier aber danach, was aus der Urform der Bewegung, sofern sie im Fühlen gelegen ist, nach dieser Qualifikation als Bewegung wird?

Die Antwort kann nur darin gefunden werden, daß die Qualifikation als solche wieder aufgehoben wird, und der Urstand des Bewußtseins als Fühlen lediglich mit Rücksicht auf die Bildung des Innern gedacht wird. Denn die Bewegung entspricht schon der Rücksicht auf die Außenwelt. Ohne diese Unterscheidung wird die Unterscheidung zwischen Bewußtsein und Bewegung überhaupt, und so auch zwischen Fühlen und Bewegung gegenstandslos. Die Frage erledigt sich also durch die Durchführung der Ansicht, daß das Fühlen in jeder Hinsicht, auf das Äußere, wie auf das Innere, die Urform des Bewußtseins ist, und daß sie, als solche, beständig bleiben muß: niemals aufgehoben werden kann.

Diese Bestimmung über den notwendigen Fortbestand des Fühlens enthält nun aber eine große Schwierigkeit. Wenn man das Fühlen nur subjektiv nimmt, nur in der Richtung von Lust und Unlust, so läßt sich diese Bestimmung wohl verstehen. Das bloße Stattfinden und Gehaben darf nicht aufhören und nicht abgebrochen werden; sonst würde die Anlage zum Bewußtsein vernichtet. Anders aber liegt die Sache doch mit Rücksicht auf die Bewegung, als die erste Anlage zum Inhalt. Wir hatten soeben gefragt, was aus dieser ersten Anlage werde, wenn sie sich vollzogen hat. Und wir hatten antworten zu müssen geglaubt, daß die Qualifikation sich wieder in das unqualifizierte Fühlen zurückbilden müsse. Das ist an sich eine Schwierigkeit, welche in dieser Unterscheidung nicht zu umgehen ist. Sie darf aber daran nichts ändern, daß der Ansatz zum Inhalt noch

<!-- pdf:171 S.141 -->

nicht Inhalt ist, aber Inhalt werden muß und werden kann. Bevor er aber dies wird, bevor die Inhaltsbildung in Vollzug tritt, muß er als Fühlen seinen Urstand zurückgewinnen.

Welchen Inhalt hat er dann, wenn von der Qualifikation als Bewegung abgesehen wird? Dann bleibt offenbar nur die Anlage zum Innern übrig. Darin aber scheint sich die Ansicht wieder zu bestätigen, daß Lust und Unlust dennoch eine Art von Inhalt seien, da es ja andern Inhalt jetzt nicht geben soll, ohne allen Inhalt überhaupt aber das Fühlen doch nicht gedacht werden kann. Wir werden sehen, daß diese Schwierigkeit nicht nur eine Verlegenheit bildet, sondern daß wir zu versuchen haben, ob sie uns nicht für die Bestimmung des ästhetischen Gefühls von Nutzen werden kann. Wir bleiben jetzt aber noch bei dem Anfang.

Wenn die Bewegung Ansatz zum Inhalt sein soll, so entsteht eine andere Schwierigkeit für die Erledigung der Frage: was wird aus der Qualifikation des Fühlens in der Bewegung? Die Schwierigkeit liegt in dem Begriffe des Inhalts des Bewußtseins. Ein Inhalt setzt einen Bestand voraus. Wie kann das Bewußtsein aber Bestand haben? Nur ein Ding hat Bestand. Das Bewußtsein ist kein Ding, sondern nur ein Vorgang, und als solcher zwar nicht nur ein Geschehen und Stattfinden, sondern auch eine Erzeugung. Immer weist die Methodik des reinen Bewußtseins nur auf eine Tätigkeit, nicht auf ein Ding für das Bewußtsein hin.

Daraus ergibt sich aber, daß auch der Ansatz zum Inhalt, den die Bewegung bildet, für das Bewußtsein nur den Vorgang der Erzeugung bedeuten kann, keineswegs aber darf sich darauf die Meinung stützen, als ob in solchem Ansatz des Inhalts das Bewußtsein sich dinghaft stabilierte, und solcherart etwa eine angebliche Substantialität anzunehmen vermöchte. Hiergegen soll uns die Unterscheidung schützen, welche an Bewegung und Bewußtsein im Fühlen gemacht wurde. Diese Unterscheidung bezieht sich nur auf Rücksichten in bezug auf den Doppelsinn des Inhalts; sie bedeutet nur eine Abstraktion am Fühlen, am Bewußtsein. Und nun soll uns diese Unterscheidung jetzt bei der vorliegenden Frage zur Klärung verhelfen.

<!-- pdf:172 S.142 -->

Die Unterscheidung vom eigentlichen Inhalt, auch in seinem Ansatze, ist besonders nötig mit Rücksicht auf die Bestimmung des ästhetischen Gefühls. Und gemäß der systematischen Bestimmung desselben wird daher auch bei den ersten Stufen des Bewußtseins ein Ansatz zum Gefühl erforderlich sein. Solcher Ansatz entspricht dem allgemeinen Sprachgebrauch, demzufolge auch ein sinnliches Gefühl angenommen wird, weil man die Unterscheidung zwischen dem objektiven Inhalt und dem subjektiven Innern nicht aufgeben kann. Dem Zwange dieses Gedankens entspricht die Annahme von Lust und Unlust als Gefühl. Es wäre ein Fehler in der Anwendung der Methodik, wenn wir den Aufbau des Bewußtseins nur nach der objektiven Seite versuchen wollten, und nicht ebenso nach der subjektiven.

Das vorliegende Problem schützt uns vor diesem Fehler. Wir sollen das ästhetische Bewußtsein als ästhetisches Gefühl erzeugen. Der Terminus des Gefühls muß eine Gemeinsamkeit der Beziehungen voraussetzen zwischen dem ästhetischen Gefühle und dem Grundgefühl von Lust und Unlust. Diese Voraussetzung kann dadurch nicht erschüttert werden, daß Lust und Unlust mit bedenklichen Fehlerquellen behaftet sind. Das ästhetische Gefühl ist immerhin Gefühl. Und so führt auf das ästhetische Gefühl auch die Frage hin: was wird aus dem Fühlen, wenn seine Qualifikation als Bewegung wieder zurückgenommen wird, so daß es wieder nur für den Aufbau des Innern gedacht wird? Das isolierte Fühlen weist dann auf das problematische Gefühl hin.

Wir haben es so ausgedrückt, daß die Qualifikation der Bewegung aufgehoben wird, so daß die Disposition des Fühlens ohne den Ansatz zum Inhalt isoliert bleibt. Indessen ist ja diese ganze Unterscheidung nur eine Abstraktion, um den Inhalt zur Erzeugung zu bringen. Im Grunde aber ist ja das Fühlen, als Analogon zu den Eigenbewegungen des Nervensystems, an sich schon Bewegung. Man kann daher eigentlich nicht fragen: was wird aus der Bewegung, wenn das Fühlen sich als Bewegung qualifiziert hat? Diese Quali-

<!-- pdf:173 S.143 -->

fikation ist nur eine Abstraktion. Das Fühlen selbst ist schon Bewegung. Insofern das Fühlen der Ursprung des Bewußtseins ist, ist es eo ipso der Ursprung der Bewegung; denn Bewußtsein ist Bewegung.

## 2. Das Bewegungsgefühl

Daraus folgt nun aber, daß diese beiden Abstraktionen, Fühlen und Bewegung, ihre Korrelation aufrecht erhalten müssen. Der Aufbau des Bewußtseins beginnt mit dem Fühlen, und geht zur Qualifikation des Fühlens als Bewegung über. Wenn nun aber der Aufbau fortgeführt werden soll, so muß auch rückwärts diese Korrelation in Kraft treten. Damit wird das Fühlen ein Annex zur Bewegung, zu der Bewußtseinsstufe der Bewegung.

Aber als dieser Annex ist der Terminus des Fühlens zu verändern. Denn er bedeutet ja nur den Ursprung des Bewußtseins, hier aber wird er als Annex gedacht, also als ein Nachtrag, ein Nachklang. Daher wird es notwendig, diese Veränderung durch einen besondern Terminus zu bezeichnen, der den Zusammenhang zwischen Bewegung und Fühlen kennzeichnet, und zwar die rückwärts gewendete Korrelation, die Bedeutung des Annex.

Dieser Verbindung entspricht das Bewegungsgefühl.

Hier tritt uns nun das Gefühl entgegen, im Unterschiede von der Reinheit, in der wir seine systematische Bedeutung zu ermitteln suchen. Dieses Gefühl, wie es hier auftritt, ist nicht bloß nicht als rein zu denken; sondern nicht einmal als isoliert. Es hat keine Selbständigkeit des Bewußtseins; es bezeichnet eine Verbindung; es ist schlechthin nur Relativität. Als eine solche Relativitätsstufe des Bewußtseins ist das Bewegungsgefühl auszuzeichnen. Diese Relativität ist notwendig; denn die Abstraktion der Bewegung fordert den Zusammenhang mit der des Fühlens.

Diese ist zwar zunächst die allgemeine Disposition des Ursprungs. Aber das Problem des Bewußtseins fordert

<!-- pdf:174 S.144 -->

es, daß der Ursprung für jede Stufe des Bewußtseins in Kraft bleibt. Er kann nicht bloß nachwirken; denn das Bewußtsein ist kein Ding, auf das eine Nachwirkung ausgeübt werden könnte; sein Bestand ist immer nur als ein Bestehen, und dieses nur als ein Entstehen zu denken; das Entstehen aber fordert ununterbrochen den Ursprung. Wir werden dies immerfort für den Aufbau des Bewußtseins zu beachten haben. Jetzt hat sich diese Einsicht geltend zu machen für die Relativität des Bewegungsgefühls. In diese Relativität mußte sich der Ursprung des Fühlens unaufhörlich verwandeln, nicht nur, was wir zuvor bedachten, weil die Abstraktion der Bewegung in die Abstraktion des Fühlens zurückgehen muß, sondern auch deshalb, weil das Fühlen niemals aufhören darf, wenn anders andere Qualifikationen des Bewußtseins erzeugbar werden sollen. So wird schon aus diesem Grunde die Relativität des Bewegungsgefühls nicht nur unvermeidlich, sondern auch positiv notwendig.

Wir dürfen zugleich nun aber auch die sachliche Bedeutung dieser Relativitätsstufe bedenken, für den Aufbau des Bewußtseins und insbesondere auch für das ästhetische Gefühl.

Wir sind von der systematischen Methodik darauf hingerichtet, das ästhetische Gefühl vom sogenannten sinnlichen Gefühle zu unterscheiden. Indessen werden wir nicht darauf ausgehen, das ästhetische Gefühl von Lust und Unlust, von allem Wohlgefühl und allem Wehgefühl gänzlich zu entleeren. In diesem Sinne ist die Reinheit keineswegs zu verstehen, wenngleich freilich das ästhetische Gefühl durchaus nicht das Glücksgefühl als seinen wesentlichen Bestandteil enthalten darf, wie dies bei den neueren Versuchen, die Ästhetik auf Einfühlung zu begründen, darauf schließlich hinauskommt.

Indessen die Unterscheidung ist nicht Scheidung. Ein Element des ästhetischen Gefühls darf das relative Gefühl durchaus bleiben; aber eben als relatives; das will sagen, als Annex zu einer Inhaltsstufe des Bewußtseins. Diesen Sinn gewinnt die Relativität.

<!-- pdf:175 S.145 -->

Das relative Gefühl ist selbst nicht Inhalt, sondern nur Annex zu einer Inhaltsstufe. Und seine erste Erscheinungsform, als Bewegungsgefühl, ist Relativität zum ersten Ansatz des Inhalts. Aber wie dieser Ansatz die erste Qualifikation des Bewußtseins ist, so ist auch diese erste Relativität eine Stufe des Ursprungs, eine Verwandlung des allgemeinen Ursprungs in seine Fortwirkung, die für jede neue Stufe des Bewußtseins erhalten bleiben muß, damit neuer Inhalt entstehen kann.

Jetzt aber war es nur um den Ansatz zum Inhalt zu tun, und, nachdem er bestimmt war, um seine Wiedervereinigung mit dem Ursprung schlechthin, ohne weitere Qualifikation. Doch bildet die Relativität selbst wieder eine Art von Qualifikation. Das ist die Illusion des Inhalts, die im Gefühl, im bloßen Gehaben, in Lust und Unlust nun einmal liegt. Wir erkennen jetzt schon den Grund des Irrtums auch positiv. Der Schein des Inhalts, der für das relative Gefühl besteht, rührt von dem Inhalt oder von dem Ansatz zum Inhalt her, zu dem er das Annex ist. Dieses Annex, diese Relativität ist notwendig, aber darum noch nicht an sich ein Inhalt. Das Wohlgefühl ist eine notwendige Relativität, aber kein selbständiger Inhalt. Im Bewegungsgefühle liegt in der Bewegung der Ansatz zum Inhalt.

Das ist der Sinn der Betonung, wie sie jetzt allgemein angenommen wird. Wir können sie schon für die Bewegung annehmen, da wir ja schon Klarheit darüber gewonnen haben, daß es sich nur um die Verteilung von Abstraktionen handelt. Der Irrtum wird aber besser ausgeschlossen durch die sprachliche Bezeichnung der Relativität, bei welcher das Gefühl zugleich als eine Relativitätsstufe gekennzeichnet wird. Diese Relativität des Gefühls mag auch ein Bestandteil sein im ästhetischen Gefühle; aber ein bestimmender kann sie nicht sein; geschweige daß sie mit dem ästhetischen Gefühle gleichgesetzt werden dürfte.

Wir lassen nun aber diese Bedeutung des Annex im Begriffe des relativen Gefühls auf sich beruhen, und gehen weiter in der Bestimmung des Inhalts. Die Bewegung

<!-- pdf:176 S.146 -->

bildet nur den Ansatz zum Inhalt. Der eigentliche Inhalt entsteht erst mit der Empfindung.

## 3. Die Empfindung

Wie entsteht die Empfindung? Die Frage geht nicht auf die Bewußtheit; sie bedeutet: wie ist die Empfindung, als Stufe des Bewußtseins, erzeugt worden? Diese Erzeugung ist an sich eine Sache der Logik, nicht nur weil die Erzeugung von ihrer Methodik abhängt, sondern auch, weil nur die Logik das Problem der Empfindung aufstellen kann. Innerhalb der Erzeugungsweisen der reinen Erkenntnis, und zwar innerhalb der methodischen Stufen der Forschung, taucht die Empfindung auf mit dem Anspruch einer Urteilsart, weil die Urteilsart der Wirklichkeit den Anspruch der Empfindung anzeigt. Das schwierigste Problem entsteht damit für die Logik.

Unter allen Besitztiteln der Erkenntnis bildet die Empfindung den kompliziertesten, dessen Rechtfertigung den ganzen sachlichen Apparat der reinen Erkenntnis voraussetzt. An der Empfindung sollte man es einsehen lernen, daß die Psychologie keine Selbständigkeit haben kann, es sei denn eine systematische; daß sie daher nicht selbständig anfangen kann. Denn schon ihr erster Begriff, der der Empfindung, bleibt erschlichen, wenn sie nicht von der Logik seine Rechtfertigung, wenn sie nicht von ihr schon seine Begriffsbestimmung entnimmt.

Die Empfindung enthält, ihrer logischen Bedeutung gemäß, den Hinweis auf die Wirklichkeit in sich; mithin beginnt in ihr die Erzeugung des eigentlichen Inhalts.

Die Erzeugung des Inhalts hat aber schon in der Bewegung, als dem Ansatz zum Inhalt, ihren Anfang genommen. Die Erzeugung der Empfindung muß daher auf ihren Ursprung im Fühlen und in dessen Qualifikation, als Bewegung, zurückgehen. Wir dürfen jetzt diese beiden Abstraktionen zusammenfassen. Die Erzeugung der Empfindung muß auf das

<!-- pdf:177 S.147 -->

Bewegungsgefühl zurückgehen. Wie kommt nun aber der Fortschritt heraus bei diesem Rückschritt?

Der Ansatz zum Inhalt wurde gefunden durch eine Unterscheidung der Abstraktionen Bewußtsein und Bewegung am Fühlen. Diese Unterscheidung vollzog sich in der Korrelation. Unterscheidung hat sich somit als das erste Mittel erwiesen, den Weg zum Inhalt anzusetzen. Unterscheidung ist auch fernerhin als Mittel im Aufbau des Bewußtseins anzuwenden. Denn Unterscheidung ist das Mittel zur Ausbildung neuer Abstraktionen. Und nur in solchen Abstraktionen kann der Aufbau des Bewußtseins versucht werden. Unterscheidung ist aber schon deshalb das erforderliche Mittel, weil jede neue Stufe doch immer auf einer Unterscheidung von dem Ursprung des Fühlens beruht, welches Fühlen als Ursprung in den Relativitätsannexen der vorhergehenden Stufen erhalten bleiben muß. Dies ist der positive Sinn des relativen Gefühls.

Im Unterschiede von der Bewegung bezeichnet nun die Empfindung den Anfang des eigentlichen Inhalts. Und wir befinden uns im Einvernehmen mit der alten griechischen, in der modernen physiologischen Psychologie wieder erneuerten Ansicht, nach der alle Empfindung Entwicklung aus der Tastempfindung ist. Die Tastempfindung aber ist Bewegung auf den Tastflächen. Dies haben wir schon auch nach seiner Bedeutung für die Entstehung der Ästhetik betrachtet.

Das Empfindungsgefühl bildet nun aber für diese Entwicklung der spezifischen Empfindung eine Vermittlung, welche sonst entbehrt werden müßte; welche freilich der Sensualismus nicht vermißt. Wie kann die Empfindung aus der Bewegung entstehen, welche selbst als Empfindung, nicht als Fühlen gedacht wird? Wie kann eine Empfindung aus einer andern von gleicher Art entstehen? Und wie kann gar eine Empfindung aus einer andern Art von Empfindung entstehen? Diese Fragen werden zurückgedrängt, oder sie treten gar nicht hervor, weil die Empfindung, in Analogie zu ihrem materiellen

<!-- pdf:178 S.148 -->

Substrate selbst als ein isoliertes Ding illusorisch gedacht wird, und weil zwischen diesen Dingen, diesen dinghaften Gebilden des Bewußtseins das Bewußtsein selbst als ein agierender Faktor mitgedacht wird. So nachhaltig bleibt die mythologische Vorstellung von der Seele, die an ihrem Webstuhl arbeitet, und in selbständigen Akten der freien Überschau ihre Gebilde abteilt, wie sie als selbständige Gebilde sie zur Schöpfung bringt. Wenn diese Art von Neubildung des Bewußtseins schon dem Begriffe der Entwicklung widerspricht, so um so mehr der Methodik der Erzeugung. Daher kann die Empfindung nicht entstehen aus einer andern Empfindung. Sie würde damit neu entstehen.

Die Empfindung entsteht aus den Bewegungsgefühlen. Dieses ist die Voraussetzung für die Möglichkeit des Entstehens einer neuen Stufe des Bewußtseins in der Empfindung. Die neue Stufe darf nur ihrer begrifflichen Bedeutung gemäß eine neue sein. Für den Aufbau des Bewußtseins vermittelst der Erzeugung darf die Neuheit den Zusammenhang mit dem Ursprung des Bewußtseins, der für jede neue Stufe in Kraft bleiben muß, nicht aufheben. Durch das Bewegungsgefühl wird dieser Zusammenhang hergestellt und festgehalten. So wird die Empfindung eine neue Stufe des Bewußtseins auf dem methodischen Grunde der Erzeugung. Und jetzt darf sie den Inhalt vertreten, den sie ankündigt, und den sie als logischen Anspruch zu vertreten hat. Jetzt entspricht dieser logischen Vertretung auch ihre psychologische Definition. Das Bewegungsgefühl ist die notwendige und zulängliche Vorstufe für die Empfindung.

Zulänglich freilich nur als Vorstufe. Die Stufe selbst beruht noch auf einer andern positiven Voraussetzung. Die logische Bedeutung der Empfindung ist der Hinweis auf den Inhalt der Wirklichkeit. Diesem Schwergewicht muß auch die psychologische Bestimmung gerecht werden. So wird die Empfindung zur spezifischen Sinnesempfindung, gemäß den sinnlichen Qualitäten, die an dem physikalischen Körper physiologisch unterscheidbar werden.

<!-- pdf:179 S.149 -->

Diese Abstraktion des Inhalts an der Empfindung muß nun aber ebenso wieder mit dem Ursprung des Fühlens vereinbart werden, wie wir an der Bewegung dies zu leisten hatten. Wenn eine Art von Empfindung in eine andere Art von Empfindung übergehen soll, wenn eine Empfindung einer Art auch nur auf eine Empfindung von derselben Art folgen soll, so darf niemals die Vermittlung des relativen Gefühls fehlen. Weder kann sich die Gesichtsempfindung aus der Tastempfindung entwickeln, noch auch eine Tastempfindung aus der andern, ohne daß das relative Gefühl dazwischen läge, aus dem die Entwicklung erfolgen kann, während sie sonst eine schöpfungsartige Neubildung wäre. Immer muß das relative Gefühl die Vermittlung bilden.

## 4. Das Empfindungsgefühl

Wenn man dieses den Ton der Empfindung nennt, so macht das Empfindungsgefühl dagegen klar, daß der Ton der Empfindung einen Fortbestand haben kann über den Inhalt der Empfindung hinaus. Das wäre sonst ein Wunder, welches dagegen bei unserer Terminologie sich auflöst in eine schlichte Forderung, die unerläßlich ist. Wenn eine neue Empfindung auch eine von derselben Art, soll entstehen können, so kann sie nur aus dem Empfindungsgefühl der voraufgehenden Empfindung entstehen.

Die Empfindung ist nicht die Unterscheidung von einer Empfindung. Dann wäre die Unterscheidung kein Mittel der Erklärung, noch der Beschreibung. Die Empfindung ist Unterscheidung vom Empfindungsgefühl der voraufgehenden Empfindung. Das Empfindungsgefühl hat Bestand, auch wenn die Empfindung vorüber ist. Und es muß Bestand haben, wenn eine neue Empfindung soll entstehen können. Wie kann dieser Bestand gedacht werden? So darf man nur nach der Methode der Erzeugung fragen, und diese erteilt die bündige Antwort: für die Entstehung der Bestand. In anderem Sinne würde die unzulässige Frage der Bewußtheit

<!-- pdf:180 S.150 -->

hier entstehen, wie sie auch für die Empfindung nur unzulässigerweise entstehen kann.

Eine andere Bedeutung steht noch dem Empfindungsgefühl zu, welche besonders für das ästhetische Gefühl von Belang bleibt.

Man legt der betonten Empfindung, dem Gefühl, Macht, Dauer, Stärke bei. Wir können hier darauf verzichten, für den Begriff der Empfindung die Möglichkeit seiner Verbindung mit Größenbegriffen zu untersuchen. Wir können diese Belehnung mit den angegebenen Begriffen von der Empfindung auf das Empfindungsgefühl übertragen. An diesem bilden sie keinen Widerspruch. Das Empfindungsgefühl darf Stärke und Dauer haben. Denn durch die Dauer wird der Fortbestand der relativen Zwischenstufe zwischen zwei Empfindungen abgemessen. Durch die Stärke wird die Übermacht des Fühlens über den Inhalt an dem Empfindungsgefühle bezeichnet. So ist es die Erfüllung der relativen Bewußtseinsstufe, welche durch die Stärke bezeichnet wird, als ob eine Erschöpfung des Bewußtseins mit diesem Inhalt und durch ihn vollführt würde. Es ist aber nicht so sehr die Erschöpfung mit dem Inhalt, als vielmehr mit dem Empfindungsgefühl, welche den Eindruck der Stärke macht. Auch hier liegt nicht Bestimmtheit des Inhalts im Gefühl; die Verbindung mit dem Inhalt beruht nur auf der Verbindung des Gefühlsannex mit der Empfindung.

Wir müssen hier schon eine Bezugnahme machen auf das ästhetische Gefühl. Die Kunstrichtungen werden oft unterscheidbar je nach dem Übergewicht, welches in ihnen das Empfindungsgefühl erlangt, und je nach dem Verhältnis, in dem die Stärke oder die Deutlichkeit in ihm vorwaltet. Die Deutlichkeit beruht auf der Unterscheidung des Inhalts, die Stärke dagegen auf der fortdauernden Wirkung des Gefühlsannexes, welche die Unterscheidung des Inhalts erschwert, schon seine Gestaltung hemmt. Der Inhalt ist immer nur der Inhalt der Empfindung. Das Empfindungsgefühl kann nur Gehalt haben. Die Stärke ist nicht Inhalt. Diese Unterscheidung gilt schon für das Empfindungsgefühl; wieviel mehr muß sie zu gesteigerter

<!-- pdf:181 S.151 -->

und verfeinerter Durchführung kommen beim ästhetischen Gefühl, welches in den beiden Hauptarten des Bewußtseins Stufen zur Voraussetzung hat, zu denen das Empfindungsgefühl gleichsam nur eine Vorstufe ist. Aber als solche bleibt es auch in dem reifen ästhetischen Gefühl erhalten und wirksam, wie kein ästhetisches Bewußtsein der Empfindungen, noch mithin der Empfindungsgefühle entraten kann.

Daher entsteht für die Reife und Reinheit des ästhetischen Gefühls immer der Konflikt mit den Empfindungsgefühlen, und es ergibt sich aus ihrem Begriffe, als einer Relativitätsstufe, und aus diesem ihrem Verhältnis zum Inhalt: daß der ästhetische Inhalt nicht in ihnen begründet werden kann. Es ist nur die allgemeine Disposition des Bewußtseins, wie sie in Lust und Unlust verlautet, die auch da im Empfindungsgefühle laut wird, wo dieses als Bestandteil des ästhetischen Gefühls zur natürlichen Mitwirkung kommt. Wenn anders nun aber in diesem relativen Gefühle die Reinheit des ästhetischen Gefühls nicht begründet werden kann, so darf die Urgewalt des Fühlens, die allgemeine Disposition des Bewußtseins nicht vorlaut werden bei dieser Konstruierung des ästhetischen Gefühls. Hier liegen die Gefahren in der Bedeutung dieser allgemeinen Disposition des Bewußtseins in Lust und Unlust, die im Empfindungsgefühle drohend werden. Denn Lust und Unlust bleiben nun einmal die unsäglichen Wendungen, in denen das Empfindungsgefühl sich regt, als ob es in ihnen sich qualifizieren könnte.

Das Empfindungsgefühl in seiner Relativität hat sich nunmehr als eine selbständige Stufe des Bewußtseins erwiesen. Es bildet das Band zwischen Empfindung und Empfindung, und zwar ebenso zwischen Empfindungen derselben Art, wie von anderer Art. In dieser Annahme ist jedoch noch eine große Schwierigkeit versteckt. Wenn das Empfindungsgefühl die Möglichkeit begründet, daß aus einer Empfindung eine andere entstehen kann, so muß diese Begründung eingeschränkt werden auf die Entstehung der zweiten Empfindung, insofern sie ebenso isoliert gedacht wird, wie die erste. Bei

<!-- pdf:182 S.152 -->

solcher notwendigen Isolierung kann jedoch das Bewußtsein nicht stehen bleiben; bei ihr würde es nicht zur Ausgestaltung des Inhalts kommen können. Eine Empfindung an und für sich ist noch kein Inhalt; ebenso wenig die zweite, wie die erste. Der Inhalt in seiner eigentlichen Bedeutung entsteht erst aus zwei Empfindungen, sofern diese in ein Verhältnis zu einander treten. Auf dem Verhältnis erst beruht, in ihm erst vollzieht sich der Inhalt. Diesen Grundgedanken für die Bestimmung des Inhalts begründet die Logik.

Es entsteht daher die große Frage: wie kommt es zu diesem Verhältnis? Und damit entsteht die Vorfrage: wie kommt es zu der Mehrheit von Empfindungen? Denn ohne daß vorher diese Mehrheit der Empfindungen die zwei Empfindungen, als zwei, erzeugt worden sind, kann ein Verhältnis an ihnen nicht zur Bildung kommen.

## 5. Das Denken

So sind wir auf einmal zu den Aufgaben des Denkens gekommen. Die Empfindung selbst hat das Denken herbeigerufen; nicht zwar die Empfindung in ihrer Einheit, aber in ihrer Zweiheit. Das hat schon Plato gelehrt an diesem Beispiel der Zweiheit selbst. Freilich geht die Frage auf die Einheit der Empfindung zurück. Indessen diese Frage dürfte die Logik allein angehen; für den Aufbau des Bewußtseins, den wir hier verfolgen, genügt die Anknüpfung an das Problem der Mehrheit. Die Mehrheit tritt uns somit als die erste Aufgabe an dem Material der Empfindung entgegen, in deren Bearbeitung die erste Leistung des Denkens bestehen muß. Wiederum dürfen wir nicht fragen, wie das Denken in den Urgründen des Bewußtseins dies bewirken könne. Das wäre die Frage nach der Bewußtheit. Wir können nur der Methode der Erzeugung gemäß fragen, welche Erzeugungsweisen für diese Aufgabe im Denken, als Denken, ans Werk treten.

Schon bei der Entstehung der Empfindung aus dem Fühlen wurde die Unterscheidung geltend gemacht. An diesem ersten Punkte mag sie zulänglich sein, weil sie da nur als Reaktion des Fühlens auf den Reiz von außen die

<!-- pdf:183 S.153 -->

Bedeutung des Bewußtseins vertritt. Dieses Bewußtsein kann allenfalls noch wie ein Reflex gelten. Es ist ja nur der erste Anfang des Bewußtseins aus seinem Ursprung. Die Unterscheidung ist hier eben nur Empfindung, noch nicht Denken. Sie ist, sie vertritt nur die Abstraktion einer Empfindung; jetzt aber handelt es sich um das Problem von zwei Empfindungen als Zweiheit. Genügt auch für diese Stufe des Bewußtseins noch die Unterscheidung, die doch immer den Nebensinn des Unterschieds hat?

Die Unterscheidung genügt schon deshalb nicht in ihrer negativen Bedeutung, nämlich als Trennung der andern Empfindung von der einen, weil diese Trennung selbst ja nicht genügt, weil es vielmehr auf die Verbindung ankommt, welche die Zweiheit darstellt. Wäre denn etwa die Unterscheidung selbst schon Verbindung?

Das Denken ist schon früh in der griechischen Philosophie vornehmlich als Verbindung, als Synthesis gedacht worden. Aber freilich die Verbindung allein genügt auch nicht; die Zweiheit ist nicht allein Verbindung, sondern vorerst Trennung. Und es entsteht die Frage, ob nicht dennoch die Trennung die ursprüngliche Leistung bleibt, von welcher auch die Verbindung abhängt, in der sie selbst schon einen Teil ihrer Bedeutung vollzieht, wenn auch nur einen Teil. Diese Bedeutung der Trennung, welche selbst die Verbindung zu vollführen hat, kann nicht in der Unterscheidung zur Erkenntnis kommen. Die Unterscheidung bringt das Problem gar nicht zur Formulierung. Sie setzt die Elemente schon voraus, unter denen sie die Scheidung vollzieht. Dagegen kommt es darauf an, zu erkennen, daß die Elemente selbst, in ihrer Mehrzahl, durch die Unterscheidung erst erzeugbar werden. Das geht über den Sinn der Unterscheidung hinaus.

Die Logik der reinen Erkenntnis gebraucht daher den Terminus Sonderung, welche als Ersonderung zur Ausführung kommt. So werden in der Sonderung die Elemente erzeugt, ersondert. Und damit ist zugleich die Verbindung vorbereitet. Aber auch die Verbindung entspricht nicht der Methodik der Erzeugung. Vereinigung, Einheit-

<!-- pdf:184 S.154 -->

bildung ist der angemessene Ausdruck, den daher die griechische Philosophie schon aufgestellt hat. Die Mehrheit ist, als solche, eine Einheit. Sie ist nicht allein Sonderung, sondern ebenso sehr Vereinigung.

Einheit bezeichnet die Aufgabe des Denkens. Verbindung ist ein bildlicher Ausdruck, der das Problem nicht zulänglich bezeichnet. Vereinigung bedeutet die Einheit in der Mehrheit, die Mehrheit als Einheit. Und daher schließt sie auch die Sonderung in sich. Denn die Einheit der Mehrheit ist nicht Verbindung, Zusammenfügung, noch all dergleichen Bindungswerk, sondern sie beruht auf der Erzeugung der Mehrheit, auf ihrer Ersonderung unter dem Leitbegriffe der Vereinigung zur Mehrheit.

Das Alles ist Denken, reines Denken. Aber die Logik bedarf mancher Zurüstungen, um diese Aufgabe des Denkens zur Lösung zu bringen. Hier bewährt sich nun ganz unverkennbar unsere These von der systematischen Bedeutung der Ästhetik. Die Kunstwissenschaft selbst hat sich gedrungen gefühlt, in diese Tiefen der wissenschaftlichen Logik hinabzusteigen. Sie ist nicht etwa bei der sogenannten Psychologie stehen geblieben, sondern sie hat Erörterungen aufgenommen, welche das eigenste Gut der Logik sind, wenn nicht gar der Metaphysik in ihrem wissenschaftlichen Sinne. Von dem Begriffe der Bewegung ist sie fortgetrieben worden zu den Begriffen von Raum und Zeit, und selbst zu dem Begriffe der Mehrheit. Sie verläßt damit die alleinseligmachende Methode der Entwicklung, die mit Vergleichung, Kombination und Assoziation und allen diesen stumpfen und blinden Bindemitteln operiert, die das eigentliche Problem immer nur verschleiern. Die Mehrheit selbst, nichtsdestoweniger als Einheit zu denken, bildet hier das ausdrücklich anerkannte Problem.

Das Mannigfaltige der Anschauung, welches noch die Schwäche in Kants Disposition des Erkenntnisproblems bildet, wird damit zurückgewiesen. Und damit fällt auch der letzte Grund für die Unterscheidung von Sinnlichkeit und Verstand. Die Sinnlichkeit kann nicht mehr

<!-- pdf:185 S.155 -->

das Mannigfaltige liefern, sofern dieses als Mehrheit zum Problem wird. Mehrheit bedeutet reine Mehrheit, erzeugte Mehrheit. Diese reine Mehrheit darf als Einheit gedacht werden, wie sie dies muß, wenn anders die Sonderung auf der Vereinigung beruht, unter deren Leitung sie sich zu vollziehen hat. Da können also die alten Schlagworte des Sensualismus und Empirismus nicht mehr helfen, sie werden in ihrer Hinfälligkeit erkannt und der Apriorismus und Idealismus der Erkenntnis wird nunmehr herangezogen. Von der Kunstwissenschaft kann jetzt die zunftmäßige Logik lernen, wie sie ihr Handwerk zu betreiben hat. Verfolgen wir diese Aufgabe nun weiter nach unserer Methodik.

Das Empfindungsgefühl ist von gleicher Art, wie das Bewegungsgefühl. Die Bewegung ist auch schon Inhalt, Ansatz zum Inhalt. Und die Empfindung enthält den ausgeführteren Inhalt, aber auch nur noch im Ansatz; denn erst die Mehrheit von Empfindungen kann den Inhalt zur Ausführung bringen. Diese Mehrheit aber ist nicht mehr Empfindung, die eben nur jenen Ansatz zur Ausführung bedeutet. Die Mehrheit ist Denken. Denken bedeutet die Erzeugung des Inhalts, den Vollzug seiner Ausführung. Empfindungsgefühl und Bewegungsgefühl sind daher auch auf den Inhalt hin als homogen zu betrachten, und gänzlich sind sie dies im Annex des Gefühls.

Wenn wir nun die neue Leistung des Bewußtseins, als Denken, in die Mehrheit setzen, welche an den Empfindungen sich zu bilden hat, so sind wir zunächst an das Empfindungsgefühl gewiesen, in welches jede Empfindung für sich einzumünden hat. Dieses Empfindungsgefühl aber ist sowohl der Empfindung, wie erst recht dem Gefühlsannex nach, zugleich Bewegungsgefühl. In diesem aber ist, eine natürlichere Quelle anzusprechen für die Entstehung der Mehrheit. Mehrheit ist der erste ausgeführte Inhalt. Bewegung aber ist die Quelle für den Ansatz zum Inhalt, aus der die Empfindung selbst sich ableitet. Im Bewegungsgefühl ist daher die Brücke zu

<!-- pdf:186 S.156 -->

suchen für die Verbindung von Empfindung und Empfindung.

Dieses Bewegungsgefühl ist nun aber auch in dem Empfindungsgefühle wirksam. Denn Empfindung ist Bewegung. Und wenn sie nicht lediglich als Reaktion und als Reflex gewertet werden muß, so verdankt sie dies der Bewegung, welche, als solche, immer eine Regung und Erzeugung des Bewußtseins ist. So führt uns die Frage nach der Erzeugung der Mehrheit von Empfindungen auf die Erzeugung des Bewußtseins in der Bewegung zurück; genauer auf das Bewegungsgefühl.

Die Ethik des reinen Willens hat, um diese Reinheit zu begründen, an der Bewegung, als welche der Wille sich zu vollziehen hat, einen reinen, intellektuellen Faktor zu ermitteln gehabt, und sie hat diesen als Tendenz ausgezeichnet. In der Tendenz wirkt das Empfindungsgefühl als Bewegungsgefühl, wirkt der ursprüngliche Bewegungscharakter des Bewußtseins in das Empfindungsgefühl durch. Der Annex des Gefühls enthält diesen ursprünglichen Wert des Bewußtseins als Bewegung in sich. Wenn jetzt die Frage gestellt wird: wie kann die Mehrheit von Empfindungen zur Entstehung kommen? so kann nunmehr die Antwort lauten: sie ringt sich aus dem Bewegungsgefühle heraus, welches in dem Empfindungsgefühle, seinem Gefühlsannex nach, enthalten ist.

Dieses Sichherausringen ist nicht mehr bloß die allgemeine Regung der Bewegung, sondern in ihm wird, der Aufgabe der Mehrheit gemäß, dieses Hinausstreben zugleich zu einer Doppelheit. Denn für einmal hätte man seiner ja nicht bedurft; da hätte man sich an dem Bewußtsein der Bewegung, an dem Fühlen schon begnügen können. Die Tendenz bedeutet die Mehrheit der Tendenzen; wie sie ja für die Entstehung der Mehrheit erdacht wird. Sie ist Plural in ihrem Begriffe. Sie bedeutet das Fortstreben von Tendenz zu Tendenz, mithin das Fortstreben von einer Empfindung zur andern.

Wenn nun das Problem der Mehrheit, nach der Methodik der Erzeugung, die Ersonderung und die Vereinigung fordert,

<!-- pdf:187 S.157 -->

so werden beide Richtungen in der Erzeugung der Mehrheit durch die Tendenz verfolgt. Das Hinausstreben erzeugt die Sonderung, zumal in seinem Fortschritt von Tendenz zu Tendenz. Die Tendenzen erzeugen die Sonderung. Und hinwiederum erzeugen sie in diesem ihrem unaufhaltsamen Fortschritt zugleich die Vereinigung. So bilden sie den Ursprung der Reihenform, in der aller Inhalt des Bewußtseins sich vollzieht. Aber die Reihe ist selbst nur ein Ausdruck für die Mehrheit, außer sofern sie unendliche Reihe ist, was hier nicht in Betracht kommt.

In der hergebrachten Terminologie stellt sich die Reihe in Zeit und Raum dar, mithin in den Bildern des Nacheinander und des Nebeneinander. Sie sind beide nur Bilder; denn sie lassen zwei Fragen unerörtert: erstlich woher kommen die Elemente, die so geordnet werden? Und zweitens: wie kommen diese Ordnungen zur Erzeugung? Man sieht wiederum, daß Zeit und Raum nicht vorangestellt werden dürfen vor den Erzeugungsweisen des Denkens; sie können nichts Besonderes sein, da sie die eigensten Aufgaben des Denkens in sich enthalten.

## 6. Anwendungen in der Kunstwissenschaft

Die Kunstwissenschaft bringt diese Richtung der reinen Logik zu einer trefflichen Bestätigung. Sie verschmäht allmählich die empiristischen Stichworte und bleibt nicht mehr psychologisch bei dem Menschen und seinem Körpergefühle stehen. Sie führt den Rhythmus auf die Zeit zurück, und Symmetrie und Proportionalität auf den Raum. Vielmehr wird es so zur Klarheit gebracht, daß im Rhythmus sich die Zeit vollzieht, wie in Symmetrie und Proportionalität der Raum. Alle diese Grundbegriffe der Kunstwissenschaft aber sind Bewegungsgefühle. Darin allein beruht ihr Inhalt, daß sie Bewegung erzeugen, vielmehr daß sie den Fortgang von Bewegung zu Bewegung erzeugen.

<!-- pdf:188 S.158 -->

Wie die Tendenz die Mehrheit der Tendenzen in sich schließt, so beruht der Rhythmus auf dieser Fortspinnung des Bewegungsgefühls. Und Symmetrie und Proportionalität erzeugen ein Nebeneinander, indem sie das Nacheinander messen und auf Grund dieser Messung und in ihm eine Vereinigung des Nacheinander zustande bringen. So entsteht aus der Tendenz, vielmehr aus ihrer in ihrem Begriffe involvierten Mehrheit die Erzeugung der Mehrheit selbst nach ihren beiden Richtungen, als Sonderung und als Vereinigung. Die Ersonderung ersteht in dem Hinausstreben, und die Vereinigung in dem Fortschritt dieses Hinausstrebens, der in ihm selbst vorausgesetzt wird.

Wir dürfen auch noch auf das Moment hinweisen, welches die Logik der reinen Erkenntnis in der Zeit ausgezeichnet hat, insofern sie die Antizipation als ihre Grundtätigkeit nachzuweisen sucht. Die Antizipation macht es deutlich, daß die Zeit keineswegs eine Ordnung der Folge des Nacheinander ist, sondern vielmehr der Erzeugung des Folgens. Nicht auf die Vergangenheit folgt die Zukunft, sondern der Erzeugung der Zukunft folgt die der Vergangenheit nach. Die Sonderung geht von der Zukunft aus, und erst von ihr ab vollzieht sich die Vereinigung in dieser Ordnung der Folge. Ähnliche Änderungen ergeben sich auch an der Ordnung des Raumes, insofern sie nicht schlechthin im Nebeneinander genommen wird, sondern gemäß der Allheit einer unendlichen Reihe.

Dem Verhältnis, welches sonach zwischen Zeit und Raum besteht, kann man versucht werden, auch dasjenige zwischen Symmetrie und Proportionalität einerseits und Rhythmus andererseits analog zu bilden. Die Sonderung und Vereinigung von zwei Elementen, und der Tendenz gemäß, einschließlich ihrer Wiederholung, dies bedeutet die Grundform des Rhythmus. Der Rhythmus aber ist die ästhetische Grundform. Modifikationen derselben sind Symmetrie und Proportionalität. Symmetrie ist die Paarung nach rechts und links, die wiederum nur eine Richtungsform der Urpaarung des Rhythmus ist. Und Proportionali-

<!-- pdf:189 S.159 -->

tät ist die Schichtung solcher Paarungen aufwärts und abwärts.

In dieser Richtung des Bewegungsgefühls entsteht die Tiefe, die dritte Dimension des Raumes. Es ist aber gar nicht der Rumpf, der für diese Messung die Ausgangseinheit bildet, so wenig wie für die Symmetrie, sondern es ist der Rhythmus selbst, demzufolge die Tendenz zu Tendenz fortstrebt. Diesem Begriffe des Rhythmus entspricht auch die Antizipation, die das Wesen der Zeit ausmacht. Der Rhythmus erweist sich demnach als eine tiefere Einheit, als welche der Rumpf zu bilden vermöchte. Seine Einheit, der Einklang, den er vollzieht, der seine Aufgabe und sein Inhalt ist, liegt vielmehr in der Einheit des Menschen selbst, welche im Rhythmus sich anbaut.

Es zeigt sich so, daß das Bewegungsgefühl, oder in ihm das Empfindungsgefühl selbst in der Mehrheit, welche kraft der Tendenz sein Werk ist, zugleich den Inhalt des Bewußtseins zur Erzeugung bringt; den Inhalt, der in der isolierten Empfindung noch nicht erzeugt wird. Wir haben bei der Betrachtung der ästhetischen Grundformen diesen Inhalt vornehmlich in seiner subjektiven Richtung gefunden. Aber mehr noch als die Zeit macht es ja der Raum unmittelbar deutlich, daß auch in objektiver Bedeutung der Inhalt so zur Erzeugung gelangt. In dieser objektivierenden Richtung liegt die vorzügliche Bedeutung des Denkens. Das Denken erzeugt das Objekt.

Man pflegt die Objektivierung auch als Vorstellung zu bezeichnen. Immerhin besagt die Vorstellung schon mehr als die Empfindung, die an sich nur Änderung im Zustand, im Stattfinden des Bewußtseins ist. Aber die Vorstellung, wenngleich in dem Worte die Objizierung bezeichnet wird, kann doch auch, wie daher auch der Ausdruck lautet, Repräsentation sein. Diese Wiederholung widerspricht der Erzeugung. Das ist der Grundfehler am Terminus der Vorstellung, den für die Kunst die Phantasie nur verstärkt. Hier ist der Inhalt immer schon gegeben, und es handelt sich nur um seine Wiederholung, um die Herbeischaffung seiner Wiederkehr. Mehr hat ja auch eigentlich

<!-- pdf:190 S.160 -->

die Phantasie nicht zu leisten, wenngleich sie, sei es die Wiederkehr mit schwierigen Mitteln herbeiführt, sei es nach geschehener Wiederkehr an eine eigene Verarbeitung herangeht. Das Gegebene bleibt immer gegeben, wenngleich es verändert werden soll. Dahingegen muß das Denken immer Erzeugung sein, und als das Erzeugnis des Denkens wird das Objekt zu einem reinen Gegenstande der Erkenntnis, und in ihr die Wissenschaft. Und so kann auch das Denken, sofern es ein Grundelement des ästhetischen Gefühls ist, den Inhalt desselben zu einem reinen Inhalt, zu einem Gegenstande des reinen ästhetischen Gefühls erheben.

Hier zumal bewährt sich die methodische Verbindung, welche wir zwischen dem Bewußtsein in allen seinen Stufen mit der Bewegung herzustellen suchen. Die Kunst ist in allen ihren Tätigkeiten Bewegung. Aber das Denken muß überall mitwirken. Das Kunstgefühl beruht zwar auf dem Grundelemente des Denkens für die Erzeugung des Gegenstandes der Natur im Kunstwerk, aber wenn anders das ästhetische Bewußtsein die Benennung des Gefühls verträgt, so muß zunächst die Stufe des Gefühls in ihrer Relativität dabei mit zur Anlage kommen. Es darf bei der Relativität nicht verbleiben, aber es kann von ihr nicht Abstand genommen, auf sie nicht verzichtet werden. Somit muß eine Gefühlsstufe auch für das Denken nach allen seinen Modifikationen eingerichtet werden.

Daher ist unsere Wurzeleinheit von Bewußtsein und Bewegung für das ästhetische Gefühl von grundlegender Bedeutung. Die Kunst arbeitet ebenso sehr mit den vitalen Kräften der Bewegung, wie mit den logisch begründeten, wissenschaftlichen Einsichten des Denkens. Alles abstrakte Denken wird lebendig in ihr an der Bewegung, wie andererseits alle sinnliche Darstellung teils der mathematischen Zurüstung und Kontrolle, teils der klaren und scharfen logischen Gestaltung und Revision bedarf.

So wird das reine Denken der Bewegung im Kunstschaffen homogen. Zeit und Raum sind Grundformen der Bewegung und mithin des Denkens, ebenso aber auch Grundformen des

<!-- pdf:191 S.161 -->

Kunstschaffens. Die logische Erzeugung des Gegenstandes wird der künstlerischen gleichartig, daher die erstere zur Voraussetzung der letzteren. Und wir wurden schon darauf aufmerksam, wie die Kunstwissenschaft, um die Methodik der Kunst zu ermitteln, zu der logischen Einsicht kam, welche innerhalb der philosophischen Logik noch das eigentliche Problem im Streite der Schulmeinungen bildet.

In der Kunst geht mithin zwingender als an der Wissenschaft die logische Einsicht auf. Das wäre schwer verständlich, wenn es nicht schaffende Künstler selbst wären, von denen diese Einsicht ausgeht, wie zu Anfang von Gottfried Semper, so neuerdings von Adolf Hildebrand. Denn an sich müßte diese literarische Tatsache schwer erklärlich scheinen. Der Zusammenhang zwischen Mathematik und Logik und zugleich beider mit der Physik, ist ja schon durch Pythagoras dargelegt, also bei der ersten Entstehung der mathematischen Physik als Akustik; und nicht minder ist hier auch schon mit der logischen Begründung ein fundamentaler Beginn vollzogen. Und die Fortführung und immer lebendigere Begründung dieses dreifachen Zusammenhangs ist ebenso sehr der lebendige Geist in der Geschichte der Mathematik und der Physik, wie in der der Philosophie. Und dennoch wird darüber noch gestritten, als wenn nicht nur Pythagoras nicht gewesen wäre, sondern ebensowenig Galilei und Kepler und Leibniz und Newton.

Dahingegen ist in der Kunst scheinbar Alles nur sogenannte Phantasie, und das soll heißen Ungebundenheit durch die Gesetze der materiellen Erkenntnis, also etwa nur Gebundenheit durch die der sogenannten formalen Logik. Und dennoch soll diese Kunst die Darstellung von Gegenständen der Natur zu ihrer Aufgabe haben. Das ist ein offenbarer Widerspruch, an dem daher die Kunstwissenschaft Anstoß nehmen muß. Der geringste mechanische Fehler bringt das erbaute Haus zum Umsturz, nicht nur das Wohnhaus, sondern nicht minder das Luftschloß der architektonischen Phantasie, die den Tempel und die Kirche zur Erzeugung bringt. Ebenso vermag kein Hochflug der Phantasie den kleinsten

<!-- pdf:192 S.162 -->

Vers zustande zu bringen, ohne daß das Grundgesetz des Rhythmus eine miterzeugende Hilfe leistet. Genau so verhält es sich in der Musik. Es ist ein Irrtum, daß der Geist unbewußterweise bei der Komposition rechne. Das Rechnen allein genügt nicht. Der Komponist muß sich dessen bewußt sein, daß er rechnet, aber freilich nicht als Rechnung. Die musikalische Rechnung ist der Generalbaß. Ohne ihn aber kann die musikalische Phantasie nicht von statten gehen.

In allen diesen theoretischen Anforderungen an das Kunstschaffen ist jedoch die innere Verbindung mit der Bewegung unverkennbar. Daher wird die theoretische Anforderung nirgends ein von Außen eintretender Zwang, sondern sie erwächst aus der eigensten Wurzel, aus der sich alle Zweige des Kunstschaffens entfalten. So ist es denn auch zu verstehen, daß die theoretischen Bedingungen nicht allein von den bahnbrechenden Geistern der Kunst anerkannt, gepflegt und ausgebildet wurden, sondern daß sich ihre Originalität selbst, wie die Art ihrer Produktivität mit dem Maße ihrer theoretischen Kraft steigert. Die Originalität wird keineswegs beeinträchtigt, die schaffende Phantasie keineswegs unfrei bei dieser Personalunion mit der wissenschaftlichen Theorie, sondern die Schöpfung wird um so zauberhafter an Macht und Vielgestaltigkeit, je mehr sie von der Theorie geregelt und geleitet wird, je mehr sie die Gesetzmäßigkeit der Erkenntnis in ihre eigene Aufgabe aufnimmt, und als Grundlage für die Behandlung derselben festhält.

Hätte die Poesie aber etwa von sich selbst aus zu ihrer innern Kraft und Reife gedeihen können, oder ist es die lebendige Anteilnahme an den Problemen der theoretischen Kultur und mithin auch an deren Zentrum, der Philosophie, wodurch die Poesie, als Kunstrichtung, vom Epos der Volkspoesie zur Unterscheidung kommt? Die theoretische Reife ist der durchschlagende Grund für den Unterschied der hohen Kunst von der archaischen. Und ebenso beruht auf diesem Grunde der Unterschied zwischen der Musik und dem Volkslied, wie schon der zwischen der Musik und dem Vogelgesang. Die Polyphonie erst unterscheidet die Musik von

<!-- pdf:193 S.163 -->

allen ihren Analogien. Sie aber macht die Abhängigkeit von der Theorie unverkennbar. Zugleich aber wird an der Musik die Gleichartigkeit des Denkens mit der Bewegung unmittelbar deutlich, und daher die Homogeneität der Erkenntnisbedingung mit der ästhetischen Erzeugung.

Nur auf diese Homogeneität kommt es uns hier an; nur auf die Klarstellung des Grundgedankens, daß die Eigenart des ästhetischen Gefühls nicht beeinträchtigt wird dadurch, daß die theoretische Erkenntnis ihm zur Grundbedingung und Voraussetzung gemacht wird. Dahingegen handeln wir jetzt noch nicht von der Frage, welche den positiven Anteil des Denkens und der theoretischen Erkenntnis am Kunstschaffen selbst, wie auch am Kunsterlebnis betrifft. Diese Frage geht den Inhalt der Kunst, den Inhalt aller Kunstarten an. Sie ist daher ein Hauptteil für die gesamte Inhaltsbestimmung der Ästhetik. Hier jedoch haben wir es erst mit der Erzeugung des ästhetischen Gefühls zu tun, als einer neuen Art des Bewußtseins. Deshalb kommt es uns hier vornehmlich auf die Homogeneität der Erkenntnisbedingung mit dem ästhetischen Gefühle an, insofern sie in der Einheit von Bewußtsein und Bewegung begründet ist. Nur in Andeutungen zur Erläuterung haben wir hier auf die andere Frage schon Bezug nehmen müssen.

## 7. Die Vorbedingung des Willens

Suchen wir nunmehr die ebenso erforderliche Homogeneität des ästhetischen Bewußtseins mit der ethischen Willensbedingung zu ermitteln.

Die Reinheit in der Erzeugung des Willens ist vorgesehen in der Tendenz, welche das Willenselement mit dem Denken gleichartig macht. Diese Tendenz waltet im Rhythmus, und pflanzt sich demgemäß im ästhetischen Bewußtsein fort. Von hier aus bereitet sich die Verbindung mit der weitern Entwicklung des Denkens vor. Indessen beruht die positive Kraft des Willens auf dem Affekt.

<!-- pdf:194 S.164 -->

Der Wille bedarf zwar des Denkens und der Erkenntnis, aber er verbraucht sie für seine Eigenart. Diese hat ihren positiven Grund im Affekt. Der Affekt ist nun aber zwar nicht entblößt von Lust und Unlust, aber Lust und Unlust erschöpfen seinen Begriff nicht. Lust und Unlust sind nunmehr ja als Annexe und als relative Gefühlsstufen unzweideutig bestimmt. In Annexen aber kann nicht die positive Kraft entspringen, in denen die Eigenart des Willens besteht.

Es ist daher eine neue Art der Relativität für die Gefühlsstufe zu bestimmen. Denn der Affekt muß freilich eine Art von Gefühl sein. Der Inhalt, der immer nur dem Denken angehören kann, ist ja bereits als negative Bedingung befriedigt. Als positive Bedingung kann der Affekt aber nicht ein Anhängsel einer schon dagewesenen Bewußtseinsstufe sein, deren positive Bedeutung nur darin bestehen könnte. daß sie für eine neue Inhaltsstufe die Voraussetzung bildet. Denn jetzt handelt es sich für den Affekt um eine neue, eigenartige, selbständige Stufe des Bewußtseins, welche der Wille bildet. Daher hat die Ethik des reinen Willens die Gefühlsstufe der Suffixe unterschieden von der der Annexe. Das Suffix bedeutet nicht nur die Disposition für einen neuen Inhalt auf derselben Stufe, sondern die Bedingung der Erzeugung einer neuen Stufe des Bewußtseins.

Wenn der Affekt das Willensgefühl zu vertreten hat im Unterschiede von den Denkinhalten des Willens, so muß diese Relativität des Gefühls eine positive, an ihrem Teile rein erzeugende Bedeutung haben. Der Wille darf nicht Velleität bleiben; der Entschluß nicht nur Plan und Vorhaben; er muß als Impuls die Handlung ins Werk setzen. Die Impulsivität, die Lebensenergie, der Schaffensdrang, die Tatkraft muß sich in die Handlung ergießen. Diese Kraft des Influxus ist der reine Wille. Setzet Ihr nicht das Leben ein, nie wird Euch das Leben gewonnen sein. Das ganze Ich bringt sich in dem Ziele der Handlung an den Tag. Was Begehrung zu sein scheint, Trieb, Naturgewalt, Baulust und Zerstörungstrieb; der Affekt, als

<!-- pdf:195 S.165 -->

reines Willensgefühl, erhebt sich über alle diese vitalen Stufen des Empfindungsgefühls mit ihrer Lust und Unlust in allen ihren Nuancen.

Der Affekt nährt sich nicht allein aus diesen elementaren Empfindungsstufen: er ist ein Konflux zugleich von anderen Gefühlsstufen, von denen der Denkgefühle. Diese Vereinigung der verschiedenen Gefühlsstufen bringt die Veränderung hervor, welche das Suffix von dem Annex unterscheidet. Es ist die Reinheit zugleich, welche in dieser Veränderung sich erzeugt; welche insbesondere von den Denkgefühlen herleitbar wird. Diese Reinheit schafft dem Affekte die positive Energie, welche den Willen von der Begierde abscheidet.

Wenn dieser reine Affekt sich frei zu machen vermag von der Allgewalt der Lust und Unlust, so bedeutet dies nicht etwa, daß Lust und Unlust im Wechsel des Doppelgefühls sich aufspielen, indem etwa die Lust an und nach Kümmernissen rege wird, sondern es ist die andere Gefühlsstufe des Willens, welche die neue Gefühlsstufe zur Erzeugung kommen läßt. Wir denken unwillkürlich hier schon an das ästhetische Gefühl, wenn wir schon im reinen Willen diese Ablösung des Affekts von Lust und Unlust erkennen. Aber wir nehmen jetzt nur Bezug auf diese Ablösung, sofern sie innerhalb des reinen Willens selbst, für dessen Erzeugung sich vollzieht.

Die Ethik des reinen Willens hat das ethische Selbstbewußtsein in dem Ich der Allheit zur Objektivierung gebracht. Dieses Ich der Allheit ist nicht nur unterschieden von dem Ich des isolierten sinnlichen Bewußtseins, sondern auch von jener höheren Stufe, welche nur in einer Mehrheit von Individuen sich objektivieren kann. Diese Mehrheit bildet die relativen Gemeinschaften der Familie, des Stammes, des Volkes, wie nicht minder auch der religiösen Verbände. Die Allheit dagegen objektiviert sich in den Staaten und in der Menschheit, welche auf dem Staatenbund beruht. Diese Verbände sind absolut für den reinen Willen. Sie sind die höchsten,

<!-- pdf:196 S.166 -->

die zuverlässigen Objektivierungen des ethischen Selbstbewußtseins.

Für die Ästhetik ist es eine wichtige Frage, ob der Inhalt der Kunstwerke, wie er von dem Zeitwechsel und von der nationalen Verschiedenheit der Künstler abhängig ist, so auch in solcher Relativität aufgeht, oder ob er trotz dieser Relativität einen absoluten Wert hat. Die Gesetzlichkeit des ästhetischen Bewußtseins scheint darauf zu beruhen, daß die Frage im Sinne des Nachsatzes zur Entscheidung kommt. Es scheint sich so eine vielleicht wichtige Analogie für das ästhetische Bewußtsein zu dem Willensbewußtsein in bezug auf das Subjekt herauszustellen. Wie das ethische Selbstbewußtsein nur in der Allheit zur Reinheit kommt, so würde es demnach auch mit dem ästhetischen Selbstbewußtsein, wenn das ästhetische Gefühl zu einem solchen zu reifen vermag, ebenso der Fall sein.

Aber abgesehen vom Individuum des Künstlers, handelt es sich auch objektiv im Verhältnis des darzustellenden Individuums zum Typus zu allernächst um den ethischen Begriff des Individuums. Der Typus selbst darf nicht die letzte Grenze der Kunst bilden; denn er bezeichnet nur den Menschen der Mehrheit. So bewegt sich die Kunst immer zwischen diesen beiden Polen des ethischen Selbstbewußtseins. Sie verengt sich, wenn das Individuum sich lediglich nationalisiert, ebenso wie wenn sie sich auf ein Konterfei einschränkt. Sie erhöht sich, wenn sie ihren Horizont von dem Mehrheitsbilde erweitert zu dem Allheitsbilde des ethischen Individuums. Auf diese Allheit muß der reine Wille, muß der Affekt sich richten. Dann erst kann das ästhetische Bewußtsein zur reinen Erzeugung kommen. Die Reinheit bleibt beschränkt, wenn die Willensgrundlage nicht zur Vollendung ihrer Reinheit kommt, wenn die Kluft zwischen Allheit und Mehrheit bestehen bleibt.

## 8. Verhältnis zur Religion

Hier wird die Differenz einschneidend, welche zwischen der reinen Sittlichkeit und der

<!-- pdf:197 S.167 -->

Religion besteht. Und diese Differenz wird bedeutsam in der Erzeugung des ästhetischen Bewußtseins: ob es seine Grundbedingung streng und genau in der reinen Sittlichkeit feststellt, oder aber ob es das Grundmoment des Willens aus der Religion entnimmt. Durch diese Differenz entstehen die wichtigsten Unterschiede in der Geschichte der Kunst, und auch in den Perioden der großen Künstler. Immer ist und bleibt ein Element der Sittlichkeit in der Religion; aber es ist in ihr nicht zur Reinheit gereift. Es ist auch mit anderen Elementen gemischt, welche nicht an sich von sittlichem Gehalte sind, oder auch nur den relativen Wert des Subjektes der Mehrheit an sich tragen. Das Verhältnis des ästhetischen Bewußtseins zur Religion wird der Gegenstand einer besondern Erörterung werden müssen. Hier sei nur auf das Verhältnis des reinen Willens zur Religion in ästhetischer Rücksicht Bezug genommen.

Die politischen Momente spielen auf beiden Seiten mit. Schon in der ältesten Kunst zeigen sich diese Einflüsse. Die Ehrfurcht vor der Gewalt der Herrscher hat ihre Paläste zur Umwandlung in die Tempel gebracht. So sind die Tempelbauten entstanden aus den Palastbauten heraus. Bei den Herrschern selbst aber und bei ihren, ihrem eigenen Wohnsitz gewidmeten Bauten, spielen religiöse Motive schon mit. Auch die Götter sind ursprünglich Ahnen und Heroen, mithin politischen Ursprungs. Auch im homerischen Olymp walten sie als politische Schutzgötter für Griechen und Trojaner, als Parteigötter, als Sonderschutzgötter. Dieser politische Ursprung ist an sich ein sittlicher Ursprung der Götter; er vollzieht ihr Verhältnis zu einem Volkswesen, zu dem Urgebild eines Staatswesens.

Wenn in späterer Zeit aber noch andere Motive für die Entwicklung der Gottheit und der Religion eintreten, insbesondere auch für das Verhältnis zwischen den Göttern und den Menschen, so gilt es zu bedenken, daß dann schon die Kunst vorhanden ist, und daß es demnach notwendig wird, so schwierig es ist, die Mitwirkung der Kunst bei dieser Entwicklung der Religion zu isolieren, und auf ihren besondern Wert abzuschätzen. Der Begriff des ethischen Selbstbewußt-
