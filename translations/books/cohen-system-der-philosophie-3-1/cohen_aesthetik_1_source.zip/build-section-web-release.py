"""Generate the chapter and section routes for publication."""
import json
from pathlib import Path
base=Path('release-web')
meta=json.loads(Path('baseline-book-metadata.json').read_text(encoding='utf8'))
meta['originalTitle']='System der Philosophie. Dritter Teil: Ästhetik des reinen Gefühls. Erster Band'
projection=json.loads(Path('book-projection-draft.json').read_text(encoding='utf8'))
meta['bilingual']=True;meta['views']=['parallel','zh','en']
meta['editionNotice']='依据 1912 年柏林版校订。保留原书印刷页码与章节结构；第六章目录和正文编号分别依原书保留。'
old={c['id']:c for c in meta['chapters']};chapters=[old['front-matter'],{'id':'original-toc','title':'原书目录（原书页码）','originalTitle':'Inhaltsverzeichnis des Originals','dataUrl':'translations/books/cohen-system-der-philosophie-3-1/original-toc.json'}]
front_titles={'front-0001':'Titelei und Verlagsangaben','front-0009':'Vorrede'}
for heading in chapters[0].get('outline',[]):
    if heading['anchor'] in front_titles: heading['originalTitle']=front_titles[heading['anchor']]
for n in range(1,7):
    ident=f'chapter-{n}';chapter=old[ident];data=json.loads((base/f'{ident}.json').read_text(encoding='utf8'))
    headings=[x for x in projection['items'] if x['kind']=='heading' and x['chapter']==n]
    hmap={x['id']:x for x in headings}
    for outline in chapter.get('outline',[]):
        assert outline['anchor'] in hmap,(ident,outline)
        source=hmap[outline['anchor']];outline['title']=source['translation'];outline['originalTitle']=source['source_text']
    chapters.append(chapter)
    body=data['body'];positions=[i for i,row in enumerate(body) if row['type']=='heading']
    assert [body[i]['id'] for i in positions]==[h['id'] for h in headings]
    for k,pos in enumerate(positions):
        heading=body[pos];h=hmap[heading['id']]
        end=positions[k+1] if k+1<len(positions) else len(body)
        section_id=f'{ident}-section-{h["id"]}'
        segment={**data,'id':section_id,'title':h['translation'],'originalTitle':h['source_text'],'body':body[pos:end]}
        (base/f'{section_id}.json').write_text(json.dumps(segment,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
        chapters.append({'id':section_id,'parentId':ident,'excludeFromCount':True,'title':h['translation'],'originalTitle':h['source_text'],'dataUrl':f'translations/books/cohen-system-der-philosophie-3-1/{section_id}.json'})
meta['chapters']=chapters;meta['downloads']=[]
Path('release-web-metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print('Staged',len(chapters),'routes, including',sum('parentId' in c for c in chapters),'original headings')
