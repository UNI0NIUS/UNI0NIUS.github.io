# 《纯粹情感的美学》第一卷：可编辑源码

本包包含依据 1912 年柏林版整理的中、德及对照版 XeLaTeX 源码、中文和德文 Markdown、分章网页数据、工作原文与译稿、阅读投影、术语表、编校记录和原文疏排强调标记。完整扫描件不包含在包内。网页中文字补充字库和其 SIL OFL 许可见 `draft-font/`。

在包根目录安装 Python、XeLaTeX、Times New Roman 与 SimSun 后，运行 `python build-edition-release.py` 重编三种 PDF，运行 `python build-markdown-release.py` 重建 Markdown；依次运行 `python build-web-release.py`、`python build-section-web-release.py` 重建网页数据。网页数据需要配合站点阅读器及字体使用。

`book-projection-draft.json` 和 `preface-reading-units.json` 是本版使用的阅读投影；`source/`、`parts/` 是工作原文及中文稿。文件名中的 draft 是工作数据名称。强调数据与投影哈希绑定；更改投影文字后，必须重新定位、核对并更新偏移。源稿变更后须重建关联投影及数据。

“S.”表示底本印刷页码，扫描 PDF 页码与之不同；跨页段落的中文页标按段落定位，不表示句级定位。已知部分补正和保留的疑似印刷异常见 `editorial-variants.json`，并非完整异文清单。第六章目录与正文的编号差异按原书各自保留。
