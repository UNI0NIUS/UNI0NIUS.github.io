"""Generate bilingual reader JSON for the publication."""
from pathlib import Path
import hashlib,json
import source_emphasis

chapters=json.loads(Path('baseline-book-metadata.json').read_text(encoding='utf8'))['chapters'];book=json.loads(Path('book-projection-draft.json').read_text(encoding='utf8'));pref=json.loads(Path('preface-reading-units.json').read_text(encoding='utf8'));toc=json.loads(Path('original-contents.json').read_text(encoding='utf8'));out=Path('release-web');out.mkdir(exist_ok=True)
variants=sorted(json.loads(Path('editorial-variants.json').read_text(encoding='utf8'))['items'],key=lambda v:v['printed_page'])
emphasis=source_emphasis.load()
def dump(name,value):Path(out/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def printed(n):return {11:'VII',12:'VIII',13:'IX',14:'X',15:'XI',16:'XII',17:'XIII',18:'XIV'}.get(n,str(n-30))
def row(u):
    page=u['source_pdf_pages'][0];aliases=[a['id'] for a in u['anchor_positions'] if a['id']!=u['id']]
    return {'id':u['id'],'type':'paragraph','page':printed(page),'zh':[u['translation']],'en':source_emphasis.tokens(u,emphasis),'legacyIds':aliases,'sourcePages':[{'pdf_page':p,'printed_page':printed(p),'display_printed_page':printed(p)} for p in u['source_pdf_pages']]}
legacy_front=json.loads(Path('baseline-front-rows.json').read_text(encoding='utf8'));front=[]
front_de=['Titelei und Verlagsangaben','SYSTEM DER PHILOSOPHIE','DRITTER TEIL','ÄSTHETIK DES REINEN GEFÜHLS','VON HERMANN COHEN, PROFESSOR AN DER UNIVERSITÄT MARBURG','ZWEI BÄNDE','BERLIN, BRUNO CASSIRER, 1912','SYSTEM DER PHILOSOPHIE. DRITTER TEIL. ÄSTHETIK DES REINEN GEFÜHLS. VON HERMANN COHEN, PROFESSOR AN DER UNIVERSITÄT MARBURG. ZWEI BÄNDE. BERLIN, BRUNO CASSIRER, 1912.','Vorrede']
for x,de in zip(legacy_front[:9],front_de):
    if x['id']=='front-0009':
        front.append({'id':'front-volume-title','type':'paragraph','page':'PDF 9','pageKind':'pdf','zh':['纯粹情感的美学　赫尔曼·柯亨著　第一卷。柏林：布鲁诺·卡西雷尔，1912。'],'en':['ÄSTHETIK DES REINEN GEFÜHLS. VON HERMANN COHEN. ERSTER BAND. BERLIN, BRUNO CASSIRER, 1912.']})
    front.append({**x,'page':'PDF 8' if x['id']!='front-0009' else 'VII',**({'pageKind':'pdf'} if x['id']!='front-0009' else {}),'en':[de]})
front.extend(row(u) for u in pref['units'])
front.append({'id':'front-editorial-variants','type':'heading','page':'','zh':['编校说明'],'en':['Editorische Hinweise']})
front.append({'id':'front-editorial-variants-intro','type':'paragraph','page':'','zh':['以下记录本版相对于所用 1912 年底本的部分补正及保留的疑似印刷异常，并非全部印刷异文。'],'en':['Die folgenden Hinweise dokumentieren einzelne Eingriffe und beibehaltene mutmaßliche Druckfehler des verwendeten Drucks von 1912; sie sind keine vollständige Liste aller Druckvarianten.']})
for i,v in enumerate(variants,1):
    page=str(v['printed_page']);before=v['original'];after=v['edition']
    reading=before+(f' → {after}' if before!=after else '')
    front.append({'id':f'front-editorial-variant-{i}','type':'paragraph','page':'','zh':[f'原书第 {page} 页：{reading}。{v["explanation_zh"]}'],'en':[f'Original S. {page}: {reading}. {v["explanation_de"]}']})
dump('front-matter.json',{'id':'front-matter','title':'书名页与序言','originalTitle':'Titelei und Vorrede','sourceLanguage':'de','sourceLanguageLabel':'Deutsch','body':front,'notes':{}})
for n in range(1,7):
    c=next(x for x in chapters if x['id']==f'chapter-{n}');body=[]
    if n==6:
        body.append({'id':'ch7-editorial-numbering','type':'paragraph','page':'','zh':['〔编者按〕'+book['editorial_note_zh']],'en':['[Redaktionelle Erläuterung] '+book['editorial_note_de']]})
    for x in book['items']:
        if x['chapter']!=n or x['kind']=='chapter':continue
        if x['kind']=='heading':body.append({'id':x['id'],'type':'heading','page':str(x['printed_page']),'zh':[x['translation']],'en':[x['source_text']]})
        else:body.append(row(x))
    dump(f'chapter-{n}.json',{'id':f'chapter-{n}','title':c['title'],'originalTitle':c['originalTitle'],'sourceLanguage':'de','sourceLanguageLabel':'Deutsch','body':body,'notes':{}})
body=[]
for i,e in enumerate(toc['entries'],1):
    p='' if e['printed_toc_page_number'] is None else str(e['printed_toc_page_number'])
    body.append({'id':f'original-toc-{i:03}','type':'paragraph','page':p,'zh':[e['zh_heading']],'en':[e['de_heading']]})
    if e['de_topics']:body.append({'id':f'original-toc-{i:03}-details','type':'paragraph','page':'','zh':[e['zh_topics']],'en':[e['de_topics']]})
dump('original-toc.json',{'id':'original-toc','title':'原书目录（原书页码）','originalTitle':'Inhaltsverzeichnis des Originals','sourceLanguage':'de','sourceLanguageLabel':'Deutsch','body':body,'notes':{}})
files=[out/'front-matter.json',out/'original-toc.json']+[out/f'chapter-{n}.json' for n in range(1,7)];manifest={'status':'publication_data','scope':'Generated base reader data; section routes and publication checks are recorded separately.','inputs_sha256':{str(p):hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in ['baseline-book-metadata.json','baseline-front-rows.json','book-projection-draft.json','preface-reading-units.json','original-contents.json','editorial-variants.json','bilingual-reader-alias-prototype.js','letterspacing-preface-full.json']+[f'letterspacing-chapter{n}-full.json' for n in range(1,7)]},'files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
Path('release-web-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print('Generated',len(files),'local reader data files')
