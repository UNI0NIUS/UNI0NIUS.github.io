"""Generate reading editions from the reviewed projection."""
from pathlib import Path
import json,subprocess
import source_emphasis

projection=json.loads(Path('book-projection-draft.json').read_text(encoding='utf8'))
preface=json.loads(Path('preface-reading-units.json').read_text(encoding='utf8'))
toc=json.loads(Path('original-contents.json').read_text(encoding='utf8'))
variants=sorted(json.loads(Path('editorial-variants.json').read_text(encoding='utf8'))['items'],key=lambda v:v['printed_page'])
emphasis=source_emphasis.load()
out=Path('release-editions');out.mkdir(exist_ok=True)
def esc(t):
    return ''.join({'\\':r'\textbackslash{}','&':r'\&','%':r'\%','$':r'\$','#':r'\#','_':r'\_','{':r'\{','}':r'\}','~':r'\textasciitilde{}','^':r'\textasciicircum{}'}.get(c,c) for c in t)
def label(p):
    roman={11:'VII',12:'VIII',13:'IX',14:'X',15:'XI',16:'XII',17:'XIII',18:'XIV'}
    return roman[p] if p in roman else str(p-30)
PREAMBLE=r'''\documentclass[SIZE,a4paper,twoside]{article}
\usepackage{fontspec,xeCJK}
\setmainfont{Times New Roman}
\setCJKmainfont[AutoFakeBold=2,AutoFakeSlant=.2]{SimSun}
\usepackage[GEOMETRY,marginparwidth=16mm,marginparsep=3mm]{geometry}
\usepackage{xcolor,paracol,fancyhdr,hyperref,needspace,xurl,amsmath}
\hypersetup{unicode=true,hidelinks,pdftitle={Ästhetik des reinen Gefühls},pdfauthor={Hermann Cohen}}
\setlength{\parindent}{1em}\setlength{\parskip}{5pt}\setlength{\columnsep}{8mm}\setlength{\emergencystretch}{3em}
\tolerance=2000\widowpenalty=10000\clubpenalty=10000
\pagestyle{fancy}\fancyhf{}\fancyhead[LE,RO]{\small Ästhetik des reinen Gefühls}
\fancyhead[LO,RE]{\small Hermann Cohen}\fancyfoot[C]{\thepage}\setlength{\headheight}{14pt}
\DeclareRobustCommand{\sourcepage}[1]{\marginpar{\raggedleft\fontsize{8}{10}\selectfont\color{black!65}S.\ #1}}
\twosided[pm]\marginparthreshold{0}
\setcounter{tocdepth}{2}\setcounter{secnumdepth}{-1}
\renewcommand{\contentsname}{本版目录 / Inhalt dieser Ausgabe}
\begin{document}
'''
class Renderer:
    def __init__(self,mode):
        self.mode=mode;self.bi=mode=='bilingual';self.open=False;self.parts=[];self.last=None
        rows=preface['units']+[x for x in projection['items'] if x['kind']=='paragraph']
        self.first_pages={x['source_pdf_pages'][0] for x in rows}
    def close(self):
        if self.open:self.parts.append(r'\end{paracol}');self.open=False
    def pair(self,zh,de,small=False):
        if self.bi:
            if not self.open:self.parts.append(r'\begin{paracol}{2}');self.open=True
            if small:zh=r'{\small '+zh+'}';de=r'{\small '+de+'}'
            self.parts.extend([zh+r'\par',r'\switchcolumn',de+r'\par',r'\switchcolumn*'])
        else:
            t=zh if self.mode=='zh' else de
            self.parts.append((r'{\small '+t+'}' if small else t)+r'\par')
    def mark(self,page):
        x=label(page)
        if x==self.last:return ''
        self.last=x;return r'\sourcepage{'+esc(x)+'}'
    def paragraph(self,row):
        zh=esc(row['translation']);de=source_emphasis.tex(row,emphasis,esc);spans=row['source_page_spans'];start=spans[0]['pdf_page']
        if self.mode=='de':
            text=row['source_text'];markers=[];last_pos=0
            for ref in spans:
                pos=ref['start']
                if 0<pos<len(text) and text[pos-1].isalpha() and text[pos].isalpha():
                    while pos<len(text) and text[pos].isalpha():pos+=1
                if pos<last_pos:continue
                markers.append((pos,self.mark(ref['pdf_page'])));last_pos=pos
            de=source_emphasis.tex(row,emphasis,esc,markers);self.pair('',de)
        else:
            before=self.mark(start)
            after=''.join(self.mark(r['pdf_page']) for r in spans[1:] if r['pdf_page'] not in self.first_pages)
            self.pair(before+zh+after,de)
    def heading(self,zh,de,level=2):
        self.close();self.parts.append(r'\needspace{7\baselineskip}')
        cmd=r'\section' if level==1 else r'\subsection'
        title=zh if self.mode!='de' else de
        display=esc(zh)+r'\\{\normalsize '+esc(de)+'}' if self.bi else esc(title)
        self.parts.append(cmd+'['+esc(title)+']{'+display+'}')
    def begin(self):
        size='10pt' if self.mode in ('de','bilingual') else '11pt';geo='a4paper,inner=20mm,outer=23mm,top=21mm,bottom=23mm' if self.mode in ('de','bilingual') else 'a4paper,margin=25mm'
        self.parts=[PREAMBLE.replace('SIZE',size).replace('GEOMETRY',geo),
            r'\begin{titlepage}\centering\vspace*{25mm}',
            r'{\Huge 哲学体系\\SYSTEM DER PHILOSOPHIE\par}\bigskip',
            r'{\Large 第三部：纯粹情感的美学\\DRITTER TEIL: ÄSTHETIK DES REINEN GEFÜHLS\par}\bigskip',
            r'{第一卷\\ERSTER BAND\par}\bigskip',
            r'{\Large 赫尔曼·柯亨 著\\von HERMANN COHEN\par}\bigskip',
            r'{马堡大学教授\\PROFESSOR AN DER UNIVERSITÄT MARBURG\par}\bigskip',
            r'{柏林\\BERLIN\par}\bigskip',r'{布鲁诺·卡西雷尔出版社\\BRUNO CASSIRER\par}\bigskip',r'{1912\par}\bigskip',
            r'\vfill '+{'zh':'中文校订版','de':'Deutsche Leseausgabe','bilingual':'中德逐段对照版'}[self.mode]+r'\par\end{titlepage}']
        self.pair('页边“S.”为原书印刷页码，页底为本版页码；跨页段落的页标按段落定位。',
                  'Die Randverweise „S.“ bezeichnen die Seiten des Originals; die Fußzeile zählt die Seiten dieser Ausgabe. Bei seitenübergreifenden Absätzen sind die Seitenverweise am Absatz orientiert.')
        self.close()
        toc_font=r'\small\linespread{.95}\selectfont' if self.mode=='zh' else r'\small'
        self.parts.append(r'\bigskip{'+toc_font+r'\setlength{\parskip}{0pt}\tableofcontents}\clearpage')
    def render(self):
        self.begin();self.heading('序言','Vorrede',1)
        for row in preface['units']:self.paragraph(row)
        self.close();self.parts.append(r'\clearpage');self.heading('编校说明','Editorische Hinweise',1)
        self.pair(esc('以下记录本版相对于所用 1912 年底本的部分补正及保留的疑似印刷异常，并非全部印刷异文。'),esc('Die folgenden Hinweise dokumentieren einzelne Eingriffe und beibehaltene mutmaßliche Druckfehler des verwendeten Drucks von 1912; sie sind keine vollständige Liste aller Druckvarianten.'))
        for v in variants:
            before=v['original'];after=v['edition'];page=str(v['printed_page'])
            reading=before+(' → '+after if before!=after else '')
            self.pair(esc('原书第 '+page+' 页：'+reading+'。'+v['explanation_zh']),esc('Original S. '+page+': '+reading+'. '+v['explanation_de']))
        self.close();self.parts.append(r'\clearpage');self.heading('原书目录（原书页码）','Inhaltsverzeichnis des Originals',1)
        for chapter in range(1,7):
            self.close();self.parts.append(r'\needspace{4\baselineskip}')
            h=next(x for x in projection['items'] if x['kind']=='chapter' and x['chapter']==chapter)
            self.pair(esc(h['translation']),esc(h['source_text']),True)
            for e in (x for x in toc['entries'] if x['chapter']==chapter):
                page='' if e['printed_toc_page_number'] is None else '　'+str(e['printed_toc_page_number'])
                self.pair(esc(e['zh_heading']+page),esc(e['de_heading']+page),True)
                if e['de_topics']:
                    extra='　'+str(e['extra_printed_toc_number_after_topics']) if 'extra_printed_toc_number_after_topics' in e else ''
                    self.pair(esc('　'+e['zh_topics']+extra),esc('  '+e['de_topics']+extra),True)
        self.close();self.parts.append(r'\clearpage')
        self.heading('第一部分　系统美学的奠基','Erster Teil. Die Grundlegung der systematischen Ästhetik',1)
        for row in projection['items']:
            if row['kind']=='chapter':
                self.close()
                if row['chapter']!=1:self.parts.append(r'\clearpage')
                self.heading(row['translation'],row['source_text'],1)
                if row['chapter']==6:self.pair(esc('〔编者按〕'+projection['editorial_note_zh']),esc('[Redaktionelle Erläuterung] '+projection['editorial_note_de']),True)
            elif row['kind']=='heading':self.heading(row['translation'],row['source_text'])
            else:self.paragraph(row)
        self.close();self.parts.append(r'\end{document}')
        return '\n'.join(self.parts)+'\n'
for mode in ('zh','de','bilingual'):
    path=out/f'cohen_aesthetik_1_{mode}.tex';path.write_text(Renderer(mode).render(),encoding='utf8')
    for _ in range(2):subprocess.run(['xelatex','-interaction=nonstopmode','-halt-on-error','-output-directory',out.as_posix(),path.as_posix()],check=True,stdout=subprocess.DEVNULL)
    print('Generated draft',path.with_suffix('.pdf'),flush=True)
