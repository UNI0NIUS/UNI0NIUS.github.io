# 术语表（校订工作用）

本表记录主要译法和语境区别；同一德词的中文形式可能随句法变化，不能据此进行机械替换。全书关键词的机器筛查范围见 `selected-terms-final-screen.json`，该筛查不能替代逐句语义核对。

| 德文 | 中文 | 说明 |
| --- | --- | --- |
| Ästhetik | 美学 | |
| reines Gefühl | 纯粹情感 | 书名核心词；不译“感情”，以与 Empfindung（感觉）区分 |
| Bewußtsein | 意识 | |
| Bewußtheit | 意识性 | 与 Bewußtsein 区别 |
| Bewußtseinsart | 意识方式 | |
| Gesetzlichkeit | 规律性 | 与 Gesetz（规律）同一词根；不译“合法性” |
| Gesetz | 规律、法则 | 单数条文语境用“法则” |
| Grundlegung | 奠基 | |
| systematisch | 系统的 | 与“体系”（System）区别 |
| System | 体系 | |
| Erzeugung | 产生、创造 | “reine Erzeugung”纯粹产生；在活动语境也作“创造”“生成”，与 Erzeugnis（产物）区别 |
| Erzeugnis | 产物 | 与 Erzeugung（产生、创造）区别 |
| Ursprung | 起源 | |
| Objektivierung | 客观化 | |
| Vorbedingung | 前提条件 | |
| Allheit | 全体性 | 与 Totalität 区分 |
| Totalität | 总体、总体性 | 视语境；灵魂力量等集合语境用“总体” |
| Mehrheit | 多数性 | 与 Allheit、Einheit 并列 |
| Selbst | 自身、自我 | 自指关系常作“自身”，作为主体性概念时亦作“自我”；需依上下文与 Ich、Selbstbewußtsein 区别 |
| Einheit | 统一性 | |
| Anschauung | 直观 | |
| intellektuelle / intellektuale Anschauung | 理智直观 | 与一般 Anschauung（直观）相区分 |
| Einbildungskraft | 想象力 | |
| Phantasie | 幻想力 | 与 Einbildungskraft 区别时用“幻想力” |
| Affekt | 情动 | 与 Gefühl（情感）区分；词形命中已作有限的全书候选筛查 |
| Fühlen | 感受活动 | 作意识起源的概念时与 Gefühl（情感）、Empfindung（感觉）区分；非概念用法须按句法和语境处理 |
| Empfindung | 感觉 | |
| Empfindnis | 感受 | 特滕斯用语；第 3 章与 Empfindung（感觉）区别，全书仍需统检 |
| Gehalt / Inhalt | 内涵 / 内容 | 第 3 章明确区分；依上下文保留二者关系 |
| Disposition | 倾向、素质 | 第 3 章论神经系统对刺激的预备状态时作“倾向”；其他语境另核 |
| Empfindungsgefühl | 感觉情感 | |
| Lust und Unlust | 快感与不快感 | |
| Rührung | 感动 | |
| Stimmung | 情绪、心境 | |
| Einfühlung | 移情 | |
| Selbstgefühl | 自我情感 | 与 Selbstbewußtsein（自我意识）区分 |
| Selbstbewußtsein | 自我意识 | |
| Ich | 自我 | |
| Persönlichkeit | 人格 | |
| Individualität | 个体性 | |
| Genie | 天才 | |
| Kunstwissenschaft | 艺术科学 | |
| Kunstgeschichte | 艺术史 | |
| Kunstgewerbe | 工艺美术 | |
| bildende Kunst | 造型艺术 | |
| Plastik | 雕塑 | |
| Malerei | 绘画 | |
| Baukunst | 建筑艺术 | |
| Poesie | 诗 | 作为艺术门类时用“诗” |
| Dichtung | 诗歌 | |
| das Erhabene | 崇高 | |
| das Schöne | 美 | |
| das Häßliche | 丑 | |
| Humor | 幽默 | |
| Symbol | 象征 | |
| Schema | 图式 | |
| Zweckmäßigkeit | 合目的性 | |
| Normalidee | 常态理念 | |
| Ideal | 理想 | |
| Charakteristische | 特征性 | |
| Sittlichkeit | 道德、伦理性 | 第一章多译“道德”，与 Ethik（伦理学）区别；其他章节按语境复核 |
| sittlich | 伦理的 | |
| Religion | 宗教 | |
| Humanität | 人道 | |
| Kultur | 文化 | |
| Idealismus | 唯心主义 | 艺术趣味语境作“理想主义”并出注 |
| Rationalismus | 理性主义 | |
| Romantik | 浪漫派 | |
| Aufklärung | 启蒙 | |
| Naturalismus | 自然主义 | |
| Impressionismus | 印象主义 | |
| Kontrapunkt | 对位法 | |
| Metron | 尺度 | 第一章作为认识与艺术的基本尺度；音乐节拍义须按语境判断 |
| Kanon | 法式、准则 | 第一章是造型艺术的尺度；音乐语境的卡农另按上下文判断 |
| Landschaft | 风景 | |
| Porträt | 肖像 | |
| Karikatur | 漫画 | |
| Satyr | 萨提尔 | |
| Pathos | 激情 | |
| Idee | 理念 | |
| Begriff | 概念 | |
| Moment | 环节 | 美学语境亦作“要素” |
| Problematik | 问题性 | |

## 第四章至第六章及艺术门类（续补）

| 德文 | 中文 | 说明 |
| --- | --- | --- |
| das Komische | 喜剧性的东西 | |
| Komik | 喜剧性 | |
| das Tragische | 悲剧性的东西 | |
| Tragik | 悲剧性 | |
| Ironie | 反讽 | |
| Pathos | 激情 | |
| Würde | 尊严 | |
| Erhabenheit | 崇高性 | |
| Heiterkeit | 明朗 | |
| Naiv | 素朴 | 与 sentimentalisch（感伤的）对举 |
| Klassik | 古典 | |
| klassisch | 古典的 | |
| Realismus | 现实主义 | |
| Stil | 风格 | |
| Manier | 作风 | |
| Technik | 技术 | |
| Kunstwerk | 艺术作品 | |
| Kunstschöpfung | 艺术创造 | |
| Kunsterlebnis | 艺术体验 | |
| Kunstgenuß | 艺术享受 | |
| Stoff | 质料 | 与 Form（形式）、Inhalt（内容）区分 |
| Subjekt | 主体 | |
| Objekt | 客体 | |
| Korrelation | 相关关系 | |
| Reinheit | 纯粹性 | |
| Voraussetzung | 预设 | 与 Vorbedingung（前提条件）、Bedingung（条件）区分 |
| Regung | 萌动 | |
| Erregung | 激动 | |
| Charakter | 性格 | |
| Offenbarung | 启示 | |
| Erlösung | 救赎 | |
| Gnade | 恩典 | |
| Verdammnis | 定罪 | |
| Frömmigkeit | 虔诚 | |
| Pietät | 虔敬 | |
| Menschenliebe | 人类之爱 | |
| Nächstenliebe | 邻人之爱 | |
| Eros | 厄洛斯 | |
| Mythos | 神话 | |
| Symbol | 象征 | |
| Symbolismus | 象征主义 | |
| Humor | 幽默 | |
| Witz | 机智 | |
| Tanz | 舞蹈 | |
| Architektur | 建筑 | 与 Baukunst（建筑艺术）视语境区分 |
| Skulptur | 雕塑 | |
| Komposition | 作曲；构图 | 音乐语境作“作曲”，绘画语境作“构图” |
| Harmonie | 和谐；和声 | 哲学关系语境作“和谐”，音乐语境作“和声” |
| Melodie | 旋律 | |
| Rhythmus | 节奏 | |
| Motiv | 动机 | |
| Thema | 主题 | |
| Symphonie | 交响曲 | |
| Sonate | 奏鸣曲 | |
| Quartett | 四重奏 | |
| Oper | 歌剧 | |
| Oratorium | 清唱剧 | |
| Lied | 歌曲 | |
| Chor | 合唱 | |
| Rezitativ | 宣叙调 | |
| Epos | 史诗 | |
| Epik | 叙事诗 | |
| Lyrik | 抒情诗 | |
| Drama | 戏剧 | |
| Roman | 长篇小说 | |
| Tragödie | 悲剧 | |
| Komödie | 喜剧 | |
| Idylle | 田园诗 | |
| Metrum | 格律 | |
| Vers | 诗行 | |
| Gebärde | 手势 | |
| Interjektion | 感叹词 | |
| Begriffswort | 概念词 | |
| Begriffswortgefühl | 概念词情感 | |
| Anschaulichkeit | 直观性 | |
| Verinnerlichung | 内在化 | |
| Äußerung | 外化 | |
| Mitteilung | 传达 | |
| Darstellung | 表现 | |
| Ausdruck | 表达 | |
| Gestaltung | 构形；塑造 | 造型、结构语境作“构形” |
| Erlebnis | 体验 | |
| Ereignis | 事件 | |
| Erzählung | 叙述 | |
| Bekenntnis | 告白 | |
| Handlung | 行动 | |
| Leib | 身体 | |
| Gestalt | 形态 | |
| Beseelung | 赋灵 | 与 Begeistung（赋神）对举 |
| Begeistung | 赋神 | |
| vaterländischer Staat | 祖国国家 | 指作为祖国的国家 |
