"""One-time business/railroad semantic batch."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent;f=p/'translation_units.jsonl';raw=f.read_bytes();rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch04-0071':[('他的《经济学原理》第一版','他的{{I}}《经济学原理》{{/I}}第一版','恢复书名斜体。')],
'ch04-0072':[('霍布森的《帝国主义》','霍布森的{{I}}《帝国主义》{{/I}}','恢复书名斜体。')],
'ch04-0073':[('棉花和糖种植园的尼罗河洪泛盆地','棉花和甘蔗种植园的尼罗河围堤蓄水田区','承接前章灌溉田区语境；种植甘蔗而非糖。'),('它们占了其股份可以交易的公司的大多数','铁路公司在可交易股票的公司中占据多数','明确统计主体为公司而非计划。')],
'ch04-0074':[('“商人”或“城里人”','“商人”或“金融城人士”（city men）','金融商业语境不泛指城镇居民。'),('批判性著作《商业企业理论》','批判性著作{{I}}《商业企业理论》{{/I}}','恢复斜体。'),('600 页的研究《商业周期》','600 页的研究{{I}}《商业周期》{{/I}}','恢复斜体。'),('更有规律的时间性','更受规整的时间性','regulated指经规整/调节，不只是自然规律性。')],
'ch04-0076':[('每个工业部门','每个产业部门','sector of industry此处含金融等非工业部门。')],
'ch04-0077':[('经典著作《看得见的手》','经典著作{{I}}《看得见的手》{{/I}}','恢复斜体。')],
'ch04-0079':[('《美国铁路杂志》早在','{{I}}《美国铁路杂志》{{/I}}早在','恢复斜体。')],
'ch04-0080':[('从《美国铁路杂志》的遭遇','从{{I}}《美国铁路杂志》{{/I}}的演变','恢复斜体并避免遭遇的贬义。'),('开始在做工程知识的同时发布金融信息','开始在刊载工程知识之外发布金融信息','alongside knowledge指并列刊载，不是做知识。'),('以《美国铁路便览》这一新形式','以{{I}}《美国铁路便览》{{/I}}这一新形式','恢复斜体。'),('最终，《便览》每年','最终，{{I}}《便览》{{/I}}每年','恢复斜体。')],
'ch04-0081':[('《便览》第一卷','{{I}}《便览》{{/I}}第一卷','恢复斜体。'),('《便览》意在','{{I}}《便览》{{/I}}意在','恢复斜体。')],
'ch04-0082':[('世界上第一个按价值加权的股市指数，即今天所称的标普 500 指数','世界上第一个按市值加权的股市指数，也创设了今天所称的标普 500 指数','and不应擅改为即，避免等同两个历史阶段；value-weighted市值加权。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits:continue
 old=r['translation'];why=[]
 for a,b,c in edits[r['id']]:
  assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b);why.append(c)
 pattern=r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}'
 assert re.findall(pattern,old)==re.findall(pattern,r['translation'])
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=why))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
ids=[f'ch04-{i:04}' for i in range(69,83)]+[f'note-ch4-{i:03}' for i in range(74,84)]
e=dict(read_ids=ids,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',queries=['ch04-0081 original ratio11,250,000/4,868,428 is about2.31 not2.5; retain quote and assess editorial note at chapter close','ch04-0074/note079 Veblen1905 may refer edition not first publication1904; verify limited publisher evidence at close','ch04-0082 index origin and merger dates retained as source, not independent financial history validation','note076 singular separate work followed by one/another awkward source resolved by two works in translation; no content loss'],next='ch04-0083 and note-ch4-084')
(p/'ch04_enterprise_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(ids),len(revs),e['output_sha256'])
