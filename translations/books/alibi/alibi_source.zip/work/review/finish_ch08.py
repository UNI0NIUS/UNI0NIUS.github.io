"""One-time chapter eight final reread, terminology and note-heading audit."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent;f=p/'translation_units.jsonl';raw=f.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='3a902818d5c576fde02d3b91a689047c7c0386e76b3ab918f0eecf68b4d776b5'
rows=[json.loads(s) for s in raw.decode('utf-8').splitlines()];before={r['id']:dict(r) for r in rows}
edits={
'introduction-0037':[('“经济全景”（EconoCon）','“经济全景装置”（EconoCon）','依据第八章完整定义统一造词译名，强调治理装置并保留Panopticon类比。')],
'ch08-0004':[('“经济全景”','“经济全景装置”（EconoCon）','本章首次定义保留原词，与导论统一。'),('他们今天臣服于偿还此前从未来榨取的款项','多数人如今受制于偿还此前从未来榨取的款项这一义务','明确their所指为多数人；不是自愿臣服，也不是前句少数人偿付。')],
'ch08-0005':[('一种赔偿模式','一种偿付保障机制','indemnification由下一句确保债务偿还解释，非一般损害赔偿；与0074偿还本金和利息呼应。')],
'ch08-0034':[('它作为确保可预测未来的稳定力量反而更加重要：它保障了可预测的未来','它作为稳定力量反而愈加重要，因为它保障了可预测的未来','删除前次页标修复引入的近义重复，保留稳定力量因果。')],
'ch08-0060':[('“经济全景”','“经济全景装置”','术语统一。')],
'ch08-0073':[('这是经济全景的关键','这是经济全景装置的关键','术语统一。')],
'notes-0008':[('经济心态','经济治理术','注释分组标题必须与已校正文第五章题名一致。')]
}
revs=[]
for r in rows:
 old=r['translation'];why=[]
 for a,b,c in edits.get(r['id'],[]):
  assert a in r['translation'],(r['id'],a);r['translation']=r['translation'].replace(a,b);why.append(c)
 if why:revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=why))
 if r['id'].startswith('notes-') and r['status']=='translated':r['review_status']='semantic_reviewed'
chapter=[r for r in rows if (r['section']=='ch08' or r['id'].startswith('note-ch8-')) and r['status']=='translated']
seen=set()
for name in ['opening','capture']:seen.update(json.loads((p/f'ch08_{name}_revisions.json').read_text(encoding='utf-8'))['read_ids'])
seen.update(json.loads((p/'ch08_close_evidence.json').read_text(encoding='utf-8'))['read_ids'])
assert seen=={r['id'] for r in chapter} and len(chapter)==134
refs=[];notes=[]
for r in chapter:
 pat=r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}'
 assert re.findall(pat,r['source_text'])==re.findall(pat,r['translation']),r['id']
 refs+=re.findall(r'\{\{N:([^}]+)\}\}',r['translation'])
 if r['id'].startswith('note-ch8-'):notes.append(r['id'])
assert sorted(refs)==sorted(notes) and len(notes)==49
byid={r['id']:r for r in rows}
heading_pairs=[('notes-0003','introduction-0002')]+[(f'notes-{n+3:04d}',f'ch{n:02d}-0002') for n in range(1,9)]
for a,b in heading_pairs:assert byid[a]['translation']==byid[b]['translation']
for r in rows:
 a=before[r['id']]
 assert {k:v for k,v in a.items() if k not in ['translation','review_status']}=={k:v for k,v in r.items() if k not in ['translation','review_status']}
 if r['id'] not in edits and not (r['id'].startswith('notes-') and r['status']=='translated'):assert a==r
assert all(r.get('review_status')=='semantic_reviewed' for r in rows if r['status']=='translated')
tf=p/'term_decisions.json';terms=json.loads(tf.read_text(encoding='utf-8'));terms['scope']='All translated units source-compared; global terminology audit pending'
for t in terms['terms']:
 if t['en']=='EconoCon':t.update(zh='经济全景装置',note='依据导论0037及第八章0004/0060/0073的Panopticon松散类比与治理功能定译；首次定义保留EconoCon，英语书目标题不改。')
terms['terms'].append(dict(en='indemnification',zh='偿付保障（本章语境）',note='第八章0005下一句定义为确保债务偿还，不按一般损害赔偿解释。'))
qf=p/'ch08_query_resolution.json';q=json.loads(qf.read_text(encoding='utf-8'));q['status']='closed_with_disclosed_source_limits';q['remaining']='全书统检、图表及格式和输出传播验收；无本章未处理的译文待办。'
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
for name,obj in [('term_decisions.json',terms),('ch08_query_resolution.json',q)]: (p/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
e=dict(status='chapter_review_complete_with_disclosed_source_limits',targeted_reread_ids=['introduction-0037','ch08-0004','ch08-0005','ch08-0034','ch08-0055','ch08-0060','ch08-0067','ch08-0073','ch08-0074','ch08-0082','ch08-0088'],additional_read_ids=[f'notes-{i:04d}' for i in range(2,12)],revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_reviewed_count=134,notes=49,total_translated_source_compared=1719,checks=['134 chapter units covered','49 note references/definitions','source fields and structural tokens preserved','nine note-group headings match chapters','all1719 translated units carry semantic_reviewed; global audit still pending'],next='global audit: terminology, markup, images, index, original preservation, render overrides, output baseline')
(p/'ch08_final_evidence.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
cp=p.parents[2]/'工作文档'/'Alibi后续工作检查点.md';s=cp.read_text(encoding='utf-8')
entry='第八章章末收口及附属标题校读完成：11处重点回读，EconoCon定为经济全景装置（首次保留原词），indemnification按上下文改偿付保障；修复代词指向与前次修订重复句。10个注释分组标题均源译对照，第五章题名同步经济治理术。7单元修订，134章内单元/49原注覆盖和结构检查通过，1719个有效译文单元现均已逐项读过；这不等于全书统检或排版验收。证据ch08_final_evidence.json；finish_ch08.py一次性不重跑。规范稿SHA256 '+e['output_sha256']+'。**实际下一位置：全书集中统检（跨章术语、格式令牌、图表、索引、原稿保留与输出约定），然后严格对齐Thinking Art生成交付物**。排版、网站发布与线上验收未开始。\n\n'
assert '## 授权与当前状态' in s;cp.write_text(s.replace('## 授权与当前状态',entry+'## 授权与当前状态',1),encoding='utf-8')
print(json.dumps(dict(revised=len(revs),translated=1719,sha256=e['output_sha256']),ensure_ascii=False))
