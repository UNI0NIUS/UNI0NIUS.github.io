"""One-time chapter six opening semantic review; do not rerun."""
import json, hashlib, re
from pathlib import Path
p=Path(__file__).parent
f=p/'translation_units.jsonl'
raw=f.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='78ef34d5c36d0931cf0cfb6f4c128c69a63011f11994807d4ed31416d413118e'
rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch06-0003':[('二十世纪最后四分之一，','二十世纪最后二十五年，','补足时期量词。')],
'ch06-0006':[('心照不宣的知识','默会知识','tacit knowledge不是彼此心知的秘密。')],
'ch06-0007':[('经济学家把社会生活的复杂性简化为理性行动者回应激励之计算的结果，这些结果以价格表示，并以最大化其利益的方式呈现。','经济学家把社会生活的复杂性简化为理性行动者计算的结果：这些行动者回应以价格表达的激励，以使自身利益最大化。','价格表达激励，最大化利益修饰行动者回应方式，不是计算结果。'),('关于机构如何构成','关于行动主体如何构成','agencies不限于机构。')],
'ch06-0009':[('什么可以计算、什么不能','什么可以计入、什么不能计入','count为交换核算中的纳入范围。')],
'ch06-0010':[('经济学把它为其建模世界进行格式化的工作置于视野之外','经济学把对其所建模的世界进行格式化的工作置于视野之外','原文被动式不将全部格式化工作归给经济学。'),('不仅因为它抽象自或简化了生产行动者和商品世界的工作，而且因为它抽象自生产一个可在当下被攫取的未来的工作','不仅因为它略去了或简化了生产行动者和商品世界的工作，而且因为它略去了生产一个可在当下被攫取的未来的工作','abstracts from指抽离忽略而非来源于。')],
'ch06-0011':[('雇员必须被投入工作，否则他们可能被拒之门外或被解雇。','雇员必须被安排工作，也可能因雇主停工而被拒绝入厂，或被解雇。','or列举控制手段，不是否则条件；locked out是雇主停工拒入。')],
'ch06-0012':[('纪律制度','规训制度','disciplinary regimes与权力技术语境一致。')],
'ch06-0013':[('把大西洋鳕鱼转化为可以附加所有权主张并加以交易的资产','把大西洋鳕鱼转化为资产，使所有权主张可以附着其上并进而被交易','明确所有权主张的附着与交易关系。')],
'ch06-0014':[('其财产关系人们已经知道数十年甚至数代','其中的财产关系已存在数十年甚至数代','have known指这些场所已历经财产关系，不是人们知晓这些关系。')],
'ch06-0016':[('却远非无法无天','却绝非没有规则约束','lawless此处强调非正式安排仍有道德权利义务规则，避免贬义判断。')],
'ch06-0020':[('前资本主义、非市场世界','非资本主义、非市场世界','non-capitalist不是pre-capitalist，不能增添阶段先后。'),('《另一条道路》（1989）和《资本的奥秘》（2000）','{{I}}《另一条道路》{{/I}}（1989）和{{I}}《资本的奥秘》{{/I}}（2000）','恢复书名斜体。'),('世界第二大有影响力的智库','世界上影响力排名第二的智库','排名指影响力，不是规模。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits: continue
 old=r['translation']; reasons=[]
 for a,b,why in edits[r['id']]:
  assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b);reasons.append(why)
 pattern=r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}'
 assert re.findall(pattern,old)==re.findall(pattern,r['translation'])
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=reasons))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
ids=[f'ch06-{i:04}' for i in range(2,21)]+[f'note-ch6-{i:03}' for i in range(1,14)]
e=dict(read_ids=ids,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',queries=['note002 Steadman Jones likely Stedman; compare previous chapter evidence at chapter close','note007 Code of Capital 2016 likely publication year discrepancy; verify publisher at chapter close','note012 Economist date 21 October 1991 to check if authoritative record obtainable','note004 source Çalişkan versus translation Çalışkan spelling to account for at chapter close','ch0003 alongside versus ch0006 a generation earlier: retain source conceptual chronology, reread at chapter close','Properties title may carry property/attribute double meaning; decide after entire chapter','note008 Leung-Sea name ordering compare earlier chapter decision; do not silently rewrite bibliography'],next='ch06-0021 and note-ch6-014')
(p/'ch06_opening_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
checkpoint=p.parents[2]/'工作文档'/'Alibi后续工作检查点.md'
s=checkpoint.read_text(encoding='utf-8')
entry='第六章开头已源译校读：ch06-0002—0020及原注001—013共32有效单元，修订11单元；累计1286。修复价格所修饰的激励、行动主体、默会知识、abstracts from忽略义、雇主停工控制手段、财产关系已存在及非资本主义误作前资本主义，恢复书名斜体。证据ch06_opening_revisions.json，review_ch06_opening.py一次性不重跑。书目姓名/年份、题名双义与治理抽象年代关系留章末集中核对。当前规范稿SHA256 '+e['output_sha256']+'。**实际下一位置：ch06-0021及note-ch6-014**。第六章未完成，全书统检排版发布未开始。\n\n'
assert '## 授权与当前状态' in s
checkpoint.write_text(s.replace('## 授权与当前状态',entry+'## 授权与当前状态',1),encoding='utf-8')
print(len(ids),len(revs),e['output_sha256'])
