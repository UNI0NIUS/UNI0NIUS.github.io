"""Read-only, repeatable global canonical/source structural audit."""
import json,re,hashlib,collections
from pathlib import Path
p=Path(__file__).parent;b=p.parents[1]
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
f=p/'translation_units.jsonl';rows=[json.loads(s) for s in f.read_text(encoding='utf-8').splitlines()]
orig=b/'work/translation/translation_units.jsonl';old=[json.loads(s) for s in orig.read_text(encoding='utf-8').splitlines()]
checks={};checks['draft_json_preserved']=sha(orig)=='a39cdaee5eaf75fc4afdc90e76de8d55961357cb4700d190185f34b3356e0c24'
checks['draft_markdown_preserved']=sha(b/'output/The_Alibi_of_Capital_资本的托词_初译稿.md')=='37dce4e904f232b6046f528091ad66a057dee6fe65d8cd2b381ba51505288ee0'
epubs=list(b.glob('*.epub'));checks['original_epub_preserved']=len(epubs)==1 and sha(epubs[0])=='9dab51f1594fdc5899968d28cb3d767c96f58a7b65ef5476b0c86617d93b8abb'
checks['ids_and_order']=len(rows)==2752 and [r['id'] for r in rows]==[r['id'] for r in old]
sourcekeys=['id','section','kind','source_refs','source_text','source_markup','printed_pages','page_start','page_end','note_refs','status']
checks['source_fields_preserved']=all(all(r[k]==o[k] for k in sourcekeys) for r,o in zip(rows,old))
checks['excluded_preserved']=all(r==o for r,o in zip(rows,old) if r['status']=='excluded')
translated=[r for r in rows if r['status']=='translated']
checks['translated_coverage']=len(translated)==1719 and all(r['translation'].strip() and r.get('review_status')=='semantic_reviewed' for r in translated)
pat=r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}'
checks['structural_tokens']=all(re.findall(pat,r['source_text'])==re.findall(pat,r['translation']) for r in translated)
checks['inline_tag_balance']=all(all(r['translation'].count('{{'+tag+'}}')==r['translation'].count('{{/'+tag+'}}') for tag in ['I','B']) for r in translated)
pages=[];refs=[]
for r in rows:
 t=r['translation'] if r['status']=='translated' else r['source_text'];pages+=re.findall(r'\{\{P:([^}]+)\}\}',t);refs+=re.findall(r'\{\{N:([^}]+)\}\}',t)
m=json.loads((b/'work/source/source_manifest.json').read_text(encoding='utf-8'))
checks['400_pages_in_original_order']=len(pages)==400 and len(set(pages))==400 and pages==[a['page'] for a in m['pagebreak_sequence']]
definitions=[r['id'] for r in rows if r['kind']=='note']
checks['853_notes_bijection']=len(refs)==len(set(refs))==len(definitions)==853 and sorted(refs)==sorted(definitions)
checks['six_source_images_unchanged']=len(m['images'])==6 and all(sha(b/a['path'])==a['sha256'] for a in m['images'])
en=json.loads((p/'editor_notes.json').read_text(encoding='utf-8'));ids={r['id'] for r in rows}
checks['independent_editor_notes_targets']=len({n['id'] for n in en})==len(en) and all(n['unit_id'] in ids and n['text'].startswith('校注：') for n in en)
o=json.loads((p/'render_overrides.json').read_text(encoding='utf-8'))
checks['render_override_targets']=all(i['unit_id'] in ids and (i.get('action')!='link_text_to_unit' or i['target_unit_id'] in ids) for i in o['items'])
checks['old_core_term_forms_absent']=not any(any(t in r['translation'] for t in ['经济心态','取消赎回权','国家外技艺']) for r in translated)
findings={'markdown_emphasis_units':[r['id'] for r in translated if '*' in r['translation']], 'pending':['figure image/alt/long-description visual review','global glossary contextual audit beyond selected old forms','English index output reconstruction and entry coverage','font/layout/reference baseline and rendered output QA','actual link resolution and editor-note rendering in every output']}
report=dict(canonical_sha256=sha(f),checks=checks,passed=all(checks.values()),counts=dict(records=len(rows),translated=len(translated),pages=len(pages),original_notes=len(definitions),editor_notes=len(en)),findings=findings,scope='Canonical structural checks only; not proof of final semantic/layout/publication acceptance')
(p/'global_structure_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,ensure_ascii=False));assert report['passed']
