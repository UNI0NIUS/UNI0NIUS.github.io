"""One-time Egypt/development semantic batch."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent;f=p/'translation_units.jsonl';raw=f.read_bytes();rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch05-0078':[('一支敌对军队','一支与埃及方面竞争的军队','rival指相互竞争，不直接断言敌军。'),('一支埃及旅','埃及军队的一个旅','修复量词搭配。'),('法卢贾口袋（该地区由此得名）','后来被称为“法卢贾口袋”的地区','as became known是地区的后称，不说村庄因此得名。')],
'ch05-0080':[('经营苏伊士运河的英资公司','经营苏伊士运河的英法公司','补回French所有权。')],
'ch05-0081':[('一群年轻军官','一群初级军官','junior指军阶层级，不等同年龄。'),('其他非常大的土地占有','其他大宗地产','landholdings为地产而非占有动作。')],
'ch05-0082':[('由于向马歇尔计划出让了资助欧洲战后重建的使命','由于资助欧洲战后重建的使命已由马歇尔计划接替','lost to不暗示主动出让。'),('迈出了夺取南巴勒斯坦其余地区和占领西奈的第一步，占领埃及领土直至苏伊士','由此迈出了向南巴勒斯坦其余地区和西奈推进、占领直至苏伊士的埃及领土的第一步','避免把后续占领全部误落在1955年2月事件上，保留原作first step目的关系。')],
'ch05-0085':[('重要通信路线','重要交通通道','communication route此处为航运通道而非电信。')],
'ch05-0087':[('尝试挑起地方经济计算的这些力量','尝试以军事手段激发这些地方经济计算的力量','补回militarily。'),('以与沙特阿拉伯结盟为基础的公司“石油秩序”','以与沙特阿拉伯结盟为基础、由公司构建的“石油秩序”','corporate-built是公司构建，非仅公司所有或属性。'),('经济心态的新方法','经济治理术的新方法','协调定义。'),('集体经济计算的纪律','集体经济计算的规训','协调治理语境。')],
'ch05-0088':[('一家德国工程公司联合体','一个德国工程公司联合体','多家公司组成联合体。'),('英镑信贷','英镑债权余额','明确埃及拥有的储备债权，与本章0004协调。'),('释放这些信贷','释放这些余额','同一所指。'),('蓄水引尼罗河水的计划','拦蓄和引流尼罗河水的计划','修复中文语法。'),('大约在延迟的大坝贷款利息可能到期之时','大约在大坝贷款缓期支付的利息可能到期之时','delayed interest缓期支付而非无意逾期。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits:continue
 old=r['translation'];why=[]
 for a,b,c in edits[r['id']]:
  assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b);why.append(c)
 pattern=r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}'
 assert re.findall(pattern,old)==re.findall(pattern,r['translation'])
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=why))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
ids=[f'ch05-{i:04}' for i in range(78,91)]+[f'note-ch5-{i:03}' for i in range(61,76)]
e=dict(read_ids=ids,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',queries=['note067 explicitly cites Spycatcher chapter8; source wrongly links Alibi8; precise output override added, validate at chapter end','ch05-0082 source1955attack asfirststep toward laterSinaioccupation preserved, do not interpret fulloccupation asFebruary1955','ch05-0078 terror/ethniccleansing attribution and400000 estimate retain as source historical account, not independent archive review','ch05-0089 probably preserved; do not convert RosensteinRodan inferred view into certain documentedquote','note065 repeats Staples/Sayward author issue already queued','note070 missing subtitlecolon normalized draft retained as punctuation only; no silent change to substantive bibliography','ch05-0079 source usesFaluja forboth while earlier Chinese differentiates费卢杰/法卢贾; chapter-end consider clarifying sharedname rather than erase geographicaldistinction'],next='ch05-0091 and note-ch5-076')
(p/'ch05_egypt_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
o=p/'render_overrides.json';d=json.loads(o.read_text(encoding='utf-8'));assert not any(x['unit_id']=='note-ch5-067' for x in d['items'])
d['items'].append(dict(unit_id='note-ch5-067',action='render_cross_reference_as_plain_text',targets=['16_Chapter08.xhtml'],reason='原注引用Spycatcher第八章，底本误链本书第八章；保留可见文字并在输出移除误导跳转。'));o.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(ids),len(revs),e['output_sha256'])
