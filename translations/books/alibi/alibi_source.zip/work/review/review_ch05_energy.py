"""One-time energy and labour semantic review."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent;f=p/'translation_units.jsonl';raw=f.read_bytes();rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch05-0002':[('经济心态','经济治理术','0020明确economentality为governmentality的一种模式；不能仅译心理状态。')],
'ch05-0020':[('把未来引入政府','把未来引入治理','government为治理过程。'),('“经济心态”','“经济治理术”（economentality）','显式解释作者造词及其与治理术的联系。')],
'ch05-0021':[('经济心态','经济治理术','与定义协调，章末统一本章余处。')],
'ch05-0022':[('经济心态、因而经济，是作为围绕资本化的斗争的一部分而出现的。','经济治理术，以及由此形成的经济整体，是作为围绕资本化的斗争的一部分而出现的。','消除不完整并列，明确对象随治理模式形成。'),('埃及和南方许多地区','埃及和全球南方许多地区','与前段政治经济区域用语一致。')],
'ch05-0023':[('最大规模工业行动浪潮','最大规模劳工行动浪潮','industrial action指罢工等劳工行动，不是工业生产行动。'),('1945—6 年的罢工从已被置于军队控制下的全国炼油厂开始','1945—6 年的罢工从已被置于军队控制下的美国炼油厂开始','the country’s不意味着全国每一座炼油厂。')],
'ch05-0024':[('绰号“圣牛”','绰号{{I}}“圣牛”{{/I}}','恢复原文斜体。')],
'ch05-0026':[('其他有组织力量','其他有工会组织的力量','保留unionised具体工会组织性。'),('第一次世界大战前后赢得的社会和民主权利','第一次世界大战之前及此后赢得的社会和民主权利','before and since不只战前战后紧邻时段。')],
'ch05-0029':[('海法是一条现有伊拉克—英国修建输油管道的终点','海法是一条由英国修建、从伊拉克出发的既有输油管道的终点','原译错误拼成伊拉克—英国路线，源文英国为修建者。'),('争取较少不稳定的集体生活','争取更有保障的集体生活','less precarious指更有保障、脆弱性较低，修复中文表达。')],
'ch05-0033':[('相互关联、破坏性、民主的集体行动','相互联动、能够中断生产和供应的民主集体行动','disruptive承接管道/能源停运机制，避免泛化为破坏行为。')],
'note-ch5-024':[('但消费了略高于 60%。换言之，净进口仅供应了消费的 1%','但其消费量占世界总量略高于 60%。换言之，净进口供应的比例仅约为消费量的 1%','显式保留世界总量分母，barely避免译成精确等于；原作比例疑点单独留待章末。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits:continue
 old=r['translation'];why=[]
 for a,b,c in edits[r['id']]:
  assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b);why.append(c)
 pattern=r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}'
 assert re.findall(pattern,old)==re.findall(pattern,r['translation'])
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=why))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
ids=[f'ch05-{i:04}' for i in range(16,34)]+[f'note-ch5-{i:03}' for i in range(17,33)]
e=dict(read_ids=ids,reread_ids=['ch05-0002'],revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',queries=['economentality defined0020 as governmentality mode; changed reviewed occurrences/title to经济治理术, finish chapter and global references later','note024 59percent world output versus60percent world consumption does not alone imply imports barely1percent of US consumption; stock flows/rounding may matter; retain source and add bounded editorial at chapter end','ch05-0024 1947 National Security Act Department of Defense naming may conflate National Military Establishment and1949 rename; verify official history at chapter close','ch05-0031 says12May day after railway defeat while0023 prevention10May and0026 same-day10May; differentiate planned11Maystrike and10Mayinjunction, source retained','note027 remainder split four equal parts means23.75percent each of whole, existing translation其余部分由四家各占四分之一 is valid; not25percent of whole','note032 note60 internal textual reference must resolve in final render; source has no N token, consider exact render link after chapter complete','author labour/oil/MarshallPlan causal interpretation preserved, not independently audited all historical claims'],next='ch05-0035 and note-ch5-033')
(p/'ch05_energy_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(len(ids),len(revs),e['output_sha256'])
