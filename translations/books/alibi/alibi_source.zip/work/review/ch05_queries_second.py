"""One-time second chapter-five query annotations."""
import json
from pathlib import Path
p=Path(__file__).parent;f=p/'editor_notes.json';d=json.loads(f.read_text(encoding='utf-8'))
new=[
dict(id='ed-ch5-defense-name',unit_id='ch05-0024',text='校注：底本把1947年设立的机构直接称为国防部。美国国会访客中心对档案的说明区分1947年的National Military Establishment与1949年修法后采用的Department of Defense名称。正文保留原作概述。',sources=['https://www.visitthecapitol.gov/artifact/new-organization-national-defense-chart-accompanying-statement-secretary-war-robert-p'],source_locator='档案说明及The National Security Act小节，已打开'),
dict(id='ed-ch5-ito',unit_id='ch05-0072',text='校注：底本概括为美国国会拒绝批准宪章。世界贸易组织的历史说明具体记为：国会反对强烈，美国政府于1950年宣布不再寻求国会批准《哈瓦那宪章》。原作概述不宜据此理解为一次明确的否决表决。',sources=['https://www.wto.org/English/thewto_e/whatis_e/tif_e/fact4_e.htm'],source_locator='The GATT years中1948—1950年段，已打开'),
dict(id='ed-ch5-dewey-subtitle',unit_id='note-ch5-043',text='校注：底本把副标题An Essay in Political Inquiry连续重复两次。Penn State University Press在JSTOR所列2012年Melvin L. Rogers编订本书名只含一次该副标题。原注重复照录。',sources=['https://www.jstor.org/stable/10.5325/j.ctt7v1gh'],source_locator='出版方图书页面题名与编者，已打开'),
dict(id='ed-ch5-lehmann',unit_id='note-ch5-010',text='校注：底本本注姓名作Fritz Lehman，原注014则作Fritz Lehmann。德国数字图书馆的人名规范记录以Fritz Lehmann列出本书，支持双n拼写；两处底本拼写均照录。',sources=['https://www.deutsche-digitale-bibliothek.de/person/gnd/131347438'],limit='依据人名规范记录检索元数据；直接打开Cache miss，未读取1938年题名页。'),
dict(id='ed-ch5-oil-ratio',unit_id='note-ch5-024',text='校注：本注所列59%与略高于60%均以世界总量为基数，两者之差不能直接当作美国消费量的1%。若仅按同一世界总量且忽略库存等因素计算，净进口占美国消费的比例应为差额除以美国消费份额。本注未提供足够口径来复算“仅约1%”，原数照录。',sources=[],source_locator='本注数值分母的内部核对',limit='未核对原统计表库存、取整或其他口径，不据简单差额给出替代的历史净进口率。'),
dict(id='ed-ch5-nato-date',unit_id='ch05-0070',text='校注：本段用北约名称概述1948年竞选期间的政策。北约官方历史记载，正式公开条约谈判于1948年12月开始，北大西洋公约于1949年4月4日签署。这里应区分此前的联盟构想与已经成立的组织。正文保留原作追述。',sources=['https://nato.int/en/about-us/organization/founding-treaty'],source_locator='Founding treaty页面，已打开')]
for n in new:n['verified_on']='2026-10-23'
assert not {n['id'] for n in new}&{n['id'] for n in d};d.extend(new);f.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
f=p/'ch05_query_resolution.json';q=json.loads(f.read_text(encoding='utf-8'));q['resolutions'] += [dict(unit_id=n['unit_id'],decision='editor_note_with_stated_evidence',editor_note_id=n['id']) for n in new]
q['remaining']='本章重点回读、术语表更新、未改作者判断的证据限度收束，以及原注032文本引用与067链接例外确认。'
f.write_text(json.dumps(q,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(len(d))
