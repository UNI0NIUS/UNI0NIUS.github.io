"""One-time chapter closing read and structural audit; queries remain."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent;f=p/'translation_units.jsonl';raw=f.read_bytes();rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch04-0094':[('国民经济学只是在把“经济”变成自身对象的过程中才成为默认尺度','国家尺度只是在把“经济”变成一个独立对象的过程中才成为默认尺度','尺度为国家而非学科国民经济学。'),('然而在《经济与社会》中','然而在{{I}}《经济与社会》{{/I}}中','恢复书名斜体。')],
'ch04-0098':[('对当代资本主义生活','对当时资本主义生活','以韦伯写作时代为参照。')],
'ch04-0104':[('对当代资本主义经济化','对当时资本主义经济化','以韦伯写作时代为参照。')],
'ch04-0107':[('两种模式：{{I}}经济{{/I}}','两种模式：“{{I}}这个{{/I}}经济整体”（the economy）','延续过程与对象的区别。')],
'ch04-0108':[('这些论点后来成为后来被称为新自由主义的智识运动的核心','这些论点后来成为被称为新自由主义的智识运动的核心','去除无意义重复。'),('正在排版《经济与社会》的第一部分','正在排版{{I}}《经济与社会》{{/I}}的第一部分','恢复斜体。'),('反对{{I}}经济{{/I}}作为对象出现','反对“{{I}}这个{{/I}}经济整体”（the economy）作为对象出现','协调对象义。')],
'ch04-0112':[('韦伯《经济与社会》的第一部分','韦伯{{I}}《经济与社会》{{/I}}的第一部分','恢复书名斜体。'),('原文也不含不定冠词“一个”','原文也不含不定冠词 an（“一个”）','讨论英文冠词，不把中文数量短语称为冠词。')],
'ch04-0113':[('对《经济与社会》的重译','对{{I}}《经济与社会》{{/I}}的重译','恢复书名斜体。')],
'ch04-0114':[('恢复“经济”被发明之前思考经济的一种方式','恢复“这个经济整体”（the economy）被发明之前思考经济的一种方式','同段economy/the economy不能合并而造成自相矛盾。'),('“经济”不是人类社会生活的普遍领域','“这个经济整体”不是人类社会生活的普遍领域','同一所指保持明确。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits:continue
 old=r['translation'];why=[]
 for a,b,c in edits[r['id']]:
  assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b);why.append(c)
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=why))
read=[r['id'] for r in rows if r.get('translation') and (re.fullmatch(r'ch04-\d{4}',r['id']) and r['id']>='ch04-0094' or r['id'].startswith('note-ch4-') and r['id']>='note-ch4-098')]
seen=set(read)
for name in ['opening','abstraction','economisation','credit','enterprise','weber']:
 seen.update(json.loads((p/f'ch04_{name}_revisions.json').read_text(encoding='utf-8'))['read_ids'])
chapter=[r for r in rows if (r['section']=='ch04' or r['id'].startswith('note-ch4-')) and r['status']=='translated']
assert {r['id'] for r in chapter}==seen,({r['id'] for r in chapter}-seen,seen-{r['id'] for r in chapter})
refs=[];notes=[r['id'] for r in chapter if r['id'].startswith('note-ch4-')]
for r in chapter:
 refs+=re.findall(r'\{\{N:([^}]+)\}\}',r['translation'])
 pattern=r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}'
 assert re.findall(pattern,r['source_text'])==re.findall(pattern,r['translation']),r['id']
 r['review_status']='semantic_reviewed';r['status_reason']='source/translation comparison completed; chapter structural checks passed; external queries recorded separately'
assert sorted(refs)==sorted(notes)
oldrows=[json.loads(x) for x in raw.decode('utf-8').splitlines()];chapterids={r['id'] for r in chapter}
for a,b in zip(oldrows,rows):
 assert a['id']==b['id']
 for k in ['source_text','source_markup','source_refs','printed_pages','note_refs','page_start','page_end']:assert a.get(k)==b.get(k)
 if b['id'] not in chapterids:assert a==b
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
e=dict(read_ids=read,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_reviewed_count=len(chapter),notes=len(notes),status='semantic_and_structure_review_passed_external_queries_pending',checks=['all chapter translated units read','115 note references match definitions','structural token order','source fields unchanged','other chapters unchanged'],queries=['note-ch4-100 Paul Siebeck incorrectly described as German translator of German original; verify publisher/titlepage before editorial note','note-ch4-111 Ibid follows Hayek1976 and Mises1949 but page2/4/21/34 likely Hayek1935; inspect cited text before precise render/editorial action','ch04-0112 system nowhere in text claim may refer definition rather than whole book; retain author scope, no unverified universal claim of independent review','chapter-end reread economy/economising/economisation distinction across0086–0114 and previous definitions; author political-theoretical argument preserved as such'],next='chapter4 query resolution, terminology reconciliation and targeted reread')
(p/'ch04_close_evidence.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(read),len(revs),len(chapter),len(notes),e['output_sha256'])
