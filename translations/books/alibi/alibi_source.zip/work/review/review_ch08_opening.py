"""One-time source/translation review of chapter eight opening. Do not rerun."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent; f=p/'translation_units.jsonl';raw=f.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='e3663cb7c254256b1c878433bb53aa5d587031c91ce5ad6f6dabc2e8e415517a'
rows=[json.loads(s) for s in raw.decode('utf-8').splitlines()]
ids=[r['id'] for r in rows if (('ch08-0002'<=r['id']<='ch08-0026') or ('note-ch8-001'<=r['id']<='note-ch8-010')) and r['status']=='translated']
edits={
'ch08-0007':[('化石燃料、经济和增长作为资本的托词。','化石燃料与经济，以及作为资本托词的增长。','as an alibi修饰growth，避免把三个概念一概称为托词。')],
'ch08-0013':[('其中一半以上是 1990 年以后燃烧的','所有燃烧量的一半以上是 1990 年以后燃烧的','明确统计分母仍为工业时代以来总量，不误指1960年后的80%。')],
'ch08-0014':[('才开始使用“经济”一词','才开始使用“the economy”（作为对象的经济整体）这一说法','保留定冠词与旧economy概念的关键区分，避免声称此前没有经济一词。')],
'ch08-0015':[('经济的出现主要是欧美叙事','经济这一对象的出现主要发生于欧美','story在这里指历史过程，非仅叙事文本。')],
'ch08-0017':[('变成一条平直得多、近乎水平的线','变成一条平缓得多的直线','much flatter不意味着近乎水平；对数图斜率仍取决于增长率和坐标比例。'),('少获而善生的生活方式','以更少的物质消耗过好生活的方式','living well with less不是减少收入获取；结合本段去增长和物质消耗语境。')],
'ch08-0018':[('除储备耗尽时开采成本上升之外','除资源储量逐渐减少时开采成本上升之外','reserves run down为资源储量消耗，不是储备已全部耗尽。')],
'ch08-0023':[('是一种{{I}}错误{{/I}}再现，还是一种{{I}}纯粹{{/I}}再现','是一种{{I}}错误{{/I}}的再现，还是{{I}}仅仅{{/I}}一种再现','mere表示仅仅，而非纯净或纯粹性；保留强调位置。'),('但至少对其保持不可知','但至少不预设支持或反对增长的立场','agnostic about growth指对增长本身不持预设取向，不是声称增长不可知。')],
'ch08-0025':[('一种生产物质世界与其再现之{{I}}效果{{/I}}的特定方式','一种制造物质世界与其再现相对立这一{{I}}效果{{/I}}的特定方式','恢复versus：效果是物质/再现的对立，不只是两者的效果。'),('或以物质世界——以及仅仅指涉它、管理它的账户、价格和金融交换体系——的形式','或以物质世界与仅仅指涉它、管理它的账户、价格和金融交换体系相对立的形式','平行解释仍在强调对立，不能译成并列清单。')],
'ch08-0026':[('银行从“产业”中分离的过程，这种分离最初表现为商人生活中两个相互关联的方面，后来在建筑、立法和职业上逐渐分开','银行业从“产业”中逐渐分离的过程：两者起初是商人生活中相互关联的两个方面，后来才在建筑、立法和职业层面彼此分离','starting主语为银行业和产业，而非分离过程本身；修复历史关系。')]
}
revs=[]
for r in rows:
 if r['id'] not in ids:continue
 old=r['translation'];why=[]
 for a,b,c in edits.get(r['id'],[]):
  assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b);why.append(c)
 if why:revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=why))
 r['review_status']='semantic_reviewed'
 assert re.findall(r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}',r['source_text'])==re.findall(r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}',r['translation']),r['id']
for a,b in zip([json.loads(s) for s in raw.decode('utf-8').splitlines()],rows):
 assert {k:v for k,v in a.items() if k not in ['translation','review_status']}=={k:v for k,v in b.items() if k not in ['translation','review_status']}
 if a['id'] not in ids:assert a==b
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
e=dict(read_ids=ids,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',queries=['EconoCon待本章全部论证读完再定译并全书统一。','indemnification在债务偿付语境中不宜只作赔偿，待后文展开协调。','note-ch8-001为2026刊文元数据；note003工作论文编号33:8、note007卷题/编者、note008页码待章末定向核查。','note002燃料比例为作者据2021数据计算；不得使用当前累计数据替换历史分母。'],next='ch08-0027 and note-ch8-011')
(p/'ch08_opening_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
cp=p.parents[2]/'工作文档'/'Alibi后续工作检查点.md';s=cp.read_text(encoding='utf-8')
entry=f'第八章开篇已源译对照：ch08-0002—0026（排除空页标0008）及原注001—010共{len(ids)}有效单元，修订{len(revs)}单元。恢复the economy与旧economy区别、对数图平缓而非近乎水平、物质/再现对立、银行与产业起初关系，澄清燃料比例分母。证据ch08_opening_revisions.json；review_ch08_opening.py一次性不重跑。规范稿SHA256 '+e['output_sha256']+f'；累计{1575+len(ids)}有效单元。EconoCon及indemnification留本章读完协调，书目疑点留章末集中查。**实际下一位置：ch08-0027及note-ch8-011**。第八章尚未章级核对，全书统检、排版与发布未开始。\n\n'
assert '## 授权与当前状态' in s;cp.write_text(s.replace('## 授权与当前状态',entry+'## 授权与当前状态',1),encoding='utf-8')
print(json.dumps(dict(read=len(ids),revised=len(revs),sha256=e['output_sha256']),ensure_ascii=False))
