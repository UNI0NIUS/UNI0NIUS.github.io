"""One-time chapter five opening semantic batch."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent;f=p/'translation_units.jsonl';raw=f.read_bytes();rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch05-0004':[('积累的大额英镑信贷','积累的大额英镑债权余额','credits built up指埃及持有的债权余额，避免误作向埃及发放贷款。')],
'ch05-0005':[('南半球国家','全球南方国家','South为政治经济分类，不是地理南半球。'),('以更多公顷生长较慢的工业作物——棉花和甘蔗——取代快速生长的粮食作物','减少快速生长的粮食作物，扩大生长较慢的工业作物——棉花和甘蔗——的种植面积','避免更多公顷修饰作物的生硬搭配，保留土地配置转变。'),('就是把它称为“经济”','就是把它称为“经济”（the economy）','承接上一章对象义。')],
'ch05-0008':[('“经济”观念本身','“经济整体”（the economy）这一观念本身','与同段旧义明确区分。'),('1933 年美国《经济法》不是规范经济的法律。它是一部经济化法案，{{P:178}}旨在','1933 年美国《节约法》（Economy Act）不是规制经济整体的法律。它是一项实行节约、{{P:178}}节省开支的法案，旨在','Economy Act此处节约义，与下文政府开支相应；保留源页位顺序。')],
'ch05-0009':[('作为一个独特空间或对象的{{I}}经济{{/I}}','作为一个独特空间或对象的“{{I}}这个{{/I}}经济整体”（the economy）','保留the强调及对象义。'),('《纽约时报》','{{I}}《纽约时报》{{/I}}','恢复两处报刊名斜体。'),('作者们是“政府干预经济是现代危机政策必要基准这一经济学派的人士，英国约翰·梅纳德·凯恩斯是该学派著名代言人”','作者们“属于这样一个经济思想学派：它把政府干预经济视为现代危机政策的必要既定条件，英国的约翰·梅纳德·凯恩斯是该学派的一位著名代言人”','修复引文语法，datum指接受的既定条件而非测量基准。')],
'ch05-0010':[('对一家有志于证明所得税减少投资的银行来说','对一家关注所得税减少投资之证据的银行来说','interested in evidence不直接等于有志证明，保留动机限度。'),('希望这本书不会获得其吸引人的形式、清晰的文风以及作者显而易见的胜任和诚实本来应得的流行追随','希望这本书不会得到广泛追捧，尽管若无这些缺陷，凭其吸引人的形式、清晰的文风和作者显而易见的才干与诚实，它本应获得这样的反响','修复otherwise反事实条件及following语义。')],
'ch05-0014':[('向人口征收收入','向民众征收财政收入','raising revenue from a population为公共收入征收，避免人口作为缴款对象的生硬表达。'),('把未来带入政府','把未来带入治理','government为治理活动，与章节题名及论证一致。')],
'note-ch5-008':[('并不是“经济”（Mitchell 不使用这一短语）的一个附属部分','并不是“经济整体”（the economy，Mitchell 不使用这一短语）的一个附属部分','不能把作者不用特定英文短语误成不使用经济一词。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits:continue
 old=r['translation'];why=[]
 for a,b,c in edits[r['id']]:
  assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b);why.append(c)
 pattern=r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}'
 assert re.findall(pattern,old)==re.findall(pattern,r['translation'])
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=why))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
ids=[f'ch05-{i:04}' for i in range(2,16)]+[f'note-ch5-{i:03}' for i in range(1,17)]
e=dict(read_ids=ids,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',queries=['Economentality title经济心态 provisional until chapter explains relation to governmentality; review at chapter end','ch05-0011 Bureau of Budget Commerce Department may be source error versus Treasury; verify authoritative institutional history at chapter close','note-ch5-006 Amy Staples and Amy Sayward may be same author under different names; check publisher before note','note-ch5-008 Breslau32:3 year2020 and pages79–411 likely source anomalies; verify publisher','note-ch5-010 Lehman versus note014 Lehmann source spellings retained for chapter-end check','note004 increased more than threefold translated增长两倍多 consistent final>3 times; no unsupported precise profit audit','ch05-0011 formatting economy and larger definition conceptual wording to revisit after full chapter'],next='ch05-0016 and note-ch5-017')
(p/'ch05_opening_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(ids),len(revs),e['output_sha256'])
