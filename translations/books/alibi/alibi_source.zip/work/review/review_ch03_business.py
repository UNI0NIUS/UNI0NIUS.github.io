"""One-time batch. Chapter review remains in progress."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent; f=p/'translation_units.jsonl'; raw=f.read_bytes()
rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch03-0079': [('因为竞争对手公司很快就会采用{{P:124}}同样的效率','因为竞争对手公司很快就会达到{{P:124}}同样的效率','不能采用效率，保留竞争趋同机制。')],
'ch03-0081': [('在各省，小面额纸币','在地方上，小面额纸币','英国provinces指地方，而非行政省。')],
'ch03-0086': [('部分是为了清偿利润更高的棉花贸易业务所产生的债务','部分是以接收纱厂来抵偿别人因利润更高的棉花贸易业务而欠他们的债务','收购用于抵偿别人欠他们的债，而非他们清偿自身债务；恢复owed方向。'),('标志性的工业革命遗址','标志性的工业革命场所','sites在当时论述中不是已成为遗址。')],
'ch03-0089': [('金融资本在很大程度上并非作为现有商业的剩余或储蓄而产生，也不是通过银行或私人投资者改投新项目。','金融资本在很大程度上，并不是由现有企业的剩余或储蓄经银行或私人投资者转投新项目而形成的。','否定的是将过去剩余转投的整体起源解释，不是否认银行或投资者参与新项目。'),('它的创造不取决于是否有过去积累的剩余可供吸收，而取决于是否把未来建构为一种可靠的剩余索取权，并以可在当下实现和交易的方式获得。','它的创造不取决于是否有过去积累的剩余可供吸收，而取决于能否把未来建构为一种对尚待获取的剩余的可靠索取权，使这种索取权能够在当下变现和交易。','恢复surplus to be acquired未来对象及索取权当下变现的关系。')],
'ch03-0091': [('1860 年至 1914 年期间','1860 年代至 1914 年期间','1860s为年代，非单一年份。')],
'ch03-0092': [('省级和地方银行','地区性和地方银行','不引入英国行政省层级。')],
'note-ch3-130': [('约克郡和西部乡村','约克郡和西部地区（West Country）','West Country为地区名称，不是泛指乡村。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits:continue
 old=r['translation']; reasons=[]
 for a,b,why in edits[r['id']]:
  assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b); reasons.append(why)
 assert re.findall(r'\{\{.*?\}\}',old)==re.findall(r'\{\{.*?\}\}',r['translation'])
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=reasons))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
ids=[f'ch03-{i:04}' for i in range(79,94)]+[f'note-ch3-{i:03}' for i in range(128,143)]
e=dict(read_ids=ids,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',next='ch03-0094 and note-ch3-143',queries=['ch03-0080 source direct exchange of time for labour is conceptually odd; preserve source and consider editorial note after chapter reread','ch03-0084 City Business and later business concept translated 商业/业务 provisionally; reconcile chapter argument at close','ch03-0086 interest figures 3.25 and 5 percent retained; no independent historical finance verification','ch03-0082 English central-bank monopoly wording preserved as source with source note132 qualification; not generalized to present UK rules'])
(p/'ch03_business_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(ids),len(revs),e['output_sha256'])
