"""One-time calculated future/development semantic review."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent;f=p/'translation_units.jsonl';raw=f.read_bytes();rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch05-0057':[('苏联实验的追随者之一','关注苏联实验的人之一','followed指跟踪关注，不能擅断赞同追随。')],
'ch05-0060':[('实际上不再有自由土地','实际上不再有可自由取得的土地','free land为可取得的土地，不是自由这一属性。'),('很可能成为危险而非帮助','既可能带来帮助，也同样可能带来危险','as likely as为同等可能，不是危险胜于帮助。')],
'ch05-0063':[('平缓而均匀地横贯页面','平缓而均匀地向上延伸，横贯页面','补回rising，不能读成水平线。')],
'ch05-0064':[('一个显然稳定的未来','一个看似稳定的未来','apparently表象限定，非确证。')],
'ch05-0066':[('更平等的生命形式','更平等的生活形式','forms of life为社会生活而非生物生命形态。')],
'ch05-0067':[('由国家层面的生产配额设定','由美国各州层面的生产配额设定','state-level在美国石油生产语境为州级，不是联邦国家级。')],
'ch05-0070':[('未来出人意料地进入了政府','未来出人意料地进入了治理','government治理义。'),('为总统第二任期制定一份指导未来的愿景','提出一幅指导总统第二任期的未来愿景','guide对象是任期施政，不是愿景指导未来。')],
'ch05-0072':[('把未来带入政府','把未来带入治理','government治理义。'),('公开监管的协定','公共监管的协定','publicly regulated是公共权力监管，不仅公开透明。'),('其他南方国家','其他全球南方国家','沿用政治经济分类。')],
'ch05-0073':[('把劳工权利扩展到伊拉克石油工人等人民的替代','把劳工权利扩展至伊拉克石油工人等群体的替代方案','修复中文主语搭配。')],
'ch05-0077':[('他们集中在六个最大城镇和一些农业定居点','他们集中在最大的城镇中的六个以及一些农业定居点','half a dozen of the largest不等于恰好排名前六。'),('或按种族分离计划显然的要求组织把巴勒斯坦人从他们的城镇和村庄迁走','或组织把巴勒斯坦人从他们的城镇和村庄迁走，而族群分离的计划似乎要求这样做','apparently为作者推断限定，非明确要求；ethnic为族群。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits:continue
 old=r['translation'];why=[]
 for a,b,c in edits[r['id']]:
  assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b);why.append(c)
 pattern=r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}'
 assert re.findall(pattern,old)==re.findall(pattern,r['translation'])
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=why))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
ids=[f'ch05-{i:04}' for i in range(56,78) if i!=74]+[f'note-ch5-{i:03}' for i in range(47,61)]
e=dict(read_ids=ids,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',queries=['ch05-0066 constant versus falling growth rate and income stagnation claimed in source; do not silently rewrite economic causal argument','ch05-0070 calls NATO existing policy1948 although organisation treaty1949; original wording possibly retrospective umbrella, bounded date check at chapter end','ch05-0072 ITO charter Congress refused ratification may compress withdrawal/no vote; verify authoritative history before editorial note','note060 Arabic malformed source punctuation normalized in draft, transliterations Falluja/Faluja preserved by费卢杰/法卢贾; exact typography final visual QA','ch05-0077 partition/no one agreed/required removal are author historical interpretation; preserve apparently limitation, do not turn into independent factual endorsement','ch05-0067 source decade-by-decade real oil price claim not independently recalculated; preserve historical author claim'],next='ch05-0078 and note-ch5-061')
(p/'ch05_future_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(len(ids),len(revs),e['output_sha256'])
