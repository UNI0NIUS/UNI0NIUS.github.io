"""One-time chapter-six targeted reread and final chapter audit."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent;f=p/'translation_units.jsonl';raw=f.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='20a60cf700eabe71998dfd7f1c49499143a96f87f2116932d5439fa797b25b26'
rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch06-0003':[('它与“经济”的治理同时出现','它在对“经济”的治理之外兴起，与之并存','alongside指并存关系，不强加两种治理同时起源；与0006先后一代的展开相容。')],
'ch06-0006':[('个体经济行动者分散的、往往是默会知识','个体经济行动者所拥有的分散知识——往往是默会知识——','修复前次替换留下的语法残缺。'),('价格作为一个整体，作为一个知识体系运作，它类似但优于政府对经济的统计知识。','从整体来看，价格作为一个知识体系运作，类似于政府关于经济的统计知识，却比后者更优越。','理顺taken as a whole与比较句，保留观点归属。')],
'ch06-0075':[('不得不失去','有所可失','照应0094没有财产可失去；保留拥有与丧失关联，不只译被迫丧失。')],
'ch06-0098':[('而是其履行。它是一种法律工具，用来履行转移','而是对这种所有权的施行。它是一种法律文书，用来实施转移','performance强调产生法律行为的作用，不是所有权本身作为义务被履行。'),('它还必须在实际上被履行','这种行为还必须通过实际动作来完成','明确实物交付的实施行为。')],
'ch06-0101':[('第三，资产可以变现，但又不太容易变现。','第三，这些资产可以相互转换，但又不至于过于容易转换。','fungible与0097可替代性呼应，随后变现实例解释，不将概念直接缩为流动性。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits:continue
 old=r['translation'];why=[]
 for a,b,c in edits[r['id']]:
  assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b);why.append(c)
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=why))
chapter=[r for r in rows if (r['section']=='ch06' or r['id'].startswith('note-ch6-')) and r['status']=='translated']
seen=set()
for name in ['opening','property','history','housing','boundaries']:
 seen.update(json.loads((p/f'ch06_{name}_revisions.json').read_text(encoding='utf-8'))['read_ids'])
seen.update(json.loads((p/'ch06_close_evidence.json').read_text(encoding='utf-8'))['read_ids'])
assert seen=={r['id'] for r in chapter} and len(chapter)==202
refs=[];notes=[]
for r in chapter:
 pat=r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}'
 assert re.findall(pat,r['source_text'])==re.findall(pat,r['translation']),r['id']
 refs+=re.findall(r'\{\{N:([^}]+)\}\}',r['translation'])
 if r['id'].startswith('note-ch6-'):notes.append(r['id'])
assert sorted(refs)==sorted(notes) and len(notes)==94
for a,b in zip([json.loads(x) for x in raw.decode('utf-8').splitlines()],rows):
 assert a['id']==b['id']
 assert {k:v for k,v in a.items() if k!='translation'}=={k:v for k,v in b.items() if k!='translation'}
 if b['id'] not in edits:assert a==b
assert not any('取消赎回权' in r['translation'] or '包容性排斥' in r['translation'] for r in chapter)
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
tf=p/'term_decisions.json';t=json.loads(tf.read_text(encoding='utf-8'));t['scope']='frontmatter/introduction/chapters1–6; later contextual review pending'
for en,zh,note in [
('foreclosure','止赎','第六章统一为止赎，区别于一般没收；全书集中统检核对其他章节。'),
('formalisation','正式化','第六章指纳入正式财产/产权制度，不译空具形式的形式化；具体项目可译产权登记。'),
('inclusive exclusion','包容性排除','正文与原注047一致；exclusion-inclusion仍按原文复合顺序译排除—纳入。'),
('Having to Lose','有所可失','第六章小标题照应0094因为没有财产可失去，兼顾拥有与丧失风险。'),
('The Properties of Markets','市场的属性','保留主标题；property财产双义由正文展开，不在标题擅加解释性副题。'),
('fungible','可替代；可相互转换','0097技术概念用可替代性，0101以牲畜资产互换及变现语境解释，不机械等同高流动性。'),
('performative','述行性','0098契据不仅再现还实施所有权转移；performance按行为译施行，保留法律行为与描述的区别。')]:
 if not any(x['en']==en for x in t['terms']):t['terms'].append(dict(en=en,zh=zh,note=note))
tf.write_text(json.dumps(t,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
of=p/'render_overrides.json';o=json.loads(of.read_text(encoding='utf-8'))
assert not any(x['unit_id']=='note-ch6-019' for x in o['items'])
o['items'].append(dict(unit_id='note-ch6-019',action='link_text_to_unit',target_unit_id='note-ch6-002',source_text='note 2',translation_text='第 2 条注',reason='本章原注019明确以普通文本回指原注002；输出补充精确跳转，规范稿和原注数不变。'))
of.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
qf=p/'ch06_query_resolution.json';q=json.loads(qf.read_text(encoding='utf-8'))
q['resolutions'].extend([
dict(unit_id='ch06-0003',decision='translation_revised',reason='并存治理不等于同时起源，结合0006澄清。'),
dict(unit_id='ch06-0075',decision='title_revised',reason='有所可失照应0094；全书生成目录时采用规范稿。'),
dict(unit_id='ch06-0086',decision='plain_reference_retained',reason='原文普通文字提及第一章，仍保留可读文本；不必将所有普通章节提及强制生成链接。'),
dict(unit_id='note-ch6-019',decision='render_override',reason='增加link_text_to_unit；实际多格式跳转待生成验收。'),
dict(unit_id='ch06-0002',decision='title_retained',reason='市场的属性保留主标题，财产双义由正文表达。'),
dict(unit_id='chapter6',decision='scope_limit',reason='来源核查限于记录的书目/机构/年代疑点；住房率、信贷分类、资本收益、农业集中及作者历史政治因果不宣称独立重做统计或全面事实审计。')])
q['status']='closed_with_disclosed_source_limits';q['remaining']='实际输出链接、标题目录传播和视觉排版留全书生成验收；无本章语义待办。'
qf.write_text(json.dumps(q,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
e=dict(targeted_reread_ids=['ch06-0003','ch06-0006','ch06-0007','ch06-0019','ch06-0046','ch06-0075','ch06-0085','ch06-0094','ch06-0098','ch06-0101','ch06-0108','note-ch6-019'],revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_reviewed_count=202,notes=94,status='chapter_review_complete_with_disclosed_source_limits',checks=['read coverage202','94references/94definitions','structural tokens and source fields preserved','other units unchanged','foreclosure and inclusive exclusion consistency','textual note019 target002 exists'],next='ch07-0001 and note-ch7-001')
(p/'ch06_final_evidence.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
cp=p.parents[2]/'工作文档'/'Alibi后续工作检查点.md';s=cp.read_text(encoding='utf-8');entry='第六章收口完成：12处重点回读、5单元增量修订，修复并存/同时起源、默会知识语法及契据施行关系，小标题定为有所可失。202单元覆盖、94原注对应、结构令牌、源字段和其他单元保留检查通过。术语表更新；注019指向注002加入link_text_to_unit，实际输出跳转仍待验收。疑点状态closed_with_disclosed_source_limits；证据ch06_final_evidence.json，finish_ch06.py一次性不重跑。规范稿SHA256 '+e['output_sha256']+'，累计1456有效单元。**实际下一位置：ch07-0001及note-ch7-001**。全书统检、排版、发布与线上验收未开始。\n\n';assert '## 授权与当前状态' in s;cp.write_text(s.replace('## 授权与当前状态',entry+'## 授权与当前状态',1),encoding='utf-8');print(e['output_sha256'])
