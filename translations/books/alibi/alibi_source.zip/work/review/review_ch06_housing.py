"""One-time housing batch: source/translation read, no chapter-wide pass yet."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent; f=p/'translation_units.jsonl';raw=f.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='16c816781e5c767e11354034ac30449cb5349931774f0c465c5ac5c1a0b1e65b'
rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch06-0051':[('正式或资本主义可得被辨识之每一个地点','可以辨识出正式制度或资本主义的每一个地点','修复可得被辨识语法，保留空间论证。')],
'ch06-0054':[('《资本的奥秘》','{{I}}《资本的奥秘》{{/I}}','恢复书名斜体。')],
'ch06-0056':[('《资本的奥秘》','{{I}}《资本的奥秘》{{/I}}','恢复书名斜体。'),('大多数住房是完全自有','大多数住房由房主全额持有，不负担购房贷款','owned outright明确无未清偿房贷，而非仅产权名义归属。')],
'ch06-0057':[('取消赎回权的威胁','止赎的威胁','与本章术语对齐。')],
'ch06-0059':[('通常还从该家庭雇人帮忙','通常还会借助该家庭成员的帮忙','employs help指利用帮助，不能直接断言有偿雇佣。')],
'ch06-0060':[('随着需求和收入增加添加房间、楼层或设施','随着需求的发展和收入的到账，增建房间、楼层或添置设施','income arrives是资金陆续到位，并非必须收入增长。')],
'ch06-0061':[('此前，大部分农地因每年灌溉淹水而受到保护，不得建房','此前，每年为灌溉而淹没田地的做法，使大部分农地免于被用于建房','原文是灌溉淹水构成物理阻碍，并非当时法律禁止。')],
'ch06-0062':[('合法住房不必承担违法建筑频繁受到的传唤和罚款，也更容易接通水和电','合法住房不必承担违法建筑因频繁传唤和罚款而产生的费用，也可能更容易接通水和电','补回费用对象及may可能性限定。')],
'ch06-0063':[('合法化使土地价值至少提高十倍','合法化使土地价值至少升至原来的十倍'),('合法化可使价值提高三十到四十倍','合法化可使价值升至原来的三十到四十倍')],
'note-ch6-047':[('“包容性排斥”','“包容性排除”','正文原注术语对齐。'),('我在本书中对这一术语的用法','我在这里对这一术语的用法','here不扩展到全书。')],
'note-ch6-053':[('{{/I}}{{P:357}}{{I}}Critique','{{/I}} {{P:357}}{{I}}Critique','补回跨页英文词间空格。')],
'note-ch6-055':[('枣椰树','椰枣树','与正文植物名称一致。')],
'note-ch6-056':[('60 万至 120 万费丹','60 万至 120 万英亩','原文明列acres，虽注040允许近似互用仍应准确照录单位。')],
'note-ch6-058':[('在开罗周边以及开罗以北的尼罗河三角洲','在大城市周边以及开罗以北的尼罗河三角洲','large cities不限开罗，恢复地理范围。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits:continue
 old=r['translation'];why=[]
 for item in edits[r['id']]:
  a,b=item[:2];c=item[2] if len(item)>2 else 'by a factor of指最终为原来的倍数，避免提高倍数多算一个基数。'
  assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b);why.append(c)
 pat=r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}'
 assert re.findall(pat,old)==re.findall(pat,r['translation'])
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=why))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
ids=[f'ch06-{i:04}' for i in range(51,66)]+[f'note-ch6-{i:03}' for i in range(47,63)]
e=dict(read_ids=ids,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',queries=['note050 source Office on National Statistics versus official Office for National Statistics: verify institutional name at chapter close','ch0055–57 homeownership comparisons use historical sources; retain source attribution and do not present as contemporary2026 data or independently verified causal claims','note049 40% no credit,25% traditional,50% nontraditional categories may overlap; do not force percentages to sum100','ch0061 High Dam completion1971 may refer inauguration versus1970 construction; assess at chapter close','note060175m2=4200/24;currency1000/6.2 about161 supports about160, no correction','ch0051 inclusive exclusion versus ch0019 exclusion-inclusion: preserve distinct phrasings; decide term mapping at chapter close'],next='ch06-0066 and note-ch6-063')
(p/'ch06_housing_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
cp=p.parents[2]/'工作文档'/'Alibi后续工作检查点.md';s=cp.read_text(encoding='utf-8')
entry='第六章住房部分已校读：ch06-0051—0065及原注047—062共31单元，修订14单元；累计1380。修复收入到账误作增长、家属帮忙误作雇佣、淹水物理阻碍误作禁令、可能性限定、倍数基数及大城市误限开罗，统一包容性排除/止赎并恢复斜体和英文空格。证据ch06_housing_revisions.json绑定哈希；review_ch06_housing.py一次性不重跑。章末待核统计机构名称、高坝1971竣工/启用口径；历史住房率未冒充当前统计。**实际下一位置：ch06-0066及note-ch6-063**。本章未完成，全书统检排版发布未开始。\n\n'
assert '## 授权与当前状态' in s
cp.write_text(s.replace('## 授权与当前状态',entry+'## 授权与当前状态',1),encoding='utf-8')
print(len(ids),len(revs),e['output_sha256'])
