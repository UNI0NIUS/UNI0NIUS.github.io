"""One-time review of chapter eight capture/credit argument. Do not rerun."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent;f=p/'translation_units.jsonl';raw=f.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='63a7a5a5eb212d7250cb6c9b8a48b94a0a1bc3f5230dae0927d765ccb300fec7'
rows=[json.loads(s) for s in raw.decode('utf-8').splitlines()]
ids=[r['id'] for r in rows if ('ch08-0027'<=r['id']<='ch08-0050' or 'note-ch8-011'<=r['id']<='note-ch8-027') and r['status']=='translated']
edits={
'ch08-0029':[('都会创造对未来的一项额外索取权','都会增加一个向未来提出索取的人','claimant为索取者，不是claim索取权。')],
'ch08-0030':[('还有对未来的设押','还有对未来施加负担','encumbering按全书核心术语，不限抵押设押法律形式。')],
'ch08-0032':[('对我们关于货币或资本的朴素日常观念','我们关于货币或资本的朴素日常观念','删除悬空介词对，恢复主语。')],
'ch08-0033':[('对未来付款的主张始终会因价值波动而变化，随着未来变得更确定或更受风险影响。','随着未来变得更确定或面临更多风险，对未来付款的主张在价值上始终可能发生波动。','修复价值波动的条件与主语关系。'),('摧毁未来权力所创造的全部资本','摧毁对未来的权力所创造的全部资本','power over the future指支配未来的权力。')],
'ch08-0034':[('未来{{P:272}}。','未来。{{P:272}}','页标仍置于本句结尾附近；下项进一步按source中future后的实际语义位置恢复。')],
'ch08-0035':[('许多南方国家','许多全球南方国家'),('多数北方国家','多数全球北方国家')],
'ch08-0040':[('政府装置','治理装置','government这里指治理过程，与全书术语一致。')],
'ch08-0046':[('资本化程度最高的公司','资本化估值最高的公司','most highly capitalised指估值规模而非资本化程度。')],
'ch08-0047':[('不再是工人与生产资料所有权的分离，也不再是生产与市场的表面分离，或所谓的经济与政治的分离。','不再仅仅是工人与生产资料所有权的分离，也不只是生产与市场的表面分离，或所谓经济与政治的分离。','恢复simply，不能暗示这些分离已不存在。'),('依赖不断扩大规模就业的体系','依赖不断扩展的大规模就业体系','widening system of large-scale employment修复中文修饰关系。')],
'note-ch8-016':[('依赖于“想象的”或“虚构的”未来概念的解释','依赖于对“虚构的”未来进行“想象”这一观念的解释','imagination of fictional futures是从属关系，非二者择一。')],
'note-ch8-022':[('并最终规范用餐时间、假日以及工资本身','并最终规范用餐时间、假日以及工资率本身','rate of wage保留工资率含义。')],
'note-ch8-025':[('“领地”（fiefdoms）','“封地”（fiefdoms）','与本章0046对应词统一。')]
}
# Restore the printed page boundary to the source semantic position in a reordered Chinese sentence.
edits['ch08-0034']=[('反而更加重要，而资本化和贴现越来越依赖这种未来{{P:272}}。','反而更加重要：它保障了可预测的未来{{P:272}}，而资本化和贴现越来越依赖这样的未来。','原书272页从on which开始；页标应在可预测未来之后、后续依赖从句之前。')]
edits['ch08-0035']=[(a,b,'South/North是全球南方/北方的政治经济分组，不是普通地理方向。') for a,b in edits['ch08-0035']]
revs=[]
for r in rows:
 if r['id'] not in ids:continue
 old=r['translation'];why=[]
 for a,b,c in edits.get(r['id'],[]):
  assert a in r['translation'],(r['id'],a);r['translation']=r['translation'].replace(a,b);why.append(c)
 if why:revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=why))
 r['review_status']='semantic_reviewed'
 assert re.findall(r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}',r['source_text'])==re.findall(r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}',r['translation']),r['id']
for a,b in zip([json.loads(s) for s in raw.decode('utf-8').splitlines()],rows):
 assert {k:v for k,v in a.items() if k not in ['translation','review_status']}=={k:v for k,v in b.items() if k not in ['translation','review_status']}
 if a['id'] not in ids:assert a==b
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
e=dict(read_ids=ids,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',queries=['ch08-0039最高法院竞选支出裁决称2011年，疑与2010年Citizens United及后续超级PAC发展混合；章末核查并保留作者底本。','ch08-0030复利翻倍24/12年是近似；第七章贴现口径校注全书统检需呼应，不把90至100超过10%误判。','ch08-0041千年前并列Fatimid/Mamluk应视原作历史概述，章末检查时间范围。','ch08-0048银行创造95%以上货币未给地域/口径，保留作者主张，不宣称全球独立核实。','note-ch8-025出版者与版次组合待章末定向核查；note026保留原讲座日期和链接。'],next='ch08-0051 and note-ch8-028')
(p/'ch08_capture_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
cp=p.parents[2]/'工作文档'/'Alibi后续工作检查点.md';s=cp.read_text(encoding='utf-8')
entry=f'第八章资本化与信用部分已源译对照：ch08-0027—0050及原注011—027共{len(ids)}有效单元，修订{len(revs)}单元。修复索取者/索取权、对未来的权力、悬空介词、不再仅仅限定及原注从属关系，统一治理装置/全球南北/封地并恢复272页标语义位置。证据ch08_capture_revisions.json；review_ch08_capture.py一次性不重跑。规范稿SHA256 '+e['output_sha256']+f'；累计{1609+len(ids)}有效单元。2011裁决年份和货币比例口径等列章末疑点。**实际下一位置：ch08-0051及note-ch8-028**。第八章未完成，章级核查及全书统检、排版发布未开始。\n\n'
assert '## 授权与当前状态' in s;cp.write_text(s.replace('## 授权与当前状态',entry+'## 授权与当前状态',1),encoding='utf-8')
print(json.dumps(dict(read=len(ids),revised=len(revs),sha256=e['output_sha256']),ensure_ascii=False))
