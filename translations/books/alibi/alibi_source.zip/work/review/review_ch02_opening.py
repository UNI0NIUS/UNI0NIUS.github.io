"""One-time chapter 2 opening corrections; do not rerun after later revisions."""
import json, hashlib
from pathlib import Path
p=Path(__file__).parent
f=p/'translation_units.jsonl'
raw=f.read_bytes()
rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch02-0004': [('后来管理了资助建坝者的糖业地产，即英国资本家和企业家欧内斯特·卡塞尔爵士。','后来管理了建坝出资人——英国资本家和企业家欧内斯特·卡塞尔爵士——的糖业地产。','纠正同位语，卡塞尔是出资人而非地产。')],
'ch02-0007': [('改变世界最长河流的流向','调节世界最长河流的水流','flow 不等于方向，后文讨论流量和季节调节。')],
'ch02-0011': [('以改变河流的流向','以调节河流的水流','同上。'),('蓄洪盆地','围堤田块','人工围堤分区田块，沿用第一章术语，不误指自然盆地。'),('已增长十倍','已增至十倍','increased tenfold 表终值为原值十倍。')],
'ch02-0013': [('它还很可能增加了洪水过度的可能性。','它还可能增加了过度泛滥的概率。','may 不支持很可能，保留推测限定。')],
'ch02-0016': [('帮忙推动水轮','帮忙操作水车','helping with 不证明人力推动，原文明确为畜力装置。')],
'ch02-0017': [('主要是那些以液体形式存在的物品——水、石油，尤其是货币。','主要是那些具有液态或流动形式的东西——水、石油，尤其是货币。','保留 liquid 在物质与货币之间的双关，避免断言货币为液体。')],
'ch02-0018': [('这种忽视是无知学的产物，而不是无知。','这种忽视源于无知的制造（agnotology），而非单纯的不知情。','后句明确知而不顾；不能把研究无知的学科误作工程师采取的理论。'),('“水的灌溉定额”（duty of water）','“单位供水的灌溉面积”（duty of water）','原文紧接定义为给定水量可灌面积，避免与面积所需水量倒置。')],
'ch02-0019': [('盆地灌溉','围堤蓄水灌溉','与人工围堤田块的术语对齐。')],
'ch02-0022': [('盆地灌溉','围堤蓄水灌溉','同上。'),('大型蓄洪盆地','大型蓄水田区','强调人为分区。'),('每个盆地','每个田区','同上。'),('较低的盆地','较低的田区','同上。'),('蓄洪盆地的布局，加强了上、下游盆地的序列','蓄水田区的布局，改进了较高与较低田区之间的依次衔接','upper/lower 侧重高低及灌排次序，非仅上下游地理。')],
'note-ch2-016': [('关于用水定额','关于单位供水的灌溉面积','与正文给定水量可灌面积的定义一致。')],
'note-ch2-021': [('盆地维护减少','围堤田区维护减少','同本节人工蓄水田区。')],
'note-ch2-022': [('各省盆地的规模','各省蓄水田区的规模','同上。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits: continue
 old=r['translation']; reasons=[]
 for a,b,why in edits[r['id']]:
  assert a in r['translation'], (r['id'],a)
  r['translation']=r['translation'].replace(a,b); reasons.append(why)
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=reasons))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
e=dict(read_ids=[f'ch02-{i:04}' for i in range(2,21)]+['ch02-fig01','ch02-0022']+[f'note-ch2-{i:03}' for i in range(1,26)],revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',next='ch02-0023',queries=['duty of water definition is explicit in source; primary citation check deferred to chapter end if required','agnotology deliberate production of ignorance: confirm later chapter usage before global term pass','Figure 1 caption read; actual image/layout validation pending. Figures 2-4 captions incidentally read but not credited pending context/notes.','note-ch2-018 winter inundation wording preserved as source; check seasonal discussion later in chapter'])
(p/'ch02_opening_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(e['read_ids']),len(revs),e['output_sha256'])
