"""One-time chapter-eight query evidence; canonical translation unchanged."""
import json,hashlib
from pathlib import Path
p=Path(__file__).parent
assert hashlib.sha256((p/'translation_units.jsonl').read_bytes()).hexdigest()=='3a902818d5c576fde02d3b91a689047c7c0386e76b3ab918f0eecf68b4d776b5'
nf=p/'editor_notes.json';notes=json.loads(nf.read_text(encoding='utf-8'));assert len(notes)==67
new=[dict(id='ed-ch8-citizens-date',unit_id='ch08-0039',text='校注：底本此处将美国最高法院取消公司独立竞选支出限制的裁决记为2011年。美国联邦选举委员会所载Citizens United v. FEC裁决日期为2010年1月21日；这与后文科尔伯特在2011年的讽刺活动是不同时间节点。正文保留底本年份。',sources=['https://www.fec.gov/updates/citizens-united-v-fecsupreme-court/','https://www.fec.gov/law/litigation/cu_sc08_opinion.pdf'],source_locator='FEC同期裁决说明已打开；裁决PDF首页日期检索确认。未据此核定科尔伯特节目具体播出日。',verified_on='2026-10-23'),dict(id='ed-ch8-emissions-scope',unit_id='note-ch8-044',text='校注：原注混列了不同统计口径：“人均CO₂排放”与包含多种气体的“温室气体排放（CO₂当量）”不能直接互换。所引Minx等2021年论文包括化石燃料与工业CO₂、土地利用CO₂、甲烷、氧化亚氮及含氟气体；Our World in Data同名人均CO₂指标则说明统计化石燃料燃烧与工业过程的CO₂，不包括土地利用变化。本注数字及其地区概述照录，但未确认作者所用历史数据版本及各项数值的统一口径，不能将这组数字视为已经按同一温室气体口径核算。',sources=['https://essd.copernicus.org/articles/13/5213/2021/','https://ourworldindata.org/grapher/co-emissions-per-capita'],source_locator='Minx论文气体分组说明和OWID指标定义均已打开。OWID当前页面为2025版数据；仅用于区分指标，未用其数值替换底本2024/2025访问口径。',verified_on='2026-10-23')]
assert not any(n['id'] in {a['id'] for a in notes} for n in new)
q=dict(status='in_progress',resolutions=[dict(unit_id=n['unit_id'],decision='editor_note',editor_note_id=n['id']) for n in new])
q['resolutions'] += [
dict(unit_id='note-ch8-001',decision='verified_retained',reason='作者哥伦比亚大学个人书目列Critical Times9(1–2),2026,204–226,DOI10.1215/26410478-12217422，与底本卷年一致。',sources=['https://blogs.cuit.columbia.edu/tm2421/all-articles-by-subject/'],limit='作者书目搜索结果；直接打开超时，未取得刊文首页。'),
dict(unit_id='note-ch8-031',decision='spelling_retained',reason='Feavearyear为实际作者拼写，非拼写错误；1963版书目与底本一致。',sources=['https://academic.oup.com/jrsssa/article/95/2/335/7094713','https://publications.banque-france.fr/sites/default/files/medias/documents/document-de-travail_525_2014.pdf'],limit='原刊书评及法国央行工作论文参考书目检索元数据；未核所引页99—305。'),
dict(unit_id='note-ch8-042',decision='year_retained_with_evidence_conflict',reason='出版社JSTOR书页列Copyright Date2014；其他书目常列2016，不能以后一出版时间覆盖前一版权时间。底本2014保留。',sources=['https://www.jstor.org/stable/j.ctvjf9wcc','https://www.hup.harvard.edu/books/9780674545038'],limit='JSTOR出版方元数据搜索结果；Harvard直接页面要求JS验证，未取得纸本版权页。'),
dict(unit_id='note-ch8-007',decision='book_identified_retained',reason='NBER原出版方确认1972年、卷5 Economic Growth，作者WilliamD.Nordhaus与JamesTobin。底本所列总系列题可识别，不必擅补副题；authors/eds角色差异列证据限度。',sources=['https://www.nber.org/books-and-chapters/economic-research-retrospect-and-prospect-volume-5-economic-growth/growth-obsolete'],limit='出版方搜索元数据；未核原版完整题名页和编者角色。'),
dict(unit_id='note-ch8-003',decision='query_pending',reason='检索显示工作论文编号33/08而非卷期33:8；ETH原作者机构库记录可定位，但直接403，待查原PDF或LSE记录。',sources=['https://www.research-collection.ethz.ch/entities/publication/fa2960ac-a013-4280-9540-5a20a030c75e']),
dict(unit_id='note-ch8-008',decision='query_pending',reason='原刊网页已定位，卷年吻合，94–127页码尚待原刊目录/PDF。',sources=['https://newleftreview.org/issues/ii127/articles/nancy-fraser-climates-of-capital']),
dict(unit_id='note-ch8-029',decision='edition_pending',reason='Harvard书页要求JS验证，其他初版元数据2018不能直接否定底本2019所用版本。',sources=['https://www.hup.harvard.edu/books/9780674976337'])]
q['remaining']=['note003编号、note008页码、note025版次、note029版次的定向收口','ch0030算术近似、ch0041历史范围、ch0048货币比例口径、ch0055—0057历史概述核查','note002/043排放与燃料累计口径；note040历史统计证据限度','EconoCon与indemnification协调、重点回读、附属材料与全书统检']
nf.write_text(json.dumps(notes+new,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(p/'ch08_query_resolution.json').write_text(json.dumps(q,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
cp=p.parents[2]/'工作文档'/'Alibi后续工作检查点.md';s=cp.read_text(encoding='utf-8')
entry='第八章疑点首轮已留证：确认Citizens United裁决为2010年，新增独立校注；确认原注044把单一CO₂与多气体CO₂当量来源混列，新增口径校注且不替换历史数值。校注现69条。2026刊文卷年、Feavearyear拼写及NBER书目有支持；大加速2014版权年有出版方元数据支持，不贸然改为2016。证据ch08_query_resolution.json记录所有已查结果、访问限度及剩余定向事项；resolve_ch08_queries_a.py一次性不重跑。规范稿未改，SHA256仍3a902818d5c576fde02d3b91a689047c7c0386e76b3ab918f0eecf68b4d776b5。**实际下一位置：继续第八章章末剩余疑点，随后术语及重点回读**。未完成全书终校、排版或发布。\n\n'
assert '## 授权与当前状态' in s;cp.write_text(s.replace('## 授权与当前状态',entry+'## 授权与当前状态',1),encoding='utf-8')
print('Saved query evidence; editor notes 69; canonical unchanged.')
