"""One-time semantic batch, chapter audit pending."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent; f=p/'translation_units.jsonl'; raw=f.read_bytes()
rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch03-0054':[
('富有的长途阿拉伯商人','从事长途贸易的富有阿拉伯商人','long-distance限定商贸活动。'),
('穆罕默德·伊本·阿卜杜勒·瓦哈卜的改革宗教运动','穆罕默德·伊本·阿卜杜勒·瓦哈卜的宗教改革运动','调整reformist religious movement修饰关系。'),
('不断扩张的埃及战争权力','埃及不断增强的战争能力','powers of war-making指发动战争的能力。')],
'ch03-0056':[
('开罗一位贵族的“花园”里','开罗一位贵族的花园里','此处原文仅discover有引号，花园引号属于下一段。'),
('却忽视了埃及从小麦出口国转向棉花出口国的更可能原因','却忽视了埃及试图从小麦出口国转向棉花出口国的更可能原因','恢复attempted。')],
'ch03-0057':[
('无疑是一座城墙环绕的果园，位于城市郊区，每个大城镇的富人都用井灌种植免受尼罗河洪水侵袭的树果作物','那无疑是城郊一处有围墙的果园；每个大城镇的富人都会在这样的地方用井水灌溉树木类作物，使其免受尼罗河洪水侵袭','walled不是城市城墙；原译插入语将贵族等同果园，明确指花园。')],
'ch03-0058':[
('在南部，棉花仅限于尼罗河沿岸高地和别处的围墙果园','在南部，棉花仅种在尼罗河沿岸高地；在其他地方，则仅种在有围墙的果园里','南部和其他地方是分列空间，不是南部包括别处。'),
('水轮，即{{I}}saqiya{{/I}}','水车，即萨基亚（{{I}}saqiya{{/I}}）','与第二章术语对齐。'),
('水轮','水车','统一灌溉水车称谓。')],
'ch03-0062':[
('然而，欧洲的革命和战争经历虽然比该大陆近代任何其他事件都更具破坏性，尼罗河上新地区强国的建立也只是更广泛的信用流动中断及其所依赖利润的一部分。','然而，欧洲经历的革命和战争——尽管其破坏性超过该大陆近期历史上的任何其他事件——以及尼罗河上新地区强国的建立，都只是更大范围内信用流动及依赖这种流动的利润遭到扰乱的一部分。','恢复并列主语，利润依赖信用流动，不是信用流动依赖利润。')],
'ch03-0063':[
('数量不多的羊毛货物','数量不多的毛织品','woollen goods为加工织物。'),
('这第二次、也更早的中断','这里谈到的第二种、发生时间更早的中断','second为论述次序，并非时间上第二次。')],
'ch03-0064':[
('第三次中断的来源','第三种扰乱的来源','third source按原因分类，不是第三次历史事件。'),
('英国商人在印度享有的自由','英国商人移民在印度享有的自由','恢复merchant-settlers双重身份。'),
('似乎抄袭了东印度公司旗帜上的十三道红白条纹','似乎仿用了东印度公司旗帜上的十三道红白条纹','copied不额外引入抄袭的贬义裁定，保留似乎。')],
'note-ch3-100':[
('{{I}}Trade and Civilisation{{/I}}{{P:332}}{{I}}in the Indian Ocean{{/I}}','{{I}}Trade and Civilisation{{/I}} {{P:332}}{{I}}in the Indian Ocean{{/I}}','保留英文书名词间空格，页位令牌不应造成单词粘连。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits:continue
 old=r['translation']; reasons=[]
 for a,b,why in edits[r['id']]:
  assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b); reasons.append(why)
 assert re.findall(r'\{\{.*?\}\}',old)==re.findall(r'\{\{.*?\}\}',r['translation'])
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=reasons))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
ids=[f'ch03-{i:04}' for i in range(54,66)]+[f'note-ch3-{i:03}' for i in range(81,110)]
e=dict(read_ids=ids,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',next='ch03-0066 and note-ch3-110',queries=['note-ch3-100 Empire of Guns 2008 likely source date error; verify publisher at chapter end','ch03-0054 Muhammad bin Saud and expansion to Mecca chronology may compress later successor events; preserve author wording pending targeted check','ch03-0056 within five years and note096 1818–1823 retained; precise arrival/death dates not verified','ch03-0064 flag derivation remains qualified author claim, not independently established fact','note-ch3-103 Jackson MI retained source; publisher location abbreviation may be MS, verify at chapter end'])
(p/'ch03_egypt_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(ids),len(revs),e['output_sha256'])
