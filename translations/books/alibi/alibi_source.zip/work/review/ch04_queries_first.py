"""One-time first query resolutions, preserving original notes."""
import json
from pathlib import Path
p=Path(__file__).parent;f=p/'editor_notes.json';d=json.loads(f.read_text(encoding='utf-8'))
assert isinstance(d,list)
new=[dict(id='ed-ch4-stedman',unit_id='note-ch4-065',text='校注：底本作者姓名作Gareth Steadman Jones；本注所引英国学术院论文首页署名为Gareth Stedman Jones。原注拼写照录。',sources=['https://www.thebritishacademy.ac.uk/documents/990/JBA-6-StedmanJones.pdf'],source_locator='论文PDF首页，书内187页，已打开',verified_on='2026-10-23'),dict(id='ed-ch4-siebeck',unit_id='note-ch4-100',text='校注：底本将Paul Siebeck列为这部德文著作的德文译者。巴伐利亚科学院《韦伯全集》数字版编校报告将J.C.B. Mohr (Paul Siebeck)列为1922年版出版者，并明确称Paul Siebeck为出版人。原注照录，此处译者归属有误。',sources=['https://mwg-digital.badw.de/de/editorischer-gesamtbericht/'],source_locator='Zur Textüberlieferung开头及第1、7注附近，已打开',limit='核对权威全集编校报告，未取得本注所引第31页原版影像。',verified_on='2026-10-23')]
assert not {x['id'] for x in new}&{x['id'] for x in d};d.extend(new);f.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
q=dict(status='in_progress',resolutions=[dict(unit_id='note-ch4-003',decision='retain_no_error_note',finding='岭南大学作者机构书目明确列Leung Sea SIU及2008；原作Siu Leung-Sea可为姓前名后，不能因其他记录用Lucia便判错。',sources=['https://scholars.ln.edu.hk/en/publications/do-economists-make-markets-on-the-performativity-of-economics/'],evidence='机构书目已打开，编辑者字段与出版年'),dict(unit_id='note-ch4-090',decision='retain_no_error_note',finding='出版社列纸本2004、电子书2010，原注2010有明确版本依据，不改。',sources=['https://press.uchicago.edu/ucp/books/book/chicago/P/bo3637242.html'],evidence='出版社页面已打开，分格式出版日期'),dict(unit_id='note-ch4-065',decision='editor_note',editor_note_id='ed-ch4-stedman'),dict(unit_id='note-ch4-100',decision='editor_note',editor_note_id='ed-ch4-siebeck')],remaining='汇总本章其余queries并定向处理；术语协调、重点回读及输出例外确认仍待做。',canonical_changed=False)
(p/'ch04_query_resolution.json').write_text(json.dumps(q,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(d))
