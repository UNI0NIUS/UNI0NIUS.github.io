"""One-time chapter3 semantic edits; chapter audit pending."""
import json,hashlib
from pathlib import Path
p=Path(__file__).parent; f=p/'translation_units.jsonl'; raw=f.read_bytes()
rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch03-0032':[('过去是一种虚构，是在这个词积极意义上的虚构','过去是被建构出来的——这里取fabrication一词积极的、制作与构建的含义','positive sense区别于前文fictitious，保留双义转折。'),('如果它是一种投射或虚构，那么它是以具体方式被虚构和投射的，这些方式在当下被组织、计算、行动并使之可得。','如果它是一种投射或建构，那它也是以具体方式被构建和投射的：人们在当下组织它、计算它、据此行动，并使它成为可供利用的东西。','恢复制造的具体实践及acted upon的宾语关系。'),('未来的虚构效果','未来被建构出来的效果','承接积极建构义。')],
'ch03-0034':[('未来正是通过这些关系在当下被设押和攫取','未来正是通过这些关系被施加负担，并在当下被攫取','encumbered不限狭义抵押，与既定术语一致。')],
'ch03-0036':[('自由或无产劳动力','自由或无财产的劳动力','propertyless明确财产条件，避免无产被误读为产出不足。')],
'ch03-0039':[('而煤炭供应可以私下获得（并被资本化）','而煤炭供应可以由私人确保（并被资本化）','privately指组织和控制形式，不是暗中。'),('这些殖民地为围绕机械化组织起来的材料提供了来源和市场','这些殖民地既提供了机械化所围绕的原料，也提供了相关产品的市场','纠正机械化围绕材料而非材料围绕机械化，恢复source/market关系。')],
'note-ch3-057':[('剩余的 72% 出口','余下部分中的 72% 出口','明确扣除纺织损耗之后的分母，非总进口量的72%。')],
'note-ch3-058':[('“freak”（畸形）','“freak”（怪胎）','与正文同引文一致。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits:continue
 old=r['translation']; reasons=[]
 for a,b,why in edits[r['id']]:
  assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b); reasons.append(why)
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=reasons))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
ids=[f'ch03-{i:04}' for i in range(28,43)]+[f'note-ch3-{i:03}' for i in range(48,67)]
e=dict(read_ids=ids,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',next='ch03-0043',queries=['ch03-0037 German Grossbetreib appears source misspelling of Grossbetrieb; preserve pending chapter-end note','note-ch3-051 Silvia Frederici spelling appears source error; verify publisher at chapter end','note-ch3-057 India repeated in source list; preserve, no silent removal','ch03-0039 wool/cotton scientific comparison preserved as author claim, not independent materials-science review','fabrication heading 制造 and paragraph positive 建构 preserve productive versus fictitious distinction; include term decision at chapter end'])
(p/'ch03_fabrication_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(ids),len(revs),e['output_sha256'])
