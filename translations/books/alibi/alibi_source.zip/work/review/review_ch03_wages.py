"""One-time semantic batch; preserve source and audit chapter after completion."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent; f=p/'translation_units.jsonl'; raw=f.read_bytes()
rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch03-0066':[
('而该厂所有者格雷格家族主要参与奴隶种植园和商船{{P:119}}业务','而拥有该厂的格雷格家族主要从事的正是这些贸易，他们拥有奴隶种植园和商船{{P:119}}运输业务','恢复in which指前述奴隶及北美贸易，owners为所有权而非仅参与。'),
('生态灭绝','生态毁灭','对齐ecocide既定术语。'),
('把制造过程带到棉花最初生产的地方，然后作为成品出售','把制造过程搬到棉花原本的产地——那里同时也是制成品后来的销售地','恢复where同时修饰生产和销售地点。')],
'ch03-0067':[
('一种自我运动、自我改进的力量','一种自行推动改进的力量','self-moving修饰力量，不是技术改进自身。')],
'ch03-0069':[
('恶是小钱之根','恶是小额货币之根','small money指小额支付工具，不是钱少；与正文定义一致。')],
'ch03-0071':[
('即使人们不像较老的马克思主义学术那样，承认生产过程产生的全部剩余并非都是劳动的产物——事实上，尤其是有此承认时——波斯通认为，工资仍然发挥着强大的功能。','波斯通认为，即使承认生产过程产生的剩余并非全都是劳动的产物——这不同于较早的马克思主义研究，而恰恰在承认这一点时尤其如此——工资仍然发挥着强大的功能。','消除不像…那样承认导致的否定辖域歧义，保留作者限定。')],
'ch03-0072':[
('不仅是通过许多工人借以表现其“价值”的小时与分钟的抽象性','不仅在于：对许多工人而言，工资的“价值”是用抽象的小时和分钟来表示的','in which its value presented为工资价值以时间呈现，不是工人主动表现。'),
('不精确、不可计量、由来已久','不精确、未经计量、由来已久','unmeasured并不断言不可测量。')],
'ch03-0073':[
('某种广泛使用的“小钱”形式','某种得到广泛使用的“小额货币”形式','明确小额货币语义。'),
('是{{I}}小{{/I}}钱之根','是{{I}}小额{{/I}}货币之根','保留small的强调范围，术语统一。')],
'ch03-0075':[
('棉花制造业特别适合','棉纺织业特别适合','cotton manufacturing不是制造原棉。')],
'ch03-0078':[
('这些雇工每周都需要一笔现金；如果雇工能用这种方便的纸片得到满足','本来每周都必须筹措一笔现金来支付这些雇工；如果用这种方便的纸片就能满足他们','must be procured指雇主筹款义务，非仅工人需求。')],
'note-ch3-122':[
('{{I}}Legal{{/I}}{{P:334}}{{I}}Plunder{{/I}}','{{I}}Legal{{/I}} {{P:334}}{{I}}Plunder{{/I}}','英文书名跨页保留词间空格。')],
'note-ch3-125':[
('“捕捉装置”（apparatus of capture）','“攫取装置”（apparatus of capture）','与正文及既定术语统一。')],
'note-ch3-127':[
('一旦某家同时经营银行和贸易业务、靠发行此类纸币联合起来的企业破产','一旦某家通过发行此类纸币而把银行业务与贸易业务结合起来的企业破产','united指两类业务结合，而非若干企业联合。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits:continue
 old=r['translation']; reasons=[]
 for a,b,why in edits[r['id']]:
  assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b); reasons.append(why)
 # Emphasis lexical span changes, but token names and order remain identical.
 assert re.findall(r'\{\{.*?\}\}',old)==re.findall(r'\{\{.*?\}\}',r['translation'])
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=reasons))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
ids=[f'ch03-{i:04}' for i in range(66,79)]+[f'note-ch3-{i:03}' for i in range(110,128)]
e=dict(read_ids=ids,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',next='ch03-0079 and note-ch3-128',queries=['Small money terminology now 小额货币; reconcile rest of chapter at chapter end','ch03-0066 two decades of war versus ch03-0064 1775–83 retained as source; referenced statistic period not independently confirmed','ch03-0071 Postone argument retained as author interpretation, not independently attributed from whole Postone work','ch03-0076 in arrears currently 拖欠一个月: check subsequent context for normal payment-in-arrears versus delinquency at chapter end'])
(p/'ch03_wages_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(ids),len(revs),e['output_sha256'])
