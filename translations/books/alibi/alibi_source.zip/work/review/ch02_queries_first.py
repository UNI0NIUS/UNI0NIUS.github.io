"""One-time append of independently checked source discrepancies."""
import json
from pathlib import Path
p=Path(__file__).parent; f=p/'editor_notes.json'; notes=json.loads(f.read_text(encoding='utf-8'))
new=[dict(id='ed-ch2-petry-date',unit_id='note-ch2-133',text='校注：底本将Petry的The Mamluk Sultanate: A History出版年记为2002；剑桥大学出版社提供的版权页（PDF第4页）标明初版为2022年。原注年份照录。',sources=['https://assets.cambridge.org/97811084/71046/frontmatter/9781108471046_frontmatter.pdf'],verified_on='2026-10-23'),dict(id='ed-ch2-gerd-date',unit_id='ch02-0044',text='校注：底本将埃塞俄比亚复兴大坝的建成与2020年相联系。美国地质调查局的卫星观测说明记载，2020年夏开始的是水库第一阶段蓄水；蓄水开始不等于大坝全面建成。正文保留原作年代及措辞。',sources=['https://eros.usgs.gov/earthshots/grand-ethiopian-renaissance-dam-ethiopia'],verified_on='2026-10-23')]
assert not {n['id'] for n in new}&{n['id'] for n in notes}
notes+=new; f.write_text(json.dumps(notes,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
e=dict(status='in_progress',checked=[dict(unit=n['unit_id'],resolution=n['text'],sources=n['sources'],access='opened source text') for n in new],remaining=['Fayyum location','Abib calendar dates','Nubia Upper/Lower and1933','Linant bibliography','Tanta-Zagazig above map','cholera1881/1883','duty of water/agnotology term closure','targeted reread of semantic corrections'],canonical_unchanged=True)
(p/'ch02_query_resolution.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(notes))
