"""One-time closing edits and chapter data audit; never regenerate later work."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent; f=p/'translation_units.jsonl'; raw=f.read_bytes()
rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch02-0077':[('田间盆地及其下方的底层','围堤田块及其下方的地层','与本章分层蓄水系统一致。'),('河流本身抬高的水量中','河流本身因水位抬高而增大的水体中','volume为水体容积，不是可抬高的水量。')],
'ch02-0078':[('非农业份额','不归耕作者的那部分价值','non-farming share指收入分配而非产业分类。')],
'ch02-0080':[('工业夏季作物靛蓝','夏季工业作物靛蓝植物','指作物非染料。'),('田间盆地','围堤田区','人工灌溉田区术语。')],
'ch02-0082':[('应对多余洪水的盆地','应对多余洪水的围堤田区','人工灌溉田区。'),('在洪泛盆地中','在围堤田区中','同上。')],
'ch02-0083':[('新的盆地和运河','新的围堤田区和运河','人工灌溉田区。')],
'ch02-0087':[('田地和河流生物财富所依赖','田地肥力和河流生物丰度所依赖','恢复fertility漏译及richness含义。'),('在洪泛盆地播种','在围堤田区播种','术语对齐。')],
'ch02-0094':[('购买债券的投资者的银行','购买股份的投资者的银行','原段此处明确shares，其余certificates不据此静默改写，原作术语不一致记疑点。')],
'ch02-0100':[('那些日后偿还它的人的生活的产物','那些日后以自己的生活偿还这笔收入的人所创造的产物','原文生产者为人，生活是承担偿还的方式；改善嵌套关系。')],
'note-ch2-150':[('田间盆地','围堤田块','术语对齐。')],
'note-ch2-152':[('生产数茬收获的靛蓝植物','能够多次刈割的靛蓝植物','cuttings指多次收割。'),('洪水盆地上','围堤蓄水田区中','术语对齐。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits: continue
 old=r['translation']; reasons=[]
 for a,b,why in edits[r['id']]:
  assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b); reasons.append(why)
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=reasons))
read=[r['id'] for r in rows if r.get('translation') and (re.fullmatch(r'ch02-\d{4}',r['id']) and r['id']>='ch02-0075' or r['id'].startswith('note-ch2-') and r['id']>='note-ch2-144')]
seen=set(read)
for name in ['opening','groundwater','storage','silencing','famines']:
 seen.update(json.loads((p/f'ch02_{name}_revisions.json').read_text(encoding='utf-8'))['read_ids'])
chapter=[r for r in rows if (r['section']=='ch02' or r['id'].startswith('note-ch2-')) and r['status']=='translated']
assert {r['id'] for r in chapter}==seen,({r['id'] for r in chapter}-seen,seen-{r['id'] for r in chapter})
refs=[]; notes=[r['id'] for r in chapter if r['id'].startswith('note-ch2-')]
for r in chapter:
 refs+=re.findall(r'\{\{N:([^}]+)\}\}',r['translation'])
 pattern=r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}'
 assert re.findall(pattern,r['source_text'])==re.findall(pattern,r['translation']),r['id']
 r['review_status']='semantic_reviewed'; r['status_reason']='source/translation comparison completed; chapter structural checks passed; external queries recorded separately'
assert sorted(refs)==sorted(notes)
oldrows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
for a,b in zip(oldrows,rows):
 assert a['id']==b['id']
 for k in ['source_text','source_markup','source_refs','printed_pages','note_refs']: assert a.get(k)==b.get(k)
 if b not in chapter: assert a==b
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
e=dict(read_ids=read,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_reviewed_count=len(chapter),notes=len(notes),status='semantic_and_structure_review_passed_external_queries_pending',checks=['all chapter units read','references match definitions','structural token order','source fields unchanged','other chapters unchanged'],queries=['ch02-0088 source Upper Nubia submerged in1933 may confuse Lower Nubia; preserve and verify source','ch02-0094 source certificates versus shares inconsistent; original accounting narrative retained, no independent audit','ch02-0087 agricultural yields20% decline may be per-area output; preserve generic translation until cited context checked','ch02-0079 source physiology of cotton wording preserved; not independent botanical audit'],next='chapter2 queries and targeted reread')
(p/'ch02_close_evidence.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(read),len(revs),len(chapter),len(notes),e['output_sha256'])
