"""One-time chapter-seven query resolution and final targeted audit. Do not rerun."""
import json, hashlib, re
from pathlib import Path
p=Path(__file__).parent; f=p/'translation_units.jsonl'; raw=f.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='6bf123eb19ac555d66f14be88e84f1fdf1f02422efdb73bd4e0c30aa9beed986'
rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch07-0011':[('把其中一段航道加倍','为其中一段增设平行航道','doubling指新增平行航道，不是含糊的尺寸加倍。')],
'ch07-0050':[('国家外技艺','国家之外的治理术','与下文空间治理的标准和协议对应，保留似乎在国家直接治理之外的限定。')],
'ch07-0051':[('液态','流动','与耐久标题并列，照应流动性；物理隐喻由正文继续展开。')],
'ch07-0056':[('乡村银行','地方银行','country banks指地方银行，不限乡村或农业银行。')],
'ch07-0067':[('而管理和控制这些方法的是技术政治装置','也是组织和控制这些方法的技术政治装置的产物','原文and连接两种共同构成剩余实现的要素，不应只作插入的装置释义。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits: continue
 old=r['translation']; reasons=[]
 for a,b,c in edits[r['id']]:
  assert a in r['translation']; r['translation']=r['translation'].replace(a,b); reasons.append(c)
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=reasons))
chapter=[r for r in rows if (r['section']=='ch07' or r['id'].startswith('note-ch7-')) and r['status']=='translated']
seen=set()
for name in ['opening','finance','durability']:
 seen.update(json.loads((p/f'ch07_{name}_revisions.json').read_text(encoding='utf-8'))['read_ids'])
seen.update(json.loads((p/'ch07_close_evidence.json').read_text(encoding='utf-8'))['read_ids'])
assert seen=={r['id'] for r in chapter} and len(chapter)==119
refs=[]; notes=[]
for r in chapter:
 pat=r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}'
 assert re.findall(pat,r['source_text'])==re.findall(pat,r['translation']),r['id']
 refs+=re.findall(r'\{\{N:([^}]+)\}\}',r['translation'])
 if r['id'].startswith('note-ch7-'): notes.append(r['id'])
assert sorted(refs)==sorted(notes) and len(notes)==50
for a,b in zip([json.loads(x) for x in raw.decode('utf-8').splitlines()],rows):
 assert {k:v for k,v in a.items() if k!='translation'}=={k:v for k,v in b.items() if k!='translation'}
 if a['id'] not in edits: assert a==b
nf=p/'editor_notes.json'; en=json.loads(nf.read_text(encoding='utf-8')); assert len(en)==57
new=[]
def note(key,unit,text,sources,locator):
 new.append(dict(id='ed-ch7-'+key,unit_id=unit,text='校注：'+text,sources=sources,source_locator=locator,verified_on='2026-10-23'))
note('white','ch07-0015','底本此处及原注015作Richard Wright；《Railroaded》作者实为Richard White，与本章原注006一致。英文底本照录。',['https://web.stanford.edu/group/spatialhistory/railroaded/about-author.html'],'作者所在大学的本书网站About the Author，已打开。')
note('qje-volume','note-ch7-006','底本卷期作101:7；出版方书目列为《The Quarterly Journal of Economics》131卷2期（2016年5月），799—858页，DOI为10.1093/qje/qjw002。',['https://academic.oup.com/qje/article-abstract/131/2/799/2606976?login=true'],'出版方检索元数据；直接打开所转CDN失败，未取得文章首页。')
note('cronon','note-ch7-020','底本作者姓氏作Cronin；《Nature’s Metropolis》作者为William Cronon。原注年份保留，不以初版年份代替所引版本。',['https://wwnorton.co.uk/books/9780393342376-railroaded-a347d9ee-9fba-4a4c-af67-9c9b5b4f6c30'],'Norton出版社Railroaded页面的William Cronon荐语署名明确标出Nature’s Metropolis作者，已打开；未核原注所用书的版权页。')
note('discount','note-ch7-027','正文先把一年后的100美元以10%折扣写作90美元；本注的51.32美元则采用按10%年收益率求现值的算法，即100÷1.1⁷≈51.32。同一算法的一年现值约为90.91美元；若每年直接减去10%，七年为100×0.9⁷≈47.83美元。正文“约50美元”是近似值，但一年例子与原注精确数值的贴现口径并不相同。原数值均保留。',[],'本地复算：100/1.1=90.909090909；100/1.1**7=51.315811823；100*.9**7=47.82969。')
note('law-supplement','note-ch7-031','底本期号作1；出版方标为32卷S1增刊（1984年5月），234—263页。',['https://onlinelibrary.wiley.com/doi/abs/10.1111/j.1467-954X.1984.tb00114.x'],'出版方文章页面Volume32 IssueS1，已打开；不以作者后来收入论文集的年份替换此刊年。')
note('chicago-press','note-ch7-018','底本出版社作Chicago University Press，正式名称为University of Chicago Press。',['https://press.uchicago.edu/ucp/books/book/chicago/J/bo49967326.html','https://academic.oup.com/chicago-scholarship-online/book/42896'],'出版社本书页面及Chicago Scholarship Online出版者字段；2021年保留。')
note('ships-year','note-ch7-030','底本所引年份2017尚未确认。MIT Press书目分别列精装上市日期2006年11月3日、平装2010年1月22日；作者任职大学书目列2007。此处保留底本年份并标疑，不在未核所用印次版权页的情况下擅定应替换年份。',['https://mitpress.mit.edu/9780262514156/ships-and-science/','https://historyarthistory.gmu.edu/people/lferreir'],'MIT出版方页面已打开，ISBN9780262062596/9780262514156；作者大学书目检索元数据。')
note('smith-delay','ch07-0031','底本称1772年危机使《国富论》推迟五年出版，但未交代这五年的起算点。《国富论》初版为1776年；原注所引Rae传记收录的1772年9月5日斯密致Pulteney信中，只说疾病及帮助陷于危机的友人迫使出版再延后数月。因此不宜直接把底本“五年”理解为从1772年危机发生之日起计算；正文保留，精确延误年数仍有疑点。',['https://www.econlib.org/book-chapters/chapter-chapter-16/','https://era.ed.ac.uk/items/97be930c-78b6-40af-bdcf-d63fea980bbb'],'Rae第16章内斯密书信转录已打开；爱丁堡大学1776年版馆藏元数据。不宣称已核全部四种所引文献。')
note('suez-dates','ch07-0011','底本把2015年扩建与最大载重由21万吨提高至24万吨相接叙述。苏伊士运河管理局历史表列2001年为21万吨，2010年已为24万吨，2015年仍为24万吨。因此该吨位提升不宜全归于2015年工程；正文数字和叙述保留。',['https://www.suezcanal.gov.eg/English/About/SuezCanal/Pages/CanalCharacteristics.aspx'],'管理局Stages of developing the Suez Canal表，年份与Max.Loaded ship/DWT列逐项对应，已打开。')
note('mortgage-scope','note-ch7-033','此处“直到1925年才正式确立财产抵押”的概述应谨慎理解。1925年《财产法》第三部分对抵押形式和效力作了规定，其中条文明确涉及本法生效之前或之后设立的土地抵押，不能据此将1925年视为英格兰抵押实践本身的起点。原注照录；未取得Anderson所引12—13页，不擅自补定作者所指的具体旧制限制。',['https://www.legislation.gov.uk/ukpga/Geo5/15-16/20/part/III'],'官方法条检索摘要明确含mortgages of land made before or after the commencement of this Act；直接打开因application/xhtml+xml未解析。限于条文范围提示，不作现行法律建议。')
assert not {n['id'] for n in new}&{n['id'] for n in en}
q=dict(status='closed_with_disclosed_source_limits',resolutions=[dict(unit_id=n['unit_id'],decision='editor_note',editor_note_id=n['id']) for n in new])
q['resolutions'] += [
 dict(unit_id='note-ch7-002',decision='verified_retained',reason='Bowker期刊53卷4期2014年563—576页，与Wiley期刊目录一致。',source='https://onlinelibrary.wiley.com/toc/14682303/2014/53/4'),
 dict(unit_id='note-ch7-014',decision='edition_unconfirmed_retained',reason='Oxford Academic列2011年版；未取得底本引用版本的版权页，不能排除再版/印次差异，保留2013，不据检索不到判错。',source='https://academic.oup.com/edited-volume/42046'),
 dict(unit_id='ch07-0008',decision='award_verified_retained',reason='AEA官方2017年Clark奖得主为Dave Donaldson；未重做作者所批评研究的计量验证。',source='https://www.aeaweb.org/about-aea/honors-awards/bates-clark/david-donaldson'),
 dict(unit_id='note-ch7-035',decision='historical_scope_retained',reason='2022收入与2023费率为原作历史材料，不替换成当前费率；未独立审计收入。'),
 dict(unit_id='chapter7',decision='scope_limit',reason='疾病范围、殖民地历史、公司财产权和资本因果为原作者论述，保留限定；本轮仅核明确列出的疑点，不声称全面史实或统计审计。')]
q['remaining']='书目版次及原作证据限度已披露；本章无未处理译文待办，目录与独立校注实际输出待全书生成验收。'
tf=p/'term_decisions.json'; terms=json.loads(tf.read_text(encoding='utf-8')); terms['scope']='frontmatter/introduction/chapters1–7; chapter8 contextual review pending'
terms['terms'] += [dict(en='extrastatecraft',zh='国家之外的治理术',note='第七章0050定义是标准、公式、协议形成的空间治理；不是无国家，也不限技艺。'),dict(en='The Durable / The Liquid',zh='耐久／流动',note='标题与耐久性和流动性概念呼应；液态物理隐喻在正文保留。'),dict(en='country banks',zh='地方银行',note='英国历史语境，不限乡村或农业银行。'),dict(en='sabotage',zh='破坏；蓄意破坏（按语境）',note='第七章包括限制、停顿与阻塞，不擅缩为实物毁坏。')]
# All validations above precede writes. Input-bound one-time evidence avoids rerunning earlier batch generators.
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
def save(name,obj): (p/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
save('editor_notes.json',en+new);save('ch07_query_resolution.json',q);save('term_decisions.json',terms)
e=dict(targeted_reread_ids=['ch07-0011','ch07-0031','ch07-0034','ch07-0035','ch07-0036','ch07-0038','ch07-0039','ch07-0044','ch07-0050','ch07-0051','ch07-0052','ch07-0056','ch07-0057','ch07-0060','ch07-0067','ch07-0071','note-ch7-026','note-ch7-027'],revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_reviewed_count=119,notes=50,editor_notes_added=10,status='chapter_review_complete_with_disclosed_source_limits',checks=['119 read coverage','50 references/50 definitions','structural tokens preserved','source fields preserved','other units unchanged'],next='ch08-0001 and note-ch8-001')
save('ch07_final_evidence.json',e)
cp=p.parents[2]/'工作文档'/'Alibi后续工作检查点.md';s=cp.read_text(encoding='utf-8')
entry='第七章收口完成：18处重点回读、5单元增量修订，协调国家之外的治理术/流动/地方银行，澄清平行航道及剩余实现的并列关系。119单元覆盖、50原注对应、结构令牌、源字段及其他单元保留检查通过。定向疑点核查新增10条独立校注，校注共67条；贴现算术口径、作者姓名、卷期、苏伊士工程年代与法律概述等已处理，版本和史料证据限度保留披露。证据ch07_query_resolution.json及ch07_final_evidence.json；finish_ch07.py一次性不重跑。规范稿SHA256 '+e['output_sha256']+'；累计1575有效单元。**实际下一位置：第八章ch08-0001及note-ch8-001**。全书统检、排版、打包、发布与线上验收尚未开始。\n\n'
assert '## 授权与当前状态' in s
cp.write_text(s.replace('## 授权与当前状态',entry+'## 授权与当前状态',1),encoding='utf-8')
print(json.dumps(e,ensure_ascii=False))
