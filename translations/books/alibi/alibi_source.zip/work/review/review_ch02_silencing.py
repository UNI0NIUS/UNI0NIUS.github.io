"""One-time edits; chapter review is ongoing."""
import json,hashlib
from pathlib import Path
p=Path(__file__).parent; f=p/'translation_units.jsonl'; raw=f.read_bytes()
rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch02-0048':[('田间盆地','围堤田块','人工灌溉田块术语对齐。')],
'ch02-0050':[('法庭案件不成比例地处理陌生人之间的纠纷','法庭处理的案件中，陌生人之间的纠纷占了不成比例的高份额','disproportionately 指案件分布，不是处置方式失衡。')],
'ch02-0051':[('地方司法官','地方法学家','jurists不是法院任职官员；此处强调不诉诸法院。'),('地方司法意见','地方法学意见','同上。')],
'ch02-0053':[('蓄洪盆地','围堤蓄水田区','人工田区术语。'),('田间盆地','围堤田块','同上。'),('洪泛盆地农业','围堤蓄水农业','同上。')],
'ch02-0054':[('蓄洪盆地','围堤蓄水田区','人工田区术语。'),('洪泛盆地系统','围堤蓄水系统','同上。'),('在盆地中','在围堤田区中','同上。'),('上埃及的盆地中','上埃及的围堤田区中','同上。')],
'ch02-0055':[('在纽约和伦敦同时出版','在伦敦和纽约两地出版','as well as 未说明同时出版。'),('洪泛盆地','围堤蓄水田区','人工田区术语。'),('如今依赖棉花种植的运河系统','棉花种植如今所依赖的运河系统','修复依赖关系反译：棉花依赖运河。')],
'ch02-0056':[('糖、棉花或水稻等夏季作物','甘蔗、棉花或水稻等夏季作物','sugar 指产糖作物而非糖本身。'),('尼罗河水也从不低于地表 35 英尺','尼罗河水面距地表也从不超过 35 英尺','修复深度上限表达歧义。')],
'ch02-0058':[('在盆地制度下','在围堤蓄水制度下','人工灌溉系统。')],
'ch02-0061':[('已因先期抵达的天花而崩溃','已因先期抵达的天花而陷入崩溃','already collapsing为过程，非已经完成。'),('这两种疾病都随着战争加剧而传播：俄罗斯向北方奥斯曼领土扩张，英国和法国在东地中海和南亚的军事扩张，以及贸易和朝圣交通的日益增加。','俄罗斯向北方的奥斯曼领土扩张，英国和法国在东地中海及南亚扩张军事势力，由此带来的战争增多，以及贸易和朝圣往来的日益频繁，都促使这两种疾病传播。','修复并列句法，贸易朝圣不是战争的例项。')],
'note-ch2-097':[('一线以北地区','一线以上地区','source above不能直接变成以北，与南三角洲冲突；保留源相对方位待章末地图核实。')],
'note-ch2-098':[('在内陆深处有源源不断的水源','在远离河流的内陆，这一深度仍有源源不断的水源','补回at that depth。'),('一口井可带动多达四架水车','多达四架水车可从同一口井提水','井为水源，不是驱动力。')],
'note-ch2-099':[('洪水盆地体系','围堤蓄水体系','人工灌溉系统。')],
'note-ch2-101':[('其他工程师总是先于他获得晋升','其他工程师总是被提拔到他的上级职位','over him 指职级关系不只是先后。')],
'note-ch2-102':[('盆地内井上','围堤田区内的井上','人工田区术语。'),('额定功率 11,740 马力','额定总功率 11,740 马力','多台泵合计，不是每台。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits: continue
 old=r['translation']; reasons=[]
 for a,b,why in edits[r['id']]:
  assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b); reasons.append(why)
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=reasons))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
ids=[r['id'] for r in rows if r.get('translation') and (('ch02-0048'<=r['id']<='ch02-0061') or ('note-ch2-089'<=r['id']<='note-ch2-110'))]
e=dict(read_ids=ids,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',next='ch02-0062',queries=['note-ch2-097 above a line Tanta to Zagazig: source says southern Delta; avoid translating above as north without cited map','ch02-0052 Linant 1874 vs note094 1872-3 and author Maurice vs note048 Louis; source bibliographic discrepancy retained pending chapter-end resolution','ch02-0061 cholera 1881 vs note109 title1883; preserve source pending targeted chapter-end chronology check'])
(p/'ch02_silencing_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(ids),len(revs),e['output_sha256'])
