"""One-time chapter4 semantic batch; chapter audit remains pending."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent;f=p/'translation_units.jsonl';raw=f.read_bytes();rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch04-0031':[('制造缝衣针的工场中离散操作的倍增','制造裁缝用大头针的工场中各道独立工序的增加','dressmakers pins为大头针而非有孔缝衣针，discrete为分立工序。'),('狄德罗的《百科全书》','狄德罗的{{I}}《百科全书》{{/I}}','恢复斜体。')],
'ch04-0032':[('塑造《国富论》论证','塑造{{I}}《国富论》{{/I}}论证','恢复斜体。'),('借鉴了当代关于农场改良实践试验的记述','借鉴了当时关于农场改良实践试验的记述','contemporary相对于李嘉图时代，不是今天。')],
'ch04-0033':[('在《资本论》第一卷中','在{{I}}《资本论》{{/I}}第一卷中','恢复斜体。')],
'ch04-0034':[('旨在改善工业劳动虐待','旨在减轻工业劳动中虐待现象','ameliorate abuse减少虐待而非改进虐待。'),('研究《论机器和制造业的经济》（1832）','研究{{I}}《论机器和制造业的经济》{{/I}}（1832）','恢复书名斜体。'),('尤尔的《制造业哲学》（副标题为《工厂制度的科学、道德和商业经济阐述》）','尤尔的{{I}}《制造业哲学》{{/I}}（副标题为{{I}}《工厂制度的科学、道德和商业经济阐述》{{/I}}）','恢复书名和副标题斜体。'),('我们从当代记述中知道','我们从当时的记述中知道','contemporary指当时。')],
'ch04-0035':[('只出版了《资本论》第一卷','只出版了{{I}}《资本论》{{/I}}第一卷','恢复书名斜体。'),('在十九世纪最后三分之一','在十九世纪的最后三分之一时段','明确时间长度。')],
'ch04-0039':[('导致印度卢比贬值','导致印度卢比价值暴跌','collapse强度不应减为一般贬值。')],
'ch04-0041':[('为经济科学所需的两个新问题例子','这两个需要经济科学来解答的新问题','原译反转科学与问题的需要关系。')],
'ch04-0042':[('这种重新利用服务于资本托词的另一个：即“帝国托词”。','这种重新利用促成了资本的另一种托词，即“帝国的托词”。','恢复creation谓语并改善宾语。'),('复兴为殖民政府的工具','复兴为殖民治理的工具','government指治理实践。'),('而是指政府的规则和问题','而是指治理的规则和问题','同上。')],
'ch04-0044':[('马克思《资本论》中','马克思{{I}}《资本论》{{/I}}中','恢复书名斜体。'),('例如马克思在后来的《资本论》第三卷手稿中所说','例如马克思在后来成为{{I}}《资本论》{{/I}}第三卷的手稿中所说','恢复手稿后被编为卷三的时间关系和斜体。'),('“在空间因而在建筑物等方面节约多少{{I}}经济{{/I}}，结果就是把工人拥挤在狭小环境中”','“在空间，因而也在建筑物等方面作出的大量{{I}}节省{{/I}}，结果把工人挤在狭小的环境中”','economy即节省，不是节约经济，保留原文强调。')],
'note-ch4-043':[('“殖民物质主义”（colonial materialism）','“殖民唯物主义”（colonial materialism）','与正文术语一致。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits:continue
 old=r['translation']; reasons=[]
 for a,b,why in edits[r['id']]:
  assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b);reasons.append(why)
 pattern=r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}'
 assert re.findall(pattern,old)==re.findall(pattern,r['translation'])
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=reasons))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
ids=[f'ch04-{i:04}' for i in range(29,45)]+[f'note-ch4-{i:03}' for i in range(29,47)]
e=dict(read_ids=ids,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',queries=['note-ch4-032 volume51 issue2 versus2024 may be online/issue publication difference; preserve pending chapter-end check','ch04-0035 Marx abandonment claim is author interpretation; assess subsequent explanation rather than silently soften','ch04-0039 Vienna exposition/property crash causal chronology author claim retained, not independently verified','ch04-0041 solar/weather explanation attributed to Jevons; no modern scientific endorsement','ch04-0044 English Marx quote economy now 节省; reread with note046 at chapter end','Cromer viceroy is author nomenclature; not independently verified official title'],next='ch04-0045 and note-ch4-047')
(p/'ch04_abstraction_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(ids),len(revs),e['output_sha256'])
