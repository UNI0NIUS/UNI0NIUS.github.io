"""Recover interrupted final audit from verified before/after edits, without rolling back disk."""
import ast,json,hashlib
from pathlib import Path
p=Path(__file__).parent;s=(p/'finish_ch06.py').read_text(encoding='utf-8')
tree=ast.parse(s);edits=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='edits' for t in n.targets))
rows=[json.loads(x) for x in (p/'translation_units.jsonl').read_text(encoding='utf-8').splitlines()]
for r in rows:
 if r['id'] in edits:
  for a,b,c in reversed(edits[r['id']]):
   assert b in r['translation'];r['translation']=r['translation'].replace(b,a)
recovered=''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows).replace('\n','\r\n').encode('utf-8')
assert hashlib.sha256(recovered).hexdigest()=='20a60cf700eabe71998dfd7f1c49499143a96f87f2116932d5439fa797b25b26'
exec(compile(s.replace('raw=f.read_bytes()','raw=recovered'),str(p/'finish_ch06.py'),'exec'),{'__file__':str(p/'finish_ch06.py'),'recovered':recovered})
