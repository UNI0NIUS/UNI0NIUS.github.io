"""One-time front matter review; never rerun after subsequent revisions."""
import json, hashlib
from pathlib import Path
p=Path(__file__).parent
f=p/'translation_units.jsonl'
before=f.read_bytes()
rows=[json.loads(x) for x in before.decode('utf-8').splitlines()]
changes={
 'frontmatter-0013':('作者已声明其精神权利。','修正被动直译，明确权利声明主体；不增加授权含义。'),
}
ids=[]; revisions=[]
for r in rows:
 if r['section'] not in ('01_cover','frontmatter','acknowledgements') or r['status']!='translated': continue
 ids.append(r['id'])
 if r['id'] in changes:
  new,reason=changes[r['id']]
  revisions.append(dict(id=r['id'],before=r['translation'],after=new,reason=reason))
  r['translation']=new
 r['review_status']='semantic_reviewed'
 r['status_reason']='draft retained; source/translation semantic comparison completed for this unit'
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
newrows=[json.loads(x) for x in f.read_text(encoding='utf-8').splitlines()]
oldrows=[json.loads(x) for x in before.decode('utf-8').splitlines()]
assert [r['id'] for r in oldrows]==[r['id'] for r in newrows]
for a,b in zip(oldrows,newrows):
 assert all(a[k]==b[k] for k in a if k not in ('translation','status_reason'))
 if a['id'] not in ids: assert a==b
evidence=dict(scope=ids,reviewed_count=len(ids),revisions=revisions,input_sha256=hashlib.sha256(before).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),checks=['ID/order unchanged','source fields unchanged','unreviewed units unchanged'],limits=['No independent external verification of names or publication references','No PDF or website layout verification'],next='introduction, with corresponding notes')
(p/'front_review_evidence.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(evidence,ensure_ascii=False))
