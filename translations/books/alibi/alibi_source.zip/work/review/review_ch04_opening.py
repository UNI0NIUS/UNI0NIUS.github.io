"""One-time chapter4 opening semantic batch; no chapter completion yet."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent;f=p/'translation_units.jsonl';raw=f.read_bytes();rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch04-0004':[('把“{{I}}经济{{/I}}”本身视为一个对象','把“{{I}}这个{{/I}}经济整体”（the economy）本身视为一个对象','保留定冠词强调及经济作为整体对象的区别。')],
'ch04-0005':[('经济作为自身对象的出现','经济作为独立对象的出现','in itself不指自身成为自身的对象。')],
'ch04-0012':[('关于其政府和“增长”的语言','关于其治理和“增长”的语言','government指经济的治理，不是一个政府机构。')],
'ch04-0013':[('《论政治经济学的兴起、进步、特殊对象与重要性》','{{I}}《论政治经济学的兴起、进步、特殊对象与重要性》{{/I}}','恢复底本书名斜体结构。')],
'ch04-0014':[('在经济一词指称{{I}}经济{{/I}}之前','在economy一词指称{{I}}这个{{/I}}经济整体之前','避免同词同义反复，保留the的强调。')],
'ch04-0016':[('在{{I}}经济{{/I}}被发明之前，“经济”一词是如何使用的','在{{I}}这个{{/I}}经济整体被发明之前，economy一词是如何使用的','与开篇概念区分一致。')],
'ch04-0017':[('维持上等阶层和下等阶层生计的准则','维持上层和下层阶级生计的准则','upper/lower不带优劣等级评价。'),('为赞助的殖民贸易垄断辩护或扩大它','为国家支持的殖民贸易垄断辩护，或扩大这种垄断','恢复state-sponsored主语。')],
'ch04-0019':[('在《国富论》（1776）中','在{{I}}《国富论》{{/I}}（1776）中','恢复书名斜体。')],
'ch04-0020':[('在《国富论》问世同一年','在{{I}}《国富论》{{/I}}问世同一年','恢复书名斜体。'),('开始用以扩大了的国内未来攫取方式来补充','开始用扩展了的国内未来攫取方式来补充','消除用以叠加语病。')],
'ch04-0024':[('通过宗教透镜去把握的“彼世”','通过宗教视角去把握的那个“领域之外”','beyond回指经济领域以外，不仅是超验彼世；后文包括私人和殖民空间。')],
'ch04-0026':[('而自利这一至高力量“只存在于欧洲某些地区，而且只是在最近”','而自利只在“欧洲某些地区，而且只是在最近”才成为至高力量','限制的是主导性而非自利存在本身。')],
'ch04-0028':[('玉米（小麦）','谷物（此处指小麦）','英国corn原文已明确wheat，非玉米。'),('《公报》的玉米均价','{{I}}《公报》{{/I}}的小麦均价','修复作物名并恢复Gazette斜体。'),('同一确切品质玉米','品质完全相同的小麦','同一引文统一作物名。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits:continue
 old=r['translation']; reasons=[]
 for a,b,why in edits[r['id']]:
  assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b); reasons.append(why)
 pattern=r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}'
 assert re.findall(pattern,old)==re.findall(pattern,r['translation'])
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=reasons))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
ids=[f'ch04-{i:04}' for i in range(2,29)]+[f'note-ch4-{i:03}' for i in range(1,29)]
e=dict(read_ids=ids,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',queries=['note-ch4-003 Siu Leung-Sea name order/spelling check at chapter end; source retained','ch04-0021 Whately appointment1831 may confuse appointment with lecture publication; source retained pending chapter-end check','ch04-0025 Burckhardt conversion and Drummond funding preserved as author claim; verify only if adequate source available at chapter end','Performative 述行性 and economy/the economy distinction to track throughout chapter','ch04-0006 author says prior chapters never use economy, while source actually mentions world economy; preserve author methodological generalisation rather than silently rewriting'],next='ch04-0029 and note-ch4-029')
(p/'ch04_opening_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(ids),len(revs),e['output_sha256'])
