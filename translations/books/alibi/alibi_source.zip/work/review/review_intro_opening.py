"""One-time opening review; chapter verification remains pending."""
import json,hashlib
from pathlib import Path
p=Path(__file__).parent; f=p/'translation_units.jsonl'; raw=f.read_bytes()
rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'introduction-0003': [('租车服务公司','叫车服务公司','car service 在优步语境为叫车服务，不是车辆出租。'),('把投资者的收益形容为“平流层的”','把投资者的收益形容为“高入平流层”','保留气象隐喻并传达收益极高的意思。')],
'introduction-0006': [('可追溯到欧洲商人约三百年前开始创建的武装贸易公司','可追溯到欧洲商人在比十九世纪早约三百年的时期开始创建的武装贸易公司','earlier 参照前句十九世纪，不是距今三百年前。')],
'introduction-0008': [('租车服务业务','叫车服务业务','与本段优步及 Careem 的服务类型对应。'),('其地理扩张既是投资者财富来源的体现，又同时掩盖了这一来源','其地理扩张既构成了投资者财富的来源，又同时掩盖了这一来源','serves as 指构成来源，不只是体现来源。')],
'introduction-0010': [('另一种则是一套使我们盲目的机制，它把未来安排成可计算的巨额财富来源','另一种则是一套使我们盲目、并已将这场灾难带到我们身上的机制：它把未来安排成可计算的巨额财富来源','补回 has brought the calamity upon us 的因果归责。')],
'introduction-0011': [('只要我们还以经济增长原则组织集体生活，就会有人努力指出它的限度','自从我们开始围绕经济增长原则组织集体生活以来，就一直有人努力指出它的限度','For as long as ... there have been 表述历史持续，非未来条件。')],
'introduction-0013': [('不仅仅像批判地理学中的“扩张”那样批判“历史即增长”的观念','不仅仅像批判“地理即扩张”的观念那样批判“历史即增长”的观念','保留两个概念命题的对称，不改为一般地理学学科。')],
'introduction-0015': [('未来各年利润的“折现值”','未来各年利润的“折现现值”','保留 present discounted value 中的当前价值含义。')],
}
revs=[]; read=[]
for r in rows:
 if r['section']=='introduction' and 2<=int(r['id'].split('-')[-1])<=16: read.append(r['id'])
 if r['id'] not in edits: continue
 old=r['translation']; reasons=[]
 for a,b,why in edits[r['id']]:
  assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b); reasons.append(why)
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=reasons))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
(p/'introduction_opening_revisions.json').write_text(json.dumps(dict(read_ids=read,revisions=revs,chapter_status='in_progress_notes_and_chapter_check_pending',input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),next='introduction-0017'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(read),len(revs),hashlib.sha256(f.read_bytes()).hexdigest())
