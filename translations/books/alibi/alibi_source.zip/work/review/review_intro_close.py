"""One-time final passage review, followed by chapter data checks."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent; f=p/'translation_units.jsonl'; raw=f.read_bytes()
rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'introduction-0045':[('我们靠未来生活的模式','我们以未来为代价的生活模式','补足 at the expense of 的代价含义。')],
'introduction-0052':[('被设押或负债者','背负负担或债务的人','encumbered 范围不限抵押。')],
'introduction-0053':[('却毫无新意','却并非新近才有','nothing new 指历史非新生，不是评价观点没有新意。')],
'introduction-0054':[('也让人难以看到更远','也让人难以超越这种增长观念去思考','beyond 承接增长观念，不是看见更远时间。')],
'introduction-0055':[('减少化石燃料燃烧的大多数努力，以及其他破坏生物圈的行动，都远远不够','大多数旨在减少化石燃料燃烧及其他破坏生物圈行为的努力，都远远不够','修复 reduce 的并列宾语范围；原译反而称破坏行为不够。')],
'introduction-0058':[('掩盖这一设押','掩盖这种负担的施加','与本段 encumber 定义一致。'),('对我们在当下生产未来这一方式的误解','对我们如何相对于当下来生产未来的误解','in relation to 不只是 in the present，保留相对关系。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits: continue
 old=r['translation']; reasons=[]
 for a,b,why in edits[r['id']]:
  assert a in r['translation'],r['id']
  r['translation']=r['translation'].replace(a,b); reasons.append(why)
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=reasons))
read=[f'introduction-{i:04}' for i in range(44,59)]+[f'note-int-{i:03}' for i in range(39,44)]
seen=set(read)
for name in ['opening','middle','technology']:
 seen.update(json.loads((p/f'introduction_{name}_revisions.json').read_text(encoding='utf-8'))['read_ids'])
chapter=[r for r in rows if (r['section']=='introduction' or r['id'].startswith('note-int-')) and r['status']=='translated']
assert {r['id'] for r in chapter}==seen
notes=[r['id'] for r in chapter if r['id'].startswith('note-int-')]
refs=[]
for r in chapter:
 refs+=re.findall(r'\{\{N:([^}]+)\}\}',r['translation'])
 assert re.findall(r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}',r['source_text'])==re.findall(r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}',r['translation']),r['id']
 r['review_status']='semantic_reviewed'
 r['status_reason']='source/translation comparison completed; chapter structural checks passed; external queries recorded separately'
assert sorted(refs)==sorted(notes)
original=[json.loads(x) for x in (p.parent/'translation/translation_units.jsonl').read_text(encoding='utf-8').splitlines()]
assert [r['id'] for r in original]==[r['id'] for r in rows]
for a,b in zip(original,rows):
 for k in ['source_text','source_markup','source_refs','printed_pages','note_refs']:
  assert a.get(k)==b.get(k),(a['id'],k)
 if a['section'] not in ('01_cover','frontmatter','acknowledgements','introduction') and not a['id'].startswith('note-int-'): assert a==b
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
e=dict(read_ids=read,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_reviewed_count=len(chapter),notes=len(notes),checks=['all chapter translated units read','43 note refs match 43 definitions exactly','structural tokens retain order','source fields and ID order unchanged','unreviewed chapters unchanged'],status='semantic_and_structure_review_passed_external_queries_pending',next='resolve introduction source queries, then ch01')
(p/'introduction_close_evidence.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(chapter),len(notes),len(revs),e['output_sha256'])
