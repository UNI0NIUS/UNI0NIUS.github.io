"""One-time source/translation corrections, chapter audit pending."""
import json,hashlib
from pathlib import Path
p=Path(__file__).parent; f=p/'translation_units.jsonl'; raw=f.read_bytes()
rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch03-0003':[('造币方法','创造货币的方法','quantitative easing 不指铸币。')],
'ch03-0005':[('对制造业和雇佣劳动的{{I}}绕道{{/I}}','进入制造业和雇佣劳动的{{I}}绕道{{/I}}','detour into 是途经而非绕过这些领域。'),('世界被划分为金融与实体、虚构与物质——以及殖民者与被殖民者——这一更广泛效果的产生','世界似乎被划分为金融与实体、虚构与物质——以及殖民者与被殖民者——这一更广泛效果的产生','恢复seemed的表象限定。')],
'ch03-0008':[('二十一世纪最初二十年','二十一世纪最初几十年','opening decades非确切二十年，后文含2020。')],
'ch03-0009':[('民族货币','国家货币','national currencies为国家货币，非民族属性。')],
'ch03-0010':[('从有效的未来权力内部产生并调节这种权力','从对未来的有效支配力内部产生并调节这种支配力','power over the future不是未来的权力。')],
'ch03-0011':[('一种对未来权力的关系','一种支配未来的权力关系','power over the future句法。'),('最初不是纽约或伦敦，而是在开罗了解现代金融的','最初不是在纽约或伦敦，而是在开罗了解现代金融的','补回缺失介词。')],
'note-ch3-010':[('后来成为埃及著名足球俱乐部 al-Ahly 的主场','后来成为埃及著名足球俱乐部 al-Ahly 的组织依托','home非明确体育场地，原句描述体育俱乐部及足球组织关系。')],
'note-ch3-017':[('缩写版与译本','节译本','abridged为删节，不是缩写。')],
'note-ch3-019':[('从贴现的预付款销售中获利','从折价预售交易中获利','advance sales为农作物预售而非预付款被销售。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits:continue
 old=r['translation']; reasons=[]
 for a,b,why in edits[r['id']]:
  assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b); reasons.append(why)
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=reasons))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
e=dict(read_ids=[f'ch03-{i:04}' for i in range(2,16)]+[f'note-ch3-{i:03}' for i in range(1,23)],revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',next='ch03-0016',queries=['note-ch3-004 source EPUB X links incorrectly target this book chapters1/2 though prose cites Colonising Egypt. Preserve canonical source tokens, suppress those two erroneous links in all generated outputs via scoped override; verify at chapter end.','ch03-0006 Money Is No Object title pun: retain current contextual translation pending chapter-wide interpretation.','ch03-0009 broad money-creation claim follows author; not independent financial verification.'])
(p/'ch03_opening_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
override=p/'render_overrides.json'
assert not override.exists()
override.write_text(json.dumps(dict(items=[dict(unit_id='note-ch3-004',action='render_cross_reference_as_plain_text',targets=['09_Chapter01.xhtml','10_Chapter02.xhtml'],reason='原注正文明确指另书Colonising Egypt的章节；底本却误链接到本书章节，保留可见文字，输出不制造误导性跳转。')]),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(e['read_ids']),len(revs),e['output_sha256'])
