"""One-time chapter final reconciliation; do not rerun."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent;f=p/'translation_units.jsonl';raw=f.read_bytes();rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch04-0004':[('早于“经济”的出现','早于“这个经济整体”（the economy）这一观念的出现','开篇即明确对象义，不让历史上经济活动未存在的读法占先。')],
'ch04-0046':[('这一措辞指一个过程，而不是一个事物。','前一种用法指一个过程，而不是一个事物。','末句回指前述过程义，避免紧邻对象义产生反指。')],
'ch04-0056':[('即“经济”。目前','即“这个经济整体”（the economy）。目前','明确所形成的对象。'),('更广泛领域“社会经济”（或“政治科学”）','更广泛领域“社会经济学”（或“政治科学”）','与0088学科义一致。')],
'ch04-0087':[('在结束讨论之前，让我们提出有关“经济”（economy）在“这个经济整体”（the economy）诞生之前那段历史的最后一个问题。','关于“经济”（economy）在“这个经济整体”（the economy）诞生之前的历史，让我们转向最后一个问题。','删去前次修订额外引入的结束讨论时间语，直接保留原句。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits:continue
 old=r['translation'];why=[]
 for a,b,c in edits[r['id']]:
  assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b);why.append(c)
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=why))
oldrows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
for a,b in zip(oldrows,rows):
 assert {k:v for k,v in a.items() if k!='translation'}=={k:v for k,v in b.items() if k!='translation'}
 if a['id'] not in edits:assert a==b
 pattern=r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}'
 assert re.findall(pattern,a.get('translation',''))==re.findall(pattern,b.get('translation',''))
chapter=[r for r in rows if (r['section']=='ch04' or r['id'].startswith('note-ch4-')) and r['status']=='translated']
assert len(chapter)==225 and all(r['review_status']=='semantic_reviewed' for r in chapter)
assert sorted(n for r in chapter for n in re.findall(r'\{\{N:([^}]+)\}\}',r['translation']))==sorted(r['id'] for r in chapter if r['id'].startswith('note-ch4-'))
o=json.loads((p/'render_overrides.json').read_text(encoding='utf-8'))
assert any(x['unit_id']=='ch04-0089' and x['targets']==['10_Chapter02.xhtml'] for x in o['items'])
assert '{{X:10_Chapter02.xhtml}}' in next(r for r in rows if r['id']=='ch04-0089')['translation']
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
e=dict(status='chapter_closed_with_disclosed_source_limits',reread_ids=['ch04-0004','ch04-0044','ch04-0046','ch04-0053','ch04-0056','ch04-0064','ch04-0087','ch04-0092','ch04-0093','ch04-0112'],revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_units=225,notes=115,checks=['chapter semantic coverage evidence retained','115 note references and definitions','source fields and other units unchanged','incremental structural token order','Weber other-book cross-reference precise override present; generation still pending'],next='ch05-0001 and note-ch5-001')
(p/'ch04_final_evidence.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
f=p/'editor_notes.json';d=json.loads(f.read_text(encoding='utf-8'))
new=[dict(id='ed-ch4-smart-date',unit_id='note-ch4-095',text='校注：底本将William Smart英译本列为1888年。Liberty Fund收录的同一译本注明采用1891年伦敦Macmillan版；译者序把1888年用于因斯布鲁克原著，并称本书现译成英文。此处疑混用了原著与英译本年份，原注照录。',sources=['https://oll-resources.s3.us-east-2.amazonaws.com/oll3/store/titles/283/Boehm-Bawerk_0183_EBk_v6.0.pdf'],source_locator='PDF第2页Edition Used及第6页Translator’s Preface，已打开',limit='根据数字版所用版本与译者序标疑，未穷尽各印次题名页。'),dict(id='ed-ch4-ibid',unit_id='note-ch4-111',text='校注：本注“同上”指向不清。前一注同时列有哈耶克1976年著作、米塞斯1949年著作及惠特利讲稿，而正文讨论哈耶克1935年文集导言，原注109亦引用该导言。此处保留原注，不将“同上”擅自展开为确定书名。',sources=[],source_locator='本书ch04-0111及原注109—111',limit='未取得所列页码的逐页核对，不能据上下文确定全部页码归属。')]
for n in new:n['verified_on']='2026-10-23'
assert not {n['id'] for n in new}&{n['id'] for n in d};d.extend(new);f.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
f=p/'ch04_query_resolution.json';q=json.loads(f.read_text(encoding='utf-8'))
q['resolutions']=[r for r in q['resolutions'] if r['unit_id']!='note-ch4-095']
q['resolutions'] += [dict(unit_id=n['unit_id'],decision='editor_note_with_limit',editor_note_id=n['id']) for n in new]
q['resolutions'].append(dict(unit_id='note-ch4-064',decision='retain_with_evidence_limit',finding='一桥大学三浦文库目录检索显示1905–10、4册，并分列第1卷、第2卷上下册及第3卷；四册与三卷不矛盾，保留原文四卷表述，不据现代版三卷直接判错。',sources=['https://hit-u.repo.nii.ac.jp/record/2055921/files/az0285000_5.pdf'],limit='机构目录检索元数据，直接打开429；未读各原版题名页。放弃写作的说法仍作为作者解释保留。'))
q['retained_author_claims']=['马克思放弃政治经济学批判的解释及草稿叙述，不冒充通读全部手稿后的历史裁定。','展览会与危机因果、指数沿革、日斑理论、Polanyi词汇论断、Cromer称号均按作者语境保留；未对这些领域做全面历史审计。','0006从未使用economy与前文world economy存在概括张力，按作者方法论陈述保留。','0112 system从未出现按当前定义段落语境理解，未独立搜索韦伯全部版本。']
q['status']='closed_with_disclosed_source_limits';q['remaining']=[];q['targeted_reread_evidence']='ch04_final_evidence.json'
f.write_text(json.dumps(q,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
f=p/'term_decisions.json';d=json.loads(f.read_text(encoding='utf-8'));d['scope']='frontmatter/introduction/chapters1–4; later contextual review pending'
d['terms'] += [dict(en='economy / the economy',zh='经济／作为对象的经济整体',note='第四章定义和对比处显式保留the economy；一般行文沿用经济，勿把历史过程与新对象等同。'),dict(en='economising / economisation',zh='经济化；节约（按语境）',note='第四章讨论英文词义时保留原词，以区别传统节俭义与使事物成为经济的过程；不机械替换。'),dict(en='fictitious capital',zh='虚拟资本',note='保留技术名词，与解释性fiction虚构区分。'),dict(en='social economy',zh='社会经济学（学科语境）',note='第四章密尔、韦伯所指研究领域用学科名，其他语境另判。')]
f.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(e['output_sha256'],len(new),len(revs))
