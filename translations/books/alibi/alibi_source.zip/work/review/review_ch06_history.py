"""One-time chapter six historical argument batch."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent;f=p/'translation_units.jsonl';raw=f.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='9b3add1921081f283b4365e63a3a7fe1840dec9ae6499b50f221840638bb3a6d'
rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch06-0037':[('《福布斯》','{{I}}《福布斯》{{/I}}','恢复刊名斜体。'),('创造财富、分配财富的发电机','创造财富、分配财富的强劲引擎','dynamo为经济活力比喻，避免误读发电设施。')],
'ch06-0041':[('新的取消赎回权权力','新的止赎权力','与前章foreclosure术语对齐。'),('执行取消赎回权裁决','执行止赎裁决','统一法律机制名称。')],
'ch06-0042':[('取消赎回权的机器','止赎的机器','统一foreclosure术语。')],
'ch06-0044':[('如果说有什么不同，情况恰恰相反','若要说有哪种情况成立，倒是恰恰相反','if anything强调反向论断，不是在比较不同之处。')],
'ch06-0045':[('财产所有权的扩张和形式化','财产所有权的扩张和正式化','formalisation此处纳入正式产权制度，不是空具形式。')],
'ch06-0046':[('由形式化造成','由正式化造成','formalisation为产权正式化。'),('十九世纪加州的案例展示了一种成功，当代发展中国家的改革者若要效仿，只能剥去其历史的每一层。','只有剥去其历史的每一层，十九世纪加州的案例才会呈现为一种可供当代发展中国家改革者效仿的成功。','条件限定案例被呈现为可效仿范本，不是教改革者先实际抹去历史。')],
'ch06-0047':[('取消赎回权','止赎','两处foreclosure统一。'),('其人身的在场也无法消灭','也无法将这些实际居住于此的人口消灭','physical presence修饰当地人口，避免人身在场生硬表述。')],
'ch06-0048':[('《资本的奥秘》','{{I}}《资本的奥秘》{{/I}}','恢复书名斜体。')],
'ch06-0049':[('《资本的奥秘》','{{I}}《资本的奥秘》{{/I}}','恢复书名斜体。'),('《经济学人》','{{I}}《经济学人》{{/I}}','恢复刊名斜体。'),('取消赎回权机制','止赎机制','统一foreclosure术语。'),('土地被效率较低但更有权势的公司经营接管','土地被效率较低但更有权势的公司经营实体接管','operations在此指经营实体，补足接管主体。')],
'ch06-0050':[('财产形式化和资产化','财产正式化和资产化','明确formalisation制度义。'),('能够拖延、转移或限制其实施程度','能够延缓其实施、改变其路径或限制其范围','divert为改变实施路径，不是转移人口。')],
'note-ch6-035':[('以及 Ali Barakat','以及 ‘Ali Barakat','恢复阿拉伯姓名转写首字母符号。')],
'note-ch6-038':[('关于“Urabi 运动（这场民众运动以其领袖 Ahmad ‘Urabi 命名）更广泛的社会起源','关于‘Urabi 运动（这场民众运动以其领袖 Ahmad ‘Urabi 命名）更广泛的社会起源','修复把转写符误作未闭合中文引号。')],
'note-ch6-042':[('{{/I}}{{P:356}}{{I}}Idea','{{/I}} {{P:356}}{{I}}Idea','补回跨页英文书名词间空格。')],
'note-ch6-044':[('德索托','德·索托','统一人名。')],
'note-ch6-046':[('第 1 版：18','第 1 部分：18','Section 1不是版次；18为页码。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits:continue
 old=r['translation'];why=[]
 for a,b,c in edits[r['id']]:
  assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b);why.append(c)
 pat=r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}'
 assert re.findall(pat,old)==re.findall(pat,r['translation'])
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=why))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
ids=[f'ch06-{i:04}' for i in range(36,51)]+[f'note-ch6-{i:03}' for i in range(33,47)]
e=dict(read_ids=ids,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',queries=['note041 Ibid71 formally points to Lyons1908 in note040 yet supports1920s landlessness; likely ambiguous/source wrong cross-reference; assess at chapter close without inventing target','ch0043 five acres/feddans intentional source approximation explained note040; retain distinctions and no false exact conversion','ch0042 1874 depression date retained as source; chapter-end assess whether editorial note needed versus1873 conventional start','ch0049 farm concentration/efficiency/dispossession claims remain author assertions, not independent statistical validation','ch0046 conditional argument reread at chapter close; formalisation means formal property registration, now正式化'],next='ch06-0051 and note-ch6-047')
(p/'ch06_history_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
cp=p.parents[2]/'工作文档'/'Alibi后续工作检查点.md';s=cp.read_text(encoding='utf-8')
entry='第六章产权史部分已校读：ch06-0036—0050及原注033—046共29单元，修订15单元；累计1349。修复加州案例可供效仿的条件范围、正式化制度义、报纸Section误作版次、阿文姓名转写符及跨页英文空格；止赎术语对齐，恢复书刊斜体。证据ch06_history_revisions.json绑定哈希；review_ch06_history.py一次性不重跑。章末待核注041同上指向与年代矛盾、1874萧条表述；费丹/英亩近似为原注明确约定，未伪造精确相等。**实际下一位置：ch06-0051及note-ch6-047**。第六章尚未完成，全书统检排版发布未开始。\n\n'
assert '## 授权与当前状态' in s
cp.write_text(s.replace('## 授权与当前状态',entry+'## 授权与当前状态',1),encoding='utf-8')
print(len(ids),len(revs),e['output_sha256'])
