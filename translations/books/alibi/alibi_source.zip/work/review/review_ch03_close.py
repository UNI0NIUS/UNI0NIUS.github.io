"""One-time chapter closing edits and structural audit; external queries remain."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent; f=p/'translation_units.jsonl'; raw=f.read_bytes()
rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch03-0094': [('亨利·乔治和其他大多已被遗忘的政治经济学家等作家，曾奋力反对这种过于简单的解释方式，即用房地产开发这一装置来说明投机者攫取未来收入的奇特能力。','亨利·乔治和其他大多已被遗忘的政治经济学家等论者，曾反对用这种过于简单的方式，来解释投机者凭借房地产开发这一装置攫取未来收入的奇特能力。','反对的是前述归因土地价值的解释，不是反对承认房地产开发装置。'),('在这种耐久装置的技术新颖性中，价格机制只起次要作用，而这种新颖性很快就从视野中消失了。','这种耐久装置在技术上的新颖性很快就从视野中消失了，而价格机制在该装置中仅起次要作用。','in which指装置，不是新颖性。')],
'ch03-0095': [('房地产开发所创造的意外剩余','房地产开发所创造的非劳动所得剩余','unearned不等于意外，强调无劳动所得。'),('企业家可以在其中实现从后来者那里攫取的当下收入','企业家可以在其中把从后来者那里攫取的收入提前变现于当下','收入从后来者攫取，当下修饰变现而不是收入来源。')],
'ch03-0101': [('提着一个装满现金的公文包','提着一个装有现金的公文包','actual cash并无装满的数量限定。')],
'ch03-0102': [('不是因为它吸收其他客户的贷款','不是因为它向其他客户借入资金','takes in loans from other customers表述银行作为借入方，避免与客户贷款业务混淆。')],
'ch03-0106': [('商业与银行之间明显分离','商业与银行之间表面上的分离','apparent指呈现的分离效果，不是强调事实明确。')],
'ch03-0109': [('如果说有什么不同，贸易是被组织起来服务于信用创造的。','恰恰相反，贸易是为了服务于信用创造而被组织起来的。','If anything在此反转前句因果优先次序。'),('贷款人的可供性','贷方可提供的资金','availability of lenders在中介论中指可供借款的资金，消除生硬译法。')],
'note-ch3-145': [('强调为原文所有','强调为本书作者所加','emphasis added为引述者添加，与原文所有相反。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits:continue
 old=r['translation']; reasons=[]
 for a,b,why in edits[r['id']]:
  assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b); reasons.append(why)
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=reasons))
read=[r['id'] for r in rows if r.get('translation') and (re.fullmatch(r'ch03-\d{4}',r['id']) and r['id']>='ch03-0094' or r['id'].startswith('note-ch3-') and r['id']>='note-ch3-143')]
seen=set(read)
for name in ['opening','bills','fabrication','detour','egypt','wages','business']:
 seen.update(json.loads((p/f'ch03_{name}_revisions.json').read_text(encoding='utf-8'))['read_ids'])
chapter=[r for r in rows if (r['section']=='ch03' or r['id'].startswith('note-ch3-')) and r['status']=='translated']
assert {r['id'] for r in chapter}==seen,({r['id'] for r in chapter}-seen,seen-{r['id'] for r in chapter})
refs=[]; notes=[r['id'] for r in chapter if r['id'].startswith('note-ch3-')]
for r in chapter:
 refs+=re.findall(r'\{\{N:([^}]+)\}\}',r['translation'])
 pattern=r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}'
 assert re.findall(pattern,r['source_text'])==re.findall(pattern,r['translation']),r['id']
 r['review_status']='semantic_reviewed'; r['status_reason']='source/translation comparison completed; chapter structural checks passed; external queries recorded separately'
assert sorted(refs)==sorted(notes)
oldrows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
chapterids={r['id'] for r in chapter}
for a,b in zip(oldrows,rows):
 assert a['id']==b['id']
 for k in ['source_text','source_markup','source_refs','printed_pages','note_refs','page_start','page_end']: assert a.get(k)==b.get(k)
 if b['id'] not in chapterids: assert a==b
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
e=dict(read_ids=read,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_reviewed_count=len(chapter),notes=len(notes),status='semantic_and_structure_review_passed_external_queries_pending',checks=['all chapter units read','156 references match 156 definitions','structural token order','source fields unchanged','other chapters unchanged'],queries=['note-ch3-150 edition6 versus date1855–6 needs catalog check; retain source','note-ch3-143 Cas Gilbert likely source spelling error; compare introduction and publisher','ch03-0098 title Money in a Theory of Finance versus note153 Money in the Theory of Finance: retain source until catalog check','ch03-0105 money3percent has no jurisdiction/denominator in source; preserve as author estimate, not current statistical claim','ch03-0101–0104 banking explanation preserved as author argument, not financial advice or independent validation of every theoretical claim'],next='chapter3 external queries, term reconciliation and targeted reread; render_overrides must be used by later generators')
(p/'ch03_close_evidence.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(read),len(revs),len(chapter),len(notes),e['output_sha256'])
