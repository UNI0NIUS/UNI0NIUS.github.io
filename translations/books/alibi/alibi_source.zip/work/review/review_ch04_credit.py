"""One-time chapter4 credit section edits."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent;f=p/'translation_units.jsonl';raw=f.read_bytes();rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch04-0060':[('当时他还在二十多岁','当时他才二十五岁上下','mid-twenties较原译更精确。')],
'ch04-0062':[('对社会将如何知道得比对其现在如何更多。如果你想在未来的书中读到，就打开斯密、萨伊、李嘉图。','对未来社会的了解，比对当下社会的了解更多。如果你想读一读未来之书，就翻开斯密、萨伊、李嘉图的著作。','修复引文语义残缺，呼应章题。')],
'ch04-0063':[('即《资本论》第一卷','即{{I}}《资本论》{{/I}}第一卷','恢复斜体。'),('放弃了批判这个项目的写作','放弃了撰写这部政治经济学批判的计划','批判的对象是政治经济学，不是项目。'),('再写几卷《资本论》','再写几卷{{I}}《资本论》{{/I}}','恢复斜体。')],
'ch04-0064':[('现代股份公司，以及它所促成的扩大了的信用创造权力','现代股份公司，以及促成它的信用创造能力的扩展','that enabled it为信用能力促成股份公司，恢复方向。'),('到马克思出版《资本论》第一卷时','到马克思出版{{I}}《资本论》{{/I}}第一卷时','恢复斜体。')],
'ch04-0065':[('也就是《资本论》第一卷终于问世的那个月','也就是{{I}}《资本论》{{/I}}第一卷终于问世的那个月','恢复斜体。')],
'ch04-0066':[('工业劳动及其工资作为对未来消费的信用预支，只是从未来索取的方法不断增多的一方面。','工业劳动及其工资——工资以未来消费为依据、作为信用预支——只是日益增多的从未来索取的方法中的一个方面。','预支为信用的是工资，避免工业劳动本身也被当成货币预支。')],
'note-ch4-067':[('少数勇敢的‘手’独自努力','少数勇敢的‘工人’凭自身努力','hands为工人的借代，不是器官。')],
'note-ch4-069':[('法国征服了突尼斯和东京','法国征服了突尼斯和北圻（Tonkin）','Tonkin指越南北部，非Tokyo。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits:continue
 old=r['translation'];why=[]
 for a,b,c in edits[r['id']]:
  assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b);why.append(c)
 pattern=r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}'
 assert re.findall(pattern,old)==re.findall(pattern,r['translation'])
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=why))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
ids=[f'ch04-{i:04}' for i in range(59,68)]+[f'note-ch4-{i:03}' for i in range(63,74)]
e=dict(read_ids=ids,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',queries=['note-ch4-065 Gareth Steadman Jones likely Stedman; verify publisher at chapter close','ch04-0064 quotation practical success refers Ten Hours Bill in note067 before cooperative movement; retain source mismatch for chapter-end editorial decision','note-ch4-064 Marx abandoned drafting decades earlier and four volumes1905–1910 author assertions retained pending bounded source check','ch04-0065 Paris1867/Vienna1873 exposition causal narrative is author claim; no independent chronology confirmation','Fictitious capital 虚拟资本 retained technical term, fiction 虚构 retained explanatory word; do not globally replace'],next='ch04-0069 and note-ch4-074')
(p/'ch04_credit_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(ids),len(revs),e['output_sha256'])
