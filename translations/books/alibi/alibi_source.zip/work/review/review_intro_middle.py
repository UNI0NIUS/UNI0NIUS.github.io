"""One-time semantic edits; chapter-wide validation follows full chapter."""
import json,hashlib
from pathlib import Path
p=Path(__file__).parent; f=p/'translation_units.jsonl'; raw=f.read_bytes()
rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'introduction-0017':[('租车服务价格','叫车服务价格','car service rides 与前文统一为叫车服务。')],
'introduction-0018':[('对社会主义或星球未来之诉求的漠视','对社会正义或地球未来之诉求的漠视','social justice 被误译为社会主义。')],
'introduction-0023':[('建筑物的租约与土地的租约分开计算','建筑物的租金与土地的租金分开计算','此处计算的是租赁费用，非契约本身。'),('材料建造成本','实体建造成本','material construction 指物理建造，不限于材料费用。')],
'introduction-0027':[('这种破坏、设押、支配和扰乱的历史','这种破坏、施加负担、支配和扰乱的历史','encumbrance 不限于抵押设押，包含本章各类未来负担。')],
'introduction-0028':[('把当下获得的意外之财和未来偿还这些费用的款项','把当下获得的意外之财和未来用来偿还这笔意外之财的收费','it 指 windfall；初稿误将偿还对象译成费用。')],
'note-int-007':[('估算其在中国、俄罗斯和东南亚被竞争对手逐出市场后所持不可交易股份的账面价值增值','估算其持有的不可交易股份的账面价值增值，而这些股份属于曾把优步逐出中国、俄罗斯和东南亚市场的那些公司','恢复所持股份所属公司这一关系，原译仅剩先后关系。')],
'note-int-009':[('如第一章下文所讨论的','如下文第一章所讨论的','below 修饰第一章在本书的位置，不是第一章内部下文。')]
}
read=[f'introduction-{i:04}' for i in range(17,30)]+[f'note-int-{i:03}' for i in range(5,19)]
revs=[]
for r in rows:
 if r['id'] not in edits: continue
 old=r['translation']; reasons=[]
 for a,b,why in edits[r['id']]:
  assert a in r['translation'],r['id']
  r['translation']=r['translation'].replace(a,b); reasons.append(why)
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=reasons))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
(p/'introduction_middle_revisions.json').write_text(json.dumps(dict(read_ids=read,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',next='introduction-0030',queries=['note-int-005: source author spelling Domadaran retained; verify at chapter-end if needed','note-int-007: accounting claims retained as author claims; not independently audited']),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(read),len(revs),hashlib.sha256(f.read_bytes()).hexdigest())
