"""One-time second source-query batch. Do not rerun."""
import json,hashlib
from pathlib import Path
p=Path(__file__).parent
notes=json.loads((p/'editor_notes.json').read_text(encoding='utf-8'))
new=[
dict(id='ed-ch3-gurley-title',unit_id='note-ch3-153',text='校注：底本本注书名作Money in the Theory of Finance，正文则用a；1960年《The Economic Journal》同期书评所列书名为Money in a Theory of Finance。原注照录。',sources=['https://academic.oup.com/ej/article-abstract/70/279/568/5249184'],source_locator='书评标题及首段书目信息，已打开'),
dict(id='ed-ch3-gilbert',unit_id='note-ch3-143',text='校注：底本姓名作Cas Gilbert；美国国会图书馆建筑师档案及其设计图记录署名为Cass Gilbert。原注拼写照录。',sources=['https://www.loc.gov/item/95860799/','https://findingaids.loc.gov/repositories/19/resources/5239'],limit='依据国会图书馆检索元数据确认姓名；档案页直接打开403，未取得1900年原文。'),
dict(id='ed-ch3-jackson',unit_id='note-ch3-103',text='校注：底本出版地作Jackson, MI；密西西比州政府所列University Press of Mississippi所在地为Jackson, MS，即密西西比州杰克逊。原注照录。',sources=['https://ms.gov/agencies/university-press-mississippi','https://www.upress.state.ms.us/Royalties'],limit='依据州政府及出版社检索元数据；州政府页面直接打开Cache miss，未检查该书版权页。'),
dict(id='ed-ch3-cavafy',unit_id='ch03-0051',text='校注：底本称彼得罗斯去世后家族回到曼彻斯特。奥纳西斯卡瓦菲档案馆的传记记述，诗人的母亲在1870年丈夫去世后携子女赴英，1872—1877年先住利物浦、后住伦敦，随后返回亚历山大。正文地名照录。',sources=['https://cavafy.onassis.org/creator/cavafy-c-p/'],source_locator='The Cavafy Family及The Years in England两节，已打开',limit='档案确认Petros是诗人之父，但原文孙辈可能回指公司创办者；不据此裁定孙辈一词错误，未读取所引Glavanis论文页。')
]
for n in new:
 assert not any(x['id']==n['id'] for x in notes)
 n['verified_on']='2026-10-23'
notes.extend(new); (p/'editor_notes.json').write_text(json.dumps(notes,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
f=p/'ch03_query_resolution.json'; d=json.loads(f.read_text(encoding='utf-8'))
d['added_editor_notes'] += [n['id'] for n in new]; d['source_checks']+=new
d['resolved']+=['note-ch3-153 title a/the','note-ch3-143 Cass spelling','note-ch3-103 Jackson state abbreviation','ch03-0051 grandson ambiguity retained; archive identifies different English cities, editorial note added']
d['pending_source_leads']=[dict(query='Macleod sixth edition year',evidence='University research references list sixth edition1902 versus first1855; no direct edition title page yet',sources=['https://openaccess.city.ac.uk/id/eprint/8350/1/The_development_of_the_role_of_the_Bank_of_England_as_a_Lender_of_Last_Resort%2C_1870-1914.pdf','https://www.unibocconi.it/sites/default/files/media/attachments/lea-CatalogoGreco.pdf']),dict(query='Saudi expansion chronology',evidence='Saudipedia lists founder death1765 and successors to1818; exact Mecca conquest date not yet verified',sources=['https://saudipedia.com/en/list-of-imams-of-the-first-saudi-state'])]
d['canonical_sha256']=hashlib.sha256((p/'translation_units.jsonl').read_bytes()).hexdigest()
f.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('editor notes',len(notes),'status',d['status'])
