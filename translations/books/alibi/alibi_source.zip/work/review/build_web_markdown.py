"""Export the shared model for the existing reader and Markdown downloads."""
import json
import re
from collections import defaultdict
from pathlib import Path
from bs4 import BeautifulSoup, NavigableString
from edition_model import P, build

O = P.parents[1] / 'output/reviewed'
PREFIX = 'translations/books/alibi/'


def main():
    m = build()
    W = O / 'webdata'
    W.mkdir(exist_ok=True)
    target_sections = {r['id']: r['section'] for r in m['rows']}
    for r in m['rows']:
        def scan(nodes):
            for n in nodes:
                if isinstance(n, dict):
                    if n['type'] == 'page':
                        target_sections['page-' + n['id']] = r['section']
                    scan(n.get('children', []))
        scan(r['zh'])
    for n in BeautifulSoup(m['index']['full_source_body_html'], 'html.parser').find_all(id=True):
        target_sections[n['id']] = 'index'
        if n['id'].startswith('page'):
            target_sections['page-' + n['id'][4:]] = 'index'

    def url(target, lang):
        anchor = target + ('-en' if lang == 'en' and (target.startswith('page-') or target.startswith('ind_')) else '')
        return 'translations/book.html?id=alibi&chapter=' + target_sections[target] + '&view=' + lang + '#' + anchor

    def convert(nodes, lang):
        out = []
        for n in nodes:
            if isinstance(n, str):
                out.append(n)
                continue
            kind = n['type']
            children = convert(n.get('children', []), lang)
            if kind in ('em', 'strong'):
                out.append({'type': kind, 'children': children})
            elif kind == 'span':
                out.extend(children)
            elif kind == 'link':
                out.append({'type': 'link', 'url': n['target'], 'children': children})
            elif kind in ('xref', 'unitlink'):
                out.append({'type': 'link', 'url': url(n.get('resolved', n.get('target')), lang), 'children': children})
            elif kind == 'page':
                out.append({'type': 'page', 'page': n['id'], 'id': 'page-' + n['id'] + ('' if lang == 'zh' else '-en')})
            elif kind == 'note':
                out.extend([{'type': 'anchor', 'id': 'ref-' + lang + '-' + n['id']}, {'type': 'link', 'url': url(n['id'], lang), 'children': [{'type': 'sup', 'children': [str(int(n['id'].rsplit('-', 1)[1]))]}]}])
            elif kind == 'image':
                out.append({'type': 'image', 'src': PREFIX + 'images/' + n['filename'], 'alt': n['alt']})
            else:
                raise ValueError(kind)
        return out

    books = {}
    for r in m['rows']:
        sec, kind, uid = r['section'], r['kind'], r['id']
        if sec not in books:
            books[sec] = {'id': sec, 'title': {'01_cover': '原书封面', 'frontmatter': '前置材料'}.get(sec, sec), 'body': [], 'notes': {}, 'sourceLanguage': 'en', 'sourceLanguageLabel': 'English'}
        b = books[sec]
        if kind == 'heading' and r['level'] == 1 and sec not in ('frontmatter', '01_cover'):
            b['title'] = ''.join(x for x in r['zh'] if isinstance(x, str))
            b['originalTitle'] = ''.join(x for x in r['en'] if isinstance(x, str))
        row = {'id': uid, 'type': 'heading' if kind == 'heading' and r['level'] == 1 else 'subheading' if kind in ('heading', 'note_group_heading') else 'quote' if kind == 'quote' else 'paragraph', 'page': r['page_start'], 'sourceIds': [uid]}
        for lang in ('zh', 'en'):
            row[lang] = convert(r[lang], lang)
            if 'figure' in r:
                f = r['figure']
                row[lang] = [{'type': 'block', 'kind': 'figure', 'children': [{'type': 'image', 'src': PREFIX + 'images/' + f['filename'], 'alt': f['alt'][lang]}, {'type': 'block', 'kind': 'caption', 'children': row[lang]}]}]
                if f['description'][lang]:
                    row[lang].append({'type': 'block', 'kind': 'paragraph', 'children': [f['description'][lang]]})
            if kind == 'note':
                row[lang].insert(0, str(int(uid.rsplit('-', 1)[1])) + '. ')
                ref = m['note_ref_units'][uid]
                row[lang].append({'type': 'link', 'url': 'translations/book.html?id=alibi&chapter=' + target_sections[ref] + '&view=' + lang + '#ref-' + lang + '-' + uid, 'children': ['↩']})
        if r['editor_notes']:
            row['review'] = '\n\n'.join(n['text'] + ' ' + ' '.join(x if isinstance(x, str) else x['url'] for x in n.get('sources', [])) for n in r['editor_notes'])
            row['editorNoteIds'] = [n['id'] for n in r['editor_notes']]
        b['body'].append(row)

    soup = BeautifulSoup(m['index']['full_source_body_html'], 'html.parser')

    def index_tokens(node, lang):
        if isinstance(node, NavigableString):
            return [str(node)]
        if node.has_attr('hidden'):
            return []
        if node.get('role') == 'doc-pagebreak':
            return [{'type': 'page', 'page': node['id'][4:], 'id': 'page-' + node['id'][4:] + ('' if lang == 'zh' else '-en')}]
        children = [v for c in node.children for v in index_tokens(c, lang)]
        if node.name == 'a':
            key = node['href'].split('#')[-1]
            target = m['aliases'].get(key, key)
            return [{'type': 'link', 'url': url(target, lang), 'children': children}]
        if node.name in ('i', 'em'):
            return [{'type': 'em', 'children': children}]
        if node.name in ('ul', 'li', 'p', 'h1'):
            tokens = []
            if node.get('id'):
                tokens.append({'type': 'anchor', 'id': node['id'] + ('' if lang == 'zh' else '-en')})
            tokens.append({'type': 'block', 'kind': {'ul': 'list', 'li': 'item', 'p': 'heading', 'h1': 'heading'}[node.name], 'children': children})
            return tokens
        return children

    books['index'] = {'id': 'index', 'title': '英文索引', 'originalTitle': 'Index', 'body': [{'id': 'index-content', 'type': 'paragraph', 'shared': True, 'zh': index_tokens(soup, 'zh'), 'en': index_tokens(soup, 'en')}], 'notes': {}, 'sourceLanguage': 'en', 'sourceLanguageLabel': 'English'}
    for sec, b in books.items():
        (W / (sec + '.json')).write_text(json.dumps(b, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    notice = '校订阅读版；原书页位、853条原注、4幅正文图及英文索引保留。72条校注与原注分列。原著及图像权利归原权利人；非出版社官方译本。'
    meta = {'id': 'alibi', 'title': '资本的托词', 'originalTitle': 'The Alibi of Capital', 'author': 'Timothy Mitchell', 'authorZh': '蒂莫西·米切尔', 'language': 'zh-CN', 'languagePair': 'English → 中文', 'structured': True, 'bilingual': True, 'views': ['parallel', 'zh', 'en'], 'example': False, 'editionNotice': notice, 'chapters': [{'id': b['id'], 'title': b['title'], 'originalTitle': b.get('originalTitle', b['title']), 'dataUrl': PREFIX + b['id'] + '.json'} for b in books.values()], 'downloads': [{'label': label, 'url': PREFIX + name} for label, name in [('中文PDF', 'alibi_zh.pdf'), ('双语PDF', 'alibi_bilingual.pdf'), ('中文Markdown', 'alibi_zh.md'), ('规范稿与源码包', 'alibi_source.zip')]]}
    meta.update(translator='Xiaoyang Hao (AI-assisted translation, reviewed edition)', tags=['政治经济学 Political Economy', '历史 History', '生态 Ecology'])
    (W / 'book-metadata.json').write_text(json.dumps(meta, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

    def md(nodes):
        out = []
        for n in nodes:
            if isinstance(n, str):
                out.append(n.replace('*', '\\*'))
                continue
            body = md(n.get('children', []))
            t = n['type']
            if t in ('em', 'strong'):
                mark = '*' if t == 'em' else '**'
                out.append(mark + body + mark)
            elif t == 'link':
                href = n['url']
                if href.startswith('translations/book.html?id=alibi'):
                    href = '#' + href.split('#', 1)[1]
                out.append('[' + body + '](' + href + ')')
            elif t == 'anchor':
                out.append('<a id="' + n['id'] + '"></a>')
            elif t == 'page':
                out.append('<a id="' + n['id'] + '"></a>〔原书第' + n['page'] + '页〕')
            elif t == 'image':
                out.append('![' + n['alt'] + '](' + n['src'].removeprefix(PREFIX) + ')')
            elif t == 'block':
                kind = n['kind']
                if kind == 'list':
                    out.append('\n' + body + '\n')
                elif kind == 'item':
                    lines = body.strip().splitlines()
                    out.append('- ' + lines[0] + '\n' + ''.join('  ' + line + '\n' for line in lines[1:]))
                else:
                    out.append('\n\n' + ('### ' if kind == 'heading' else '') + body + '\n\n')
            elif t == 'sup':
                out.append(body)
            else:
                raise ValueError(t)
        return ''.join(out)

    for bilingual in (False, True):
        output = ['# 资本的托词', notice]
        for b in books.values():
            output.append('\n# ' + b['title'])
            for r in b['body']:
                output.append('<a id="' + r['id'] + '"></a>')
                for lang in (('zh', 'en') if bilingual and not r.get('shared') else ('zh',)):
                    prefix = '## ' if r['type'] == 'heading' else '### ' if r['type'] == 'subheading' else '> ' if r['type'] == 'quote' else ''
                    output.append(prefix + md(r[lang]))
                if r.get('review'):
                    output.append(r['review'])
        (O / ('alibi_bilingual.md' if bilingual else 'alibi_zh.md')).write_text('\n\n'.join(output) + '\n', encoding='utf-8')
    print('Exported', len(books), 'reader sections and two Markdown editions')


if __name__ == '__main__':
    main()
