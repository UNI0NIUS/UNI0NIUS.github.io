"""One-time first chapter-six bibliographic query resolutions."""
import json
from pathlib import Path
p=Path(__file__).parent;f=p/'editor_notes.json';d=json.loads(f.read_text(encoding='utf-8'))
new=[
dict(id='ed-ch6-pistor-year',unit_id='note-ch6-007',text='校注：底本将《The Code of Capital》出版年列为2016。普林斯顿大学出版社在JSTOR的书籍记录列版权年为2019，出版社2019年春季书目亦收录该书。原注照录。',sources=['https://www.jstor.org/stable/j.ctvc777c1','https://assets.press.princeton.edu/catalogs/S19Seasonal.pdf'],source_locator='JSTOR出版社书籍记录已打开，Copyright Date:2019；出版社季节书目检索摘录支持2019年5月。'),
dict(id='ed-ch6-mitchell-volume',unit_id='note-ch6-022',text='校注：底本将〈The Work of Economics〉列为第47卷第2期、2005年。剑桥大学出版社记录为第46卷第2期（2005年8月），第297—320页；线上发布日期另为2006年2月15日。因此卷号应为46，不能仅按上线年份把2005改为2006。原注照录。',sources=['https://www.cambridge.org/core/journals/european-journal-of-sociology-archives-europeennes-de-sociologie/article/work-of-economics-how-a-discipline-makes-its-world/815F059377FD85DCE1F269E6B29C6DC3'],source_locator='出版方文章页已打开；Information卷期年页及Published online。'),
dict(id='ed-ch6-field-volume',unit_id='note-ch6-067',text='校注：底本将Field的〈Entitled to Work〉列为《Quarterly Journal of Economics》第112卷。日本国立信息学研究所CiNii书目记录列为第122卷第4期（2007），第1561—1602页，所列出版社DOI亦含122.4.1561。原注卷号照录。',sources=['https://cir.nii.ac.jp/crid/1360588385929547520','https://academic.oup.com/qje/article-abstract/122/4/1561/1850508'],source_locator='CiNii检索返回的完整书目及出版社DOI10.1162/qjec.2007.122.4.1561。',limit='出版社文章页重定向到不可访问的CDN，未获得原刊首页；依据机构书目元数据确认卷号，不冒充论文全文核验。'),
dict(id='ed-ch6-alston-pages',unit_id='note-ch6-074',text='校注：底本所列Alston等〈The Determinants and Impact of Property Rights〉页码为1569—614。牛津大学出版社第12卷第1期（1996年4月）目录列该文为第25—61页。原注照录。',sources=['https://academic.oup.com/jleo/issue/12/1'],source_locator='出版方卷期目录检索结果，文章DOI10.1093/oxfordjournals.jleo.a023360。',limit='检索结果包含完整卷期目录及页码；直接打开目录返回状态错误，未取得文章首页。')
]
for n in new:n['verified_on']='2026-10-23'
assert not {n['id'] for n in new}&{n['id'] for n in d}
d.extend(new);f.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
q=dict(status='in_progress',resolutions=[dict(unit_id=n['unit_id'],decision='editor_note',editor_note_id=n['id']) for n in new],canonical_changed=False,remaining='各批其他疑点、术语协调、重点回读和链接输出例外仍待收束；不能将书目核查当历史统计/研究结论全面复核。')
(p/'ch06_query_resolution.json').write_text(json.dumps(q,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
cp=p.parents[2]/'工作文档'/'Alibi后续工作检查点.md';s=cp.read_text(encoding='utf-8')
entry='第六章首批书目疑点已处理：Pistor出版年、Mitchell卷号、Field卷号及Alston等页码新增4条独立校注，现47条。Mitchell正确为46卷2005年、上线2006年，不贸然改为2006；Pistor的JSTOR出版社记录已打开。Field依据CiNii书目，Alston依据出版社目录检索结果，直接访问失败限度均已记。见ch06_query_resolution.json（in_progress）；ch06_queries_first.py一次性不重跑。规范稿未变。**实际下一位置：第六章其余疑点定向核查，随后术语协调与重点回读**。全书统检排版发布未开始。\n\n'
assert '## 授权与当前状态' in s
cp.write_text(s.replace('## 授权与当前状态',entry+'## 授权与当前状态',1),encoding='utf-8');print(len(d))
