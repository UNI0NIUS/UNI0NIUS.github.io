"""One-time initial source-query resolution; remaining queries still pending."""
import json,hashlib
from pathlib import Path
p=Path(__file__).parent
notes=json.loads((p/'editor_notes.json').read_text(encoding='utf-8'))
new=[
dict(id='ed-ch3-barbour',unit_id='note-ch3-040',text='校注：底本作者姓名作Violet Babour；剑桥大学出版社所刊《The Journal of Economic History》论文的参考文献列为Violet Barbour，并列出该书1950年Johns Hopkins Press版。原注拼写照录。',sources=['https://www.cambridge.org/core/journals/journal-of-economic-history/article/abs/transactions-costs-and-differential-growth-in-seventeenth-century-western-europe/395536A9C207F25E9C777DF1D6BDDB84'],source_locator='参考文献第15条',limit='核对期刊引文，未取得1950年书籍题名页。'),
dict(id='ed-ch3-wallerstein',unit_id='note-ch3-040',text='校注：底本将《The Modern World System》第2卷出版年记为1974；日本国立国会图书馆对Academic Press版第2卷的书目记为1980。原注日期照录。',sources=['https://ndlsearch.ndl.go.jp/books/R100000002-I000006370870'],limit='依据馆藏检索元数据；直接打开页面返回Cache miss，未读书籍版权页。'),
dict(id='ed-ch3-federici',unit_id='note-ch3-051',text='校注：底本作者姓名作Silvia Frederici；PM Press所列Autonomedia版《Caliban and the Witch》署名为Silvia Federici。原注拼写照录。',sources=['https://www.pmpress.org/product/caliban-and-the-witch'],source_locator='商品书目Author字段；ISBN9781570270598'),
dict(id='ed-ch3-guns-date',unit_id='note-ch3-100',text='校注：底本《Empire of Guns》出版年作2008；Satia在《Time’s Monster》中回述该书时明确记为2018。原注日期照录。',sources=['https://cdn.penguin.co.uk/dam-assets/books/9780141993928/9780141993928-sample.pdf'],source_locator='出版社试读PDF第21页，书内第8页',limit='确认作者自述出版年份；未据此判定本注所用具体平装印次。')
]
for n in new:
 assert not any(x['id']==n['id'] for x in notes)
 n['verified_on']='2026-10-23'
notes.extend(new)
(p/'editor_notes.json').write_text(json.dumps(notes,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
allq=[]
for f in sorted(p.glob('ch03_*json')):
 d=json.loads(f.read_text(encoding='utf-8'))
 if isinstance(d,dict) and 'queries' in d: allq.extend(dict(batch=f.name,query=q) for q in d['queries'])
record=dict(status='in_progress',canonical_sha256=hashlib.sha256((p/'translation_units.jsonl').read_bytes()).hexdigest(),added_editor_notes=[n['id'] for n in new],resolved=['note-ch3-040 author spelling and volume2 year','note-ch3-051 author spelling','note-ch3-100 publication year'],source_checks=new,all_recorded_queries=allq,next='Remaining bibliography/chronology checks, conceptual terms and targeted chapter reread; no chapter-final approval yet')
(p/'ch03_query_resolution.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('editor notes',len(notes),'canonical unchanged',record['canonical_sha256'])
