"""One-time semantic edits for property and vulnerability sections."""
import json,hashlib
from pathlib import Path
p=Path(__file__).parent; f=p/'translation_units.jsonl'; raw=f.read_bytes()
rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch01-0034':[('这些企业的区别不在于规模或复杂性，而在于','这些企业的独特之处，与其说在于规模或复杂性，不如说在于','not so much 比较重心，不绝对排除规模因素。'),('钢铁和混凝土等再利用材料','钢铁和混凝土等被赋予新用途的材料','repurposed 不意味着回收旧料。')],
'ch01-0036':[('对未来收益或收益率的索取权','对未来收益或回报的索取权','yields 此处是可取得的收益，不是对比率本身的权利。')],
'ch01-0038':[('保障新通信路线的需要','保障新交通通道的需要','此处以运河和补给站为例，communication 指交通联络而非电信。')],
'ch01-0043':[('另一个去稳定后果','另一个破坏稳定的后果','使 destabilising consequences 含义明确。')],
'ch01-0044':[('其他生物和非生物元素回收它的能力','其他生物与非生物要素将其重新纳入循环的能力','recycle 此处是地球系统物质循环。'),('未被回收的废料','未被重新纳入循环的废料','同一生态循环语境。')],
'ch01-0045':[('另一股去稳定力量','另一股破坏稳定的力量','与前段术语一致。')],
'ch01-0047':[('延长并加速工作日','延长工作日并加快其中的劳动节奏','speeding up 工作日指劳动速度，不是日历时间加速。'),('这一去稳定过程','这一破坏稳定的过程','同节术语一致。')],
'note-ch1-047':[('在十九世纪三十年代','在十九世纪的第三个十年（1820年代）','third decade 是1820年代，非1830年代。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits: continue
 old=r['translation']; reasons=[]
 for a,b,why in edits[r['id']]:
  assert a in r['translation'],r['id']
  r['translation']=r['translation'].replace(a,b); reasons.append(why)
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=reasons))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
e=dict(read_ids=[f'ch01-{i:04}' for i in range(34,49)]+[f'note-ch1-{i:03}' for i in range(31,48)],revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',next='ch01-0049',queries=['ch01-0046 late19 first-use claim qualified by note047 earlier French use: preserve author scope rather than rewrite as universal lexical history','grain elevator translation pending terminology pass; denotes storage/handling infrastructure, not just generic lift'])
(p/'ch01_property_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(e['read_ids']),len(revs),e['output_sha256'])
