"""One-time chapter closure, evidence and source-discrepancy notes."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent
def load(n): return json.loads((p/n).read_text(encoding='utf-8'))
def save(n,v): (p/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
notes=load('editor_notes.json')
new=[
dict(id='ed-ch2-fayyum',unit_id='ch02-0033',text='校注：底本此处写法尤姆位于开罗以北；埃及国家新闻署的法尤姆介绍列其位置为开罗西南。正文方位照录。',sources=['https://sis.gov.eg/en/egypt/system-of-government/executive-authority/fayyoum/'],limit='采用官方检索元数据；直接打开返回502。'),
dict(id='ed-ch2-linant',unit_id='ch02-0052',text='校注：底本正文记利南著作为1874年，原注94记1872—1873年；法国国家劳动世界档案馆书目列出版年为1872—1873。原注48的Louis与原注94的Maurice均为书目所列全名Louis Maurice Adolphe Linant de Bellefonds的一部分。原文各处写法照录。',sources=['https://pmb.culture.fr/opac_anmt/index.php?id=19106&lvl=author_see'],limit='档案馆检索元数据可读，直接打开缓存未命中；未查看原版扉页。'),
dict(id='ed-ch2-cholera',unit_id='ch02-0061',text='校注：底本写1881年英国占领前夕霍乱再次出现，原注109所引论文题名则为1883年疫情。该注另引Kuhnke的Lives at Risk区分了1881年汉志霍乱及埃及检疫措施，与1883年埃及疫情。正文照录，不将两地与两年混同。',sources=['https://publishing.cdlib.org/ucpressebooks/public/book/lives-at-risk-public-health-in-nineteenth-century-egypt.html'],limit='出版社数字典藏检索正文，直接打开返回405；不能据此排除所有1881年埃及个案。'),
dict(id='ed-ch2-nubia',unit_id='ch02-0088',text='校注：底本把1933年大坝加高的淹没区域写为“上努比亚”，并笼统称后来的水库抹去整个地区。密歇根大学凯尔西博物馆对阿斯旺坝及淹没遗址的介绍使用“下努比亚”。此处应注意上下努比亚及实际淹没范围的区别；正文保留原作表述。',sources=['https://exhibitions.kelsey.lsa.umich.edu/galleries/Exhibits/AncientNubia/PhotoIntro.html'],limit='博物馆检索元数据；页面直接打开523。未获取原注Adams第19页，未据此断定1933年具体淹没边界。')]
assert not {n['id'] for n in new}&{n['id'] for n in notes}
for n in new:n['verified_on']='2026-10-23'
save('editor_notes.json',notes+new)
q=load('ch02_query_resolution.json')
q['checked'] += [dict(unit=n['unit_id'],resolution=n['text'],sources=n['sources'],access=n['limit']) for n in new]
q['checked'] += [dict(unit='ch02-0031/note-ch2-042',resolution='不判为确定日期错误。教会现行对照表Abib起于公历7月8日；旧历资料存在儒略历6月25日起月的口径，15日对应儒略历7月9日。因此保留底本，未取得中世纪原历书说明，不混用现代公历换算。',sources=['https://www.suscopts.org/messages/preface.pdf'],access='教会对照表PDF已打开；历史儒略历解释是待证推断，非已核原历书'),dict(unit='ch02-0018/note-ch2-016',resolution='Wescoat论文首页明确历史灌溉用英亩/每秒立方英尺的指标，保留依本段定义翻译的单位供水灌溉面积；不把论文现代定义与历史定义强行合一。',sources=['https://hess.copernicus.org/articles/17/4759/2013/hess-17-4759-2013.pdf'],access='出版社PDF第1页已读'),dict(unit='note-ch2-097',resolution='保留above的相对用语“一线以上”；结合正文南三角洲可理解为上游侧，但未取得所引370页地图，不静默改成北侧或声称地图核验完成。',sources=[],access='内部语境'),dict(unit='ch02-0018',resolution='agnotology按本句知而忽视的语境译为无知的制造，并保留原词；这不是给学科名下通用定义。',sources=[],access='源译语境回读')]
q['remaining']=[]
q['status']='closed_with_disclosed_source_limits'
q['limits']=['并未独立验证全章历史、医学、植物学或财务事实。','原作原注数据与shares/certificates术语混用保留，未经独立金融史审计。','原作农业产量下降20%统计未获取分母资料，保留产量泛称。','马赫迪国家1881等年代仍按作者原文，不宣称逐年核实。']
f=p/'translation_units.jsonl'; raw=f.read_bytes(); rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]; changes=[]
for r in rows:
 old=r.get('translation','')
 if r['id']=='ch02-0094':
  r['translation']=old.replace('灌溉债券','灌溉凭证').replace('债券','凭证')
  why='certificates译为凭证，避免无凭据限定为债券；保留源文另用shares的股份。'
 elif r['id']=='ch02-0055':
  r['translation']=old.replace('八名印度培训灌溉工程师','八名在印度受训的灌溉工程师')
  why='明确受训地点，避免印度国籍歧义。'
 else:continue
 changes.append(dict(id=r['id'],before=old,after=r['translation'],reason=why))
 pattern=r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}'
 assert re.findall(pattern,old)==re.findall(pattern,r['translation'])
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
q['canonical_unchanged']=False; q['canonical_sha256']=hashlib.sha256(f.read_bytes()).hexdigest(); save('ch02_query_resolution.json',q)
terms=load('term_decisions.json'); terms['scope']='frontmatter/introduction/chapters1–2; later contextual review pending'
terms['terms'] += [dict(en='basin irrigation',zh='围堤蓄水灌溉',note='田块/田区指人工分区；自然河流流域及法尤姆盆地另按地貌译。'),dict(en='duty of water',zh='单位供水的灌溉面积',note='第二章历史语境定义；并非该词所有时期的唯一含义。'),dict(en='agnotology',zh='无知的制造（本句语境）',note='第二章强调有意忽视；保留原词，学科名语境需另判断。')]
save('term_decisions.json',terms)
e=dict(reread_ids=['ch02-0018','ch02-0025','ch02-0040','ch02-0043','ch02-0055','ch02-0072','ch02-0094','ch02-0100','note-ch2-097'],revisions=changes,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=q['canonical_sha256'],chapter_status='semantic_review_and_chapter_checks_complete_with_source_limits',visual_check='pending',editor_note_count=len(notes+new),next='ch03-0001')
save('ch02_final_evidence.json',e)
print(e['output_sha256'],e['editor_note_count'])
