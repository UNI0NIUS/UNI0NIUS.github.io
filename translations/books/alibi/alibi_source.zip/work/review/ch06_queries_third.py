"""One-time remaining chapter-six source limits and editorial notes."""
import json
from pathlib import Path
p=Path(__file__).parent;f=p/'editor_notes.json';d=json.loads(f.read_text(encoding='utf-8'))
new=[dict(id='ed-ch6-highdam-dates',unit_id='ch06-0061',text='校注：底本称阿斯旺高坝于1971年建成。埃及水资源与灌溉部工程史区分了1970年7月主体工程完成与1971年1月15日正式揭幕两个时间节点。正文保留底本年份，读者宜注意竣工与揭幕口径之别。',sources=['https://www.mwri.gov.eg/?page_id=33310&lang=en'],source_locator='Steps in implementing the project中1970/1971两条，已打开'),dict(id='ed-ch6-ibid-041',unit_id='note-ch6-041',text='校注：此处底本仅作“同上：71”，紧邻前注所引为1908年出版的Lyons土地测量著作，却用于支持正文关于1920年代失地人口的叙述，指向与年代存在疑点。原注照录，未擅自补定所指文献。',sources=[],source_locator='内部对照ch06-0043及note-ch6-040—041；不声称已定位正确出处。'),dict(id='ed-ch6-caliskan',unit_id='note-ch6-004',text='校注：底本作者姓氏作Çalişkan；出版方文章书目署名为Koray Çalışkan。译文采用后者，英文底本保持原貌。',sources=['https://www.tandfonline.com/doi/abs/10.1080/03085140903020580?journalCode=reso20'],source_locator='出版方检索结果作者栏；直接访问403，未取得原刊首页。')]
for n in new:n['verified_on']='2026-10-23'
assert not {n['id'] for n in new}&{n['id'] for n in d};d.extend(new);f.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
qf=p/'ch06_query_resolution.json';q=json.loads(qf.read_text(encoding='utf-8'))
q['resolutions'].extend(dict(unit_id=n['unit_id'],decision='editor_note',editor_note_id=n['id']) for n in new)
q['resolutions'].extend([
dict(unit_id='ch06-0042',decision='retain_source_with_limit',reason='1873恐慌与1874全球萧条起点不是仅凭美国恐慌史即可等同的口径；本轮检索显示相关年代，但不足以裁定作者全球/埃及叙事的起点有误，不强改或加确定纠错。'),
dict(unit_id='note-ch6-020',decision='retain_source_with_limit',reason='1980支持信可以先于1981基金会成立；本轮未定位原信全文，不能只因先后不同判错，不宣称原信日期核实。'),
dict(unit_id='note-ch6-008',decision='retain_source',reason='Leung-Sea与Siu Leung-Sea为书内姓名排列问题，参见第四章Siu姓名核查；不足以推断为另一人或更改引文。'),
dict(unit_id='note-ch6-049',decision='retain_source',reason='信贷种类可重叠，40%不借款、约25%传统与近50%非传统不能强加互斥假定；未重算原始调查。'),
dict(unit_id='note-ch6-060',decision='arithmetic_consistent',reason='4200/24=175；1000/6.20约161.29，与约160美元兼容。'),
dict(unit_id='ch06-0030',decision='retain_author_argument',reason='正文改引与注026的行家们主语差异已对齐；作者对项目成效、政治网络、殖民因果与现代产权制度的判断作为作者论证保存，不冒充本轮独立全量复核。'),
dict(unit_id='note-ch6-085',decision='retain_source_with_limit',reason='Jeson及阿文文章/英文周刊信息未获可核原件，不据姓名常见拼法推改；译文书目转写已恢复底本。'),
dict(unit_id='ch06-0055',decision='retain_historical_scope',reason='自有住房率与其他历史统计保留其原注出处年代；不以2026统计覆盖历史论证。')])
q['remaining']='外部疑点按证据限度收束；尚需重点回读、术语/标题定稿、注019内部跳转与章末最终证据。'
qf.write_text(json.dumps(q,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
cp=p.parents[2]/'工作文档'/'Alibi后续工作检查点.md';s=cp.read_text(encoding='utf-8');entry='第六章其余来源疑点已按证据限度收束：高坝竣工/揭幕口径、注041同上指向疑点、Çalışkan拼写新增3校注，现57条。1874萧条与1873恐慌不凭单一美国史口径等同，1980信件可先于1981成立，均保留来源并记录未独立核实限度；历史统计不以当前数据替换。ch06_queries_third.py一次性不重跑；规范稿未变。**实际下一位置：第六章重点回读、术语与标题定稿、注019链接补充及最终章末证据**。\n\n';assert '## 授权与当前状态' in s;cp.write_text(s.replace('## 授权与当前状态',entry+'## 授权与当前状态',1),encoding='utf-8');print(len(d))
