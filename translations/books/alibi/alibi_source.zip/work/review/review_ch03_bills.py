"""One-time edits; do not rerun after further review."""
import json,hashlib
from pathlib import Path
p=Path(__file__).parent; f=p/'translation_units.jsonl'; raw=f.read_bytes()
rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch03-0016':[('提供和收回债务','发放信贷和收回欠款','债权人的放贷与回收动作，不是提供债务。')],
'ch03-0020':[('王子们','王公们','princes指统治者，非限君主之子。')],
'ch03-0023':[('民族货币','国家货币','national currency语境。'),('中央印刷的纸币','集中印制的纸币','centrally修饰印制方式，非地理中心。')],
'ch03-0024':[('省级银行','地方银行','英国provincial指伦敦以外地方，不引入省行政制度。'),('多数{{P:102}}现钱','多数{{P:102}}可即时使用的货币','ready money包含原文紧接的信用工具，不限现金。')],
'ch03-0027':[('以未来收入损失的形式支付罚金','以损失未来收入的形式付出代价','penalty是经济代价比喻，非法律罚金。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits:continue
 old=r['translation']; reasons=[]
 for a,b,why in edits[r['id']]:
  assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b); reasons.append(why)
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=reasons))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
ids=[r['id'] for r in rows if r.get('translation') and (('ch03-0016'<=r['id']<='ch03-0027') or ('note-ch3-023'<=r['id']<='note-ch3-047'))]
e=dict(read_ids=ids,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',next='ch03-0028',queries=['note-ch3-023 source X link targets this book ch4 while prose cites another book; scoped render override appended','note-ch3-040 Violet Babour spelling and Modern World System vol2 year1974 need chapter-end publisher check','ch03-0025 paid forwards is author temporal concept: keep current direction provisionally and revisit after chapter argument','ch03-0016 simplified bill definition preserved as author account, not independent legal or banking guidance'])
(p/'ch03_bills_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
o=json.loads((p/'render_overrides.json').read_text(encoding='utf-8'))
assert not any(x['unit_id']=='note-ch3-023' for x in o['items'])
o['items'].append(dict(unit_id='note-ch3-023',action='render_cross_reference_as_plain_text',targets=['12_Chapter04.xhtml'],reason='引用Private Money and Public Currencies第四章，底本误链到本书第四章；输出保留文字，移除误链。'))
(p/'render_overrides.json').write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(ids),len(revs),e['output_sha256'])
