"""One-time semantic batch; do not rerun after later edits."""
import json, hashlib, re
from pathlib import Path
p=Path(__file__).parent; f=p/'translation_units.jsonl'; raw=f.read_bytes()
rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch03-0044':[
('棉纺织是从被全球战争、殖民扩张、抵抗和革命所打乱的信用制造体系中挽救出来的一条岔路。','转向棉纺织，是为了挽救被全球战争、殖民扩张、抵抗和革命打乱的信用制造体系而采取的一次绕道。','恢复to salvage的目的及宾语，不是棉纺织被挽救。')],
'ch03-0046':[
('英国政府支付德国各邦统治者提供的雇佣兵','英国政府为德国各邦统治者提供的雇佣兵付费','明确付款对象是雇佣兵费用，避免支付人。'),
('通过向伦敦商人开立信用证转移','通过以伦敦商人为付款人的信用证转移','drawn on指付款方，不是将信用证开给商人。'),
('英格兰羊毛和亚麻贸易','英格兰毛织品和亚麻织品贸易','woollens/linens指织品而非原料。'),
('需要一种新的衣服回程','需要换上一身新衣才能回流','保留new clothing比喻并表达信用回流。')],
'ch03-0048':[
('他至少是当时定居曼彻斯特的八名德国商人之一','当时至少有八名德国商人定居曼彻斯特，他是其中之一','at least限定群体数量。'),
('作为现钱','作为可即时使用的货币','ready money与前文信用票据语境一致，非现金。'),
('其他曼彻斯特棉花商人','其他曼彻斯特棉布商人','交易对象为布匹。')],
'ch03-0049':[
('来购买棉花','来采购布匹','恢复与上下段weavers/cloth的对象关联。'),
('可以把供织机梭子使用的纱线“绕”到或同时卷到几根锭子上','可以把供织机梭子使用的纱线同时卷绕到几根锭子上','copped or wound是同义解释，并非两种不同动作。'),
('积累在他父亲法兰克福手中的汇票','积累在他位于法兰克福的父亲手中的汇票','恢复地点与人物修饰关系。')],
'ch03-0050':[
('这座城市成为商人—金融家的中心','曼彻斯特成为商人—金融家的中心','排除上句搬往伦敦造成的指代歧义。'),
('创始人之子弗里德里希·恩格斯','创始人之一的儿子弗里德里希·恩格斯','保留one of限定。')],
'ch03-0051':[
('德国商行的增长，后来又被越来越多来自奥斯曼世界的商人所匹配','随着德国商行的发展，来自奥斯曼世界的商人后来也日益增多','消除被匹配的生硬被动句，保留并行增长关系。'),
('后来又与西非和大多数其他地区贸易','后来又为与西非和大多数其他地区的贸易融资','financed延续修饰后列地区。'),
('他在英国统治下工作了三十年，而且恰如其分地在灌溉部谋生','他在英国统治下的灌溉部工作了三十年，以此谋生——这份任职倒也恰如其分','三十年限定在灌溉部工作。')],
'ch03-0053':[
('如果说曼彻斯特的外国商人为推动棉花制造绕道的贸易提供了融资','如果说曼彻斯特的外国商人为贸易提供融资，推动了向棉纺织业的绕道','cotton manufacturing非制造棉花；恢复trade帮助推动绕道。'),
('埃及则作为一个独立的权力中心得到加强，越来越自主于伊斯坦布尔的奥斯曼当局','埃及则作为一个有别于其他地区的权力中心得到加强，相对于伊斯坦布尔的奥斯曼当局获得了越来越大的自主性','distinct不直接断言政治独立，保留increasingly autonomous程度。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits: continue
 old=r['translation']; reasons=[]
 for a,b,why in edits[r['id']]:
  assert r['translation'].count(a)==1,(r['id'],a)
  r['translation']=r['translation'].replace(a,b); reasons.append(why)
 assert re.findall(r'\{\{.*?\}\}',old)==re.findall(r'\{\{.*?\}\}',r['translation'])
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=reasons))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
ids=[f'ch03-{i:04}' for i in range(43,54)]+[f'note-ch3-{i:03}' for i in range(67,81)]
e=dict(read_ids=ids,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',next='ch03-0054 and note-ch3-081',queries=['ch03-0052 Provincialising Manchester heading retained pending subsequent section and chapter-end context','ch03-0051 Cavafy grandson relationship is in source; preserve pending chapter-end targeted verification','ch03-0046 58 percent and ch03-0048 15/20 percent preserved source values; no independent economic history audit','ch03-0048 machinic diversion currently 机械式转用; reconcile conceptual usage at chapter end'])
(p/'ch03_detour_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(ids),len(revs),e['output_sha256'])
