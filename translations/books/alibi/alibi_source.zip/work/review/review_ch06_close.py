"""One-time final reading batch and chapter coverage/structure audit."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent;f=p/'translation_units.jsonl';raw=f.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='c86db5de4a408a241a83fae0d1a5141c1c5b75f063062db80aa54814d0022a61'
rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch06-0093':[('取消赎回权权力','止赎权力','统一foreclosure术语。')],
'ch06-0094':[('取消赎回权权力','止赎权力','统一foreclosure术语。'),('对佃户权利的保护','对租户权利的保护','tenants在住房语境不限农地佃户。')],
'ch06-0096':[('在其物质存在之外过一种无形的、平行的生活','在与其物质存在并行的层面上，过一种无形的生活','alongside不是排除物质存在，而是并行。')],
'ch06-0101':[('不会在日常购物中不知不觉流失','不会在随意购物中一点点流失','casual purchases非一切日常必要采购。')],
'ch06-0102':[('可以旅行更远距离','可以流通到更远的地方','travel指资产流通。')],
'ch06-0103':[('亲戚家附近穿过田地的灌溉泵','田地另一头亲戚家旁的灌溉泵','across fields定位亲戚住宅，泵不穿过田地。'),('用客户家庭操作','让依附于他们的家庭操作','client families为依附关系，不是消费客户。'),('监督和纪律约束大批劳动力','监督和规训大批劳动力','与纪律权力概念对齐。')],
'ch06-0104':[('取消赎回权和驱逐','止赎和驱逐','统一foreclosure术语。'),('如果说有什么，反而在于某种更物质的东西','真要说来，反而在于某种更具物理强制性的东西','if anything加强反向判断，physical对应驱逐强制。'),('最物质的权力','最直接的物理强制权力','physical powers指实体强制执行。')],
'ch06-0108':[('这种重新排序','这种重新安排','reordering为社会关系重组，不是列表排序。')],
'ch06-0110':[('并延长未来的贫困','并扩大未来的贫困化','impoverishment是使未来贫困化的过程，extended不限延长持续时间。')],
'note-ch6-085':[('al-dakhil?','al-dakhl?','恢复源文书目转写，不无证据改写。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits:continue
 old=r['translation'];why=[]
 for a,b,c in edits[r['id']]:
  assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b);why.append(c)
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=why))
read=[f'ch06-{i:04}' for i in range(93,111)]+[f'note-ch6-{i:03}' for i in range(85,95)]
seen=set(read)
for name in ['opening','property','history','housing','boundaries']:
 seen.update(json.loads((p/f'ch06_{name}_revisions.json').read_text(encoding='utf-8'))['read_ids'])
chapter=[r for r in rows if (r['section']=='ch06' or r['id'].startswith('note-ch6-')) and r['status']=='translated']
chapterids={r['id'] for r in chapter}
assert chapterids==seen,(chapterids-seen,seen-chapterids)
refs=[];notes=[r['id'] for r in chapter if r['id'].startswith('note-ch6-')]
for r in chapter:
 refs+=re.findall(r'\{\{N:([^}]+)\}\}',r['translation'])
 pat=r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}'
 assert re.findall(pat,r['source_text'])==re.findall(pat,r['translation']),r['id']
 r['review_status']='semantic_reviewed';r['status_reason']='source/translation comparison completed; chapter structural checks passed; external queries recorded separately'
assert sorted(refs)==sorted(notes)
oldrows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
for a,b in zip(oldrows,rows):
 assert a['id']==b['id']
 for k in ['source_text','source_markup','source_refs','printed_pages','note_refs','page_start','page_end']:assert a.get(k)==b.get(k)
 if b['id'] not in chapterids:assert a==b
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
e=dict(read_ids=read,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_reviewed_count=len(chapter),notes=len(notes),status='semantic_and_structure_review_passed_external_queries_pending',checks=['all translated chapter units read','94 note references match94 definitions','structural token order','source fields preserved','other chapters unchanged'],queries=['resolve accumulated chapter queries and perform targeted reread','ch0075 Having to Lose refers ch0094 no property to lose; title choice at final review','ch0098 performance/performative contrast should retain legal act rather than mere representation; terminology reread','ch0099 historical US title registry account not independent current legal advice or all-state verification','note085 Jeson spelling and Arabic article cited in English weekly remain source details unless verified'],next='chapter6 query resolution, terminology and targeted reread')
(p/'ch06_close_evidence.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
cp=p.parents[2]/'工作文档'/'Alibi后续工作检查点.md';s=cp.read_text(encoding='utf-8')
entry='第六章全章源译校读完成：末批ch06-0093—0110及原注085—094共28单元，修订10单元；全章108正文/标题与94原注共202单元，已读覆盖、94引用/定义、结构令牌、源字段和其他章节保留检查通过。累计1456有效单元。修复灌溉泵位置、依附家庭误作客户、租户范围和强制权力表述。证据ch06_close_evidence.json；review_ch06_close.py一次性不重跑。当前SHA256 '+e['output_sha256']+'。**实际下一位置：第六章疑点定向核查、术语协调和重点回读**。全书统检、排版和发布尚未开始。\n\n'
assert '## 授权与当前状态' in s
cp.write_text(s.replace('## 授权与当前状态',entry+'## 授权与当前状态',1),encoding='utf-8')
print(len(read),len(revs),len(chapter),len(notes),e['output_sha256'])
