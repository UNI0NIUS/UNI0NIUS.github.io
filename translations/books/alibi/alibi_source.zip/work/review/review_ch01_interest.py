"""One-time edits; chapter-level audit pending."""
import json,hashlib
from pathlib import Path
p=Path(__file__).parent; f=p/'translation_units.jsonl'; raw=f.read_bytes()
rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch01-0065':[('经济学人试图','经济学家试图','修复称谓。')],
'ch01-0068':[('一位富有姑母','一位富有的姑姨辈亲属','aunt 未指明父系或母系，避免杜撰。'),('在法国东北部奥希村上游开凿了一条小河','把法国东北部奥希村上游的一条小河改造成运河','canalised 为改造既有河道，不是挖出河流。'),('像许多想成为工业家的人来说','与许多想成为工业家的人一样','修复句法。')],
'ch01-0070':[('企业家这一脆弱的人际纽带','企业家这个人物构成的薄弱联系','human link 指人的理论中介，不是人际关系。')],
'ch01-0071':[('货币赚取货币的能力完全取决于企业家的角色','货币赚取货币的能力在决定性程度上依赖于企业家的角色','decisively 不等同于 exclusively，避免加强为完全。')],
'ch01-0074':[('二十世纪之交的资本主义感','二十世纪之交“资本主义”的含义','sense 指词义，非感受。')],
'ch01-0076':[('把约瑟夫·熊彼特带到开罗的事件，正是这场崩盘之后发生的，其起点是 1905 年巴黎的一起自杀。','约瑟夫·熊彼特在那场崩盘之后来到开罗，而促成此行的一连串事件，起于1905年巴黎的一起自杀。','崩盘之后限定赴开罗，不能把1905事件放到1907之后。')],
'ch01-0078':[('交易商在随后的日子里感受到了{{P:48}}伦敦、纽约和汉堡交易所的冲击','随后的几天，伦敦、纽约和汉堡交易所的交易商也感受到了这场{{P:48}}冲击','这些交易所是冲击接受地，不是冲击来源。')],
'note-ch1-074':[('创造性毁灭','创造性破坏','与正文同一术语统一。')],
'note-ch1-083':[('直到去年 8 月 15 日','直到刚过去的8月15日','1905年11月文章的August last是同年8月，不是去年。'),('非凡的才干和声望','才干和声望','simple ability 无非凡程度限定，删除增译。')],
'note-ch1-087':[('在[国家]埃及银行股东会议上','在埃及[国民]银行股东会议上','与正文National Bank of Egypt统一并保留原文括号。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits: continue
 old=r['translation']; reasons=[]
 for a,b,why in edits[r['id']]:
  assert a in r['translation'],r['id']
  r['translation']=r['translation'].replace(a,b); reasons.append(why)
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=reasons))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
e=dict(read_ids=[f'ch01-{i:04}' for i in range(65,82)]+[f'note-ch1-{i:03}' for i in range(70,89)],revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',next='ch01-0082',queries=['Fisher book:正文1908 vs note070 1907; retain and verify chapter-end','note083 expert report wording may require syntax clarification at chapter-end'])
(p/'ch01_interest_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(e['read_ids']),len(revs),e['output_sha256'])
