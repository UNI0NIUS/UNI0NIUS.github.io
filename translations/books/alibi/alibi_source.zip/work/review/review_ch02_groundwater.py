"""One-time edits. Chapter-end verification remains pending."""
import json,hashlib
from pathlib import Path
p=Path(__file__).parent; f=p/'translation_units.jsonl'; raw=f.read_bytes()
rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch02-0023':[('田间盆地中，而是储存在盆地之下的底层中','围堤田块中，而是储存在它们之下的地层中','区分田块与地下储层。'),('后来十九世纪灌溉方案','十九世纪后期灌溉方案','later-nineteenth-century 指十九世纪后期。')],
'ch02-0025':[('形成盆地','构成围堤田区的底部','此处承接人工围堤田块，不是自然盆地。'),('在地下黏土之上截留大量{{P:64}}水分','蓄存大量{{P:64}}水分，水被截留在上覆黏土层之下','纠正 beneath/above 修饰关系和储水层上下位置，同时保留页位。'),('地下水枯竭','地下水减少','depletion 未必完全枯竭。')],
'ch02-0030':[('夜晚最安静时刻','夜间最安静地段','part of a village 指空间区域，不是时间。'),('从这里往下七八英里、阿斯旺以下的地方','沿着这里，也就是阿斯旺下游七八英里的地方','距离起点是阿斯旺，不是此地。')],
'ch02-0031':[('田地盆地中央','围堤田块中央','沿用人工围堤田块术语。'),('水井在生长季节逐渐枯竭','井中储水在生长季节逐渐减少','depleted 结合最低水位，非井干涸。')],
'ch02-0032':[('南极探险的老兵','南极探险的老队员','veteran 指有经验的参与者，非军人身份。'),('田间盆地中','围堤田块中','术语对齐。')],
'ch02-0033':[('主要蓄洪盆地排空','主要蓄水田区排空','人工田区，不改本段自然法尤姆盆地。')],
'ch02-0034':[('洪泛盆地农业','围堤蓄水农业','对应 flood-basin agriculture，保留与自然流域之别。'),('大型河流盆地上千年来','大型河流流域数千年来','river basins 为自然流域，millennia 为复数千年。'),('对盆地系统的改良','对围堤蓄水系统的改良','人工灌溉系统。')],
'ch02-0035':[('包括靛蓝、芝麻','包括靛蓝作物、芝麻','indigo 此处为作物而非染料。'),('块根作物','根茎类作物','root crop 为宽泛作物类，避免添加块根器官判断。')],
'note-ch2-026':[('洪水盆地','围堤田区'),('而盆地作物','而围堤田区的作物')],
'note-ch2-027':[('各不相同的洪水盆地','各不相同的围堤田区'),('大型盆地系统链条','大型蓄水田区的系统链条')],
'note-ch2-028':[('田间盆地','围堤田块'),('所有盆地土地','所有围堤田区的土地'),('每年可收获三到四种不同的作物','每年可取得三到四次不同的收成','harvests 不是种类数量，保留原引文的收获次数。')],
'note-ch2-051':[('盆地中只有三处溃决','围堤田区只有三处溃决'),('蓄水过满的盆地','蓄水过满的田区')],
'note-ch2-057':[('各盆地','各围堤田区'),('上游盆地','上游蓄水田区'),('盆地里','围堤田区里')]
}
revs=[]
for r in rows:
 if r['id'] not in edits: continue
 old=r['translation']; reasons=[]
 for edit in edits[r['id']]:
  a,b=edit[:2]; why=edit[2] if len(edit)>2 else '本段 basin 指围堤灌溉田区，统一语境术语。'
  assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b); reasons.append(why)
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=reasons))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
read_ids=[r['id'] for r in rows if ('ch02-0023'<=r['id']<='ch02-0036') or r['id'] in ['ch02-fig02','ch02-fig03','ch02-fig04'] or ('note-ch2-026'<=r['id']<='note-ch2-058')]
# Preserve supplied figure translations in the independent review area, not the draft.
fig=p.parent/'translation'/'figure_translations.json'; dest=p/'figure_translations.json'
assert not dest.exists()
dest.write_bytes(fig.read_bytes())
e=dict(read_ids=read_ids,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',next='ch02-0037',figure_description_review=['ch02-fig02','ch02-fig03','ch02-fig04'],figure_description_sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),figure_visual_status='pending',queries=['ch02-0033 Fayyum north of Cairo appears source geographic error; preserve source and verify at chapter end','ch02-0031 and note-ch2-042 Abib 15 (July 9) calendar pairing appears inconsistent; verify primary calendar evidence at chapter end','ch02-0031 artificial head retained from source; no silent technical rewriting','Figure metadata translations copied separately; final generator must consume review/figure_translations.json for alt and long descriptions as well as canonical unit captions'])
(p/'ch02_groundwater_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(read_ids),len(revs),e['output_sha256'])
