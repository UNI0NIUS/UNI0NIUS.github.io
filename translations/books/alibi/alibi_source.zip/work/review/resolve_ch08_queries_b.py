"""One-time bounded query closure; source limitations remain disclosed."""
import json,math,hashlib
from pathlib import Path
p=Path(__file__).parent;qf=p/'ch08_query_resolution.json';q=json.loads(qf.read_text(encoding='utf-8'))
nf=p/'editor_notes.json';ns=json.loads(nf.read_text(encoding='utf-8'));assert len(ns)==69
new=[]
def add(key,unit,text,url,loc):new.append(dict(id='ed-ch8-'+key,unit_id=unit,text='校注：'+text,sources=url,source_locator=loc,verified_on='2026-10-23'))
add('speich-number','note-ch8-003','原注将编号写作33:8；作者机构库列为工作论文33/08（2008年），不宜理解成期刊第33卷第8期。',['https://www.research-collection.ethz.ch/entities/publication/fa2960ac-a013-4280-9540-5a20a030c75e'],'ETH机构库检索元数据含33/08；直接访问403，未核PDF封面。')
add('gold-scope','ch08-0057','底本“只有英国实行金本位”的说法须区分制度采用与国际货币体系中英镑的主导地位。1876年美国外交文书明确记载德国采用黄金作为单一本位，并自1876年1月1日起以金马克为法定货币；因此不能将此句理解为其他国家从未采用金本位。正文保留作者论述，未擅自改写其关于国际信用体系的解释。',['https://history.state.gov/historicaldocuments/frus1876/d67'],'美国国务院历史文献FRUS1876文书67，已打开；同时与IMF关于德国1871—73改革的研究摘要交叉核对。')
add('money-share','ch08-0048','底本“95%以上”未在本段标明地区、时期和货币统计口径。英格兰银行2014年说明中，97%指当时英国广义货币中的银行存款份额；这一常被引用的比例不能直接当作所有国家、所有货币口径的恒定比例。正文保留原数，未作全球比例复算。',['https://www.bankofengland.co.uk/-/media/boe/files/quarterly-bulletin/2014/quarterly-bulletin-2014-q1'],'英格兰银行2014Q1原刊检索文字：Of the two types of broad money…bank deposits…97%。不声称这是作者未列出的确切来源。')
ns+=new
for n in new:q['resolutions'].append(dict(unit_id=n['unit_id'],decision='editor_note',editor_note_id=n['id']))
for r in q['resolutions']:
 if r['unit_id']=='note-ch8-003' and r['decision']=='query_pending':r['decision']='resolved_by_editor_note'
 if r['unit_id']=='note-ch8-008' and r['decision']=='query_pending':
  r['decision']='retained_with_source_limit';r['reason']='原刊确认作者、题名、卷年；期刊PDF地址重定向目录，未取得完整页码证据，底本94–127保留，不凭单页检索推断首末页。'
 if r['unit_id']=='note-ch8-029':r['decision']='edition_unconfirmed_retained';r['reason']='未核到所引2019版本版权页；初版年份不同不足以否定后续印次，保留底本。'
q['resolutions'] += [
dict(unit_id='note-ch8-025',decision='publisher_year_verified_retained',reason='Melville House原出版社书页确认2024年2月13日出版；底本年份与出版社吻合，出版城市未核版权页，不擅改。',sources=['https://mhpbooks.com/books/technofeudalism']),
dict(unit_id='ch08-0030',decision='arithmetic_approximation_retained',reason='3%和6%复利翻倍时间约23.45年、11.90年；24/12年为近似。100/1.06^12约49.70，50为近似。90至100增长约11.11%，超过10%成立。',calculations={'double_at_3':math.log(2)/math.log(1.03),'double_at_6':math.log(2)/math.log(1.06),'pv_100_12yr_6pct':100/(1.06**12),'90_to_100_pct':(100/90-1)*100}),
dict(unit_id='ch08-0041',decision='historical_scope_retained',reason='一千年前作为长时段回顾的起点；未将马穆鲁克时期本身错误重译为一千年前开始。底本并列概述保留，不为作者添加未列出的精确断代。'),
dict(unit_id='ch08-0055',decision='translation_scope_corrected_source_claim_retained',reason='四百年限定英国参战历史已修正译文；作者所称重大程度和战争范围未核所引Jones原页，保留论述且不宣称已独立证实。'),
dict(unit_id='ch08-0056',decision='historical_scope_limit',reason='检索史料区分1708年对六人以上银行合伙发行票据的限制与后续发行管制；未核Ingham126–131页，不能据概述确认贴现私人汇票的全面排他垄断。原文保留，作为作者概括而非独立法律史结论。',sources=['https://www.bankofengland.co.uk/about/history','https://fraser.stlouisfed.org/title/history-bank-england-financial-services-state-634/fulltext']),
dict(unit_id='note-ch8-002',decision='historical_calculation_not_reproduced',reason='作者称依据2021版GlobalCarbonBudget计算，所述是燃料燃烧总量但来源属于碳排放统计。未取得其具体计算表；保留80%和一半及历史时间，不把当前排放数据替换进去，也不声称燃料能量/质量比例已核实。'),
dict(unit_id='note-ch8-043',decision='source_limit_retained',reason='原注题名明确CO2排放且起点1751，正文概述1750；未取得IEEP原页，不把一年差异擅判为计算错误，保留作者历史概述。'),
dict(unit_id='note-ch8-040',decision='historical_statistic_retained',reason='35–40%依原注注明2006年估算；未取得计算明细，不宣称重做德国成本分解。')]
q['status']='queries_closed_with_disclosed_source_limits_terms_and_reread_pending'
q['remaining']=['EconoCon及indemnification术语协调','重点段落回读与章末最终证据','附属材料10个标题（已对照读取，尚未写review_status）及全书集中统检']
nf.write_text(json.dumps(ns,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');qf.write_text(json.dumps(q,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
cp=p.parents[2]/'工作文档'/'Alibi后续工作检查点.md';s=cp.read_text(encoding='utf-8')
entry='第八章疑点集中核查已收口并披露限度：新增工作论文33/08编号、金本位范围、95%以上货币口径三条校注，现72条；复利近似本地复算通过，2024年Melville House版本获出版方确认。无法取得的原页/具体印次不凭推测改写，范围写入ch08_query_resolution.json，状态queries_closed_with_disclosed_source_limits_terms_and_reread_pending。resolve_ch08_queries_b.py一次性不重跑，规范稿未改。已读取尚未标已校的10个注释分组标题，其中第五章经济心态须改为经济治理术。**实际下一位置：第八章术语与重点回读，随后附属标题和全书集中统检**。排版与发布未开始。\n\n'
cp.write_text(s.replace('## 授权与当前状态',entry+'## 授权与当前状态',1),encoding='utf-8')
print('Saved 72 editor notes; queries closed with disclosed limits; terms/reread pending.')
