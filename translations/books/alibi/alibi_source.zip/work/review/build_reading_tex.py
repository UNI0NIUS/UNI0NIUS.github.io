"""Generate both PDF sources from the reviewed shared model; compile separately."""
import json
import re
import shutil
from pathlib import Path
from bs4 import BeautifulSoup, NavigableString
from edition_model import P, build

O = P.parents[1] / 'output/reviewed'


def esc(text):
    return ''.join({'\\': r'\textbackslash{}', '{': r'\{', '}': r'\}', '%': r'\%', '&': r'\&', '$': r'\$', '#': r'\#', '_': r'\_', '~': r'\textasciitilde{}', '^': r'\textasciicircum{}'}.get(c, c) for c in text)


PRE = r'''\documentclass[11pt,a4paper]{article}
\usepackage{fontspec,xeCJK}
\setmainfont{Times New Roman}
\setCJKmainfont[AutoFakeBold=2,AutoFakeSlant=.2]{SimSun}
\setCJKmonofont{SimSun}
\usepackage[margin=23mm,top=24mm,bottom=24mm]{geometry}
\usepackage{xcolor,hyperref,xurl,fancyhdr,needspace,graphicx}
\newfontfamily\arabicfont[Script=Arabic]{Times New Roman}
\usepackage{bidi}
\hypersetup{unicode=true,hidelinks,pdftitle={资本的托词},pdfauthor={Timothy Mitchell}}
\setlength{\parindent}{0pt}\setlength{\parskip}{6pt}
\setlength{\emergencystretch}{4em}\tolerance=2500
\widowpenalty=10000\clubpenalty=10000
\pagestyle{fancy}\fancyhf{}\fancyhead[L]{\small 资本的托词}\fancyhead[R]{\small EDITION}\fancyfoot[C]{\thepage}
\setlength{\headheight}{15pt}
\renewcommand{\contentsname}{目录}
\begin{document}
\begin{titlepage}\vspace*{28mm}{\Huge\bfseries 资本的托词\par}\vspace{8mm}{\Large 我们如何以“明天会更好”的承诺，毁掉地球，窃取未来\par}\vspace{10mm}The Alibi of Capital\par\vspace{8mm}蒂莫西·米切尔（Timothy Mitchell）\par\vspace{18mm}EDITION\par\vfill
校订阅读版。依用户提供的 Verso 2026 年 EPUB 校读，保留原书页位、853 条原注、4 幅正文图及英文索引。72 条校注与原注分列；其中注明原作疑点与查证限度。原著与图像权利归原权利人；本译文非出版社官方译本。\end{titlepage}
\tableofcontents\clearpage
'''


def generate():
    model = build()
    assert not model['unresolved_xrefs']
    O.mkdir(parents=True, exist_ok=True)
    (O / 'images').mkdir(exist_ok=True)
    for image in (P.parent / 'source/images').iterdir():
        if image.is_file():
            shutil.copy2(image, O / 'images' / image.name)
    for bilingual in (False, True):
        seen_pages = set()
        langlist = ('zh', 'en') if bilingual else ('zh',)

        def page(number):
            if number in seen_pages:
                return ''
            seen_pages.add(number)
            blank = '（空白页）' if number in ('ii', 'vi', 'viii', 'xii', '292', '370') else ''
            return r'\hypertarget{page-' + number + r'}{}{\scriptsize\color{gray}〔原书第' + number + '页〕' + blank + '}'

        def text(value):
            def mixed(v):
                return ''.join(r'\RL{{\arabicfont ' + esc(run) + '}}' if re.search(r'[\u0600-\u06ff]', run) else esc(run)
                               for run in re.split(r'([\u0600-\u06ff]+)', v))
            return ''.join(r'\url{' + v + '}' if re.match(r'(?:https?://|www\.)', v) else mixed(v)
                           for v in re.split(r'((?:https?://|www\.)[^\s\u3000-\u9fff\uff00-\uffef]+)', value))

        def tokens(nodes, lang):
            out = []
            for node in nodes:
                if isinstance(node, str):
                    out.append(text(node))
                    continue
                kind = node['type']
                body = tokens(node.get('children', []), lang)
                if kind == 'page':
                    out.append(page(node['id']) if lang == 'zh' else '')
                elif kind == 'note':
                    key = node['id']
                    out.append(r'\hypertarget{ref-' + lang + '-' + key + r'}{}\hyperlink{' + key + r'}{\textsuperscript{' + str(int(key.rsplit('-', 1)[1])) + '}}')
                elif kind in ('em', 'strong'):
                    out.append(('\\emph' if kind == 'em' else '\\textbf') + '{' + body + '}')
                elif kind == 'span':
                    out.append(body)
                elif kind in ('xref', 'unitlink'):
                    out.append(r'\hyperlink{' + node.get('resolved', node.get('target')) + '}{' + body + '}')
                elif kind == 'link':
                    out.append(r'\href{' + esc(node['target']) + '}{' + body + '}')
                elif kind == 'image':
                    width = '25mm' if node['filename'] == 'logo.jpg' else '.65\\linewidth'
                    out.append(r'\par\begin{center}\includegraphics[width=' + width + ',height=.65\\textheight,keepaspectratio]{images/' + node['filename'] + r'}\end{center}')
                else:
                    raise ValueError(kind)
            return ''.join(out)

        edition = '中英逐段对照校订阅读版' if bilingual else '中文校订阅读版'
        out = [PRE.replace('EDITION', edition)]
        previous_section = None
        for row in model['rows']:
            uid, section, kind = row['id'], row['section'], row['kind']
            if section != previous_section:
                out.append(r'\clearpage')
                previous_section = section
            out.append(r'\hypertarget{' + uid + '}{}')
            if 'figure' in row:
                out.append(r'\begin{center}\includegraphics[width=.9\linewidth,height=.56\textheight,keepaspectratio]{images/' + row['figure']['filename'] + r'}\end{center}')
            for lang in langlist:
                content = tokens(row[lang], lang)
                if not content:
                    continue
                if kind in ('heading', 'note_group_heading'):
                    level = 'section' if row['level'] == 1 else 'subsection'
                    # Source title pages and source TOC retained, without duplicate navigation.
                    navigation = section not in ('frontmatter', '01_cover') and lang == 'zh'
                    out.append(r'\needspace{6\baselineskip}\phantomsection' + '\\' + level + '*{' + content + '}' + (r'\addcontentsline{toc}{' + level + '}{' + content + '}' if navigation else ''))
                    if uid == 'frontmatter-0029' and lang == 'zh':
                        out.append('阅读版目录见卷首；原书目录条目已由本版导航替代。')
                elif kind == 'quote':
                    out.append(r'\begin{quote}' + content + r'\end{quote}')
                elif kind == 'note':
                    out.append(r'{\small ' + ('\\color{black!75} ' if lang == 'en' else '') + r'\textbf{' + str(int(uid.rsplit('-', 1)[1])) + '.} ' + content + r' \hyperlink{ref-' + lang + '-' + uid + r'}{[返回]}\par}')
                else:
                    out.append(('{' if lang == 'zh' else r'{\color{black!75} ') + content + r'\par}')
                if 'figure' in row and row['figure']['description'][lang]:
                    out.append(r'{\small 图像描述：' + text(row['figure']['description'][lang]) + r'\par}')
            for note in row['editor_notes']:
                urls = ' '.join(x if isinstance(x, str) else x['url'] for x in note.get('sources', []))
                out.append(r'\hypertarget{' + note['id'] + r'}{}{\small\color{blue!50!black} ' + text(note['text'] + ' ' + urls) + r'\par}')
        # Traverse full source index DOM to retain page positions within nested entries.
        soup = BeautifulSoup(model['index']['full_source_body_html'], 'html.parser')

        def index_node(node, depth=0):
            if isinstance(node, NavigableString):
                return esc(str(node))
            if node.has_attr('hidden'):
                return ''
            if node.get('role') == 'doc-pagebreak':
                return page(node['id'].removeprefix('page'))
            body = ''.join(index_node(child, depth + (node.name == 'ul')) for child in node.children)
            if node.name == 'h1':
                return r'\section*{英文索引}\addcontentsline{toc}{section}{英文索引}'
            if node.name in ('i', 'em'):
                return r'\emph{' + body + '}'
            if node.name == 'a':
                target = node.get('href', '').split('#')[-1]
                resolved = model['aliases'].get(target, target if target.startswith('ind_') else None)
                assert resolved, target
                return r'\hyperlink{' + resolved + '}{' + body + '}'
            if node.name == 'li':
                return r'\par\hypertarget{' + node['id'] + r'}{}\noindent\hspace*{' + str(max(0, depth - 1) * 5) + 'mm}' + body + '\n'
            if node.name == 'p':
                return r'\par\needspace{3\baselineskip}\textbf{' + body + r'}\par'
            return body

        out.extend([r'\clearpage', index_node(soup), r'\end{document}'])
        assert len(seen_pages) == 400, len(seen_pages)
        stem = 'alibi_bilingual' if bilingual else 'alibi_zh'
        (O / (stem + '.tex')).write_text('\n'.join(out), encoding='utf-8')
    (O / 'tex_build_manifest.json').write_text(json.dumps({'canonical_sha256': model['canonical_sha256'], 'status': 'tex_generated_not_compiled_or_layout_verified', 'editions': ['alibi_zh', 'alibi_bilingual'], 'source_pages': 400, 'original_notes': 853, 'editor_notes': 72}, ensure_ascii=False, indent=2), encoding='utf-8')
    print('Generated TeX sources:', O)


if __name__ == '__main__':
    generate()
