"""One-time boundaries and asset-transfer batch; do not rerun."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent;f=p/'translation_units.jsonl';raw=f.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='4cfbae98d7d36ceb957fd8d9bfda4822335fef7acab0a9ff3d4438cd31af62b0'
rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch06-0066':[('实现形式化','实现正式化','formalisation为纳入正式产权制度。')],
'ch06-0067':[('城市住房形式化','城市住房正式化','统一制度义。'),('《资本的奥秘》','{{I}}《资本的奥秘》{{/I}}','恢复书名斜体。')],
'ch06-0068':[('目前没有足够证据','当时没有足够证据','There was指所述调查时期，不冒充当前现状。'),('他们要么失去土地，要么被迫','他们要么失去使用土地的机会，要么被迫','lost access非失去原有所有权，前文为佃户。')],
'ch06-0069':[('新法若增加了业主的权利','就新法增加业主权利的方面而言','to the extent限定论证范围，不是假定是否增加。')],
'ch06-0070':[('那些损失对家庭不至于{{P:228}}灾难性打击的信贷形式','那些即使损失，对家庭造成的{{P:228}}灾难性打击也较小的信用形式','less catastrophic是程度比较，不保证完全没有灾难后果；保留credit的宽义。')],
'ch06-0071':[('这类应急出售','这类困境中的被迫出售','distress sales强调被迫而非主动应急。')],
'ch06-0072':[('那也不是为了冒险贷款','那也不是为了用它担保贷款而使财产承受风险','risk it指使财产面临丧失风险。'),('贷款接受率','贷款申请批准率','贷款机构接受申请，非借款者接受贷款。'),('不会让小土地所有者变得有信用','不会使小土地所有者达到贷款机构的授信要求','creditworthy为信贷评估资格，不是道德诚信。')],
'ch06-0076':[('《资本的奥秘》','{{I}}《资本的奥秘》{{/I}}','恢复斜体。')],
'ch06-0079':[('不劳而获的可能性','几乎无需付出成本就获得收益的可能性','something for nothing承接政策成本论证，不是劳动伦理指责。')],
'ch06-0081':[('不规则住房或土地','未纳入正式制度的住房或土地','irregular指非正式权属状态，不是几何形状。'),('房产价值往往上升','财产价值往往上升','包括土地，避免仅限房屋。'),('使其价值提高十倍','使其价值升至原来的十倍','factor of ten为最终倍数。')],
'ch06-0082':[('所有不规则财产的所有者','所有未纳入正式制度的财产的所有者','irregular property制度义。')],
'ch06-0085':[('我们一直在讨论的剥夺、主张、暴力、组织和抵抗的多种形式，其多样性和流动性，被想象为表达一个潜在原则，这个原则的名字叫资本主义。','剥夺、主张、暴力、组织和抵抗有多种形式，我们一直在讨论它们的多样性和流动性；这些形式被想象为表达着一个潜在原则，其名为资本主义。','被想象为表达原则的是诸种形式，不是其多样性这一属性。'),('资本托词的一部分','资本的托词的一部分','对齐书名术语。')],
'ch06-0087':[('《纽约时报》','{{I}}《纽约时报》{{/I}}','恢复报刊斜体。')],
'ch06-0088':[('该论文结论的证据表明，它们完全错了','用于支持该论文结论的证据却显示，这些结论完全错了','明确they指结论，保留作者批判归属。')],
'ch06-0090':[('提供手机或麦当劳餐厅等服务','提供移动电话通信或麦当劳餐饮等服务','mobile phones在此为服务特许经营，不是手机商品。'),('扩大规模就业','大规模增加就业','修复large-scale employment中文搭配。')],
'note-ch6-067':[('上述四项均引自 Field','上述四项均被 Field'),('〈Entitled to Work〉。另参见 Mitchell','〈Entitled to Work〉引用。另参见 Mitchell')],
'note-ch6-069':[('拥有地权者获得的贷款略多','拥有地权者获得的贷款金额略大','larger loans明确金额，不是笔数或获贷概率。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits:continue
 old=r['translation'];why=[]
 for item in edits[r['id']]:
  a,b=item[:2];c=item[2] if len(item)>2 else 'are cited in指被该文引用，不是本书转引自该文。'
  assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b);why.append(c)
 pat=r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}'
 assert re.findall(pat,old)==re.findall(pat,r['translation'])
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=why))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
ids=[f'ch06-{i:04}' for i in range(66,93) if i!=74]+[f'note-ch6-{i:03}' for i in range(63,85)]
e=dict(read_ids=ids,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',queries=['ch0067–68 source abolition2002 versus commonly cited1997 tenancy transition: verify authoritative historical source at chapter close','note067 Quarterly Journal Economics112 in2007 likely122; Torero/Torrero inconsistency; review publisher/author evidence','note071 Jean-Philippe Plateau likely Platteau; verify publisher','note074 pages1569–614 anomalous for12:1; verify publisher','note084 International Financial Corporation source name likely Finance Corporation; Chinese国际金融公司 already conventional, disclose source error if confirmed','ch0086 plain first-chapter reference to add precise link_text_to_unit only if consistent generator support','ch0075 Having to Lose title may mean having something to lose; decide after chapter close','ch0087 40percent finding and ch0088 rebuttal remain author claims, not independently verified study reanalysis'],next='ch06-0093 and note-ch6-085')
(p/'ch06_boundaries_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
cp=p.parents[2]/'工作文档'/'Alibi后续工作检查点.md';s=cp.read_text(encoding='utf-8')
entry='第六章财产边界及财富转移部分已校读：ch06-0066—0092（0074为空页位）及原注063—084共48单元，修订17单元；累计1428。修复过去时、土地使用权、授信资格、贷款申请批准率、贷款金额、引用方向及十倍基数；非正式权属不译几何不规则，恢复斜体。证据ch06_boundaries_revisions.json绑定哈希；review_ch06_boundaries.py一次性不重跑。章末新增租佃保障取消年份、期刊卷页、作者及IFC名称疑点；未据猜测改原作。**实际下一位置：ch06-0093及note-ch6-085**。第六章未章末核对，全书统检排版发布未开始。\n\n'
assert '## 授权与当前状态' in s
cp.write_text(s.replace('## 授权与当前状态',entry+'## 授权与当前状态',1),encoding='utf-8')
print(len(ids),len(revs),e['output_sha256'])
