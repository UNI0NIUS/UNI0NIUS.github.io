"""One-time growth/calculation semantic batch."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent;f=p/'translation_units.jsonl';raw=f.read_bytes();rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch05-0038':[('作为一种不受政府过程影响的可见机制运作','作为一种独立于治理过程的可见机制运作','independent不等于不受任何影响，government为治理过程。')],
'ch05-0039':[('它的定期报告将帮助经济发挥作用','它的定期报告将有助于使经济这一对象得以形成','bring into effect承接制造对象，而非让已有经济运行。')],
'ch05-0040':[('把未来带入政府','把未来带入治理','government治理义。')],
'ch05-0041':[('把信用创造引向消费而非投资的效果','把信用创造引向消费或投资这两种选择各自的效果','versus比较两种配置，不预先排除投资。')],
'ch05-0043':[('伦敦城一座建筑','伦敦金融城一座建筑','City of London专名。')],
'ch05-0045':[('把一个时间单位内产生的总量与下一个时间单位相比较','把一个时间单位内产生的总量与下一个时间单位的总量相比较','比较对象均为总量。'),('但与报告公司利润不同，计算 GDP 的人','但与报告公司利润的人不同，计算 GDP 的人','恢复人员比较。')],
'ch05-0046':[('可以指正在随经济的衡量而形成的新国家层面总量','可以指新的国家层面总量；对这些总量的计量，正在形成经济这一对象','whose measurement taking shape as economy被原译反转为随经济衡量形成总量。'),('并操纵这些数字来计算','并处理这些数字来计算','manipulating此处计算处理，不加数据造假贬义。')],
'ch05-0050':[('纪律和控制的工具','规训和控制的工具','discipline在治理论述中为规训。')],
'ch05-0051':[('《人口原理》','{{I}}《人口原理》{{/I}}','恢复书名斜体。')],
'ch05-0053':[('技术时代运作的一个阶段','技术时代运作的一个方面','one phase此处方面而非时间阶段。'),('在《公众及其问题》（1927）中','在{{I}}《公众及其问题》{{/I}}（1927）中','恢复书名斜体。'),('社会生活不安定不稳的症状','社会生活动荡不安的症状','修复重复残缺表达。')],
'ch05-0055':[('本世纪初，格奥尔格','二十世纪早期，格奥尔格','earlier in the century回指二十世纪，不应使读者理解为当前世纪。')],
'note-ch5-043':[('The Public and Its Problems: An Essay in Political Inquiry{{/I}}','The Public and Its Problems: An Essay in Political Inquiry: An Essay in Political Inquiry{{/I}}','底本重复副标题先照录；是否排印误重复以独立校注说明，不静默删原作书目。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits:continue
 old=r['translation'];why=[]
 for a,b,c in edits[r['id']]:
  assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b);why.append(c)
 pattern=r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}'
 assert re.findall(pattern,old)==re.findall(pattern,r['translation'])
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=why))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
ids=[f'ch05-{i:04}' for i in range(35,56)]+[f'note-ch5-{i:03}' for i in range(33,47)]
e=dict(read_ids=ids,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',queries=['note043 repeated subtitle in source restored; verify publisher and annotate at chapter end','ch05-0049 exponential curve near-vertical/infinity description is source qualitative account, depends on axes/time horizon; preserve not an independent mathematical proof','ch05-0051 Jevons prediction and1913peak source historical claim retained; bounded check if needed, no assumed resource depletion causality','ch05-0038 CEA outside government theoretical separation is explained0039 bypublicacademicvoice, not literal absence from executive; preserve author contrast','ch05-0044–0048 switches GNP/GDP in source; do not silently homogenise','ch05-0052 Koselleck otherness quote retained; reread alongside changing temporal scheme at chapter close'],next='ch05-0056 and note-ch5-047')
(p/'ch05_growth_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(len(ids),len(revs),e['output_sha256'])
