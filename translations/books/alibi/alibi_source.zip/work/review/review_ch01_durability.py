"""One-time review edits; chapter checks deferred to chapter completion."""
import json,hashlib
from pathlib import Path
p=Path(__file__).parent; f=p/'translation_units.jsonl'; raw=f.read_bytes()
rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch01-0021':[('更换周期延长三倍','更换周期增至原来的三倍','threefold 指变为三倍，与后文三年到十年对应。'),('钢轨测试机器和标准的制定','钢材测试设备的研制和测试标准的制定','steels 是钢材，并非仅钢轨；设备不能说制定。')],
'ch01-0024':[('大型投资者所有的商业公司','由投资者所有的大型商业公司','large 修饰公司，不修饰投资者。')],
'ch01-0026':[('并没有真正创造筹资支付它们的需要','所带来的，与其说是为支付建设费用而筹集资本的需要','not so much 是比较重点，不是否定确有资金需求。'),('政府允许阿斯旺大坝的主要推动者发行一种新货币','政府通过允许阿斯旺大坝的主要推动者发行一种新货币来支付大坝建设费用','补回 paid for 的融资用途关系。')],
'ch01-0032':[('欧洲缺乏足够有价值、可运回国内出售的商品','欧洲缺乏足够有价值、可作为交换而运往海外的商品','European goods shipped in return 为欧洲向贸易对方输出的回报商品，原译方向反了。')],
'ch01-0033':[('燃煤、钢铁建造、支配地形的基础设施','以碳燃料为动力、以钢铁建造、支配地形的基础设施','carbon-fuelled 范围宽于煤，不擅缩窄。')],
'note-ch1-021':[('并以证券作为付款','并收取证券作为对价','taking securities in payment 是发起人收取证券，不是支付。'),('股票通常被视为奖金','股票通常作为附赠权益','bonus 此处是发行时附赠股票，不是薪酬奖金。'),('关于发起人股份','关于供应商股份','vendor shares 与正文供应商股份对应，不等于发起人股份。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits: continue
 old=r['translation']; reasons=[]
 for a,b,why in edits[r['id']]:
  assert a in r['translation'],r['id']
  r['translation']=r['translation'].replace(a,b); reasons.append(why)
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=reasons))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
e=dict(read_ids=[f'ch01-{i:04}' for i in range(19,34)]+[f'note-ch1-{i:03}' for i in range(15,31)],revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',next='ch01-0034',queries=['note-ch1-023 Capturing Finance author Carolyn Adkins differs from introduction Hardin; verify publisher at chapter-end','note-ch1-020 Railroaded year 2007 requires chapter-end verification','ch01-0020 1906 conversion 100% retained; source statistical denominator not independently checked'])
(p/'ch01_durability_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(e['read_ids']),len(revs),e['output_sha256'])
