"""One-time closing edits and chapter data audit."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent; f=p/'translation_units.jsonl'; raw=f.read_bytes()
rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch01-0095':[('都注定会下降','都将下降','were set to 非宿命必然。'),('耐久物与流动物的组合','耐久性与流动性的组合','liquid 承接金融流动性，避免物理液体误解。')],
'ch01-0096':[('伴随这场大地冲击而来的非凡财富攫取的观点和思想','用来解释非凡财富攫取的观点和思想','暂时占位，下一步整句替换')]
}
# Replace complete sentence for accurate clause and page placement.
edits['ch01-0096']=[('经济学家和其他人用来解释伴随这场大地冲击而来的非凡财富攫取的观点和思想，也同时呈现出轻盈或转瞬即逝的性质。','经济学家和其他人用来解释伴随这场大地冲击而来的非凡财富攫取的观点和思想，也同时呈现出轻盈或转瞬即逝的性质。','保留原意')]
revs=[]
for r in rows:
 if r['id']=='ch01-0096':
  old=r['translation']; r['translation']=old.replace('伴随这场大地冲击而来的非凡财富攫取','非凡财富攫取——这种攫取{{P:54}}伴随着这场对大地的攻击——').replace('身上{{P:54}}。','身上。')
  revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=['将原书54页标从段末恢复到财富攫取/大地攻击的对应分句。']))
 elif r['id']=='ch01-0095':
  old=r['translation']
  for a,b,why in edits[r['id']]: assert a in r['translation']; r['translation']=r['translation'].replace(a,b)
  revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=[x[2] for x in edits[r['id']]]))
read=[f'ch01-{i:04}' for i in range(82,98)]+[f'note-ch1-{i:03}' for i in range(89,100)]
seen=set(read)
for name in ['opening','durability','property','cassel','interest']:
 seen.update(json.loads((p/f'ch01_{name}_revisions.json').read_text(encoding='utf-8'))['read_ids'])
chapter=[r for r in rows if (r['section']=='ch01' or r['id'].startswith('note-ch1-')) and r['status']=='translated']
assert {r['id'] for r in chapter}==seen
refs=[]; notes=[r['id'] for r in chapter if r['id'].startswith('note-ch1-')]
for r in chapter:
 refs+=re.findall(r'\{\{N:([^}]+)\}\}',r['translation'])
 pattern=r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}'
 assert re.findall(pattern,r['source_text'])==re.findall(pattern,r['translation']),r['id']
 r['review_status']='semantic_reviewed'; r['status_reason']='source/translation comparison completed; chapter structural checks passed; external queries recorded separately'
assert sorted(refs)==sorted(notes)
oldrows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
for a,b in zip(oldrows,rows):
 assert a['id']==b['id']
 for k in ['source_text','source_markup','source_refs','printed_pages','note_refs']: assert a.get(k)==b.get(k)
 if b not in chapter: assert a==b
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
e=dict(read_ids=read,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_reviewed_count=len(chapter),notes=len(notes),status='semantic_and_structure_review_passed_external_queries_pending',checks=['all chapter units read','references match definitions','structural token order','source fields unchanged','other chapters unchanged'],queries=['ch01-0089 switches sugar to cotton,0090 reverses direction in source: retain and add editorial explanation','note095/0091 spouse status versus marriage 1910: preserve author speculative identification','note099 yields translation may mean per-area yield: check cited context before change'],next='chapter1 queries and targeted reread')
(p/'ch01_close_evidence.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(chapter),len(notes),e['output_sha256'])
