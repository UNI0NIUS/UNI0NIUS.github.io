"""One-time first chapter-five query annotations."""
import json
from pathlib import Path
p=Path(__file__).parent;f=p/'editor_notes.json';d=json.loads(f.read_text(encoding='utf-8'))
new=[dict(id='ed-ch5-budget-bureau',unit_id='ch05-0011',text='校注：底本称预算局1939年从商务部转入总统行政办公室。美国财政部的机构史说明，预算局1921年设于财政部，1939年转入总统行政办公室；原文部门名有误，正文照录。',sources=['https://home.treasury.gov/about/history/history-overview/history-of-the-treasury'],source_locator='History of the Treasury中预算局沿革段，页面已打开'),dict(id='ed-ch5-development-author',unit_id='note-ch5-006',text='校注：底本把Amy L. S. Staples与Amy L. Sayward并列为作者，原注065亦沿用这一写法。苏黎世联邦理工学院图书馆所存题名页只署Amy L. S. Staples，不是两位作者合著。原注照录。',sources=['https://toc.library.ethz.ch/objects/pdf/z01_978-0-87338-849-8_01.pdf'],source_locator='PDF第1页题名页，已打开',limit='本注依据题名页确认单一署名，不延伸推断姓名变化的私人原因。'),dict(id='ed-ch5-breslau',unit_id='note-ch5-008',text='校注：底本将Breslau论文记为2020年、第79—411页。出版方书目列该文发表于2003年6月，《Theory and Society》第32卷，第379—411页。原注年月页码照录。',sources=['https://link.springer.com/article/10.1023/A:1024480118264'],source_locator='出版方文章首页及Cite this article，已打开')]
for n in new:n['verified_on']='2026-10-23'
assert not {n['id'] for n in new}&{n['id'] for n in d};d.extend(new);f.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
q=dict(status='in_progress',resolutions=[dict(unit_id=n['unit_id'],decision='editor_note',editor_note_id=n['id']) for n in new],canonical_changed=False,remaining='其余各批queries待汇总收束；本章重点回读、术语表更新、链接例外和note032文本指向仍需确认。')
(p/'ch05_query_resolution.json').write_text(json.dumps(q,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(len(d))
