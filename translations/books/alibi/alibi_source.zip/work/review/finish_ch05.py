"""One-time fifth-chapter final reconciliation."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent;f=p/'translation_units.jsonl';raw=f.read_bytes();rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch05-0011':[('经济的“错置的确定性”获得了更大的定义','经济的“错置的确定性”获得了范围更广的界定','definition在此为界定范围，不是定义大小。')],
'ch05-0052':[('可能无法反驳未来可能的他异性','未必能用来否定未来可能呈现的他异性','count against为构成反证，避免历史像行动者直接反驳。')],
'ch05-0066':[('策划了{{P:194}}一次前所未有的财富再分配','促成了{{P:194}}一次前所未有的财富再分配','engineered指实际促成而不止策划。'),('管道和曲线将协同运作','输油管线和图表线条将协同运作','graph lines泛指图表线条，上一段对数线为直线，不专指曲线。')],
'ch05-0079':[('1948 年两次法卢贾失败——伊拉克和巴勒斯坦——','1948 年发生在伊拉克费卢杰和巴勒斯坦法卢贾这两个同名之地的失败，','协调两地不同中文译名，同时保留原作同名关联。'),('欧洲定居者少数的建立','一个欧洲定居者少数群体的形成','补明少数群体而非少量定居点。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits:continue
 old=r['translation'];why=[]
 for a,b,c in edits[r['id']]:
  assert a in r['translation'];r['translation']=r['translation'].replace(a,b);why.append(c)
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=why))
oldrows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
for a,b in zip(oldrows,rows):
 assert {k:v for k,v in a.items() if k!='translation'}=={k:v for k,v in b.items() if k!='translation'}
 if a['id'] not in edits:assert a==b
 pattern=r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}'
 assert re.findall(pattern,a.get('translation',''))==re.findall(pattern,b.get('translation',''))
ch=[r for r in rows if (r['section']=='ch05' or r['id'].startswith('note-ch5-')) and r['status']=='translated']
assert len(ch)==167 and all(r['review_status']=='semantic_reviewed' for r in ch)
assert sorted(n for r in ch for n in re.findall(r'\{\{N:([^}]+)\}\}',r['translation']))==sorted(r['id'] for r in ch if r['id'].startswith('note-ch5-'))
assert not any('经济心态' in r['translation'] for r in ch)
o=p/'render_overrides.json';d=json.loads(o.read_text(encoding='utf-8'))
assert any(x['unit_id']=='note-ch5-067' and x['targets']==['16_Chapter08.xhtml'] for x in d['items'])
byid={r['id']:r for r in rows};assert '{{X:16_Chapter08.xhtml}}' in byid['note-ch5-067']['translation']
assert 'note 60' in byid['note-ch5-032']['source_text'] and '第 60 条注' in byid['note-ch5-032']['translation'] and 'Fālūja' in byid['note-ch5-060']['source_text']
assert not any(x['unit_id']=='note-ch5-032' for x in d['items'])
d['items'].append(dict(unit_id='note-ch5-032',action='link_text_to_unit',target_unit_id='note-ch5-060',source_text='note 60',translation_text='第 60 条注',reason='底本以普通文本引用本章原注60；输出保留可见文字并增加精确内部跳转，规范稿令牌与原注计数不变。'))
o.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
e=dict(status='chapter_closed_with_disclosed_source_limits',reread_ids=['ch05-0011','ch05-0020','ch05-0038','ch05-0052','ch05-0063','ch05-0066','ch05-0079','ch05-0082','ch05-0088','ch05-0094','note-ch5-032','note-ch5-060'],revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_units=167,notes=75,checks=['semantic coverage preserved','75 note references match definitions','other fields/units unchanged','structural tokens preserved','economentality aligned within chapter','Spycatcher erroneous link override confirmed','plain-text reference032to060 mapped; actual output link validation pending'],next='ch06-0001 and note-ch6-001')
(p/'ch05_final_evidence.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
f=p/'ch05_query_resolution.json';q=json.loads(f.read_text(encoding='utf-8'))
q['resolutions'] += [dict(unit_id='ch05-0031',decision='retain_source_date_reference',finding='0023的5月10日接管/禁令与原定11日罢工不同，0031的12日为罢工失败后次日可按原定罢工日理解；不强改成同一事件时点。'),dict(unit_id='note-ch5-004',decision='retain',finding='增长两倍多可表示总额超过三倍，与threefold相容。'),dict(unit_id='note-ch5-027',decision='retain',finding='其余部分由四家各占四分之一以剩余95%为分母，不是各占全公司25%。'),dict(unit_id='ch05-0066',decision='retain_author_argument_with_limit',finding='增长率平稳并不在数学上必然推出收入停滞；本段是作者对政治分配机制的论述，保留原句及自然地引号，不作为统计恒等式验证。'),dict(unit_id='note-ch5-032',decision='supplemental_render_link',finding='render_overrides.json精确映射本章注060；原稿保留。')]
q['retained_author_claims']=['劳工/油价/马歇尔计划因果、Jevons预测和1913峰值、原作1948冲突叙事与数字按作者归属保留，未进行全部档案或统计表审计。','指数图趋近垂直是受尺度与时段影响的定性叙述；0063用固定比例增长的对数图解释，未作实测经济数据复算。','GNP/GDP的切换保留原文；未把历史国民账户术语机械统一。','CEA排除经济学家的论断按0039学界专家与行政经济学家区别解释，不是机构不在行政体系的字面断言。','0082 first step避免把后续占领落为1955年2月已全数发生；0089 probably推测限定保留。','note060阿文标点规范化照初译，异体/重音及双向显示留最终视觉检查。']
q['status']='closed_with_disclosed_source_limits';q['remaining']=[];q['targeted_reread_evidence']='ch05_final_evidence.json';f.write_text(json.dumps(q,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
f=p/'term_decisions.json';d=json.loads(f.read_text(encoding='utf-8'));d['scope']='frontmatter/introduction/chapters1–5; later contextual review pending'
d['terms'] += [dict(en='economentality',zh='经济治理术',note='第五章0020由governmentality定义；本章所有旧译经济心态已替换，全书其他引用与生成目录待集中统检。'),dict(en='governmentality',zh='治理术',note='对应economentality造词关系；government表示过程时用治理，机构时用政府。'),dict(en='sterling credits',zh='英镑债权余额',note='第五章埃及持有于伦敦的外汇债权，不是新发放给埃及的贷款。'),dict(en='Falluja / Faluja',zh='费卢杰／法卢贾',note='第五章分别指伊拉克和巴勒斯坦地点；保留作者同名关联及注060拼写区别。')]
f.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(e['output_sha256'],len(revs))
