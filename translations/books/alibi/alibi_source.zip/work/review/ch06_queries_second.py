"""One-time chapter-six names and chronology evidence."""
import json
from pathlib import Path
p=Path(__file__).parent;f=p/'editor_notes.json';d=json.loads(f.read_text(encoding='utf-8'))
data=[
('stedman','note-ch6-002','底本姓名作Daniel Steadman Jones。出版社的《Masters of the Universe》书籍页署名Daniel Stedman Jones；原注照录。此人为Daniel，不能与第四章的Gareth Stedman Jones混同。','https://academic.oup.com/princeton-scholarship-online/book/18096','出版社书籍页署名，已打开；该页面为2014版，仅用于核对姓名，不据此否定原注2012初版年。'),
('ons','note-ch6-050','底本机构名称作Office on National Statistics；英国国家统计局官方名称为Office for National Statistics。原注英文照录。','https://www.ons.gov.uk/aboutus','机构官方网站About us及页面标题，已打开。'),
('platteau','note-ch6-071','底本作者姓氏作Plateau；所引文章出版方页面署名Jean-Philippe Platteau。原注照录。','https://onlinelibrary.wiley.com/doi/10.1111/j.1467-7660.1996.tb00578.x','Wiley文章作者栏，已打开。'),
('ifc','note-ch6-084','底本作International Financial Corporation；世界银行集团所列机构名称为International Finance Corporation（IFC），即国际金融公司。中文采用通行机构名，英文底本保留原貌。','https://www.worldbank.org/en/about/annual-report/ifc?dropid=risk','世界银行官方IFC页面标题和正文名称，已打开；只核机构名称，未据此核实2004年投资细节。'),
('tenancy-date','ch06-0067','本段及下段将农地租佃保障取消记为2002年。Reem Saad在英国学术院发表的1992年租佃法研究指出，1992年第96号法给予地主在五年过渡期后驱逐佃户的权利，过渡期于1997年结束。底本年份与该法时间表不符；正文照录。','https://www.thebritishacademy.ac.uk/documents/3888/96p387.pdf','Reem Saad论文首页，书内第387页，已打开。此证据支持1997年过渡期结束，不等于断言所有地区所有形式保障同日消失。'),
('thinktank-date','note-ch6-012','底本将〈The Good Think Tank Guide〉日期列为1991年10月21日。胡佛研究所官方年表引用同题报道时列为1991年12月21日，第49页起；底本月份疑有误。原注照录。','https://www.hoover.org/about/hoover-story/timeline','官方年表1991年条目及来源说明，已打开；未取得《经济学人》原刊，故标疑，不声称原刊直接验证。'),
('torero','note-ch6-067','本注先署Maximo Torero，后又作Maximo Torrero。联合国粮农组织本人简介署名Máximo Torero，支持姓氏为Torero。原注两种写法照录。','https://www.fao.org/about/leadership/Torero','粮农组织个人简介署名，已打开；未取得1999年报告题名页，本注只核常用姓名，不声称报告原版署名已查。')]
new=[dict(id='ed-ch6-'+a,unit_id=b,text='校注：'+c,sources=[u],source_locator=l,verified_on='2026-10-23') for a,b,c,u,l in data]
assert not {n['id'] for n in new}&{n['id'] for n in d};d.extend(new)
f.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
qf=p/'ch06_query_resolution.json';q=json.loads(qf.read_text(encoding='utf-8'));q['resolutions'].extend(dict(unit_id=n['unit_id'],decision='editor_note',editor_note_id=n['id']) for n in new)
q['remaining']='剩余：注004姓名转写、注008姓名顺序、注020信件、注041同上、1874萧条及1971高坝时间口径；术语/标题、链接例外和重点回读。'
qf.write_text(json.dumps(q,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
cp=p.parents[2]/'工作文档'/'Alibi后续工作检查点.md';s=cp.read_text(encoding='utf-8')
entry='第六章第二批疑点已处理：Daniel Stedman Jones、ONS、Platteau、IFC、租佃法过渡期、智库报道日期及Torero姓名新增7条独立校注，现54条。出版社/机构页及Saad论文已打开；智库日期为机构引用原刊、Torero仅核本人姓名，限度写入校注。租佃法1997过渡期结束与底本2002不符，保留正文并注释，不扩大为所有保障统一消失的断言。ch06_queries_second.py一次性不重跑；规范稿未变。**实际下一位置：第六章剩余时间口径/同上指向疑点、术语标题及重点回读**。\n\n'
assert '## 授权与当前状态' in s;cp.write_text(s.replace('## 授权与当前状态',entry+'## 授权与当前状态',1),encoding='utf-8');print(len(d))
