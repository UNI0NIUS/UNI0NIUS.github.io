"""One-time chapter closing read and coverage audit."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent;f=p/'translation_units.jsonl';raw=f.read_bytes();rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={'ch05-0091':[('成本必须计算未来','成本核算必须把未来纳入计算','成本本身不执行计算。')],'ch05-0092':[('十五年以上贷款偿还期内','十五年或更长的贷款偿还期内','fifteen or more包含十五年，明确边界。')],'ch05-0093':[('经济不仅是政府的新对象，而且是一种效果','经济不只是治理的新对象，更是一种效果','government治理义，rather保留转向。')],'ch05-0094':[('西方战后经济心态','西方战后的经济治理术','与本章定义协调。')],'ch05-0095':[('一个不同的未来进入了政府','一个不同的未来进入了治理','与标题及全章概念一致。')]}
revs=[]
for r in rows:
 if r['id'] not in edits:continue
 old=r['translation'];why=[]
 for a,b,c in edits[r['id']]:
  assert a in r['translation'];r['translation']=r['translation'].replace(a,b);why.append(c)
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=why))
read=[f'ch05-{i:04}' for i in range(91,96)];seen=set(read)
for name in ['opening','energy','growth','future','egypt']:seen.update(json.loads((p/f'ch05_{name}_revisions.json').read_text(encoding='utf-8'))['read_ids'])
chapter=[r for r in rows if (r['section']=='ch05' or r['id'].startswith('note-ch5-')) and r['status']=='translated']
assert {r['id'] for r in chapter}==seen,({r['id'] for r in chapter}-seen,seen-{r['id'] for r in chapter})
refs=[];notes=[r['id'] for r in chapter if r['id'].startswith('note-ch5-')]
for r in chapter:
 refs+=re.findall(r'\{\{N:([^}]+)\}\}',r['translation'])
 pattern=r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}'
 assert re.findall(pattern,r['source_text'])==re.findall(pattern,r['translation']),r['id']
 r['review_status']='semantic_reviewed';r['status_reason']='source/translation comparison completed; chapter structural checks passed; external queries recorded separately'
assert sorted(refs)==sorted(notes)
oldrows=[json.loads(x) for x in raw.decode('utf-8').splitlines()];chapterids={r['id'] for r in chapter}
for a,b in zip(oldrows,rows):
 assert a['id']==b['id']
 for k in ['source_text','source_markup','source_refs','printed_pages','note_refs','page_start','page_end']:assert a.get(k)==b.get(k)
 if b['id'] not in chapterids:assert a==b
assert not any('经济心态' in r['translation'] for r in chapter)
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
e=dict(read_ids=read,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_reviewed_count=len(chapter),notes=len(notes),status='semantic_and_structure_review_passed_external_queries_pending',checks=['all chapter translated units read','75 note references match definitions','structural token order','source fields unchanged','other chapters unchanged','economentality no unreviewed old Chinese term left in chapter'],queries=['chapter-end resolve previous batches queries and reread key paragraphs','note032 textual reference to note060 lacks source token; decide exact supplemental link for all renderers','note067 wrong external-book reference override must be checked before export'],next='chapter5 query resolution, terminology reconciliation and targeted reread')
(p/'ch05_close_evidence.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(len(chapter),len(notes),e['output_sha256'])
