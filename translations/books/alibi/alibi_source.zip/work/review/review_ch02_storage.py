"""One-time corrections; do not regenerate from this file."""
import json,hashlib
from pathlib import Path
p=Path(__file__).parent; f=p/'translation_units.jsonl'; raw=f.read_bytes()
rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch02-0037':[('这个自行移动的洪水和施肥过程','这一自行运转的泛滥与增肥过程','self-moving 指过程自行运行，非过程位置移动。'),('从而产生全年从运河提水的繁重劳动和费用，以及机械施肥的需求','使全年从运河提水和机械施肥都需要繁重劳动和高昂费用','heavy labour and expense 修饰提水与施肥两项。')],
'ch02-0038':[('这种自行移动的肥力','这种自然发生的肥力补充','enrichment 是增肥过程。'),('在陆地和水中繁殖生命的相互作用','维系陆地与水中生命繁衍的相互作用','reproduce life 此处含生态系统维系。'),('曾经流行','为地方性流行病','endemic 不仅指曾经流行。')],
'ch02-0040':[('蜗牛和线虫','螺类和线虫','snails 在运河血吸虫语境为螺类。'),('棉铃虫——一种蛾','棉叶虫——一种蛾','原文明确Spodoptera littoralis，EPPO通称cotton leafworm，不误归棉铃虫。'),('受感染的叶子','受虫害的叶子','此处为幼虫危害，不是微生物感染。')],
'ch02-0041':[('盆地灌溉','围堤蓄水灌溉','沿用本章术语。'),('农民“的洪水没有任何工程师能够截断，他们便利水位上充沛的底土水是自己的财产”，他们享有显著的独立与繁荣。','这些农民享有显著的独立与繁荣：“没有任何工程师能够截断他们的洪水，而水位便于利用的充沛地下水则是他们自己的财产。”','恢复关系从句完整中文句法，便利修饰取水水位。')],
'ch02-0043':[('“{{I}}saqiya{{/I}}环”','“{{I}}saqiya{{/I}}合作圈”','ring 指合作群体，非机械环。'),('参加不止一个环','参加不止一个合作圈','同上。'),('然后带着堆满高粱穗的空盘子回来','然后把吃空的盘子装满高粱穗送回','returning plates 是归还盘子，不是人带空盘回来。')],
'ch02-0044':[('官员建立大型农业庄园的第一批命令就是确保牛只和“竖立水车”','发给负责建立大型农业庄园的官员的首批命令就是取得牛只并“架设水车”','命令接收者是官员，secure指确保取得资源。'),('然而，它的使用越来越局限于','然而，这些提水装置的使用越来越局限于','their 包括逐步取代水车的泵，不只旧水车。')],
'ch02-0047':[('它们所促成的生命形式','它们所促成的生活方式','modes of life 在生态及储存经济中指生活方式，不是生物类型。')],
'note-ch2-059':[('人类与超人类历史叙述','涵盖人类及人类之外生命的历史叙述','more-than-human 非超人或超自然。')],
'note-ch2-064':[('凤眼蓝如今','水葫芦（凤眼蓝）如今','与正文同物异名建立明确对应。')],
'note-ch2-066':[('占耕地面积','占作物种植面积','cropped area 指实际种植面积，不是全部耕地面积。')],
'note-ch2-075':[('187，转引自','187，其中引述','citing主语为Sato，不颠倒引述关系。')],
'note-ch2-080':[('当地人宁愿井灌而反对开挖运河方案的偏好','当地人相较于开挖运河方案更偏好井灌','preference 不足以断定反对。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits: continue
 old=r['translation']; reasons=[]
 for a,b,why in edits[r['id']]:
  assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b); reasons.append(why)
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=reasons))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
ids=[r['id'] for r in rows if r.get('translation') and (('ch02-0037'<=r['id']<='ch02-0047') or ('note-ch2-059'<=r['id']<='note-ch2-088'))]
e=dict(read_ids=ids,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',next='ch02-0048',external_evidence=[dict(unit='ch02-0040',url='https://gd.eppo.int/taxon/SPODLI/datasheet',finding='EPPO names S. littoralis Egyptian cotton leafworm/cotton worm; translation rendered descriptively as 棉叶虫 with source scientific name retained',access='publisher search metadata, not full datasheet read')],queries=['ch02-0044 GERD completed in 2020 is source wording; verify construction versus filling chronology at chapter end, preserve for now','ch02-0040 source medical and dietary claims preserved as author argument, not independent clinical review','ch02-0042 only domesticated insect besides honeybee is source categorical assertion; retained, no independent zoological validation'])
(p/'ch02_storage_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(ids),len(revs),e['output_sha256'])
