"""One-time chapter-seven opening source/translation batch."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent;f=p/'translation_units.jsonl';raw=f.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='003d0c834a431fca0a53c572a1e418b6b7beaf428fd12e778d913cc972796d4b'
rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch07-0006':[('都能缩短输送一定数量线路所载物资所需的时间','都可能缩短输送一定数量线路所载物资所需的时间','can为能力/可能性，不断言每次改进必然缩短。')],
'ch07-0008':[('价格上涨被假定为衡量福利增加','价格上涨被假定为福利增加的衡量指标','补足谓语关系。'),('这些研究对基础设施发展所依赖的经济化工作有所贡献，其{{P:241}}中一项研究的引人注目之处，既在于衡量铁路对价格影响的高超技巧，也在于它无视其他被广泛研究、却难以通过价格衡量的建设后果','这类研究有助于基础设施发展所依赖的经济化工作，其{{P:241}}引人注目之处，既在于衡量铁路对价格影响的高超技巧，也在于对其他被广泛研究、却难以通过价格衡量的建设后果的漠视','such research指这类研究，不限其中一篇。')],
'ch07-0009':[('印度河流域也是如此','印度各河流域也是如此','river basins of India不是专名Indus basin，恢复地理范围。')],
'ch07-0010':[('而且它们这样做不仅以我们通常想象的方式，还是资本化工作的一部分','这种延迟不仅以我们通常想象的方式发生，也构成资本化工作的一部分','修复不仅方式/还是部分搭配。')],
'ch07-0011':[('而享受局部循环的流动则利用更广泛的连接','而原先仅在本地范围内进行的流动，则开始利用更广泛的连接','enjoyed a local circulation指原来的流动范围。')],
'ch07-0012':[('长期超支是常态','工期大幅超期是常态','long overruns承接完工延迟，不能把时间超期误作预算超支。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits:continue
 old=r['translation'];why=[]
 for a,b,c in edits[r['id']]:
  assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b);why.append(c)
 pat=r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}'
 assert re.findall(pat,old)==re.findall(pat,r['translation'])
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=why))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
ids=[f'ch07-{i:04}' for i in range(2,16) if i!=13]+[f'note-ch7-{i:03}' for i in range(1,16)]
e=dict(read_ids=ids,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',queries=['ch0015 Richard Wright/note015 Wright versus note006 Richard White Railroaded: verify same book author at chapter close and annotate source error','note006 QJE101:7 year2016 likely131:2; verify publisher','ch0008 Clark award description and scholarship critique remain author interpretation; verify author/award identification if needed, not full welfare reanalysis','ch0009 snails/nematodes carrying diseases source loose wording; preserve source claims rather than medical correction in translation','ch0011 doubling canal stretch,deadweight210000->240000 and2015 timing scope to check at chapter end; grounding bank-effect may preserved','note002 Bowker53:4 pages563–76 and note014 handbook2013 may edition issues; verify if reliable metadata obtainable','ch0015 move paper financial-context metaphor to reread after following paragraphs'],next='ch07-0016 and note-ch7-016')
(p/'ch07_opening_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
cp=p.parents[2]/'工作文档'/'Alibi后续工作检查点.md';s=cp.read_text(encoding='utf-8');entry='第七章开头已校读：ch07-0002—0015（0013为空页位）及原注001—015共28有效单元，修订6单元；累计1484。修复工期超期误作超支、印度各河流域误作印度河、这类研究误限一篇、可能性限定及语法。证据ch07_opening_revisions.json绑定哈希；review_ch07_opening.py一次性不重跑。章末待核Wright/White、QJE卷期、运河扩建口径及书目版年；原作论断未据猜测改写。**实际下一位置：ch07-0016及note-ch7-016**。第七章未完成，全书统检排版发布未开始。\n\n';assert '## 授权与当前状态' in s;cp.write_text(s.replace('## 授权与当前状态',entry+'## 授权与当前状态',1),encoding='utf-8');print(len(ids),len(revs),e['output_sha256'])
