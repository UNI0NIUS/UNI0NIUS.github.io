"""One-time chapter-seven closing read and coverage audit."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent;f=p/'translation_units.jsonl';raw=f.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='bab5c11f640795f502de86257d58b965acc12ccdde321225f9a2c18c11171c8e'
rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch07-0053':[('可以迅速启动的权利','可以迅速进入流通的权利','put in motion对应下一句所有权转让，不是启动法律权利。')],
'ch07-0057':[('十九世纪后期伟大的碳燃料基础设施项目帮助创造了现代商业银行，其组织者利用新基础设施耐久性所便利的流动性和信用机制。','十九世纪后期的大型碳燃料基础设施项目，帮助促成了现代商业银行业的形成；商业银行负责组织由新基础设施耐久性所促成的流动性和信用机制。','as organisers指商业银行组织机制，不是基础设施项目的组织者利用机制；great为规模宏大。')],
'ch07-0060':[('被拖欠工资或退休金者','享有工资或退休金债权者','owed未必逾期拖欠，表达应付款项主张。')],
'ch07-0069':[('我们所设想的人类创世需要大量非人要素','我们所设想的人类建构世界的活动，需要大量非人要素','world-making与0021一致，避免宗教创世义。')],
'ch07-0071':[('我们的生活方式是对后来者的威胁，不仅是我们不顾后果地开发地球资源所带来的副产品，而且是一种建立在从未来夺取生计之上的生活方式。','我们的生活方式威胁着后来者，这不仅是我们不顾后果地开发地球资源所造成的副产品，更因为这种生活方式本就建立在从未来夺取生计之上。','明确副产品指威胁而非生活方式，恢复not just...but as因果论证。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits:continue
 old=r['translation'];why=[]
 for a,b,c in edits[r['id']]:
  assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b);why.append(c)
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=why))
read=[f'ch07-{i:04}' for i in range(51,72)]+[f'note-ch7-{i:03}' for i in range(44,51)];seen=set(read)
for name in ['opening','finance','durability']:seen.update(json.loads((p/f'ch07_{name}_revisions.json').read_text(encoding='utf-8'))['read_ids'])
chapter=[r for r in rows if (r['section']=='ch07' or r['id'].startswith('note-ch7-')) and r['status']=='translated'];chapterids={r['id'] for r in chapter}
assert chapterids==seen,(chapterids-seen,seen-chapterids)
refs=[];notes=[]
for r in chapter:
 pat=r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}'
 assert re.findall(pat,r['source_text'])==re.findall(pat,r['translation']),r['id']
 refs+=re.findall(r'\{\{N:([^}]+)\}\}',r['translation'])
 if r['id'].startswith('note-ch7-'):notes.append(r['id'])
 r['review_status']='semantic_reviewed';r['status_reason']='source/translation comparison completed; chapter structural checks passed; external queries recorded separately'
assert sorted(refs)==sorted(notes)
for a,b in zip([json.loads(x) for x in raw.decode('utf-8').splitlines()],rows):
 assert a['id']==b['id']
 for k in ['source_text','source_markup','source_refs','printed_pages','note_refs','page_start','page_end']:assert a.get(k)==b.get(k)
 if b['id'] not in chapterids:assert a==b
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
e=dict(read_ids=read,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_reviewed_count=len(chapter),notes=len(notes),status='semantic_and_structure_review_passed_external_queries_pending',checks=['all translated units read','50 note references match definitions','structural token order','source fields preserved','other chapters unchanged'],queries=['resolve accumulated queries; then targeted reread and terminology','The Liquid title液态 versus financial流动性 to reconcile with durable/liquid material metaphor','country banks乡村银行 more properly地方银行 contextual British banking; reread0056 at close','extrastatecraft国家外技艺 needs careful consistent term with sourcemeaning','book finalchapter remains unread; crosschapter terms cannot claim finished'],next='chapter7 query resolution, terminology and targeted reread')
(p/'ch07_close_evidence.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
cp=p.parents[2]/'工作文档'/'Alibi后续工作检查点.md';s=cp.read_text(encoding='utf-8');entry='第七章全章源译校读完成：末批ch07-0051—0071及原注044—050共28单元，修订5单元；全章69正文/标题与50原注共119单元，已读覆盖、50引用/定义、结构令牌、源字段及其他章节保留检查通过。累计1575有效单元。修复银行组织者关系、应付工资误作拖欠、world-making及结尾因果主语。证据ch07_close_evidence.json；review_ch07_close.py一次性不重跑；规范稿SHA256 '+e['output_sha256']+'。**实际下一位置：第七章疑点核查、术语协调和重点回读**。第八章及全书统检、排版、发布仍未完成。\n\n';assert '## 授权与当前状态' in s;cp.write_text(s.replace('## 授权与当前状态',entry+'## 授权与当前状态',1),encoding='utf-8');print(len(read),len(revs),len(chapter),len(notes),e['output_sha256'])
