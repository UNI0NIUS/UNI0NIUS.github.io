"""One-time query evidence and editorial annotations."""
import json
from pathlib import Path
p=Path(__file__).parent;f=p/'editor_notes.json';d=json.loads(f.read_text(encoding='utf-8'))
new=[
dict(id='ed-ch4-whately',unit_id='ch04-0021',text='校注：底本记惠特利于1831年当选牛津政治经济学教席。埃默里大学Pitts神学图书馆所藏惠特利书信的传记说明记为1829年当选、1831年离任。正文年份照录。',sources=['https://dia.pitts.emory.edu/archives/text/mss102.html'],source_locator='Biographical Note，已打开'),
dict(id='ed-ch4-marx-quotation',unit_id='ch04-0064',text='校注：正文把两段赞语连用于合作所有制，但原注067所引全文中，“不仅是一个伟大的实践成就”指十小时法案；后面的劳动政治经济学对财产政治经济学的胜利才转指合作运动。正文保留原作引述方式，请与原注合读。',sources=[],source_locator='本书ch04-0064与note-ch4-067源文内部对照'),
dict(id='ed-ch4-railway-ratio',unit_id='ch04-0081',text='校注：按本段所列数额计算，11,250,000÷4,868,428约为2.31，与引文的“两倍半”不符。数额与引文均按底本保留。',sources=[],source_locator='本书ch04-0081源文数额复算',limit='仅核对本书所列数值之间的比例，未独立审计铁路原始账簿。'),
dict(id='ed-ch4-mill-reference',unit_id='ch04-0056',text='校注：正文此处以《政治经济学原理》为例，但紧随引句的原注060所列出处为〈论政治经济学的定义〉第138页。书名与注中出处不一致，均保留原作。',sources=[],source_locator='本书ch04-0056与note-ch4-060源文内部对照',limit='指出书内引注差异，未凭此认定引句不见于其他著作。')]
for n in new:n['verified_on']='2026-10-23'
assert not {x['id'] for x in new}&{x['id'] for x in d};d.extend(new);f.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
f=p/'ch04_query_resolution.json';q=json.loads(f.read_text(encoding='utf-8'))
q['resolutions'] += [dict(unit_id=n['unit_id'],decision='editor_note',editor_note_id=n['id']) for n in new]
q['resolutions'] += [
dict(unit_id='note-ch4-032',decision='retain_with_evidence_limit',finding='机构库PDF检索元数据分别显示卷期年2025及首次网上发表24 Apr 2024，原注2024可能采用线上发表年；不改原注。',sources=['https://umu.diva-portal.org/smash/get/diva2%3A1854250/FULLTEXT02.pdf','https://www.tandfonline.com/doi/full/10.1080/01916599.2024.2343530'],limit='PDF两次直接打开超时，出版方403；仅用检索元数据，不声称全文核查。'),
dict(unit_id='ch04-0025',decision='retain_with_evidence_limit',finding='剑桥大学图书馆特藏介绍支持Burckhardt皈依伊斯兰教；其行旅与Drummond的具体资助关系未由此次材料确认，保留作者原说。',sources=['https://specialcollections-blog.lib.cam.ac.uk/?p=2126'],evidence='特藏文章已打开',limit='非完整传记核查；不以未找到证据推断资助不存在。'),
dict(unit_id='note-ch4-079',decision='retain_with_evidence_limit',finding='查得1904原版记录，未核定原作1905是否另次印本，保留所引版年。',sources=['https://agso.uni-graz.at/archive/lexikon/klassiker/veblen/47bib.htm'],limit='大学书目检索元数据；未读取1905题名页，不判错误。'),
dict(unit_id='note-ch4-095',decision='pending_bounded_check',finding='Liberty Fund所载Smart译本明确采用London Macmillan1891版；尚不能仅据这一版本排除1888版，继续核对题名/译者序年份。',sources=['https://oll-resources.s3.us-east-2.amazonaws.com/oll3/store/titles/283/Boehm-Bawerk_0183_EBk_v6.0.pdf'],evidence='PDF第2页Edition Used已打开')]
q['remaining']='note095译本年份、note064卷册口径和note111同上归属仍待收束；随后本章重点回读、术语协调及输出例外确认。'
f.write_text(json.dumps(q,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(len(d),11250000/4868428)
