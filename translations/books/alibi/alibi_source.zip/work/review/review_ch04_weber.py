"""One-time semantic batch; never rerun after subsequent edits."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent;f=p/'translation_units.jsonl';raw=f.read_bytes();rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch04-0083':[('成为一个知识和规范的对象','成为知识与规制的对象','regulation为规制而非规范。')],
'ch04-0084':[('他后来写了《看得见的手》','他后来写了{{I}}《看得见的手》{{/I}}','恢复书名强调。')],
'ch04-0085':[('《看得见的手》则主张','{{I}}《看得见的手》{{/I}}则主张','恢复书名强调。')],
'ch04-0086':[('经济将（不再）意味着经济化','经济将（不再）意味着经济化（economising）','为下文区分economising与economisation保留英文关键词。')],
'ch04-0087':[('在“经济”诞生之前，让我们转向关于“经济”历史的最后一个问题。','在结束讨论之前，让我们提出有关“经济”（economy）在“这个经济整体”（the economy）诞生之前那段历史的最后一个问题。','before修饰所讨论历史，不是作者转向问题的时间；区分对象义。'),('这些危机开始威胁资本化过程所依赖的未来本身的生产','这些危机开始威胁未来本身，而资本化过程正有赖于这种未来的生产','保留危机直接威胁未来、资本化依赖其生产的关系。'),('回应就是发明{{I}}经济{{/I}}','回应就是发明“{{I}}这个{{/I}}经济整体”（the economy）','the强调整体对象，协调本章。')],
'ch04-0088':[('德国学者急于把其研究领域界定为','德国学者对将其研究领域界定为','concern不添急迫。'),('“社会经济”（{{I}}Sozialökonomik{{/I}}）。','“社会经济学”（{{I}}Sozialökonomik{{/I}}）的关切。','此处学科研究领域。')],
'ch04-0089':[('他的代表作《经济与社会》1922','他的代表作{{I}}《经济与社会》{{/I}}1922','恢复书名强调。')],
'ch04-0090':[('“经济化”一词需要','“经济化”（economising）一词需要','标出与下一段economisation区分的词。'),('的《资本实证论》时','的{{I}}《资本实证论》{{/I}}时','恢复书名强调。')],
'ch04-0092':[('“经济化”也意味着节俭或吝啬','“economising”一词也使人想到节俭或吝啬','讨论英语词的联想，避免断言中文经济化意味着节俭；suggests非等同。')],
'ch04-0093':[('在经济化的意义上，“经济化”一词','在 economisation（经济化）的意义上，economising 一词','避免两个不同英文词同译后论证不可辨。'),('作为对象的{{I}}经济{{/I}}','作为对象的“{{I}}这个{{/I}}经济整体”（the economy）','协调强调与对象义。')],
'note-ch4-096':[('“economic action”（经济活动）','“economic action”（经济行动）','对应经济行动者与韦伯行动概念。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits:continue
 old=r['translation'];why=[]
 for a,b,c in edits[r['id']]:
  assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b);why.append(c)
 pattern=r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}'
 assert re.findall(pattern,old)==re.findall(pattern,r['translation'])
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=why))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
ids=[f'ch04-{i:04}' for i in range(83,94)]+[f'note-ch4-{i:03}' for i in range(84,98)]
e=dict(read_ids=ids,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',queries=['ch04-0089 cross-reference is Weber chapter2, not Alibi; exact render override added, verify at chapter end','note090 Producing India2010 and note095 Positive Theory1888 may be edition years; bounded bibliography check at close','economising/economisation distinct English terminology kept visible where Chinese conflates; chapter-end read across0086–0093 and following paragraphs'],next='ch04-0094 and note-ch4-098')
(p/'ch04_weber_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
o=p/'render_overrides.json';d=json.loads(o.read_text(encoding='utf-8'));assert not any(x['unit_id']=='ch04-0089' for x in d['items'])
d['items'].append(dict(unit_id='ch04-0089',action='render_cross_reference_as_plain_text',targets=['10_Chapter02.xhtml'],reason='此处明确引用韦伯《经济与社会》第二章，底本误链本书第二章；输出保留可见文字，移除误导跳转。'))
o.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(ids),len(revs),e['output_sha256'])
