"""One-time chapter3 close; source limitations remain expressly documented."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent;f=p/'translation_units.jsonl';raw=f.read_bytes()
rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={'ch03-0025':('通过可靠执行手段向前偿付的债务','以可靠的强制执行手段确保在未来偿付的债务','根据前句未来债务语境消除向前的时间歧义。'),'ch03-0048':('这种机械式转用','这种借助机器的绕道','machinic不是机械僵化的方式，连接制造业绕道。'),'ch03-0076':('“支付”工人工资时拖欠一个月','在工人劳动一个月后才“支付”工资','in arrears说明后付关系，不额外断言逾期违约。'),'ch03-0084':('城市业务','城市与商业','本节并列讨论商业公司与城市两个资本化场所，避免误读为市政事务。')}
revs=[]
for r in rows:
 if r['id'] not in edits:continue
 a,b,why=edits[r['id']];old=r['translation'];assert a in old
 r['translation']=old.replace(a,b)
 assert re.findall(r'\{\{.*?\}\}',old)==re.findall(r'\{\{.*?\}\}',r['translation'])
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reason=why))
notes=json.loads((p/'editor_notes.json').read_text(encoding='utf-8'))
new=[
dict(id='ed-ch3-grossbetrieb',unit_id='ch03-0037',text='校注：底本德语拼作Grossbetreib；《杜登》所列“大企业”一词为Großbetrieb，词尾应为betrieb而非betreib。正文底本拼写照录。',sources=['https://www.duden.de/rechtschreibung/Groszbetrieb'],limit='词典已打开；未核对本注所引历史文献中的原始引文。'),
dict(id='ed-ch3-macleod-edition',unit_id='note-ch3-150',text='校注：底本将第6版与1855—1856年并列。伦敦城市大学收录的银行史研究书目区分1855年原版与1902年第6版，故本注版本和年代搭配疑有混淆。原注照录。',sources=['https://openaccess.city.ac.uk/id/eprint/8350/1/The_development_of_the_role_of_the_Bank_of_England_as_a_Lender_of_Last_Resort%2C_1870-1914.pdf'],limit='依据机构库PDF的检索摘录；直接读取因文件超过工具大小限制失败，未查得原书第6版题名页，故标疑而不替换。'),
dict(id='ed-ch3-saudi-chronology',unit_id='ch03-0054',text='校注：本段将迪里耶政权的扩张合并叙述在穆罕默德·本·沙特治下。Saudipedia记其统治止于1765年，并将此后跨半岛扩张分别置于继任者阿卜杜勒阿齐兹及沙特治下，故此处不宜理解为所列扩张均由创立者在世时完成。正文保留原作概述。',sources=['https://saudipedia.com/en/first-saudi-state'],limit='已打开历任统治者部分；仅提示合并叙述，不据此断言麦加控制权变动的具体日期。'),
dict(id='ed-ch3-time-labour',unit_id='ch03-0080',text='校注：底本此处确作“时间与劳动的直接交换”（a direct exchange of time for labour），与本章其他地方的工资与劳动交换表述有异。译文照录，未擅自将time改为money。',sources=[],source_locator='本书ch03-0080及ch03-0083、ch03-0071源文')
]
for n in new:
 assert not any(z['id']==n['id'] for z in notes); n['verified_on']='2026-10-23'
notes+=new
(p/'editor_notes.json').write_text(json.dumps(notes,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
t=json.loads((p/'term_decisions.json').read_text(encoding='utf-8'));t['scope']='frontmatter/introduction/chapters1–3; later contextual review pending'
t['terms'] += [dict(en='fabrication',zh='制造／虚构／建构',note='第三章保留先虚构后积极建构的转折，不全章机械替换。'),dict(en='small money',zh='小额货币',note='包括硬币、纸币与凭券等用于小额支付的货币。'),dict(en='business',zh='商业',note='第三章特指现代股份公司和投资银行共同兴起的现象，不当作商品贸易的同义词；City Business小节译城市与商业。'),dict(en='Provincialising Manchester',zh='使曼彻斯特地方化',note='保留标题，指将其置回全球关系中的地方位置，非改行政区划。'),dict(en='Money Is No Object',zh='货币不是实物',note='按本章货币不是物件而是信用关系取意；英语惯用语的双关未强塞入标题。')]
(p/'term_decisions.json').write_text(json.dumps(t,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
oldrows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
for a,b in zip(oldrows,rows):
 assert {k:v for k,v in a.items() if k!='translation'}=={k:v for k,v in b.items() if k!='translation'}
 if b['id'] not in edits:assert a==b
chapter=[r for r in rows if (r['section']=='ch03' or r['id'].startswith('note-ch3-')) and r['status']=='translated']
assert len(chapter)==264
refs=[n for r in chapter for n in re.findall(r'\{\{N:([^}]+)\}\}',r['translation'])]
assert sorted(refs)==sorted(r['id'] for r in chapter if r['id'].startswith('note-ch3-'))
over=json.loads((p/'render_overrides.json').read_text(encoding='utf-8'))['items']; byid={r['id']:r for r in rows}
for item in over:
 for target in item['targets']:assert '{{X:'+target+'}}' in byid[item['unit_id']]['translation']
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
qpath=p/'ch03_query_resolution.json';q=json.loads(qpath.read_text(encoding='utf-8'))
q['status']='closed_with_disclosed_source_limits';q['source_checks']+=new;q['added_editor_notes'] += [n['id'] for n in new]
q['remaining_author_claim_limits']=['Raw historical percentages and economic claims retained, no independent statistical audit','Flag derivation retains seems; no independent proof','Jumel1818–1823 and within5years retained; exact dates unverified','Two decades of war versus1775–83: may refer wider trade-disruption period; cited statistic not accessed; not silently corrected','India repetition in note057 retained','Postone interpretation, wool/cotton comparison, central bank monopoly and money3percent estimate retained as author claims, not independently validated or generalized to today']
q['conceptual_resolutions']=['Paid forwards read with preceding future debt; clarified future repayment','Money Is No Object and Provincialising headings retained contextually','fabrication distinction and small money saved to terms','machinic revised to machinery-based detour','in arrears revised to one-month post-work payment','City Business rendered cities and business','Two wrong external-book links remain scoped renderer requirements; source intact']
q['canonical_sha256']=hashlib.sha256(f.read_bytes()).hexdigest();q['next']='chapter4'
qpath.write_text(json.dumps(q,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
e=dict(status='chapter3_semantic_and_chapter_checks_complete_with_disclosed_limits',reread_ids=['ch03-0006','ch03-0025','ch03-0032','ch03-0048','ch03-0052','ch03-0076','ch03-0080','ch03-0084','ch03-0087'],revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=q['canonical_sha256'],checks=['other fields and units unchanged','264 chapter units','156 notes matched','render overrides point to extant tokens; outputs still pending'],editor_note_count=len(notes),next='ch04-0001 and corresponding notes')
(p/'ch03_final_evidence.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(revs),len(notes),q['canonical_sha256'])
