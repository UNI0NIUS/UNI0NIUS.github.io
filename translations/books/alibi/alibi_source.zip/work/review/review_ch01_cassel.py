"""One-time source-based revision batch, not a regeneration entry point."""
import json,hashlib
from pathlib import Path
p=Path(__file__).parent; f=p/'translation_units.jsonl'; raw=f.read_bytes()
rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch01-0053':[('被赫迪夫的欧洲债权人没收的糖业地产','被赫迪夫的欧洲债权人通过止赎取得的糖业地产','foreclosed 是债权执行，不是行政没收。'),('在当地被划分并出售给投资者时','在这些土地被分割并出售给投资者时','lands 主语漏失并错成地点。')],
'ch01-0058':[('也产生了经济学这门科学','也为经济学这门科学的出现创造了可能','produced the possibility 不能直接等同于产生科学。'),('一种流动的东西','一种具有流动性的东西','liquid 为金融可变现性，不是物理流动。')],
'ch01-0059':[('将在后一章讨论','将在后面的某一章讨论','a later chapter 不一定为紧随的下一章。')],
'ch01-0061':[('以其生产性使用后的完好状态出现','经过生产性使用后仍以完好状态出现','明确完好价值经使用仍保存，非含混的后置状态。')],
'ch01-0063':[('管理者信息的获取渠道','掌控着获取信息的渠道','修复错字造成主谓断裂。')],
'note-ch1-059':[('在伦敦经济学院设立的经济学讲席','在伦敦政治经济学院设立的捐赠经济学讲席','与正文校名统一，并保留 endowed。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits: continue
 old=r['translation']; reasons=[]
 for a,b,why in edits[r['id']]:
  assert a in r['translation'],r['id']
  r['translation']=r['translation'].replace(a,b); reasons.append(why)
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=reasons))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
e=dict(read_ids=[f'ch01-{i:04}' for i in range(49,65)]+[f'note-ch1-{i:03}' for i in range(48,70)],revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',next='ch01-0065',queries=['ch01-0054 Mahdi government chronology: preserve founder/government wording, verify only if chapter-end requires clarification','note-ch1-057 Annals of Science volume 7 likely missing digit: verify at chapter-end'])
(p/'ch01_cassel_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(e['read_ids']),len(revs),e['output_sha256'])
