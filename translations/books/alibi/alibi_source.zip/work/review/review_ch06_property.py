"""One-time chapter six property programme batch; do not rerun."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent; f=p/'translation_units.jsonl';raw=f.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='4f094cc1d0b0ec17b0743d268baf82659a2cb3590f0085c7f38fec5758a68d56'
rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch06-0022':[('《资本的奥秘》','{{I}}《资本的奥秘》{{/I}}','恢复书名斜体。')],
'ch06-0023':[('产权缺失以及它所能促成的信用机制，是西方以外资本主义发展失败的主要原因。','缺乏产权及其所能促成的信用机制，是西方以外资本主义发展失败的主要原因。','absence统摄产权和信用机制，不能把机制本身译成失败原因。')],
'ch06-0025':[('五十多倍','五十五倍以上','more than fifty-five遗漏五倍下界。')],
'ch06-0026':[('《另一条道路》','{{I}}《另一条道路》{{/I}}','恢复书名斜体。'),('《资本的奥秘》','{{I}}《资本的奥秘》{{/I}}','恢复书名斜体。')],
'ch06-0028':[('政治机构和财政资源网络','政治机构和资金资源网络','financial resources不限政府财政。')],
'ch06-0029':[('哈耶克写这封信之前刚从秘鲁访问归来','哈耶克是在从秘鲁访问归来后写下这封信的','after未限定刚刚返回。'),('阿特拉斯提供财政支持','阿特拉斯提供资金支持','基金会资助不是财政拨款。')],
'ch06-0030':[('《另一条道路》','{{I}}《另一条道路》{{/I}}','恢复两处书名斜体。'),('《资本的奥秘》','{{I}}《资本的奥秘》{{/I}}','恢复两处书名斜体。'),('《福布斯》','{{I}}《福布斯》{{/I}}','恢复报刊斜体。'),('《新政治家》','{{I}}《新政治家》{{/I}}','恢复报刊斜体。'),('德·索托还是设法赢得了远超新自由主义运动界限的支持者','德·索托还是设法宣称自己拥有远超新自由主义运动范围的支持者','claim supporters在误引语境保留声称性质，不能断言全部实际赢得。')],
'ch06-0031':[('《资本的奥秘》','{{I}}《资本的奥秘》{{/I}}','恢复书名斜体。'),('并再次获得弗里德曼和道格拉斯·诺斯等经济学家认可的教材素材','并为经济学教材提供了素材；这些教材获得了弗里德曼以及道格拉斯·诺斯等经济学家的认可，其中弗里德曼再次给予了支持','补足provided subject matter谓语，again仅指弗里德曼再次认可。')],
'ch06-0033':[('《资本的奥秘》的成功以及其作者在德·索托公关努力和欧美{{P:215}}新自由主义运动帮助下获得的认可，使自由与民主研究所能够把自己的活动转化为一种财产形式。','{{I}}《资本的奥秘》{{/I}}的成功及其作者获得的认可，是德·索托在欧美{{P:215}}新自由主义运动帮助下通过公关努力制造出来的；这些使自由与民主研究所能够把自己的活动转化为一种财产形式。','manufactured同时修饰著作成功和作者认可，恢复作者论断及书名斜体。'),('这类合同通常不经过竞争对手咨询公司的正常招标程序','这类合同的授予通常不按正常程序邀请其他咨询公司竞标','招标发起者为政府，避免误作竞争公司自己的招标。')],
'ch06-0034':[('《资本的奥秘》','{{I}}《资本的奥秘》{{/I}}','恢复书名斜体。'),('当被问及为什么不允许其他发展机构参与竞标时','在解释为什么不允许其他发展机构参与竞标时','原文只说解释，不额外断言被问。')],
'note-ch6-026':[('德索托','德·索托','正文原注译名一致。'),('已经使行家们把他列入我们这个时代伟大的进步知识分子万神殿','已经使行家们把他列入我们时代伟大进步知识分子的殿堂','与正文被改引措辞对齐，使差异集中于行家们这一关键主语。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits:continue
 old=r['translation'];why=[]
 for a,b,c in edits[r['id']]:
  assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b);why.append(c)
 pat=r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}'
 assert re.findall(pat,old)==re.findall(pat,r['translation'])
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=why))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
ids=[f'ch06-{i:04}' for i in range(21,36)]+[f'note-ch6-{i:03}' for i in range(14,33)]
e=dict(read_ids=ids,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',queries=['note022 European Journal of Sociology47:2 year2005 likely2006; verify publisher at chapter close','note020 Hayek letter1980 versus chapter1981foundation chronology: inspect if genuine conflict, not automatically incorrect','note019 plain-text note2 should receive link_text_to_unit override at chapter close','ch0024 and note016 pilot1992–94/replacement1996: preserve distinction, no unsupported claim full history verified','ch0025 Egypt housing92%,248bn,55fold retained as de Soto claims; chapter later may critique denominator','ch0030 New Statesman misquotation now aligns with note026; do not conflate journal assertion with reported cognoscenti judgement'],next='ch06-0036 and note-ch6-033')
(p/'ch06_property_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
cp=p.parents[2]/'工作文档'/'Alibi后续工作检查点.md';s=cp.read_text(encoding='utf-8')
entry='第六章产权计划部分已校读：ch06-0021—0035及原注014—032共34单元，修订11单元；累计1320。修复缺失范围同时统摄产权与信用机制、五十五倍数值下界、公关制造的修饰范围、教材句谓语与认可归属、宣称支持者的限定，并恢复书刊斜体。证据ch06_property_revisions.json绑定哈希；review_ch06_property.py一次性不重跑。章末待核新增期刊卷年、哈耶克信件年代及注019跳转；统计仍保留原作者归属。**实际下一位置：ch06-0036及note-ch6-033**。本章未章末核对，排版发布未开始。\n\n'
assert '## 授权与当前状态' in s
cp.write_text(s.replace('## 授权与当前状态',entry+'## 授权与当前状态',1),encoding='utf-8')
print(len(ids),len(revs),e['output_sha256'])
