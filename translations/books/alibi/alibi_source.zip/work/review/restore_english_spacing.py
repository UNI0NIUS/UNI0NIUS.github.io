"""Recover display whitespace from EPUB DOM, without modifying canonical sources."""
import importlib.util
import json
import re
import zipfile
from collections import defaultdict
from pathlib import Path
from bs4 import BeautifulSoup, NavigableString, Tag

P = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('source_reader', P.parent / 'scripts/extract_source.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class Spaced(module.Extractor):
    def render_inline(self, node, soup):
        if isinstance(node, NavigableString):
            return re.sub(r'\s+', ' ', str(node))
        return super().render_inline(node, soup)

    def _inline_children(self, node, soup):
        return ''.join(self.render_inline(child, soup) for child in node.children)


def key(text):
    return re.sub(r'\s+', '', text.replace('../images/', ''))


def main():
    units = [json.loads(x) for x in (P / 'translation_units.jsonl').read_text(encoding='utf-8').splitlines()]
    notes = json.loads((P.parent / 'source/notes_map.json').read_text(encoding='utf-8'))
    archive = zipfile.ZipFile(next(P.parents[1].glob('*.epub')))
    old, new = module.Extractor(archive, notes), Spaced(archive, notes)
    candidates = defaultdict(dict)
    for filename in dict.fromkeys(ref['file'] for unit in units if unit.get('translated') for ref in unit['source_refs']):
        soup = BeautifulSoup(archive.read(filename), 'html.parser')
        for node in soup.find_all(['p', 'h1', 'h2', 'h3', 'h4', 'figcaption', 'blockquote', 'img']):
            original = old.render_inline(node, soup)
            restored = new.render_inline(node, soup).strip().replace('../images/', '')
            assert key(original) == key(restored), filename
            candidates[filename][key(original)] = restored
        # Notes have a distinct source serializer joining direct children with spaces.
        for node in soup.select('ol.endnote-list > li > p'):
            parts = [child for child in node.children if not (isinstance(child, Tag) and child.find('a', role='doc-backlink'))]
            original = re.sub(r'^\.\s*', '', module.norm_text(' '.join(old.render_inline(child, soup) for child in parts)))
            restored = re.sub(r'^\.\s*', '', ''.join(new.render_inline(child, soup) for child in parts).strip())
            assert key(original) == key(restored)
            candidates[filename][key(original)] = restored
    changes, unmatched = {}, []
    for unit in units:
        if not unit.get('translated'):
            continue
        original = unit['source_markup']
        restored = candidates[unit['source_refs'][0]['file']].get(key(original))
        if restored is None:
            unmatched.append({'id': unit['id'], 'kind': unit['kind']})
        elif restored != original:
            assert key(original) == key(restored)
            changes[unit['id']] = restored
    result = {'policy': 'Whitespace-only EPUB display restoration; canonical source fields unchanged', 'changes': changes,
              'unmatched': unmatched}
    (P / 'english_display_spacing.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'changed': len(changes), 'unmatched': unmatched}, ensure_ascii=False))


if __name__ == '__main__':
    main()
