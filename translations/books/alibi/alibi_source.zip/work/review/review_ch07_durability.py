"""One-time durability batch."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent;f=p/'translation_units.jsonl';raw=f.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='f2e871cd9878598ffd3070ef5dac345735484810128e1022ba438b84a27afa60'
rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch07-0036':[('一定量货币显然能使自身规模翻倍的能力','一定量货币看似能使自身规模翻倍的能力','apparently表表象，不是显然确定。')],
'ch07-0038':[('这些票价、费用、费率和水电费','这些票价、费用、费率和工资','wages被错替为水电费，恢复劳动报酬承担负担的论证。')],
'ch07-0041':[('船舶建筑史学家','造船学史学家','naval architecture为造船学，不是建筑学。'),('贸易冒险资助者','贸易项目资助者','venture为商业项目，避免冒险语义过强。')],
'ch07-0043':[('对古代占有的主张','对历史久远的占有权的主张','ancient possession强调长期既有占有，不强限古代历史时期。')],
'ch07-0044':[('信用不再是由商人长期借货给把货物制成纺织品者，而是由工人延长：工人把劳动借给如今建造工厂的商人。','以往长期沿袭的做法，是商人把货物借给将其加工成纺织品的人；如今则由工人提供信用：工人把劳动借给那些转而建造工厂的商人。','long-standing修饰惯例，不是借款期限；extended credit为提供信用，不是延长信用。')],
'ch07-0047':[('在“长赐号”灾难期间通过苏伊士运河时支付的','在“长赐号”事故发生前后，通行苏伊士运河所需支付的','at the time标当时费率，不暗示堵塞期间仍实际通行。'),('把数字平台转变为有产资产','把数字平台转变为具有产权归属的资产','propertied修饰产权化，避免有产资产的无意义重复。')],
'ch07-0050':[('普尔《铁路手册》','普尔的{{I}}《铁路手册》{{/I}}','恢复书名斜体和所属关系。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits:continue
 old=r['translation'];why=[]
 for a,b,c in edits[r['id']]:
  assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b);why.append(c)
 pat=r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}'
 assert re.findall(pat,old)==re.findall(pat,r['translation'])
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=why))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
ids=[f'ch07-{i:04}' for i in range(36,51)]+[f'note-ch7-{i:03}' for i in range(28,44)]
e=dict(read_ids=ids,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',queries=['note033 sweeping claim England mortgage not formally established until1925 needs contextual editorial check, distinguish reform of legal mortgage mechanisms from absence of earlier mortgages','note030 Ships and Science2017 possibly edition year; check publisher if needed','note031 Sociological Review32:1 may supplement designation; verify source metadata at chapter close','ch0043 ethical limits and landalienability historical generalization retained as author argument','ch0050 extrastatecraft国家外技艺 provisional; assessconcept after chapter, not equate extrastate with simply stateless','ch0046 non-decomposing source relative conceptual contrast; avoid claiming literal eternal indestructibility','note0352022revenue8bn/2023fee15% are historicalsource figures, not currentpricing; no need new tariff lookup'],next='ch07-0051 and note-ch7-044')
(p/'ch07_durability_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
cp=p.parents[2]/'工作文档'/'Alibi后续工作检查点.md';s=cp.read_text(encoding='utf-8');entry='第七章耐久性部分已校读：ch07-0036—0050及原注028—043共31单元，修订7单元；累计1547。恢复工资被误替成水电费，修复工人提供信用误作延长、长期惯例误作借款期限、apparently限定和产权化表达，恢复书名斜体。证据ch07_durability_revisions.json绑定哈希；review_ch07_durability.py一次性不重跑。章末待核1925抵押法概述与期刊增刊/版年，extrastatecraft留本章术语协调。**实际下一位置：ch07-0051及note-ch7-044**。第七章未完成，全书统检排版发布未开始。\n\n';assert '## 授权与当前状态' in s;cp.write_text(s.replace('## 授权与当前状态',entry+'## 授权与当前状态',1),encoding='utf-8');print(len(ids),len(revs),e['output_sha256'])
