"""Lossless reading model for reviewed Alibi editions. No draft writers imported."""
import hashlib
import json
import re
from collections import defaultdict
from pathlib import Path

P = Path(__file__).resolve().parent


def read(name):
    return json.loads((P / name).read_text(encoding='utf-8'))


def parse(text, uid, lang, overrides):
    """Parse inline markers into a shared AST, retaining exact visible strings."""
    for rule in overrides.get(uid, []):
        if rule['action'] == 'link_text_to_unit':
            label = rule['translation_text' if lang == 'zh' else 'source_text']
            assert text.count(label) == 1, (uid, lang, label)
            text = text.replace(label, '{{U:' + rule['target_unit_id'] + '}}' + label + '{{/U}}')
    plain_targets = {t for rule in overrides.get(uid, [])
                     if rule['action'] == 'render_cross_reference_as_plain_text'
                     for t in rule['targets']}
    root = []
    stack = [(None, root)]
    for part in re.split(r'(\{\{.*?\}\})', text):
        if not part:
            continue
        if not part.startswith('{{'):
            stack[-1][1].append(part)
            continue
        token = part[2:-2]
        if token.startswith('/'):
            assert len(stack) > 1 and stack[-1][0] == token[1:], (uid, token)
            stack.pop()
            continue
        kind, _, value = token.partition(':')
        if kind in ('I', 'B', 'X', 'L', 'U'):
            node = {'type': {'I': 'em', 'B': 'strong', 'X': 'xref', 'L': 'link', 'U': 'unitlink'}[kind], 'children': []}
            if value:
                node['target'] = value
            if kind == 'X' and value in plain_targets:
                node['type'] = 'span'
            stack[-1][1].append(node)
            stack.append((kind, node['children']))
        elif kind in ('P', 'N'):
            stack[-1][1].append({'type': 'page' if kind == 'P' else 'note', 'id': value})
        elif kind == 'IMG':
            filename, _, alt = value.partition('|')
            stack[-1][1].append({'type': 'image', 'filename': Path(filename).name, 'alt': alt})
        else:
            raise ValueError((uid, token))
    assert len(stack) == 1, uid
    return root


def walk(nodes):
    for node in nodes:
        if isinstance(node, dict):
            yield node
            yield from walk(node.get('children', []))


def build():
    raw = (P / 'translation_units.jsonl').read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    audit = read('global_structure_audit.json')
    assert audit['passed'] and audit['canonical_sha256'] == digest
    units = [json.loads(line) for line in raw.decode('utf-8').splitlines()]
    overrides = defaultdict(list)
    for rule in read('render_overrides.json')['items']:
        overrides[rule['unit_id']].append(rule)
    editors = defaultdict(list)
    for note in read('editor_notes.json'):
        editors[note['unit_id']].append(note)
    figures = read('figure_translations.json')
    display_spacing = read('english_display_spacing.json')['changes']
    sections = {}
    aliases = {}
    note_refs = {}
    note_map = json.loads((P.parent / 'source/notes_map.json').read_text(encoding='utf-8'))
    for target, note in note_map.items():
        aliases[target] = note['id']
    rows = []
    excluded = []
    for unit in units:
        uid, section, kind = unit['id'], unit['section'], unit['kind']
        if section == 'index' or kind == 'toc_entry':
            excluded.append(uid)
            continue
        assert unit.get('translated') or kind == 'pagebreak', uid
        if unit.get('translated'):
            assert unit['review_status'] == 'semantic_reviewed', uid
        row = {k: unit.get(k) for k in ('id', 'section', 'kind', 'level', 'page_start', 'page_end', 'source_refs')}
        # source_markup normalizes image paths while preserving source emphasis.
        english = display_spacing.get(uid, unit['source_markup'])
        normalize = lambda value: re.sub(r'\s+', '', value.replace('../images/', ''))
        assert normalize(english) == normalize(unit['source_markup']), uid
        row['en'] = parse(english, uid, 'en', overrides)
        row['zh'] = parse(unit['translation'] if unit.get('translated') else unit['source_markup'], uid, 'zh', overrides)
        row['editor_notes'] = editors.get(uid, [])
        for ref in unit['source_refs']:
            filename = Path(ref['file']).name
            aliases.setdefault(filename, uid)
        for token in walk(row['zh']):
            if token['type'] == 'page':
                aliases['page' + token['id']] = 'page-' + token['id']
            elif token['type'] == 'note':
                assert token['id'] not in note_refs
                note_refs[token['id']] = uid
        if kind == 'figure':
            fig = figures[uid]
            row['figure'] = {'filename': unit['source_image'], 'alt': {'zh': fig['alt_translation'], 'en': unit['source_alt']},
                             'description': {'zh': fig['long_description_translation'], 'en': unit['source_long_description']}}
            aliases['fig' + str(int(uid[-2:]))] = uid
        rows.append(row)
        sections.setdefault(section, []).append(uid)
    for target, note in note_map.items():
        aliases[note['backlink_target']] = note_refs[note['id']]
    assert len(note_refs) == 853
    assert sum(len(row['editor_notes']) for row in rows) == 72
    assert len([row for row in rows if row['kind'] == 'note']) == 853
    unresolved = []
    for row in rows:
        for lang in ('zh', 'en'):
            for node in walk(row[lang]):
                if node['type'] == 'xref':
                    target = node['target'].split('#')[-1] if '#' in node['target'] else Path(node['target']).name
                    if target not in aliases:
                        unresolved.append({'unit': row['id'], 'language': lang, 'target': node['target']})
                    else:
                        node['resolved'] = aliases[target]
    model = {'canonical_sha256': digest, 'sections': sections, 'rows': rows, 'aliases': aliases,
             'note_ref_units': note_refs, 'index': read('index_source.json'), 'excluded_unit_ids': excluded,
             'unresolved_xrefs': unresolved, 'status': 'model_built_not_rendered'}
    (P / 'edition_model.json').write_text(json.dumps(model, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    report = {'canonical_sha256': digest, 'rows': len(rows), 'notes': len(note_refs),
              'editor_notes': 72, 'figures': sum('figure' in row for row in rows), 'unresolved_xrefs': unresolved}
    (P / 'edition_model_audit.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False))
    return model


if __name__ == '__main__':
    build()
