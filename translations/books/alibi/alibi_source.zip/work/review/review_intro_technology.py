"""One-time edits. Do not rerun."""
import json,hashlib
from pathlib import Path
p=Path(__file__).parent; f=p/'translation_units.jsonl'; raw=f.read_bytes()
rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'introduction-0030':[('租车公司','汽车客运服务公司','此处包含出租车等客运服务，不是车辆出租。'),('其他国家银行服务','其他国家的银行服务机构','national banking services 不是“国家银行服务”的机构名。')],
'introduction-0032':[('而汽车的个人所有权——多数家庭可能购买的最昂贵物品——催生了','而个人拥有汽车——汽车是多数家庭可能购买的物品中远为昂贵的一项——催生了','最昂贵物品修饰汽车而非所有权；保留原作比较断言。')],
'introduction-0033':[('全球租车服务公司','全球叫车服务公司','与上下文客运服务对应。')],
'introduction-0036':[('它们所依赖的设押','它们所依赖的负担'),('使未来得以被设押的阻碍与控制关系','使未来背负负担的阻碍与控制关系'),('托词代之以一种旧的资本观','这一托词没有把资本看作与未来的关系，而是代之以一种旧的资本观','补回 Rather than seeing capital as a relation to the future 被遗漏的对照项。')],
'introduction-0039':[('租车服务','叫车服务')],
'introduction-0040':[('机械上娴熟但概念上狭隘','操作上娴熟但概念上狭隘','mechanically proficient 指分析操作熟练，不是机械设备技术。')],
'introduction-0041':[('本地租车公司','本地汽车客运服务公司'),('监管租车业','监管汽车客运服务业')],
'introduction-0042':[('城市租车公司','城市汽车客运服务公司'),('新的租车服务公司','新的叫车服务公司'),('租车服务使用者','叫车服务使用者'),('更多交通，更少公交','更多车流，更少公交','traffic 是机动车流量，与 transit 对举。')],
'note-int-034':[('它对地方抗议、政治组织和改革持开放态度','它存在可由地方抗议、政治组织活动和改革加以影响的空间','open to 指制度可被介入和改革，不是监管者主观赞同抗议。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits: continue
 old=r['translation']; reasons=[]
 for item in edits[r['id']]:
  a,b=item[:2]; assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b); reasons.append(item[2] if len(item)>2 else '依据本段语境保持术语含义，避免将一般负担缩为抵押或将客运误作租车。')
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=reasons))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
e=dict(read_ids=[f'introduction-{i:04}' for i in range(30,44)]+[f'note-int-{i:03}' for i in range(19,39)],revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',next='introduction-0044',queries=['0030: semiconductor invention formulation retained; fact-check scope at chapter end','0037: EconoCon translation provisional pending chapter 8 context','note-int-037: publication year to verify at chapter end'])
(p/'introduction_technology_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(e['read_ids']),len(revs),e['output_sha256'])
