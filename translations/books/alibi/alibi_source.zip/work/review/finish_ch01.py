"""One-time chapter terminology and targeted reread corrections."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent; f=p/'translation_units.jsonl'; raw=f.read_bytes(); rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch01-0007':[('在田块围堰中截留洪水','在围堤田块中蓄留洪水','basin 为围堤内田块，非堤坝本身。')],
'ch01-0009':[('田块围堰储水系统','围堤田块的储水系统','区分田块与堤坝。'),('围堰之下的系统','这些田块之下的系统','beneath them 指田块下土壤储水。'),('生态灭绝','生态毁灭','ecocide 指生态系统毁灭，不限物种灭绝。')],
'ch01-0010':[('生态灭绝','生态毁灭','与上段术语一致。')],
'ch01-0026':[('所带来的，与其说是为支付建设费用而筹集资本的需要——尽管这些支付必须找到，通常通过进一步的信用货币系统：','其意义并不主要在于产生了为支付建设费用而筹集资本的需要。诚然，支付建设费用的资金必须筹措，通常是借助进一步的信用货币体系：','回读修复前次修改留下的未闭合比较句；保留非绝对否定。')],
'ch01-0037':[('谷物升降机','谷物提升设备','避免一般人员升降机误读；不额外扩写原文设施。')],
'note-ch1-083':[('该文描述了为调查该公司倒闭而设立的专家报告','该文介绍了受命调查公司倒闭的专家所提交的报告','set up 指专家调查组织，不能设立报告。'),('克罗尼耶先生才干和声望','克罗尼耶先生的才干和声望','补足结构助词。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits: continue
 old=r['translation']
 for a,b,_ in edits[r['id']]: assert a in r['translation']; r['translation']=r['translation'].replace(a,b)
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=[x[2] for x in edits[r['id']]]))
pattern=r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}'
oldrows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
for a,b in zip(oldrows,rows):
 assert a['id']==b['id']
 if a['id'] not in edits: assert a==b
 else:
  assert re.findall(pattern,a['translation'])==re.findall(pattern,b['translation'])
  for k in a:
   if k!='translation': assert a[k]==b[k]
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
e=dict(revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),reread_ids=['ch01-0007','ch01-0009','ch01-0010','ch01-0026','ch01-0032','ch01-0037','ch01-0042','ch01-0076','ch01-0096','note-ch1-083'],status='chapter_review_complete_with_disclosed_source_limits',checks=['incremental token order','other fields unchanged','other units unchanged'],next='ch02-0001 and notes')
(p/'ch01_final_evidence.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
t=p/'term_decisions.json'; terms=json.loads(t.read_text(encoding='utf-8')); terms['terms'] += [{'en':'field basins','zh':'围堤田块','note':'不与围堤本身或地下储水混淆；第二章延续核对。'},{'en':'ecocide','zh':'生态毁灭','note':'保留毁灭性，不限个别物种灭绝。'},{'en':'grain elevator','zh':'谷物提升设备','note':'第一章按技术机制语境处理，不补写源文没有的仓储结构。'}]; t.write_text(json.dumps(terms,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(revs),e['output_sha256'])
