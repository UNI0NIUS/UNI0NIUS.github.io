"""One-time chapter4 process/object comparison; chapter checks pending."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent;f=p/'translation_units.jsonl';raw=f.read_bytes();rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch04-0046':[('英国帝国主义的主要批评者','英国批评克罗默等帝国主义者的主要论者','恢复like Cromer限定及English修饰批评者。'),('经典文章《帝国主义》','经典论著{{I}}《帝国主义》{{/I}}','恢复原书名斜体。'),('对{{I}}国民{{/I}}资源','对国民资源','删除底本不存在的强调。'),('用“{{I}}国民经济{{/I}}”短语指称这样一种对象','用“{{I}}这个{{/I}}国民经济整体”（the national economy）指称这样一种对象','强调the及对象化，而非再次强调相同中文词。')],
'ch04-0048':[('庞大的无地、无产人口','庞大的无土地、无财产人口','propertyless明确财产条件，与第三章一致。')],
'ch04-0049':[('对这种方式的一种简单描述是','对这一变化有时会作这样一种简单描述','change及sometimes，不是方式。')],
'ch04-0052':[('经典著作《大转型》（1944）','经典著作{{I}}《大转型》{{/I}}（1944）','恢复斜体。')],
'ch04-0053':[('把某个机构构成为买者、把另一个构成为卖者','把某个行动主体构成为买者、把另一个构成为卖者','agency不限于组织机构。')],
'ch04-0056':[('密尔的《政治经济学原理》','密尔的{{I}}《政治经济学原理》{{/I}}','恢复斜体。')],
'ch04-0057':[('通过政治经济学、法律、政府还是生产组织的工作','通过政治经济学、法律、治理还是生产组织的工作','government与过程并列，保持治理义。')],
'note-ch4-056':[('{{I}}Freaks of Fortune:{{/I}}{{P:342}}{{I}}The Emerging','{{I}}Freaks of Fortune:{{/I}} {{P:342}}{{I}}The Emerging','跨页书名保留词间空格。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits:continue
 old=r['translation'];why=[]
 for a,b,c in edits[r['id']]:
  assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b);why.append(c)
 pattern=r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}'
 assert re.findall(pattern,old)==re.findall(pattern,r['translation'])
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=why))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
ids=[f'ch04-{i:04}' for i in range(45,58)]+[f'note-ch4-{i:03}' for i in range(47,63)]
e=dict(read_ids=ids,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',queries=['ch04-0056 identifies Principles but note060 cites On the Definition: source inconsistency retained, check at chapter end','Economisation means continual production of calculable relations, not invention of separate sphere; reconcile all chapter at close','ch04-0048 Such arguments has loose antecedent from national economy discussion; source structure retained','Polanyi interpretation and claim about economy vocabulary preserved as author interpretation, not independent full-corpus audit'],next='ch04-0058 and note-ch4-063')
(p/'ch04_economisation_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(ids),len(revs),e['output_sha256'])
