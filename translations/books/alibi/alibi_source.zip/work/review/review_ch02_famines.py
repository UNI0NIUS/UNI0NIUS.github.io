"""One-time semantic corrections. Full chapter audit follows later."""
import json,hashlib
from pathlib import Path
p=Path(__file__).parent; f=p/'translation_units.jsonl'; raw=f.read_bytes()
rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch02-0068':[('以前在当地处理和决定的计算，现在要在远处进行。','以前在当地处理的计算与决策，如今要在远处作出。','calculations and decisions为并列对象，不能把决策并入计算。')],
'ch02-0070':[('它的洪水制度','它的洪水节律','regime此处为水文规律，非治理制度。'),('也更容易交换的','也更具可互换性的','fungible为可互换，区别一般交换便利。')],
'ch02-0071':[('转而在象征性铜币之外依靠账面信用（记账货币）','转而依靠账面信用（记账货币），辅以作为辅币的铜币','恢复信用为主、铜币为补充的关系；token coin非象征性物品。')],
'ch02-0072':[('《解除民众忧患》','《考察困苦以救助民众》','补回作者给出的Examining和Community，书名辨析正是本段论点。')],
'ch02-0074':[('表水和地下水','地表水和地下水','规范表述。'),('过于适应、过于复杂','适应性过强、过于复杂','too adaptable为适应性强，不是过度适合新目的。'),('土地生产力注定会迅速下降','土地生产力即将迅速下降','was set to为随后趋势，不加宿命必然性。')],
'note-ch2-119':[('但可能与意大利入侵有关的大规模驮畜流动很可能促成了其迅速传播','但与意大利入侵相伴的大规模驮畜流动，很可能促成了其迅速传播','probable限定促成传播，不重复转嫁到入侵关联。')],
'note-ch2-121':[('高地已大体上被砍伐殆尽','高原上的森林已大多遭到砍伐','被砍伐的是森林，不是高地本身；largely不过度译为全尽。')],
'note-ch2-122':[('盆地体系','围堤蓄水体系','人工灌溉体系。')],
'note-ch2-141':[('上埃及盆地体系','上埃及围堤蓄水体系','人工灌溉体系。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits: continue
 old=r['translation']; reasons=[]
 for a,b,why in edits[r['id']]:
  assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b); reasons.append(why)
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=reasons))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
ids=[r['id'] for r in rows if r.get('translation') and (('ch02-0062'<=r['id']<='ch02-0074') or ('note-ch2-111'<=r['id']<='note-ch2-143'))]
e=dict(read_ids=ids,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',next='ch02-0075',queries=['note-ch2-133 Petry Mamluk Sultanate publication2002 looks potentially2022; verify publisher at chapter end','ch02-0070 categorical never famine from flood retained as author claim with note137 support; not independent historical proof','note121 explicitly identifies deforestation causal chain as author inference; preserve this limitation in all outputs','ch02-0069 Mahdist independent state1881 retained as source chronology; assess alongside other dates at chapter end'])
(p/'ch02_famines_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(ids),len(revs),e['output_sha256'])
