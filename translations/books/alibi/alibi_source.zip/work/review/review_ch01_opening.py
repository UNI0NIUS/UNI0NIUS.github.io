"""One-time edits; full chapter audit remains pending."""
import json,hashlib
from pathlib import Path
p=Path(__file__).parent; f=p/'translation_units.jsonl'; raw=f.read_bytes()
rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch01-0007':[('消除特大洪水的威胁','消除异常洪水的威胁','exceptional 此处包括洪水偏低和过高，不能缩为特大。')],
'ch01-0008':[('大型动物和微生物生命','大型土壤动物和微生物生命','结合土壤共生语境澄清macrofauna，非大型兽类。')],
'ch01-0010':[('一个世界如何围绕通过资本化从未来抽取来安排——也就是在当下实现那笔非劳动预期收入的能力？','一个世界如何被组织起来，围绕着对未来的资本化而从中抽取收入——也就是在当下兑现那笔非劳动预期收入的能力？','理清世界被组织与资本化能力的句法关系，避免破碎直译。')],
'ch01-0013':[('地球自转的速度和轴心','地球自转的速度和转轴','axis 为转轴，不是中心点。')],
'ch01-0014':[('大大五个数量级','大五个数量级','去除重复字。')],
'ch01-0015':[('这个术语只存在了大约七十五年','我们这样使用它不过大约七十五年','时间限定的是把握运作的用法，不是词语首次存在。')],
'ch01-0018':[('以抵抗老化、腐烂和回收','以抵抗老化、腐烂和物质再循环','recycling 承接生态物质循环，不限废物回收。')],
'note-ch1-001':[('本注及下一段','本段及下一段','this 指正文段落。')],
'note-ch1-004':[('本注及下一段','本段及下一段','同上，原注资料支持正文而非注释自身。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits: continue
 old=r['translation']; reasons=[]
 for a,b,why in edits[r['id']]:
  assert a in r['translation'],r['id']
  r['translation']=r['translation'].replace(a,b); reasons.append(why)
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=reasons))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
e=dict(read_ids=[f'ch01-{i:04}' for i in range(2,19)]+[f'note-ch1-{i:03}' for i in range(1,15)],revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',next='ch01-0019',queries=['basin irrigation: confirm consistent rendering after chapter 2; preserve basin versus embankment distinction','ecocide: provisional 生态灭绝; consider 生态毁灭 at chapter end, preserving political force','ch01-0008 parasite wording follows source; not independent medical verification'])
(p/'ch01_opening_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(len(e['read_ids']),len(revs),e['output_sha256'])
