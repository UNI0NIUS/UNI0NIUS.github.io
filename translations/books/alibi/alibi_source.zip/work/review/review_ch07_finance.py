"""One-time chapter-seven finance batch."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent;f=p/'translation_units.jsonl';raw=f.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='4061a488991c7e230b2f1f143d501fb374c28be41057ad05dd535f125a24dc4b'
rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
edits={
'ch07-0017':[('石油储备垄断权','石油储量的垄断权','reserves指地下资源储量，不是已开采库存。'),('作为资本托词运作的','作为资本的托词运作的','对齐书名核心术语。')],
'ch07-0018':[('投资的价值的来源','投资价值的来源','删除重复结构助词。')],
'ch07-0021':[('对人类创世的理解','对人类建构世界的理解','world-making不是宗教创世。')],
'ch07-0028':[('货币仍然被强调信任、社会关系和法律规制，而不是作为一种技术政治关系来处理','对货币的研究仍然着重于信任、社会关系和法律规制，而不把它作为一种技术政治关系来处理','修复被强调无谓语的语法，明确研究视角。')],
'ch07-0031':[('《国富论》','{{I}}《国富论》{{/I}}','恢复两处书名斜体。'),('所有草和谷物','所有牧草和谷物','grass在牧场及市场货物流通语境。'),('并威胁到斯密自己的赞助人、英国最大的地主之一巴克卢公爵破产','并使斯密自己的赞助人、英国最大的地主之一巴克卢公爵面临破产威胁','修复威胁到某人破产的搭配。')],
'ch07-0033':[('或者只是以实现这种控制可能带来的意外之财','或者只是为了兑现这种控制可能带来的意外收益','修复目的句。'),('信用票据的所有者——某人承诺在未来某一固定日期支付一定金额，以换取某种货物的交付——可以把这份付款承诺卖给第三方','信用票据的持有者可以把这份付款承诺卖给第三方；这张票据代表另一个人的承诺，即在未来某一固定日期支付一定金额，以换取某种货物的交付','破折号定义票据而非所有者，补清另一个人承担付款义务。')],
'note-ch7-022':[('基于可转让信贷的会计体系','基于可转让信用的会计体系','与正文信用货币宽义对齐，不限银行贷款。')],
'note-ch7-026':[('{{/I}}{{P:363}}{{I}}Macroeconomics','{{/I}} {{P:363}}{{I}}Macroeconomics','恢复跨页英文词间空格。')],
'note-ch7-027':[('以 10% 年贴现率计算，100 美元七年后的确切现值是 51.32 美元。','按每年 10% 的贴现率折算，七年后取得的 100 美元，其确切现值为 51.32 美元。','现值是当下的价值，不是七年后的现值；数字和作者口径原样保留。')]
}
revs=[]
for r in rows:
 if r['id'] not in edits:continue
 old=r['translation'];why=[]
 for a,b,c in edits[r['id']]:
  assert a in r['translation'],(r['id'],a)
  r['translation']=r['translation'].replace(a,b);why.append(c)
 pat=r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}'
 assert re.findall(pat,old)==re.findall(pat,r['translation'])
 revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=why))
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
ids=[f'ch07-{i:04}' for i in range(16,36)]+[f'note-ch7-{i:03}' for i in range(16,28)]
e=dict(read_ids=ids,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_status='in_progress',queries=['note020 William Cronin likely William Cronon; verify publisher at chapter close; book1992 may paperback edition','ch0031 1772 crisis/five-year postponement of Wealth of Nations1776 chronology needs caution; source historical explanation retained, assess evidence','ch0034 and note027 mix100*(1-.1)=90 with100/(1.1**7)=51.3158; ordinary discount10% gives47.82969 after7years, yield discount gives90.9091 after1year; disclose convention inconsistency at chapter close, do not silently alter source numbers','ch0015 move paper clarified0016 corporatebonds,loans,sharecertificates; paper metaphor may stay literal with next paragraph explanation','note018 Chicago University Press naming differs University of Chicago Press; inspect publisher at chapter close if needed','note021 ordinary text crossrefchapter1 can stay readable, no need automatic link for every mention','ch0017 sabotage deliberate withholding not solely physicaldestruction; whole-chapter terminology reread','ch0020 can increase not promised guaranteed returns; author theoretical argument remains attributed'],next='ch07-0036 and note-ch7-028')
(p/'ch07_finance_revisions.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
cp=p.parents[2]/'工作文档'/'Alibi后续工作检查点.md';s=cp.read_text(encoding='utf-8');entry='第七章融资/延迟部分已校读：ch07-0016—0035及原注016—027共32单元，修订9单元；累计1516。修复储量误作储备、world-making创世义、票据持有人与付款人关系及现值时点，恢复斜体和英文空格。证据ch07_finance_revisions.json绑定哈希；review_ch07_finance.py一次性不重跑。章末待核Cronin/Cronon、国富论延迟出版时序、折扣与收益率口径混用；原数字未静默改写。**实际下一位置：ch07-0036及note-ch7-028**。本章未完成，全书统检排版发布未开始。\n\n';assert '## 授权与当前状态' in s;cp.write_text(s.replace('## 授权与当前状态',entry+'## 授权与当前状态',1),encoding='utf-8');print(len(ids),len(revs),e['output_sha256'])
