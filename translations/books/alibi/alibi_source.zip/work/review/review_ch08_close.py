"""One-time remaining chapter-eight semantic review and coverage audit."""
import json,hashlib,re
from pathlib import Path
p=Path(__file__).parent;f=p/'translation_units.jsonl';raw=f.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='5547b54db1465109a899e96955bf6b80e6961e44b1dce630f702256eb6f8578a'
rows=[json.loads(x) for x in raw.decode('utf-8').splitlines()]
ids=[r['id'] for r in rows if ('ch08-0051'<=r['id']<='ch08-0088' or 'note-ch8-028'<=r['id']<='note-ch8-049') and r['status']=='translated']
edits={
'ch08-0051':[('如果说有什么不同','确切地说','if anything在此强调工业只是绕道，而非提出未说明的差异。'),('帝国扩张的更新权力','重新增强的帝国扩张力量','renewed指再度增强/复兴，不是更新权力。')],
'ch08-0055':[('并率领国家卷入四百年来欧洲第一场重大战争；作为交换，他接受了一项安排','并率领这个国家卷入其四百年来首次在欧洲进行的重大战争；他接受了一项安排','first major war限定the country的参战经历，不是欧洲四百年无重大战争；删除原文没有的作为交换。'),('为战争筹集的贷款越来越多地用于扩张英国海外商业垄断，不再要求一年内偿还。','这些战争越来越以扩张英国海外商业垄断为目的，而为战争筹集的贷款不再要求一年内偿还。','fought increasingly修饰战争，非贷款支出份额；恢复两层关系。')],
'ch08-0058':[('已成为未来榨取如今所依赖的工具','已成为如今从未来榨取所依赖的工具','extraction from the future，不是发生在未来的榨取。')],
'ch08-0060':[('它像控制装置那样物质地运作','它作为控制装置在物质层面运作','as an apparatus是性质判断，不是仅仅类比。')],
'ch08-0063':[('一项“难以克服”的挑战','一项“无法克服”的挑战','insuperable强度应保留；为原作者转引，不由译者缓和。')],
'ch08-0067':[('取消赎回权','止赎','全书已确定的foreclosure术语。')],
'ch08-0073':[('生产者、消费者、房主、企业主','生产者、消费者、户主、企业主','householder为家庭户主，不要求拥有住房产权。')],
'ch08-0081':[('异常长期利润最可靠的来源','超额、长期利润最可靠的来源','extraordinary修饰利润水平，不能变成期限异常地长。')],
'ch08-0082':[('一条异常未来收入流的折现现值','一条异常丰厚的未来收入流的贴现现值','extraordinary指收益规模，不是未来异常；贴现用语一致。'),('通过公关活动、智库','通过公共{{P:288}}关系活动、智库','恢复public/relations处原书页标。'),('以及许多其他形式的宣传、国家补贴、破坏、战争和舆论塑造{{P:288}}','以及许多其他形式的宣传、国家补贴、破坏、战争和舆论塑造','移除误置于长列表末尾的旧页标；原页位数不变。')],
'ch08-0085':[('先前插曲的断裂性质','此前历史片段的断裂性质','episodes不是暗示不重要的插曲。'),('始终可能被转移和受挫','始终可能转向或受挫','diversion是计划改变路径，不是被搬运转移。')],
'ch08-0086':[('人的和超过人的','人类的与超出人类范围的','more than human不指高于人的等级。'),('有机的和无机的、稳定的和失稳的','有机的和无机的、促成稳定的和破坏稳定的','stabilising/destabilising为作用，不只是力量本身状态。'),('预先购买农产品生产的不可预测性','预购农业产出的不可预测性','production此处为预购的农业产出。')],
'ch08-0087':[('来自别处的例子和插曲','来自别处的例子和历史片段','episodes与前段一致。')],
'ch08-0088':[('以这种更有节制的方式接近资本主义及其增长','以这种把范围界定得更具体的方式理解资本主义及其增长','circumscribed指前述限定历史过程与机制的范围，不是态度节制。')]
}
revs=[]
for r in rows:
 if r['id'] not in ids:continue
 old=r['translation'];why=[]
 for a,b,c in edits.get(r['id'],[]):
  assert a in r['translation'],(r['id'],a);r['translation']=r['translation'].replace(a,b);why.append(c)
 if why:revs.append(dict(id=r['id'],before=old,after=r['translation'],reasons=why))
 r['review_status']='semantic_reviewed'
chapter=[r for r in rows if (r['section']=='ch08' or r['id'].startswith('note-ch8-')) and r['status']=='translated']
seen=set(ids)
for name in ['opening','capture']:seen.update(json.loads((p/f'ch08_{name}_revisions.json').read_text(encoding='utf-8'))['read_ids'])
assert seen=={r['id'] for r in chapter}
refs=[];notes=[]
for r in chapter:
 pat=r'\{\{(?:N|P|X|/X|L|/L|B|/B)[^}]*\}\}'
 assert re.findall(pat,r['source_text'])==re.findall(pat,r['translation']),r['id']
 refs+=re.findall(r'\{\{N:([^}]+)\}\}',r['translation'])
 if r['id'].startswith('note-ch8-'):notes.append(r['id'])
assert sorted(refs)==sorted(notes) and len(notes)==49
for a,b in zip([json.loads(s) for s in raw.decode('utf-8').splitlines()],rows):
 assert {k:v for k,v in a.items() if k not in ['translation','review_status']}=={k:v for k,v in b.items() if k not in ['translation','review_status']}
 if a['id'] not in ids:assert a==b
f.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
e=dict(read_ids=ids,revisions=revs,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),chapter_read_count=len(chapter),notes_count=len(notes),chapter_status='full_source_translation_read_complete_queries_pending',checks=['complete read coverage','49 note references and definitions matched','source fields preserved','structural tokens preserved','other units unchanged'],queries=['ch08-0055四百年未在欧洲大战/0056英格兰银行垄断贴现/0057仅英国金本位是原作历史概述，需定向核实范围，不能默改。','note-ch8-029出版年份2019、note031Feavearyear拼写、note042Harvard2014疑点集中核查。','note044混用CO2与温室气体CO2当量、GCP与Minx数据来源，须作口径核查，勿更新成今日数据。','note040德国35–40%明确是2006数据；保留历史统计口径，不冒充独立复算。','EconoCon全文定义0060及0073支持作为治理/控制装置的类比，统一译名待重点回读与全书术语传播；indemnification开篇与后文债务偿还相关。'],next='chapter8 queries/terms/targeted reread; ten remaining translated endmatter units to inspect globally')
(p/'ch08_close_evidence.json').write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
cp=p.parents[2]/'工作文档'/'Alibi后续工作检查点.md';s=cp.read_text(encoding='utf-8')
entry=f'第八章全章源译校读完成：末批ch08-0051—0088（排除0075空页标）及原注028—049共{len(ids)}单元，修订{len(revs)}单元；本章{len(chapter)}有效单元与49原注已全覆盖，引用/定义、结构令牌、源字段、其他单元不变检查通过。修复四百年大战的国家范围、战争目的修饰关系、户主/房主、超额长期利润、原书288页标及结尾限定范围等。证据ch08_close_evidence.json；review_ch08_close.py一次性不重跑。规范稿SHA256 '+e['output_sha256']+f'；累计{1650+len(ids)}有效单元。**实际下一位置：第八章疑点集中核查、术语协调、重点回读**。全书尚余附属材料核读与集中统检，排版发布未开始。\n\n'
assert '## 授权与当前状态' in s;cp.write_text(s.replace('## 授权与当前状态',entry+'## 授权与当前状态',1),encoding='utf-8')
print(json.dumps(dict(read=len(ids),revised=len(revs),chapter=len(chapter),sha256=e['output_sha256']),ensure_ascii=False))
