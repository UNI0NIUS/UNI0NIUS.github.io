#!/usr/bin/env python3
"""Populate the canonical translation JSONL from the validated draft batch output.

The source EPUB is never modified. Draft body/notes translations live in
work/translation/zh/. Figure captions come from work/translation/figure_translations.json.
The English source index is retained as source-language apparatus and is rebuilt by
build_output.py directly from OEBPS/xhtml/18_Index.xhtml.
"""
from __future__ import annotations

import hashlib
import json
import re
from collections import Counter, OrderedDict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / "work"
SOURCE = WORK / "source"
TRANSLATION = WORK / "translation"
ZH = TRANSLATION / "zh"

UNIT_MARKER = re.compile(r"^@@UNIT:([^@]+)@@\s*$", re.M)
TOKEN = re.compile(r"\{\{(?:P|N|I|B|L|X|IMG)(?::[^}]*)?\}\}|\{\{/(?:I|B|L|X)\}\}")

COVER_TRANSLATION = (
    "{{IMG:cover.jpg|图书封面：书名《资本的托词》位于中央，上方副标题为"
    "“我们如何以明天会更好的承诺，毁掉地球，窃取未来”，作者蒂莫西·米切尔的名字位于上方。}}"
)

NOTES_HEADING = "注释"
NOTE_GROUP_TRANSLATIONS = OrderedDict(
    [
        ("Uber Eats: How Capitalism Consumes the Future", "导论：优步外卖——资本主义如何消费未来"),
        ("1 Groundbreaking", "第一章　破土"),
        ("2 On Rivercide", "第二章　论弑河"),
        ("3 Capitalism as a Detour", "第三章　作为绕道的资本主义"),
        ("4 Reading the Book of the Future", "第四章　解读未来之书"),
        ("5 Economentality: How the Future Entered Government", "第五章　经济心态：未来如何进入治理"),
        ("6 The Properties of Markets", "第六章　市场的属性"),
        ("7 Infrastructures Work on Time", "第七章　基础设施作用于时间"),
        (
            "8 A Better Tomorrow, Tomorrow? Climate Crisis and the Alibi of Growth",
            "第八章　明天会更好，明天？气候危机与增长的托词",
        ),
    ]
)


def parse_batches(folder: Path) -> dict[str, str]:
    units: dict[str, str] = {}
    for path in sorted(folder.glob("*.md")):
        text = path.read_text(encoding="utf-8")
        parts = re.split(r"^@@UNIT:([^@]+)@@\s*$", text, flags=re.M)
        if len(parts) % 2 != 1:
            raise ValueError(f"malformed unit markers in {path}")
        for i in range(1, len(parts), 2):
            uid = parts[i].strip()
            body = parts[i + 1].strip()
            if uid in units:
                raise ValueError(f"duplicate unit {uid} (including {path.name})")
            units[uid] = body
    return units


def structural_tokens(text: str) -> list[str]:
    """Token fingerprint used for layout verification.

    Italic markers are handled as visible typography rather than structural
    tokens: Chinese book titles conventionally use 《》 and English titles are
    rendered as Markdown emphasis. Page, note, image, link, cross-reference and
    bold markers must match the source exactly.
    """
    out: list[str] = []
    for token in TOKEN.findall(text):
        if token.startswith("{{/"):
            if token in ("{{/X}}", "{{/B}}", "{{/L}}"):
                out.append(token)
            continue
        if token == "{{I}}":
            continue
        if token.startswith("{{P:"):
            out.append("P:" + token[4:-2])
        elif token.startswith("{{N:"):
            out.append("N:" + token[4:-2])
        elif token.startswith("{{X:"):
            out.append("X:" + token[4:-2])
        elif token.startswith("{{L:"):
            out.append("L:" + token[4:-2])
        elif token == "{{B}}":
            out.append("B")
        elif token.startswith("{{IMG:"):
            out.append("IMG:" + token[6:-2].split("|", 1)[0].split("/")[-1])
        else:
            raise ValueError(f"unhandled token {token!r}")
    return out


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> None:
    source_units = [json.loads(line) for line in (SOURCE / "source_units.jsonl").open(encoding="utf-8")]
    by_id = {u["id"]: u for u in source_units}
    if len(by_id) != len(source_units):
        raise ValueError("duplicate source unit ids")

    body = parse_batches(ZH)
    body = {uid: text for uid, text in body.items() if not uid.startswith("note-")}
    notes = parse_batches(ZH)
    notes = {uid: text for uid, text in notes.items() if uid.startswith("note-")}

    figure_data = json.loads((TRANSLATION / "figure_translations.json").read_text(encoding="utf-8"))

    expected_body = {
        u["id"]
        for u in source_units
        if u["section"] not in ("index", "notes")
        and u["kind"] not in ("pagebreak", "toc_entry", "figure")
        and u["id"] != "01_cover-0001"
    }
    expected_notes = {u["id"] for u in source_units if u["kind"] == "note"}
    expected_figures = {u["id"] for u in source_units if u["kind"] == "figure"}
    expected_note_headings = {u["id"] for u in source_units if u["kind"] == "note_group_heading"}

    if set(body) != expected_body:
        raise ValueError(f"body coverage mismatch: missing={sorted(expected_body - set(body))}, extra={sorted(set(body) - expected_body)}")
    if set(notes) != expected_notes:
        raise ValueError(f"note coverage mismatch: missing={sorted(expected_notes - set(notes))}, extra={sorted(set(notes) - expected_notes)}")
    if set(figure_data) != expected_figures:
        raise ValueError(f"figure coverage mismatch: {set(figure_data) ^ expected_figures}")
    if set(note_group_headings := {u["source_text"] for u in source_units if u["kind"] == "note_group_heading"}) != set(NOTE_GROUP_TRANSLATIONS):
        raise ValueError("note group heading set does not match the manual translation map")

    translations: dict[str, str] = {}
    translations.update(body)
    translations.update(notes)
    for uid, data in figure_data.items():
        translations[uid] = data["caption_translation"].strip()
    translations["01_cover-0001"] = COVER_TRANSLATION
    translations["notes-0002"] = NOTES_HEADING
    for unit in source_units:
        if unit["kind"] == "note_group_heading":
            translations[unit["id"]] = NOTE_GROUP_TRANSLATIONS[unit["source_text"]]

    # Structural layout verification against source.
    mismatches = []
    for uid, text in translations.items():
        src = by_id[uid]
        if structural_tokens(src["source_text"]) != structural_tokens(text):
            mismatches.append(
                {
                    "unit": uid,
                    "source": structural_tokens(src["source_text"]),
                    "translation": structural_tokens(text),
                }
            )
    if mismatches:
        raise ValueError("structural token mismatches:\n" + json.dumps(mismatches[:10], ensure_ascii=False, indent=2))

    # Apply statuses. Planned units: 851 body + 853 notes + 4 figures + 10 notes
    # apparatus + 1 cover = 1,719. All 993 index units and the 28 non-index
    # structural/toc units are retained/excluded with an explicit reason.
    out = []
    for unit in source_units:
        rec = dict(unit)
        uid = rec["id"]
        if rec["section"] == "index":
            rec["translation"] = ""
            rec["status"] = "excluded"
            rec["translated"] = False
            rec["status_reason"] = "source-language index rebuilt in full from 18_Index.xhtml; entries not translated"
        elif rec["kind"] == "pagebreak":
            rec["translation"] = ""
            rec["status"] = "excluded"
            rec["translated"] = False
            rec["status_reason"] = "structural page marker rendered in place; no translation needed"
        elif rec["kind"] == "toc_entry":
            rec["translation"] = ""
            rec["status"] = "excluded"
            rec["translated"] = False
            rec["status_reason"] = "source contents entry replaced by the generated translated TOC"
        elif uid in translations:
            text = translations[uid]
            if not text:
                raise ValueError(f"empty translation for {uid}")
            rec["translation"] = text
            rec["status"] = "translated"
            rec["translated"] = True
            rec["status_reason"] = "draft translation; semantic review not performed"
        else:
            raise ValueError(f"unaccounted unit {uid} ({rec['kind']}, section {rec['section']})")
        out.append(rec)

    # All source units must be accounted for exactly once and in source order.
    if [u["id"] for u in out] != [u["id"] for u in source_units]:
        raise ValueError("canonical unit order changed")

    counts = Counter()
    for rec in out:
        counts[(rec["status"], rec["section"], rec["kind"])] += 1
    status_counts = Counter(rec["status"] for rec in out)
    if status_counts != {"translated": 1719, "excluded": 1033}:
        raise ValueError(f"unexpected status counts: {status_counts}")
    if len(translations) != 1719:
        raise ValueError(f"unexpected translation count: {len(translations)}")

    out_path = TRANSLATION / "translation_units.jsonl"
    with out_path.open("w", encoding="utf-8", newline="\n") as fh:
        for rec in out:
            fh.write(json.dumps(rec, ensure_ascii=False) + "\n")

    excluded = [r for r in out if r["status"] == "excluded"]
    excluded_counts = {
        "index_units_rebuilt": sum(1 for r in excluded if r["section"] == "index"),
        "non_index_pagebreak_units_rendered": sum(
            1 for r in excluded if r["section"] != "index" and r["kind"] == "pagebreak"
        ),
        "toc_entry_units_replaced": sum(
            1 for r in excluded if r["section"] != "index" and r["kind"] == "toc_entry"
        ),
        "all_pagebreak_units_including_index": sum(1 for r in out if r["kind"] == "pagebreak"),
        "total": len(excluded),
    }
    if (
        excluded_counts["index_units_rebuilt"]
        + excluded_counts["non_index_pagebreak_units_rendered"]
        + excluded_counts["toc_entry_units_replaced"]
        != excluded_counts["total"]
    ):
        raise ValueError(f"excluded counts do not add up: {excluded_counts}")

    report = {
        "status": "draft translation applied; semantic review not performed",
        "source_epub": "The Alibi of Capital How We Broke the Earth to Steal the Future on the Promise of a Better Tomorrow (Timothy Mitchell).epub",
        "canonical_units": len(out),
        "status_counts": dict(status_counts),
        "translated_counts": {
            "body_text_units": len(body),
            "notes": len(notes),
            "figures": len(figure_data),
            "notes_apparatus_headings": 1 + len(NOTE_GROUP_TRANSLATIONS),
            "cover": 1,
            "total": len(translations),
        },
        "excluded_counts": excluded_counts,
        "structural_validation": {
            "checked_units": len(translations),
            "mismatches": 0,
            "note": "P/N/IMG/L/X/B tokens match source order; italic typography may use Chinese title punctuation or Markdown emphasis in the body.",
        },
        "source_language_content": {
            "index": "full English index rebuilt by build_output.py from OEBPS/xhtml/18_Index.xhtml",
            "index_page_markers": "371-388",
        },
        "hashes": {
            "translation_units_jsonl_sha256": sha256(out_path),
        },
    }
    report_path = TRANSLATION / "translation_apply_report.json"
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
