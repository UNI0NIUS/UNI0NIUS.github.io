#!/usr/bin/env python3
"""Assemble the Chinese draft Markdown and verify source structure.

The EPUB is never modified. This script reads canonical translation units,
rebuilds the English index directly from the EPUB, copies the six source
images, writes output/, and records structural checks in build_report.json.

Semantic proofreading, publication, deployment and online verification are
explicitly out of scope.
"""
from __future__ import annotations

import hashlib
import json
import re
import shutil
from collections import Counter, OrderedDict
from pathlib import Path

from bs4 import BeautifulSoup, NavigableString, Tag

ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / "work"
SOURCE = WORK / "source"
TRANSLATION = WORK / "translation"
OUTPUT = ROOT / "output"
OUTPUT_IMAGES = OUTPUT / "images"
EPUB = ROOT / (
    "The Alibi of Capital How We Broke the Earth to Steal the Future "
    "on the Promise of a Better Tomorrow (Timothy Mitchell).epub"
)
OUTPUT_NAME = "The_Alibi_of_Capital_资本的托词_初译稿.md"
OUTPUT_MD = OUTPUT / OUTPUT_NAME
UNITS_PATH = TRANSLATION / "translation_units.jsonl"
MANIFEST_PATH = SOURCE / "source_manifest.json"
FIGURE_PATH = TRANSLATION / "figure_translations.json"
REPORT_PATH = TRANSLATION / "build_report.json"

TOKEN = re.compile(
    r"\{\{/(?:I|B|L|X)\}\}|\{\{(?:P|N|I|B|L|X|IMG)(?::[^}]*)?\}\}"
)
PAGE_MARKER_RE = re.compile(r"〔原书第([^〕]+?)页(（空白页）)?〕")
INTERNAL_LINK_RE = re.compile(r"\]\(#([^)]+)\)")
ANCHOR_RE = re.compile(r'<a id="([^"]+)"></a>')
NOTE_ID_RE = re.compile(r"^note-(int|ch[1-8])-(\d{3})$")

IMAGE_NAMES = {
    "cover.jpg",
    "logo.jpg",
    "ufig_1.jpg",
    "ufig_2.jpg",
    "ufig_3.jpg",
    "ufig_4.jpg",
}

X_TARGETS = {
    "08_Introduction.xhtml": "#introduction",
    "09_Chapter01.xhtml": "#ch01",
    "10_Chapter02.xhtml": "#ch02",
    "11_Chapter03.xhtml": "#ch03",
    "12_Chapter04.xhtml": "#ch04",
    "13_Chapter05.xhtml": "#ch05",
    "14_Chapter06.xhtml": "#ch06",
    "15_Chapter07.xhtml": "#ch07",
    "16_Chapter08.xhtml": "#ch08",
    "fig1": "#fig1",
    "fig2": "#fig2",
    "fig3": "#fig3",
    "fig4": "#fig4",
}

SECTION_ANCHORS = {
    "acknowledgements": "acknowledgements",
    "introduction": "introduction",
    "ch01": "ch01",
    "ch02": "ch02",
    "ch03": "ch03",
    "ch04": "ch04",
    "ch05": "ch05",
    "ch06": "ch06",
    "ch07": "ch07",
    "ch08": "ch08",
    "notes": "notes",
    "index": "index",
}

FIGURE_ANCHORS = {
    "ch02-fig01": "fig1",
    "ch02-fig02": "fig2",
    "ch02-fig03": "fig3",
    "ch02-fig04": "fig4",
}

TOC_SECTIONS = [
    "acknowledgements",
    "introduction",
    "ch01",
    "ch02",
    "ch03",
    "ch04",
    "ch05",
    "ch06",
    "ch07",
    "ch08",
    "notes",
    "index",
]

EXPECTED_HEADING_NUMBERS = {
    "frontmatter": 3,
    "acknowledgements": 1,
    "introduction": 5,
    "ch01": 9,
    "ch02": 10,
    "ch03": 10,
    "ch04": 11,
    "ch05": 8,
    "ch06": 7,
    "ch07": 7,
    "ch08": 8,
    "notes": 1,
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.open(encoding="utf-8")]


def note_number(note_id: str) -> int:
    match = NOTE_ID_RE.fullmatch(note_id)
    if not match:
        raise ValueError(f"unexpected note id: {note_id}")
    return int(match.group(2))


def escape_alt(text: str) -> str:
    return text.replace("[", r"\[").replace("]", r"\]")


class Builder:
    def __init__(self, units: list[dict], manifest: dict, figure_data: dict, soup: BeautifulSoup):
        self.units = units
        self.manifest = manifest
        self.figure_data = figure_data
        self.soup = soup
        self.by_id = {unit["id"]: unit for unit in units}

        if len(self.by_id) != len(units):
            raise ValueError("duplicate canonical unit ids")

        self.pages = [entry["page"] for entry in manifest["pagebreak_sequence"]]
        self.page_set = set(self.pages)
        if len(self.pages) != 400 or len(self.page_set) != 400:
            raise ValueError(f"source page sequence is not 400 unique pages: {len(self.pages)}")
        self.blank_pages = {
            entry["page"] for entry in manifest["pagebreak_sequence"] if entry["blank"]
        }
        if self.blank_pages != {"ii", "vi", "viii", "xii", "292", "370"}:
            raise ValueError(f"unexpected blank pages: {sorted(self.blank_pages)}")

        notes = [unit for unit in units if unit["kind"] == "note"]
        if len(notes) != 853:
            raise ValueError(f"expected 853 notes, found {len(notes)}")
        self.note_numbers: dict[str, int] = {}
        self.note_group_of: dict[str, str] = {}
        group_order: list[tuple[str, str]] = []
        current_group = None
        current_ids: list[str] = []
        for unit in units:
            if unit["kind"] == "note_group_heading":
                if current_group is not None:
                    group_order.append((current_group, current_ids))
                current_group = unit["id"]
                current_ids = []
            elif unit["kind"] == "note":
                if current_group is None:
                    raise ValueError(f"note before group heading: {unit['id']}")
                current_ids.append(unit["id"])
                self.note_numbers[unit["id"]] = note_number(unit["id"])
                self.note_group_of[unit["id"]] = current_group
        if current_group is not None:
            group_order.append((current_group, current_ids))
        if len(group_order) != 9:
            raise ValueError(f"expected 9 note groups, found {len(group_order)}")
        if len(self.note_numbers) != 853:
            raise ValueError("note id coverage mismatch")
        for group_id, note_ids in group_order:
            numbers = [self.note_numbers[note_id] for note_id in note_ids]
            if numbers != list(range(1, len(numbers) + 1)):
                raise ValueError(f"non-contiguous note numbering in {group_id}")
        self.note_group_order = group_order

        self.note_defs: list[str] = []
        self.note_refs: Counter[str] = Counter()
        self.markers: list[str] = []
        self.marker_context: Counter[str] = Counter()
        self.anchors: set[str] = set()
        self.section_anchors_emitted: set[str] = set()
        self.used_images: set[str] = set()
        self.handled: set[str] = set()
        self.headings: list[tuple[int, str, str, str]] = []
        self.note_group_headings: list[str] = []
        self.figure_ids: list[str] = []
        self.toc_entries: list[dict] = []
        self.toc_skipped = 0
        self.pagebreak_rendered = 0
        self.index_blocks: list[str] = []
        self.index_stats: dict = {}
        self.index_markers: list[str] = []
        self.current_note_group: str | None = None

        # The source index is entirely source-language apparatus. Rebuild it
        # before rendering so its statistics can be cited in the front matter.
        self.index_blocks, self.index_stats, self.index_markers = self.build_index()

        self.toc_entries = self.build_toc()
        self.cover_alt = self.get_cover_alt()
        self.header = self.build_header()
        self.blocks: list[str] = []

    # ------------------------------------------------------------------ text
    def page_marker_text(self, page: str) -> str:
        if page not in self.page_set:
            raise ValueError(f"page marker outside source page list: {page}")
        suffix = "（空白页）" if page in self.blank_pages else ""
        return f"〔原书第{page}页{suffix}〕"

    def record_marker(self, page: str, phase: str) -> str:
        text = self.page_marker_text(page)
        self.markers.append(page)
        self.marker_context[phase] += 1
        return text

    @staticmethod
    def phase_for(section: str) -> str:
        if section == "notes":
            return "notes"
        if section == "index":
            return "index"
        return "body"

    @staticmethod
    def normalize_image_path(payload: str) -> tuple[str, str]:
        if "|" not in payload:
            raise ValueError(f"image token without alt text: {payload!r}")
        path, alt = payload.split("|", 1)
        base = path.replace("\\", "/").split("/")[-1]
        if base not in IMAGE_NAMES:
            raise ValueError(f"unexpected image: {base}")
        alt = alt.strip()
        if not alt:
            raise ValueError(f"empty image alt text: {base}")
        return base, alt

    def add_anchor(self, anchor_id: str) -> None:
        if anchor_id in self.anchors:
            raise ValueError(f"duplicate anchor: {anchor_id}")
        self.anchors.add(anchor_id)

    def render_inline(self, text: str, phase: str) -> str:
        out: list[str] = []
        stack: list[tuple[str, str]] = []
        pos = 0
        for match in TOKEN.finditer(text):
            gap = text[pos : match.start()]
            if "{{" in gap:
                raise ValueError(f"unparsed token before {match.group(0)!r}: {gap!r}")
            out.append(gap)
            token = match.group(0)
            pos = match.end()

            if token == "{{I}}":
                stack.append(("I", "*"))
                out.append("*")
            elif token == "{{/I}}":
                if not stack or stack[-1][0] != "I":
                    raise ValueError("unbalanced italic close")
                stack.pop()
                out.append("*")
            elif token == "{{B}}":
                stack.append(("B", "**"))
                out.append("**")
            elif token == "{{/B}}":
                if not stack or stack[-1][0] != "B":
                    raise ValueError("unbalanced bold close")
                stack.pop()
                out.append("**")
            elif token.startswith("{{X:"):
                target = token[4:-2]
                if target not in X_TARGETS:
                    raise ValueError(f"unmapped cross-reference target: {target}")
                destination = X_TARGETS[target]
                stack.append(("X", destination))
                out.append("[")
            elif token == "{{/X}}":
                if not stack or stack[-1][0] != "X":
                    raise ValueError("unbalanced cross-reference close")
                _, destination = stack.pop()
                out.append(f"]({destination})")
            elif token.startswith("{{L:"):
                destination = token[4:-2]
                if not destination or re.search(r"[\s)]", destination):
                    raise ValueError(f"unsafe link destination: {destination!r}")
                stack.append(("L", destination))
                out.append("[")
            elif token == "{{/L}}":
                if not stack or stack[-1][0] != "L":
                    raise ValueError("unbalanced external-link close")
                _, destination = stack.pop()
                out.append(f"]({destination})")
            elif token.startswith("{{N:"):
                note_id = token[4:-2]
                if note_id not in self.note_numbers:
                    raise ValueError(f"reference to unknown note: {note_id}")
                self.note_refs[note_id] += 1
                out.append(f"[{self.note_numbers[note_id]}](#{note_id})")
            elif token.startswith("{{P:"):
                page = token[4:-2]
                out.append(self.record_marker(page, phase))
            elif token.startswith("{{IMG:"):
                base, alt = self.normalize_image_path(token[6:-2])
                self.used_images.add(base)
                out.append(f"![{escape_alt(alt)}](images/{base})")
            else:
                raise ValueError(f"unhandled token: {token!r}")
        out.append(text[pos:])
        rendered = "".join(out)
        if stack:
            raise ValueError(f"unclosed inline token(s): {stack}")
        if "{{" in rendered or "}}" in rendered:
            raise ValueError(f"unresolved token residue in: {rendered[:160]!r}")
        return rendered

    # ----------------------------------------------------------------- blocks
    def render_heading(self, unit: dict) -> str:
        section = unit["section"]
        text = self.render_inline(unit["translation"], self.phase_for(section)).strip()
        if not text:
            raise ValueError(f"empty heading translation: {unit['id']}")
        source_level = unit.get("level")
        if section in ("frontmatter", "acknowledgements"):
            level = 2
        elif source_level == 2:
            level = 2
        elif source_level == 1:
            level = 1
        else:
            raise ValueError(f"unexpected heading level: {unit['id']} {source_level}")
        anchor = ""
        if section in SECTION_ANCHORS and section not in self.section_anchors_emitted:
            anchor_id = SECTION_ANCHORS[section]
            self.add_anchor(anchor_id)
            self.section_anchors_emitted.add(section)
            anchor = f'<a id="{anchor_id}"></a>\n\n'
        self.headings.append((level, text, section, unit["id"]))
        block = anchor + "#" * level + " " + text
        if unit["id"] == "frontmatter-0029":
            block += "\n\n" + self.toc_markdown()
        return block

    def render_paragraph(self, unit: dict, quote: bool = False) -> str:
        text = self.render_inline(unit["translation"], self.phase_for(unit["section"])).strip()
        if not text:
            raise ValueError(f"empty paragraph translation: {unit['id']}")
        if quote:
            lines = text.split("\n")
            return "\n".join("> " + line if line else ">" for line in lines)
        return text

    def render_pagebreak(self, unit: dict) -> str:
        page = unit.get("page_start")
        source_pages = re.findall(r"\{\{P:([^}]+)\}\}", unit["source_text"])
        if source_pages != [page]:
            raise ValueError(f"standalone pagebreak mismatch in {unit['id']}: {source_pages} vs {page}")
        self.pagebreak_rendered += 1
        return self.record_marker(page, self.phase_for(unit["section"]))

    def render_figure(self, unit: dict) -> str:
        data = self.figure_data[unit["id"]]
        anchor_id = FIGURE_ANCHORS[unit["id"]]
        self.add_anchor(anchor_id)
        self.figure_ids.append(unit["id"])
        image = unit.get("source_image", "")
        if image not in IMAGE_NAMES:
            raise ValueError(f"unexpected figure image: {image}")
        self.used_images.add(image)
        alt = data.get("alt_translation", "").strip()
        caption = data.get("caption_translation", "").strip()
        long_description = data.get("long_description_translation", "").strip()
        if not alt or not caption:
            raise ValueError(f"incomplete figure translation: {unit['id']}")
        if bool(unit.get("source_long_description", "").strip()) != bool(long_description):
            raise ValueError(f"long-description mismatch: {unit['id']}")
        caption_html = self.render_inline(caption, "body")
        block = (
            f'<a id="{anchor_id}"></a>\n\n'
            f"![{escape_alt(alt)}](images/{image})\n\n"
            f"{caption_html}"
        )
        if long_description:
            figure_label = anchor_id.replace("fig", "图")
            block += (
                "\n\n<details>\n"
                f"<summary>{figure_label} 长描述</summary>\n\n"
                f"{long_description}\n\n"
                "</details>"
            )
        return block

    def render_note_group_heading(self, unit: dict) -> str:
        text = self.render_inline(unit["translation"], "notes").strip()
        if not text:
            raise ValueError(f"empty note group heading: {unit['id']}")
        self.current_note_group = unit["id"]
        self.note_group_headings.append(text)
        return "## " + text

    def render_note(self, unit: dict) -> str:
        if self.current_note_group is None:
            raise ValueError(f"note outside group: {unit['id']}")
        body = self.render_inline(unit["translation"], "notes").strip()
        if not body:
            raise ValueError(f"empty note translation: {unit['id']}")
        anchor_id = unit["id"]
        self.add_anchor(anchor_id)
        self.note_defs.append(anchor_id)
        return f'<a id="{anchor_id}"></a>**[{self.note_numbers[anchor_id]}]**　{body}'

    # -------------------------------------------------------------- front matter
    def build_toc(self) -> list[dict]:
        entries = []
        for section in TOC_SECTIONS:
            if section == "index":
                index_start = self.by_id.get("index-0001")
                if index_start is None or index_start.get("page_start") != "371":
                    raise ValueError("unexpected index start page")
                entries.append(
                    {
                        "section": section,
                        "label": "索引（英文原文，未译）",
                        "page": index_start["page_start"],
                    }
                )
                continue
            headings = [
                unit
                for unit in self.units
                if unit["section"] == section
                and unit["kind"] == "heading"
                and unit.get("level") == 1
            ]
            if len(headings) != 1:
                raise ValueError(f"expected one section heading for {section}: {len(headings)}")
            heading = headings[0]
            label = heading["translation"].strip()
            if not label:
                raise ValueError(f"empty TOC label for {section}")
            entries.append({"section": section, "label": label, "page": heading["page_start"]})
        if len(entries) != 12:
            raise ValueError(f"expected 12 TOC entries, found {len(entries)}")
        return entries

    def toc_markdown(self) -> str:
        return "\n\n".join(f'{entry["label"]}　{entry["page"]}' for entry in self.toc_entries)

    def get_cover_alt(self) -> str:
        unit = self.by_id.get("01_cover-0001")
        if unit is None or unit["status"] != "translated":
            raise ValueError("missing translated cover unit")
        tokens = TOKEN.findall(unit["translation"])
        if len(tokens) != 1 or not tokens[0].startswith("{{IMG:cover.jpg|"):
            raise ValueError(f"unexpected cover translation: {unit['translation']!r}")
        base, alt = self.normalize_image_path(tokens[0][6:-2])
        if base != "cover.jpg":
            raise ValueError("cover image mismatch")
        self.used_images.add(base)
        self.handled.add(unit["id"])
        return alt

    def build_header(self) -> str:
        title_unit = self.by_id.get("frontmatter-0005")
        if title_unit is None or not title_unit["translation"].strip():
            raise ValueError("missing translated title page")
        title = title_unit["translation"].strip()
        source = self.manifest["source"]
        iso_date = source["date"]
        year = iso_date.split("-", 1)[0]
        note_count = len(self.note_numbers)
        index_stats = self.index_stats
        explanation = (
            "本稿为全书汉译初稿，依据提供的 EPUB 电子版翻译，收入封面、前置页、"
            f"致谢、导论、八章正文、{len(FIGURE_ANCHORS)} 幅图、全部 {note_count} 条注释"
            "及注释分组标题。原书英文索引保留原文，未翻译。\n\n"
            "原书 EPUB 含完整的 "
            f"{len(self.pages)} 个页位标记，正文中以“〔原书页码〕”在对应位置标示；"
            f"{len(self.blank_pages)} 个空白页另注“（空白页）”。目录据原书条目重排为中文，"
            "所列页码为原书印刷页码。\n\n"
            f"注释按原书 {len(self.note_group_order)} 组编排；正文注号重建为方括号数字，"
            "并可跳转至书末对应注释。图注、图片替代文本以及原书为图 2、图 3 提供的"
            "长描述均已译出。\n\n"
            "原书索引以英文完整重建，共 "
            f"{index_stats['entries']:,} 个条目（{index_stats['top_level']:,} 个主条目、"
            f"{index_stats['nested']:,} 个次级条目）、{index_stats['groups']} 个字母分组、"
            f"{index_stats['page_markers']} 个索引页位；条目文字与页码保持原貌，"
            "索引内部超链接未逐条重建。\n\n"
            "本稿未作语义校对；专名、术语、引文和注释仍待校对。未进行发布、部署或在线核验。"
        )
        return (
            f"# {title}\n\n"
            "**蒂莫西·米切尔（Timothy Mitchell） 著**\n\n"
            "> 原著：Timothy Mitchell, *The Alibi of Capital: How We Broke the Earth "
            "to Steal the Future on the Promise of a Better Tomorrow*, "
            f"London: Verso, {year}. ISBN {source['isbn']}.\n>\n"
            "> 汉译初稿。依据 EPUB 电子版翻译；未校对、未发布。"
            "结构与页位标记已按原书核验。\n\n"
            f"![{escape_alt(self.cover_alt)}](images/cover.jpg)\n\n"
            "## 译稿说明\n\n"
            f"{explanation}"
        )

    # ------------------------------------------------------------------- index
    @staticmethod
    def _index_page_from_span(span: Tag) -> str | None:
        marker_id = span.get("id", "")
        match = re.fullmatch(r"page([ivxlcdm]+|\d+)", marker_id)
        return match.group(1) if match else None

    def _collect_index_markers(self, node: Tag) -> list[str]:
        found: list[str] = []

        def walk(current: Tag) -> None:
            for child in current.children:
                if isinstance(child, NavigableString):
                    continue
                if child.name == "ul":
                    continue
                if child.name == "span" and child.get("epub:type") == "pagebreak":
                    page = self._index_page_from_span(child)
                    if page:
                        found.append(page)
                    continue
                if child.has_attr("hidden"):
                    continue
                walk(child)

        walk(node)
        return found

    @staticmethod
    def _index_entry_text(li: Tag) -> str:
        parts: list[str] = []

        def walk(node: Tag) -> None:
            for child in node.children:
                if isinstance(child, NavigableString):
                    parts.append(str(child))
                elif child.name == "ul":
                    continue
                elif child.name == "span" and child.get("epub:type") == "pagebreak":
                    continue
                elif child.has_attr("hidden"):
                    continue
                elif child.name == "i":
                    parts.append("*")
                    walk(child)
                    parts.append("*")
                else:
                    walk(child)

        walk(li)
        text = "".join(parts)
        text = re.sub(r"\s+", " ", text).strip()
        text = re.sub(r"\s*–\s*", "–", text)
        text = re.sub(r"\s+([,.;:])", r"\1", text)
        text = re.sub(r"\s{2,}", " ", text)
        return text

    def _parse_index_li(self, li: Tag, depth: int) -> dict:
        markers = self._collect_index_markers(li)
        text = self._index_entry_text(li)
        if not text:
            raise ValueError(f"empty index entry: {li.get('id')}")
        children = []
        for sublist in li.find_all("ul", recursive=False):
            for subli in sublist.find_all("li", recursive=False):
                children.append(self._parse_index_li(subli, depth + 1))
        return {"text": text, "markers": markers, "children": children, "depth": depth}

    def _flatten_index_entries(self, entries: list[dict]) -> list[dict]:
        flat = []
        for entry in entries:
            flat.append(entry)
            flat.extend(self._flatten_index_entries(entry["children"]))
        return flat

    def _render_index_entry(self, entry: dict) -> str:
        marker_text = "".join(
            self.page_marker_text(page) for page in entry["markers"]
        )
        line = "  " * entry["depth"] + "- " + marker_text + entry["text"]
        lines = [line]
        for child in entry["children"]:
            lines.append(self._render_index_entry(child))
        return "\n".join(lines)

    def build_index(self) -> tuple[list[str], dict, list[str]]:
        root = self.soup.find("section", attrs={"epub:type": "index"})
        if not root:
            raise ValueError("index section not found in EPUB")
        events: list[tuple[str, object]] = []
        groups = []
        root_markers = 0
        for child in root.children:
            if not isinstance(child, Tag):
                continue
            classes = child.get("class") or []
            if child.name == "div" and "pageNum" in classes:
                for span in child.find_all(attrs={"epub:type": "pagebreak"}):
                    page = self._index_page_from_span(span)
                    if page:
                        events.append(("marker", page))
                        root_markers += 1
            elif child.name == "h1":
                events.append(("h1", child.get_text(" ", strip=True)))
            elif child.name == "section" and child.get("epub:type") == "index-group":
                letter_node = child.find("p", class_="ind-sec")
                if letter_node is None:
                    raise ValueError("index group without letter")
                letter = letter_node.get_text(" ", strip=True)
                list_node = child.find("ul", class_="index1", recursive=False)
                if list_node is None:
                    raise ValueError(f"index group {letter} without entry list")
                entries = [
                    self._parse_index_li(li, 0)
                    for li in list_node.find_all("li", recursive=False)
                ]
                groups.append((letter, entries))
                events.append(("group", (letter, entries)))

        flat_entries = [
            entry
            for _, entries in groups
            for entry in self._flatten_index_entries(entries)
        ]
        top_level = sum(1 for entry in flat_entries if entry["depth"] == 0)
        nested = sum(1 for entry in flat_entries if entry["depth"] == 1)
        if len(flat_entries) != 1496 or top_level != 964 or nested != 532:
            raise ValueError(
                "index count mismatch: "
                f"entries={len(flat_entries)}, top={top_level}, nested={nested}"
            )
        if len(groups) != 25:
            raise ValueError(f"index group count mismatch: {len(groups)}")
        letters = [letter for letter, _ in groups]
        expected_letters = [chr(code) for code in range(ord("A"), ord("Z") + 1) if code != ord("X")]
        if letters != expected_letters:
            raise ValueError(f"unexpected index letters: {letters}")

        markers = [
            page
            for event_type, payload in events
            if event_type == "marker"
            for page in [payload]
        ]
        for _, entries in groups:
            for entry in self._flatten_index_entries(entries):
                markers.extend(entry["markers"])
        # Marker order must be reconstructed from rendering order, not this
        # flattened approximation: root markers P379/P383 fall between groups.
        ordered_markers: list[str] = []
        for event_type, payload in events:
            if event_type == "marker":
                ordered_markers.append(str(payload))
            elif event_type == "group":
                _, entries = payload
                for entry in self._flatten_index_entries(entries):
                    ordered_markers.extend(entry["markers"])
        if len(ordered_markers) != 18:
            raise ValueError(f"index page-marker count mismatch: {len(ordered_markers)}")
        expected_index_pages = [str(page) for page in range(371, 389)]
        if ordered_markers != expected_index_pages:
            raise ValueError(f"index page-marker sequence mismatch: {ordered_markers}")
        if root_markers != 3:
            raise ValueError(f"index root page markers mismatch: {root_markers}")

        stats = {
            "source_units": sum(1 for unit in self.units if unit["section"] == "index"),
            "entries": len(flat_entries),
            "top_level": top_level,
            "nested": nested,
            "groups": len(groups),
            "group_letters": letters,
            "page_markers": len(ordered_markers),
            "page_markers_sequence": ordered_markers,
            "root_page_markers": root_markers,
            "italic_runs": len(root.find_all("i")),
        }

        # Render after stats are available for the explanatory note.
        blocks: list[str] = []
        rendered_markers: list[str] = []
        h1_seen = False
        for event_type, payload in events:
            if event_type == "marker":
                page = str(payload)
                blocks.append(self.page_marker_text(page))
                rendered_markers.append(page)
            elif event_type == "h1":
                if h1_seen:
                    raise ValueError("duplicate index h1")
                h1_seen = True
                self.add_anchor("index")
                self.section_anchors_emitted.add("index")
                note = (
                    f"> 本索引为原书英文索引的完整重建，未逐条翻译；共 "
                    f"{stats['entries']:,} 个条目，其中主条目 {stats['top_level']:,} 个、"
                    f"次级条目 {stats['nested']:,} 个，按 {stats['groups']} 个字母分组编排。"
                    "条目文字、页码与斜体均保留原书形式；原书索引内部的超链接未逐条重建，"
                    "页码仅作阅读定位。"
                )
                blocks.append(f'<a id="index"></a>\n\n# 索引（英文原文，未译）\n\n{note}')
            elif event_type == "group":
                letter, entries = payload
                bullets = "\n".join(self._render_index_entry(entry) for entry in entries)
                blocks.append(f"## {letter}\n\n{bullets}")
                for entry in self._flatten_index_entries(entries):
                    rendered_markers.extend(entry["markers"])
        if not h1_seen:
            raise ValueError("index heading missing")
        if rendered_markers != expected_index_pages:
            raise ValueError(f"rendered index marker sequence mismatch: {rendered_markers}")
        stats["markers_rendered"] = len(rendered_markers)
        stats["markers_render_order"] = rendered_markers
        return blocks, stats, rendered_markers

    # -------------------------------------------------------------------- build
    def build(self) -> tuple[str, dict]:
        index_unit_ids = {unit["id"] for unit in self.units if unit["section"] == "index"}
        body_units = [unit for unit in self.units if unit["section"] != "index"]
        # Verify the index is the final section block.
        seen_index = False
        for unit in self.units:
            if unit["section"] == "index":
                seen_index = True
            elif seen_index:
                raise ValueError("non-index unit found after index units")

        for unit in body_units:
            uid = unit["id"]
            if uid == "01_cover-0001":
                # Rendered in the generated header; still count it as handled.
                continue
            kind = unit["kind"]
            if unit["status"] == "translated" and not unit["translation"].strip():
                raise ValueError(f"translated unit without text: {uid}")
            if kind == "pagebreak":
                block = self.render_pagebreak(unit)
            elif kind == "toc_entry":
                self.toc_skipped += 1
                self.handled.add(uid)
                continue
            elif kind == "heading":
                block = self.render_heading(unit)
            elif kind == "paragraph":
                block = self.render_paragraph(unit)
            elif kind == "quote":
                block = self.render_paragraph(unit, quote=True)
            elif kind == "figure":
                block = self.render_figure(unit)
            elif kind == "note_group_heading":
                block = self.render_note_group_heading(unit)
            elif kind == "note":
                block = self.render_note(unit)
            elif kind == "image":
                raise ValueError(f"unexpected non-cover image unit: {uid}")
            else:
                raise ValueError(f"unhandled unit kind {kind}: {uid}")
            if not block.strip():
                raise ValueError(f"empty output block: {uid}")
            self.blocks.append(block)
            self.handled.add(uid)

        # Mark every source index unit handled by the full index rebuild.
        for uid in index_unit_ids:
            self.handled.add(uid)

        # Append the rebuilt source-language index at the source position.
        self.blocks.extend(self.index_blocks)
        for page in self.index_markers:
            self.markers.append(page)
            self.marker_context["index"] += 1

        if self.handled != set(self.by_id):
            missing = sorted(set(self.by_id) - self.handled)
            raise ValueError(f"unhandled canonical units: {missing[:20]} ({len(missing)})")

        content = "\n\n".join([self.header] + self.blocks) + "\n"

        checks = self.validate(content)
        return content, checks

    # --------------------------------------------------------------- validation
    def validate(self, content: str) -> dict:
        checks: dict[str, object] = {}

        # Page markers: exact source sequence, no missing/extra/reordering.
        rendered_pages = [match.group(1) for match in PAGE_MARKER_RE.finditer(content)]
        if rendered_pages != self.pages:
            mismatch_at = next(
                (
                    index
                    for index, (left, right) in enumerate(zip(rendered_pages, self.pages))
                    if left != right
                ),
                min(len(rendered_pages), len(self.pages)),
            )
            raise ValueError(
                "page marker sequence mismatch at "
                f"{mismatch_at}: got {rendered_pages[:mismatch_at + 3]}, "
                f"expected {self.pages[:mismatch_at + 3]} "
                f"(counts {len(rendered_pages)}/{len(self.pages)})"
            )
        if self.markers != self.pages:
            raise ValueError("internal page marker sequence does not match source")
        blank_markers = [
            match.group(1) for match in PAGE_MARKER_RE.finditer(content) if match.group(2)
        ]
        if set(blank_markers) != self.blank_pages or len(blank_markers) != 6:
            raise ValueError(f"blank-page annotations mismatch: {blank_markers}")
        if self.pagebreak_rendered != 28:
            raise ValueError(f"standalone pagebreak mismatch: {self.pagebreak_rendered}")
        checks["page_markers"] = {
            "expected": len(self.pages),
            "rendered": len(rendered_pages),
            "sequence_matches": True,
            "blank_pages": sorted(self.blank_pages),
            "blank_annotations": len(blank_markers),
            "standalone_rendered": self.pagebreak_rendered,
            "context_counts": dict(self.marker_context),
        }

        # Note definitions and references.
        if len(self.note_defs) != 853 or len(set(self.note_defs)) != 853:
            raise ValueError(f"note definition count mismatch: {len(self.note_defs)}")
        if set(self.note_defs) != set(self.note_numbers):
            raise ValueError("note definition set mismatch")
        if set(self.note_refs) != set(self.note_numbers):
            missing = sorted(set(self.note_numbers) - set(self.note_refs))
            extra = sorted(set(self.note_refs) - set(self.note_numbers))
            raise ValueError(f"note reference set mismatch: missing={missing[:10]}, extra={extra[:10]}")
        duplicate_refs = {note_id: count for note_id, count in self.note_refs.items() if count != 1}
        if duplicate_refs:
            raise ValueError(f"note references are not exactly once: {duplicate_refs}")
        if sum(self.note_refs.values()) != 853:
            raise ValueError(f"note reference count mismatch: {sum(self.note_refs.values())}")
        note_anchors = [anchor for anchor in self.anchors if anchor.startswith("note-")]
        if len(note_anchors) != 853:
            raise ValueError(f"note anchor count mismatch: {len(note_anchors)}")
        checks["notes"] = {
            "definitions": len(self.note_defs),
            "references": sum(self.note_refs.values()),
            "unique_note_ids": len(self.note_numbers),
            "groups": len(self.note_group_order),
            "group_headings": self.note_group_headings,
            "orphans": 0,
        }

        # Headings and section anchors.
        if len(self.headings) != 77:
            raise ValueError(f"output source headings mismatch: {len(self.headings)}")
        if len(self.section_anchors_emitted) != 12:
            raise ValueError(f"section anchor mismatch: {sorted(self.section_anchors_emitted)}")
        h1_headings = [text for level, text, _, _ in self.headings if level == 1]
        expected_h1 = [
            self.by_id["introduction-0002"]["translation"].strip(),
            *[
                self.by_id[f"ch{number:02d}-0002"]["translation"].strip()
                for number in range(1, 9)
            ],
            self.by_id["notes-0002"]["translation"].strip(),
        ]
        if h1_headings != expected_h1:
            raise ValueError(f"chapter H1 order mismatch: {h1_headings}")
        if len(re.findall(r"^# ", content, flags=re.M)) != 12:
            raise ValueError("rendered H1 count mismatch")
        checks["headings"] = {
            "translated_source_headings": len(self.headings),
            "generated_h1_title": 1,
            "source_h1_count": len(h1_headings),
            "h1_order": h1_headings,
            "section_anchors": sorted(self.section_anchors_emitted),
            "note_group_h2": len(self.note_group_headings),
            "index_group_h2": self.index_stats["groups"],
        }

        # TOC and links.
        if len(self.toc_entries) != 12 or self.toc_skipped != 12:
            raise ValueError(
                f"TOC mismatch: generated={len(self.toc_entries)}, skipped={self.toc_skipped}"
            )
        toc_pages = [entry["page"] for entry in self.toc_entries]
        if toc_pages != ["ix", "1", "21", "55", "94", "136", "176", "204", "239", "261", "293", "371"]:
            raise ValueError(f"TOC page numbers mismatch: {toc_pages}")
        toc_text = self.toc_markdown()
        if toc_text not in content:
            raise ValueError("generated TOC not found in output")
        checks["toc"] = {
            "entries": len(self.toc_entries),
            "replaced_source_entries": self.toc_skipped,
            "pages": toc_pages,
        }

        anchors = ANCHOR_RE.findall(content)
        if len(anchors) != len(set(anchors)):
            duplicate = [anchor for anchor, count in Counter(anchors).items() if count > 1]
            raise ValueError(f"duplicate HTML anchors: {duplicate}")
        if set(anchors) != self.anchors:
            raise ValueError(
                f"anchor set mismatch: missing={sorted(self.anchors - set(anchors))[:10]}, "
                f"extra={sorted(set(anchors) - self.anchors)[:10]}"
            )
        internal_links = INTERNAL_LINK_RE.findall(content)
        internal_counter = Counter(internal_links)
        if sum(internal_counter.values()) != 940:
            raise ValueError(f"internal link count mismatch: {sum(internal_counter.values())}")
        note_link_count = sum(count for target, count in internal_counter.items() if target.startswith("note-"))
        if note_link_count != 853:
            raise ValueError(f"internal note-link count mismatch: {note_link_count}")
        if any(target.startswith("fig") for target in internal_counter) is False:
            raise ValueError("no figure cross-reference links")
        unknown_targets = sorted(set(internal_links) - set(anchors))
        if unknown_targets:
            raise ValueError(f"internal links without anchors: {unknown_targets}")
        figure_refs = sum(
            count for target, count in internal_counter.items() if re.fullmatch(r"fig[1-4]", target)
        )
        chapter_refs = sum(
            count for target, count in internal_counter.items() if re.fullmatch(r"ch\d{2}|introduction", target)
        )
        checks["links_and_anchors"] = {
            "html_anchors": len(anchors),
            "internal_links": sum(internal_counter.values()),
            "note_links": note_link_count,
            "figure_links": figure_refs,
            "chapter_or_intro_links": chapter_refs,
            "unresolved_targets": 0,
        }

        # Figures and images.
        if len(self.figure_ids) != 4 or len(set(self.figure_ids)) != 4:
            raise ValueError(f"figure count mismatch: {self.figure_ids}")
        figure_anchors = sorted(FIGURE_ANCHORS.values())
        for anchor_id in figure_anchors:
            if anchor_id not in anchors:
                raise ValueError(f"missing figure anchor: {anchor_id}")
        if content.count("<details>") != 2 or content.count("</details>") != 2:
            raise ValueError("long-description details count mismatch")
        image_links = re.findall(r"!\[[^\]]*\]\((images/[^)]+)\)", content)
        if len(image_links) != 6:
            raise ValueError(f"image reference count mismatch: {image_links}")
        if set(Path(path).name for path in image_links) != IMAGE_NAMES:
            raise ValueError(f"image reference set mismatch: {sorted(set(image_links))}")
        if self.used_images != IMAGE_NAMES:
            raise ValueError(f"used image set mismatch: {sorted(self.used_images)}")
        for image_path in image_links:
            if not (OUTPUT / image_path).is_file():
                raise ValueError(f"missing output image: {image_path}")
        checks["figures_and_images"] = {
            "figures": len(self.figure_ids),
            "figure_anchors": figure_anchors,
            "long_descriptions": 2,
            "image_references": len(image_links),
            "images": sorted(IMAGE_NAMES),
        }

        # Index.
        index_stats = self.index_stats
        if index_stats["entries"] != 1496 or index_stats["groups"] != 25:
            raise ValueError("index statistics mismatch")
        bullet_lines = re.findall(r"^(?:  )?- .*$", content, flags=re.M)
        if len(bullet_lines) != 1496:
            raise ValueError(f"rendered index bullet count mismatch: {len(bullet_lines)}")
        top_bullets = sum(1 for line in bullet_lines if line.startswith("- "))
        nested_bullets = sum(1 for line in bullet_lines if line.startswith("  - "))
        if top_bullets != 964 or nested_bullets != 532:
            raise ValueError(
                f"index nesting count mismatch: top={top_bullets}, nested={nested_bullets}"
            )
        index_section = content.split("# 索引（英文原文，未译）", 1)
        if len(index_section) != 2:
            raise ValueError("index heading not found")
        index_tail = index_section[1]
        index_pages = [match.group(1) for match in PAGE_MARKER_RE.finditer(index_tail)]
        if index_pages != [str(page) for page in range(372, 389)]:
            raise ValueError(f"index page markers in output mismatch: {index_pages}")
        if "〔原书第371页〕" not in content.rsplit("# 索引（英文原文，未译）", 1)[0]:
            raise ValueError("index opening page marker missing before index heading")
        checks["index"] = {
            **index_stats,
            "rendered_bullets": len(bullet_lines),
            "rendered_top_level": top_bullets,
            "rendered_nested": nested_bullets,
            "source_index_units_accounted": sum(
                1 for unit in self.units if unit["section"] == "index"
            ),
            "untranslated": True,
        }

        # Token and text hygiene.
        if "{{" in content or "}}" in content:
            raise ValueError("unresolved token braces remain in output")
        if "@@UNIT" in content or "@@N" in content:
            raise ValueError("internal unit marker leaked into output")
        if "\x00" in content or "﻿" in content:
            raise ValueError("control character or BOM in output")
        if "\r" in content:
            raise ValueError("carriage return in output")
        if content.count("*") % 2 != 0:
            raise ValueError("unbalanced Markdown asterisks")
        if content.count("<!--") != content.count("-->"):
            raise ValueError("unbalanced HTML comments")
        if "@@" in content:
            raise ValueError("unexpected @@ in output")
        checks["text_hygiene"] = {
            "unresolved_tokens": 0,
            "unexpected_unit_markers": 0,
            "bom_or_nul": 0,
            "asterisk_count": content.count("*"),
        }

        # Status accounting across all 2,752 canonical units.
        status_counts = Counter(unit["status"] for unit in self.units)
        if status_counts != {"translated": 1719, "excluded": 1033}:
            raise ValueError(f"unexpected status counts: {status_counts}")
        if len(self.units) != 2752:
            raise ValueError(f"canonical unit count mismatch: {len(self.units)}")
        translated_units = [unit for unit in self.units if unit["status"] == "translated"]
        excluded_units = [unit for unit in self.units if unit["status"] != "translated"]
        if len(translated_units) != 1719 or len(excluded_units) != 1033:
            raise ValueError("unit status accounting mismatch")
        source_index_units = sum(1 for unit in self.units if unit["section"] == "index")
        non_index_pagebreaks = sum(
            1
            for unit in self.units
            if unit["kind"] == "pagebreak" and unit["section"] != "index"
        )
        toc_units = sum(1 for unit in self.units if unit["kind"] == "toc_entry")
        if source_index_units + non_index_pagebreaks + toc_units != 1033:
            raise ValueError("excluded accounting mismatch")
        checks["coverage"] = {
            "source_units": len(self.units),
            "translated_units_included": len(translated_units),
            "excluded_units_accounted": len(excluded_units),
            "excluded_breakdown": {
                "index_units_rebuilt": source_index_units,
                "non_index_pagebreak_units_rendered": non_index_pagebreaks,
                "toc_units_replaced_by_generated_toc": toc_units,
            },
            "handled_unit_ids": len(self.handled),
            "unaccounted_units": 0,
        }

        return checks


def copy_images(manifest: dict) -> dict:
    OUTPUT_IMAGES.mkdir(parents=True, exist_ok=True)
    expected = {Path(item["path"]).name: item for item in manifest["images"]}
    if set(expected) != IMAGE_NAMES:
        raise ValueError(f"manifest image set mismatch: {sorted(expected)}")
    hashes = {}
    for name in sorted(IMAGE_NAMES):
        source_path = SOURCE / "images" / name
        if not source_path.is_file():
            raise ValueError(f"missing source image: {source_path}")
        source_hash = sha256(source_path)
        if source_hash != expected[name]["sha256"]:
            raise ValueError(f"source image hash mismatch: {name}")
        target_path = OUTPUT_IMAGES / name
        shutil.copy2(source_path, target_path)
        target_hash = sha256(target_path)
        if target_hash != source_hash:
            raise ValueError(f"copied image hash mismatch: {name}")
        hashes[name] = target_hash
    if set(path.name for path in OUTPUT_IMAGES.iterdir() if path.is_file()) != IMAGE_NAMES:
        raise ValueError("unexpected files in output/images")
    return hashes


def main() -> None:
    manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    units = load_jsonl(UNITS_PATH)
    figure_data = json.loads(FIGURE_PATH.read_text(encoding="utf-8"))
    source_epub_hash = sha256(EPUB)
    if source_epub_hash != manifest["source"]["source_sha256"]:
        raise ValueError("source EPUB hash changed")

    import zipfile

    with zipfile.ZipFile(EPUB) as archive:
        index_html = archive.read("OEBPS/xhtml/18_Index.xhtml").decode("utf-8")
    soup = BeautifulSoup(index_html, "html.parser")

    OUTPUT.mkdir(parents=True, exist_ok=True)
    image_hashes = copy_images(manifest)
    builder = Builder(units, manifest, figure_data, soup)
    content, checks = builder.build()

    with OUTPUT_MD.open("w", encoding="utf-8", newline="\n") as handle:
        handle.write(content)

    output_hash = sha256(OUTPUT_MD)
    report = {
        "status": "draft assembled; structural checks passed; semantic review not performed",
        "generated_at": "2026-10-23",
        "output": {
            "path": str(OUTPUT_MD.relative_to(ROOT)).replace("\\", "/"),
            "bytes": OUTPUT_MD.stat().st_size,
            "characters": len(content),
            "lines": content.count("\n"),
            "sha256": output_hash,
        },
        "source": {
            "path": manifest["source"]["source_file"],
            "sha256": source_epub_hash,
            "pages": manifest["source"]["epub_page_count"],
            "notes": manifest["source"]["endnote_count"],
        },
        "canonical_data": {
            "path": str(UNITS_PATH.relative_to(ROOT)).replace("\\", "/"),
            "units": len(units),
            "sha256": sha256(UNITS_PATH),
        },
        "images": image_hashes,
        "checks": checks,
        "status_fields": {
            "source_coverage": "verified",
            "translation": "complete_draft",
            "semantic_review": "not_performed",
            "layout": "markdown_structure_verified",
            "web_export": "not_performed",
            "publication": "not_performed",
            "online_verification": "not_performed",
        },
        "known_limitations": [
            "No semantic proofreading or copyediting was performed.",
            "The English index is retained untranslated; its internal hyperlinks were not individually rebuilt.",
            "The Markdown page markers preserve EPUB page positions, not physical pagination of this file.",
            "No publication, deployment, web export, git operation or online verification was performed.",
        ],
    }
    REPORT_PATH.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
