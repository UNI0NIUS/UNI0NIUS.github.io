#!/usr/bin/env python3
"""Extract The Alibi of Capital EPUB into traceable source units.

The EPUB supplies a pageList and inline doc-pagebreak markers.  This script
preserves those markers as {{P:...}} tokens, note anchors as {{N:...}} tokens,
and inline italics/links as lightweight tokens so a translation can retain
the source structure without copying presentation markup blindly.

Outputs:
  work/source/source_units.jsonl
  work/source/source_units_by_section/*.txt
  work/source/notes_map.json
  work/source/source_manifest.json
  work/source/images/*
"""
from __future__ import annotations

import hashlib
import json
import re
import shutil
import warnings
import zipfile
from collections import Counter
from pathlib import Path
from urllib.parse import unquote

from bs4 import BeautifulSoup, NavigableString, Tag, XMLParsedAsHTMLWarning

warnings.filterwarnings("ignore", category=XMLParsedAsHTMLWarning)

ROOT = Path(__file__).resolve().parents[2]
EPUB = ROOT / "The Alibi of Capital How We Broke the Earth to Steal the Future on the Promise of a Better Tomorrow (Timothy Mitchell).epub"
OUT = ROOT / "work" / "source"
SECTION_DIR = OUT / "source_units_by_section"
IMAGE_DIR = OUT / "images"

SECTION_META = {
    "02_Half_Title": ("frontmatter", "half_title"),
    "03_Titlepage": ("frontmatter", "title_page"),
    "04_Copyright": ("frontmatter", "copyright"),
    "05_Dedication": ("frontmatter", "dedication"),
    "06_Contents": ("frontmatter", "contents"),
    "07_Acknowledgments": ("acknowledgements", "acknowledgements"),
    "08_Introduction": ("introduction", "introduction"),
    "09_Chapter01": ("ch01", "chapter 1"),
    "10_Chapter02": ("ch02", "chapter 2"),
    "11_Chapter03": ("ch03", "chapter 3"),
    "12_Chapter04": ("ch04", "chapter 4"),
    "13_Chapter05": ("ch05", "chapter 5"),
    "14_Chapter06": ("ch06", "chapter 6"),
    "15_Chapter07": ("ch07", "chapter 7"),
    "16_Chapter08": ("ch08", "chapter 8"),
    "17_Notes": ("notes", "notes"),
    "18_Index": ("index", "index"),
}

PAGE_TOKEN_RE = re.compile(r"\{\{P:([^}]+)\}\}")
NOTE_TOKEN_RE = re.compile(r"\{\{N:([^}]+)\}\}")

# Block-level tags that should become units or be walked into.
HEADING_TAGS = {"h1", "h2", "h3", "h4", "h5", "h6"}
TEXT_BLOCK_TAGS = {"p", "blockquote", "figcaption"}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def norm_text(s: str) -> str:
    s = s.replace("­", "")  # soft hyphen
    s = s.replace("​", "").replace("﻿", "")
    s = s.replace(" ", " ")
    s = re.sub(r"\s+", " ", s)
    return s.strip()


def note_display_group(target_id: str) -> tuple[str, int] | None:
    """fn12-ch3 -> (ch3, 12), fn1-int -> (int, 1)."""
    m = re.fullmatch(r"fn(\d+)-([a-zA-Z0-9]+)", target_id or "")
    if not m:
        return None
    return m.group(2), int(m.group(1))


def note_id(group: str, number: int) -> str:
    return f"note-{group}-{number:03d}"


def page_label(span: Tag, soup: BeautifulSoup) -> str:
    target_id = span.get("aria-labelledby")
    if target_id:
        el = soup.find(id=target_id)
        if el is not None:
            text = norm_text(el.get_text(" ", strip=True))
            if text:
                return text
    p = span.parent
    if p is not None:
        hidden = p.find("span", attrs={"hidden": "hidden"})
        if hidden is not None:
            text = norm_text(hidden.get_text(" ", strip=True))
            if text:
                return text
        text = norm_text(p.get_text(" ", strip=True))
        if text and re.fullmatch(r"(?:[ivxlcdm]+|\d+)(?:\s+is blank)?", text, re.I):
            return text
    # Last resort: a following hidden label.
    nxt = span.find_next("span", attrs={"hidden": "hidden"})
    if nxt is not None:
        text = norm_text(nxt.get_text(" ", strip=True))
        if text:
            return text
    return ""


def clean_page_number(label: str) -> tuple[str, bool]:
    text = norm_text(label)
    blank = bool(re.search(r"\bis blank\b", text, re.I))
    m = re.match(r"([ivxlcdm]+|\d+)", text, re.I)
    return (m.group(1) if m else text), blank


class Extractor:
    def __init__(self, zf: zipfile.ZipFile, notes_map: dict[str, dict]):
        self.zf = zf
        self.notes_map = notes_map
        self.current_page = ""
        self.units: list[dict] = []
        self.page_sequence: list[dict] = []
        self.errors: list[str] = []
        self.section_counters: Counter[str] = Counter()
        self.figure_count = 0
        self.section = ""
        self.section_label = ""
        self.subsection = ""
        self.current_paragraph = ""
        self.paragraph_counter = Counter()

    # ---------- token serialization ----------
    def render_inline(self, node: Tag | NavigableString, soup: BeautifulSoup) -> str:
        if isinstance(node, NavigableString):
            return norm_text(str(node))
        if not isinstance(node, Tag):
            return ""
        name = node.name.lower()
        classes = set(node.get("class") or [])
        role = node.get("role") or ""

        if role == "doc-pagebreak":
            label = page_label(node, soup)
            page, blank = clean_page_number(label)
            if page:
                self.current_page = page
                self.page_sequence.append({"page": page, "blank": blank, "label": label})
                return f"{{{{P:{page}}}}}"
            self.errors.append(f"Unlabelled pagebreak in {self.section}")
            return ""

        if name == "span" and (node.get("hidden") == "hidden" or node.get("aria-hidden") == "true"):
            return ""

        if name == "sup":
            a = node.find("a", role="doc-noteref")
            if a is not None:
                target = unquote((a.get("href") or "").split("#")[-1])
                meta = self.notes_map.get(target)
                if meta:
                    return f"{{{{N:{meta['id']}}}}}"
                self.errors.append(f"Unknown note anchor {target!r} in {self.section}")
                return f"[^{target}]"
            return "^{" + self._inline_children(node, soup) + "}^"

        if name == "sub":
            return "_{" + self._inline_children(node, soup) + "}_"

        if name in ("i", "em", "cite"):
            inner = self._inline_children(node, soup)
            return f"{{{{I}}}}{inner}{{{{/I}}}}" if inner else ""

        if name in ("b", "strong"):
            inner = self._inline_children(node, soup)
            return f"{{{{B}}}}{inner}{{{{/B}}}}" if inner else ""

        if name == "a":
            inner = self._inline_children(node, soup)
            href = node.get("href") or ""
            if role == "doc-backlink":
                return ""
            if not href:
                return inner
            if href.startswith(("http://", "https://", "mailto:")):
                return f"{{{{L:{href}}}}}{inner}{{{{/L}}}}"
            # Internal links become a lightweight target token; the renderer
            # maps known chapter links and otherwise keeps the visible text.
            target = href.split("#")[-1] if "#" in href else href
            return f"{{{{X:{target}}}}}{inner}{{{{/X}}}}"

        if name == "img":
            src = node.get("src") or ""
            alt = norm_text(node.get("alt") or "")
            return f"{{{{IMG:{src}|{alt}}}}}"

        if name == "br":
            return "\n"

        if name == "span" and "s-small" in classes:
            return self._inline_children(node, soup)

        return self._inline_children(node, soup)

    def _inline_children(self, node: Tag, soup: BeautifulSoup) -> str:
        out = []
        for child in node.children:
            out.append(self.render_inline(child, soup))
        text = "".join(out)
        # Join around tokens without adding spaces inside the marker itself.
        text = re.sub(r"[ \t]+", " ", text)
        text = re.sub(r"\s+([,.;:!?…])", r"\1", text)
        return text.strip()

    def extract_text_blocks(self, container: Tag, soup: BeautifulSoup) -> str:
        """Serialize a paragraph-like container, preserving <br> and tokens."""
        return self._inline_children(container, soup)

    # ---------- unit creation ----------
    def add_unit(
        self,
        kind: str,
        source_text: str,
        *,
        level: int | None = None,
        extra: dict | None = None,
        translated: bool = True,
        source_selector: str = "",
    ) -> dict:
        self.section_counters[self.section] += 1
        idx = self.section_counters[self.section]
        uid = f"{self.section}-{idx:04d}"
        pages = PAGE_TOKEN_RE.findall(source_text)
        notes = NOTE_TOKEN_RE.findall(source_text)
        unit = {
            "id": uid,
            "section": self.section,
            "section_label": self.section_label,
            "subsection": self.subsection,
            "kind": kind,
            "level": level,
            "source_refs": [
                {
                    "file": f"OEBPS/xhtml/{self.current_file}",
                    "selector": source_selector or "",
                }
            ],
            "printed_pages": pages,
            "page_start": pages[0] if pages else (self.current_page or ""),
            "page_end": pages[-1] if pages else (self.current_page or ""),
            "source_text": norm_text(source_text) if "\n" not in source_text else source_text.strip(),
            "source_markup": source_text.strip(),
            "note_refs": notes,
            "translation": "",
            "status": "pending" if translated else "excluded",
            "translated": translated,
        }
        if extra:
            unit.update(extra)
        self.units.append(unit)
        return unit

    # ---------- document walk ----------
    def process_section(self, filename: str, soup: BeautifulSoup) -> None:
        stem = Path(filename).stem
        self.section, self.section_label = SECTION_META.get(stem, (stem.lower(), stem))
        self.current_file = filename
        self.current_page = ""
        self.subsection = ""
        body = soup.find("body")
        if body is None:
            self.errors.append(f"No body: {filename}")
            return

        if self.section == "notes":
            self.process_notes(soup, body)
            return

        def emit_pagebreak_tag(span: Tag, selector: str = "span[role=doc-pagebreak]") -> None:
            markup = f"{{{{P:{self.current_page}}}}}"
            label = page_label(span, soup)
            page, blank = clean_page_number(label)
            if page:
                self.current_page = page
                self.page_sequence.append({"page": page, "blank": blank, "label": label})
                markup = f"{{{{P:{page}}}}}"
            else:
                self.errors.append(f"Unlabelled pagebreak in {self.section}")
                return
            self.add_unit("pagebreak", markup, translated=False, source_selector=selector)

        def walk(el: Tag, quote: bool = False):
            name = el.name.lower() if isinstance(el, Tag) else ""
            classes = set(el.get("class") or []) if isinstance(el, Tag) else set()
            if name == "div" and "pageNum" in classes:
                markup = self.extract_text_blocks(el, soup)
                if markup:
                    self.add_unit("pagebreak", markup, translated=False, source_selector="div.pageNum")
                return
            if (el.get("role") == "doc-pagebreak") or (el.get("epub:type") == "pagebreak"):
                emit_pagebreak_tag(el)
                return
            if el.get("hidden") == "hidden" or el.get("aria-hidden") == "true":
                return
            if name in HEADING_TAGS:
                text = self.extract_text_blocks(el, soup)
                if text:
                    level = int(name[1])
                    if level >= 2:
                        self.subsection = NOTE_TOKEN_RE.sub("", PAGE_TOKEN_RE.sub("", text)).strip()
                    self.add_unit("heading", text, level=level, source_selector=name)
                return
            if name in ("section", "div", "header", "article"):
                for child in el.children:
                    if isinstance(child, Tag):
                        walk(child, quote)
                    elif isinstance(child, NavigableString) and norm_text(str(child)):
                        self.errors.append(f"Loose text in {filename}: {str(child)[:80]!r}")
                return
            if name == "p":
                text = self.extract_text_blocks(el, soup)
                if text:
                    self.add_unit("quote" if quote else "paragraph", text, source_selector="p")
                return
            if name == "blockquote":
                # Keep the quote designation for each paragraph inside.
                inner_ps = el.find_all("p", recursive=False)
                if inner_ps:
                    for p in inner_ps:
                        text = self.extract_text_blocks(p, soup)
                        if text:
                            self.add_unit("quote", text, source_selector="blockquote p")
                else:
                    text = self.extract_text_blocks(el, soup)
                    if text:
                        self.add_unit("quote", text, source_selector="blockquote")
                return
            if name == "figure":
                self.extract_figure(el, soup)
                return
            if name == "ol":
                for li in el.find_all("li", recursive=False):
                    self.extract_toc_entry(li, soup)
                return
            if name == "ul":
                for li in el.find_all("li", recursive=False):
                    text = self.extract_text_blocks(li, soup)
                    if text:
                        self.add_unit("list_item", text, source_selector="li")
                return
            if name == "img":
                src = el.get("src") or ""
                alt = norm_text(el.get("alt") or "")
                self.add_unit("image", f"{{{{IMG:{src}|{alt}}}}}", source_selector="img")
                return
            if name == "nav":
                return
            # Unhandled wrapper with text: walk children.
            if el.find(["p", "h1", "h2", "section", "figure", "blockquote"]):
                for child in el.children:
                    if isinstance(child, Tag):
                        walk(child, quote)
                return
            text = self.extract_text_blocks(el, soup)
            if text:
                self.add_unit("paragraph", text, source_selector=name)

        for child in body.children:
            if isinstance(child, Tag):
                walk(child)

        # The TOC pagebreak before the title should be visible. The source order
        # has the pageNum div before the h1, which walk() preserves.

    def extract_toc_entry(self, li: Tag, soup: BeautifulSoup) -> None:
        a = li.find("a")
        if a is None:
            text = self.extract_text_blocks(li, soup)
            if text:
                self.add_unit("toc_entry", text, translated=False)
            return
        text = self.extract_text_blocks(a, soup)
        href = a.get("href") or ""
        self.add_unit(
            "toc_entry",
            text,
            translated=False,
            extra={"target_file": href.split("#")[0], "target_href": href},
            source_selector="li",
        )
        # The Contents page carries a trailing blank-page marker (viii) after
        # the Index link, outside the anchor. Emit it as its own pagebreak unit.
        for span in li.find_all(
            lambda t: t.name == "span"
            and (t.get("role") == "doc-pagebreak" or t.get("epub:type") == "pagebreak")
        ):
            if a in span.parents:
                continue
            label = page_label(span, soup)
            page, blank = clean_page_number(label)
            if page:
                self.current_page = page
                self.page_sequence.append({"page": page, "blank": blank, "label": label})
                self.add_unit(
                    "pagebreak",
                    f"{{{{P:{page}}}}}",
                    translated=False,
                    source_selector="li span[role=doc-pagebreak]",
                )
            else:
                self.errors.append(f"Unlabelled pagebreak in {self.section}")

    def extract_figure(self, fig: Tag, soup: BeautifulSoup) -> None:
        img = fig.find("img")
        src = img.get("src") if img else ""
        alt = norm_text((img.get("alt") if img else "") or "")
        long_desc = fig.find(class_=re.compile(r"long-desc"))
        caption = fig.find("figcaption")
        # Some EPUB exports put the long description inside div.long-desc-para.
        ld_text = ""
        if long_desc is not None:
            ld_text = self.extract_text_blocks(long_desc, soup)
            if long_desc.name == "div":
                # Avoid the long description leaking into caption.
                pass
        cap_text = self.extract_text_blocks(caption, soup) if caption is not None else ""
        # Caption includes a bare print page number sometimes. Page markers are
        # already tokens; strip a trailing bare number that duplicates metadata.
        cap_text = re.sub(r"\s+\d{1,3}$", "", cap_text).strip()
        self.figure_count += 1
        self.section_counters[self.section] += 1
        uid = f"{self.section}-fig{self.figure_count:02d}"
        pages = PAGE_TOKEN_RE.findall(cap_text)
        unit = {
            "id": uid,
            "section": self.section,
            "section_label": self.section_label,
            "subsection": self.subsection,
            "kind": "figure",
            "level": None,
            "source_refs": [{"file": f"OEBPS/xhtml/{self.current_file}", "selector": "figure"}],
            "printed_pages": pages,
            "page_start": pages[0] if pages else self.current_page,
            "page_end": pages[-1] if pages else self.current_page,
            "source_text": cap_text,
            "source_markup": cap_text,
            "source_image": src,
            "source_alt": alt,
            "source_long_description": ld_text,
            "caption_source": cap_text,
            "caption_translation": "",
            "long_description_translation": "",
            "note_refs": NOTE_TOKEN_RE.findall(cap_text),
            "translation": "",
            "status": "pending",
            "translated": True,
        }
        self.units.append(unit)

    def process_notes(self, soup: BeautifulSoup, body: Tag) -> None:
        # First, show the pagebreak before the Notes heading and the heading.
        for el in body.find_all("div", class_="pageNum", recursive=True):
            markup = self.extract_text_blocks(el, soup)
            if markup:
                self.add_unit("pagebreak", markup, translated=False, source_selector="div.pageNum")
        h1 = body.find("h1")
        if h1 is not None:
            self.add_unit("heading", self.extract_text_blocks(h1, soup), level=1, source_selector="h1")
        for sec in body.select("section[aria-labelledby^='secN_']"):
            h2 = sec.find("h2")
            if h2 is not None:
                self.subsection = norm_text(h2.get_text(" ", strip=True))
                self.add_unit("note_group_heading", self.extract_text_blocks(h2, soup), level=2, source_selector="h2")
            for li in sec.select("ol.endnote-list > li"):
                p = li.find("p")
                if p is None:
                    self.errors.append(f"Note without p in {self.subsection}")
                    continue
                back = p.find("a", role="doc-backlink")
                number = norm_text(back.get_text(" ", strip=True)) if back else ""
                target_id = back.get("id") if back else ""
                if not number and li.get("id"):
                    meta = self.notes_map.get(li.get("id"), {})
                    number = str(meta.get("number", ""))
                group, num = note_display_group(target_id or f"fn{number}-{self.subsection}")
                if group is None:
                    group = self.section
                    num = int(number) if number.isdigit() else 0
                # Serialize note paragraph while skipping the leading backlink.
                parts = []
                for child in p.children:
                    if isinstance(child, Tag) and child.find("a", role="doc-backlink"):
                        # Remove the number link; still process any trailing page labels.
                        continue
                    txt = self.render_inline(child, soup)
                    if txt:
                        parts.append(txt)
                markup = norm_text(" ".join(parts))
                markup = re.sub(r"^\.\s*", "", markup)
                pages = PAGE_TOKEN_RE.findall(markup)
                uid = note_id(group, num) if num else f"{self.section}-n{len(self.units)+1:04d}"
                unit = {
                    "id": uid,
                    "section": self.section,
                    "section_label": self.section_label,
                    "subsection": self.subsection,
                    "kind": "note",
                    "level": None,
                    "note_group": group,
                    "note_number": num,
                    "source_refs": [{"file": f"OEBPS/xhtml/{self.current_file}", "selector": "ol.endnote-list > li > p"}],
                    "printed_pages": pages,
                    "page_start": pages[0] if pages else self.current_page,
                    "page_end": pages[-1] if pages else self.current_page,
                    "source_text": markup,
                    "source_markup": markup,
                    "source_note_target": target_id,
                    "note_refs": [],
                    "translation": "",
                    "status": "pending",
                    "translated": True,
                }
                self.units.append(unit)

    # ---------- validation / persistence ----------
    def validate(self, page_list: list[dict]) -> None:
        seen = [p["page"] for p in self.page_sequence]
        expected = [p["page"] for p in page_list]
        # The notes and index pagebreak spans include all breakpoints; front
        # matter is also complete. A duplicate page number can occur where a
        # page has more than one breakpoint in fixed-layout books, but not here.
        if len(seen) != len(expected):
            self.errors.append(f"Page marker count mismatch: {len(seen)} != {len(expected)}")
        if seen != expected:
            # Report the first divergences rather than dumping 400 values.
            diffs = [(i, a, b) for i, (a, b) in enumerate(zip(seen, expected)) if a != b]
            self.errors.append(f"Page marker sequence differs at {diffs[:12]} (total {len(diffs)})")
        if len(seen) != len(set(seen)):
            dup = [p for p, c in Counter(seen).items() if c > 1]
            self.errors.append(f"Duplicate page markers: {dup}")
        note_ids = [u["id"] for u in self.units if u["kind"] == "note"]
        if len(note_ids) != len(set(note_ids)):
            self.errors.append("Duplicate note IDs")
        refs = []
        for u in self.units:
            refs.extend(u.get("note_refs", []))
        missing = sorted(set(refs) - set(note_ids))
        if missing:
            self.errors.append(f"Note references without a note unit: {missing[:20]}")


def parse_spine(opfsoup: BeautifulSoup) -> list[str]:
    items = {i.get("id"): i.get("href") for i in opfsoup.find_all("item")}
    spine = opfsoup.find("spine")
    return [items[ref.get("idref")] for ref in spine.find_all("itemref")]


def parse_page_list(soup: BeautifulSoup) -> list[dict]:
    out = []
    for pt in soup.find_all("pagetarget"):
        content = pt.find("content")
        label_el = pt.find("navlabel")
        label = norm_text(label_el.get_text(" ", strip=True)) if label_el else ""
        value = norm_text(pt.get("value") or "")
        page, blank = clean_page_number(label or value)
        out.append({"page": page, "blank": blank, "src": content.get("src") if content else ""})
    return out


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    SECTION_DIR.mkdir(parents=True, exist_ok=True)
    IMAGE_DIR.mkdir(parents=True, exist_ok=True)
    for old in SECTION_DIR.glob("*.txt"):
        old.unlink()

    with zipfile.ZipFile(EPUB) as zf:
        opf = BeautifulSoup(zf.read("OEBPS/contents.opf").decode("utf-8", "replace"), "html.parser")
        spine = parse_spine(opf)
        ncx = BeautifulSoup(zf.read("OEBPS/xhtml/toc.ncx").decode("utf-8", "replace"), "html.parser")
        page_list = parse_page_list(ncx)

        # Build the endnote target map before walking body chapters.
        notes_soup = BeautifulSoup(zf.read("OEBPS/xhtml/17_Notes.xhtml").decode("utf-8", "replace"), "html.parser")
        notes_map: dict[str, dict] = {}
        for p in notes_soup.select("p.note, p.note1, p.note2"):
            back = p.find("a", role="doc-backlink")
            if back is None:
                continue
            target_id = back.get("id") or ""
            number_text = norm_text(back.get_text(" ", strip=True))
            group_num = note_display_group(target_id)
            if group_num is None or not number_text.isdigit():
                continue
            group, number = group_num
            nid = note_id(group, number)
            notes_map[target_id] = {
                "id": nid,
                "group": group,
                "number": number,
                "display": number_text,
                "backlink_target": (back.get("href") or "").split("#")[-1],
            }
        if len(notes_map) != 853:
            raise SystemExit(f"Expected 853 note targets, found {len(notes_map)}")

        meta = {
            "title": "The Alibi of Capital",
            "subtitle": "How We Broke the Earth to Steal the Future on the Promise of a Better Tomorrow",
            "author": "Timothy Mitchell",
            "publisher": "Verso Books",
            "date": "2026-01-29",
            "isbn": "978-1-83674-227-2",
            "source_file": EPUB.name,
            "source_sha256": sha256(EPUB),
            "source_bytes": EPUB.stat().st_size,
            "epub_spine": spine,
            "epub_page_count": len(page_list),
            "endnote_count": len(notes_map),
        }

        extractor = Extractor(zf, notes_map)
        for href in spine:
            name = "OEBPS/" + href
            soup = BeautifulSoup(zf.read(name).decode("utf-8", "replace"), "html.parser")
            extractor.process_section(Path(href).name, soup)

        extractor.validate(page_list)

        # Copy referenced images and the cover.
        image_files = []
        for name in zf.namelist():
            if name.startswith("OEBPS/images/") and not name.endswith("/"):
                target = IMAGE_DIR / Path(name).name
                target.write_bytes(zf.read(name))
                image_files.append(
                    {
                        "path": target.relative_to(ROOT).as_posix(),
                        "bytes": target.stat().st_size,
                        "sha256": sha256(target),
                    }
                )

    # Use source-relative image paths in units once files are copied.
    for u in extractor.units:
        for field in ("source_image",):
            src = u.get(field)
            if src:
                u["source_image"] = Path(src).name
        if u.get("source_markup"):
            u["source_markup"] = u["source_markup"].replace("../images/", "")

    with (OUT / "notes_map.json").open("w", encoding="utf-8", newline="\n") as f:
        json.dump(notes_map, f, ensure_ascii=False, indent=2)
        f.write("\n")

    with (OUT / "source_units.jsonl").open("w", encoding="utf-8", newline="\n") as f:
        for u in extractor.units:
            f.write(json.dumps(u, ensure_ascii=False) + "\n")

    by_section: dict[str, list[dict]] = {}
    for u in extractor.units:
        by_section.setdefault(u["section"], []).append(u)
    for section, units in by_section.items():
        lines = []
        current_sub = None
        for u in units:
            if u.get("subsection") != current_sub and u["kind"] == "heading":
                current_sub = u.get("subsection")
            page = u.get("page_start") or ""
            extra = f" page={page}" if page else ""
            lines.append(f"===== {u['id']} [{u['kind']}{extra}] =====")
            lines.append(u.get("source_markup", ""))
            lines.append("")
        (SECTION_DIR / f"{section}.txt").write_text("\n".join(lines), encoding="utf-8", newline="\n")

    counts = Counter(u["kind"] for u in extractor.units)
    section_counts = Counter(u["section"] for u in extractor.units)
    report = {
        "source": meta,
        "epub_pages": len(page_list),
        "page_list_first": page_list[:12],
        "page_list_last": page_list[-12:],
        "pagebreak_sequence": extractor.page_sequence,
        "unit_count": len(extractor.units),
        "kind_counts": dict(counts),
        "section_counts": dict(section_counts),
        "note_refs": sum(len(u.get("note_refs", [])) for u in extractor.units),
        "note_units": counts.get("note", 0),
        "figure_units": counts.get("figure", 0),
        "images": image_files,
        "errors": extractor.errors,
        "status": "extracted",
    }
    with (OUT / "source_manifest.json").open("w", encoding="utf-8", newline="\n") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
        f.write("\n")

    print(json.dumps(
        {
            "source_sha256": meta["source_sha256"],
            "epub_pages": len(page_list),
            "units": len(extractor.units),
            "kinds": dict(counts),
            "sections": dict(section_counts),
            "note_refs": report["note_refs"],
            "note_units": report["note_units"],
            "figures": report["figure_units"],
            "errors": extractor.errors,
        },
        ensure_ascii=False,
        indent=2,
    ))


if __name__ == "__main__":
    main()
