# 资本的托词：校订规范稿与源码

规范稿：work/review/translation_units.jsonl。原初译稿、原 EPUB 与源结构保留，勿运行 work/scripts/apply_translations.py 或 build_output.py 覆盖初稿。

构建环境：Python 3.11+、beautifulsoup4；PDF 使用 XeLaTeX（TeX Live 2025），字体 Times New Roman、SimSun。排版来源为既有 Thinking Art 成品参数；具体记录见 format_baseline.json。

在本书目录依次执行：

```
python work/review/audit_global_structure.py
python work/review/restore_english_spacing.py
python work/review/build_reading_tex.py
python work/review/build_web_markdown.py
cd output/reviewed
xelatex -interaction=nonstopmode -halt-on-error alibi_zh.tex
xelatex -interaction=nonstopmode -halt-on-error alibi_zh.tex
xelatex -interaction=nonstopmode -halt-on-error alibi_bilingual.tex
xelatex -interaction=nonstopmode -halt-on-error alibi_bilingual.tex
```

如目录发生变化，重复对应编译直至 toc 内容稳定。网页 JSON 供既有网站 bilingual-reader.js 消费，链接按网站根目录解析；复制 webdata 内章节文件至 translations/books/alibi，元数据来自 book-metadata.json。不要覆盖其他书目或共享渲染器。

853 条原注、72 条独立校注、400 个原书页位、4 幅正文图及 1496 条英文索引保留。校注披露原作疑点及来源限度。英文显示空白从 EPUB 恢复，规范来源字段未改。原著、图像及其权利声明保留，本译文非出版社官方译本。

一次性语义修订脚本仅作证据，不要重跑；可重复生成入口仅为上述命令。源码包不包含在线发布凭据。bundle_manifest.json 记录每个文件 SHA256。
