import {escapeHtml as e} from './records.js';

const normalized = value => String(value || '').normalize('NFKD').replace(/\p{M}/gu, '').toLowerCase();
export function readingUnits(block) {
  const text = nodes => (Array.isArray(nodes) ? nodes : [nodes]).map(node => typeof node === 'string' ? node : Array.isArray(node) ? text(node) : [node?.tex || '',text(node?.children || []),text(node?.rows || [])].join(' ')).join(' ');
  return Math.max(1,((block.readingText || text(block.en?.length ? block.en : block.zh || [])).match(/[\p{L}\p{N}][\p{L}\p{M}\p{N}'’-]*/gu) || []).length);
}

export function wholeBookProgress(post, chapterId, fraction) {
  const index = Math.max(0,post.chapters.findIndex(chapter=>chapter.id===chapterId));
  const weights = post.chapters.map(chapter=>Math.max(1,chapter.readingUnits || 1));
  return (weights.slice(0,index).reduce((sum,n)=>sum+n,0) + weights[index]*Math.min(1,Math.max(0,fraction || 0))) / weights.reduce((sum,n)=>sum+n,0);
}

export function translationPosition() {
  const blocks = [...document.querySelectorAll('#translation-body > .translation-block')];
  if (!blocks.length) return {fraction:0};
  const total = blocks.reduce((sum,block)=>sum+Number(block.dataset.readingUnits),0);
  const readingLine = 100;
  let completed = 0;
  for (const block of blocks) {
    const rect=block.getBoundingClientRect();
    const within=Math.min(1,Math.max(0,(readingLine-rect.top)/Math.max(1,rect.height)));
    const weight=Number(block.dataset.readingUnits);
    if (rect.bottom > readingLine) {
      const atEnd=window.scrollY>0 && blocks.at(-1).getBoundingClientRect().bottom<=window.innerHeight+2;
      return {blockId:block.id,within, fraction:atEnd ? 1 : (completed+within*weight)/total};
    }
    completed+=weight;
  }
  return {blockId:blocks.at(-1).id,within:1,fraction:1};
}

export function restoreTranslationPosition(position) {
  if (!position?.blockId || position.fraction===0) return;
  const block=document.getElementById(position.blockId);
  if (!block) return;
  const rect=block.getBoundingClientRect();
  const last=document.querySelector('#translation-body > .translation-block:last-of-type');
  const top=position.fraction===1 && last ? window.scrollY+last.getBoundingClientRect().bottom-window.innerHeight : window.scrollY+rect.top+position.within*rect.height-100;
  window.scrollTo({top:Math.max(0,top),behavior:'instant'});
}
export function filterWriting(posts, {category='all', tag='', query=''}={}) {
  const terms = normalized(query).trim().split(/\s+/).filter(Boolean);
  return posts.filter(post => {
    const kind = post.type === 'translation' ? 'translation' : post.category || 'personal';
    const text = normalized([post.title, post.subtitle, post.originalTitle, post.author, post.translator, ...(post.tags || []),
      ...(post.chapters || []).flatMap(chapter => [chapter.title, chapter.originalTitle])].join(' '));
    return (category === 'all' || category === kind) && (!tag || post.tags?.includes(tag)) && terms.every(term => text.includes(term));
  });
}

export function chapterRoute(post, chapter, language='zh', comparison=false) {
  return `#/read/${post.slug}?chapter=${encodeURIComponent(chapter.id)}&lang=${language}${comparison && post.revisionComparison ? '&compare=1' : ''}`;
}

export function sourceAsset(src) {
  if (!src || /^(?:[a-z]+:|\/\/)/i.test(src)) return /^https?:\/\//i.test(src || '') ? src : '';
  return src.startsWith('/') ? src : `${import.meta.env?.PROD ? '/' : '/personal/'}${src}`;
}

function inline(nodes, language, ref) {
  return (Array.isArray(nodes) ? nodes : [nodes]).map(node => {
    if (typeof node === 'string') return e(node).replace(/\n/g,'<br>');
    if (!node) return '';
    const children = () => inline(node.children || [], language, ref);
    if (['em','strong','sup','sub'].includes(node.type)) return `<${node.type}>${children()}</${node.type}>`;
    if (node.type === 'note') return `<sup><button class="translation-note-ref" id="${e(ref)}-${e(node.id)}-${language}" data-translation-note="${e(node.id)}" aria-controls="translation-note-panel" aria-expanded="false">${e(node.label || node.id.split('-').at(-1))}</button></sup>`;
    if (node.type === 'anchor') return `<span id="${e(node.id)}-${language}"></span>`;
    if (node.type === 'page') return `<span class="inline-source-page" id="${e(node.id)}-${language}">〔p. ${e(node.page)}〕</span>`;
    if (node.type === 'linebreak') return '<br>';
    if (node.type === 'break') return '<br><br>';
    if (node.type === 'image') return `<img src="${e(sourceAsset(node.src))}" alt="${e(node.alt || '')}" loading="lazy">`;
    if (node.type === 'math') return `<span class="source-math" data-tex="${e(node.tex)}" data-display="${!!node.display}">${e(node.tex)}</span>`;
    if (node.type === 'table') return `<div class="source-table-wrap"><table><tbody>${(node.rows || []).map(row=>`<tr>${row.map(cell=>`<td>${inline(cell,language,ref)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
    if (node.type === 'verse') return `<div class="source-verse">${children()}</div>`;
    if (node.type === 'block') {
      const tags={paragraph:'p',quote:'blockquote',interview:'blockquote',sidebar:'aside',notice:'aside',figure:'figure',caption:'figcaption',list:'ul',item:'li'};
      const tag=node.kind==='heading' ? `h${Math.min(6,Math.max(2,node.level || 2))}` : tags[node.kind] || 'div';
      return `<${tag} class="source-${e(node.kind)}${node.centered ? ' source-centered' : ''}${node['stanza-start'] ? ' source-stanza-start' : ''}${node.indented ? ' source-indented' : ''}">${children()}</${tag}>`;
    }
    if (node.type === 'link') {
      if (/^#/.test(node.url)) return `<button class="source-cross-reference" data-scroll="${e(node.url.slice(1))}-${language}">${children()}</button>`;
      if (/^(?:\.\/)?translations\/book\.html\?/.test(node.url || '')) {
        const url=new URL(node.url,'https://example.invalid/');
        const params=url.searchParams;
        return `<a href="#/read/${e(params.get('id'))}?chapter=${encodeURIComponent(params.get('chapter') || '')}&lang=${language}&anchor=${encodeURIComponent(url.hash.slice(1))}">${children()}</a>`;
      }
      if (!/^(https?:\/\/|mailto:)/i.test(node.url || '') || (/\.(pdf|epub|docx?|zip|md)(?:[?#]|$)/i.test(node.url) && !(node.citation === true && /\.pdf(?:[?#]|$)/i.test(node.url)))) return children();
      return `<a href="${e(node.url)}" target="_blank" rel="noreferrer">${children()}</a>`;
    }
    return children();
  }).join('');
}

export function restoredRows(data, rows=data.body) {
  const links=new Map((data.paragraphLinks || []).map(edge=>[edge.from,edge]));
  const consumed=new Set([...links.values()].map(edge=>edge.to));
  const lookup=new Map(data.body.map(row=>[row.id,row]));
  return rows.filter(row=>!consumed.has(row.id)).map(row=>{
    if (!links.has(row.id)) return row;
    const merged={...row,zh:structuredClone(row.zh),units:readingUnits(row)};
    const visited=new Set();
    let current=row.id;
    while(links.has(current) && !visited.has(current)) {
      visited.add(current);
      const edge=links.get(current), next=lookup.get(edge.to);
      if (!next) throw new Error('Missing paragraph continuation');
      if(edge.trim_end) {
        const last=merged.zh.at(-1);
        if(typeof last!=='string' || !last.endsWith(edge.trim_end)) throw new Error('Paragraph evidence mismatch');
        merged.zh[merged.zh.length-1]=last.slice(0,-edge.trim_end.length);
      }
      const tail=structuredClone(next.zh);
      if(edge.trim_start) tail[0]=tail[0].slice(edge.trim_start.length);
      if(edge.joiner) merged.zh.push(edge.joiner);
      merged.zh.push({type:'page',page:edge.page,id:edge.to},...tail);
      merged.units+=readingUnits(next);
      current=edge.to;
    }
    return merged;
  });
}

export function revisionDetails(entry, id) {
  if (!entry) return '';
  const label=entry.base==='reference' ? '原译' : '补译初稿';
  const fragments=(entry.hunks || []).map(h=>{
    const context=text=>e(text || '');
    const before=h.before ? `<del>${e(h.before)}</del>` : '<span class="comparison-empty">（无）</span>';
    const after=h.after ? `<ins>${e(h.after)}</ins>` : '<span class="comparison-empty">（删除）</span>';
    return `<li><p><b>${label}：</b>${h.leading ? '…' : ''}${context(h.prefix)}${before}${context(h.suffix)}${h.trailing ? '…' : ''}</p><p><b>校订：</b>${h.leading ? '…' : ''}${context(h.prefix)}${after}${context(h.suffix)}${h.trailing ? '…' : ''}</p></li>`;
  }).join('');
  return `<details class="translation-comparison" data-comparison-for="${e(id)}"><summary>修订对照 · ${entry.hunks?.length || 0}处${entry.base==='draft' ? ' · 补译初稿' : ''}</summary><p class="comparison-provenance">对照底稿：${e(entry.baselineLabel)}${entry.referencePdfPage ? ` · 中文PDF第${Number(entry.referencePdfPage)}页` : ''}</p><ol class="comparison-fragments">${fragments}</ol><p class="comparison-label">校对记录</p><ul class="comparison-reasons">${(entry.reasons || []).map(reason=>`<li>${e(reason)}</li>`).join('')}</ul><details class="comparison-full"><summary>查看整段对照</summary><p><b>${label}：</b>${e(entry.before)}</p><p><b>校订：</b>${e(entry.after)}</p></details></details>`;
}

export function translationBody(data, language='zh', post={}, comparison={}) {
  const languages = language === 'parallel' ? ['zh','en'] : [language];
  const sourceLanguage=data.sourceLanguage || post.sourceLanguage || 'en';
  const renderCell=(block,lang)=>{
      const hasBlocks=(block[lang] || []).some(token=>['table','block','verse','image'].includes(token.type));
      const tag = hasBlocks ? 'div' : ({heading:'h2',subheading:'h3',quote:'blockquote',diagram:'pre',code:'pre'}[block.type] || 'p');
      const content = inline(language==='parallel' && block.sharedFigure ? block.parallelFigureCaption : block[lang] || [], lang, block.id);
      const dimensions=block.imageWidth>0 && block.imageHeight>0 ? ` width="${Number(block.imageWidth)}" height="${Number(block.imageHeight)}"` : '';
      const image=`<img src="${e(sourceAsset(block.src))}" alt="${e((block[lang] || []).filter(x=>typeof x==='string').join(' '))}"${dimensions} loading="lazy">`;
      const figureImage=block.linkImage ? `<a href="${e(sourceAsset(block.src))}" target="_blank" rel="noreferrer">${image}</a>` : image;
      return `<div lang="${lang === 'zh' ? 'zh-CN' : e(sourceLanguage)}" class="${block.indent ? 'source-indented' : ''} ${lang==='en' && block.sourceItalic ? 'source-italic' : ''}">${['diagram','figure'].includes(block.type) && block.src ? `<figure>${figureImage}<figcaption>${content}</figcaption></figure>` : `<${tag}>${content}</${tag}>`}${lang==='zh' ? revisionDetails(comparison[block.id],block.id) : ''}${lang==='zh' && block.review ? `<details class="source-editorial"><summary>Editorial note</summary><p>${e(block.review)}</p></details>` : ''}</div>`;
  };
  let body;
  if(data.sourceMode==='facsimile' && language!=='zh') {
    const joins=new Set((data.paragraphLinks || []).map(edge=>Number(edge.page)));
    const groups=[];
    for(const page of data.facsimilePages) {
      if(joins.has(Number(page.page)) && groups.length) groups.at(-1).push(page);
      else groups.push([page]);
    }
    const lookup=new Map(data.body.map(row=>[row.id,row]));
    body=groups.map(pages=>{
      const rows=pages.flatMap(page=>page.rows).map(id=>lookup.get(id)).filter(Boolean);
      const chinese=language==='parallel' ? `<div>${restoredRows(data,rows).map(row=>`<div id="${e(row.id)}">${renderCell(row,'zh')}</div>`).join('')}</div>` : rows.map(row=>`<span id="${e(row.id)}" hidden></span>`).join('');
      const images=pages.map(page=>`<figure><a href="${e(sourceAsset(page.src))}" target="_blank" rel="noreferrer"><img src="${e(sourceAsset(page.src))}" alt="${e(post.sourceLanguageLabel || 'Original')} · ${e(page.page)}" width="${Number(page.width)}" height="${Number(page.height)}" loading="lazy"></a><figcaption>${e(page.page)}</figcaption></figure>`).join('');
      return `<section id="${e(pages[0].id)}" class="translation-block ${language==='parallel' ? 'is-parallel' : ''}" data-reading-units="${rows.reduce((sum,row)=>sum+readingUnits(row),0)}">${chinese}<div lang="${e(sourceLanguage)}">${images}</div></section>`;
    }).join('');
  } else body=restoredRows(data).map(block=>`<section class="translation-block ${language==='parallel' && !(block.shared || block.sharedFigure) ? 'is-parallel' : ''}" id="${e(block.id)}" data-reading-units="${block.units || readingUnits(block)}">${block.page ? `<small class="translation-page">${e(block.page)}</small>` : ''}${(language==='parallel' && (block.shared || block.sharedFigure) ? ['zh'] : languages).map(lang=>renderCell(block,lang)).join('')}</section>`).join('');
  const notes = Object.entries(data.notes || {}).map(([id,note]) => {
    const content = languages.filter(lang=>note[lang]?.length).map(lang=>`<div lang="${lang === 'zh' ? 'zh-CN' : e(sourceLanguage)}">${inline(note[lang],lang,`note-${id}`)}${lang==='zh' ? revisionDetails(comparison[id],id) : ''}</div>`).join('');
    if (!content) return '';
    return `<section id="note-${e(id)}" class="translation-note" hidden><h3>${e(note.number || id.split('-').at(-1))}</h3>${content}${note.editorial?.length ? inline(note.editorial,'zh',`editorial-${id}`) : ''}${language!=='en' && note.review ? `<p class="source-editorial">${e(note.review)}</p>` : ''}</section>`;
  }).join('');
  return body + (notes ? `<aside id="translation-note-panel" class="translation-note-panel" aria-label="Note" hidden><div class="translation-note-toolbar"><button class="translation-note-handle" data-drag-note aria-label="Move note" title="Drag to move"><svg width="18" height="18" viewBox="0 0 18 18" aria-hidden="true" fill="currentColor"><circle cx="6" cy="4" r="1"/><circle cx="12" cy="4" r="1"/><circle cx="6" cy="9" r="1"/><circle cx="12" cy="9" r="1"/><circle cx="6" cy="14" r="1"/><circle cx="12" cy="14" r="1"/></svg></button><button class="translation-note-close" data-close-note aria-label="Close note">×</button></div><div class="translation-note-content">${notes}</div></aside>` : '');
}

let notePosition = null;
let resizeListenerAdded = false;
export function clampNotePosition(x, y, width, height, viewportWidth, viewportHeight) {
  return {x:Math.max(8,Math.min(x,Math.max(8,viewportWidth-width-8))), y:Math.max(8,Math.min(y,Math.max(8,viewportHeight-height-8)))};
}

export function positionNotePanel(panel) {
  if (!notePosition || panel.hidden) return;
  const rect = panel.getBoundingClientRect();
  notePosition = clampNotePosition(notePosition.x,notePosition.y,rect.width,rect.height,window.innerWidth,window.innerHeight);
  Object.assign(panel.style,{left:`${notePosition.x}px`,top:`${notePosition.y}px`,right:'auto'});
}

function setupNoteDragging(panel) {
  if (!panel) return;
  const handle = panel.querySelector('[data-drag-note]');
  let drag = null;
  handle.addEventListener('pointerdown', event => {
    if (event.button !== 0) return;
    const rect = panel.getBoundingClientRect();
    drag = {id:event.pointerId, offsetX:event.clientX-rect.left, offsetY:event.clientY-rect.top};
    handle.setPointerCapture(event.pointerId);
    panel.classList.add('is-dragging');
    event.preventDefault();
  });
  handle.addEventListener('pointermove', event => {
    if (!drag || event.pointerId !== drag.id) return;
    notePosition = {x:event.clientX-drag.offsetX,y:event.clientY-drag.offsetY};
    positionNotePanel(panel);
  });
  const stop = () => { drag=null; panel.classList.remove('is-dragging'); };
  handle.addEventListener('pointerup', stop);
  handle.addEventListener('pointercancel', stop);
  handle.addEventListener('lostpointercapture', stop);
  handle.addEventListener('keydown', event => {
    const delta = {ArrowLeft:[-1,0],ArrowRight:[1,0],ArrowUp:[0,-1],ArrowDown:[0,1]}[event.key];
    if (!delta) return;
    event.preventDefault();
    const rect = panel.getBoundingClientRect(), step=event.shiftKey ? 20 : 5;
    notePosition = {x:rect.left+delta[0]*step,y:rect.top+delta[1]*step};
    positionNotePanel(panel);
  });
  if (!resizeListenerAdded) {
    window.addEventListener('resize',()=>{
      const current=document.getElementById('translation-note-panel');
      if(current) positionNotePanel(current);
    });
    resizeListenerAdded=true;
  }
}

export function translationReader(post, route) {
  const language = ['zh','en','parallel'].includes(route.language) ? route.language : 'zh';
  const chapter = post.chapters.find(item=>item.id===route.chapter) || post.chapters[0];
  const index = post.chapters.indexOf(chapter);
  const comparing=!!(route.comparison && post.revisionComparison);
  const routeFor=(item,lang=language)=>chapterRoute(post,item,lang,comparing);
  const title = language === 'en' ? chapter.originalTitle || chapter.title : language === 'parallel' ? chapter.parallelTitle || chapter.title : chapter.title;
  let lastPart;
  const directory=post.chapters.map(item=>{
    const part=(post.parts || []).find(part=>part.id===item.partId);
    const heading=part && part.id!==lastPart ? `<h3>${e(language==='en' ? part.originalTitle || part.title : part.title)}</h3>` : '';
    lastPart=item.partId;
    const outline=(item.outline || []).map(section=>`<a class="chapter-outline" style="--outline-level:${Math.max(1,Math.min(3,section.level || 1))}" href="${routeFor(item)}&anchor=${encodeURIComponent(section.anchor)}">${e(language==='en' ? section.originalTitle || section.title : section.title)}</a>`).join('');
    return `${heading}<a href="${routeFor(item)}" ${item.parentId ? 'class="chapter-subentry"' : ''} ${item.id===chapter.id ? 'aria-current="page"' : ''}>${e(language==='en' ? item.shortOriginalTitle || item.originalTitle || item.title : item.shortTitle || item.title)}</a>${outline}`;
  }).join('');
  return `<main class="reader-main translation-reader" data-language="${language}">
    <header class="translation-heading"><h1>${e(post.title)}</h1><p>${e(post.subtitle)}</p>
      ${post.originalHeading ? `<div class="translation-original-heading" lang="${e(post.originalHeading.language || post.sourceLanguage || 'en')}"><p class="translation-original-title">${e(post.originalHeading.title)}</p><p class="translation-original-subtitle">${e(post.originalHeading.subtitle)}</p></div>${post.originalHeading.authorLanguage === 'ru' ? '' : `<p>${e(post.authorZh || post.author)}</p>`}<p class="translation-original-author" lang="${e(post.originalHeading.language || post.sourceLanguage || 'en')}">${e(post.originalHeading.author)}</p>` : `<p>${e(post.author)}</p>`}
      ${post.translator ? `<small>Chinese: ${e(post.translator)}${post.englishTranslator ? ` · English: ${e(post.englishTranslator)}` : ''}</small>` : ''}
      ${post.originalEdition ? `<p class="translation-original-edition">${post.originalHeading ? e(post.originalHeading.edition) : `${e(post.originalEdition.title)} · ${e(post.originalEdition.subtitle)} (${e(post.originalEdition.year)})`}</p>` : ''}
    </header>
    <div class="translation-controls">
      <details class="translation-directory"><summary>Contents</summary><nav aria-label="Chapters">${directory}</nav></details>
      ${post.revisionComparison ? `<a class="comparison-switch" role="switch" aria-checked="${comparing}" href="${chapterRoute(post,chapter,language,!comparing)}">修订对照${comparing ? '：已开' : ''}</a>` : ''}
      <nav class="translation-language" aria-label="Reading language">${[['zh','中文'],['en',post.sourceLanguageLabel || 'English'],['parallel','Parallel']].filter(([lang])=>!post.views || post.views.includes(lang)).map(([lang,label])=>`<a href="${routeFor(chapter,lang)}" ${language===lang ? 'aria-current="page"' : ''}>${e(label)}</a>`).join('')}</nav>
    </div>
    ${comparing ? `<p class="comparison-status" id="comparison-status" role="status">${language==='en' ? '中文或双语视图显示修订对照。' : '正在加载修订对照…'}</p>` : ''}
    <article class="reader-article translation-article" id="reader-article" style="--reader-scale:1"><h2 class="translation-chapter-title">${e(title)}</h2><div id="translation-body" aria-busy="true"><p role="status">Loading…</p></div></article>
    <nav class="translation-pagination" aria-label="Chapter navigation">${index>0 ? `<a href="${routeFor(post.chapters[index-1])}">← Previous</a>` : '<span></span>'}${index<post.chapters.length-1 ? `<a href="${routeFor(post.chapters[index+1])}">Next →</a>` : ''}</nav>
  </main>`;
}

const cache = new Map();
const comparisonCache = new Map();
export async function loadTranslation(post, route) {
  const target = document.getElementById('translation-body');
  const chapter = post.chapters.find(item=>item.id===route.chapter) || post.chapters[0];
  try {
    if (!cache.has(chapter.dataUrl)) {
      const response = await fetch(chapter.dataUrl);
      if (!response.ok) throw new Error(`Chapter request failed: ${response.status}`);
      const data = await response.json();
      if (data.id !== chapter.id || !Array.isArray(data.body)) throw new Error('Invalid chapter');
      cache.set(chapter.dataUrl,data);
    }
    if (!target?.isConnected) return;
    const language=['zh','en','parallel'].includes(route.language) ? route.language : 'zh';
    const data=cache.get(chapter.dataUrl);
    const render=(entries={})=>{
      target.innerHTML = translationBody(data,language,post,entries);
      target.querySelectorAll('[data-tex]').forEach(node=>window.katex?.render(node.dataset.tex,node,{displayMode:node.dataset.display==='true',throwOnError:false,trust:false}));
      setupNoteDragging(target.querySelector('#translation-note-panel'));
    };
    render();
    if(route.comparison && post.revisionComparison && language!=='en') {
      const status=document.getElementById('comparison-status');
      const metadata=post.revisionComparison[chapter.id];
      try {
        if(metadata?.count) {
          if(!comparisonCache.has(metadata.dataUrl)) {
            const response=await fetch(metadata.dataUrl);
            if(!response.ok) throw new Error(`Comparison request failed: ${response.status}`);
            const comparison=await response.json();
            const ids=new Set([...data.body.map(row=>row.id),...Object.keys(data.notes || {})]);
            if(comparison.schema!==1 || comparison.chapter!==chapter.id || !comparison.entries ||
              Object.keys(comparison.entries).length!==metadata.count || Object.keys(comparison.entries).some(id=>!ids.has(id))) throw new Error('Invalid revision comparison');
            comparisonCache.set(metadata.dataUrl,comparison.entries);
          }
          if(!target.isConnected) return;
          render(comparisonCache.get(metadata.dataUrl));
        }
        if(status?.isConnected) status.textContent=metadata?.count ? `本节${metadata.count}个修订单元。展开段旁“修订对照”查看。原译为中文版整理文本；补译初稿另行标明。差异不一概判作错译。` : '本节没有文字修订；结构和英文OCR修复不列入中文对照。';
      } catch(error) {
        if(status?.isConnected) status.innerHTML='修订对照暂时无法加载，校订正文仍可阅读。<button data-retry-chapter>重试对照</button>';
        console.error(error);
      }
    }
  } catch (error) {
    if (target?.isConnected) target.innerHTML = '<p role="alert">Could not load this chapter. <button data-retry-chapter>Retry</button></p>';
    console.error(error);
  } finally {
    target?.setAttribute('aria-busy','false');
  }
}
