import './styles.css';
import './refinements.css';
import { ReferenceBackground } from './reference-background.js';
import { setupMusicPlayer } from './music-player.js';
import { createAtlas } from './map.js';
import { places, posts, books, projects } from './data.js';
import './gwern.css';
import './archive-layout.css';
import './writing.css';
import './inner-fonts.css';
import { escapeHtml, visitDate, sortedVisits, placePhotos, readingShelves, bookEntries, bookByline, photoIndex, photoCredit, englishDate } from './records.js';
import { filterWriting, translationReader, loadTranslation, positionNotePanel, wholeBookProgress, translationPosition, restoreTranslationPosition } from './writing.js';

const app = document.getElementById('app');
const overlayRoot = document.getElementById('overlay-root');
const cellular = new ReferenceBackground();

let atlas = null;
let revealObserver = null;
let currentRoute = null;
let readerOrigin = 'archive';
let postFilter = 'all';
let writingQuery = '';
let writingTag = '';
let currentNoteButton = null;
let travelView = 'map';
let albumQuery = '';
let readQuery = '';
let readerScale = 1;
let toastTimer;
let archiveSection = 'intro';
let readerReturnHash = '#/archive/writing';
let lastScrollY = 0;
let scrollDirection = 0;
let scrollDistance = 0;
let keyboardNavigation = false;
const archiveSections = ['intro', 'writing', 'atlas', 'reading', 'album'];
const scrollPositions = { home: 0, archive: 0, reader: 0 };

const icons = {
  arrowUpRight: '<path d="M4 12 12 4M4 4h8v8"/>',
  arrowRight: '<path d="M3 8h10M9 4l4 4-4 4"/>',
  arrowLeft: '<path d="M13 8H3m4-4L3 8l4 4"/>',
  arrowDown: '<path d="M8 3v10m-4-4 4 4 4-4"/>',
  pause: '<path d="M6 4v8M10 4v8"/>',
  play: '<path d="m5 3 8 5-8 5Z"/>',
  refresh: '<path d="M13 5V2m0 0h-3m3 0L10.8 4.2A6 6 0 1 0 14 8"/>',
  map: '<path d="m1.5 3 4-1.5 5 2 4-1.5v10.5l-4 1.5-5-2-4 1.5ZM5.5 2v10m5-8v10"/>',
  list: '<path d="M5 4h9M5 8h9M5 12h9M1.5 4h.01M1.5 8h.01M1.5 12h.01"/>',
  close: '<path d="m3 3 10 10M13 3 3 13"/>',
  plus: '<path d="M8 3v10M3 8h10"/>',
  minus: '<path d="M3 8h10"/>',
  expand: '<path d="M6 2H2v4m8-4h4v4M2 10v4h4m8-4v4h-4"/>',
  chevronLeft: '<path d="m10 3-5 5 5 5"/>',
  chevronRight: '<path d="m6 3 5 5-5 5"/>',
  copy: '<rect x="5" y="5" width="8" height="8" rx="1"/><path d="M3 10V3h7"/>',
  check: '<path d="m3 8 3 3 7-7"/>',
  book: '<path d="M2 2.5h4a2 2 0 0 1 2 2v9a2 2 0 0 0-2-1.5H2Zm12 0h-4a2 2 0 0 0-2 2v9a2 2 0 0 1 2-1.5h4Z"/>'
};

function icon(name, className = '') {
  return `<svg class="icon ${className}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.35" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${icons[name] || icons.arrowRight}</svg>`;
}

function siteHeader(view) {
  const isHome = view === 'home';
  if (!isHome) return `<header class="archive-header archive-navigation">
    <button class="mirror-avatar" type="button" data-switch="home" aria-label="Personal homepage"></button>
    <nav aria-label="Navigation">${archiveSections.map((section, index) => `<button type="button" data-archive-section="${section}" ${section === archiveSection ? 'aria-current="page"' : ''}>${['About', 'Writing', 'Places', 'Reading', 'Photos'][index]}</button>`).join('')}</nav>
    <span>Union</span>
  </header>`;
  return `
    <header class="site-header ${isHome ? 'home-header' : 'archive-header'}">
      <div class="header-inner">
        ${isHome ? `
          <button class="wordmark-switch" type="button" data-switch="archive" aria-label="进入 Union 的镜像档案页">
            <span class="wordmark">Union<span>.</span></span>
            <span class="wordmark-orbit" aria-hidden="true">${icon('arrowUpRight')}</span>
          </button>` : `
          <button class="avatar-switch" type="button" data-switch="home" aria-label="返回 Union 主页">
            <img src="/avatar.svg" alt="Union 的占位头像" />
            <span class="avatar-return">${icon('arrowLeft')}</span>
          </button>`}
        <nav class="main-nav" aria-label="Navigation">
          ${isHome ? `
            <button type="button" data-scroll="about">关于</button>
            <button type="button" data-scroll="work">项目</button>
            <button type="button" data-scroll="now">近况</button>` : `
            ${archiveSections.map((section, index) => `<button type="button" data-archive-section="${section}" ${section === archiveSection ? 'aria-current="page"' : ''}><small>0${index}</small>${['About', 'Writing', 'Places', 'Reading', 'Photos'][index]}</button>`).join('')}`}
        </nav>
        <div class="header-meta">
          <span class="availability-dot"></span>
          ${isHome ? '<span>GMT+8</span><time data-local-time>00:00</time>' : '<span class="archive-name">Union</span>'}
        </div>
      </div>
    </header>`;
}

function homeTemplate() {
  return `
    ${siteHeader('home')}
    <main class="page-shell home-page">
      <section class="home-hero reveal" id="top">
        <div class="home-hero-main">
          <div class="eyebrow hero-eyebrow"><span>PERSONAL HOMEPAGE</span><span>NO. 001 / 2026</span></div>
          <h1>Union<span>.</span></h1>
          <p class="home-kicker">在复杂的事物之间，<br><em>寻找清晰的结构。</em></p>
          <div class="home-intro">
            <p>我关注工具、文字与行走。这里是一个正在生长的个人档案，也是一种更慢的互联网实践。</p>
            <button class="text-link" type="button" data-switch="archive">去另一面看看 <span>写作、阅读与远方</span>${icon('arrowUpRight')}</button>
          </div>
        </div>
        <aside class="home-hero-aside">
          <div class="orbit-art" aria-hidden="true">
            <span class="orbit orbit-one"></span>
            <span class="orbit orbit-two"></span>
            <span class="orbit orbit-three"></span>
            <span class="orbit-center">U</span>
            <span class="orbit-caption caption-one">READ</span>
            <span class="orbit-caption caption-two">WRITE</span>
            <span class="orbit-caption caption-three">WANDER</span>
          </div>
          <div class="hero-aside-note">
            <p class="mini-label">A WORK IN PROGRESS</p>
            <p>保持好奇，容纳矛盾。<br>让不同的经验在这里相遇。</p>
            <span class="aside-coordinate">31.2304° N / 121.4737° E</span>
          </div>
        </aside>
        <div class="hero-index-row">
          <span><b>01</b> 思考 / THINK</span>
          <span><b>02</b> 制作 / MAKE</span>
          <span><b>03</b> 漫游 / WANDER</span>
          <button type="button" data-scroll="about" aria-label="向下查看">${icon('arrowDown')}</button>
        </div>
      </section>

      <section class="home-section about-section reveal" id="about">
        <div class="section-side"><span>01</span><p>ABOUT /<br>关于</p></div>
        <div class="about-content">
          <p class="section-kicker">A SHORT INTRODUCTION</p>
          <h2>I make tools, write notes,<br>and <em>pay attention.</em></h2>
          <div class="about-columns">
            <p>你好，我是 Union。我喜欢研究那些连接不同领域的事物：界面如何影响思考，翻译如何改变原文，Map如何组织记忆。</p>
            <p>这个主页不是一份完成的简历，而是一处开放的工作台。稳定的内容放在这里；更私人、更流动的记录，藏在镜像页面。</p>
          </div>
        </div>
      </section>

      <section class="home-section work-section reveal" id="work">
        <div class="section-side"><span>02</span><p>SELECTED /<br>正在做的事</p></div>
        <div class="work-content">
          <div class="section-heading-inline"><h2>Projects & inquiries</h2><span>2022 — 2026</span></div>
          <div class="project-list">
            ${projects.map((project) => `
              <a class="project-row" href="${project.link}">
                <span class="project-index">${project.index}</span>
                <div><h3>${project.title}</h3><p>${project.description}</p><span>${project.meta}</span></div>
                <span class="project-arrow">${icon('arrowUpRight')}</span>
              </a>`).join('')}
          </div>
        </div>
      </section>

      <section class="home-section now-section reveal" id="now">
        <div class="section-side"><span>03</span><p>NOW /<br>此刻</p></div>
        <div class="now-content">
          <div class="section-heading-inline"><h2>A few things, lately</h2><span>UPDATED OCT 2026</span></div>
          <div class="now-grid">
            <article><span class="mini-label">READING</span><h3>《游隼》</h3><p>J. A. Baker</p><div class="thin-progress"><i style="width:68%"></i></div><small>慢慢读，读到 68%</small></article>
            <article><span class="mini-label">MAKING</span><h3>一个地点档案</h3><p>把Map、照片与笔记连成可以重走的路线。</p><a href="#/archive">查看镜像档案 ${icon('arrowRight')}</a></article>
            <article><span class="mini-label">THINKING ABOUT</span><h3>注意力的边界</h3><p>界面能不能不那么着急？我们能不能为空白留下位置？</p><a href="#/read/attention-as-space">读这篇笔记 ${icon('arrowRight')}</a></article>
          </div>
        </div>
      </section>
    </main>
    <footer class="site-footer page-shell"><span>Union © 2026</span><span>Made slowly, with curiosity.</span><a href="mailto:hello@example.com">hello@example.com ${icon('arrowUpRight')}</a></footer>
`;
}

function archiveHero() {
  return `
    <section class="personal-introduction" aria-label="About">
      <p>Forced to combat nature or social institutions, one must choose between making a man or a citizen.</p>
    </section>`;
}

function postCard(post, featured = false) {
  if (featured) {
    return `
      <article class="featured-post">
        <a href="#/read/${post.slug}" class="featured-post-link">
          <div class="featured-post-top"><span>${post.number}</span><span>${post.type === 'blog' ? 'BLOG' : 'TRANSLATION'}</span></div>
          <div class="featured-post-body"><p class="post-subtitle">${post.subtitle}</p><h3>${post.title}</h3><p>${post.excerpt}</p></div>
          <div class="featured-post-bottom"><span>${post.date} · ${post.readTime}</span><span class="round-arrow">${icon('arrowUpRight')}</span></div>
        </a>
      </article>`;
  }
  return `
    <article class="post-row">
      <a href="#/read/${post.slug}">
        <div class="post-row-meta"><span>${post.number}</span><time>${post.date}</time></div>
        <div class="post-row-title"><span>${post.type === 'blog' ? 'BLOG' : 'TRANSLATION'}</span><h3>${post.title}</h3><p>${post.subtitle}</p></div>
        <p class="post-row-excerpt">${post.excerpt}</p>
        <span class="post-row-arrow">${icon('arrowUpRight')}</span>
      </a>
    </article>`;
}

function filteredPosts() {
  return filterWriting(posts, {category:postFilter, tag:writingTag, query:writingQuery});
}

function writingListTemplate() {
  const filtered = filteredPosts();
  return filtered.length ? `<div class="writing-results">${filtered.map(post=>`<article class="writing-entry"><h3><a href="#/read/${post.slug}">${escapeHtml(post.listTitle || post.title)}</a></h3><p class="writing-original">${escapeHtml(post.listOriginalTitle || post.subtitle)}</p><p class="writing-author">${escapeHtml(post.author)}</p><div class="writing-tags">${(post.tags || []).map(tag=>`<button data-writing-tag="${escapeHtml(tag)}" aria-pressed="${writingTag===tag}">${escapeHtml(tag)}</button>`).join('')}</div></article>`).join('')}</div>` : `<p class="quiet-empty" role="status">${writingQuery || writingTag ? 'No matches' : '—'}</p>`;
}

function writingSection() {
  return `
    <section class="archive-section writing-section reveal" id="writing">
      
      <div class="writing-filter" role="group" aria-label="Writing categories">
        <button type="button" data-post-filter="all" class="${postFilter === 'all' ? 'is-active' : ''}" aria-pressed="${postFilter === 'all'}">All <sup>${String(posts.length).padStart(2, '0')}</sup></button>
        <button type="button" data-post-filter="technical" class="${postFilter === 'technical' ? 'is-active' : ''}" aria-pressed="${postFilter === 'technical'}">Technical <sup>${posts.filter((p) => p.type === 'blog' && p.category === 'technical').length}</sup></button>
        <button type="button" data-post-filter="personal" class="${postFilter === 'personal' ? 'is-active' : ''}" aria-pressed="${postFilter === 'personal'}">Personal <sup>${posts.filter((p) => p.type === 'blog' && p.category !== 'technical').length}</sup></button>
        <button type="button" data-post-filter="translation" class="${postFilter === 'translation' ? 'is-active' : ''}" aria-pressed="${postFilter === 'translation'}">Translation <sup>${String(posts.filter((p) => p.type === 'translation').length).padStart(2, '0')}</sup></button>
        
      </div>
      <div class="writing-search" role="search" aria-label="Search writing"><input type="search" data-writing-query placeholder="Search writing" aria-label="Search writing" value="${escapeHtml(writingQuery)}"><select data-writing-tag-select aria-label="Filter by tag"><option value="">All tags</option>${[...new Set(posts.flatMap(post=>post.tags || []))].map(tag=>`<option value="${escapeHtml(tag)}" ${writingTag===tag ? 'selected' : ''}>${escapeHtml(tag)}</option>`).join('')}</select></div><div class="post-list" id="post-list">${writingListTemplate()}</div>
    </section>`;
}

function placeIndexTemplate() {
  return places.map((place, index) => `
    <button class="place-index-item" type="button" data-focus-place="${place.id}">
      <span class="place-index-number">${String(index + 1).padStart(2, '0')}</span>
      <span><b>${place.name}</b><small>${place.country}</small></span>
      ${icon('arrowUpRight')}
    </button>`).join('');
}

function journeySequenceTemplate() {
  const visits = places.flatMap(place => sortedVisits(place).map(visit => ({place, visit})))
    .sort((a,b) => (b.visit.startedAt || b.visit.endedAt || '').localeCompare(a.visit.startedAt || a.visit.endedAt || ''));
  if (!visits.length) return '<p class="quiet-empty">—</p>';
  return visits.map(({place, visit}) => {
    const photos = placePhotos(place);
    const photoIndex = photos.findIndex(photo => photo.visitId === visit.id);
    return `<article class="visit-entry" id="journey-${escapeHtml(visit.id)}" data-journey-place="${place.id}">
      <header><h3>${escapeHtml(place.name)}</h3>${visitDate(visit) ? `<time>${escapeHtml(visitDate(visit))}</time>` : ''}</header>
      ${photoIndex >= 0 ? `<button class="visit-photo" data-lightbox="${place.id}:${photoIndex}"><img src="${escapeHtml(photos[photoIndex].src)}" alt="${escapeHtml(photos[photoIndex].caption || place.name)}" loading="lazy"></button>` : ''}
      ${visit.note ? `<p class="visit-note">${escapeHtml(visit.note)}</p>` : ''}
      <div class="visit-actions"><button data-journey-map="${place.id}">Show on map ${icon('map')}</button>${visit.postSlug && posts.some(post => post.slug === visit.postSlug) ? `<a href="#/read/${visit.postSlug}">Notes ${icon('arrowRight')}</a>` : ''}</div>
    </article>`;
  }).join('');
}

function atlasSection() {
  return `
    <section class="archive-section atlas-section reveal" id="atlas">
      
      <div class="atlas-toolbar">
        <div class="view-switch" role="group" aria-label="Travel view">
          <button type="button" data-travel-view="map" class="${travelView === 'map' ? 'is-active' : ''}" aria-pressed="${travelView === 'map'}">${icon('map')} Map</button>
          <button type="button" data-travel-view="sequence" class="${travelView === 'sequence' ? 'is-active' : ''}" aria-pressed="${travelView === 'sequence'}">${icon('list')} Timeline</button>
        </div>
        <div class="map-layer-switch ${travelView === 'map' ? '' : 'is-hidden'}">
          <button type="button" data-map-layer="street" class="is-active" aria-pressed="true">Map</button>
          <button type="button" data-map-layer="satellite" aria-pressed="false">Satellite</button>
        </div>
        <button class="atlas-reset ${travelView === 'map' ? '' : 'is-hidden'}" type="button" data-map-reset>${icon('refresh')} Reset view</button>
      </div>
      <div class="atlas-map-layout ${travelView === 'map' ? '' : 'is-hidden'}" id="atlas-map-panel">
        <div class="atlas-map-frame">
          <div id="atlas-map" aria-label="Interactive map of visited places"></div>
        </div>
      </div>
      <div class="journey-sequence ${travelView === 'sequence' ? '' : 'is-hidden'}" id="journey-panel">
        ${journeySequenceTemplate()}
      </div>
    </section>`;
}

function readingSection() {
  return `<section class="archive-section reading-section reveal" id="reading">
    
    <div class="book-shelves">${readingShelves(books, readQuery)}</div>
  </section>`;
}

function openBookReview(id) {
  const book = books.find(book => book.id === id);
  if (!book) return;
  showDialog(`<button class="dialog-close" data-dialog-close aria-label="Close review">${icon('close')}</button>
    <article class="book-review-content"><h2>${escapeHtml(book.title)}</h2>${book.originalTitle ? `<p class="book-original-title">${escapeHtml(book.originalTitle)}</p>` : ''}<p class="book-byline">${bookByline(book)}</p><p class="book-inline-meta"><span>${book.rating}/10</span>${book.finishedAt ? `<span>${englishDate(book.finishedAt)}</span>` : ''}</p>
    <div class="book-review-body">${book.review ? book.review.split(/\n\s*\n/).map(paragraph => `<p>${escapeHtml(paragraph).replace(/\n/g,'<br>')}</p>`).join('') : '<p class="quiet-empty">—</p>'}</div></article>`, 'book-review-dialog');
}

function albumGridTemplate() {
  return photoIndex(places, {query:albumQuery});
}

function albumSection() {
  return `<section class="archive-section album-section reveal" id="album">
    
    <div class="photo-search" role="search" aria-label="Search photo archive">
      <input type="search" data-photo-query aria-label="Search places or dates" placeholder="Search places or dates" value="${escapeHtml(albumQuery)}">
    </div>
    <div class="photo-index" id="album-grid">${albumGridTemplate()}</div>
  </section>`;
}

function archiveTemplate() {
  const sections = { intro: archiveHero, writing: writingSection, atlas: atlasSection, reading: readingSection, album: albumSection };
  return `
    ${siteHeader('archive')}
    <div class="archive-sheet">
    <button class="menu-recall" type="button" data-menu-recall aria-label="Show navigation">Contents ${icon('arrowDown')}</button>
    <main class="archive-content">
      ${sections[archiveSection]()}
    </main>
    </div>
`;
}

function readerHeader(post) {
  return `
    <header class="reader-header">
      <div class="reading-progress"><span id="reading-progress-bar"></span></div>
      <div class="reader-header-inner">
        <button type="button" class="reader-back" data-reader-back>${icon('arrowLeft')}<span>Back to ${readerOrigin === 'home' ? 'home' : 'archive'}</span></button>
        <span class="reader-header-title">Union / ${post.type === 'blog' ? 'Notes' : 'Translations'}</span>
        <div class="reader-controls" aria-label="Text size">
          <button type="button" data-font-size="decrease" aria-label="Decrease text size">A<span>−</span></button>
          <button type="button" data-font-size="increase" aria-label="Increase text size">A<span>+</span></button>
          <span class="reader-percent" id="reader-percent">0%</span>
        </div>
      </div>
    </header>`;
}

function readerTemplate(post) {
  if (post.kind === 'book') return readerHeader(post) + translationReader(post, currentRoute);
  const headings = [...post.content.matchAll(/<h2 id="([^"]+)">([^<]+)<\/h2>/g)];
  const currentIndex = posts.findIndex((item) => item.slug === post.slug);
  const previous = posts[(currentIndex - 1 + posts.length) % posts.length];
  const next = posts[(currentIndex + 1) % posts.length];
  return `
    ${readerHeader(post)}
    <button class="menu-recall" type="button" data-menu-recall aria-label="Show navigation">Contents ${icon('arrowDown')}</button>
    <div class="reader-top-fade" aria-hidden="true"></div>
    <main class="reader-main">
      <header class="reader-hero" id="reader-hero">
        <p class="reader-category">${post.number} / ${post.type === 'blog' ? 'FIELD NOTES & ESSAYS' : 'TRANSLATIONS & NOTES'}</p>
        <h1>${post.title}</h1>
        ${post.subtitle.toLowerCase() !== post.title.toLowerCase() ? `<p class="reader-subtitle">${post.subtitle}</p>` : ''}
        <p class="reader-deck">${post.excerpt}</p>
        <div class="reader-meta"><span>UNION</span><span>${post.date}</span><span>${post.readTime} read</span></div>
        ${post.original ? `<p class="reader-original">ORIGINAL / ${post.original}</p>` : ''}
        <button class="reader-begin" type="button" data-scroll="reader-article">Read ${icon('arrowDown')}</button>
      </header>
      <div class="reader-content-grid">
        <aside class="reader-toc" aria-label="Table of contents"><span>CONTENTS</span>${headings.map((match, index) => `<button type="button" data-scroll="${match[1]}" data-toc-target="${match[1]}"><i>${String(index + 1).padStart(2, '0')}</i>${match[2]}</button>`).join('')}</aside>
        <article class="reader-article" id="reader-article" style="--reader-scale:${readerScale}">
          ${post.content}
          <footer class="reader-article-footer">
            <span></span>
            <button type="button" data-copy-link>${icon('copy')} Copy link</button>
          </footer>
        </article>
        <aside class="reader-margin"><span>READING MODE</span><p></p><i></i><small></small></aside>
      </div>
      <nav class="reader-next" aria-label="Continue reading">
        <a href="#/read/${previous.slug}"><span>${icon('arrowLeft')} Previous</span><b>${previous.title}</b></a>
        <a href="#/read/${next.slug}"><span>Next ${icon('arrowRight')}</span><b>${next.title}</b></a>
      </nav>
    </main>
    <footer class="reader-footer"><span>Union / Personal archive</span><button type="button" data-reader-back>Back to archive ${icon('arrowUpRight')}</button></footer>`;
}

function getRoute() {
  const hash = window.location.hash;
  if (hash.startsWith('#/read/')) {
    const [path, query] = hash.slice('#/read/'.length).split('?');
    const params = new URLSearchParams(query);
    const slug=decodeURIComponent(path), post=posts.find(item=>item.slug===slug);
    const alias=post?.chapterAliases?.[params.get('chapter')];
    return { name: 'reader', slug, chapter:alias?.chapter || params.get('chapter'), language:params.get('lang') || 'zh', comparison:params.get('compare')==='1', anchor:params.get('anchor') || alias?.anchor };
  }
  if (hash.startsWith('#/archive')) {
    const section = hash.split('/')[2] || 'intro';
    return { name: 'archive', section: archiveSections.includes(section) ? section : 'intro' };
  }
  return { name: 'home' };
}

function updateTime() {
  const time = new Intl.DateTimeFormat('zh-CN', {
    timeZone: 'Asia/Shanghai', hour: '2-digit', minute: '2-digit', hour12: false
  }).format(new Date());
  document.querySelectorAll('[data-local-time]').forEach((element) => { element.textContent = time; });
}

function setupReveal() {
  revealObserver?.disconnect();
  const elements = document.querySelectorAll('.reveal');
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    elements.forEach((element) => element.classList.add('is-visible'));
    return;
  }
  revealObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.06, rootMargin: '0px 0px -30px' });
  elements.forEach((element) => revealObserver.observe(element));
}

function ensureAtlas() {
  if (atlas || travelView !== 'map' || currentRoute?.name !== 'archive' || archiveSection !== 'atlas') return;
  atlas = createAtlas(places, {
    onOpenPlace: openPlaceDialog,
    onSelectPlace: (id) => {
      document.querySelectorAll('[data-focus-place]').forEach((button) => {
        button.classList.toggle('is-active', button.dataset.focusPlace === id);
      });
    }
  });
}

function setTravelView(view, scrollToJourney) {
  travelView = view;
  const mapPanel = document.getElementById('atlas-map-panel');
  const journeyPanel = document.getElementById('journey-panel');
  if (!mapPanel || !journeyPanel) return;
  mapPanel.classList.toggle('is-hidden', view !== 'map');
  journeyPanel.classList.toggle('is-hidden', view !== 'sequence');
  document.querySelector('.map-layer-switch')?.classList.toggle('is-hidden', view !== 'map');
  document.querySelector('.atlas-reset')?.classList.toggle('is-hidden', view !== 'map');
  document.querySelectorAll('[data-travel-view]').forEach((button) => {
    const active = button.dataset.travelView === view;
    button.classList.toggle('is-active', active);
    button.setAttribute('aria-pressed', String(active));
  });
  if (view === 'map') {
    ensureAtlas();
    requestAnimationFrame(() => atlas?.invalidate());
  }
  if (scrollToJourney) {
    requestAnimationFrame(() => {
      const target = document.getElementById(`journey-${scrollToJourney}`);
      target?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      target?.classList.add('is-highlighted');
      setTimeout(() => target?.classList.remove('is-highlighted'), 1800);
    });
  }
}

function renderWriting() {
  const list = document.getElementById('post-list');
  if (list) list.innerHTML = writingListTemplate();
  const tagSelect = document.querySelector('[data-writing-tag-select]');
  if (tagSelect) tagSelect.value = writingTag;
  document.querySelectorAll('[data-post-filter]').forEach((button) => {
    const active = button.dataset.postFilter === postFilter;
    button.classList.toggle('is-active', active);
    button.setAttribute('aria-pressed', String(active));
  });
}

function renderAlbum() {
  const grid = document.getElementById('album-grid');
  if (grid) grid.innerHTML = albumGridTemplate();

}

function showDialog(content, className = '') {
  closeDialog();
  overlayRoot.innerHTML = `<dialog class="site-dialog ${className}">${content}</dialog>`;
  const dialog = overlayRoot.querySelector('dialog');
  document.body.classList.add('modal-open');
  dialog.showModal();
  dialog.addEventListener('click', (event) => {
    if (event.target !== dialog) return;
    const rect = dialog.getBoundingClientRect();
    if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) {
      closeDialog();
    }
  });
  dialog.addEventListener('close', () => {
    if (overlayRoot.querySelector('dialog') === dialog) overlayRoot.innerHTML = '';
    if (!overlayRoot.querySelector('dialog[open]')) document.body.classList.remove('modal-open');
  }, { once: true });
  return dialog;
}

function closeDialog() {
  const dialog = overlayRoot.querySelector('dialog');
  if (dialog?.open) dialog.close();
  else {
    overlayRoot.innerHTML = '';
    document.body.classList.remove('modal-open');
  }
}

function openPlaceDialog(id) {
  const place = places.find(item => item.id === id);
  if (!place) return;
  const photos = placePhotos(place);
  const visits = sortedVisits(place);
  if (!visits.length && photos.length) { openLightbox(place.id, 0); return; }
  showDialog(`<button class="dialog-close" data-dialog-close aria-label="Close place">${icon('close')}</button>
    <article class="place-visits"><h2>${escapeHtml(place.name)}</h2><p>${escapeHtml(place.location)}</p>
    ${sortedVisits(place).map((visit, index) => {
      const photoIndex = photos.findIndex(photo => photo.visitId === visit.id);
      return `<section class="place-visit"><h3>${escapeHtml(visitDate(visit) || `Visit ${index + 1}`)}</h3>
        ${photoIndex >= 0 ? `<button class="visit-photo" data-lightbox="${place.id}:${photoIndex}"><img src="${escapeHtml(photos[photoIndex].src)}" alt="${escapeHtml(photos[photoIndex].caption || place.name)}"></button>` : ''}
        ${visit.note ? `<p class="visit-note">${escapeHtml(visit.note)}</p>` : ''}
        ${visit.postSlug && posts.some(post => post.slug === visit.postSlug) ? `<a href="#/read/${visit.postSlug}">Notes</a>` : ''}
      </section>`;
    }).join('')}</article>`, 'place-dialog visits-dialog');
}

function openLightbox(placeId, imageIndex = 0) {
  const place = places.find(item => item.id === placeId);
  if (!place) return;
  const photos = placePhotos(place);
  if (!photos.length) return;
  const index = ((Number(imageIndex) || 0) % photos.length + photos.length) % photos.length;
  const photo = photos[index];
  const visitPhotos = photos.map((item, globalIndex) => ({...item, globalIndex})).filter(item => item.visitId === photo.visitId);
  const position = visitPhotos.findIndex(item => item.globalIndex === index);
  const previousIndex = visitPhotos[(position - 1 + visitPhotos.length) % visitPhotos.length].globalIndex;
  const nextIndex = visitPhotos[(position + 1) % visitPhotos.length].globalIndex;
  showDialog(`
    <button class="dialog-close lightbox-close" data-dialog-close aria-label="Close photo">${icon('close')}</button>
    <div class="lightbox-stage"><img src="${escapeHtml(photo.src)}" alt="${escapeHtml(photo.caption || place.name)}"></div>
    <div class="lightbox-caption"><div><h2>${escapeHtml(place.name)}</h2>${photo.caption ? `<p>${escapeHtml(photo.caption)}</p>` : ''}${photoCredit(photo)}</div><p>${escapeHtml(photo.date)}</p></div>
    <div class="lightbox-footer"><button data-open-place="${place.id}">${icon('map')} Back to place</button><div><button data-lightbox="${place.id}:${previousIndex}" aria-label="Previous photo">${icon('chevronLeft')}</button><span>${position + 1} / ${visitPhotos.length}</span><button data-lightbox="${place.id}:${nextIndex}" aria-label="Next photo">${icon('chevronRight')}</button></div></div>`, 'lightbox-dialog');
}

function showToast(message) {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.classList.add('is-visible');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('is-visible'), 2400);
}

function handleReaderScroll() {
  if (currentRoute?.name !== 'reader') return;
  const maxScroll = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
  const post=posts.find(item=>item.slug===currentRoute.slug);
  const progress = post?.kind === 'book'
    ? wholeBookProgress(post, currentRoute.chapter, translationPosition().fraction)
    : Math.min(1, Math.max(0, window.scrollY / maxScroll));
  const bar = document.getElementById('reading-progress-bar');
  const percent = document.getElementById('reader-percent');
  if (bar) bar.style.transform = `scaleX(${progress})`;
  if (percent) percent.textContent = `${Math.round(progress * 100)}%`;

  const headings = [...document.querySelectorAll('.reader-article h2')];
  let activeId = headings[0]?.id;
  headings.forEach((heading) => {
    if (heading.getBoundingClientRect().top < 180) activeId = heading.id;
  });
  document.querySelectorAll('[data-toc-target]').forEach((button) => {
    button.classList.toggle('is-active', button.dataset.tocTarget === activeId && window.scrollY > 300);
  });
}

function handleMenuScroll() {
  const y = Math.max(0, window.scrollY);
  const delta = y - lastScrollY;
  lastScrollY = y;
  if (currentRoute?.name === 'home') return;
  const header = document.querySelector('.archive-header, .reader-header');
  if (y < 120 || (keyboardNavigation && header?.contains(document.activeElement))) {
    document.body.classList.remove('menu-tucked');
    return;
  }
  const direction = Math.sign(delta);
  scrollDistance = direction === scrollDirection ? scrollDistance + Math.abs(delta) : Math.abs(delta);
  scrollDirection = direction;
  if (scrollDistance > (direction > 0 ? 60 : 12)) {
    document.body.classList.toggle('menu-tucked', direction > 0);
  }
}

function routeScrollKey(route) {
  return route.name === 'archive' ? `archive-${route.section}` : route.name;
}

function renderRoute() {
  const nextRoute = getRoute();
  const sameChapter = currentRoute?.name === 'reader' && nextRoute.name === 'reader' && currentRoute.slug === nextRoute.slug &&
    (currentRoute.chapter || posts.find(item=>item.slug===currentRoute.slug)?.chapters?.[0]?.id) === (nextRoute.chapter || posts.find(item=>item.slug===nextRoute.slug)?.chapters?.[0]?.id);
  const savedPosition = sameChapter && (currentRoute.language !== nextRoute.language || currentRoute.comparison !== nextRoute.comparison) ? translationPosition() : null;
  if (nextRoute.name === 'home') {
    window.location.replace(import.meta.env.PROD ? '/index.html' : '/personal/index.html');
    return;
  }
  if (currentRoute) scrollPositions[routeScrollKey(currentRoute)] = window.scrollY;
  if (nextRoute.name === 'reader' && currentRoute?.name !== 'reader') {
    readerOrigin = currentRoute?.name === 'home' ? 'home' : 'archive';
    readerReturnHash = readerOrigin === 'home' ? '#/' : `#/archive/${currentRoute?.section || 'writing'}`;
  }

  atlas?.destroy();
  atlas = null;
  closeDialog();
  revealObserver?.disconnect();

  currentRoute = nextRoute;
  if (nextRoute.name === 'archive') archiveSection = nextRoute.section;
  document.body.dataset.view = nextRoute.name;
  document.body.dataset.section = nextRoute.section || '';
  document.body.classList.remove('menu-tucked');
  lastScrollY = 0;
  scrollDistance = 0;
  cellular.setActive(nextRoute.name !== 'reader');
  window.scrollTo(0, 0);

  if (nextRoute.name === 'reader') {
    const post = posts.find((item) => item.slug === nextRoute.slug);
    if (!post) {
      window.location.hash = '#/archive';
      return;
    }
    document.title = `${post.title} — Union`;
    app.innerHTML = readerTemplate(post);
    if (post.kind === 'book') loadTranslation(post, nextRoute).then(()=>{
      requestAnimationFrame(()=>{
        if(currentRoute!==nextRoute) return;
        restoreTranslationPosition(savedPosition);
        if(nextRoute.anchor) (document.getElementById(`${nextRoute.anchor}-${nextRoute.language==='parallel' ? 'zh' : nextRoute.language}`) || document.getElementById(nextRoute.anchor))?.scrollIntoView();
        handleReaderScroll();
      });
    });
  } else if (nextRoute.name === 'archive') {
    document.title = 'Union — Personal archive';
    app.innerHTML = archiveTemplate();
  } else {
    document.title = 'Union — A personal archive';
    app.innerHTML = homeTemplate();
  }

  updateTime();
  setupReveal();
  requestAnimationFrame(() => {
    const top = nextRoute.name === 'reader' ? 0 : (scrollPositions[routeScrollKey(nextRoute)] || 0);
    window.scrollTo(0, top);
    lastScrollY = top;
    if (nextRoute.name === 'archive') ensureAtlas();
    handleReaderScroll();
  });
}

document.addEventListener('click', async (event) => {
  const target = event.target.closest('button, [data-lightbox]');
  if (!target) return;

  if (target.hasAttribute('data-translation-note')) {
    const panel = document.getElementById('translation-note-panel');
    const note = document.getElementById(`note-${target.dataset.translationNote}`);
    if (!panel || !note) return;
    panel.querySelectorAll('.translation-note').forEach(item => { item.hidden = item !== note; });
    currentNoteButton?.setAttribute('aria-expanded','false');
    currentNoteButton = target;
    target.setAttribute('aria-expanded','true');
    panel.hidden = false;
    positionNotePanel(panel);
    panel.querySelector('.translation-note-content').scrollTop = 0;
    panel.querySelector('[data-close-note]').focus({preventScroll:true});
  } else if (target.hasAttribute('data-close-note')) {
    document.getElementById('translation-note-panel').hidden = true;
    currentNoteButton?.setAttribute('aria-expanded','false');
    currentNoteButton?.focus({preventScroll:true});
  } else if (target.dataset.switch) {
    window.location.hash = target.dataset.switch === 'archive' ? '#/archive' : '#/';
  } else if (target.dataset.archiveSection) {
    window.location.hash = `#/archive/${target.dataset.archiveSection}`;
  } else if (target.hasAttribute('data-menu-recall')) {
    document.body.classList.remove('menu-tucked');
    document.querySelector('.archive-header button, .reader-header button')?.focus({ preventScroll: true });
  } else if (target.dataset.scroll) {
    document.getElementById(target.dataset.scroll)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  } else if (target.dataset.postFilter) {
    postFilter = target.dataset.postFilter;
    renderWriting();
  } else if (target.hasAttribute('data-writing-tag')) {
    writingTag = writingTag === target.dataset.writingTag ? '' : target.dataset.writingTag;
    renderWriting();
  } else if (target.hasAttribute('data-retry-chapter')) {
    const post = posts.find(item => item.slug === currentRoute.slug);
    if (post) loadTranslation(post, currentRoute).then(handleReaderScroll);
  } else if (target.dataset.openBook) {
    openBookReview(target.dataset.openBook);
  } else if (target.dataset.travelView) {
    setTravelView(target.dataset.travelView);
  } else if (target.dataset.focusPlace) {
    atlas?.focusPlace(target.dataset.focusPlace);
    if (window.innerWidth < 760) document.querySelector('.atlas-map-frame')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
  } else if (target.hasAttribute('data-map-reset')) {
    atlas?.reset();
  } else if (target.dataset.openPlace) {
    openPlaceDialog(target.dataset.openPlace);
  } else if (target.dataset.lightbox) {
    const [placeId, index] = target.dataset.lightbox.split(':');
    openLightbox(placeId, Number(index));
  } else if (target.dataset.journeySequence) {
    const placeId = target.dataset.journeySequence;
    closeDialog();
    setTravelView('sequence', placeId);
  } else if (target.dataset.journeyMap) {
    setTravelView('map');
    requestAnimationFrame(() => {
      atlas?.focusPlace(target.dataset.journeyMap);
      document.getElementById('atlas-map-panel')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    });
  } else if (target.hasAttribute('data-dialog-close')) {
    closeDialog();
  } else if (target.dataset.fontSize) {
    readerScale = Math.min(1.2, Math.max(0.9, readerScale + (target.dataset.fontSize === 'increase' ? 0.1 : -0.1)));
    document.getElementById('reader-article')?.style.setProperty('--reader-scale', readerScale.toFixed(1));
    requestAnimationFrame(handleReaderScroll);
    showToast(`Text size ${Math.round(readerScale * 100)}%`);
  } else if (target.hasAttribute('data-reader-back')) {
    window.location.hash = readerReturnHash;
  } else if (target.hasAttribute('data-copy-link')) {
    try {
      await navigator.clipboard.writeText(window.location.href);
      showToast('Link copied');
    } catch {
      showToast('Copy the link from your address bar');
    }
  }
});

document.addEventListener('input', event => {
  if (event.target.matches('[data-writing-query]')) { writingQuery = event.target.value; renderWriting(); }
  if (event.target.matches('[data-photo-query]')) { albumQuery = event.target.value; renderAlbum(); }
  if (event.target.matches('[data-read-query]')) {
    readQuery = event.target.value;
    document.getElementById('read-books').innerHTML = bookEntries(books, 'read', readQuery);
  }
});
document.addEventListener('change', event => {
  if (event.target.matches('[data-writing-tag-select]')) { writingTag = event.target.value; renderWriting(); }
});
window.addEventListener('scroll', handleReaderScroll, { passive: true });
window.addEventListener('resize', handleReaderScroll, { passive: true });
window.addEventListener('scroll', handleMenuScroll, { passive: true });
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape') {
    const panel = document.getElementById('translation-note-panel');
    if (panel && !panel.hidden) panel.querySelector('[data-close-note]').click();
  }
  if (event.key === 'Tab') {
    keyboardNavigation = true;
    document.body.classList.remove('menu-tucked');
  }
});
document.addEventListener('pointerdown', () => { keyboardNavigation = false; });
window.addEventListener('hashchange', renderRoute);
setInterval(updateTime, 30000);
setupMusicPlayer();
renderRoute();
