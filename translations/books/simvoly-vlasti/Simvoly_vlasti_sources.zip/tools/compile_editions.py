"""Compile exported TeX twice; write concise, separate compilation evidence."""
from pathlib import Path
import argparse, collections, hashlib, json, re, subprocess, sys

ROOT=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--sample',action='store_true');ap.add_argument('--probe',action='store_true');args=ap.parse_args()
out=ROOT/('work/review/layout-trial' if args.sample or args.probe else 'output/final')
names=['font-probe'] if args.probe else ['Simvoly_vlasti_zh','Simvoly_vlasti_bilingual']
results=[]
for name in names:
    stable=False
    for n in range(1,5):
        before={ext:(out/(name+ext)).read_bytes() if (out/(name+ext)).exists() else None for ext in ('.toc','.aux')}
        run=subprocess.run(['xelatex','-interaction=nonstopmode','-halt-on-error','-file-line-error',name+'.tex'],cwd=out,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        (out/f'{name}.pass{n}.console.log').write_bytes(run.stdout)
        if run.returncode:
            print(run.stdout.decode('utf8',errors='replace')[-3000:]);sys.exit(run.returncode)
        after={ext:(out/(name+ext)).read_bytes() if (out/(name+ext)).exists() else None for ext in ('.toc','.aux')}
        if n>=2 and before==after:stable=True;break
    assert stable,('TOC and cross references did not converge',name)
    log=(out/(name+'.log')).read_text('utf8',errors='replace')
    missing=sorted(set(re.findall(r'Missing character:.*',log)))
    overflow=re.findall(r'Overfull \\[hv]box.*',log)
    pdf=out/(name+'.pdf')
    item=dict(name=name,passes=n,toc_aux_converged=stable,tex_sha256=hashlib.sha256((out/(name+'.tex')).read_bytes()).hexdigest(),pdf_sha256=hashlib.sha256(pdf.read_bytes()).hexdigest(),missing_characters=missing,overfull_boxes=overflow,pages=re.findall(r'Output written.*',log)[-1:])
    results.append(item);print(json.dumps(item,ensure_ascii=False))
(out/('font-probe-compilation.json' if args.probe else 'compilation.json')).write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n','utf8')
if any(x['missing_characters'] for x in results):sys.exit(2)
