"""Generate reading editions from the accepted master; never run the draft builder.

Run with the bundled Python (Pillow required). XeLaTeX is a separate compilation
step so a successful export cannot be mistaken for layout acceptance.
"""
from __future__ import annotations
import argparse, collections, copy, hashlib, html, json, re, shutil
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
MASTER = ROOT / 'work/review/translation.json'
EXPECTED = '2a7b1abf3eb0e082ec4c42552139bd54780ec312b10903a8f875ee679a06522d'
SLUG = 'simvoly-vlasti'
REVISION = '2026年11月校订阅读版'
NOTICE = ('本稿据鲍里斯·伊万诺维奇·科洛尼茨基《权力的象征与权力之争：1917年俄国革命政治文化研究》2012年第2版数字底本及俄文影印本翻译、校订。'
          '原著权利归原权利人；本稿不是出版社授权版本。俄文显示层据有记录的影印核对修复数字抽取讹误，原作疑点另附校注。'
          '原注按原书各章编号，移至相应阅读节末；内部链接保持唯一。原书页码与本阅读版页码分别标明，未核定的原页不编造页锚。'
          '人名索引保留原书第313—318页的俄文影像，索引页码仍指原书。图版与封底保留原书图像；本稿的内容核对、版面检查与外部史实查证范围分别记录。')
MARK = re.compile(r'⟦(n_\d+)⟧')
TOKEN = re.compile(r'⟦n_\d+⟧|⟪/?(?:em|strong)⟫|\*\*|\*|\[([^\]\n]+)\]\((https?://[^\s)]+)\)|https?://[^\s<>]+')

def load(p): return json.loads(p.read_text('utf-8'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p, obj):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
def clean(s):
    return re.sub(r'^#{1,6}\s+', '', s.replace('\\n','\n').strip())
def source(u): return clean(u.get('source_display_text', u['source_text']))
def zh(u): return clean(u['translation'])
def title(s): return re.sub(r'⟪/?\w+⟫|\*', '', clean(s)).replace('\n',' ')
def label(nid):
    n=int(nid.split('_')[1]); offset=0 if n<=22 else 22 if n<=267 else 267 if n<=793 else 793 if n<=1059 else 1059
    return str(n-offset)

def inline(s):
    """Lossless small inline grammar: FB2 emphasis, Markdown emphasis, refs/URLs."""
    out=[]; stack=[(None,out)]; pos=0
    for m in TOKEN.finditer(s):
        if m.start()>pos: stack[-1][1].append(s[pos:m.start()])
        t=m.group(); ref=MARK.fullmatch(t)
        if ref: stack[-1][1].append(dict(type='note',id=ref[1],label=label(ref[1])))
        elif t in ('⟪em⟫','⟪strong⟫'):
            typ=t[1:-1]; children=[];stack[-1][1].append(dict(type=typ,children=children));stack.append((typ,children))
        elif t in ('⟪/em⟫','⟪/strong⟫'):
            assert len(stack)>1 and stack[-1][0]==t[2:-1],('unbalanced source emphasis',s)
            stack.pop()
        elif t in ('*','**'):
            typ='em' if t=='*' else 'strong'
            # Only treat a delimiter as markup if paired; literal stars survive.
            if len(stack)>1 and stack[-1][0]==typ:stack.pop()
            elif t in s[m.end():]:
                children=[];stack[-1][1].append(dict(type=typ,children=children));stack.append((typ,children))
            else:stack[-1][1].append(t)
        elif t.startswith('['): stack[-1][1].append(dict(type='link',url=m[2],citation=True,children=[m[1]]))
        else:
            # Trailing sentence punctuation belongs outside the URL.
            url=t.rstrip('.,;。；，»”');stack[-1][1].append(dict(type='link',url=url,citation=True,children=[url]))
            if len(url)<len(t):stack[-1][1].append(t[len(url):])
        pos=m.end()
    if pos<len(s):stack[-1][1].append(s[pos:])
    assert len(stack)==1,('unclosed emphasis',s)
    return out

def nodes(s, kind='p'):
    s=clean(s)
    if kind=='poem':
        s=re.sub(r'^~~~poem\s*\n','',s);s=re.sub(r'\n~~~(?:\n|$)','\n',s).strip()
        # Keep poem tails (attributions, final punctuation and refs) with the last line.
        s=re.sub(r'\n(?=⟦n_\d+⟧[。.]?$)','',s)
        return [dict(type='verse',children=inline(s))]
    paragraphs=re.split(r'\n\s*\n',s)
    if kind=='cite':return [dict(type='block',kind='quote',children=[dict(type='block',kind='paragraph',children=inline(p)) for p in paragraphs])]
    if len(paragraphs)>1:return [dict(type='block',kind='paragraph',children=inline(p)) for p in paragraphs]
    return inline(s)

def is_separator(u): return u['kind']=='separator' or (u['kind']=='subheading' and re.fullmatch(r'[\s*＊]+',source(u)))
def asset(u):
    im=u['image'];p=ROOT/im.get('path', 'work/canonical/images/'+im['file'])
    assert sha(p)==im['sha256'],('changed original image',u['id'])
    overrides=ROOT/'work/review/layout-assets.json'
    if overrides.exists():
        ov=load(overrides).get('overrides',{}).get(u['id'])
        if ov:
            assert ov['original_sha256']==im['sha256']
            p=ROOT/ov['path'];assert sha(p)==ov['sha256']
    return p

def groups(d):
    by={u['id']:u for u in d['units']}; taken=set(); out=[]
    for key in ('publication-front','author-preface'):
        m=d['edition_metadata']['reading_sections'][key]
        rows=[by[x] for x in m['unit_ids']];taken.update(m['unit_ids'])
        out.append(dict(id=key,title=m['title_zh'],originalTitle=m['title_ru'],synthetic=True,units=rows))
    pending=[]
    for u in d['units']:
        if u['id'] in taken:continue
        if u['kind']=='heading':
            sec=u['section']
            if sec in ('part1','part3'):pending.append(u);continue
            out.append(dict(id=sec,title=title(zh(u)),originalTitle=title(source(u)),synthetic=False,units=pending+[u]));pending=[]
        elif not out or u['section'] not in ('part2-0',) and u['section']!=out[-1]['id']:
            sec=u['section']
            if sec=='colophon':
                m=d['edition_metadata']['reading_sections']['colophon'];titles=(m['title_zh'],m['title_ru'])
            elif sec=='bio':titles=('作者与本书简介','Об авторе и книге')
            else:raise ValueError(('unhandled section boundary',u['id'],sec,out[-1]['id']))
            out.append(dict(id=sec,title=titles[0],originalTitle=titles[1],synthetic=True,units=[u]))
        else:out[-1]['units'].append(u)
    assert not pending
    assert [u['id'] for c in out for u in c['units']]==[u['id'] for u in d['units']]
    for c in out:
        ids=[]
        for u in c['units']:
            ids.extend(MARK.findall(source(u)))
            assert MARK.findall(source(u))==MARK.findall(zh(u)),('reference mismatch',u['id'])
        c['note_ids']=ids
        if c['id'].startswith('part'):c['partId']=c['id'].split('-')[0]
    return out

def web(chapters, d, out):
    note_by={n['id']:n for n in d['notes']}; result=[]; assets=out/'web/assets';assets.mkdir(parents=True,exist_ok=True)
    for c in chapters:
        item={k:copy.deepcopy(v) for k,v in c.items() if k not in ('units','note_ids','synthetic')}
        item.update(sourceLanguage='ru',sourceLanguageLabel='Русский',body=[],notes={},outline=[])
        if c['id']=='publication-front':
            item['body'].append(dict(id='edition-notice',shared=True,zh=[dict(type='block',kind='notice',children=[NOTICE])],en=[dict(type='block',kind='notice',children=[NOTICE])]))
        for u in c['units']:
            if u.get('image_role')=='invalid_fb2_reference':continue
            row=dict(id=u['id'],canonical_kind=u['kind'],page=u.get('page_label') or (('、'.join(u['printed_pages'])) if u.get('printed_pages') else ''),zh=nodes(zh(u),u['kind']),en=nodes(source(u),u['kind']))
            if is_separator(u):row.update(shared=True,zh=['＊　＊　＊'] if source(u) or zh(u) else [''],en=['＊　＊　＊'] if source(u) or zh(u) else [''])
            elif u['kind']=='image':
                p=asset(u);target=assets/p.name
                if not target.exists() or sha(target)!=sha(p):shutil.copy2(p,target)
                capz=u.get('caption_zh',u.get('alt','原书图版'));capr=u.get('caption_ru','')
                row.update(type='figure',src=f'/writing/{SLUG}/assets/{target.name}',shared=True,readingText=capz,zh=[capz],en=[capr or capz])
                row['imageWidth'],row['imageHeight']=Image.open(p).size
                if u.get('image_role')=='original_index_facsimile':row['linkImage']=True
            elif u['kind'] in ('heading','subheading'):
                row['type']='subheading'
                # Main page heading already printed above the body; chapter roots
                # remain as body headings when preceding the first numbered section.
                if title(zh(u))==c['title'] and u['section']==c['id']:
                    row.update(page='',zh=[dict(type='anchor',id=u['id']+'-heading')],en=[dict(type='anchor',id=u['id']+'-heading')])
                    row.pop('type',None);row['shared']=True
                else:item['outline'].append(dict(anchor=u['id'],title=title(zh(u)),originalTitle=title(source(u)),level=max(1,u.get('level',3)-1)))
            if u.get('editorial_note_zh'):
                for lang in ('zh','en'):row[lang].append(dict(type='block',kind='notice',children=[u['editorial_note_zh']]))
            item['body'].append(row)
        for nid in c['note_ids']:
            n=note_by[nid];item['notes'][nid]=dict(number='原注 '+label(nid),zh=nodes(zh(n)),en=nodes(source(n)))
        save(out/'web'/f"{c['id']}.json",item);result.append(item)
    return result

def esc(s):
    special={'\\':r'\textbackslash{}','&':r'\&','%':r'\%','$':r'\$','#':r'\#','_':r'\_','{':r'\{','}':r'\}','~':r'\textasciitilde{}','^':r'\textasciicircum{}'}
    out=''.join(special.get(c,c) for c in s).replace('\n', '\\newline{}\n')
    # Preserve the printed hard hyphen while allowing both Russian word parts
    # to use Babel's hyphenation (a literal TeX hyphen blocks that).
    return re.sub(r'(?<=[А-Яа-яЁёѢѣ])-+(?=[А-Яа-яЁёѢѣ])',lambda m:r'\babelhyphen{hard}'*len(m[0]),out)

def tex(ns,lang):
    out=[]
    for n in ns:
        if isinstance(n,str):out.append(esc(n));continue
        typ=n['type'];children=lambda:tex(n.get('children',[]),lang)
        if typ=='note':out.append('\\nobreak\\hypertarget{ref-'+n['id']+'-'+lang+'}{}\\hyperlink{note-'+n['id']+'-'+lang+'}{\\textsuperscript{'+n['label']+'}}')
        elif typ in ('em','strong'):out.append(('\\emph{' if typ=='em' else '\\textbf{')+children()+'}')
        elif typ=='link':
            visible=''.join(x for x in n['children'] if isinstance(x,str))
            out.append(('\\url{'+n['url']+'}') if visible==n['url'] else ('\\href{'+n['url'].replace('%',r'\%').replace('#',r'\#')+'}{'+children()+'}'))
        elif typ=='verse':
            stanzas=children().split('\\newline{}\n\\newline{}\n');rendered=[]
            for stanza in stanzas:
                line_count=stanza.count('\\newline{}')+1
                if line_count<=12:
                    rendered.append('\\par\\needspace{'+str(line_count+1)+'\\baselineskip}\n'+stanza.replace('\\newline{}',r'\\*'))
                else:rendered.append(stanza) # Long unsegmented source verse may break naturally.
            out.append('\\begin{readingquote}\n'+'\\par\\smallskip\n'.join(rendered)+'\n\\end{readingquote}')
        elif typ=='block':
            s=children()
            if n['kind']=='quote':out.append('\\begin{readingquote}\n'+s+'\n\\end{readingquote}')
            elif n['kind']=='notice':out.append('\\par{\\small '+s+'}\\par\n')
            else:out.append(s+'\\par\n')
        else:raise ValueError(typ)
    return ''.join(out)

def md(ns,lang):
    out=[]
    for n in ns:
        if isinstance(n,str):out.append(n.replace('\n','  \n'));continue
        typ=n['type'];children=lambda:md(n.get('children',[]),lang)
        if typ=='note':out.append('<a id="ref-'+n['id']+'-'+lang+'"></a>[<sup>'+n['label']+'</sup>](#'+n['id']+')')
        elif typ in ('em','strong'):out.append(('*' if typ=='em' else '**')+children()+('*' if typ=='em' else '**'))
        elif typ=='link':out.append('['+children()+']('+n['url']+')')
        elif typ=='verse':out.append('\n'+ '\n'.join('> '+x for x in children().splitlines())+'\n')
        elif typ=='block':
            s=children()
            out.append(('\n'+'\n'.join('> '+x for x in s.splitlines())+'\n') if n['kind'] in ('quote','notice') else '\n\n'+s+'\n\n')
        else:raise ValueError(typ)
    return ''.join(out)

def render(chapters,d,out,sample=False):
    meta=d['edition_metadata'];note_by={n['id']:n for n in d['notes']}
    preamble=(ROOT/'tools/print_preamble.tex').read_text('utf-8')
    for bilingual in (False,True):
        name='Simvoly_vlasti_'+('bilingual' if bilingual else 'zh');view='俄中对照校订阅读版' if bilingual else '中文校订阅读版'
        langs=['ru','zh'] if bilingual else ['zh']
        cover=('\\begin{titlepage}\\centering\\vspace*{25mm}{\\LARGE '+esc(meta['title_zh'])+'\\par}\\medskip{\\large '+esc(meta['subtitle_zh'])+'\\par}\\vspace{12mm}{\\Large\\itshape '+esc(meta['title_ru'])+'\\par}\\medskip{\\large '+esc(meta['subtitle_ru'])+'\\par}\\vspace{12mm}{\\large '+view+'\\par}\\vfill '+esc(meta['author_zh']+' / '+meta['author_ru'])+'\\par\\bigskip '+esc('圣彼得堡：Лики России，2012年，第2版（修订增补版）')+'\\par\\bigskip '+REVISION+(' · 排版样张' if sample else '')+'\\end{titlepage}')
        ts=[preamble,'\\hypersetup{pdftitle={'+esc(meta['full_title_zh']+' / '+meta['full_title_ru'])+'},pdfauthor={'+esc(meta['author_zh']+' / '+meta['author_ru'])+'},pdfsubject={'+view+'；'+REVISION+'}}',cover,'\\tableofcontents','\\chapter*{阅读说明}',NOTICE]
        ms=['# '+meta['full_title_zh'],'*'+meta['full_title_ru']+'*',meta['author_zh']+' / '+meta['author_ru']+' 著',view+' · '+REVISION,'底本：2012年第2版（修订增补版），Лики России，圣彼得堡。ISBN '+meta['isbn'],NOTICE]
        for c in chapters:
            if c['synthetic']:
                heading=(c['originalTitle']+' / ' if bilingual else '')+c['title'];ts.append('\\chapter{'+esc(heading)+'}');ms.append('\n## '+heading)
            for i,u in enumerate(c['units']):
                uid=u['id'];kind=u['kind']
                if u.get('image_role')=='invalid_fb2_reference':continue
                ms.append('<a id="'+uid+'"></a>')
                ts.append('\\hypertarget{'+uid+'}{}% '+uid)
                if is_separator(u):
                    if source(u) or zh(u):ts.append(r'\par\medskip\centerline{* * *}\medskip');ms.append('\n---\n')
                    else:ts.append(r'\par\smallskip')
                    continue
                if kind in ('heading','subheading'):
                    level=u.get('level',3);command={1:'chapter',2:'section',3:'subsection'}[level]
                    following=next((x for x in c['units'][i+1:] if not is_separator(x)),None)
                    room='205mm' if following and following['kind']=='image' else '5\\baselineskip'
                    h=(title(source(u))+' / ' if bilingual else '')+title(zh(u));ts.append('\\needspace{'+room+'}\\'+command+'{'+esc(h)+'}');ms.append('\n'+'#'*(level+1)+' '+h)
                elif kind=='image':
                    p=asset(u);destination=out/'web/assets'/p.name;destination.parent.mkdir(parents=True,exist_ok=True)
                    if not destination.exists() or sha(destination)!=sha(p):shutil.copy2(p,destination)
                    rel='web/assets/'+p.name
                    capz=u.get('caption_zh',u.get('alt','原书图版'));capr=u.get('caption_ru','')
                    ms.append('!['+capz+']('+rel+')')
                    if u.get('image_role')=='original_index_facsimile':
                        ts.append('\\clearpage\\noindent\\includegraphics[width=\\linewidth,height=229mm,keepaspectratio]{'+rel+'}\\par{\\small '+esc(capz)+'}\\clearpage')
                    else:
                        # These are nonfloating figures; source order is preserved.
                        w,h=Image.open(p).size;desired_height=min(140,148*h/w)
                        ts.append('\\needspace{'+str(round(min(190,desired_height+24),1))+'mm}\\begin{center}\\includegraphics[width=148mm,height=140mm,keepaspectratio]{'+rel+'}\\par{\\small '+esc(capz)+'}\\end{center}')
                    continue
                else:
                    if i and c['units'][i-1]['kind'] in ('heading','subheading'):ts.append(r'\nopagebreak[4]')
                    for lang in langs:
                        ns=nodes(source(u) if lang=='ru' else zh(u),kind)
                        ts.append(tex(ns,lang)+'\n\\par\n');ms.append(md(ns,lang))
                if u.get('editorial_note_zh'):
                    ts.append('\\par{\\small '+esc(u['editorial_note_zh'])+'}\\par');ms.append('> '+u['editorial_note_zh'])
            if c['note_ids']:
                ts.append(r'\needspace{5\baselineskip}\subsection*{原注}');ms.append('\n### 原注\n')
                for nid in c['note_ids']:
                    n=note_by[nid];ms.append('<a id="'+nid+'"></a>\n\n**原注 '+label(nid)+'**')
                    for lang in langs:
                        ns=nodes(source(n) if lang=='ru' else zh(n))
                        ts.append('\\par\\needspace{2\\baselineskip}\\noindent\\hypertarget{note-'+nid+'-'+lang+'}{}\\hyperlink{ref-'+nid+'-'+lang+'}{\\textsuperscript{'+label(nid)+'}} '+tex(ns,lang)+'\\hfill\\hyperlink{ref-'+nid+'-'+lang+'}{\\textsuperscript{\\ensuremath{\\hookleftarrow}}}\\par')
                        ms.append(md(ns,lang)+' [返回'+('俄文' if lang=='ru' else '中文')+'](#ref-'+nid+'-'+lang+')')
        ts.append(r'\end{document}');(out/(name+'.tex')).write_text('\n\n'.join(ts)+'\n',encoding='utf-8');(out/(name+'.md')).write_text('\n\n'.join(ms)+'\n',encoding='utf-8')

SAMPLE = {'pubfront-b001','pubfront-b004','front-b005','intro-h001','intro-b003','part1-h001','part1-1-h001','part1-1-b009','part1-1-b010','part1-1-b011','part1-3-h001','part1-3-b061','part1-3-b063','part2-h001','part2-0-b003','part2-1-h001','part2-1-b003','part2-4-h001','part2-4-b122','part2-4-b123','part2-4-b125','part2-4-b126','source-plate-185-h001','part2-4-b191','part2-4-b193','part2-4-b195','part2-4-b197','part2-4-b276','part3-h001','part3-1-h001','part3-1-b104','part3-3-h001','part3-3-b011','name-index-h001','name-index-b001','bio-b001','bio-b002','bio-b004'}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--sample',action='store_true');ap.add_argument('--web-only',action='store_true');args=ap.parse_args()
    assert sha(MASTER)==EXPECTED,'Accepted master changed. Review and explicitly update build pin.'
    d=load(MASTER);assert (len(d['units']),len(d['notes']))==(1226,1067)
    chapters=groups(d);allids=[nid for c in chapters for nid in c['note_ids']]
    assert len(allids)==len(set(allids))==1067
    assert set(allids)=={n['id'] for n in d['notes']}
    out=ROOT/('work/review/layout-trial' if args.sample else 'output/final');out.mkdir(parents=True,exist_ok=True)
    if args.sample:
        trial=[]
        for c in chapters:
            rows=[u for u in c['units'] if u['id'] in SAMPLE]
            if rows:
                cc=copy.deepcopy(c);cc['units']=rows;cc['note_ids']=[nid for u in rows for nid in MARK.findall(source(u))];trial.append(cc)
        # Representative long bibliography and historical/Ukrainian glyphs.
        trial[-1]['note_ids']+=['n_48','n_303','n_577','n_950']
        chapters=trial
    else:
        ws=web(chapters,d,out)
        save(out/'edition.json',dict(metadata=d['edition_metadata'],revision=REVISION,canonical_sha256=EXPECTED,chapters=ws))
        save(out/'catalog-entry.json',dict(slug=SLUG,type='translation',title=d['edition_metadata']['title_zh'],subtitle=d['edition_metadata']['subtitle_zh'],author=d['edition_metadata']['author_zh']+' / '+d['edition_metadata']['author_ru'],sourceLanguage='ru',sourceLanguageLabel='Русский',views=['zh','en','parallel'],originalEdition=dict(title=d['edition_metadata']['title_ru'],subtitle=d['edition_metadata']['subtitle_ru'],year=2012),tags=['俄国史','政治文化','革命'],parts=[dict(id=f'part{i}',title=title(zh(next(u for u in d['units'] if u['id']==f'part{i}-h001'))),originalTitle=title(source(next(u for u in d['units'] if u['id']==f'part{i}-h001')))) for i in range(1,4)],chapters=[dict(id=c['id'],title=c['title'],originalTitle=c['originalTitle'],dataUrl=f'/writing/{SLUG}/{c["id"]}.json',outline=c['outline'],**({'partId':c['partId']} if c.get('partId') else {})) for c in ws]))
    if not args.sample:
        entry=load(out/'catalog-entry.json');meta=d['edition_metadata']
        entry.update(id=SLUG,kind='book',language='zh-CN',languagePair='Русский / 中文',structured=True,bilingual=True,originalTitle=meta['full_title_ru'],authorZh=meta['author_zh'],originalHeading=dict(title=meta['title_ru'],subtitle=meta['subtitle_ru'],author=meta['author_ru'],language='ru',edition='圣彼得堡：Лики России，2012年，第2版（修订增补版）'),translator='AI 辅助翻译与校订',tags=['History','Politics','Russia'],description='科洛尼茨基论1917年俄国革命的政治文化、权力象征与象征之争；保留完整原注、图版及原书人名索引。',editionNotice=NOTICE)
        for ch in entry['chapters']:
            ch['parallelTitle']=ch['originalTitle']+' / '+ch['title']
            ch['dataUrl']+='?v='+sha(out/'web'/(ch['id']+'.json'))[:12]
        save(out/'catalog-entry.json',entry)
    if not args.web_only:render(chapters,d,out,args.sample)
    save(out/'generation-checks.json',dict(canonical_sha256=EXPECTED,kind='sample' if args.sample else 'full',canonical_units=1226,canonical_notes=1067,exported_units=sum(len(c['units']) for c in chapters),exported_notes=sum(len(c['note_ids']) for c in chapters),chapter_ids=[c['id'] for c in chapters],invalid_image_skipped=['part2-4-b001'],layout='pending actual compilation and rendered inspection',publication='pending'))
    print(json.dumps(dict(output=str(out),chapters=len(chapters),notes=sum(len(c['note_ids']) for c in chapters),sample=args.sample),ensure_ascii=False))

if __name__=='__main__':main()
