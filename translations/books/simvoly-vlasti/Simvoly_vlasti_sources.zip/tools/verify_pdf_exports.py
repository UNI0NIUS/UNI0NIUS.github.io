"""Check actual PDF text, unique destinations and note round trips.

The text check ignores punctuation, whitespace and layout hyphens. It is an
output coverage check, not an independent second semantic review.
"""
import importlib.util,json,re,unicodedata,hashlib
from pathlib import Path
from pypdf import PdfReader
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/final'
spec=importlib.util.spec_from_file_location('edition_builder',ROOT/'tools/build_reviewed_edition.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
d=b.load(b.MASTER);results=[]
def norm(s):return ''.join(c for c in unicodedata.normalize('NFKC',s) if c.isalnum())
def plain(nodes):
    return ''.join(n if isinstance(n,str) else n['label'] if n['type']=='note' else plain(n.get('children',[])) for n in nodes)
for view,langs in [('zh',['zh']),('bilingual',['ru','zh'])]:
    p=OUT/f'Simvoly_vlasti_{view}.pdf';digest=b.sha(p);pdf=PdfReader(p);cache=ROOT/'work/review/pdf-text-cache'/f'{digest}.json';cache.parent.mkdir(exist_ok=True)
    if cache.exists():texts=b.load(cache)
    else:
        texts=[]
        for i,page in enumerate(pdf.pages):
            lines=page.extract_text().splitlines()
            if lines and lines[-1].strip()==str(i):lines.pop()
            texts.append('\n'.join(lines))
        b.save(cache,texts)
    alltext=norm('\n'.join(texts));missing=[];checked=0
    for u in d['units']+d['notes']:
        if 'kind' in u and (u['kind'] in ('image','separator') or b.is_separator(u)):continue
        for lang in langs:
            s=b.source(u) if lang=='ru' else b.zh(u)
            expected=norm(plain(b.nodes(s,u.get('kind','p'))))
            if not expected:continue
            checked+=1
            if expected not in alltext:missing.append(dict(id=u['id'],language=lang,length=len(expected),start=expected[:90]))
    stanza_checks=[];stanza_errors=[];normalized_pages=[norm(t) for t in texts]
    for u in d['units']:
        if u['kind']!='poem':continue
        for lang in langs:
            ns=b.nodes(b.source(u) if lang=='ru' else b.zh(u),'poem')
            rendered=plain(ns)
            for i,stanza in enumerate(re.split(r'\n\s*\n',rendered)):
                lines=stanza.count('\n')+1
                if lines>12:continue
                expected=norm(stanza)
                pages=[i+1 for i,t in enumerate(normalized_pages) if expected and expected in t]
                entry=dict(id=u['id'],language=lang,stanza=i+1,lines=lines,pages=pages)
                stanza_checks.append(entry)
                if not pages:stanza_errors.append(entry)
    destinations=pdf.named_destinations;link_errors=[];internal=0
    for i,page in enumerate(pdf.pages):
        for ref in page.get('/Annots',[]):
            a=ref.get_object();dest=a.get('/Dest');action=a.get('/A')
            if action and action.get('/S')=='/GoTo':dest=action.get('/D')
            if isinstance(dest,str):
                internal+=1
                if dest not in destinations:link_errors.append([i+1,str(dest)])
    for n in d['notes']:
        for lang in langs:
            for prefix in ('note-','ref-'):
                key=prefix+n['id']+'-'+lang
                if key not in destinations:link_errors.append(['missing',key])
    sizes=sorted({tuple(round(float(x),2) for x in pg.mediabox[2:]) for pg in pdf.pages})
    result=dict(view=view,pdf_sha256=digest,pages=len(pdf.pages),a4_page_sizes=sizes,checked_text_records=checked,missing_text=missing,internal_links=internal,link_errors=link_errors,short_stanza_checks=stanza_checks,stanza_errors=stanza_errors,note_targets=sum(k.startswith('note-n_') for k in destinations),reference_targets=sum(k.startswith('ref-n_') for k in destinations),unit_pages={u['id']:pdf.get_destination_page_number(destinations[u['id']])+1 for u in d['units'] if u['id'] in destinations},status='passed' if not missing and not link_errors and not stanza_errors else 'needs investigation')
    results.append(result);print(json.dumps({k:v for k,v in result.items() if k not in ('unit_pages','short_stanza_checks')},ensure_ascii=False),flush=True)
    md=(OUT/f'Simvoly_vlasti_{view}.md').read_text('utf8');ids=re.findall(r'<a id="([^"]+)"',md);assert len(ids)==len(set(ids)),view+' duplicate MD IDs'
    targets=re.findall(r'\]\(#([^)]+)\)',md);assert set(targets)<=set(ids),view+' missing MD targets'
b.save(ROOT/'work/review/pdf-output-checks.json',dict(canonical_sha256=b.EXPECTED,normalization='NFKC letters/digits; removes punctuation, whitespace, page-footer counters and layout hyphens. Full record contiguous matching.',results=results))
if any(x['missing_text'] or x['link_errors'] or x['stanza_errors'] for x in results):raise SystemExit(2)
