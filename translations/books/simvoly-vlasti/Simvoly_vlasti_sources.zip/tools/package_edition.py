"""Package explicit reproducible inputs and accepted reading sources only."""
from pathlib import Path
import hashlib,json,shutil,zipfile
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output/final'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
accepted='2a7b1abf3eb0e082ec4c42552139bd54780ec312b10903a8f875ee679a06522d'
assert sha(ROOT/'work/review/translation.json')==accepted
shutil.copy2(ROOT/'work/review/translation.json',OUT/'translation.reviewed.json')
paths={}
def add(p,name=None):
    assert p.is_file() and p.resolve().is_relative_to(ROOT.resolve()),p
    paths[name or p.relative_to(ROOT).as_posix()]=p
for name in ['build_reviewed_edition.py','compile_editions.py','verify_pdf_exports.py','print_preamble.tex','add_catalog_weights.mjs','package_edition.py']:add(ROOT/'tools'/name)
for rel in ['work/review/translation.json','work/review/glossary.md','work/review/layout-assets.json','work/review/global-final-audit.json','work/review/pdf-output-checks.json','work/review/layout-review-progress.json']:
    add(ROOT/rel)
add(ROOT/'work/review/format-recheck-2026-11-08/page-map.json')
add(ROOT/'work/review/page-label-digits-2026-11-08/change.json')
for dirname in ['work/canonical/images','work/review/assets','output/final/web']:
    for p in (ROOT/dirname).rglob('*'):
        if p.is_file():add(p)
for p in (ROOT/'work/review/source-collation').glob('*audit*.json'):add(p)
for suffix in ['md','tex']:
    for p in OUT.glob('Simvoly_vlasti_*.'+suffix):add(p)
for name in ['README.md','校对与验收说明.md','格式复查与修订.md','catalog-entry.json','edition.json','compilation.json']:add(OUT/name)
fb2=next(ROOT.glob('*.fb2'));add(fb2,'source/original.fb2')
readme=('重生成入口：\n\n'
        'python -X utf8 tools/build_reviewed_edition.py\n'
        'node tools/add_catalog_weights.mjs\n'
        'python -X utf8 tools/compile_editions.py\n'
        'python -X utf8 tools/verify_pdf_exports.py\n\n'
        '依赖：Python 3、Pillow、pypdf，Node.js，TeX Live XeLaTeX，Times New Roman、SimSun。\n'
        '规范主稿：work/review/translation.json；勿运行历史初译/修订重放工具。\n'
        '成果：output/final/。本包含复现所需原图和呈现图，不含字体文件或107MB原DjVu。\n'
        '来源DjVu SHA256：2e2c97897da854235bbbd5693f8c81bfaacc2f9e83afd4a9a8e615a7cac32d7f。\n'
        '保留source_text、显示修复、原注、来源定位和已应用修订的证据摘要。\n'
        'PDF时间戳/运行环境可改变字节哈希；校对与版面核验范围详见output/final/校对与验收说明.md。\n')
members={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in paths.items()}
manifest=dict(canonical_sha256=accepted,source_fb2_original_name=fb2.name,source_djvu_included=False,members=members)
target=OUT/'Simvoly_vlasti_sources.zip'
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,p in sorted(paths.items()):z.write(p,name)
    z.writestr('README-source.txt',readme)
    z.writestr('SOURCE-MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    for name,m in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==m['sha256']
    assert all(not n.startswith(('/','\\')) and '..' not in Path(n).parts for n in z.namelist())
files=[p for p in OUT.iterdir() if p.is_file() and p.suffix in ('.pdf','.zip','.md','.tex','.json') and not p.name.endswith('.console.log')]
(OUT/'SHA256SUMS.txt').write_text('\n'.join(sha(p)+'  '+p.name for p in sorted(files))+'\n','utf8')
print(json.dumps(dict(zip=str(target),bytes=target.stat().st_size,members=len(members)+2,sha256=sha(target)),ensure_ascii=False))
