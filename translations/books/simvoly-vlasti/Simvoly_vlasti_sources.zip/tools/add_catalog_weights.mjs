// Same Unicode word-weight rule as the site's existing readingUnits().
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const out=path.join(root,'output/final');
const entry=JSON.parse(fs.readFileSync(path.join(out,'catalog-entry.json'),'utf8'));
function readingUnits(block){
 const text=nodes=>(Array.isArray(nodes)?nodes:[nodes]).map(node=>typeof node==='string'?node:Array.isArray(node)?text(node):[node?.tex||'',text(node?.children||[]),text(node?.rows||[])].join(' ')).join(' ');
 return Math.max(1,((block.readingText||text(block.en?.length?block.en:block.zh||[])).match(/[\p{L}\p{N}][\p{L}\p{M}\p{N}'’-]*/gu)||[]).length);
}
for(const ch of entry.chapters){
 const data=JSON.parse(fs.readFileSync(path.join(out,'web',ch.id+'.json'),'utf8'));
 ch.readingUnits=data.body.reduce((n,row)=>n+readingUnits(row),0);
}
fs.writeFileSync(path.join(out,'catalog-entry.json'),JSON.stringify(entry,null,2)+'\n');
console.log('Catalog reading units:',entry.chapters.reduce((n,c)=>n+c.readingUnits,0));
