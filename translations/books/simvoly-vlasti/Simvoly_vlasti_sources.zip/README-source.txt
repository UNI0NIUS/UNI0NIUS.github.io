重生成入口：

python -X utf8 tools/build_reviewed_edition.py
node tools/add_catalog_weights.mjs
python -X utf8 tools/compile_editions.py
python -X utf8 tools/verify_pdf_exports.py

依赖：Python 3、Pillow、pypdf，Node.js，TeX Live XeLaTeX，Times New Roman、SimSun。
规范主稿：work/review/translation.json；勿运行历史初译/修订重放工具。
成果：output/final/。本包含复现所需原图和呈现图，不含字体文件或107MB原DjVu。
来源DjVu SHA256：2e2c97897da854235bbbd5693f8c81bfaacc2f9e83afd4a9a8e615a7cac32d7f。
保留source_text、显示修复、原注、来源定位和已应用修订的证据摘要。
PDF时间戳/运行环境可改变字节哈希；校对与版面核验范围详见output/final/校对与验收说明.md。
