"""Index: keep original alphabetical sequence, hierarchy and every page locator."""
from right_city_common import P,unit,text,save_packet
import re
U=[]
def add(kind,refs,zh,**kw):
    U.append(unit('rtc-index-'+str(len(U)+1).zfill(3),kind,refs,zh,source_body=False,**kw))
add('chapter',[[253,0]],'索引',editor_note='按原文词条的字母顺序保留编排；所有数字指向原书页码，非本译本PDF页码。人名附原文便于检索，子条目保留层级。')
terms={
'Ağır Roman (Heavy Roman(i))':'《重罗曼》（Ağır Roman）',
'alienation':'异化','anomie':'失范','Aslan, Şükrü':'阿斯兰，许克吕（Şükrü Aslan）','Augé, Marc':'奥热，马克（Marc Augé）',
'Bakhtin, Mikhail Mikhailovich':'巴赫金，米哈伊尔·米哈伊洛维奇（Mikhail Mikhailovich Bakhtin）',
'Bayat, Asef':'巴亚特，阿塞夫（Asef Bayat）','Belge, Murat':'贝尔盖，穆拉特（Murat Belge）',
'Benjamin, Walter':'本雅明，瓦尔特（Walter Benjamin）',
'Berci Kristin Çöp Masalları (Berji Kristin: Tales from the Garbage Hills)':'《贝尔吉·克里斯廷：垃圾山的故事》（Berci Kristin Çöp Masalları）',
'Berger, John':'伯格，约翰（John Berger）','Çiçekoğlu, Feride':'奇切克奥卢，费里德（Feride Çiçekoğlu）',
'citizenship':'公民身份','consumerism':'消费主义','cosmopolitan nostalgia':'世界主义怀旧','cosmopolitan solidarity':'世界主义团结',
'cultural materialism':'文化唯物主义','deteriorated neighbourhood':'衰败街区','encroachment':'蚕食','quiet encroachment':'静默蚕食',
'Erder, Sema':'埃尔德尔，塞玛（Sema Erder）','Erman, Tahire':'埃尔曼，塔希蕾（Tahire Erman）',
'Ertan, Kıvılcım':'埃尔坦，克维尔吉姆（Kıvılcım Ertan）','existentialism':'存在主义','flâneur':'漫游者',
'Geçgin, Ayhan':'盖奇金，艾汉（Ayhan Geçgin）','gender (women)':'性别（女性）','Genette, Gerard':'热奈特，热拉尔（Gerard Genette）',
'Goonewardena, Kanishka':'古内瓦德纳，卡尼什卡（Kanishka Goonewardena）','Gurbet Kuşları (The Homesick Birds)':'《思乡的鸟儿》（Gurbet Kuşları）',
'Gürbilek, Nurdan':'居尔比莱克，努尔丹（Nurdan Gürbilek）','Güvenç, Murat':'居文奇，穆拉特（Murat Güvenç）',
'Halo Dayı ve İki Öküz (Uncle Halo and Two Oxen)':'《哈洛大叔与两头公牛》（Halo Dayı ve İki Öküz）',
'Harvey, David':'哈维，大卫（David Harvey）','Higgins, John':'希金斯，约翰（John Higgins）',
'informality':'非正规性','inhabiting the city':'栖居于城市',
'İnsan Kısım Kısım, Yer Damar Damar (It Takes All Kinds)':'《人各有别》（İnsan Kısım Kısım, Yer Damar Damar）',
'internally displaced Kurds':'国内流离失所的库尔德人','İzgü, Muzaffer':'伊兹居，穆扎费尔（Muzaffer İzgü）',
'Kaçan, Metin':'卡钱，梅廷（Metin Kaçan）',
'Kafamda Bir Tuhaflık (A Strangeness in My Mind)':'《我脑袋里的怪东西》（Kafamda Bir Tuhaflık）',
'Kemal, Orhan':'凯末尔，奥尔罕（Orhan Kemal）','Kenarda (On the Periphery)':'《在边缘》（Kenarda）',
'Keyder, Çağlar':'凯德尔，恰拉尔（Çağlar Keyder）','Kıray, Mübeccel':'克拉伊，穆贝杰尔（Mübeccel Kıray）',
'Koçak, Orhan':'科恰克，奥尔罕（Orhan Koçak）','Lefebvre, Henri':'列斐伏尔，亨利（Henri Lefebvre）',
'magic realism':'魔幻现实主义','Marcuse, Peter':'马尔库塞，彼得（Peter Marcuse）','Marx, Karl':'马克思，卡尔（Karl Marx）',
'Merrifield, Andy':'梅里菲尔德，安迪（Andy Merrifield）','Meryem, Hatice':'梅里耶姆，哈蒂杰（Hatice Meryem）',
'narratology':'叙事学','nihilism':'虚无主义','oeuvre':'作品',
'Öncü, Ayşe':'翁居，艾谢（Ayşe Öncü）','oral culture':'口头文化','Orhangazi, Özgür':'奥尔汉加齐，厄兹居尔（Özgür Orhangazi）',
'Örs, İlay':'厄尔斯，伊莱（İlay Örs）','Özbek, Meral':'厄兹贝克，梅拉尔（Meral Özbek）',
'Paker, Saliha':'帕克尔，萨利哈（Saliha Paker）','Pamuk, Orhan':'帕慕克，奥尔罕（Orhan Pamuk）',
'periphery':'边缘','Pérouse, Jean-François':'佩鲁斯，让-弗朗索瓦（Jean-François Pérouse）',
'radical left':'激进左翼','right to housing':'住房权','right to the city':'城市权利','right to the city novels':'城市权利小说',
'Ronneberger, Klaus':'龙讷贝格尔，克劳斯（Klaus Ronneberger）','rural to urban migration':'乡城迁移',
'Sassen, Saskia':'萨森，萨斯基娅（Saskia Sassen）','Saunders, Peter':'桑德斯，彼得（Peter Saunders）',
'Schmid, Christian':'施密德，克里斯蒂安（Christian Schmid）','Secor, Anna':'塞科尔，安娜（Anna Secor）',
'Seeman, Melvin':'西曼，梅尔文（Melvin Seeman）','Sennett, Richard':'桑内特，理查德（Richard Sennett）',
'Şenyapılı, Önder':'谢尼亚珀勒，厄恩德尔（Önder Şenyapılı）','Şenyapılı, Tansı':'谢尼亚珀勒，坦瑟（Tansı Şenyapılı）',
'shanty housing':'棚户住房','Simmel, Georg':'齐美尔，格奥尔格（Georg Simmel）','socialist realism':'社会主义现实主义',
'Tekin, Latife':'泰金，拉蒂费（Latife Tekin）','Tester, Keith':'泰斯特，基思（Keith Tester）',
'Tuğal, Cihan':'图阿尔，吉汉（Cihan Tuğal）','urbanisation':'城市化','urbanity':'城市性','alternative urbanity':'另类城市性',
'urban transformation':'城市转型','varoş':'varoş（城市边缘贫困街区）','vending':'沿街叫卖',
'Williams, Raymond':'威廉斯，雷蒙德（Raymond Williams）','Wilson, Elizabeth':'威尔逊，伊丽莎白（Elizabeth Wilson）',
'Wittgenstein, Ludwig':'维特根斯坦，路德维希（Ludwig Wittgenstein）','women':'女性',
'Zürcher, Eric Jan':'祖尔歇，埃里克·扬（Eric Jan Zürcher）'}
terms.update({
'Çiçekoğlu, Feride':'奇切克奥卢，费里代（Feride Çiçekoğlu）',
'Erman, Tahire':'埃尔曼，塔希雷（Tahire Erman）',
'Goonewardena, Kanishka':'古纳瓦德纳，卡尼什卡（Kanishka Goonewardena）',
'Kıray, Mübeccel':'克赖，缪贝杰尔（Mübeccel Kıray）',
'Öncü, Ayşe':'厄恩居，艾谢（Ayşe Öncü）',
'Pérouse, Jean-François':'佩鲁兹，让-弗朗索瓦（Jean-François Pérouse）',
'Secor, Anna':'西科尔，安娜（Anna Secor）',
'Şenyapılı, Önder':'申亚珀勒，厄恩代尔（Önder Şenyapılı）',
'Şenyapılı, Tansı':'申亚珀勒，坦瑟（Tansı Şenyapılı）',
'internally displaced Kurds':'境内流离失所的库尔德人',
'urban transformation':'城市改造','varoş':'varoş（城市边缘区）'})
groups=[]
for n in range(253,257):
    for b in P[n-1]['blocks']:
        if b['block']==0 or n==253 and b['block'] in [16,17]:continue
        for i,l in enumerate(b['lines']):
            x=l['bbox'][0];r=[n,b['block'],i,i+1];s=text([r],False)
            if x<65 or 210<x<230:groups.append({'refs':[r],'sub':60<x<65 or 220<x<230})
            else:
                assert groups
                groups[-1]['refs'].append(r)
seen=[]
for g in groups:
    en=text(g['refs'],False)
    if re.fullmatch('[A-Z]',en):add('index_letter',g['refs'],en);continue
    if '. See ' in en:
        z={'informal employment. See vending':'非正规就业。见“沿街叫卖”',
           'informal housing. See shanty housing':'非正规住房。见“棚户住房”'}[en]
    else:
        m=re.match(r'^(.*?), (\d.*)$',en);assert m,en
        term,loc=m.groups();z=terms[term]+'，'+loc;seen.append(term)
    add('index',g['refs'],z,index_subentry=g['sub'])
assert set(terms)==set(seen),(set(terms)-set(seen))
add('imprint',[[253,16]],'© © 编者（如适用）及作者，2021年，独家授权Springer Nature Switzerland AG。N. Buket Cengiz：《土耳其文学中的城市权利小说：从20世纪60年代至今》，“文学城市研究”丛书。https://doi.org/10.1007/978-3-030-61221-4')
save_packet('index',1000,U,chapter='index',scope='完整原版索引，保留全部页码、参见、子条目和字母顺序。')
