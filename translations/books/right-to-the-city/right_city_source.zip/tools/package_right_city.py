"""Package only this edition's source and review materials."""
from right_city_common import B,W,O,R
from pathlib import Path
import json,zipfile,hashlib
for name in ['right_city_zh.md','glossary.md','review.md','README.md']:
    p=O/name
    p.write_text(p.read_text('utf-8'),encoding='utf-8',newline='\n')
files=[]
for pattern in ['*right_city*.py']:
    files.extend((R/'tools').glob(pattern))
files.append(R/'tools/english_source.py')
files.extend((W/'packets').glob('*.json'))
for name in ['source_pages.json','source_manifest.json','status.json','audit_latest.json','final_review.json','site_export_check.json','external_checks.md','numerical_review_candidates.json']:
    if (W/name).exists():files.append(W/name)
files.extend(W.glob('checkpoint_*.json'))
for name in ['right_city_bilingual.tex','right_city_en.tex','right_city_zh.md','glossary.md','review.md','README.md']:
    files.append(O/name)
files.extend(O.glob('images/*.png'))
archive=O/'right_city_source.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    z.writestr('README.md',(O/'README.md').read_text('utf-8'))
    for p in sorted(set(files)):z.write(p,str(p.relative_to(R)).replace('\\','/'))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    count=len(z.namelist())
manifest={}
for name in ['right_city_bilingual.pdf','right_city_en.pdf','right_city_zh.md','glossary.md','review.md','right_city_source.zip']:
    p=O/name;manifest[name]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(O/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'archive_files':count,'downloads':manifest},ensure_ascii=False))
