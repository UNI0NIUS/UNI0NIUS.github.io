"""Archive the supplied PDF with exact page labels, blocks, lines and font spans."""
from pathlib import Path
import hashlib,json,sys
sys.path.insert(0,str(Path(__file__).parent/'python_libs'))
import pymupdf as fitz
R=Path(__file__).resolve().parents[1]
B=R/'Right to the City Novels in Turkish Literature from the 1960s to the Present'
W=B/'work';W.mkdir(exist_ok=True)
(B/'output').mkdir(exist_ok=True)
src=next(B.glob('*.pdf'));doc=fitz.open(src)
pages=[]
for n,p in enumerate(doc,1):
    blocks=[]
    for b in p.get_text('dict')['blocks']:
        if b['type']==0:
            blocks.append({'block':b['number'],'bbox':b['bbox'],'lines':b['lines']})
    pages.append({'pdf_page':n,'printed_page':p.get_label(),'blocks':blocks})
(W/'source_pages.json').write_text(json.dumps(pages,ensure_ascii=False,indent=2),encoding='utf-8')
(W/'source_manifest.json').write_text(json.dumps({'path':str(src),'sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'pages':len(doc),'toc':doc.get_toc(),'extraction':'PyMuPDF; unmodified span text and page labels'},ensure_ascii=False,indent=2),encoding='utf-8')
for n in [17,18,21,23,34]:
    doc[n-1].get_pixmap(matrix=fitz.Matrix(1.5,1.5)).save(W/f'source_{n:03}.png')
print('Archived',len(pages),'pages; source words',sum(len(p.get_text().split()) for p in doc))
