from right_city_common import unit,save_packet,W,P,text
import json
groups=[];current=[]
for n in range(238,240):
    for b in P[n-1]['blocks']:
        if b['bbox'][1]<50 or (n==238 and b['block']<4):continue
        for j,l in enumerate(b['lines']):
            if l['bbox'][0]<60 and current:groups.append(current);current=[]
            current.append([n,b['block'],j,j+1])
if current:groups.append(current)
S=[{'number':i,'source_blocks':g,'en':text(g,False,True)} for i,g in enumerate(groups,1)]
(W/'ch08_bibliography_source.json').write_text(json.dumps(S,ensure_ascii=False,indent=2)+'\n','utf-8')
T='''塔尔拉巴舍大道；所载书名：从过去到现在的伊斯坦布尔百科全书
五一街区：1980年以前的社会运动与城市
内外翻转的城市中的政治
生活即政治：普通人如何改变中东
一部大师之作
我脑袋里的怪东西
伊斯坦布尔最后的流放者
我脑袋里的怪东西
某种意义上，人们因负罪感而对宗教感兴趣
小说家通过主人公的眼睛看世界
我脑袋里的怪东西
谁在怪？
直面伊斯坦布尔的尝试：边缘、流动与城市记忆
导言；所载书名：漫游者
塔尔拉巴舍；所载书名：从过去到现在的伊斯坦布尔百科全书
寻找断裂线：在“文明冲突”视野下考察土耳其伊斯兰教在土耳其加入欧盟过程中的作用；所载书名：欧盟、土耳其与伊斯兰教'''.splitlines()
assert len(S)==len(T)==16
U=[unit('rtc-ch08-bibliography','heading',[[238,3]],'参考文献')]
for s,t in zip(S,T):
    U.append(unit('rtc-ch08-ref-'+str(s['number']).zfill(3),'bibliography',s['source_blocks'],s['en']+'〔题名译文：'+t+'。〕',join_url=True))
U.append(unit('rtc-ch08-imprint','imprint',[[218,7]],'© 作者，2021年，独家授权Springer Nature Switzerland AG。N. 布凯特·坚吉兹，《土耳其文学中的城市权利小说：从20世纪60年代至今》，“文学城市研究”丛书。第8章DOI：https://doi.org/10.1007/978-3-030-61221-4_8'))
save_packet('ch08refs',840,U,chapter='8',scope='第8章原225—226页全部16条书目及章版权信息；第8章全文完成。')
