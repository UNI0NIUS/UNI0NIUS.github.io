"""Add new reading glyphs without discarding existing website font coverage."""
from pathlib import Path
import sys,json
sys.path.insert(0,str(Path(__file__).parent/'font_libs'))
from fontTools import subset
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont
R=Path(__file__).resolve().parents[1];S=R/'github-sync'
old=TTFont(S/'fonts/reading-cjk.woff2');oldc=set(old.getBestCmap());old.close()
texts=[p.read_text('utf-8') for p in (S/'translations').rglob('*.json')]
texts+=[(S/f).read_text('utf-8') for f in ['translations-data.js','translations.js','bilingual-reader.js']]
needed={ord(c) for c in ''.join(texts) if ord(c)>=0x2e80 or 0x2100<=ord(c)<0x2300}
font=TTFont(R/'tmp/right-city-fonts/NotoSerifSC.ttf');available=set(font.getBestCmap())
missing=needed-available
assert not {c for c in missing if 0x3400<=c<=0x9fff},missing
options=subset.Options();options.name_IDs=['*'];options.name_legacy=True;options.name_languages=['*']
sub=subset.Subsetter(options=options);sub.populate(unicodes=oldc|needed);sub.subset(font)
instantiateVariableFont(font,{'wght':(400,400,600)},inplace=True);font.flavor='woff2'
font.save(S/'fonts/reading-cjk.woff2')
new=TTFont(S/'fonts/reading-cjk.woff2');newc=set(new.getBestCmap())
assert not oldc-newc
print(json.dumps({'previous':len(oldc),'now':len(newc),'new_glyphs':len(newc-oldc),'unavailable_non_cjk':[hex(c) for c in missing]}))
