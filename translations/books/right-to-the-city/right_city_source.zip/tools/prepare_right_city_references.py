"""Split chapter-one bibliography at the original hanging-indent boundaries."""
from right_city_common import P,W,text
import json
groups=[];current=[]
for n in range(35,39):
    for b in P[n-1]['blocks']:
        if b['bbox'][1]<50 or (n==35 and b['block']<3):continue
        for j,l in enumerate(b['lines']):
            if l['bbox'][0]<60 and current:groups.append(current);current=[]
            current.append([n,b['block'],j,j+1])
if current:groups.append(current)
units=[{'number':i,'source_blocks':g,'en':text(g,False,True)} for i,g in enumerate(groups,1)]
(W/'ch01_bibliography_source.json').write_text(json.dumps(units,ensure_ascii=False,indent=2),'utf-8')
for u in units:print(u['number'],u['en'])
