from pathlib import Path
import json,subprocess,sys
from right_city_common import W,text
root=Path(__file__).parent
# Unify the place name already used in chapters 4 and 8; retain all other chapter 6 edits.
p=root/'build_right_city_ch06e.py'
s=p.read_text('utf-8').replace('塔尔拉巴什','塔尔拉巴舍');p.write_text(s,'utf-8')
subprocess.run([sys.executable,str(p)],check=True)
em={
'a':{'rtc-ch08-a003':['作品'],'rtc-ch08-a010':['漫游者'],'rtc-ch08-a011':['漫游者'],'rtc-ch08-a013':['需要'],'rtc-ch08-a015':['作品']},
'b':{'rtc-ch08-b002':['gecekondu']},
'c':{'rtc-ch08-c001':['tepe'],'rtc-ch08-c009':['作品','özgürce','自由地']},
'd':{'rtc-ch08-d007':['棚户房'],'rtc-ch08-d011':['旧棚屋','tuhaf'],'rtc-ch08-d017':['作品']},
}
for packet,values in em.items():
 p=root/f'build_right_city_ch08{packet}.py';s=p.read_text('utf-8')
 if '# BEGIN EMPHASIS CH08' in s:s=s.split('# BEGIN EMPHASIS CH08')[0]+s[s.index('save_packet('):]
 code="\n# BEGIN EMPHASIS CH08\nEM="+repr(values)+"\nfor u in U+locals().get('N',[]):\n    if u['id'] in EM:\n        spans=[]\n        for term in EM[u['id']]:\n            assert term in u['zh'],(u['id'],term)\n            start=0\n            while True:\n                a=u['zh'].find(term,start)\n                if a<0:break\n                b=a+len(term);start=b\n                if not any(a<y and b>x for x,y in spans):spans.append([a,b])\n        u['zh_emphasis_spans']=sorted(spans)\n"
 if packet=='a':code+="for u in U:\n    if u['id']=='rtc-ch08-a009':\n        a=u['zh'].index('作为个体');u['zh_emphasis_spans']=[[a,a+4]]\n"
 if packet=='c':code+="for u in U:\n    if u['id']=='rtc-ch08-c007':\n        a=u['zh'].rindex('在伊斯坦布尔');u['zh_emphasis_spans']=[[a,a+6]]\n"
 if packet=='d':code+="for u in U:\n    if u['id']=='rtc-ch08-d013':\n        a=u['zh'].index('这座多年来一直同自己说话的城市');b=u['zh'].index('，他想说些什么',a);u['zh_emphasis_spans']=[[a,a+2],[a+5,b]]\n"
 s=s.replace('save_packet(',code+'save_packet(',1);p.write_text(s,'utf-8')
 subprocess.run([sys.executable,str(p)],check=True)
# Confirm new hyphen rules do not silently invalidate older source packets.
changes=[]
for p in (W/'packets').glob('*.json'):
 d=json.loads(p.read_text('utf-8'))
 for u in d['units']+d.get('notes',[]):
  e=text(u['source_blocks'],u['kind'] not in {'note','bibliography'},u.get('join_url',False))
  if u['en']!=e:changes.append({'id':u['id'],'old':u['en'],'new':e})
(W/'ch08_normalization_review.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2)+'\n','utf-8')
assert not changes,changes
s=json.loads((W/'status.json').read_text('utf-8'))
s['current_scope']='目前已译完第1—8章正文、原注与各章书目；前置材料、第9章和索引尚待完成。'
(W/'status.json').write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n','utf-8')
