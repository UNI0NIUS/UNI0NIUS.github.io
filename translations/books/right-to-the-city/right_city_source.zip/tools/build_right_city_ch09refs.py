from right_city_common import unit,save_packet,W,P,text
import json
groups=[];current=[]
for n in range(251,253):
    for b in P[n-1]['blocks']:
        if b['bbox'][1]<50 or (n==251 and b['block']<4):continue
        for j,l in enumerate(b['lines']):
            if l['bbox'][0]<60 and current:groups.append(current);current=[]
            current.append([n,b['block'],j,j+1])
if current:groups.append(current)
S=[{'number':i,'source_blocks':g,'en':text(g,False,True)} for i,g in enumerate(groups,1)]
(W/'ch09_bibliography_source.json').write_text(json.dumps(S,ensure_ascii=False,indent=2)+'\n','utf-8')
T='''五一街区：1980年以前的社会运动与城市
非场所
内外翻转的城市中的政治
生活即政治：普通人如何改变中东
土耳其小说传统与《亲爱的无耻的死神》；所载书名：文学论集
城市、女性、自由
土耳其棚户区研究的政治：学术话语中乡村迁入者表征的变化
在边缘
沉默者的份额
哈洛大叔与两头公牛
重罗曼
棚户区
思乡的鸟儿
脱离土地的村民在城市中的生活策略；所载书名：城市化论集
城市权利；所载书名：城市论集
人各有别
导言；所载书名：贝尔吉·克里斯廷：垃圾山的故事
我脑袋里的怪东西
我脑袋里的怪东西
大都市地区的新组成部分：棚户区女性；所载书名：土耳其社会中的女性
贝尔吉·克里斯廷：垃圾山的故事
贝尔吉·克里斯廷：垃圾山的故事
我们电影中最绝望的恋人：乌斯卢尔'''.splitlines()
assert len(S)==len(T)==23
U=[unit('rtc-ch09-bibliography','heading',[[251,3]],'参考文献')]
for s,t in zip(S,T):
    U.append(unit('rtc-ch09-ref-'+str(s['number']).zfill(3),'bibliography',s['source_blocks'],s['en']+'〔题名译文：'+t+'。〕',join_url=True))
U.append(unit('rtc-ch09-imprint','imprint',[[240,7]],'© 作者，2021年，独家授权Springer Nature Switzerland AG。N. 布凯特·坚吉兹，《土耳其文学中的城市权利小说：从20世纪60年代至今》，“文学城市研究”丛书。第9章DOI：https://doi.org/10.1007/978-3-030-61221-4_9'))
save_packet('ch09refs',920,U,chapter='9',scope='第9章原238—239页全部23条书目及章版权信息；第9章全文完成。')
