from right_city_common import unit,save_packet,W,P,text
import json
groups=[];current=[]
for n in range(76,79):
    for b in P[n-1]['blocks']:
        if b['bbox'][1]<50 or (n==76 and b['block']<4):continue
        for j,l in enumerate(b['lines']):
            if l['bbox'][0]<60 and current:groups.append(current);current=[]
            current.append([n,b['block'],j,j+1])
if current:groups.append(current)
S=[{'number':i,'source_blocks':g,'en':text(g,False,True)} for i,g in enumerate(groups,1)]
(W/'ch03_bibliography_source.json').write_text(json.dumps(S,ensure_ascii=False,indent=2)+'\n','utf-8')
T='''探寻城市性
五一街区：1980年以前的社会斗争与城市
城市政治：由内而外
作为政治的生活：普通人如何改变中东
城市、女性、自由
城市生活对乡村迁入女性的意义及她们在迁移中的作用：土耳其案例
成为“城市的”，还是保持“乡村的”：土耳其乡城迁入者对“融入”问题的看法
迁移对土耳其乡村女性的影响：四种新生模式
从城市运动到新社会运动：对卡斯特的评析与土耳其案例
关于城市性的若干观念
东伦敦外围地区的虚无主义与城市多元文化
第三世界的城市化与社会经济发展模式：概述；所载书名：第三世界城市化
棚户区
大众文化中从乡村到城市的音乐变化：伊斯坦布尔民歌酒吧的个案研究
社会变迁与城市化中的低收入群体；所载书名：社会学论集
土耳其女性的角色如何变化；所载书名：文选
城市化论集
棚户住房：欠发达国家中迅速脱离土地与无法融入城市
脱离土地的乡村居民的城市生存策略
大众文化与奥尔罕·根杰巴伊的阿拉贝斯克
城市理论与城市经验：遭遇城市
城市时代的城市特质
城市能力：论我们的挑战与差异
城市会说话吗？
超越种族、宗教与阶级差异：城市主体的生成；所载书名：城市伦理：城市与政治的空间
社会理论与城市问题
眼睛的良知
未融入的城市人口问题
大都市地区的新组成部分：棚户区女性；所载书名：土耳其社会中的女性
未城市化的国家，城市化中的农民
农民城市居民：塞尔维亚乡城流动研究
阿拉贝斯克之争：现代土耳其的音乐与音乐家
当代城市与区域体系中资本主义发展的结构变迁与替代方案
有棚户区、合乘出租车与摊贩的城市
中国城市中流动工人的融入：就业、社会适应与自我认同的经验
城市中的斯芬克斯
战后土耳其的政治与农民：社会历史、文化与现代化'''.splitlines()
assert len(S)==len(T)==37
U=[unit('rtc-ch03-bibliography','heading',[[76,3]],'参考文献')]
for s,t in zip(S,T):
    U.append(unit('rtc-ch03-ref-'+str(s['number']).zfill(3),'bibliography',s['source_blocks'],s['en']+'〔题名译文：'+t+'。〕',join_url=True))
U.append(unit('rtc-ch03-imprint','imprint',[[58,7]],'© 作者，2021年，独家授权Springer Nature Switzerland AG。N. 布凯特·坚吉兹，《土耳其文学中的城市权利小说：从20世纪60年代至今》，“文学城市研究”丛书。第3章DOI：https://doi.org/10.1007/978-3-030-61221-4_3'))
save_packet('ch03refs',330,U,chapter='3',scope='第3章原61—63页完整37条书目与章版权信息。第3章全章齐。')
