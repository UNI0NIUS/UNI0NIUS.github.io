from right_city_common import unit,save_packet,W,P,text
import json
groups=[];current=[]
for n in range(173,176):
    for b in P[n-1]['blocks']:
        if b['bbox'][1]<50 or (n==173 and b['block']<2):continue
        for j,l in enumerate(b['lines']):
            if l['bbox'][0]<60 and current:groups.append(current);current=[]
            current.append([n,b['block'],j,j+1])
if current:groups.append(current)
S=[{'number':i,'source_blocks':g,'en':text(g,False,True)} for i,g in enumerate(groups,1)]
(W/'ch06_bibliography_source.json').write_text(json.dumps(S,ensure_ascii=False,indent=2)+'\n','utf-8')
T='''《重罗曼》与俚语
俚语大词典（附用例）
非自然叙事，非自然叙事学：超越摹仿模式
阿列维派
米歇尔·维勒贝克与梅廷·卡钱的后现代主义取向比较研究：《斗争领域的扩大》与《重罗曼》
五一街区：1980年以前的社会运动与城市
文学论集
土耳其小说传统与《亲爱的无耻的死神》；所载书名：文学论集
《亲爱的无耻的死神》补论；所载书名：文学论集
传闻〔序言〕；所载书名：贝尔吉·克里斯廷：垃圾山的故事
《重罗曼》与美学
梅廷·卡钱的一部“新时代”叙事：《榛子八》（Fındık Sekiz，题名暂作直译）；所载书名：土耳其小说中的后现代主义拓展
土耳其棚户区研究的政治：学术话语中乡村迁入者表征的变化
城市、贫困与发展
作为现代叙事的《贝尔吉·克里斯廷：垃圾山的故事》；所载书名：小说之书
拉蒂费·泰金《贝尔吉·克里斯廷：垃圾山的故事》书评
向更狂野的一面望一眼
语言是我的武器，我敬重它
重罗曼
《重罗曼》作者梅廷·卡钱：对我而言，俚语是土耳其语的旁支语言
思乡的鸟儿
最“重”的伊斯坦布尔作家
城市权利；所载书名：城市论集
陌生化；所载书名：普林斯顿诗歌与诗学百科全书
1950年以后伊斯坦布尔的人口动态；所载书名：老伊斯坦布尔人，新伊斯坦布尔人
大众文化与奥尔罕·根杰巴伊的阿拉贝斯克
语言的另一面：《重罗曼》
拉蒂费·泰金之书
导言；所载书名：贝尔吉·克里斯廷：垃圾山的故事
城市会说话吗？
观看的公民共同体〔市长城市设计研究所〕
眼睛的良知
命运交错的故事：比较语境中的现代土耳其小说
拉蒂费·泰金小说中的主体性与叙事性
大都市边缘的魔幻现实主义：《橘子回归线》与《贝尔吉·克里斯廷：垃圾山的故事》的比较研究
亲爱的无耻的死神
贝尔吉·克里斯廷：垃圾山的故事
贝尔吉·克里斯廷：垃圾山的故事
小说中的城市化：从棚户到别墅城
文化是平常的；所载书名：雷蒙德·威廉斯读本
世界城市权利宪章
从社会学视角看迁移；会议名：成为伊斯坦布尔人
棚户区'''.splitlines()
assert len(S)==len(T)==43
U=[unit('rtc-ch06-bibliography','heading',[[173,1]],'参考文献')]
for s,t in zip(S,T):
    U.append(unit('rtc-ch06-ref-'+str(s['number']).zfill(3),'bibliography',s['source_blocks'],s['en']+'〔题名译文：'+t+'。〕',join_url=True))
U.append(unit('rtc-ch06-imprint','imprint',[[133,8]],'© 作者，2021年，独家授权Springer Nature Switzerland AG。N. 布凯特·坚吉兹，《土耳其文学中的城市权利小说：从20世纪60年代至今》，“文学城市研究”丛书。第6章DOI：https://doi.org/10.1007/978-3-030-61221-4_6'))
save_packet('ch06refs',650,U,chapter='6',scope='第6章原159—161页全部43条书目及章版权信息；第6章全文完成。')
