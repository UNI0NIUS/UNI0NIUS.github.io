from right_city_common import unit,save_packet,W,P,text
import json
groups=[];current=[]
for n in range(130,133):
    for b in P[n-1]['blocks']:
        if b['bbox'][1]<50 or (n==130 and b['block']<6):continue
        for j,l in enumerate(b['lines']):
            if l['bbox'][0]<60 and current:groups.append(current);current=[]
            current.append([n,b['block'],j,j+1])
if current:groups.append(current)
S=[{'number':i,'source_blocks':g,'en':text(g,False,True)} for i,g in enumerate(groups,1)]
(W/'ch05_bibliography_source.json').write_text(json.dumps(S,ensure_ascii=False,indent=2)+'\n','utf-8')
T='''土耳其文学中的女性形象；所载书名：土耳其社会中的女性
探寻城市性
小说中的话语；所载书名：对话的想象：四篇论文
陀思妥耶夫斯基诗学问题
城市、女性、自由
奥尔罕·凯末尔
妓女之城
从文化中心伊斯坦布尔到经济与社会冲突中心伊斯坦布尔：从文化之都向棚户之城的转变
公共领域；所载书名：城市规划词典
土耳其电影：身份、距离与归属
土耳其棚户区研究的政治：学术话语中乡村迁入者表征的变化
奥尔罕·凯末尔：无声者的声音
叙事话语：方法论研究
奥尔罕·凯末尔小说中的现代化、个体与日常生活
奥尔罕·凯末尔的“文学”小说
伊斯皮尔的村庄；网站机构：梅斯吉特利村协会
哈洛大叔与两头公牛
思乡的鸟儿
土耳其语中的批评：历史化的尝试
迁移理论
城市权利；所载书名：城市论集
公民身份的重新定位：新兴的政治主体与空间
城市中的公民身份：迁往伊斯坦布尔的女性的身份、共同体与权利
谢赫·赛义德起义
幽默、讽刺与身份
乡村与城市
城市中的斯芬克斯
哲学研究'''.splitlines()
assert len(S)==len(T)==28
U=[unit('rtc-ch05-bibliography','heading',[[130,5]],'参考文献')]
for s,t in zip(S,T):
    kw={}
    if s['number']==13:kw['editor_note']='本章正文原98页写作 Narrative Discourse Revisited（《叙事话语再探》），并标注1980年；本条书目题名却为 Narrative Discourse: An Essay in Method。此处保留原书正文与书目的题名差异。'
    if s['number']==26:kw['editor_note']='原书本条作者名拼作 Raymons，照录；正文所指为雷蒙德·威廉斯。'
    U.append(unit('rtc-ch05-ref-'+str(s['number']).zfill(3),'bibliography',s['source_blocks'],s['en']+'〔题名译文：'+t+'。〕',join_url=True,**kw))
U.append(unit('rtc-ch05-imprint','imprint',[[95,8]],'© 作者，2021年，独家授权Springer Nature Switzerland AG。N. 布凯特·坚吉兹，《土耳其文学中的城市权利小说：从20世纪60年代至今》，“文学城市研究”丛书。第5章DOI：https://doi.org/10.1007/978-3-030-61221-4_5'))
save_packet('ch05refs',560,U,chapter='5',scope='第5章原116—118页完整28条参考文献及章版权信息。')
