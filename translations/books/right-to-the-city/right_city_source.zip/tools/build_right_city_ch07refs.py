from right_city_common import unit,save_packet,W,P,text
import json
groups=[];current=[]
for n in range(216,218):
    for b in P[n-1]['blocks']:
        if b['bbox'][1]<50 or (n==216 and b['block']<2):continue
        for j,l in enumerate(b['lines']):
            if l['bbox'][0]<60 and current:groups.append(current);current=[]
            current.append([n,b['block'],j,j+1])
if current:groups.append(current)
S=[{'number':i,'source_blocks':g,'en':text(g,False,True)} for i,g in enumerate(groups,1)]
(W/'ch07_bibliography_source.json').write_text(json.dumps(S,ensure_ascii=False,indent=2)+'\n','utf-8')
T='''泽伊廷布尔努的空间转型；所载书名：城墙之外：泽伊廷布尔努
导言：边缘性与文学城市研究；所载书名：文学与边缘城市
哈蒂杰·梅里耶姆《人各有别》（节选）；所载书名：城市精选：伊斯坦布尔
市政当局：土耳其市政官方数据库，按字母检索：D
焚村营
城墙之外：泽伊廷布尔努
爱尔兰的埃夫利亚·切莱比〔莱拉·内兹访谈〕；所载书名：在伊斯坦布尔记忆与遗忘：个人、记忆与归属
在边缘
神话与大都市：瓦尔特·本雅明与城市
泽伊廷布尔努的棚屋；所载书名：城墙之外：泽伊廷布尔努
“盖齐”：公共广场运动剖析
城市权利
东伦敦外围的虚无主义与城市多元文化
棚户区
叙事形式
一本不应被推到边缘的书：《在边缘》
社会变迁与城市化中的低收入群体；所载书名：社会学论集
土耳其女性的角色如何变化；所载书名：文选
20世纪40年代耶迪库莱的皮革工人：“连微生物也活不下去……”
其他的巴黎；所载书名：亨利·列斐伏尔重要著作选
1844年经济学哲学手稿
人各有别
没有个性的人，第1卷
当代伊斯坦布尔边缘地带的大规模建构与拆解；所载书名：从边缘理解城市：非洲、亚洲和中东个案研究的多学科视角
恶心
论异化的含义
大都市地区的新组成部分：棚户区女性；所载书名：土耳其社会中的女性
大都市与精神生活；所载书名：布莱克威尔城市读本
Varoş III（城市边缘区之三）；所载书名：成为伊斯坦布尔：百科全书
导言；所载书名：漫游者
在中心与边缘的交汇处：土耳其单语领域中的库尔德语
艾汉·盖奇金小说中的城市、时间与个人'''.splitlines()
assert len(S)==len(T)==32
U=[unit('rtc-ch07-bibliography','heading',[[216,1]],'参考文献')]
for s,t in zip(S,T):
    U.append(unit('rtc-ch07-ref-'+str(s['number']).zfill(3),'bibliography',s['source_blocks'],s['en']+'〔题名译文：'+t+'。〕',join_url=True))
U.append(unit('rtc-ch07-imprint','imprint',[[176,6]],'© 作者，2021年，独家授权Springer Nature Switzerland AG。N. 布凯特·坚吉兹，《土耳其文学中的城市权利小说：从20世纪60年代至今》，“文学城市研究”丛书。第7章DOI：https://doi.org/10.1007/978-3-030-61221-4_7'))
save_packet('ch07refs',760,U,chapter='7',scope='第7章原203—204页全部32条书目及章版权信息；第7章全文完成。')
