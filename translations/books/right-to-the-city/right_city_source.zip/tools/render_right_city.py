"""Build cumulative Chinese/English reading editions from canonical packets."""
from right_city_common import B,W,O,chars
from itertools import groupby
import json,re
packets=sorted((json.loads(p.read_text('utf-8')) for p in (W/'packets').glob('*.json')),key=lambda d:d['reading_order'])
rows=[(p.get('chapter','front'),u) for p in packets for u in p['units']]
notes={(p.get('chapter','front'),str(n['note_number'])):n for p in packets for n in p.get('notes',[])}
assert len({u['id'] for ch,u in rows})==len(rows)
state=json.loads((W/'status.json').read_text('utf-8'))
complete=state.get('full_translation_complete',False) and state.get('full_review_complete',False)
def plain(s):
    return ''.join({'\\':r'\textbackslash{}','&':r'\&','%':r'\%','$':r'\$','#':r'\#','_':r'\_','{':r'\{','}':r'\}','~':r'\textasciitilde{}','^':r'\textasciicircum{}'}.get(c,c) for c in s)
def esc(s,ch='front',callback=None):
    parts=[];last=0
    for m in re.finditer(r'\[\[(\d+)\]\]|(?:https?://|www\.|vatankitap\.gazetevatan\.com/)[^\s<>〔〕（）。，；：！？、“”‘’]+',s):
        parts.append(plain(s[last:m.start()]))
        if m[1]:parts.append(callback(m[1]) if callback else r'\hyperlink{note-'+ch+'-'+m[1]+r'}{\textsuperscript{'+m[1]+'}}')
        else:
            link=m[0].rstrip('.,;)。')
            nested=link.replace('%',r'\%').replace('#',r'\#')
            rendered=r'\url{'+link+'}' if link.startswith('http') else r'\href{https://'+nested+r'}{\nolinkurl{'+nested+'}}'
            parts.append(rendered+plain(m[0][len(link):]))
        last=m.end()
    parts.append(plain(s[last:]));return ''.join(parts)
def english(u,ch,callback=None,strip_note=False):
    cc=chars(u['source_blocks'],u.get('source_body',u['kind'] not in {'note','bibliography'}),u.get('join_url',False))
    assert ''.join(c for c,_ in cc)==u['en'],u['id']
    if strip_note:
        m=re.match(r'^\d+\s*',u['en'])
        if m:cc=cc[m.end():]
    result=''
    for style,g in groupby(cc,key=lambda p:p[1]):
        s=esc(''.join(c for c,_ in g),ch,callback)
        if 'i' in style:s=r'\emph{'+s+'}'
        if 'b' in style:s=r'\textbf{'+s+'}'
        result+=s
    return result
def chinese(u,ch,callback=None):
    if u.get('zh_emphasis_spans'):
        result=[];last=0
        for a,b in u['zh_emphasis_spans']:
            assert last<=a<b<=len(u['zh']),(u['id'],a,b)
            result.extend([esc(u['zh'][last:a],ch,callback),r'\emph{'+esc(u['zh'][a:b],ch,callback)+'}']);last=b
        result.append(esc(u['zh'][last:],ch,callback));return ''.join(result)
    terms=u.get('zh_emphasis',[])
    if not terms:return esc(u['zh'],ch,callback)
    for term in terms:assert term in u['zh'],(u['id'],term)
    pattern='('+'|'.join(re.escape(t) for t in sorted(terms,key=len,reverse=True))+')'
    return ''.join((r'\emph{'+esc(s,ch,callback)+'}') if s in terms else esc(s,ch,callback) for s in re.split(pattern,u['zh']))
PRE=r'''\documentclass[10pt,a4paper,twoside]{article}
\usepackage{fontspec,xeCJK}
\setmainfont{Times New Roman}
\setCJKmainfont[AutoFakeBold=2,AutoFakeSlant=.2]{SimSun}
\usepackage[a4paper,inner=20mm,outer=25mm,top=21mm,bottom=23mm,marginparwidth=15mm,marginparsep=3mm]{geometry}
\usepackage{xcolor,paracol,fancyhdr,hyperref,graphicx,needspace,xurl}
\urlstyle{same}\hypersetup{unicode=true,hidelinks,pdftitle={Right to the City Novels in Turkish Literature},pdfauthor={N. Buket Cengiz}}
\setlength{\parindent}{1em}\setlength{\parskip}{5pt}\setlength{\columnsep}{8mm}\setlength{\emergencystretch}{3em}
\tolerance=2000\widowpenalty=10000\clubpenalty=10000
\pagestyle{fancy}\fancyhf{}\fancyhead[LE,RO]{\small Right to the City Novels}
\fancyhead[LO,RE]{\small RUNNING}\fancyfoot[C]{\thepage}\setlength{\headheight}{14pt}
\newcommand{\sourcepage}[1]{\marginpar{\raggedleft\scriptsize\color{gray}p.\ #1}}
\twosided[pm]\marginparthreshold{0}\footnotelayout{m}
\begin{document}
'''
def render(bi):
    pre=PRE.replace('RUNNING','中英逐段对照' if bi else 'English reading edition')
    # paracol manages its own margin placement; mparhack conflicts with its columns.
    if not bi:pre=pre.replace(r'\begin{document}',r'\usepackage{mparhack}'+'\n'+r'\begin{document}')
    out=[pre];opened=False;lastlabel=None
    def close():
        nonlocal opened
        if opened:out.append(r'\end{paracol}');opened=False
    def start():
        nonlocal opened
        if bi and not opened:out.append(r'\begin{paracol}{2}');opened=True
    out.append(r'\begin{center}')
    if bi:out.append(r'{\Large\bfseries 土耳其文学中的城市权利小说}\par\smallskip{\large 从20世纪60年代至今}\par\medskip')
    out.append(r'{\large Right to the City Novels in Turkish Literature from the 1960s to the Present}\par\medskip N. Buket Cengiz'+('／N. 布凯特·坚吉兹' if bi else '')+r'\par\end{center}')
    scope=state.get('current_scope','当前正在整理第一章；全书尚未完成。')
    notice=('完整工作译本。' if complete else '工作中分批稿，非全书完成版。')+scope+' 以用户提供的2021年原版PDF为底本。左栏中文、右栏英文。页边为原书印刷页码；原注在页下注中完整保留，中文与英文注号均可跳转。跨页段落合并，译校记另标。'
    ennotice=('Complete reading edition.' if complete else 'Work in progress; this is NOT the complete book.')+' Based on the supplied 2021 PDF. Original printed page references and complete original notes are retained for the included sections. Ligatures, detached diacritics and line-end word divisions are normalized. Paragraphs continuing across source pages are joined.'
    out.append(r'\noindent '+esc(notice if bi else ennotice)+r'\par\bigskip')
    emitted=set()
    for rownum,(ch,u) in enumerate(rows):
        pp=u['printed_pages'];label=pp[0] if len(pp)==1 else pp[0]+'--'+pp[-1]
        marker='' if label==lastlabel else r'\sourcepage{'+plain(label)+'}';lastlabel=label
        def emitnote(num):
            key=(ch,num);n=notes[key]
            if key in emitted:return r'\hyperlink{note-'+ch+'-'+num+r'}{\textsuperscript{'+num+'}}'
            emitted.add(key)
            s=(chinese(n,ch)+r'\par '+english(n,ch,strip_note=True)) if bi else english(n,ch,strip_note=True)
            return r'\footnote['+num+r']{\hypertarget{note-'+ch+'-'+num+'}{}'+s+'}'
        out.append('% UNIT '+u['id'])
        if u['kind'] in {'chapter','heading'}:
            close()
            if u['kind']=='chapter':out.append(r'\clearpage')
            if ch=='index':out.append(r'\setlength{\parskip}{3pt}')
            # Leave space for both language headings and the opening body lines.
            out.append(r'\needspace{'+('9' if bi else '5')+r'\baselineskip}\pdfbookmark['+('0' if u['kind']=='chapter' else '1')+']{'+plain(u['zh'] if bi else u['en'])+'}{'+u['id']+'}')
            out.append(r'\hypertarget{unit-'+u['id']+r'}{}\subsection*{'+(esc(u['zh']) if bi else english(u,ch))+'}')
            if bi:out.append(r'{\small\bfseries '+english(u,ch)+r'\par}\medskip')
            if u.get('editor_note') and bi:out.append(r'{\small\color{black!65}〔译校记：'+esc(u['editor_note'])+r'〕\par}')
            lastlabel=None
            continue
        if u['kind']=='figure':
            size=r'width=.95\textwidth'
            if u.get('image_height'):size+=',height='+str(u['image_height'])+r'\textheight,keepaspectratio'
            close();out.append(r'\needspace{.58\textheight}\noindent'+marker+r'\begin{minipage}{\textwidth}\centering\includegraphics['+size+']{'+u['image']+r'}\par\medskip')
            out.append(r'\raggedright{\small '+(esc(u['zh'])+r'\par ' if bi else '')+english(u,ch)+r'\par}\end{minipage}\par\medskip');continue
        start()
        if bi:
            z=chinese(u,ch,emitnote)
            e=english(u,ch)
            if u.get('toc_target'):
                z=r'\hyperlink{unit-'+u['toc_target']+'}{'+z+'}'
                e=r'\hyperlink{unit-'+u['toc_target']+'}{'+e+'}'
            if u.get('index_subentry'):z=r'\hspace*{1em}'+z;e=r'\hspace*{1em}'+e
            if u['kind']=='index_letter':z=r'\textbf{'+z+'}';e=r'\textbf{'+e+'}'
            if u.get('editor_note'):z+=r'\par\nopagebreak[3]{\footnotesize\color{black!65}〔译校记：'+esc(u['editor_note'])+r'〕\par}'
            # paracol's default sync reserve is only one line; reserve room for
            # both languages to begin the next unit together above the footer.
            reserve='6' if rownum+1<len(rows) and rows[rownum+1][1]['kind']=='index_letter' else '3'
            out.extend([r'\leavevmode{}'+marker+z+r'\par',r'\switchcolumn\relax',e+r'\par',r'\ensurevspace{'+reserve+r'\baselineskip}\switchcolumn*'])
        else:
            if u['kind']=='index_letter':out.append(r'\needspace{4\baselineskip}')
            e=english(u,ch,emitnote)
            if u.get('toc_target'):e=r'\hyperlink{unit-'+u['toc_target']+'}{'+e+'}'
            if u.get('index_subentry'):e=r'\hspace*{1em}'+e
            if u['kind']=='index_letter':e=r'\textbf{'+e+'}'
            out.append(r'\leavevmode{}'+marker+e+r'\par')
    close();assert emitted==set(notes),(set(notes)-emitted)
    out.append(r'\end{document}');return '\n'.join(out)+'\n'
for suffix,bi in [('bilingual',True),('en',False)]:(O/f'right_city_{suffix}.tex').write_text(render(bi),'utf-8')
md=['# 土耳其文学中的城市权利小说：从20世纪60年代至今','N. Buket Cengiz／N. 布凯特·坚吉兹','完整工作译本。' if complete else '**工作中分批稿，非全书完成版。** '+state.get('current_scope','')]
for ch,u in rows:
    z=u['zh']
    for a,b in reversed(u.get('zh_emphasis_spans',[])):z=z[:a]+'*'+z[a:b]+'*'+z[b:]
    z=re.sub(r'\[\[(\d+)\]\]',lambda m:'[^ch'+ch+'-'+m[1]+']',z)
    for term in u.get('zh_emphasis',[]):z=z.replace(term,'*'+term+'*')
    md+=['<!-- '+u['id']+' -->','〔原书第'+'—'.join([u['printed_pages'][0],u['printed_pages'][-1]] if len(u['printed_pages'])>1 else u['printed_pages'])+'页〕']
    if u['kind'] in {'chapter','heading'}:z=('## ' if u['kind']=='chapter' else '### ')+z
    if u['kind']=='figure':md+=['!['+u['zh'].split('。')[0]+']('+u['image']+')']
    md.append(z)
    if u.get('editor_note'):md.append('> 译校记：'+u['editor_note'])
md.append('## 原注')
for (ch,num),n in notes.items():
    z=n['zh']
    for a,b in reversed(n.get('zh_emphasis_spans',[])):z=z[:a]+'*'+z[a:b]+'*'+z[b:]
    for term in n.get('zh_emphasis',[]):z=z.replace(term,'*'+term+'*')
    md.append('[^ch'+ch+'-'+num+']: 〔原书第'+'—'.join(n['printed_pages'])+'页〕'+z)
(O/'right_city_zh.md').write_text('\n\n'.join(md)+'\n','utf-8')
print(json.dumps({'units':len(rows),'notes':len(notes),'words':sum(len(u['en'].split()) for _,u in rows)+sum(len(n['en'].split()) for n in notes.values())}))
