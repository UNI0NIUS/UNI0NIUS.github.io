from right_city_common import O,W
from concurrent.futures import ThreadPoolExecutor
import subprocess,sys
def run(k):
    result=[]
    for i in [1,2]:
        r=subprocess.run(['C:/texlive/2025/bin/windows/xelatex.exe','-interaction=nonstopmode','-halt-on-error',f'right_city_{k}.tex'],cwd=O,capture_output=True)
        (W/f'compile_{k}_{i}.log').write_bytes(r.stdout+r.stderr);result.append(r.returncode)
        if r.returncode:break
    return k,result
with ThreadPoolExecutor(2) as ex:
    results=list(ex.map(run,sys.argv[1:] or ['bilingual','en']))
print(results)
if any(any(v) for k,v in results):raise SystemExit(1)
