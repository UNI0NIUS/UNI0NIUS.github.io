"""Content coverage and PDF checks; does not claim semantic/visual review."""
from right_city_common import P,W,O,line_keys,text
from pathlib import Path
from collections import Counter
import json,re,sys,hashlib
sys.path.insert(0,str(Path(__file__).parent/'python_libs'))
import pymupdf as fitz
packets=sorted((json.loads(p.read_text('utf-8')) for p in (W/'packets').glob('*.json')),key=lambda d:d['reading_order'])
allunits=[u for p in packets for u in p['units']+p.get('notes',[])]
used=Counter(k for u in allunits for r in u['source_blocks'] for k in line_keys(P,r))
assert not [k for k,v in used.items() if v>1],'Duplicate source lines'
for u in allunits:
    assert u['en']==text(u['source_blocks'],u.get('source_body',u['kind'] not in {'note','bibliography'}),u.get('join_url',False)),u['id']
    assert u['zh'].strip(),u['id']
chapters=sorted({p.get('chapter') for p in packets if p.get('chapter')})
coverage={}
# Append a chapter after its entirety has been added; the check is intentionally strict.
for ch,start,end in [('front',1,12),('contents',13,16),('1',17,38),('2',39,57),('3',58,78),('4',79,94),('5',95,132),('6',133,175),('7',176,217),('8',218,239),('9',240,252),('index',253,256)]:
    if ch not in chapters:continue
    expected=set()
    for n in range(start,end+1):
        for b in P[n-1]['blocks']:
            if b['bbox'][1]<50 and n!=1:continue
            raw=''.join(s['text'] for l in b['lines'] for s in l['spans']).strip()
            if raw==P[n-1]['printed_page'] and b['bbox'][1]>500:continue
            expected.update(line_keys(P,[n,b['block']]))
    actual={k for k in used if start<=k[0]<=end}
    missing=expected-actual;extra=actual-expected
    coverage[ch]={'expected_lines':len(expected),'covered_lines':len(actual),'missing':sorted(missing),'extra':sorted(extra)}
    assert not missing and not extra,coverage[ch]
refs={(p.get('chapter','front'),n) for p in packets for u in p['units'] for n in u.get('note_refs',[])}
ns={(p.get('chapter','front'),str(u['note_number'])) for p in packets for u in p.get('notes',[])}
assert refs==ns
report={'units':len(allunits),'source_words':sum(len(u['en'].split()) for u in allunits),'coverage':coverage,'notes':len(ns),'canonical_text':'pass','semantic_review':'not inferred from these checks','pdf':{}}
q=W/'rendered';q.mkdir(exist_ok=True)
for kind in ['bilingual','en']:
    p=O/f'right_city_{kind}.pdf'
    if not p.exists():continue
    d=fitz.open(p);full=''.join(page.get_text() for page in d)
    names=d.resolve_names()
    all_links=[l for page in d for l in page.get_links()]
    bad_links=[l for l in all_links if l['kind']==3 or l['kind']==4 and (l.get('nameddest') not in names or not 0<=l.get('page',-1)<len(d))]
    assert not bad_links,bad_links
    norm=lambda s:re.sub(r'[\W_]','',s).casefold()
    normalized=norm(full);note_integrity=[]
    for packet in packets:
        for n in packet.get('notes',[]):
            row={'id':n['id'],'en':norm(re.sub(r'^\d+\s*','',n['en'])) in normalized}
            if kind=='bilingual':row['zh']=norm(n['zh']) in normalized
            note_integrity.append(row)
            assert all(v for k,v in row.items() if k!='id'),row
    overflow=[];margin_collisions=[]
    for i,page in enumerate(d,1):
        spans=[s for b in page.get_text('dict')['blocks'] for l in b.get('lines',[]) for s in l['spans']]
        labels=[s for s in spans if s['color']!=0 and s['size']<8 and s['text'].startswith('p.')]
        for label in labels:
            hits=[s['text'] for s in spans if s is not label and s['text'].strip() and fitz.Rect(s['bbox']).intersects(fitz.Rect(label['bbox']))]
            if hits:margin_collisions.append({'page':i,'label':label['text'],'hits':hits})
        for b in page.get_text('blocks'):
            if b[0]<10 or b[1]<10 or b[2]>page.rect.width-10 or b[3]>page.rect.height-10:overflow.append([i,list(b[:4])])
        page.get_pixmap(matrix=fitz.Matrix(1,1)).save(q/f'{kind}_{i:03}.png')
    log=(O/f'right_city_{kind}.log').read_text('utf-8',errors='replace')
    issues=[l for l in log.splitlines() if any(s in l for s in ['Overfull','Missing character','! LaTeX Error','Undefined control sequence'])]
    report['pdf'][kind]={'pages':len(d),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'out_of_page':overflow,'margin_collisions':margin_collisions,'log_issues':issues,'links':sum(len(p.get_links()) for p in d),'images':sum(len(p.get_images()) for p in d),'note_integrity':note_integrity}
    assert not overflow and not issues and not margin_collisions,(kind,overflow,issues,margin_collisions)
(W/'audit_latest.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
