from pathlib import Path
import json,subprocess,sys
from right_city_common import W
root=Path(__file__).parent
EM={'a':{'rtc-ch09-a008':['gecekondu'],'rtc-ch09-a011':['作品'],'rtc-ch09-a013':['varoşlu','varoş'],'rtc-ch09-a014':['varoşlu'],'rtc-ch09-a017':['漫游者']},'b':{'rtc-ch09-b010':['varoş']}}
for packet,values in EM.items():
 p=root/f'build_right_city_ch09{packet}.py';s=p.read_text('utf-8')
 if '# BEGIN EMPHASIS CH09' in s:s=s.split('# BEGIN EMPHASIS CH09')[0]+s[s.index('save_packet('):]
 code="\n# BEGIN EMPHASIS CH09\nEM="+repr(values)+"\nfor u in U+locals().get('N',[]):\n    if u['id'] in EM:\n        spans=[]\n        for term in EM[u['id']]:\n            assert term in u['zh'],(u['id'],term)\n            start=0\n            while True:\n                a=u['zh'].find(term,start)\n                if a<0:break\n                b=a+len(term);start=b\n                if not any(a<y and b>x for x,y in spans):spans.append([a,b])\n        u['zh_emphasis_spans']=sorted(spans)\n"
 s=s.replace('save_packet(',code+'save_packet(',1);p.write_text(s,'utf-8')
 subprocess.run([sys.executable,str(p)],check=True)
s=json.loads((W/'status.json').read_text('utf-8'))
s['current_scope']='目前已译完第1—9章正文、原注与各章书目；前置材料和索引尚待完成，全书终校尚未结束。'
(W/'status.json').write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n','utf-8')
