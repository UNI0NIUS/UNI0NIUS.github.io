"""Verify the published edition against the checked local artifacts."""
from pathlib import Path
import urllib.request, hashlib, json, concurrent.futures, datetime
R=Path(__file__).resolve().parents[1]
S=R/'github-sync'
W=R/'Right to the City Novels in Turkish Literature from the 1960s to the Present/work'
BASE='https://uni0nius.github.io/'
paths=['translations-data.js','translations.css','fonts/reading-cjk.woff2','translations/book.html','translations/index.html']
paths += [p.relative_to(S).as_posix() for p in (S/'translations/books/right-to-the-city').rglob('*') if p.is_file()]
def check(path):
    req=urllib.request.Request(BASE+path,headers={'User-Agent':'Translation-publication-verification/1.0','Cache-Control':'no-cache'})
    with urllib.request.urlopen(req,timeout=60) as response:
        data=response.read();code=response.status
    digest=hashlib.sha256(data).hexdigest()
    local=(S/path).read_bytes()
    if Path(path).suffix in {'.js','.css','.html','.json','.md'}:
        local=local.replace(b'\r\n',b'\n')
    assert digest==hashlib.sha256(local).hexdigest(),f'Published file mismatch: {path}'
    return {'path':path,'status':code,'bytes':len(data),'sha256':digest}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    results=list(pool.map(check,paths))
report={'url':BASE+'translations/book.html?id=right-to-the-city-novels','checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'all_remote_files_match_local':True,'files':results}
(W/'publication_verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps({'verified_files':len(results),'all_hashes_match':True,'url':report['url']}))
