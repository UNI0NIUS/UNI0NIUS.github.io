from right_city_common import unit,save_packet,W
import json
S=json.loads((W/'ch02_bibliography_source.json').read_text('utf-8'))
T='''探寻城市性
巴黎的忧郁
现代生活的作家：论波德莱尔
一切坚固的东西都烟消云散了：现代性体验
为了人民而非利润的城市：批判城市理论与城市权利
走向城市文化研究：亨利·列斐伏尔与人文学科
健全的社会
空间、差异、日常生活：阅读亨利·列斐伏尔
马克思主义与日常生活：论亨利·列斐伏尔、居伊·德波及其他一些人
理论与实践中的空间和革命：八条论纲
民主的三种规范性模式
城市权利
反叛的城市：从城市权利到城市革命
现代世界中的日常生活
城市权利
城市革命
谁的权利，怎样的城市？
1844年经济学哲学手稿
城市社会运动中的“城市权利”
亨利·列斐伏尔：批判性导论
没有个性的人，第1卷
悲剧的诞生
迈向世界城市权利宪章
城市公民身份与城市权利
亨利·列斐伏尔与城市日常生活：探寻可能性
恶心
公民身份的重新定位：新兴主体与政治空间
城市能力：论我们的挑战与差异
社会理论与城市问题
亨利·列斐伏尔、城市权利与新的大都市主流
论异化的意义
眼睛的良知
大都市与精神生活
导论；所载书名：漫游者
乡村与城市
世界城市权利宪章'''.splitlines()
assert len(S)==len(T)==36
U=[unit('rtc-ch02-bibliography','heading',[[55,3]],'参考文献')]
for s,t in zip(S,T):
    kw={}
    if s['number']==10:kw['editor_note']='底本沿用上一条的作者省略线，将本条接在Goonewardena等人之后；第1章同一文献明确署Kanishka Goonewardena。此处保留底本书目信息，尚未据文集目录外部核定作者项。'
    U.append(unit('rtc-ch02-ref-'+str(s['number']).zfill(3),'bibliography',s['source_blocks'],s['en']+'〔题名译文：'+t+'。〕',join_url=True,**kw))
U.append(unit('rtc-ch02-imprint','imprint',[[39,7]],'© 作者，2021年，独家授权Springer Nature Switzerland AG。N. 布凯特·坚吉兹，《土耳其文学中的城市权利小说：从20世纪60年代至今》，“文学城市研究”丛书。第2章DOI：https://doi.org/10.1007/978-3-030-61221-4_2'))
save_packet('ch02refs',220,U,chapter='2',scope='第2章原39—41页完整36条书目与章版权信息。第2章全章齐。')
