import json
from right_city_common import W,B
A=json.loads((W/'audit_latest.json').read_text('utf-8'))
ps=sorted((json.loads(p.read_text('utf-8')) for p in (W/'packets').glob('*.json')),key=lambda p:p['reading_order'])
cp=[p for p in ps if p.get('chapter')=='9'];us=[u for p in cp for u in p['units']+p.get('notes',[])]
C={'chapter':'9','source_pdf_pages':[240,252],'source_printed_pages':['227','239'],'source_words':sum(len(u['en'].split()) for u in us),'source_lines':A['coverage']['9']['covered_lines'],'units_including_notes':len(us),'notes':1,'bibliography_entries':23,'visual_qa':'新增双语200—211页、英文105—110页全部接触表已目视。未发现空白页、脚注截断或越界；全书终排仍需统一复核。','source_visual_checks':[240,242,243,250,251,252],'semantic_review':'本章逐段翻译与源文结构核对完成；全书终校待。','source_anomalies':['正文两次Roman(i) (1995)，本章书目为1999[1990]，保留并加译校记。'],'audit':A,'full_book_complete':False}
(W/'checkpoint_ch09.json').write_text(json.dumps(C,ensure_ascii=False,indent=2)+'\n','utf-8')
s=json.loads((W/'status.json').read_text('utf-8'))
s.update(completed_packets=[p['packet'] for p in ps],next='补齐前置PDF1—16和索引253—256，随后全书终校、源码ZIP与个人主页发布验收。前置与索引源文已读取，未建翻译包。',chapters_translated=[str(i) for i in range(1,10)],source_words_translated=A['source_words'],original_notes_translated=57,bibliography_entries=304,current_pdf_pages={k:v['pages'] for k,v in A['pdf'].items()},last_checkpoint='checkpoint_ch09.json')
(W/'status.json').write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n','utf-8')
with (W/'continuation.md').open('a',encoding='utf-8') as f:
 f.write('\n\n## 第九章完成检查点\n第9章PDF240—252（原227—239页）完成：5284源词，57含注单元，1原注，23书目。累计96188源词、57原注、304书目；双语211页／英文110页。全部新增双语200—211、英文105—110接触表已目视，源240、242、243、250、251、252也已核对；audit_latest.json全文覆盖、canonical、注释全文、越界、边注碰撞、缺字与编译均通过。checkpoint_ch09.json为最新章节检查点。\n\n全部9章已翻译；仍未全书完成。下一补前置1—16、索引253—256（源文全部已读取，尚未写包），再全书终校与发布。原封面已抽取xref5278为output/images/cover_original_art.png（仅照片无文字）；work/rendered/source_cover.png为原封面整页1倍图，尚未纳入文档。原封面有照片、完整书名、作者、丛书与Palgrave标志；宜用原页高分辨率渲染保留全貌并适当限高。原封面摄影署名在PDF5 block3，仍需翻译收录。\n\n前置的块号从0开始，可直接引用。1封面、2丛书编辑、3丛书说明及编委、4扉页、5版权、6献辞、7—10致谢、11—12书评、13—15目录、16缩略语。致谢跨页7b4+8b1、8b7+9b1、9b6+10b1；10b5+6因İ分块须合并。姓名可保留原文拉丁字形完整可检索，正文已有惯用中文者保持一致。目录可按x>340的数字行结束每个条目，再匹配正文heading/chapter用现成中译，保留原页码并加跳转。索引253—256为双栏，从左至右阅读顺序已在block顺序中；首行x53/215是新条，x62/224是子条，x71/233是续行。urban transformation从255b24末+255b25续至256b1；索引版权独立253b16，双©照原文。原页码vi、xvi、162、240不在源PDF，不能误判漏页。\n')
print(C['source_words'],C['source_lines'],C['units_including_notes'])
