"""Export the reviewed canonical edition to the existing personal-site reader."""
from right_city_common import B,W,O,R,chars
from itertools import groupby
import json,re,shutil,hashlib
S=R/'github-sync';D=S/'translations/books/right-to-the-city';D.mkdir(parents=True,exist_ok=True)
BOOK='right-to-the-city-novels';BASE='translations/books/right-to-the-city/'
ps=sorted((json.loads(p.read_text('utf-8')) for p in (W/'packets').glob('*.json')),key=lambda p:p['reading_order'])
by={}
for p in ps:by.setdefault(p['chapter'],[]).append(p)
sections={ch:('chapter-'+ch if ch.isdigit() else ch) for ch in by}
targets={u['id']:sections[ch] for ch,pp in by.items() for p in pp for u in p['units']}
def inline_raw(s,ch):
    out=[];last=0
    for m in re.finditer(r'\[\[(\d+)\]\]|(?:https?://|www\.|vatankitap\.gazetevatan\.com/)[^\s<>〔〕（）。，；：！？、“”‘’]+',s):
        if m.start()>last:out.append(s[last:m.start()])
        if m[1]:out.append({'type':'note','id':'rtc-'+ch+'-'+m[1]})
        else:
            url=m[0].rstrip('.,;)。');out.append({'type':'link','url':url if url.startswith('http') else 'https://'+url,'children':[url]})
            if len(url)<len(m[0]):out.append(m[0][len(url):])
        last=m.end()
    if last<len(s):out.append(s[last:])
    return out
def inline(u,lang,ch,note=False):
    if lang=='en':
        cc=chars(u['source_blocks'],u.get('source_body',u['kind'] not in {'note','bibliography'}),u.get('join_url',False))
        if note:
            m=re.match(r'^\d+\s*',u['en'])
            if m:cc=cc[m.end():]
    else:
        cc=[(c,'') for c in u['zh']];spans=u.get('zh_emphasis_spans',[])
        for term in u.get('zh_emphasis',[]):spans+= [(m.start(),m.end()) for m in re.finditer(re.escape(term),u['zh'])]
        for a,b in spans:
            for i in range(a,b):cc[i]=(cc[i][0],'i')
    out=[]
    for style,g in groupby(cc,key=lambda x:x[1]):
        tok=inline_raw(''.join(c for c,_ in g),ch)
        if 'i' in style:tok=[{'type':'em','children':tok}]
        if 'b' in style:tok=[{'type':'strong','children':tok}]
        out.extend(tok)
    return out
def plain(tokens):
    return ''.join(t if isinstance(t,str) else '[['+t['id'].split('-')[-1]+']]' if t['type']=='note' else plain(t['children']) for t in tokens)
def notes_in(tokens):
    return [n for t in tokens if isinstance(t,dict) for n in ([t['id']] if t['type']=='note' else notes_in(t.get('children',[])))]
descriptors=[];export_count=0;note_count=0;all_ids=set()
for ch,packets in by.items():
    section=sections[ch];units=[u for p in packets for u in p['units']]
    if ch=='front':title,eng='封面、出版信息、致谢与赞誉','Cover, Publication Details, Acknowledgements and Praise'
    elif ch=='contents':title,eng='目录与缩略语','Contents and Abbreviations'
    elif ch=='index':title,eng='索引','Index'
    else:title,eng=units[0]['zh'],units[0]['en']
    desc={'id':section,'title':title,'originalTitle':eng,'dataUrl':BASE+section+'.json'}
    descriptors.append(desc)
    body=[]
    for u in units:
        row={'id':u['id'],'type':{'chapter':'heading','heading':'subheading','figure':'figure','quote':'quote'}.get(u['kind'],'paragraph'),
             'page':'–'.join([u['printed_pages'][0],u['printed_pages'][-1]]) if len(u['printed_pages'])>1 else u['printed_pages'][0],
             'zh':inline(u,'zh',ch),'en':inline(u,'en',ch)}
        for lang in ['zh','en']:assert plain(row[lang])==u[lang],(u['id'],lang)
        if row['page'].startswith('PDF '):row['pageKind']='pdf'
        if u.get('editor_note'):row['review']=u['editor_note']
        if u.get('toc_target'):
            target=u['toc_target'];url='translations/book.html?id='+BOOK+'&chapter='+targets[target]+'#'+target
            for lang in ['zh','en']:row[lang]=[{'type':'link','url':url,'children':row[lang]}]
        if u['kind']=='index_letter':
            for lang in ['zh','en']:row[lang]=[{'type':'strong','children':row[lang]}]
        if u.get('index_subentry'):
            for lang in ['zh','en']:row[lang].insert(0,'　')
        if u.get('image'):row['src']=BASE+u['image']
        assert row['id'] not in all_ids;all_ids.add(row['id']);body.append(row)
    notes={}
    for p in packets:
        for n in p['notes']:
            key='rtc-'+ch+'-'+str(n['note_number'])
            notes[key]={'zh':inline(n,'zh',ch,True),'en':inline(n,'en',ch,True)}
            assert plain(notes[key]['zh'])==n['zh']
            assert plain(notes[key]['en'])==re.sub(r'^\d+\s*','',n['en'])
    for lang in ['zh','en']:
        refs=[n for u in body for n in notes_in(u[lang])]
        assert set(refs)==set(notes)
        assert len(refs)==len(set(refs)),(ch,refs)
    data={'id':section,'title':title,'originalTitle':eng,'sourceLanguage':'en','sourceLanguageLabel':'English','body':body,'notes':notes}
    (D/(section+'.json')).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n','utf-8')
    export_count+=len(body);note_count+=len(notes)
downloads=[
('中英对照 PDF','right_city_bilingual.pdf'),('英文 PDF','right_city_en.pdf'),
('中文 Markdown','right_city_zh.md'),('术语表','glossary.md'),('校对记录','review.md'),('源码包 ZIP','right_city_source.zip')]
metadata={'id':BOOK,'title':'土耳其文学中的城市权利小说：从20世纪60年代至今',
'originalTitle':'Right to the City Novels in Turkish Literature from the 1960s to the Present',
'author':'N. Buket Cengiz','translator':'Xiaoyang Hao (AI-assisted working translation)',
'languagePair':'English / 中文','language':'zh-CN','bilingual':True,'example':False,
'description':'城市权利、乡城迁移与伊斯坦布尔：七部土耳其小说的文学与城市研究。全书中英逐段对照，含前置材料、九章正文、57条原注、304条书目及完整索引。',
'editionNotice':'全书中文工作译本 · 2026-10-17。依据2021年英文原版，保留全部前置材料、九章、原注、图像、书目与索引。p.为原书印刷页码；正文引文经英文转译，底本疑点另列译校记。',
'chapters':descriptors,'downloads':[{'label':l,'url':BASE+f} for l,f in downloads]}
(D/'book-metadata.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n','utf-8')
cat=S/'translations-data.js';s=cat.read_text('utf-8');prefix='window.TRANSLATIONS = '
catalog=json.loads(s[len(prefix):].strip().rstrip(';'))
old=[b for b in catalog['books'] if b['id']==BOOK]
if old:catalog['books'][catalog['books'].index(old[0])]=metadata
else:catalog['books'].append(metadata)
cat.write_text(prefix+json.dumps(catalog,ensure_ascii=False,indent=2)+';\n','utf-8')
for _,name in downloads:
    if (O/name).exists():shutil.copy2(O/name,D/name)
for name in ['cover_original.png','figure_1_1.png']:
    (D/'images').mkdir(exist_ok=True);shutil.copy2(O/'images'/name,D/'images'/name)
for html in [S/'translations/index.html',S/'translations/book.html',S/'index.html']:
    s=html.read_text('utf-8')
    s=re.sub(r'translations-data\.js(?:\?v=[^"]+)?','translations-data.js?v='+hashlib.sha256(cat.read_bytes()).hexdigest()[:12],s)
    html.write_text(s,'utf-8')
report={'body_rows':export_count,'original_notes':note_count,'chapters':len(descriptors),'canonical_text':'every source and translation inline flattened and compared exactly','unique_paragraph_ids':len(all_ids)}
(W/'site_export_check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
print(json.dumps(report,ensure_ascii=False))
