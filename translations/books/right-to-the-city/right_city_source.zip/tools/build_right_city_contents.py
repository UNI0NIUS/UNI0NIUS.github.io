"""Original contents and abbreviations, aligned with reviewed chapter headings."""
from right_city_common import P,W,unit,save_packet,text
import json,re
U=[]
def add(kind,refs,zh,**kw):
    U.append(unit('rtc-contents-'+str(len(U)+1).zfill(3),kind,refs,zh,source_body=False,**kw))
add('heading',[[13,0]],'目录',editor_note='目录和索引中的数字均为原书页码。目录条目可跳转至本译本对应标题。')
headings=[]
for p in sorted((json.loads(p.read_text('utf-8')) for p in (W/'packets').glob('*.json')),key=lambda d:d['reading_order']):
    if p.get('chapter','').isdigit():
        headings.extend(u for u in p['units'] if u['kind'] in {'chapter','heading'})
groups=[]
for n in [13,14,15]:
    for b in P[n-1]['blocks']:
        if b['block']==0 or n==13 and b['block']==4:continue
        start=0
        for i,l in enumerate(b['lines']):
            raw=''.join(s['text'] for s in l['spans']).strip()
            if l['bbox'][0]>340 and raw.isdigit():
                groups.append(([[n,b['block'],start,i+1]],raw));start=i+1
        assert start==len(b['lines'])
assert len(groups)==len(headings)+1,(len(groups),len(headings))
for (refs,number),h in zip(groups,headings):
    assert h['printed_pages'][0]==number,(h['id'],number)
    raw=text(refs,False)
    a=re.sub(r'^\d+ | \d+$','',raw)
    b=re.sub(r'^CHAPTER \d+ ','',h['en'])
    norm=lambda s:re.sub(r'\W','',s).lower()
    assert norm(a)==norm(b),(raw,h['en'])
    add('toc',refs,h['zh']+' …… '+number,toc_target=h['id'])
add('toc',groups[-1][0],'索引 …… 241',toc_target='rtc-index-001')
add('heading',[[16,0]],'缩略语')
entries=[
(0,2,'Birds：《思乡的鸟儿》（Gurbet Kuşları）。'),
(2,5,'Hills：《贝尔吉·克里斯廷：垃圾山的故事》（Berci Kristin Çöp Masalları）。'),
(5,7,'Kinds：《人各有别》（İnsan Kısım Kısım, Yer Damar Damar）。'),
(7,9,'Oxen：《哈洛大叔与两头公牛》（Halo Dayı ve İki Öküz）。'),
(9,11,'Periphery：《在边缘》（Kenarda）。'),
(11,13,'Roman(i)：《重罗曼》（Ağır Roman）。'),
(13,15,'Strangeness：《我脑袋里的怪东西》（Kafamda Bir Tuhaflık）。')]
for a,b,z in entries:add('body',[[16,1,a,b]],z)
save_packet('contents',10,U,chapter='contents',scope='完整原版目录及缩略语表；目录标题复用各章定稿，原书页码不改。')
