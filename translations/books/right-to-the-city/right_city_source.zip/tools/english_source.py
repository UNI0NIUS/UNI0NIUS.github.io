"""Explicit PDF block/line slices and conservative line-end dehyphenation."""
import re,unicodedata
KEEP_HYPHEN={'counter','other','more','mega','anti','post','non','trans','neo','inter','intra','fourteenth','human','eighteenth','nineteenth','seventeenth','sixteenth','twentieth','often','ever','fifteen','colonial','agri','plantation','wind','mid'}
def keep_hyphen(left,right):
 pair=(left.lower(),right.lower())
 return (pair[0] in KEEP_HYPHEN or pair in {('large','scale'),('now','ruptured'),('extra','human'),('cum','dissection'),('sub','human'),('african','american'),('tea','bushes'),('korsu','wiwiri'),('long','disappeared'),('off','white'),('place','based'),('webb','gannon'),('multi','layered'),('history','effacing')}) and pair not in {('plantation','scapes'),('agri','business')}
def block_lines(pages,ref):
 p,i=ref[:2];b=next(b for b in pages[p-1]['blocks'] if b['block']==i)
 return b['lines'][ref[2]:ref[3]] if len(ref)==4 else b['lines']
def raw_source(pages,refs):return '\n'.join(''.join(s['text'] for s in l['spans']) for ref in refs for l in block_lines(pages,ref))
def normalize(s,join_url_tail=False):
 s=unicodedata.normalize('NFKC',s)
 if join_url_tail:
  m=re.search(r'https?://|www\.',s)
  if m:return normalize(s[:m.start()])+' '+re.sub(r'\s+','',s[m.start():])
 s=re.sub(r'(\w+)-\n(?=(\w+))',lambda m:m[1]+('-' if keep_hyphen(m[1],m[2]) else ''),s)
 return ' '.join(s.split())
def line_keys(pages,ref):
 p,i=ref[:2];b=next(b for b in pages[p-1]['blocks'] if b['block']==i);a,z=ref[2:4] if len(ref)==4 else (0,len(b['lines']))
 return [(p,i,j) for j in range(a,z)]
