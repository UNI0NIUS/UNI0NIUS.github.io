"""Persist chapter-seven corrections in builders, then rebuild packets."""
from pathlib import Path
import subprocess,sys,json
from right_city_common import W
root=Path(__file__).parent
a=root/'build_right_city_ch07a.py'
s=a.read_text('utf-8').replace('盖奇金没有暗示女性成为工人阶级成员后在心态上产生任何意识变化','盖奇金没有表现出对女性成为工人阶级成员时的心态的任何关注')
a.write_text(s,'utf-8')
em={
'a':{'rtc-ch07-a004':['kenar mahalle','kenar'],'rtc-ch07-a008':['bıra'],'rtc-ch07-note2':['bıra']},
'b':{'rtc-ch07-b014':['漫游'],'rtc-ch07-b015':['漫游者','漫游形态','漫游的手法'],'rtc-ch07-b016':['漫游者','漫游'],'rtc-ch07-b017':['漫游']},
'c':{'rtc-ch07-c007':['漫游者'],'rtc-ch07-c009':['是他可以祭扫父亲坟墓的地方']},
'd':{'rtc-ch07-d003':['varoş']},
'e':{'rtc-ch07-e006':['varoş'],'rtc-ch07-e009':['varoş','少数人'],'rtc-ch07-e016':['把那时候整个伊斯坦布尔凑在一起，一个小贩就能把它背走']},
'f':{'rtc-ch07-f006':['karikatürize','与科兹卢克人一起笑','嘲笑他们'],'rtc-ch07-f007':['varoş'],'rtc-ch07-f008':['varoş'],'rtc-ch07-f015':['kağıtlı']},
}
for packet,values in em.items():
 p=root/f'build_right_city_ch07{packet}.py'
 s=p.read_text('utf-8')
 if '# BEGIN EMPHASIS CH07' in s:s=s.split('# BEGIN EMPHASIS CH07')[0]+s[s.index('save_packet('):]
 # Exact ranges avoid overlapping repeated translations, e.g. flaneur and flanerie.
 code="\n# BEGIN EMPHASIS CH07\nEM="+repr(values)+"\nfor u in U+locals().get('N',[]):\n    if u['id'] in EM:\n        spans=[]\n        for term in EM[u['id']]:\n            start=0\n            while True:\n                a=u['zh'].find(term,start)\n                if a<0:break\n                b=a+len(term);start=b\n                if not any(a<y and b>x for x,y in spans):spans.append([a,b])\n        u['zh_emphasis_spans']=sorted(spans)\n"
 if packet=='c':code+="for u in U:\n    if u['id']=='rtc-ch07-c009':\n        a=u['zh'].index('是他可以');u['zh_emphasis_spans']=[[a,a+1]]\n"
 s=s.replace('save_packet(',code+'save_packet(',1)
 p.write_text(s,'utf-8')
 subprocess.run([sys.executable,str(p)],check=True)
s=json.loads((W/'status.json').read_text('utf-8'))
s['current_scope']='目前已译完第1—7章正文、原注与各章书目；前置材料、第8—9章和索引尚待完成。'
(W/'status.json').write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n','utf-8')
