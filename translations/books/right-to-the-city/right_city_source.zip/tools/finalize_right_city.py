"""Record reviewed scope, prepare documentation and final edition status."""
from right_city_common import B,W,O,R
import json,hashlib,re
ps=sorted((json.loads(p.read_text('utf-8')) for p in (W/'packets').glob('*.json')),key=lambda d:d['reading_order'])
us=[u for p in ps for u in p['units']+p['notes']]
s=json.loads((W/'status.json').read_text('utf-8'))
s.update(status='translation_and_review_complete',completed_packets=[p['packet'] for p in ps],
 full_translation_complete=True,full_review_complete=True,publication='preparing',
 next='发布全书并验证线上阅读、注释和下载。',source_words_translated=sum(len(u['en'].split()) for u in us),
 current_scope='包含完整前置材料、九章正文、全部原注、书目与索引。',figures=2,
 current_pdf_pages={'bilingual':223,'en':118},last_checkpoint='final_review.json')
(W/'status.json').write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n','utf-8')
for p in ps:
 p['full_book_complete']=True
 (W/'packets'/(p['packet']+'.json')).write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n','utf-8')
glossary=(B/'术语工作表.md').read_text('utf-8')
glossary=glossary.replace('# 术语与题名工作表','# 术语与题名表').replace('待第2章补充其历史语境','第2章展开其历史语境')
glossary+='\n\n## 第九章与整书统一\n\nlegitimacy＝正当性；cityness／citiness＝城市特质（与urbanity城市性区分）；urban transformation＝城市改造，描述广义变化时依语境译转型；right to housing＝住房权，right to habitat＝居所权。索引采用正文的人名译法并附原文。致谢中多数姓名保留拉丁原文，以保证完整、可检索。\n\n本表中“待核”指所引外部文献尚未取得核定，不表示相应文字漏译。详细处理见校对记录。\n'
(O/'glossary.md').write_text(glossary,'utf-8')
review=['# 全书校对记录','版本日期：2026-10-17。中文工作译本，依据用户提供的2021年英文PDF。','## 范围与完整性',
'原文件256个PDF页。除重复页眉及独立页码外，前置页、九章、各章版权标记、索引的9493条源文本行全部纳入。共1286个含注单元，其中正文／标题／书目／图注／索引等1229单元、57条原注；规范化英文约99915词。各章书目共304条，重复出现的书目保留在各章原处。',
'原书印刷页码与PDF页序分别记录；vi、xvi、162、240并非源PDF中的缺译页，而是文件原有页码序列中的空缺。没有把重排PDF页码冒充原书页码。',
'## 翻译与统一处理',
'逐段翻译并对照源文，跨页段落合并。保留引文、限定语、作者写作时点及原注号。书中小说引文依据本书英文译述转译，未声称逐一核对土耳其语原著。术语区分城市权利／住房权／居所权、城市性／城市特质、融入／同化、闲荡者／漫游者；人名、七部小说书名与索引统一。',
'英文保留源文读法和字体强调，修复PDF连字、分离的土耳其语附加符号与行末断词；不以常识静默改写底本。中文保留有意义的强调。书目保留原作者、年份、题名、出版信息及可检索原文，并附中文题名说明。封面及图1.1保留原图、完整图注与摄影／地图来源。',
'对所有正文、引文与原注的三至四位数字另作筛查，仅4个候选：330,000两处译作33万；100译一百；500译五百，均已逐一确认数值一致。',
'## 版式与数据验收',
'整书双语、英文PDF全部渲染并查看接触表；前置页、图、脚注和索引另作针对性检查。修复索引字母分组孤行与末尾版权信息挤出一页的问题。双语最终223页，英文118页。自动检查未发现文字越界、页边标签重叠、缺字、Overfull或LaTeX错误。57条原注的英中全文在双语PDF中逐一检索，英文PDF中英文注全文逐一检索，均通过。目录提供对应标题跳转，原注保留页下注及跳转。',
'网页导出采用主页现有逐段对照阅读器，12个阅读单元，1229个稳定段落ID。英中结构化文本展平后分别与规范源文和中文定稿逐项比对；57个原注的引用集合与注释集合一致。网页中文字体新增1630个字形且保留全部既有字形。',
'## 逐处译校记']
for p in ps:
 for u in p['units']+p['notes']:
  if u.get('editor_note'):review.append('### '+u['id']+' · 原书 '+ '—'.join(u['printed_pages'])+'\n\n'+u['editor_note'])
review+=['## 外部核验范围',(W/'external_checks.md').read_text('utf-8').replace('# 有针对性的外部核验','有针对性的外部核验',1),
'## 保留的校订边界','本稿完成了源文覆盖、逐段翻译、术语统一、排版和数据检查；这不等于独立核定书中全部史实、引文或文献。源文中的年份矛盾、亲属关系与婚姻表述疑点等均保留并明示，未取得外部原文证据之处没有宣称已核实。']
(O/'review.md').write_text('\n\n'.join(review)+'\n','utf-8')
source=next(B.glob('*.pdf'))
readme=f"""# 《土耳其文学中的城市权利小说：从20世纪60年代至今》

N. Buket Cengiz（N. 布凯特·坚吉兹），2021年。全书中文工作译本，2026-10-17。

## 阅读与文件

- right_city_bilingual.pdf：中英逐段对照，左中文右英文，223页。
- right_city_en.pdf：完整英文整理版，118页。
- right_city_zh.md：完整中文Markdown，原注使用标准脚注语法；离线图片位于同级images目录，见源码包。
- glossary.md：术语、题名及人名表。
- review.md：校对记录、底本疑点及实际完成的外部核验。
- right_city_source.zip：逐段双语数据、源文行定位、TeX、生成脚本、图片及校对资料。

原版256页均已覆盖，包括出版前置材料、九章、57条原注、304条各章书目、封面和地图、完整索引。目录与索引数字为原书印刷页码。

网页阅读：https://uni0nius.github.io/translations/book.html?id=right-to-the-city-novels

## 源码复现

ZIP内保持tools目录与本书目录并列。规范译文在本书work/packets/*.json，reading_order指定顺序，source_blocks定位到work/source_pages.json。每个单元具有稳定ID；跨页段落保留完整来源。优先编辑规范包，不要直接改生成PDF。

从解压根目录运行 python tools/render_right_city.py，再运行 python tools/compile_right_city.py。需要Python 3、XeLaTeX、Times New Roman和SimSun；编译器路径可在compile_right_city.py内改为本机xelatex。audit_right_city.py另需PyMuPDF。不要为重排而重跑早期分章builder：这些是历史翻译生成脚本，后续修订已汇总到规范包。

源码包含生成TeX，可在本书output目录直接对两个.tex文件分别执行两遍xelatex。source_pages.json是所供PDF的带字体与坐标文本抽取，可据此重新检查覆盖。原PDF哈希：{hashlib.sha256(source.read_bytes()).hexdigest()}。

英文原作及原图的权利归各自权利人所有。中文为AI辅助工作译本，不代表授权出版中译本；引文经所供英文底本转译。
"""
(O/'README.md').write_text(readme,'utf-8')
r={'translation_complete':True,'scope':'source PDF 1–256, all non-running-header text','semantic_review':'逐段翻译时核对；整书术语、人名、小说题名、索引及数字候选复核；底本矛盾显式标注','visual_review':'所有双语／英文页面接触表已查看，索引修订页另复核','numerical_candidates':4,'numerical_findings':'all equivalent Chinese number representations','external_verification':'targeted only; see external_checks.md','publication_verification':'pending'}
(W/'final_review.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n','utf-8')
print('Documentation and full-book status prepared')
