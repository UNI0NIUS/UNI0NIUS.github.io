"""Lossless references and explicit normalization for the Right to the City edition."""
from pathlib import Path
import json,re,unicodedata
from english_source import block_lines,line_keys
R=Path(__file__).resolve().parents[1]
B=R/'Right to the City Novels in Turkish Literature from the 1960s to the Present'
W=B/'work';O=B/'output';P=json.loads((W/'source_pages.json').read_text('utf-8'))
KEEP={'double','low','pseudo','anti','non','post','pre','self','nineteenth','twentieth','twenty','left','right','middle','working','upper','lower','full','part','short','long','well','old','second','first','third'}
PAIRS={('nation','state'),('city','centre'),('cross','disciplinary'),('cross','cultural'),('high','rise'),('neo','liberal'),('human','made'),('political','economic'),('capitalist','industrial'),('charter','for'),('asylum','seekers'),('haydarpaşa','sirkeci'),('in','depth'),('industrial','urban'),('rural','urban'),('macro','scale')}
PAIRS.update({('migrant','receiving'),('thought','provoking'),('hot','blooded'),('so','called'),('istanbul','yazari'),('run','down'),('glue','sniffer'),('1940','li')})
PAIRS.update({('psycho','narration'),('fault','line'),('three','quarters')})
REPAIRS={'Fiﬁand':'Fifi and','Fiﬁsounds':'Fifi sounds','´c':'ć','¸S':'Ş','¸s':'ş','S¸':'Ş','s¸':'ş','˘g':'ğ','˘G':'Ğ','g˘':'ğ','G˘':'Ğ','˙I':'İ','I˙':'İ','ˆa':'â','ˆA':'Â'}
def chars(refs,body=True,join_url=False):
    cc=[]
    for ref in refs:
        for l in block_lines(P,ref):
            for s in l['spans']:
                st=('i' if 'Italic' in s['font'] else '')+('b' if 'Bold' in s['font'] else '')
                t=s['text']
                if body and s['size']<8 and t.strip().isdigit(): t='[['+t.strip()+']]';st=''
                cc.extend((c,st) for c in t)
            cc.append(('\n',''))
    def replace(old,new):
        nonlocal cc
        raw=''.join(c for c,_ in cc)
        while old in raw:
            j=raw.index(old);st=cc[j][1];cc[j:j+len(old)]=[(c,st) for c in new];raw=''.join(c for c,_ in cc)
    for a,z in REPAIRS.items():replace(a,z)
    cc=[(c,st) for t,st in cc for c in unicodedata.normalize('NFKC',t)]
    raw=''.join(c for c,_ in cc);delete=set()
    for m in re.finditer(r'(\w+)-\n(?=(\w+))',raw):
        delete.add(m.end()-1)
        if m[1].lower() not in KEEP and (m[1].lower(),m[2].lower()) not in PAIRS:delete.add(m.end()-2)
    if join_url:
        # Bibliographies are parsed one entry per unit; only a final URL may span lines.
        for m in re.finditer(r'(?:https?://|www\.|vatankitap\.gazetevatan\.com/)',raw):
            end=re.search(r'\.\s+(?:Accessed|Retrieved)|\s+Accessed',raw[m.end():])
            stop=m.end()+end.start() if end else len(raw)
            delete.update(j for j in range(m.start(),stop) if raw[j].isspace())
    out=[]
    for j,(c,st) in enumerate(cc):
        if j in delete:continue
        if c.isspace():
            if out and out[-1][0]!=' ':out.append((' ',''))
        else:out.append((c,st))
    if out and out[-1][0]==' ':out.pop()
    return out
def text(refs,body=True,join_url=False):return ''.join(c for c,_ in chars(refs,body,join_url))
def unit(uid,kind,refs,zh,**extra):
    en=text(refs,extra.get('source_body',kind not in {'note','bibliography'}),extra.get('join_url',False))
    u={'id':uid,'kind':kind,'source_blocks':refs,'printed_pages':list(dict.fromkeys(P[r[0]-1]['printed_page'] or 'PDF '+str(r[0]) for r in refs)),'en':en,'zh':zh,'status':'translated_source_checked','note_refs':re.findall(r'\[\[(\d+)\]\]',en)}
    u.update(extra)
    if kind!='note':assert u['note_refs']==re.findall(r'\[\[(\d+)\]\]',zh),(uid,u['note_refs'])
    return u
def save_packet(name,order,units,notes=None,**extra):
    folder=W/'packets';folder.mkdir(exist_ok=True)
    data={'packet':name,'reading_order':order,'units':units,'notes':notes or [],'full_book_complete':False,**extra}
    (folder/(name+'.json')).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n','utf-8')
    print(name,len(units),'units',len(notes or []),'notes',sum(len(u['en'].split()) for u in units+(notes or [])),'words')
