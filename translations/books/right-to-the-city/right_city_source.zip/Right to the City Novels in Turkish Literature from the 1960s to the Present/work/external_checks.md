# 有针对性的外部核验

以下仅记录实际完成的核验；不表示已经独立核对全书所有引文和参考文献。

## 第2章原24页：波拿巴政变年份

- 底本表述：1848年经济危机引出1852年起义，继而于1853年发生波拿巴政变。原文Haussman/Haussmann异拼也同时存在。
- 法国总统府历史年表 *Louis-Napoléon Bonaparte*：1851年12月1—2日发生政变；1852年12月2日第二帝国开始。已实际打开读取，非仅根据搜索摘要。来源：[法国总统府年表](https://www.elysee.fr/louis-napoleon-bonaparte)。
- 法国国家图书馆展览文章 *Félix Nadar : le Paris souterrain*（Bernd Stiegler）：奥斯曼任塞纳省行政长官时间为1853年6月至1870年1月。已实际打开读取。来源：[BnF展览文章](https://expositions.bnf.fr/les-nadar/les-innovations/le-paris-souterrain.html)。
- 处理：英中正文保留底本1852/1853的写法，中文译校记给出有证据的时间差异及来源；不据此擅自替作者重写整段历史叙述。正文中的1852年起义是否为1848年之误，未取得所引Harvey原页核对，暂不下确定结论。

## 第1章《重罗曼》题名

这项为书内互证，并非外部网页核验：原134页明确说明Ağır Roman的双关，即“沉重的小说”与缓慢／沉重演奏的罗姆音乐。译校记已经据此修订。


## Chapter 7, original pp.174-175: Nausea

Source says Sartre wrote Nausea in 1965, while Chapter 2 dates the novel to 1938. The BnF exhibition entry lists the first edition as Gallimard, 1938, and says it was published in 1938: https://expositions.bnf.fr/sartre/grand/045bis.htm . This primary source was read during translation. The chapter bibliography lists the 1965 R. Baldick translation; that bibliographic year has been retained. The body wording is preserved with an explicit Chinese editorial note, rather than silently replacing the source date.
