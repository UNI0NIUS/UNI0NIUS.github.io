# 当前校订版的重建

以 Python 3 运行：

```text
python work/translation/assemble_book.py
python work/translation/audit_assembly.py
python work/translation/review_book.py
```

这些入口仅需Python标准库；正文、原注及图像路径均为相对目录。请在包根目录运行，不要打乱目录结构。全稿位于 `output/rule_of_experts_zh.md`，分章稿位于 `output/chapters`，图像位于 `output/images`。

当前规范原文是 `work/translation/source/*.json`，译文是 `work/translation/zh/*.md`。第1章的规范对照数据是 `work/egypt_ch01_reviewed.json`；本包的第1章中文稿为既有已校版本。`review/chapter1-site-snapshot.json` 保留既有网站表现形式。

只编辑规范数据后再生成。`review/revisions.json` 保留修订前后内容与理由；第5章053—059已合并为053，旧编号见 merged_from。原批次抽取器及一次性修订脚本不属于正常重建流程，不随包分发。原始PDF留在用户本地，不在此包再分发。

此包是重点校订工作版，不宣称全书逐句终校完成。范围与限制见 `output/全书校对说明.md`。现有第一章PDF另行下载，不在本包误标为全书PDF。
