#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Assemble the Chinese translation into per-chapter and full-book Markdown.

This script only performs structural assembly: heading levels, printed-page
markers, blockquote/caption rendering, and footnote conversion. It does not
alter translated text. Chapter 1 is reused from output/egypt_ch01_zh.md.
"""

from __future__ import annotations

import json
import re
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SRC_DIR = ROOT / "work" / "translation" / "source"
ZH_DIR = ROOT / "work" / "translation" / "zh"
OUT_DIR = ROOT / "output"
CH_DIR = OUT_DIR / "chapters"
CH01 = OUT_DIR / "egypt_ch01_zh.md"
FULL_OUT = OUT_DIR / "rule_of_experts_zh.md"
FIGURES = {f['id']: f for f in json.loads((ROOT / 'work/translation/figure_manifest.json').read_text('utf-8'))['figures']}

CN_NUM = "一二三四五六七八九"
BLOCK_RE = re.compile(r"^## (\S+)\s*$")
FOOTNOTE_RE = re.compile(r"\[\[(\d+)\]\]")
DEF_RE = re.compile(r"(?m)^\[\^([A-Za-z0-9]+)\]:")
REF_RE = re.compile(r"\[\^([A-Za-z0-9]+)\](?!:)")

CHAPTER_KEYS = ["ch02", "ch03", "ch04", "ch05", "ch06", "ch07", "ch08", "ch09"]
PARTS = [
    ("第一部", "资本主义的寄生之所", "17", "ch01"),
    ("第二部", "农民研究", "121", "ch04"),
    ("第三部", "锚定经济", "207", "ch07"),
]
BIB_ENTRIES_EXPECTED = 391


def parse_blocks(path: Path) -> tuple[dict[str, str], list[str]]:
    blocks: dict[str, str] = {}
    order: list[str] = []
    current: str | None = None
    buf: list[str] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        m = BLOCK_RE.match(line)
        if m:
            if current is not None:
                blocks[current] = "\n".join(buf).strip()
            current = m.group(1)
            if current in blocks:
                raise ValueError(f"Duplicate unit {current} in {path}")
            order.append(current)
            buf = []
        elif current is not None:
            buf.append(line)
    if current is not None:
        blocks[current] = "\n".join(buf).strip()
    return blocks, order


def load_chapter(key: str) -> tuple[dict, dict[str, str]]:
    data = json.loads((SRC_DIR / f"{key}.json").read_text(encoding="utf-8"))
    files = sorted(ZH_DIR.glob(f"{key}_b*.md"))
    if not files:
        raise FileNotFoundError(f"No Chinese batches for {key}")
    blocks: dict[str, str] = {}
    order: list[str] = []
    for f in files:
        part_blocks, part_order = parse_blocks(f)
        for uid in part_order:
            if uid in blocks:
                raise ValueError(f"Duplicate unit {uid} across batches for {key}")
            blocks[uid] = part_blocks[uid]
            order.append(uid)

    body_ids = [u["id"] for u in data["units"]]
    note_ids = [n["id"] for n in data["notes"]]
    missing = [uid for uid in body_ids + note_ids if uid not in blocks]
    extra = set(blocks) - set(body_ids) - set(note_ids)
    if missing or extra:
        raise ValueError(f"{key}: missing={missing[:5]} extra={sorted(extra)[:5]}")

    body_order = [uid for uid in order if uid in set(body_ids)]
    if body_order != body_ids:
        raise ValueError(f"{key}: body units out of order")
    note_order = [uid for uid in order if uid in set(note_ids)]
    if note_order != note_ids:
        raise ValueError(f"{key}: note units out of order")

    note_numbers = [n["note_number"] for n in data["notes"]]
    if note_numbers != list(range(1, len(note_numbers) + 1)):
        raise ValueError(f"{key}: note numbers are not sequential")

    refs: set[int] = set()
    for u in data["units"]:
        refs.update(int(x) for x in FOOTNOTE_RE.findall(blocks[u["id"]]))
    if refs != set(note_numbers):
        raise ValueError(
            f"{key}: footnote refs/notes mismatch; "
            f"unreferenced={sorted(set(note_numbers) - refs)[:5]} "
            f"undefined={sorted(refs - set(note_numbers))[:5]}"
        )
    for n in data["notes"]:
        if "[[" in blocks[n["id"]]:
            raise ValueError(f"{key}: note {n['note_number']} contains a footnote marker")
    return data, blocks


def page_span(pages: list[str]) -> str:
    if not pages:
        return ""
    pages = [str(p) for p in pages]
    if len(pages) == 1:
        return pages[0]
    try:
        nums = [int(p) for p in pages]
    except ValueError:
        return "、".join(pages)
    if nums == list(range(nums[0], nums[-1] + 1)):
        return f"{nums[0]}—{nums[-1]}"
    return "、".join(pages)


def page_marker(pages: list[str]) -> str:
    span = page_span(pages)
    return f"〔原书第{span}页〕" if span else ""


def fn_id(num: int, n: int, full: bool) -> str:
    return f"ch{num:02d}n{n}" if full else str(n)


def convert_markers(text: str, num: int, full: bool) -> str:
    return FOOTNOTE_RE.sub(
        lambda m: f"[^{fn_id(num, int(m.group(1)), full)}]", text
    )


def normalized_chapter_title(raw: str, num: int) -> str:
    title = re.sub(r"^第[一二三四五六七八九十百]+章[\s　]*", "", raw.strip())
    title = re.sub(r"^\d+[\s　]+", "", title)
    if not title:
        raise ValueError(f"Could not normalize chapter title: {raw!r}")
    return f"第{CN_NUM[num - 1]}章　{title}"


def render_unit(u: dict, blocks: dict[str, str], num: int, full: bool) -> str:
    utype = u["type"]
    text = convert_markers(blocks[u["id"]], num, full)
    if utype == "heading":
        level = u.get("level") or 2
        if level == 1:
            raise ValueError(f"Unexpected duplicate level-1 heading {u['id']}")
        return ("#" * (4 if full else 2)) + " " + text

    marker = page_marker(u.get("printed_pages", []))
    if utype == "blockquote":
        quoted = "\n".join("> " + line if line.strip() else ">" for line in text.splitlines())
        body = quoted
    elif utype == "caption":
        figure = FIGURES[u['id']]
        asset = ("" if full else "../") + figure['asset']
        body = f"![{text}]({asset})\n\n*{text}*\n\n〔图内文字译释：{figure['legend_zh']}〕"
    else:
        body = text
    return (marker + "\n\n" if marker else "") + body


def render_notes(data: dict, blocks: dict[str, str], num: int, full: bool) -> str:
    lines = ["#### 章末原注" if full else "## 章末原注", ""]
    for note in data["notes"]:
        n = note["note_number"]
        marker = page_marker(note.get("printed_pages", []))
        lines.append(f"[^{fn_id(num, n, full)}]: {marker}{blocks[note['id']]}")
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def render_chapter(key: str, full: bool) -> tuple[str, dict, dict[str, str]]:
    data, blocks = load_chapter(key)
    num = data["num"]
    first = data["units"][0]
    if first["type"] != "heading" or first.get("level") != 1:
        raise ValueError(f"{key}: first unit is not a level-1 heading")
    title = normalized_chapter_title(blocks[first["id"]], num)
    parts = [("#" * (3 if full else 1)) + " " + title]
    for u in data["units"][1:]:
        parts.append(render_unit(u, blocks, num, full))
    parts.append(render_notes(data, blocks, num, full))
    return "\n\n".join(parts).rstrip() + "\n", data, blocks


def render_intro(full: bool) -> tuple[str, dict, dict[str, str]]:
    data, blocks = load_chapter("intro")
    first = data["units"][0]
    title = blocks[first["id"]]
    parts = [("#" * (2 if full else 1)) + " " + title]
    for u in data["units"][1:]:
        parts.append(render_unit(u, blocks, 0, full))
    return "\n\n".join(parts).rstrip() + "\n", data, blocks


def render_front_matter(filename: str, heading: str, pages: str, full: bool) -> str:
    blocks, order = parse_blocks(ZH_DIR / filename)
    body = "\n\n".join(blocks[uid] for uid in order)
    level = "##" if full else "#"
    return f"{level} {heading}\n\n〔原书第{pages}页〕\n\n{body}\n"


def render_bibliography(full: bool) -> str:
    original = (ZH_DIR / "bibliography.md").read_text(encoding="utf-8").rstrip() + "\n"
    lines = original.splitlines()
    if not lines or not lines[0].startswith("# "):
        raise ValueError("Bibliography does not start with a heading")
    heading = "## 参考书目" if full else "# 参考书目"
    rest = lines[1:]
    if full:
        rest = [("### " + line[3:]) if line.startswith("## ") else line for line in rest]
    marker = "〔原书第381—401页〕"
    body = "\n".join(rest).strip()
    return f"{heading}\n\n{marker}\n\n{body}\n"


def render_part(label: str, title: str, page: str) -> str:
    return f"## {label}　{title}\n\n〔原书第{page}页〕"


def render_ch01_full() -> str:
    raw = CH01.read_text(encoding="utf-8")
    lines = raw.splitlines()
    if len(lines) < 8 or not lines[0].startswith("# "):
        raise ValueError("Unexpected chapter 1 file structure")
    if not lines[2].startswith("Timothy Mitchell"):
        raise ValueError("Unexpected chapter 1 metadata line")
    if not lines[4].startswith("完整收录"):
        raise ValueError("Unexpected chapter 1 provenance line")
    rest = "\n".join(lines[6:]).lstrip("\n")

    rest = re.sub(
        r"\[\^(\d+)\]",
        lambda m: f"[^ch01n{int(m.group(1))}]",
        rest,
    )
    rest = rest.replace("## 章末原注", "#### 章末原注")
    if re.search(r"\[\^\d+\]", rest):
        raise ValueError("Unconverted numeric footnote in chapter 1")

    header = (
        "### 第一章　蚊子能说话吗？\n\n"
        "<!-- 本章复用已发表译文：output/egypt_ch01_zh.md；原书正文第19—53页，原注第305—315页。 -->"
    )
    return header + "\n\n" + rest.strip() + "\n"


def validate_footnotes(text: str, expected: int, label: str) -> None:
    defs = DEF_RE.findall(text)
    refs = REF_RE.findall(text)
    if len(defs) != expected:
        raise ValueError(f"{label}: expected {expected} footnote definitions, got {len(defs)}")
    if len(defs) != len(set(defs)):
        raise ValueError(f"{label}: duplicate footnote definitions")
    if set(refs) != set(defs):
        raise ValueError(
            f"{label}: footnote reference/definition mismatch; "
            f"undefined={sorted(set(refs) - set(defs))[:5]} "
            f"unused={sorted(set(defs) - set(refs))[:5]}"
        )


def validate_no_markers(text: str, label: str) -> None:
    if "[[" in text:
        pos = text.find("[[")
        raise ValueError(f"{label}: unconverted marker near {text[max(0, pos - 30):pos + 30]!r}")


def main() -> None:
    CH_DIR.mkdir(parents=True, exist_ok=True)

    # ---- Per-chapter files ----
    shutil.copyfile(CH01, CH_DIR / "chapter_01.md")
    validate_footnotes((CH_DIR / "chapter_01.md").read_text(encoding="utf-8"), 106, "ch01")

    intro_text, _, _ = render_intro(full=False)
    validate_no_markers(intro_text, "intro")
    (CH_DIR / "introduction.md").write_text(intro_text, encoding="utf-8")

    ack = render_front_matter("front_ack.md", "致谢", "ix—xi", full=False)
    (CH_DIR / "acknowledgments.md").write_text(ack, encoding="utf-8")
    translit = render_front_matter(
        "front_translit.md", "音译说明", "xiii", full=False
    )
    (CH_DIR / "note_on_transliteration.md").write_text(translit, encoding="utf-8")

    chapter_stats = {}
    for key in CHAPTER_KEYS:
        text, data, blocks = render_chapter(key, full=False)
        validate_no_markers(text, key)
        validate_footnotes(text, len(data["notes"]), key)
        num = data["num"]
        (CH_DIR / f"chapter_{num:02d}.md").write_text(text, encoding="utf-8")
        chapter_stats[key] = (len(data["units"]), len(data["notes"]))

    bib_chapter = render_bibliography(full=False)
    (CH_DIR / "select_bibliography.md").write_text(bib_chapter, encoding="utf-8")

    # ---- Full book ----
    segments: list[str] = []
    segments.append(
        "# 专家的统治：埃及、技术政治与现代性\n\n"
        "Timothy Mitchell（蒂莫西·米切尔）著\n\n"
        "*Rule of Experts: Egypt, Techno-Politics, Modernity*（2002）"
    )
    segments.append(render_front_matter("front_ack.md", "致谢", "ix—xi", full=True))
    segments.append(
        render_front_matter("front_translit.md", "音译说明", "xiii", full=True)
    )
    segments.append(render_intro(full=True)[0])

    parts_by_chapter = {p[3]: p for p in PARTS}
    segments.append(render_part(*parts_by_chapter["ch01"][:3]))
    segments.append(render_ch01_full())
    for key in CHAPTER_KEYS:
        if key in parts_by_chapter:
            segments.append(render_part(*parts_by_chapter[key][:3]))
        text, _, _ = render_chapter(key, full=True)
        segments.append(text)
    segments.append(render_bibliography(full=True))
    segments.append(
        "<!-- 原书索引（Index）按任务要求未翻译，未收录。 -->\n"
        "<!-- 2026-10-18重点校订工作版；完整逐句语义终校尚未完成。 -->"
    )

    body = "\n\n".join(s.strip() for s in segments if s.strip()) + "\n"
    body = (
        "<!-- 2026-10-18重点校订工作版：完成数字、单位、注号、风险语句及结构的专项校对；不等同全书逐句终校。 -->\n"
        "<!-- 第1章复用已发表译文；导论、第2—9章、致谢、音译说明为本次译文；"
        "参考书目保留英文原文，仅加中文标题；原书索引未翻译。 -->\n\n"
        + body
    )
    validate_no_markers(body, "full book")

    total_notes = 106 + sum(stats[1] for stats in chapter_stats.values())
    validate_footnotes(body, total_notes, "full book")

    if body.count("### 第") != 9:
        raise ValueError("Full book does not contain nine chapter headings")
    for label, title, _, _ in PARTS:
        if f"## {label}　{title}" not in body:
            raise ValueError(f"Missing part heading: {label} {title}")

    non_heading = [
        line
        for line in bib_chapter.splitlines()
        if line.strip()
        and not line.startswith("#")
        and not line.startswith("<!--")
        and not line.startswith("〔原书第")
    ]
    if len(non_heading) != BIB_ENTRIES_EXPECTED:
        raise ValueError(
            f"Bibliography entry count changed: {len(non_heading)} != {BIB_ENTRIES_EXPECTED}"
        )

    FULL_OUT.write_text(body, encoding="utf-8")

    # ---- Report ----
    print("Per-chapter files:", CH_DIR)
    print("Full book:", FULL_OUT)
    print("Intro units:", len(load_chapter("intro")[0]["units"]))
    for key, (units, notes) in chapter_stats.items():
        print(f"  {key}: units={units} notes={notes}")
    print("Footnote definitions in full book:", total_notes)
    print("Bibliography entries:", len(non_heading))
    print("Full book chars:", len(body))
    print("OK")


if __name__ == "__main__":
    main()
