"""Incremental review evidence. Does not infer semantic approval from checks."""
import hashlib
import json
import re
from pathlib import Path
import assemble_book as ab

ROOT = Path(__file__).resolve().parent
REVIEW = ROOT / 'review'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def records():
    for key in ['intro', *ab.CHAPTER_KEYS]:
        data, zh = ab.load_chapter(key)
        for u in data['units'] + data['notes']:
            yield dict(key=key, id=u['id'], type=u['type'], pages=u['printed_pages'], en=u['en'], zh=zh[u['id']])

def main():
    REVIEW.mkdir(exist_ok=True)
    inputs = sorted((ROOT / 'source').glob('*.json')) + sorted((ROOT / 'zh').glob('*.md')) + [Path(__file__), ROOT/'assemble_book.py']
    hashes = {str(p.relative_to(ROOT)): sha(p) for p in inputs}
    cache = REVIEW / 'mechanical.json'
    if cache.exists() and json.loads(cache.read_text('utf-8'))['inputs'] == hashes:
        print('UNCHANGED: reuse mechanical.json; no re-scan')
        return
    rows = list(records())
    errors, flags = [], []
    for r in rows:
        en, zh = r['en'], r['zh']
        if re.findall(r'\[\[(\d+)\]\]', en) != re.findall(r'\[\[(\d+)\]\]', zh):
            errors.append({'id': r['id'], 'issue': 'note_sequence'})
        clean_en = re.sub(r'\[\[\d+\]\]', '', en)
        clean_zh = re.sub(r'\[\[\d+\]\]', '', zh)
        en_nums = set(re.findall(r'(?<!\w)\d[\d,.]*\d|(?<!\w)\d', clean_en))
        zh_nums = set(re.findall(r'\d[\d,.]*\d|\d', clean_zh))
        missing = sorted(en_nums - zh_nums)
        reasons = []
        if missing:
            reasons.append('numeric:' + ','.join(missing))
        if len(re.findall('[\u4e00-\u9fff]', zh)) < len(en.split()) * .65 and r['type'] not in ['heading', 'note']:
            reasons.append('short_translation')
        if re.search('英亩', zh) and re.search(r'\bacres?\b', en):
            reasons.append('acre_context')
        if re.search('形式及非正式|使能|本世纪|五十年前', zh):
            reasons.append('wording_context')
        if reasons:
            flags.append({**r, 'reasons': reasons})
    result = {'inputs': hashes, 'units': len(rows), 'errors': errors, 'candidate_count': len(flags),
              'scope': 'IDs, order and note references validated; numeric/length/term flags are candidates, not semantic verdicts.'}
    cache.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', 'utf-8')
    (REVIEW / 'candidates.json').write_text(json.dumps(flags, ensure_ascii=False, indent=2) + '\n', 'utf-8')
    print(json.dumps({k:v for k,v in result.items() if k != 'inputs'}, ensure_ascii=False))
    print('Candidates by chapter:', {k:sum(r['key']==k for r in flags) for k in ['intro',*ab.CHAPTER_KEYS]})

if __name__ == '__main__':
    main()
