#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Audit that assembled Markdown preserves every translated unit verbatim."""

from __future__ import annotations

import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import assemble_book as ab  # noqa: E402

FULL = ab.FULL_OUT.read_text(encoding="utf-8")
CH_FILES = {
    2: ab.CH_DIR / "chapter_02.md",
    3: ab.CH_DIR / "chapter_03.md",
    4: ab.CH_DIR / "chapter_04.md",
    5: ab.CH_DIR / "chapter_05.md",
    6: ab.CH_DIR / "chapter_06.md",
    7: ab.CH_DIR / "chapter_07.md",
    8: ab.CH_DIR / "chapter_08.md",
    9: ab.CH_DIR / "chapter_09.md",
}


def check_present(text: str, haystack: str, label: str) -> None:
    if text not in haystack:
        snippet = text[:80].replace("\n", " ")
        raise AssertionError(f"Missing {label}: {snippet!r}")


def audit_chapter(key: str, full: bool, haystack: str, out_label: str) -> None:
    data, blocks = ab.load_chapter(key)
    num = data["num"]
    units = data["units"]
    checked = 0
    for i, u in enumerate(units):
        text = ab.convert_markers(blocks[u["id"]], num, full)
        if u["type"] == "heading" and i == 0:
            continue  # chapter heading is normalized during assembly
        check_present(text, haystack, f"{out_label} {u['id']}")
        checked += 1
    for note in data["notes"]:
        text = blocks[note["id"]]
        check_present(text, haystack, f"{out_label} note {note['note_number']}")
        checked += 1
    print(f"  {key} ({out_label}): {checked} text blocks present")


# ---- Per-chapter files ----
for key in ab.CHAPTER_KEYS:
    num = {"ch02": 2, "ch03": 3, "ch04": 4, "ch05": 5, "ch06": 6,
           "ch07": 7, "ch08": 8, "ch09": 9}[key]
    text = CH_FILES[num].read_text(encoding="utf-8")
    audit_chapter(key, full=False, haystack=text, out_label=f"ch{num:02d}")

intro, _, _ = ab.render_intro(full=False)
intro_out = (ab.CH_DIR / "introduction.md").read_text(encoding="utf-8")
assert intro == intro_out, "Intro per-chapter file differs from render"
print("  intro per-chapter: exact render match")

for filename, expected in [
    ("front_ack.md", (ab.CH_DIR / "acknowledgments.md").read_text(encoding="utf-8")),
    ("front_translit.md", (ab.CH_DIR / "note_on_transliteration.md").read_text(encoding="utf-8")),
]:
    blocks, order = ab.parse_blocks(ab.ZH_DIR / filename)
    for uid in order:
        check_present(blocks[uid], expected, f"{filename} {uid}")
    print(f"  {filename}: {len(order)} blocks present")

# Chapter 1 per-chapter copy must be byte-identical.
if (ab.CH_DIR / "chapter_01.md").read_bytes() != ab.CH01.read_bytes():
    raise AssertionError("chapter_01.md is not a byte-identical copy of the source")
print("  ch01 per-chapter: byte-identical copy")

# ---- Full book ----
for key in ab.CHAPTER_KEYS:
    audit_chapter(key, full=True, haystack=FULL, out_label="full")

_, intro_blocks = ab.load_chapter("intro")
intro_data = ab.load_chapter("intro")[0]
for i, u in enumerate(intro_data["units"]):
    text = ab.convert_markers(intro_blocks[u["id"]], 0, True)
    check_present(text, FULL, f"full {u['id']}")
print(f"  intro full: {len(intro_data['units'])} blocks present")

for filename in ["front_ack.md", "front_translit.md"]:
    blocks, order = ab.parse_blocks(ab.ZH_DIR / filename)
    for uid in order:
        check_present(blocks[uid], FULL, f"full {filename} {uid}")
    print(f"  {filename} full: {len(order)} blocks present")

# Chapter 1: every non-heading line of the reused translation must survive,
# after converting its local numeric footnote IDs to the prefixed full-book IDs.
ch01_lines = ab.CH01.read_text(encoding="utf-8").splitlines()[6:]
ch01_checked = 0
for line in ch01_lines:
    if not line.strip() or line.startswith("## "):
        continue
    converted = re.sub(
        r"\[\^(\d+)\]",
        lambda m: f"[^ch01n{int(m.group(1))}]",
        line,
    )
    check_present(converted, FULL, "full ch01 line")
    ch01_checked += 1
print(f"  ch01 full: {ch01_checked} non-heading lines present")

# Bibliography: every entry line must survive, and headings must be demoted.
bib = (ab.ZH_DIR / "bibliography.md").read_text(encoding="utf-8").splitlines()
bib_checked = 0
for line in bib:
    if not line.strip() or line.startswith("#"):
        continue
    check_present(line, FULL, "full bibliography line")
    bib_checked += 1
print(f"  bibliography full: {bib_checked} non-heading lines present")

# ---- Source page metadata completeness ----
missing_pages = []
for key in ["intro", *ab.CHAPTER_KEYS]:
    data = ab.load_chapter(key)[0]
    for u in data["units"]:
        if not u.get("printed_pages"):
            missing_pages.append((key, u["id"], "body"))
    for n in data["notes"]:
        if not n.get("printed_pages"):
            missing_pages.append((key, n["id"], "note"))
print("  units/notes without printed_pages:", len(missing_pages))
if missing_pages:
    print("   ", missing_pages[:10])

# ---- Final structural checks ----
assert FULL.count("\n### 第") == 9
for label, title, _, _ in ab.PARTS:
    assert f"## {label}　{title}" in FULL
assert "[[" not in FULL and not re.search(r"\[\^\d+\]", FULL)
assert FULL.count("## 参考书目") == 1
assert "## 索引" not in FULL
print("All assembly audits passed.")
