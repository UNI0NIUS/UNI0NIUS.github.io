# 参考书目

〔原书第381—401页〕

<!-- Source: Select Bibliography, printed pp. 381–401 (PDF pp. 396–416). Original text retained; not translated. -->

ʿAbbas Hamid, Raʾuf. Al-nizam al-ijtimaʿi fi misr fi zill al-milkiyyat al-ziraʿiyya al-kabira. Cairo: Dar al-Fikr al-Hadith, 1973.

ʿAbd Allah, Ahmad, ed. Al-jaysh wa-ʾl-dimuqratiyya fi misr. Cairo: Dar Sina, 1990.

ʿAbd al-Muʿti, ʿAbd al-Basit. Al-siraʿ al-tabaqi fi al-qarya al-misriyya. Cairo: Dar al-Thaqafa al-Jadida, 1977.

ʿAbd al-Rahim, ʿAbd al-Rahim ʿAbd al-Rahim. Al-rif al-misri fi al-qarn al-thamin ʿashar. 2d ed. Cairo: Maktabat Madbuli, 1986.

ʿAbd al-Rahman, ʿAʾisha [Bint al-Shatiʾ, pseud.]. Al-rif al-misri. Cairo: Maktabat al-Wafd, 1936.

Abdel-Fadil, Mahmoud. Development, Income Distribution and Social Change in Rural Egypt, 1952–70: A Study in the Political Economy of Agrarian Transition. Cambridge: Cambridge University Press, 1975.

Abu-Lughod, Lila. “The Romance of Resistance.” American Ethnologist 17, no. 1 (1990): 41–55.

———. Writing Women’s Worlds: Bedouin Stories. Berkeley: University of California Press, 1993.

———. “Television and the Virtues of Education: Upper Egyptian Encounters with State Culture.” In Directions of Change in Rural Egypt. Edited by Nicholas Hopkins and Kirsten Westergaard, 147–65. Cairo: American University in Cairo Press, 1998.

Adams, Richard H. Development and Social Change in Rural Egypt. Syracuse, N.Y.: Syracuse University Press, 1986.

Adelman, Irma. “Beyond Export-Led Growth.” World Development 12, no. 9 (1984): 937–49.

ʿAfifi, Hafiz. ʿAla hamish al-siyasa: baʿd masaʾilna al-qawmiyya. Cairo: Dar al-Kutub al-Misriyya, 1938.

Alderman, Harold, and Joachim von Braun. Egypt’s Food Subsidy and Rationing System:A Description. Washington, D.C.: International Food Policy Research Institute, 1982.

———. The Effects of the Egyptian Food Ration and Subsidy System on In-come Distribution and Consumption. Research Report no. 45. Washington, D.C.: International Food Policy Research Institute, 1984.

ʿAli, Saʿid Ismaʿil. Al-mujtamaʿ al-misri fi ʿahd al-ihtilal al-biritani. Cairo: Anglo-Egyptian Bookshop, 1972.

Amin, Samir [Hasan Riad, pseud.]. L’Egypte nassérienne. Paris: Editions de Minuit, 1964.

ʿAmir, Ibrahim. Al-ard wa-ʾl-fallah: al-masʾala al-ziraʿiyya fi misr. Cairo: Matbaʿat al-Dar al-Misriyya, 1958.

Anderson, Benedict. Imagined Communities: Reflections on the Origins and Spread of Nationalism. 2d ed. London: Verso, 1991.

Anderson, Sarah, John Cavanagh, and Thea Lee. Field Guide to the Global Economy. New York: New Press, 2000.

Andrews, J. H. A Paper Landscape: The Ordnance Survey in NineteenthCentury Ireland. Oxford: Clarendon Press, 1975.

Anhouri, Jean. “Les Répercussions de la guerre sur l’agriculture égyptienne.” L’Egypte Contemporaine 38, nos. 238–39 (Mar.–Apr. 1947): 233–51.

Anise, Mahmoud. A Study of the National Income of Egypt. Monograph, published as L’Egypte Contemporaine, nos. 261–62. Cairo: Société Fouad 1er d’Economie Politique, de Statistique et de Législation, 1950.

Ansari, Hamied. Egypt: The Stalled Society. Albany: State University of New York Press, 1986.

Appadurai, Arjun. ed. The Cultural Life of Things. Cambridge: Cambridge University Press, 1986.

———, “Number in the Colonial Imagination.” In Modernity at Large: Cultural Dimensions of Globalization, 114–35. Minneapolis: University of Minnesota Press, 1997.

Artin, Yacoub. La Propriété foncière en Egypte. Printed under the Auspices of the Ministry of Finance. Cairo: Institut Egyptien, 1883.

———. Artin Bey: Ministère des Affaires Etrangères et du Commerce sous le règne de Môhémet-Aly Pacha 1800–1859. Cairo: Imprimerie Nationale, 1896.

———. “Essai sur les causes du renchérissement de la vie matérielle au Caire dans le courant de xixe siècle (1800 à 1907).” Mémoires présentés á l’Institut Egyptien 5 (1908): 58140.

Asad, Talal. Genealogies of Religion: Discipline and Reasons of Power in Christianity and Islam. Baltimore, Md.: Johns Hopkins University Press, 1993.

———. “Ethnographic Representation, Statistics and Modern Power.” Social Research 61, no. 1 (1994): 55–88.

Ayrout, Henry Habib. The Egyptian Peasant, translated by John Alden Williams. Boston: Beacon Press, 1963.

———. Moeurs et coutumes des fellahs. Paris: Payot, 1938. English translation: The Fellaheen, translated by Hilary Wayment. Westport, Ct.: Hyperion Press, 1981.

Baer, Gabriel. A History of Landownership in Modern Egypt, 1800–1950. Oxford: Oxford University Press, 1962.

———. Studies in the Social History of Modern Egypt. Chicago: University of Chicago Press, 1969.

Baker, Raymond. Egypt’s Uncertain Revolution under Nasser and Sadat. Cambridge, Mass.: Harvard University Press, 1978.

Baraka, Magda. The Egyptian Upper Class Between Revolutions, 1919–1952. St. Antony Middle East Monographs. Reading, Eng.: Ithaca Press, 1998.

Barakat, ʿAli. Tatawwur al-milkiyya al-ziraʿiyya fi misr wa-atharuhu ʿala al-haraka al-siyasiyya. Cairo: Dar al-Thaqafa al-Jadida, 1977.

Bartsch, Ulrich.“Interpreting Household Budget Surveys: Estimates for Poverty and Income Distribution in Egypt.” Working Papers of the Economic Research Forum for the Arab Countries, Iran and Turkey, no. 9714. Cairo, 1997.

Baskin, Jonathan Barron, and Paul J. Miranti Jr. A History of Corporate Fi-nance. Cambridge: Cambridge University Press, 1997.

Beinin, Joel, and Zachary Lockman. Workers on the Nile: Nationalism, Communism, Islam and the Egyptian Working Class, 1882–1954. Princeton, N.J.: Princeton University Press, 1987.

Berger, Morroe. The Arab World Today. Garden City, N.Y.: Doubleday, 1962.

Bernstein, Henry. “Concepts for the Analysis of Contemporary Peasantries.” In The Political Economy of Rural Development: Peasants, International Capital, and the State. Edited by Rosemary Galli, 3–24. Albany: State University of New York Press, 1981.

———. “Agrarian Classes in Capitalist Development.” In Capitalism and Development. Edited by Leslie Sklair, 40–71. London: Routledge, 1994.

Berque, Jacques. “Sur la structure de quelques villages égyptiens.” Annales: Economie, Société, Civilisations 10, no. 2 (1955): 199–215.

———. Histoire sociale d’un village égyptian au xxème siècle. Paris: Mouton, 1957.

———. Egypt: Imperialism and Revolution. Translated by Jean Stewart. New York: Praeger, 1971.

Bhabha, Homi K. The Location of Culture. London: Routledge, 1994.

Binder, Leonard. In a Moment of Enthusiasm: Political Power and the Second Stratum in Egypt. Chicago: University of Chicago Press, 1978.

Binswanger, Hans. “Agricultural Mechanization: A Comparative Historical Analysis.” World Bank Research Observer 1, no. 1 (1986): 27–56.

Binswanger, Hans, Klaus Deininger, and Gershon Feder. “Power, Distortions, Revolt and Reform in Agricultural Land Relations.” In Handbook of Development Economics, vol. 3b. Edited by J. Behrman and T. N. Srinivasan, 2659–72. Amsterdam: Elsevier, 1995.

Blackman, Winifred S. The Fellahin of Upper Egypt:Their Religious, Social and Industrial Life Today with Special Reference to Survivals from Ancient Times. London: G. G. Harrap, 1927.

Bochenski, Feliks, and William Diamond. “TVA’s in the Middle East.” Middle East Journal 4, no. 1 (1950): 52–82.

Bourdieu, Pierre. Outline of a Theory of Practice. Cambridge: Cambridge University Press, 1977.

Braudel, Fernand. Afterthoughts on Material Civilization and Capitalism. Translated by Patricia Ranum. Baltimore, Md.: Johns Hopkins University Press, 1977.

Brinton, Jasper Yeates. The Mixed Courts of Egypt. 2d ed. New Haven, Conn.: Yale University Press, 1968.

Brown, Nathan. Peasant Politics in Modern Egypt: The Struggle Against the State. New Haven, Conn.: Yale University Press, 1990.

Buck-Morss, Susan.“Envisioning Capital: Political Economy on Display.” Critical Inquiry 21, no. 2 (1995): 434–67.

Burns, William J. Economic Aid and American Policy Towards Egypt, 1955–81. Albany: State University of New York Press, 1985.

Bush, Ray. Economic Crisis and the Politics of Reform in Egypt. Boulder, Colo.: Westview Press, 1999.

Callon, Michel, ed. The Laws of the Markets. Sociological Review monograph series. Oxford: Blackwell, 1998.

Central Agency for Public Mobilization and Statistics and UNICEF. The State of Egyptian Children. Cairo: CAPMAS, 1988.

Chakrabarty, Dipesh. “Postcoloniality and the Artifice of History: Who Speaks for ‘Indian’ Pasts?” Representations 37, no. 1 (1992): 1–26. Reprinted in abridged form in Dipesh Chakrabarty, Provincializing Europe: Postcolonial Thought and Historical Difference, 27–46.

———. Provincializing Europe: Postcolonial Thought and Historical Difference. Princeton, N.J.: Princeton University Press, 2000.

Chambers, Robert. Rural Development: Putting the Last First. London: Longman, 1983.

Chatterjee, Partha. Nationalist Thought and the Colonial World: A Derivative Discourse? Minneapolis: University of Minnesota Press, 1993.

———. The Nation and its Fragments: Colonial and Postcolonial Histories. Princeton, N.J.: Princeton University Press, 1993.

Clarke, Simon, ed. What About the Workers? Workers and the Transition to Capitalism in Russia. London: Verso, 1993.

Clifford, James.“On Ethnographic Authority.” Representations 1, no. 2 (1983): 118–46.

Cohen, Morris R. “Property and Sovereignty.” Cornell Law Quarterly 13, no. 1 (1927): 8–30.

Cole, Juan R. Colonialism and Revolution in the Middle East: Social and Cultural Origins of Egypt’s ʿUrabi Movement. Princeton, N.J.: Princeton University Press, 1993.

Commander, Simon. The State and Agricultural Development in Egypt Since 1973. Published for the Overseas Development Institute. London: Ithaca Press, 1987.

Cooper, Frederick, and Randall Packard, eds. International Development and the Social Sciences: Essays on the History and Politics of Knowledge. Berkeley: University of California Press, 1997.

Coudougnan, Gerard. Nos ancêtres les Pharaons: L’Historie pharaonique et copte dans les manuels scolaires égyptiens. Dossiers du CEDEJ 1998, no. 1. Cairo: Centre d’Etudes et de Documentation Economique, Juridique et Sociale, 1988.

Critchfield, Richard. The Long Charade: Political Subversion in the Vietnam War. New York: Harcourt, Brace & World, 1968.

———. Shahhat: An Egyptian. Syracuse, N.Y.: Syracuse University Press, 1978.

———. Villages. Garden City, N.Y.: Anchor Press / Doubleday, 1981; reprint ed. 1983.

———. The Golden Bowl Be Broken: Peasant Life in Four Cultures, 2d ed. Bloomington: University of Indiana Press, 1988.

———. The Villagers. Changed Values, Altered Lives: The Closing of the Urban-Rural Gap. New York: Anchor Books / Doubleday, 1994.

Cromer, Earl of. Modern Egypt. 2 vols. New York: Macmillan, 1908.

Crush, Jonathan, ed. Power of Development. London: Routledge, 1995.

Cuddihy, William. “Agricultural Price Management in Egypt.” World Bank Staff Working Paper no. 388. Washington, D.C.: The World Bank, 1980.

Cumberbatch, A. N. Economic and Commercial Conditions in Egypt. Overseas Economic Surveys, published for Commercial Relations and Exports Department of the Board of Trade. London: Her Majesty’s Stationery Office, 1952.

Cuno, Kenneth. The Pasha’s Peasants: Land, Society and Economy in Lower Egypt, 1740–1858. Cambridge: Cambridge University Press, 1992.

Davis, Eric. Challenging Colonialism: Bank Misr and Egyptian Industrialization, 1920–1941. Princeton, N.J.: Princeton University Press, 1983.

Deane, Phyllis. The Measurement of Colonial National Incomes. National In-stitute of Economic and Social Research Occasional Paper XII. Cambridge: Cambridge University Press, 1948.

———. Colonial Social Accounting. National Institute of Economic and Social Research, Economic and Social Studies No. 11. Cambridge: Cambridge University Press, 1953. Reprint ed., Hamden, Conn.: Archon Books, 1973.

De Guerville, A. B. New Egypt. London: William Heinemann, 1905.

De Regny, E. Statistique de l’Egypte d’après des documents officiels. Alexandria: n.p., 1870–72.

Derrida, Jacques. Of Grammatology. Translated by Gayatri Chakravorty Spivak. Baltimore, Md.: Johns Hopkins University Press, 1976.

———. Writing and Difference. Translated by Alan Bass. Chicago: University of Chicago Press, 1978.

———. Margins of Philosophy. Translated by Alan Bass. Chicago: University of Chicago Press, 1982.

———. “The Force of Law.” Cardozo Law Review 11 (1990).

———. Specters of Marx: The State of the Debt, the Work of Mourning, and the New International. New York: Routledge, 1994.

Dethier, Jean-Jacques. Trade, Exchange Rate, and Agricultural Pricing Policies in Egypt. Washington, D.C.: World Bank, 1989.

Dirks, Nicholas B. “History as a Sign of the Modern.” Public Culture 2, no. 1 (1990): 25–32.

Disuqi, ʿAsim al-. Kibar mullak al-aradi al-ziraʿiyya wa dawruhum fi al-mujtamaʿ al-misri. Cairo: Dar al-Thaqafa al-Jadida, 1976.

Dowson, E. M., and J. I. Craig. Collection of Statistics of the Area Planted in Cotton in 1909. Cairo: Survey Department, 1910.

Dowson, Sir Ernest, and V. L. O. Sheppard. “Evolution of the Land Records.” Empire Survey Review 60 (1956): 202.

Duff-Gordon, Lucie. Letters from Egypt. Revised ed. London: R. Brimley Johnson, 1902.

Dumont, Louis. From Mandeville to Marx: The Genesis and Triumph of Economic Ideology. Chicago: University of Chicago Press, 1977.

Durkheim, Emile. The Rules of Sociological Method. New York: Free Press, 1938.

Dyer, Graham. Class, State, and Agricultural Productivity in Egypt:A Study of the Inverse Relationship between Farm Size and Land Productivity. London: Frank Cass, 1997.

Edmond, Charles. L’Egypte a l’Exposition Universelle de 1867. Paris: Dentu, 1867.

Edney, Mathew. Mapping an Empire: The Geographical Construction of British India, 1765–1843. Chicago: University of Chicago Press, 1997.

Edwards, Jill, ed. Al-Alamein Revisited: The Battle of Al-Alamein and Its Historical Implications. Cairo: American University in Cairo Press, 2000.

Eisner, Robert.“Divergences of Measurement and Theory and Some Implications for Economic Policy.” American Economic Review 79, no. 1 (1989): 1–13.

El-Rafie, M., W. A. Hassouna, N. Hirschhorn, S. Loza, P. Miller, A. Nagaty, S. Nasser, and S. Riyad. “Effect of Diarrhoeal Disease Control on Infant and Child Mortality in Egypt.” Lancet 335 (Feb. 10, 1990): 334–38.

English, E. Philip. The Great Escape? An Examination of North-South Tourism. Ottawa: North-South Institute, 1986.

Escobar, Arturo. Encountering Development: The Making and Unmaking of the Third World. Princeton, N.J.: Princeton University Press, 1995.

Fahmy, Khaled. All the Pasha’s Men: Mehmed Ali, His Army and the Making of Modern Egypt. Cambridge: Cambridge University Press, 1997.

Fathy, Hassan. Gurna:A Tale of Two Villages. Cairo: Ministry of Culture, 1969. Reprinted as Architecture for the Poor: An Experiment in Rural Egypt. Chicago: University of Chicago Press, 1973.

Feder, Gershon. “The Relation Between Farm Size and Farm Productivity.” Journal of Development Economics 18, nos. 2–3 (1985): 297–313.

Feis, Herbert. Europe: The World’s Banker, 1870–1914: An Account of European Foreign Investment and the Connection of World Finance with Diplomacy Before the War. New Haven, Conn.: Yale University Press, 1930. Reprint ed. Clifton, N.J.: Augustus M. Kelley, 1974.

Ferguson, James. The Anti-Politics Machine: “Development,” Depoliticization, and Bureaucratic Power in Lesotho. Cambridge: Cambridge University Press, 1990.

Fitzpatrick, Peter. Modernism and the Grounds of Law. Cambridge: Cambridge University Press, 2001.

Fletcher, Lehman B., ed. Egypt’s Agriculture in a Reform Era. Ames: Iowa State University Press, 1996.

Food and Agriculture Organization of the United Nations. National Methods of Collecting Agricultural Statistics. Supplement no. 18, Egypt, Mexico, Puerto Rico. Rome: FAO, 1983.

Foster Carter, Aidan. “The Modes of Production Controversy.” New Left Review, no. 107 (Jan.–Feb. 1978): 47–77.

Foucault, Michel. “Governmentality.” In The Foucault Effect: Studies in Governmentality. Edited by Graham Burchell, Colin Gordon, and Peter Miller, 87–104. Hemel Hempstead, Herts: Harvester Wheatsheaf, 1991.

Fresco, Jacques. “Histoire et organisation de la statistique officielle en Egypte.” L’Egypte Contemporaine 31, nos. 191–92 (1940): 339–91.

Friedmann, Harriet. “World Market, State, and Family Farm: Social Bases of Household Production in the Era of Wage Labor.” Comparative Studies in Society and History 20, no. 4 (1978): 545–86.

———. “The Political Economy of Food: A Global Crisis.” New Left Review, no. 197 (1993): 2957.

Fustel de Coulanges, Noma Denis. La Cité antique. 9th ed. Paris: Hachette, 1881.

Galal, Dina. Al-maʿuna al-amrikiyya li-man: Misr am amrika? Cairo: al-Ahram, 1988.

Gallagher, Nancy. Egypt’s Other Wars: Epidemics and the Politics of Public Health. Syracuse, N.Y.: Syracuse University Press, 1990.

Geertz, Clifford. The Interpretation of Cultures: Selected Essays. New York: Basic Books, 1973.

Gendzier, Irene. Managing Political Change: Social Scientists and the Third World. Boulder, Colo.: Westview Press, 1985.

Gerber, Haim. The Social Origins of the Modern Middle East. Boulder, Colo.: Lynne Rienner, 1987.

Gershoni, Israel, and James P. Jankowski. Egypt, Islam and the Arabs: The Search for Egyptian Nationhood. Oxford: Oxford University Press, 1986.

———. Redefining the Egyptian Nation, 1930–1945. Cambridge: Cambridge University Press, 1995.

Ghali, Mirrit Butrus. Siyasat al-ghad: barnamij siyasi wa-iqtisadi wa-ijtimaʿi. Cairo: Matbaʿat al-Risala, 1938. English translation, The Policy of Tomorrow, translated by Ismail R. el-Faruqi. Washington, D.C.: American Council of Learned Societies, 1953.

———. Al-islah al-ziraʿi. Cairo: Jamaʿat al-Nahda al-Qawmiyya, 1945.

Gibbon, P., and M. Neocosmos. “Some Problems in the Political Economy of ‘African Socialism.’ ” In Contradictions of Accumulation in Africa: Studies in Economy and State. Edited by Henry Bernstein and B. K. Campbell. Beverly Hills, Calif.: Sage, 1985.

Gibson, Katherine, and Julie Graham [J. K. Gibson-Graham, pseud.]. “Identity and Economic Plurality: Rethinking Capitalism and ‘Capitalist Hegemony.’ ” Environment and Planning D: Society and Space 13, no. 3 (1995): 275–82.

———. The End of Capitalism (As We Knew It): A Feminist Critique of Political Economy. Cambridge, Mass.: Blackwell, 1996.

Glavanis, Kathy, and Pandeli Glavanis.“The Sociology of Agrarian Relations in the Middle East: The Persistence of Household Production.” Current Sociology 31, no. 2 (1983): 1–106.

———. The Rural Middle East: Peasant Lives and Modes of Production. London: Zed Press, 1989.

Godlewska, Anne. “Napoleon’s Geographers (1797–1815): Imperialists and Soldiers of Modernity.” In Geography and Empire. Edited by Anne Godlewska and Neil Smith. Oxford: Blackwell, 1994.

Goffman, Erving. Frame Analysis: An Essay on the Organization of Experience. New York: Harper & Row, 1974.

Goldschmidt Jr., Arthur. Biographical Dictionary of Modern Egypt. Boulder, Colo.: Lynne Rienner, 2000.

Gordon, Joel. Nasser’s Blessed Movement: Egypt’s Free Officers and the July Revolution. Oxford: Oxford University Press, 1992.

Government of Egypt, Central Agency for Public Mobilization and Statistics. Census of Egypt 1986. Cairo: n.p., n.d.

Government of Egypt, Ministry of Finance, Survey Department. A Report on the Work of the Survey Department in 1909. Cairo: Ministry of Finance, 1909.

Gran, Peter. “Modern Trends in Egyptian Historiography: A Review Article.” International Journal of Middle East Studies 9, no. 3 (1978): 367–71.

Griliches, Zvi. “Productivity, R&D, and the Data Constraint.” American Economic Review 14, no. 1 (1994): 1–23.

Guha, Ranajit. Elementary Aspects of Peasant Insurgency in Colonial India. New Delhi: Oxford University Press, 1983.

———. A Rule of Property for Bengal: An Essay on the Idea of Permanent Settlement. Durham, N.C.: Duke University Press, 1996.

Guha, Ranajit, ed. A Subaltern Studies Reader, 1986–1995. Minneapolis: University of Minnesota Press, 1997.

Guha, Ranajit, and Gayatri Chakravorty Spivak, eds. Selected Subaltern Studies. New York: Oxford University Press, 1988.

Gupta, Akhil. Postcolonial Developments: Agriculture in the Making of Modern India. Durham, N.C.: Duke University Press, 1998.

Hammoudi, Abdellah. “Substance and Relation: Water Rights and Water Distribution in the Dra Valley.” In Property, Social Structure and Law in the Modern Middle East. Edited by Ann Elizabeth Mayer. Albany: State University of New York Press, 1985.

Hamrush, Ahmad. Qissat thawrat 23 yulyu. Vol. 2, Mujtamaʿ Jamal ʿAbd al-Nasir. Cairo: Maktabat Madbuli, 1975.

Handy, Howard, and Staff Team. Egypt: Beyond Stabilization, Towards a Dynamic Market Economy. IMF Occasional Paper, no. 163. Washington, D.C.: IMF, 1998.

Haraway, Donna. ModestWitness@SecondMillennium. FemaleMan© Meets OncoMouseTM: Feminism and Technoscience. New York: Routledge, 1997.

Harik, Iliya. The Political Mobilization of Peasants: A Study of an Egyptian Community. Bloomington: Indiana University Press, 1974.

———. “Continuity and Change in Local Development Policies in Egypt: From Nasser to Sadat.” International Journal of Middle East Studies 16, no. 1 (1984): 43–66.

Harik, Iliya, and Susan Randolph. Distribution of Land, Employment and In-come in Rural Egypt. Ithaca, N.Y.: Rural Development Committee, Center for International Studies, Cornell University, 1979.

Harrison, Gordon. Mosquitoes, Malaria and Man: A History of the Hostilities Since 1880. New York: E. P. Dutton, 1978.

Hart, H. L. A. The Concept of Law. Oxford: Oxford University Press, 1961.

Haykal, Muhammad Husayn. Mudhakkirati fi al-siyasa al-misriyya. 3 vols. Cairo: Dar al-Maʿarif, 1977–78.

Heikel, Mohamed. Autumn of Fury: The Assassination of Sadat. New York: Random House, 1983.

Hekekyan. “Journals 1851–54.” British Library Add Ms. 37452. London.

Henein, Nessim Henry. Ma ̄rı ̄ Girgis: Village de Haute-Egypte. Cairo: Institut Français d’Archéologie Orientale du Caire, 1988.

Henry, Clement M., and Robert Springborg. Globalization and the Politics of Development in the Middle East. Cambridge: Cambridge University Press, 2001.

Hill, Polly. Development Economics on Trial: The Anthropological Case for a Prosecution. Cambridge: Cambridge University Press, 1986.

Hinnebusch, Raymond A. “Class, State, and the Reversal of Egypt’s Agrarian Reform.” Middle East Report, no. 184 (Sept.–Oct. 1993): 20–23.

Hopkins, Nicholas S. “The Social Impact of Mechanization.” In Migration, Mechanization, and Agricultural Labor Markets in Egypt. Edited by Alan Richards and Philip L. Martin, 181–97. Boulder, Colo.:Westview Press, 1983.

———. Agrarian Transformation in Egypt. Boulder, Colo.: Westview Press, 1987.

———. “Small Farmer Households and Agricultural Sustainability in Egypt.” In Sustainable Agriculture in Egypt. Edited by Mohamed A. Faris and Mahmood Hasan Khan, 185–95. Boulder, Colo.: Lynne Rienner, 1993.

Hopkins, Nicholas S., Soheir R. Mehanna, and Bahgat Abdelmaksoud. The State of Agricultural Mechanization in Egypt. Cairo: Ministry of Agriculture, 1982.

Hopkins, Nicholas S, and Kirsten Westergaard, eds. Directions of Change in Rural Egypt. Cairo: American University in Cairo Press, 1998.

Hubbard, Preston J. Origins of the TVA: The Muscle Shoals Controversy, 1920–1932. New York: Norton, 1961.

Hughes, Thomas P. Networks of Power: Electrification in Western Society, 1880–1930. Baltimore, Md.: Johns Hopkins University Press, 1983.

Hunter, F. Robert. Egypt Under the Khedives, 1805–1879: From Household Government to Modern Bureaucracy. Pittsburgh, Penn.: University of Pittsburgh Press, 1984.

Husayn, ʿAdil. Nahw fikr ʿarabi jadid: al-nasiriyya wa-l-tanmiya wa-l-dimuqratiya. Cairo: Dar al-Mustaqbal al-ʿArabi, 1985.

Hussein, Mahmoud. Class Conflict in Egypt: 1945–1970. New York: Monthly Review Press, 1973.

Ikram, Khalid. Egypt: Economic Management in a Period of Transition. Report of a Mission Sent to the Arab Republic of Egypt by the World Bank. Published for the World Bank. Baltimore, Md.: Johns Hopkins University Press, 1980.

International Monetary Fund, Middle Eastern Department. “The Egyptian Stabilization Experience: An Analytical Retrospective.” Prepared by Arvind Subramanian. Working Papers of the International Monetary Fund, WP/97/105, September 1997.

Ireton, François. “Eléments pour une sociologie de la production statistique en Egypte.” Peuples méditerranéens, nos. 54–55 (Jan.–June 1991): 53–92.

Islamoglu-Inan, Huri. State and Peasant in the Ottoman Empire: Agrarian Power Relations and Regional Economic Development in Ottoman Anatolia during the Sixteenth Century. Leiden: E. J. Brill, 1994.

Islamoglu-Inan, Huri, and Çagˇlar Keyder. “Agenda for Ottoman History.” Review 1, no. 1 (1977): 31–55.

Issawi, Charles. Egypt in Revolution: An Economic Analysis. Oxford: Oxford University Press, 1963.

Jenks, Leland Hamilton. The Migration of British Capital to 1875. London: Al-fred A. Knopf, 1927.

Jennings, Anne M. The Nubians of West Aswan: Village Women in the Midst of Change. Boulder, Colo.: Lynne Rienner, 1995.

Jevons, W. Stanley. The Theory of Political Economy. London: Macmillan, 1871.

Johansen, Baber. The Islamic Law on Land Tax and Rent: The Peasant Loss of Property Rights as Interpreted in the Hanafite Legal Literature of the Mamluk and Ottoman Periods. London: Croom Helm, 1988.

Johnson, Pamela R., et al. Egypt: The Egyptian American Rural Improvement Service, a Point Four Project, 1952–63. AID Project Impact Evaluation, no. 43. Washington, D.C.: Agency for International Development, 1983.

Kabeer, Naila. Reversed Realities: Gender Hierarchies in Development Thought. London: Verso, 1994.

Kairys, David, ed. The Politics of Law:A Progressive Critique. 2d ed. New York: Pantheon, 1990.

Kamel Selim, Hussein. Twenty Years of Agricultural Development in Egypt. Cairo: Ministry of Finance, Egypt, 1940.

Kaviraj, Sudipta. “The Imaginary Institution of India.” In Subaltern Studies VII. Edited by Partha Chatterjee and Gyanendra Pandey, 1–39. New Delhi: Oxford University Press, 1992.

Kelley, Allen C., Atef M. Khalifa, and M. Nabil el-Khorazaty. Population and Development in Rural Egypt. Durham, N.C.: Duke University Press, 1982.

Keynes, John Maynard. Indian Currency and Finance. London: Macmillan, 1913.

Killearn, Baron of [Sir Miles Lampson]. Diaries. Private Papers Collection, Middle East Centre, St. Antony College, Oxford.

Koptiuch, Kristin. A Poetics of Political Economy in Egypt. Minneapolis: University of Minnesota Press, 1999.

Kuhnke, Laverne. Lives at Risk: Public Health in Nineteenth-Century Egypt. Berkeley: University of California Press, 1989.

Kuznets, Simon. National Income and Its Composition, 1919–1939. New York: National Bureau of Economic Research, 1941.

Laclau, Ernesto. New Reflections on the Revolution of Our Time. London: Verso, 1990.

Laclau, Ernesto, and Chantalle Mouffe. Hegemony and Socialist Strategy: Towards a Radical Democratic Politics. London: Verso, 1985.

Laïdi, Zaki. Enquête sur la Banque Mondiale. Paris: Fayard, 1989.

Landes, David S. Bankers and Pashas: International Finance and Economic Imperialism in Egypt. 2d ed. Cambridge, Mass.: Harvard University Press, 1979.

Larson, Barbara K.“The Rural Marketing System in Egypt over the Last Three Hundred Years.” Comparative Studies in Society and History 27, no. 3 (1985): 494–530.

Latour, Bruno. The Pasteurization of France. Cambridge, Mass.: Harvard University Press, 1988.

———. We Have Never Been Modern. Cambridge, Mass.: Harvard University Press, 1993.

———. Pandora’s Hope: Essays on the Reality of Science Studies. Cambridge, Mass.: Harvard University Press, 1999.

Lawson, Fred H. “Rural Revolt and Provincial Society in Egypt, 1820–1824.” International Journal of Middle East Studies 13, no. 2 (1981): 131–53.

Le Bon, Gustave. Psychologie des foules. Paris: Felix Alcan, 1895. English translation, The Crowd: A Study of the Popular Mind. New York: Macmillan, 1896.

———. Les lois psychologiques de l’évolution des peuples. Paris: Felix Alcan, 1898. English translation, The Psychology of Peoples. New York: Macmillan, 1898.

Lee, Eddy. “Egalitarian Peasant Farming and Rural Development: The Case of South Korea.” World Development 7, nos. 4/5 (1979): 510.

Lefebvre, Henri. The Production of Space. Translated by Donald NicholsonSmith. Oxford: Blackwell, 1991.

Lévi, I. G. “Le recensement de la population de l’Egypte de 1917.” L’Egypte Contemporaine no. 67 (Nov. 1922): 471–506.

———. “La réforme de la statistique officielle égyptienne.” L’Egypte Contemporaine 15, no. 80 (1924): 412–42.

———. “L’augementation des revenus de l’état: possibilités et moyen d’y parvenir.” L’Egypte Contemporaine no. 68 (Dec. 1992): 596–617.

Library of Congress, Federal Research Division. Egypt: A Country Study. Country Studies / Area Handbook series. Washington, D.C.: Library of Congress, 1991.

List, Friedrich. Das nationale System der politischen Oekonomie. Stuttgart: Cotta, 1841. English translation, National System of Political Economy, translated by Sampson S. Lloyd. London: Longmans, Green, 1885. Reprint ed. Fairfield, N.J.: A. M. Kelley, 1977.

Little, Tom. High Dam at Aswan. New York: John Day, 1965.

Lozach, Jean. Le Delta du Nil: Etude de géographie humaine. Cairo: Société Royale de Géographie d’Egypte, 1935.

Lozach, Jean, and Georges Hug. L’Habitat rural en Egypte. Cairo: Société Royale de Géographie d’Egypte, 1930.

Ludwig, Emil. Der Nil: Lebenslauf Eines Stromes. Amsterdam: Querido Verlag, 1935–36. English translation, The Nile: The Mighty Story of Egypt Fabulous River—6,000 Years of Thrilling History, translated by Mary H. Lindsay. New York: Viking Press, 1937.

Lyons, H. G. The Cadastral Survey of Egypt 1892–1907. Cairo: Ministry of Fi-nance, Survey Department, 1908.

Mabro, Robert. The Egyptian Economy, 1952–1972. Oxford: Clarendon Press, 1974.

Marx, Karl. Capital: A Critique of Political Economy. Vol. 1, The Process of Capitalist Production. Translated from the 3d German ed. by Samuel Moore and Edward Aveling. Edited by Frederick Engels. New York: Modern Library, 1906.

———. Capital: A Critique of Political Economy. Vol. 3. Translated by David Fernbach. London: Penguin, 1981.

Mayfield, James B. Rural Politics in Nasser Egypt: A Quest for Legitimacy. Austin: University of Texas Press, 1971.

McNeill, William H. Plagues and Peoples. Garden City, N.Y.: Anchor Press / Doubleday, 1976.

Meade, James, and Richard Strue. National Income and Expenditure. 2d ed. Cambridge: Bowes and Bowes, 1948.

Mehanna, Soheir, Nicholas S. Hopkins, and Bahgat Abdelmaksoud. Farmers and Merchants: Background to Structural Adjustment in Egypt. Cairo Papers in Social Science 17, Monograph 2. Cairo: American University in Cairo Press, 1994.

Mehta, Uday Singh. Liberalism and Empire: A Study in NineteenthCentury British Liberal Thought. Chicago: University of Chicago Press, 1999.

Meskell, Lynn, ed. Archaeology Under Fire: Nationalism, Politics and Heritage in the Eastern Mediterranean and the Middle East. London: Routledge, 1998.

Mintz, Sidney W. Sweetness and Power: The Place of Sugar in Modern History. New York: Viking Penguin, 1985.

Mitchell, Timothy. “Everyday Metaphors of Power.” Theory and Society 19, no. 5 (1990): 545–77.

———. Colonising Egypt. Berkeley: University of California Press, 1991.

———.“Worlds Apart:An Egyptian Village and the International Tourism In-dustry.” Middle East Report, no. 196 (Sept.–Oct. 1995).

———. “Origins and Limits of the Modern Idea of the Economy.” Advanced Study Center, University of Michigan, Working Papers Series, no. 12, Nov. 1995.

———. Al-dimuqratiyya wa-ʾl-dawla fi al-ʿalam al-ʿarabi. Damascus: Dar ʿIybal, 1996.

———. “Fixing the Economy.” Cultural Studies 12, no. 1 (1998): 82–101.

———. “Society, Economy, and the State Effect.” In State/Culture: StateFormation after the Cultural Turn. Edited by George Steinmetz, 76–97. Ithaca, N.Y.: Cornell University Press, 1999.

———.“The Stage of Modernity.” In Questions of Modernity. Edited by Timothy Mitchell, 1–34. Minneapolis: University of Minnesota Press, 2000.

Mitchell, Timothy, ed. Questions of Modernity. Minneapolis: University of Minnesota Press, 2000.

Mohieldin, Mahmoud. “Causes, Measures and Impact of State Intervention in the Financial Sector: The Egyptian Example.” Working Papers of the Economic Research Forum for the Arab Countries, Iran and Turkey, no. 9507. Cairo, 1995.

Moussa, M. Z., and T. T. Jones.“Efficiency and Farm Size in Egypt:A Unit Output Price Profit Function Approach.” Applied Economics 23, no. A1 (1991): 21–29.

Mubarak, ʿAli. Al-khitat al-tawfiqiyya li-misr al-qahira wa-muduniha wa-biladiha al-qadima wa-ʾl-shahira. Cairo: al-Matbaʿa al-Kubra al-Amiriyya, 1886–88.

Nahas, Joseph F. Situation économique et sociale du fellah égyptien. Paris: Arthur Rousseau, 1901.

Newberry, David M. “Futures Markets, Hedging, and Speculation.” In The New Palgrave Dictionary of Money and Finance. Edited by David M. Newberry, Murray Milgate, and John Eatwell. Vol. 2. New York: Stockton Press, 1992.

Nockrashy, A. S., Osman Galal, and Jay Davenport. More and Better Food: An Egyptian Demonstration Project. Washington, D.C.: National Research Council, 1987.

Owen, Roger. Cotton and the Egyptian Economy, 1820–1914:A Study in Trade and Development. Oxford: Oxford University Press, 1969.

———.“The Development of Agricultural Production in Nineteenth-Century Egypt: Capitalism of What Type?” In The Islamic Middle East 700–1900: Studies in Economic and Social History. Edited by A. L. Udovitch, 521–46. Princeton, N.J.: Darwin Press, 1981.

———. “The Population Census of 1917 and its Relationship to Egypt’s Three Nineteenth-Century Statistical Regimes.” Journal of Historical Sociology 9, no. 4 (1996): 457–72.

Palgrave, Robert. Palgrave’s Dictionary of Political Economy. 2d ed. London: Macmillan, 192526.

Patriarca, Silvana. Numbers and Nationhood. Cambridge: Cambridge University Press, 1996.

Piore, Michael J., and Charles F. Sabel. The Second Industrial Divide: Possibilities for Prosperity. New York: Basic Books, 1984.

Polanyi, Karl. The Great Transformation: The Political and Economic Origins of Our Time. Boston: Beacon Press, 1944.

Population Council. “Egypt 1988: Results from the Demographic and Health Survey.” Studies in Family Planning 21, no. 6 (1990): 351.

Postone, Moishe. Time, Labor, and Social Domination. Cambridge: Cambridge University Press, 1993.

Posusney, Marsha Pripstein. Labor and the State in Egypt: Workers, Unions, and Economic Restructuring. New York: Columbia University Press, 1997.

Pottage, Alain. “The Measure of Land.” The Modern Law Review 57, no. 3 (1994): 361–84.

Powelson, John P., and Richard Stock. The Peasant Betrayed: Agriculture and Land Reform in the Third World. Published in association with the Lincoln Institute of Land Policy. Boston: Oelgeschlager, Gunn & Hain, 1987.

Prakash, Gyan. “Writing Post-Orientalist Histories of the Third World: Perspectives from Indian Historiography.” Comparative Studies in Society and History 32, no. 2 (1990): 383–408.

———. “Can the ‘Subaltern’ Ride? A Reply to O’Hanlon and Washbrook.” Comparative Studies in Society and History 34, no. 1 (1992): 168–84.

———. Another Reason: Science and the Imagination of Modern India. Princeton, N.J.: Princeton University Press, 1999.

Radice, Hugo. “The National Economy: A Keynesian Myth?” Capital and Class, no. 22 (Spring 1984): 111–40.

Radwan, Samir. Agrarian Reform and Rural Poverty: Egypt, 1952–1975. Geneva: International Labour Organization, 1977.

Radwan, Samir, and Eddy Lee. Agrarian Change in Egypt: An Anatomy of Rural Poverty. London: Croom Helm, 1986.

Ragan, John David.“A Fascination for the Exotic: Suzanne Volquin, Ismayl Urbain, Jehan D’Ivray, and the Saint-Simonians—French Travelers in Egypt on the Margins.” Ph. D. diss., New York University, 2000.

Ramadan, ʿAbd al-ʿAzim. ʿAbd al-Nasir wa-azmat maris. Cairo: Ruz al-Yusuf, 1976.

———. Siraʿ al-tabaqat fi misr (1837–1952). Beirut: al-Muʾassasa al-ʿArabiyya li-ʾl-Dirasat wa-ʾl-Nashr, 1978.

———. Tatawwur al-harakah al-wataniyya fi misr: min sanat 1937 ila sanat 1948. Cairo: al-Hayʾa al-Misriyya al-ʿAmma li-ʾl-Kitab, 1998.

Rashad, Muhammad. Sirri jiddan: min milaffat al-lajna al-ʿulya ʾli-tasfiyat al-iqtaʿ. Cairo: Dar al-Taʿawun, 1977.

Reid, Donald M. Cairo University and the Making of a Modern Egypt. Cambridge: Cambridge University Press, 1990.

Renan, Ernest. Qu’est-ce qu’une nation? What is a nation? English translation by Wanda Romer Taylor. Toronto: Tapir Press, 1996.

Ricardo, David. “An Essay on the Influence of a Low Price of Corn on the Profits of Stock.” [1815]. In The Works and Correspondence of David Ricardo. Edited by Piero Sraffa. Vol. 4, Pamphlets and Papers, 1815–1823. Published for the Royal Economic Society, 9–41. Cambridge: Cambridge University Press, 1951.

———. On the Principles of Political Economy and Taxation. London: John Murray, 1817.

Richards, Alan. Egypt’s Agricultural Development 1800–1980: Technical and Social Change. Boulder, Colo.: Westview Press, 1982.

Richards, Alan, and Philip L. Martin, eds. Migration, Mechanization and Agricultural Labor Markets in Egypt. Boulder, Colo.: Westview Press, 1983.

Richards, Alan, and John Waterbury. A Political Economy of the Middle East. Boulder, Colo.: Westview Press, 1990.

Rieker, Martina. “The Saʿid and the City: Subaltern Spaces in the Making of Modern Egyptian History.” Ph. D. diss., Temple University, 1997.

Rifaʿa Rafiʿ Al-tahtawi. Al-aʿmal al-kamila. Edited by Muhammad al-ʿImara. Vol. 1. Al-tamaddun wa-ʾl-hadara wa-ʾl-ʿumran. Beirut: Al-Muʾassasa al-ʿArabiyya li-l-Dirasat wa-l-Nashr, 1973–78.

Rizq, Yunan Labib. Al-Wafd wa-ʾl-kitab al-aswad. Cairo: Muʾassasat al-Dirasat al-Siyasiyya wa-ʾl-Istratijiyya, 1978.

Ruf, Thierry. Histoire contemporaine de l’agriculture egyptienne: Essai de synthèse. Bondy, France: Editions de l’Orstom, 1988.

Saad, Reem. “Agriculture and Politics in Contemporary Egypt: The 1997 Tenancy Crisis.” In Discourses in Contemporary Egypt: Political and Social Issues. Edited by Enid Hill, 22–35. Cairo Papers in Social Science 22, monograph 4. Cairo: American University in Cairo Press, 1999.

———. “State, Landlord, Parliament and Peasant: The Story of the 1992 Tenancy Law in Egypt.” In Agriculture in Egypt from Pharaonic to Modern Times. Edited by Alan Bowman and Eugene Rogin, 387–404. Proceedings of the British Academy, no. 96. Oxford: Oxford University Press, 1999.

Saad Mikhail, Reem. “Peasant Perceptions of Recent Egyptian History.” D.Phil. thesis, University of Oxford, 1994.

Sachs, Wolfgang, ed. The Development Dictionary: A Guide to Knowledge and Power. London: Zed Press, 1992.

Sadowski, Yahya. Political Vegetables? Businessman and Bureaucrat in the Development of Egyptian Agriculture. Washington, D.C.: Brookings Institution, 1991.

Said, Edward. Orientalism. New York: Pantheon, 1978.

Saʿid, Rifʿat al-. Al-sihafa al-yasariyya fi misr, 1925–1948. Cairo: Maktabat Madbuli, 1977.

St. John, J. A. Egypt and Nubia, Their Scenery and Their People. London: Chapman and Hall, 1845.

Sami, Amin. Taqwim al-nil wa-asmaʾ man tawallaw amr misr wa-muddat hukmihim ʿalayha wa-mulahazat taʾrikhiyya ʿan ahwal al-khilafa al-ʿamma wa-shuʾun misr al-khassa. Vol. 3., in 3 parts. 1264–1289 (1848–1872). Cairo: Matbaʿat Dar al-Kutub, 1936.

Sami, Salib. Dhikriyyat Salib Basha Sami, 1891–1952. Edited by Sami Abu al-Nur. Cairo: Maktabat Madbuli, 1999.

Saunders, Frances Stonor. The Cultural Cold War: The CIA and the World of Arts and Letters. New York: New Press, 1999. Originally published as Who Paid the Piper: The CIA and the Cultural Cold War. London: Granta Books, 1999.

Sayyad, Nezar al-. “From Vernacularism to Globalism: The Temporal Reality of Traditional Settlements.” Traditional Dwellings and Settlements Review 7, no. 1 (1995): 13–24.

Schultz, Theodore. Transforming Traditional Agriculture. New Haven, Conn.: Yale University Press, 1964.

Schulze, Reinhard. Die Rebellion der ägyptischen Fallahin 1919. Berlin: Baalbek Verlag, 1981.

Scott, James C. Weapons of the Weak: Everyday Forms of Peasant Resistance. New Haven, Conn.: Yale University Press, 1985.

Seddon, David. “Commentary on Agrarian Relations in the Middle East: A New Paradigm for Analysis?” Current Sociology 34, no. 2 (1986): 151–72.

Shaw, Stanford J. The Financial and Administrative Organization and Development of Ottoman Egypt, 1517–1798. Princeton, N.J.: Princeton University Press, 1962.

Simmel, Georg. Philosophie des geldes. Leipzig: Duncker & Humbolt, 1900. English translation, The Philosophy of Money. London: Routledge and Kegan Paul, 1978.

———. “Die Grossstadt und das Geistesleben.” In Die Grossstadt, Vorträge und Aufsätz zur Städteausstellung. Edited by K. Bücher et al. Gehe-Stiftung zu Dresden, Winter 1902–3, Jahrbuch der Gehe-Stiftung zu Dresden, vol. 9. Dresden: von Zahn & Jaensch, 1903.

———. “The Metropolis and Mental Life.” Translated by Edward A. Shils. In Second-Year Course in the Study of Contemporary Society (Social Science II): Syllabus and Selected Readings. Edited by Harry D. Gideonse, Herbert Goldhamer, Earl S. Johnson, Maynard C. Krueger, and Louis Wirth. 5th edition, 221–38. Chicago: University of Chicago Press, 1936.

———. “The Metropolis and Mental Life.” Translated by Hans Gerth with C. Wright Mills. In The Sociology of Georg Simmel. Translated by Kurt H. Wolff, 409–24. New York: Free Press, 1950.

Smith, Charles D. Islam and the Search for Social Order in Modern Egypt: A Biography of Muhammad Husayn Haykal. Albany: State University of New York Press, 1983.

———.“Imagined Identities, Imagined Nationalisms: Print Culture and Egyptian Nationalism in the Light of Recent Scholarship.” International Journal of Middle East Studies 29, no. 4 (1997): 607–22.

Spivak, Gayatri Chakravorty.“Can the Subaltern Speak?” In Marxism and the Interpretation of Culture. Edited by C. Nelson and L. Grossberg, 271–313. Basingstoke: Macmillan Education, 1988. Reprinted in Colonial Discourse and Post-Colonial Theory. Edited by Patrick Williams and Laura Chrisman, 66–111. New York: Columbia University Press, 1994.

Springborg, Robert. Mubarak’s Egypt: Fragmentation of the Political Order. Boulder, Colo.: Westview Press, 1989.

———. “Rolling Back Egypt’s Agrarian Reform.” Middle East Report, no. 166 (Sept.–Oct. 1990): 29.

———. “State-Society Relations in Egypt: The Debate over Owner-Tenant Relations.” Middle East Journal 45, no. 2 (1991): 231–49.

Stark, David. “Recombinant Property in East European Capitalism.” In The Laws of the Markets. Edited by Michel Callon. Sociological Review monograph series, 116–46. Oxford: Blackwell, 1998.

Stauth, Georg. Die Fellachen im Nildelta: Zur Struktur des Konflikts zwischen subsistenz- und warenproduktion in Ländlichen Ägypten. Wiesbaden: Franz Steiner, 1983.

———. “Capitalist Farming and Small Peasant Households in Egypt.” Review 7, no. 2 (1983): 285314. Reprinted in The Rural Middle East: Peasant Lives and Modes of Production. Edited by Kathy Glavanis and Pandeli Glavanis, 122–41. London: Zed Press, 1989.

Steele James. An Architecture for the People: The Complete Works of Hassan Fathy. London: Thames and Hudson, 1997.

Stewart, Frances, Henk Thomas, and Tom de Wilde, eds. The Other Policy: The Influence of Policies on Technology Choice and Small Enterprise Development. London: Intermediate Technology Publications, 1990.

Streeten, Paul. “A Cool Look at Outward-Looking Strategies for Development.” World Economy 5, no. 2 (1982): 166–67.

Sufian, Sandra. “Healing the Land and the Nation: Malaria and the Zionist Project in Mandatory Palestine, 1920–1947.” Ph. D. diss., New York University, 1999.

Taussig, Michael T.“Culture of Terror—Space of Death: Roger Casement’s Putumayo Report and the Explanation of Torture.” Comparative Studies in Society and History 26, no. 3 (1984): 467–97.

Taylor, Elizabeth. “Egyptian Migration and Peasant Wives,” MERIP Reports, no. 124 (1984): 3–10.

Thomas, Nicholas. Entangled Objects: Exchange, Material Culture, and Colonialism in the Pacific. Cambridge, Mass.: Harvard University Press, 1991.

Tignor, Robert L. Modernization and British Colonial Rule in Egypt, 1882–1914. Princeton, N.J.: Princeton University Press, 1966.

———.“Nationalism, Economic Planning, and Development Projects in Interwar Egypt.” International Journal of African Historical Studies 10, no. 2 (1977): 185–208.

———. The State, Private Enterprise and Economic Change in Egypt, 1918–1952. Princeton, N.J.: Princeton University Press, 1984.

———. Egyptian Textiles and British Capital, 1930–1956. Cairo: American University in Cairo Press, 1989.

Toth, James. Rural Labor Movements in Egypt and Their Impact on the State, 1961–1992. Gainesville: University Press of Florida, 1999.

Tribe, Keith. Land, Labour, and Economic Discourse. London: Routledge & Kegan Paul, 1978.

United States Agency for International Development. Annual Budget Submission, FY 1990: Egypt. Washington, D.C.: USAID, 1988.

———. Congressional Presentation, FY 1990. Main Volume, and Annex II: Asia and the Near East. Washington, D.C.: USAID, 1989.

United States Agency for International Development, Office of Agricultural Credit and Economics, Cairo. Agricultural Data Base. Cairo: USAID, 1989.

United States Agency for International Development, Public Affairs Office, Cairo. Status Report: United States Economic Assistance to Egypt. Cairo: USAID, 1989.

United States Congress, Senate Committee on Foreign Relations. The BCCI Affair:A Report to the Committee on Foreign Relations, United States Senate, by Senator John Kerry and Senator Hank Brown. Washington, D.C.: United States Government Printing Office, 1992.

United States Congress, Senate Committee on Foreign Relations, Subcommittee on Multinational Corporations. Hearings on International Grain Companies. 94th Congress, June 1976.

United States Department of Agriculture. Egypt: Major Constraints to In-creasing Agricultural Productivity. Foreign Economic Report no. 120. Washington, D.C.: Department of Agriculture, 1976.

United States Department of Commerce, International Trade Administration. Foreign Economic Trends and their Implication for the U.S. Washington, D.C.: Department of Commerce, 1989.

Urbain, Ismayl [Georges Voisin, pseud.]. L’Algérie pour les Algériens. Paris: Michel Lévy Frères, 1861.

Urry, John. The Tourist Gaze: Leisure and Travel in Contemporary Societies. London: Sage, 1990.

Van der Spek, Kees. “Dead Mountain vs. Living Community: The Theban Necropolis as Cultural Landscape.” Paper presented at the UNESCO Third International Forum, “University and Heritage,” Deakin University, Melbourne and Geelong, Australia, October 4–9, 1998.

Vaucher, Georges.“La Livre égyptienne, de sa creation par Mohamed Aly a ses recentes modifications.”L’Egypte Contemporaine 41, no.256 (Jan.1950):115–46.

Villiers Stuart, Henry. Egypt after the War, Being the Narrative of a Tour of Inspection. London: John Murray, 1883.

Vitalis, Robert. When Capitalists Collide: Business Conflict and the End of Empire in Egypt. Berkeley: University of California Press, 1995.

Volait, Mercedes. L’Architecture moderne en Egypte et la Revue Al-ʿImara, 1939–59. Dossiers du CEDEJ 1987, no. 4. Cairo: Centre d’Etudes et de Documentation Economique, Juridique et Sociale, 1988.

Wald, Alan M. The New York Intellectuals: The Rise and Decline of the AntiStalinist Left from the 1930s to the 1980s. Chapel Hill: University of North Carolina Press, 1987.

Walras, Leon. Eléments d’économie politique pure, ou, Théorie de la richesse sociale. 1 vol. in 2. Lausanne: L. Corbaz, 1874–77.

Walz, Terence. Trade Between Egypt and Bilad as-Sudan, 1700–1820. Cairo: Institut Français d’Archéologie Orientale du Caire, 1978.

Warriner, Doreen. Land and Poverty in the Middle East. Westport, Conn.: Hyperion Press, 1948.

———. Land Reform and Development in the Middle East: A Study of Egypt, Syria, and Iraq. 2d ed. London: Oxford University Press, 1962.

Waterbury, John. The Egypt of Nasser and Sadat: The Political Economy of Two Regimes. Princeton, N.J.: Princeton University Press, 1983.

———. Hydropolitics of the Nile Valley. Syracuse, N.Y.: Syracuse University Press, 1979.

Weber, Max. The Theory of Economic and Social Organization. Edited by Talcott Parsons. Translated by A. M. Henderson and Talcott Parsons. New York: Oxford University Press, 1947.

———. Wirtschaft und Gesellschaft: Grundriss der Verstehenden Soziologie. 2 vols. in 1. Tübingen: Mohr 1972.

Wessel, James, with Mort Hantman. Trading the Future: Farm Exports and the Concentration of Economic Power in Our Food System. San Francisco: In-stitute for Food and Development Policy, 1983.

Wilbour, Charles Edwin. Travels in Egypt (December 1880 to May 1891): Letters of Charles Edwin Wilbour. Edited by Jean Capart. New York: Brooklyn Museum, 1936.

Willcocks, Sir William. Irrigation of Mesopotamia. London: E. & F. N. Spon, 1917.

Willcocks, Sir William, and J. I. Craig. Egyptian Irrigation. 3d ed., 2 vols. London: E. & F. N. Spon, 1913.

World Bank. Trends in Developing Economies 1989. Washington, D.C.: World Bank, 1989.

———. Egypt: Alleviating Poverty. Washington, D.C.: World Bank, 1991.

———. Global Economic Prospects and the Developing Countries: 2000. Washington, D.C.: World Bank, 1999.

World Commission on Dams. Dams and Development: A New Framework for Decision Making. November 2000. Available at www.damsreport.org.

World Commission on Environment and Development. Our Common Future. Oxford: Oxford University Press, 1987.

World Wildlife Fund Canada and World Wildlife Fund U.S. Resolving the DDT Dilemma: Protecting Biodiversity and Human Health. Toronto and Washington, D.C.: WWF Canada and WWF U.S., 1998.

Zaytoun, Mohaya A. “Income Distribution in Egyptian Agriculture and Its Main Determinants.” In The Political Economy of Income Distribution in Egypt. Edited by Gouda Abdel-Khalek and Robert Tignor, 268–306. New York: Holmes and Meier, 1982.

Zelizer, Viviana A. The Social Meaning of Money: Pin Money, Paychecks, Poor Relief and Other Currencies. Princeton, N.J.: Princeton University Press, 1997.

## Newspapers and Periodicals

al-Ahram

al-Ahram al-iqtisadi

al-Ahram Hebdo

al-Ahram Weekly

al-Akhbar

Akhbar al-yawm

Business Monthly (Cairo)

Business Today Egypt

Cairo Times

al-Dustur

Economist

Egyptian Gazette

Financial Times

Guardian Weekly (London)

Middle East Times (Egypt edition)

Le Monde Diplomatique

New York Times

Observer (London)

Ruz al-Yusuf

al-Shaʿb

al-Wafd

Wall Street Journal

## Serials and Archives

Food and Agriculture Organization of the United Nations. The State of Food and Agriculture.

Food and Agriculture Organization of the United Nations. Yearbook.

Gouvernement d’Egypte, Département de la Statistique Générale. L’Annuaire Statistique (1910–).

Government of Egypt, Central Agency for Public Mobilization and Statistics. Statistical Yearbook.

Great Britain, Parliament. Hansard. Available at http://www.parliament.the-stationery-office.co.uk.

United States Congress, House of Representatives, Committee on Foreign Affairs, Subcommittee on Europe and the Middle East. Foreign Assistance Legislation.

United States Department of Agriculture. Agriculture Fact Book.

United States National Archives. Record Group 59, Department of State, Central Files, Egypt. Microform. University Publications of America, 1985.

United States Securities and Exchange Commission. Archives. Available at http://www.sec.gov/archives.

World Bank. World Development Report. Available at http://www.worldbank.org.

World Tourism Organization. World Tourism Highlights. Available at http://www.world-tourism.org.
