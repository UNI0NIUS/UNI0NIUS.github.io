# 第1章外部核验与编辑记录

核验日期：2026-10-16。以下是针对底本疑点的有限核验，不表示已查阅全部106条原注的原始文献或档案。

- 原注3把恶性疟原虫写成 *Plasmodium gambiae*，与正文原19页的 *Plasmodium falciparum* 不同。底本PDF320目视确认。对照[CDC DPDx：Malaria](https://www.cdc.gov/dpdx/malaria/index.html)，按蚊属与疟原虫属应区分；译文保留原注错误名称并说明。
- 原24页以spores统称不同发育阶段。CDC同一页面区分sporozoites、merozoites和gametocytes；蚊吸入配子体。原文说堵塞动脉，相关说明可对照[CDC：Clinical Features of Malaria](https://www.cdc.gov/malaria/hcp/clinical-features/)。原22页的“幼虫孵化”亦保留并提示严格术语问题，参考[CDC：Life Cycle of Anopheles Mosquitoes](https://www.cdc.gov/mosquitoes/about/life-cycle-of-anopheles-mosquitoes.html)。不以当代医学说明取代作者历史论述。
- 原25页确印ammonium nitrate。USGS的[《Mineral Resources in Deserts》](https://pubs.usgs.gov/gip/deserts/minerals/)检索摘要明确记载阿塔卡马用于肥料和炸药的矿物是sodium nitrate；正文打开返回错误，因此证据限于官方检索摘要。仅标明名称疑误，不把硝酸铵静默改成硝酸钠。
- 原35页将《浮士德》称为novel。对照[魏玛古典基金会作品目录](https://goethe.klassik-stiftung.de/de/objekt/knowledge-graph/work/8bdbd03fa506407aac7e40ddfc9d7ae0/)，作品属戏剧/悲剧。对有关圣西门主义者的具体思想影响未做全面史料核验。
- 原45页称高坝1964年开工、1971年完成。[埃及水资源与灌溉部工程年表](https://www.mwri.gov.eg/mwri2/?page_id=33310&lang=en)列1960-01-09开工、1964年5月截流、1970年7月主体完成、1971-01-15正式落成。译文保留底本日期，校注区分工程节点；没有采纳该网页对经济与环境效益的评价来替代作者论点。
- 原46页将穆勒发现DDT杀虫性的年份写成1941。法兰西公学院2022年[《Legacy endocrine disruptors》课程材料](https://www.college-de-france.fr/sites/default/files/media/document/2022-09/Cours%205-Perturbateurs%20endo1-RS-CdF-2022_05_11-web.pdf)检索摘要列1939；此处记录差异。诺贝尔官方个人页、颁奖词和讲座PDF直接打开均返回访问错误，不能声称已读到这些全文。诺贝尔官方[奖项总表](https://www.nobelprize.org/prizes/lists/all-nobel-laureates-in-physiology-or-medicine/all/?gallery_style=page)支持其1948年获奖及DDT接触毒作用的获奖理由。
- 原49页及原注99所说2007年属于当时谈判目标。[斯德哥尔摩公约DDT概述](https://www.pops.int/Implementation/PesticidePOPs/DDT/Overview/tabid/378/Default.aspx)说明附件B在条件限制下保留病媒控制用途。译注只防止把历史目标误读成既成的全面禁用事实。
- 原注46把Appadurai编著写成 *The Cultural Life of Things*。[剑桥出版社扉页](https://assets.cambridge.org/97805213/57265/frontmatter/9780521357265_frontmatter.pdf)及[出版书目](https://doi.org/10.1017/CBO9780511819582)题名为 *The Social Life of Things: Commodities in Cultural Perspective*，1986。译文照录错误并加校注。
- 原注67明确acre专指Egyptian acre/feddan。全章中文统一作费丹，未把它作为英制英亩进行换算。
- 原注23的policosanal、原注102的Gresselli等拼写保留底本，未凭印象替换为其他拼写。文中统计、疗效叙述和环境寿命数字均作为2002年原书论述保留，不表示已逐项复核为当代研究共识。

## 文本提取规范化

原PDF为可提取文本，无需OCR。保留行坐标、字体、斜体与上标注号；IPAExtras字体中的`[`和`]`按原页面字形还原为ʿ和ʾ。合并跨页段落、行末断词和旧网址的换行空白；修复抽取造成的少量标点后空格、fi misr / fi al-的连写；保留复合词和阿拉伯语转写前缀al-/wa-。全部规则在`tools/egypt_source.py`中可复现，原始提取未覆盖。

原文中的章间互见保留，并明确写“本书下文第X章”；交付范围只有第1章，不把其他章节伪装成已收录。所有人名与文献题名中文为工作译法，书目信息保留原语以便检索。
