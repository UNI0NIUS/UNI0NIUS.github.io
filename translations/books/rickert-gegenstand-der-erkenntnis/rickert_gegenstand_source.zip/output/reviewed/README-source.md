# 认识的对象：先验哲学导论　校订阅读成果源码

Heinrich Rickert, Der Gegenstand der Erkenntnis. Einführung in die
Transzendentalphilosophie. Dritte völlig umgearbeitete und erweiterte Auflage.
Tübingen: J. C. B. Mohr (Paul Siebeck), 1915.

规范双语文本、前置材料、原注、译解与修订证据由本包保留。原扫描PDF仍由工作区
保存，未装入本包；来源PDF页序与印刷页码不可混用。书前空白装帧及馆藏痕迹分类
在front_back_inventory.json。原稿807条ID及原定位字段保留，实际阅读位置以
reviewed_*、原页锚、reading_group和note_placement为准。

## 复现

保留目录结构。Python 3与XeLaTeX；PDF检查需要PyMuPDF。PDF字体Times New Roman、
SimSun，字体不随包分发。所用TeX包包括fontspec、xeCJK、geometry、paracol、
fancyhdr、hyperref、needspace、xurl、amsmath。更换字体会改变分页，须重新验收。

    python work/review/build_projection.py
    python work/review/build_reading_editions.py --compile
    python work/review/build_markdown_editions.py
    python work/review/build_web_edition.py
    python work/review/build_inner_data.py
    python work/review/check_pdf_readback.py
    python work/review/check_markdown.py

输出在output/reviewed。也可直接对本包三份TeX各运行两遍xelatex。
模板参数和已验收参考脚本哈希在template_reference.json；生成器已自含样式，
不需要另一书目目录。当前网站已迁入里站，入口为
https://uni0nius.github.io/union.html#/read/rickert-gegenstand-der-erkenntnis。
将inner_webdata内52份JSON置于网站writing/rickert-gegenstand-der-erkenntnis/，
将inner_book_record.json作为独立记录加入里站src/content/writing.json后构建。
沿用当前src/writing.js阅读器与样式，保留无下载控件的设计；不可重跑旧迁移器
覆盖其他书目。本包包含本书数据与生成入口，不复制网站源码或其他书目。
webdata是中间通用格式；适配器只调整原目录链接前缀并计算全书阅读权重。
book-metadata.json由网页生成器重建；发布步骤
再装配下载URL及字节哈希，该动态下载清单不装入ZIP，避免源码包自引用。

## 数据职责与验收

work/review/translation_units.jsonl和front_matter.json为规范数据；
reading_projection.json是可重建的阅读层。该层按原书真实标题顺序决定节归属，
不采用旧元数据按页分配的误归属；逐组件回读保证原文译文不丢字。
原注在PDF节末，在网页相应段落旁；页内原注编号和稳定ID同时保留。
跨页原注p168-n01与p167-n01合为一注，sach+lich连写；诗引保持两行。
原目录与正文Seinsverdoppelung/Seinsverdopplung等实际异文分别记录。

各章语义、前置材料及全书源行/段界/术语审查已记录。来源覆盖不是字形或语义
无误百分比，指定原页核查与外部出处核验范围见global_text_audit_063.json。
PDF全文回读、页面几何及指定实页目视、实际Edge窄屏/注释往返检查分别记录。
发布和线上字节验收是独立步骤，最新状态以网站或工作区交付记录为准。

不要运行历史apply_review或Qoder初译批次来重建。修订文本或原注锚点后应先完成
增量语义核对，再从规范数据生成并复验受影响成果。机器专用OCR缓存、浏览器
临时配置、原始PDF及其他任务文件不在本包。
