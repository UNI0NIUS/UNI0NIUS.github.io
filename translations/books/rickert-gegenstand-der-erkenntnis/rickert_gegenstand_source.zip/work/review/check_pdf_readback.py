"""Actual PDF text/link/geometry readback against canonical projection."""
from pathlib import Path
from collections import Counter
import json,re,unicodedata,hashlib
import pymupdf
R=Path(__file__).resolve().parent;O=R.parents[1]/'output/reviewed'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def norm(s):
 s=re.sub(r'⟦p\.[^⟧]+⟧','',s).replace('ß','ss').replace('ſ','s')
 return ''.join(c for c in unicodedata.normalize('NFKD',s).lower() if c.isalnum())
def text(page,clip):
 # Only actual small links (superscript note refs / return arrows) are removed.
 # Numbers in the running text and bibliographic citations remain testable.
 refs=[x['from'] for x in page.get_links() if x['from'].width<20 and x['from'].height<15]
 out=[]
 for b in page.get_text('rawdict',clip=clip)['blocks']:
  for l in b.get('lines',[]):
   for sp in l['spans']:
    for c in sp['chars']:
     q=pymupdf.Rect(c['bbox']);mid=pymupdf.Point((q.x0+q.x1)/2,(q.y0+q.y1)/2)
     if not any(pymupdf.Rect(z.x0-.5,z.y0-.5,z.x1+.5,z.y1+.5).contains(mid) for z in refs):out.append(c['c'])
 return ''.join(out)
def windows(s,n=44):
 if len(s)<=n:return [s] if s else []
 return list(dict.fromkeys([s[i:i+n] for i in range(0,len(s)-n+1,32)]+[s[-n:]]))

d=json.loads((R/'reading_projection.json').read_text(encoding='utf-8'))
assert d['canonical_sha256']==sha(R/'translation_units.jsonl') and d['front_matter_sha256']==sha(R/'front_matter.json')
raw={x['id']:x for x in map(json.loads,(R/'translation_units.jsonl').read_text(encoding='utf-8').splitlines())}
for pf in d['front']['prefaces']:raw.update({x['id']:x for x in pf['units']})
results={}
for mode in ['zh','de','bilingual']:
 path=O/f'rickert_gegenstand_{mode}.pdf';pdf=pymupdf.open(path);full=[];left=[];right=[];outside=[];badlinks=[]
 for i,p in enumerate(pdf):
  w,h=p.rect.width,p.rect.height
  mm=72/25.4
  if mode=='zh':x0=x1=25*mm
  else:x0,x1=((20*mm,23*mm) if (i+1)%2 else (23*mm,20*mm))
  # The source-page marginalia can extend inside a fixed 50pt crop.
  # Use the actual accepted template's text rectangle, including mirroring.
  full.append(text(p,pymupdf.Rect(x0-.8,54,w-x1+.8,h-52)))
  if mode=='bilingual':
   left.append(text(p,pymupdf.Rect(x0-.8,54,w/2,h-52)));right.append(text(p,pymupdf.Rect(w/2,54,w-x1+.8,h-52)))
  for word in p.get_text('words'):
   if word[0]<-.5 or word[1]<-.5 or word[2]>w+.5 or word[3]>h+.5:outside.append(dict(page=i+1,word=word[4],bbox=word[:4]))
  for link in p.get_links():
   if link['kind']==pymupdf.LINK_GOTO and not (0<=link.get('page',-1)<len(pdf)):badlinks.append(dict(page=i+1,link=str(link)))
 texts={'all':norm(''.join(full))}
 if mode=='bilingual':texts.update(zh=norm(''.join(left)),de=norm(''.join(right)))
 (R/f'pdf_extracted_{mode}.json').write_text(json.dumps(texts,ensure_ascii=False),encoding='utf-8')
 expected=[]
 for g in d['groups']:
  for c in g['components']:
   for lang,field in [('zh','translation'),('de','source_text')]:
    if mode!='bilingual' and mode!=lang:continue
    expected.append((c['unit_id'],lang,raw[c['unit_id']][field],'all' if g['kind'].endswith('heading') or mode!='bilingual' else lang))
 for pf in d['front']['prefaces']:
  for c in pf['units']:
   for lang,field in [('zh','translation'),('de','source_text')]:
    if mode=='bilingual' or mode==lang:expected.append((c['id'],lang,c[field],lang if mode=='bilingual' else 'all'))
 for n in d['notes']:
  for c in n['components']:
   for lang,field in [('zh','translation'),('de','source_text')]:
    if mode=='de' and lang=='zh':continue
    expected.append((c['unit_id'],lang,raw[c['unit_id']][field],lang if mode=='bilingual' else 'all'))
 for g in d['groups']:
  for c in g['components']:
   for e in c['editorial_notes']:
    for lang in (['zh','de'] if mode=='bilingual' else [mode]):expected.append((c['unit_id']+'-editorial',lang,(e.get('note_zh') or e.get('translation_note') or e.get('text')) if lang=='zh' else e['note_de'],lang if mode=='bilingual' else 'all'))
 for i,key in enumerate(['kant','plato']):
  e=d['front']['epigraph'][key]
  for lang in (['zh','de'] if mode=='bilingual' else [mode]):expected.append(('epigraph-'+key,lang,e['zh'] if lang=='zh' else e['de' if key=='kant' else 'el'],lang if mode=='bilingual' else 'all'))
 missing=[];checked=0
 for uid,lang,original,zone in expected:
  for window in windows(norm(original)):
   checked+=1
   if window not in texts[zone]:missing.append(dict(id=uid,lang=lang,zone=zone,window=window))
 log=(O/f'rickert_gegenstand_{mode}.log').read_text(encoding='utf-8',errors='replace')
 warnings=[s for s in log.splitlines() if any(k in s for k in ['Missing character','Overfull','undefined','multiply defined'])]
 results[mode]=dict(pdf_sha256=sha(path),pages=len(pdf),bookmarks=len(pdf.get_toc()),expected_components=len(expected),windows_checked=checked,missing_windows=missing,off_page_words=outside,bad_internal_links=badlinks,log_issues=warnings,links=sum(len(p.get_links()) for p in pdf),status='passed' if not any([missing,outside,badlinks,warnings]) else 'failed')
 print(mode,dict(pages=len(pdf),windows=checked,missing=len(missing),outside=len(outside),bad_links=len(badlinks),log_issues=len(warnings)))
 for x in missing[:7]:print(x)
(R/'pdf_readback_check.json').write_text(json.dumps(dict(canonical_sha256=d['canonical_sha256'],front_matter_sha256=d['front_matter_sha256'],method='Actual PDF chars in full/parallel column clips; only small hyperlink glyphs excluded; all text and citation digits retained; 44-character overlapping windows. Not a visual or fact check.',editions=results),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
