"""Read actual Markdown back: all projection runs, notes, verse and emphasis."""
from pathlib import Path
import json, re, hashlib, unicodedata
R = Path(__file__).resolve().parent
O = R.parents[1] / 'output/reviewed'
d = json.loads((R/'reading_projection.json').read_text(encoding='utf-8'))
def norm(s):
    s = re.sub(r'<a\b[^>]*></a>', '', s)
    s = re.sub(r'^\[\^[^\]]+\]:', '', s, flags=re.M)
    s = re.sub(r'\[\^[^\]]+\]', '', s)
    return ''.join(c for c in unicodedata.normalize('NFKC',s) if not c.isspace() and c not in '*>' and unicodedata.category(c) != 'Cf')
def source(runs):
    return ''.join(t.get('text','') if t['type'] != 'verse' else ''.join(t['lines']) for t in runs if t['type'] != 'note_ref')
report = {'status':'passed','canonical_sha256':d['canonical_sha256'],'editions':{}}
for lang in ['zh','de']:
    p = O / f'rickert_gegenstand_{lang}.md'
    raw = p.read_bytes(); s = raw.decode('utf-8'); flat = norm(s)
    definitions = re.findall(r'^\[\^([^\]]+)\]:',s,re.M)
    assert len(definitions)==184 and len(set(definitions))==184
    # A body reference may legitimately be followed by a colon.
    refs = re.findall(r'\[\^([^\]]+)\]',re.sub(r'^\[\^[^\]]+\]:','',s,flags=re.M))
    assert set(refs)==set(definitions)
    assert b'\r' not in raw
    components = [c for g in d['groups'] for c in g['components']] + [c for pf in d['prefaces'] for c in pf['units']] + d['epigraphs'] + [c for n in d['notes'] for c in n['components']]
    windows = 0
    for c in components:
        expected = norm(source(c[lang+'_runs']))
        for offset in range(0,len(expected),44):
            assert expected[offset:offset+88] in flat, (lang,c['unit_id'],offset)
            windows += 1
        for t in c[lang+'_runs']:
            if t['type']=='emphasis': assert '*'+t['text']+'*' in s
            if t['type']=='verse':
                for line in t['lines']: assert '> '+line+'  ' in s
    report['editions'][lang]={'sha256':hashlib.sha256(raw).hexdigest(),'components':len(components),'windows':windows,'notes':len(definitions),'unresolved_refs':0,'newline':'LF'}
(R/'markdown_export_check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
