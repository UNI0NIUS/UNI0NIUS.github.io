"""Chinese/German editable reading editions from the shared projection."""
from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parent;O=R.parents[1]/'output/reviewed';O.mkdir(exist_ok=True,parents=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
d=json.loads((R/'reading_projection.json').read_text(encoding='utf-8'))
assert d['canonical_sha256']==sha(R/'translation_units.jsonl') and d['front_matter_sha256']==sha(R/'front_matter.json')
def runs(rs):
 out=[]
 for t in rs:
  if t['type']=='text':out.append(t['text'])
  elif t['type']=='note_ref':out.append('[^'+t['note_id']+']')
  elif t['type']=='emphasis':out.append('*'+t['text']+'*')
  elif t['type']=='verse':out.append('\n\n'+'\n'.join('> '+l+'  ' for l in t['lines'])+'\n\n')
  else:raise ValueError(t)
 return ''.join(out)
def component(c,lang):return '<a id="'+lang+'-'+c['unit_id']+'"></a>'+runs(c[lang+'_runs'])
def components(cs,lang):return ''.join((c['source_joiner' if lang=='de' else 'translation_joiner'] if i else '')+component(c,lang) for i,c in enumerate(cs))
report={}
for lang in ['zh','de']:
 f=d['front'];a=['# '+('认识的对象：先验哲学导论' if lang=='zh' else 'Der Gegenstand der Erkenntnis. Einführung in die Transzendentalphilosophie'),
 '海因里希·李凯尔特 / Heinrich Rickert · Tübingen: J. C. B. Mohr (Paul Siebeck), 1915.',
 f['title_block']['edition' if lang=='zh' else 'edition_de'],f['translator_note' if lang=='zh' else 'translator_note_de']]
 a.append('## '+('题词、版权与印刷所' if lang=='zh' else 'Motti, Rechte und Druckvermerk'))
 for i,key in enumerate(['kant','plato']):
  a.append(component(d['epigraphs'][i],lang))
  a.append(f['epigraph'][key]['ref'] if lang=='zh' else '[Redaktionell ergänzte Quelle] '+('Kant, Kritik der reinen Vernunft, erste Auflage, AA IV, S. 133, Z. 14–19.' if key=='kant' else 'Platon, Politeia 509b.'))
 a.append(f['epigraph']['rights' if lang=='zh' else 'rights_de']+' '+f['epigraph']['printer' if lang=='zh' else 'printer_de'])
 a.extend(['## '+('献辞' if lang=='zh' else 'Widmung'),f['dedication'][lang]])
 for pf in d['prefaces']:
  a.append('## '+pf['title_'+lang]);a.extend(component(c,lang) for c in pf['units']);a.append(pf['date_'+lang])
  if pf['signature_'+lang]:a.append(pf['signature_'+lang])
 a.append('## '+('原书目录（原书页码）' if lang=='zh' else 'Inhalt des Originals (Originalseiten)'))
 for e in f['original_toc']['entries']:a.append(('- ' if e['kind']=='chapter_heading' else '  - ')+(e['translation'] if lang=='zh' else e['source_text'])+' — '+str(e['printed_page']))
 for g in d['groups']:
  value=components(g['components'],lang)
  if g['kind']=='chapter_heading' and lang=='de':value={1:'Erstes',2:'Zweites',3:'Drittes',4:'Viertes',5:'Fünftes'}[g['chapter']]+' Kapitel. '+value
  if g['kind'].endswith('heading'):value=('#'* (2 if g['kind']=='chapter_heading' else 3))+' '+value
  a.append(value)
  for c in g['components']:
   for n in c['editorial_notes']:
    note=(n.get('note_zh') or n.get('translation_note') or n.get('text')) if lang=='zh' else n['note_de']
    a.append(('〔编者按〕' if lang=='zh' else '[Redaktionelle Erläuterung] ')+note)
 a.append('## '+('原注' if lang=='zh' else 'Anmerkungen'))
 for n in d['notes']:
  label='–'.join([n['printed_pages'][0],n['printed_pages'][-1]]) if len(n['printed_pages'])>1 else n['printed_page']
  value='[S. '+str(label)+', '+str(n['number'])+'] '+components(n['components'],lang)
  if lang=='zh':value+='\n\n原文：'+components(n['components'],'de')
  a.append('[^'+n['id']+']: '+value.replace('\n','\n    '))
 p=O/f'rickert_gegenstand_{lang}.md';p.write_text('\n\n'.join(a)+'\n',encoding='utf-8',newline='\n');report[lang]=dict(path=str(p),sha256=sha(p),notes=len(d['notes']))
(R/'markdown_export_check.json').write_text(json.dumps(dict(canonical_sha256=d['canonical_sha256'],front_matter_sha256=d['front_matter_sha256'],status='exported_pending_readback',editions=report),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Chinese/German Markdown exported from the PDF/web projection.')
