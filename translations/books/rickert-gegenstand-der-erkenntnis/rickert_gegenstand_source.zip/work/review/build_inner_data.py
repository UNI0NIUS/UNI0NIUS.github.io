"""Portable adapter for the current homepage inner reader; no shared-site writes."""
from pathlib import Path
import json, unicodedata

R = Path(__file__).resolve().parent
O = R.parents[1] / 'output/reviewed'

def text(nodes):
    if not isinstance(nodes, list):
        nodes = [nodes]
    def value(node):
        if isinstance(node, str): return node
        if isinstance(node, list): return text(node)
        node = node or {}
        return ' '.join([node.get('tex') or '', text(node.get('children', [])), text(node.get('rows', []))])
    return ' '.join(value(n) for n in nodes)

def reading_units(block):
    s = block.get('readingText') or text(block.get('en') or block.get('zh') or [])
    count, inside = 0, False
    for c in s:
        category = unicodedata.category(c)[0]
        start = category in 'LN'
        continuation = category in 'LMN' or c in "'’-"
        if not inside and start:
            count += 1
            inside = True
        elif inside and not continuation:
            inside = False
    return max(1, count)

def adapt(value, book):
    if isinstance(value, list):
        for child in value: adapt(child, book)
    elif isinstance(value, dict):
        if value.get('type') == 'link' and value.get('url', '').startswith('book.html?id=' + book):
            value['url'] = 'translations/' + value['url']
        for child in value.values(): adapt(child, book)

def build():
    source, output = O / 'webdata', O / 'inner_webdata'
    output.mkdir(exist_ok=True, parents=True)
    meta = json.loads((source / 'book-metadata.json').read_text(encoding='utf-8'))
    chapters = []
    for chapter in meta['chapters']:
        data = json.loads((source / (chapter['id'] + '.json')).read_text(encoding='utf-8'))
        adapt(data, meta['id'])
        (output / (chapter['id'] + '.json')).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
        chapters.append({**chapter, 'dataUrl': f"/writing/{meta['id']}/{chapter['id']}.json", 'readingUnits': sum(reading_units(b) for b in data['body'])})
    post = {k:v for k,v in meta.items() if k != 'downloads'}
    post.update(slug=meta['id'], type='translation', kind='book', subtitle=meta['originalTitle'],
                translator='Xiaoyang Hao (AI-assisted translation, reviewed edition)', tags=['Philosophy','Epistemology'],
                chapters=chapters, parts=[], content='', date='', readTime='', number='')
    previous = R / 'inner_book_record.json'
    if previous.exists():
        assert json.loads(previous.read_text(encoding='utf-8')) == post, 'Adapter disagrees with previously validated native reader record'
    previous.write_text(json.dumps(post, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
    print(json.dumps({'chapters': len(chapters), 'readingUnits': sum(c['readingUnits'] for c in chapters), 'native_record_equal': True}))

if __name__ == '__main__': build()
