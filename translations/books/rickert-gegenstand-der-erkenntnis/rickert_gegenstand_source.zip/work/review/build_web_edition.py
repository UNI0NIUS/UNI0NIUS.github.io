"""Export this book's data for the existing, unmodified bilingual reader."""
from pathlib import Path
from collections import OrderedDict,Counter
import json,re,hashlib
R=Path(__file__).resolve().parent;O=R.parents[1]/'output/reviewed/webdata';O.mkdir(parents=True,exist_ok=True)
BOOK='rickert-gegenstand-der-erkenntnis';BASE='translations/books/'+BOOK+'/'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,o):p.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
d=json.loads((R/'reading_projection.json').read_text(encoding='utf-8'))
assert d['canonical_sha256']==sha(R/'translation_units.jsonl') and d['front_matter_sha256']==sha(R/'front_matter.json')
raw={x['id']:x for x in map(json.loads,(R/'translation_units.jsonl').read_text(encoding='utf-8').splitlines())}
for pf in d['front']['prefaces']:raw.update({x['id']:x for x in pf['units']})
notes={n['id']:n for n in d['notes']};references=Counter();page_counter=Counter();allanchors=[]
def text_tokens(s,uid,lang,suppress_first=False):
 out=[];cursor=0
 for m in re.finditer(r'⟦p\.([^⟧]+)⟧',s):
  if m.start()<cursor:continue
  out.append(s[cursor:m.start()]);page=m[1];page_counter[lang,uid]+=1
  ident=f'{lang}-{uid}-page-{page_counter[lang,uid]}';allanchors.append(ident)
  first=m.start()==0 and suppress_first
  # Preserve the exact word-boundary anchor while placing its visible page
  # label after the word, so a page marker does not split a German word.
  if lang=='en' and m.start()>0 and re.match(r'[A-Za-zÄÖÜäöüß]',s[m.start()-1]) and re.match(r'[A-Za-zÄÖÜäöüß]',s[m.end():m.end()+1]):
   tail=re.match(r'[A-Za-zÄÖÜäöüß]+',s[m.end():])[0]
   out.extend([dict(type='anchor',id=ident),tail,dict(type='page',page=page,id=ident+'-label')]);allanchors.append(ident+'-label');cursor=m.end()+len(tail)
  else:
   out.append(dict(type='anchor',id=ident) if first else dict(type='page',page=page,id=ident));cursor=m.end()
 out.append(s[cursor:]);return [z for z in out if z!='']
def runs(rs,uid,lang,suppress_first=False):
 out=[]
 for i,t in enumerate(rs):
  if t['type']=='text':out.extend(text_tokens(t['text'],uid+'-r'+str(i),lang,suppress_first and i==0))
  elif t['type']=='emphasis':out.append(dict(type='em',children=text_tokens(t['text'],uid+'-r'+str(i),lang)))
  elif t['type']=='verse':out.append(dict(type='verse',children=[dict(type='block',kind='verse-line',children=[line]) for line in t['lines']]))
  elif t['type']=='note_ref':
   nid=t['note_id'];out.append(dict(type='note',id=nid,label=str(notes[nid]['number'])));references[lang,nid]+=1
  else:raise ValueError(t)
 return out
def components(cs,lang,suppress_first=True):
 out=[]
 for i,c in enumerate(cs):
  if i:out.append(c['source_joiner' if lang=='en' else 'translation_joiner'])
  anchor=lang+'-'+c['unit_id'];out.append(dict(type='anchor',id=anchor));allanchors.append(anchor)
  out+=runs(c['de_runs' if lang=='en' else 'zh_runs'],c['unit_id'],lang,suppress_first and i==0)
 return out
def section(sid,zh,de,parent=None):return dict(id=sid,title=zh,originalTitle=de,body=[],notes={},sourceLanguage='de',sourceLanguageLabel='Deutsch',**({'parentId':parent} if parent else {}))
def row(sid,zh,de,kind='paragraph',page=''):return dict(id=sid,type=kind,page=page,zh=zh if isinstance(zh,list) else [zh],en=de if isinstance(de,list) else [de])
sections=OrderedDict();f=d['front'];front=section('front-matter','书前材料','Titelei');sections[front['id']]=front
front['body'].extend([
 row('fm-title',f['title_block']['chinese_title']+'：'+f['title_block']['chinese_subtitle'],f['title_block']['original_title'],'heading'),
 row('fm-author',f['title_block']['author'],f['title_block']['original_author']),
 row('fm-edition',f['title_block']['edition'],f['title_block']['edition_de']),
 row('fm-publisher',f['title_block']['publisher'],f['title_block']['publisher_de']),
 row('fm-reading-note',f['translator_note'],f['translator_note_de'])])
for i,key in enumerate(['kant','plato']):
 c=d['epigraphs'][i];front['body'].append(row(c['unit_id'],components([c],'zh',False),components([c],'en',False),'quote'))
 e=f['epigraph'][key];front['body'].append(row('fm-citation-'+key,e['ref'],'[Redaktionell ergänzte Quelle] '+('Kant, Kritik der reinen Vernunft, erste Auflage, AA IV, S. 133, Z. 14–19.' if key=='kant' else 'Platon, Politeia 509b.')))
front['body'].extend([row('fm-rights',f['epigraph']['rights'],f['epigraph']['rights_de']),row('fm-printer',f['epigraph']['printer'],f['epigraph']['printer_de']),row('fm-dedication-title','献辞','Widmung','subheading'),row('fm-dedication',f['dedication']['zh'],f['dedication']['de'])])
for pf in d['prefaces']:
 s=section(pf['id'],pf['title_zh'],pf['title_de']);sections[s['id']]=s;s['body'].append(row(pf['id']+'-title',pf['title_zh'],pf['title_de'],'heading'))
 for c in pf['units']:
  page=re.search(r'⟦p\.([^⟧]+)⟧',raw[c['unit_id']]['source_text'])[1];s['body'].append(row(c['unit_id'],components([c],'zh'),components([c],'en'),page=page))
 s['body'].append(row(pf['id']+'-date',pf['date_zh'],pf['date_de']))
 if pf['signature_de']:s['body'].append(row(pf['id']+'-signature',pf['signature_zh'],pf['signature_de']))
toc=section('original-toc','原书目录（原书页码）','Inhalt des Originals (Originalseiten)');sections[toc['id']]=toc
toc['body'].append(row('original-toc-title',toc['title'],toc['originalTitle'],'heading','XV'))
group_section={};scope_section={};ordinals={1:'Erstes',2:'Zweites',3:'Drittes',4:'Viertes',5:'Fünftes'}
for g in d['groups']:
 chapter=g['chapter'];code=g['section'];sid=f'chapter-{chapter}'+('-'+code.lower() if code else '')
 if sid not in sections:
  assert g['kind'].endswith('heading'),(sid,g['id'])
  x=raw[g['id']];title=x['source_text'];title=ordinals[chapter]+' Kapitel. '+title if g['kind']=='chapter_heading' else title
  sections[sid]=section(sid,x['translation'],title,f'chapter-{chapter}' if code else None)
 scope_section[chapter,code]=sid;group_section[g['id']]=sid;s=sections[sid];x=raw[g['id']]
 z=components(g['components'],'zh');e=components(g['components'],'en')
 if g['kind']=='chapter_heading':e.insert(0,ordinals[chapter]+' Kapitel. ')
 page=(x.get('reviewed_printed_pages') or [int(q) for q in re.findall(r'⟦p\.(\d+)⟧',x['source_text'])] or x['printed_pages'])[0]
 s['body'].append(row(g['id'],z,e,'heading' if g['kind'].endswith('heading') else 'paragraph',str(page)))
 for c in g['components']:
  for j,n in enumerate(c['editorial_notes']):
   zh=n.get('note_zh') or n.get('translation_note') or n.get('text')
   s['body'].append(row(c['unit_id']+f'-editorial-{j+1}',[dict(type='block',kind='notice',children=['〔编者按〕'+zh])],[dict(type='block',kind='notice',children=['[Redaktionelle Erläuterung] '+n['note_de']])]))
for e in f['original_toc']['entries']:
 sid=group_section[e['target_id']];url='book.html?id='+BOOK+'&chapter='+sid+'#'+e['target_id'];page='XVI' if e['target_id']=='p255-sec' else ''
 toc['body'].append(row('toc-'+e['target_id'],[dict(type='link',url=url,children=[e['translation']+' — '+str(e['printed_page'])])],[dict(type='link',url=url,children=[e['source_text']+' — '+str(e['printed_page'])])],page=page))
for n in d['notes']:
 s=sections[scope_section[n['chapter'],n['section']]];label='–'.join([n['printed_pages'][0],n['printed_pages'][-1]]) if len(n['printed_pages'])>1 else n['printed_page']
 # Prefix component IDs in the Chinese note's additional German original;
 # the same source also appears in the independent German column.
 zh=components(n['components'],'zh');de=components(n['components'],'en');extra=[]
 for t in de:
  if isinstance(t,dict) and t.get('id'):t=dict(t,id='zh-original-'+t['id']);allanchors.append(t['id'])
  extra.append(t)
 s['notes'][n['id']]=dict(number=str(n['number']),sourcePrintedPage=label,sourcePdfPage=int(n['printed_page'])+22,zh=['[原书第'+str(label)+'页] ']+zh+[dict(type='break'),'原文：']+extra,en=['[S. '+str(label)+'] ']+de)
assert len(references)==368 and set(references.values())=={1}
assert sum(len(s['notes']) for s in sections.values())==184
meta=dict(id=BOOK,title='认识的对象：先验哲学导论',originalTitle='Der Gegenstand der Erkenntnis. Einführung in die Transzendentalphilosophie',author='Heinrich Rickert',authorZh='海因里希·李凯尔特',tags=['哲学 Philosophy','认识论 Epistemology'],language='zh-CN',languagePair='Deutsch / 中文',structured=True,bilingual=True,views=['zh','en','parallel'],sourceLanguage='de',sourceLanguageLabel='Deutsch',editionNotice='据1915年第三版校订。原书章节目次与页码保留；原注保留原页码及页内编号，中文原注附德文原文。',chapters=[],downloads=[])
for s in sections.values():
 entry=dict(id=s['id'],title=s['title'],originalTitle=s['originalTitle'],dataUrl=BASE+s['id']+'.json')
 if s.get('parentId'):entry['parentId']=s['parentId']
 meta['chapters'].append(entry);dump(O/(s['id']+'.json'),{k:v for k,v in s.items() if k!='parentId'})
assert len(sections)==52
dump(O/'book-metadata.json',meta)
dump(R/'web_export_check.json',dict(canonical_sha256=d['canonical_sha256'],front_matter_sha256=d['front_matter_sha256'],status='exported_pending_DOM_and_browser_acceptance',sections=len(sections),rows=sum(len(s['body']) for s in sections.values()),primary_notes=184,refs_per_language=184,shared_renderer_modified=False,files={p.name:sha(p) for p in O.glob('*.json')}))
print('Exported 52 reader sections, 5 chapter roots / 42 children, 184 notes and 13 preface paragraphs. Site unchanged.')
