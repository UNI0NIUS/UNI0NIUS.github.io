"""Current PDF entrypoint. Reads only the lossless projection; never old builders.
Typography is adapted from the accepted Gesammelte Schriften I builder.
"""
from pathlib import Path
from collections import defaultdict
import json,re,hashlib,subprocess,sys,ast
R=Path(__file__).resolve().parent;B=R.parents[1];O=B/'output/reviewed';O.mkdir(parents=True,exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def esc(s):return ''.join({'\\':r'\textbackslash{}','&':r'\&','%':r'\%','$':r'\$','#':r'\#','_':r'\_','{':r'\{','}':r'\}','~':r'\textasciitilde{}','^':r'\textasciicircum{}'}.get(c,c) for c in s)

PRE=r'''\documentclass[SIZE,a4paper,twoside]{article}
\usepackage{fontspec,xeCJK}
\setmainfont{Times New Roman}
\setCJKmainfont[AutoFakeBold=2,AutoFakeSlant=.2]{SimSun}
\usepackage[GEOMETRY]{geometry}
\usepackage{xcolor,paracol,fancyhdr,hyperref,needspace,xurl,amsmath}
\hypersetup{unicode=true,hidelinks,pdftitle={Der Gegenstand der Erkenntnis / 认识的对象},pdfauthor={Heinrich Rickert}}
\setlength{\parindent}{1em}\setlength{\parskip}{5pt}\setlength{\columnsep}{8mm}\setlength{\emergencystretch}{3em}
\tolerance=2000\widowpenalty=10000\clubpenalty=10000
\pagestyle{fancy}\fancyhf{}\fancyhead[LE,RO]{\small Der Gegenstand der Erkenntnis}
\fancyhead[LO,RE]{\small Heinrich Rickert}\fancyfoot[C]{\thepage}\setlength{\headheight}{14pt}
\DeclareRobustCommand{\sourcepage}[1]{\marginpar{\raggedleft\fontsize{8}{10}\selectfont\color{black!65}S.\ #1}}
\twosided[pm]\marginparthreshold{0}
\setcounter{tocdepth}{2}\setcounter{secnumdepth}{-1}
\renewcommand{\contentsname}{本版目录 / Inhalt dieser Ausgabe}
\begin{document}
'''

class Renderer:
 def __init__(self,data,mode,prototype=False):
  self.d=data;self.mode=mode;self.bi=mode=='bilingual';self.last={'zh':None,'de':None};self.out=[];self.opened=False;self.pages=[]
  self.units={x['id']:x for x in map(json.loads,(R/'translation_units.jsonl').read_text(encoding='utf-8').splitlines())}
  self.prototype=prototype;self.references=defaultdict(set)
 def text(self,s,lang,pages=True):
  result=[]
  for p in re.split(r'(⟦p\.[^⟧]+⟧)',s):
   if p.startswith('⟦p.'):
    label=p[3:-1]
    if pages and label!=self.last[lang]:
     if not (self.bi and lang=='de'):
      result.append(r'\sourcepage{'+esc(label)+'}')
      if (self.bi and lang=='zh') or self.mode==lang:self.pages.append(label)
     self.last[lang]=label
   else:result.append(esc(p).replace('\n\n',r'\par ').replace('\n',r'\newline '))
  return ''.join(result)
 def runs(self,runs,lang,pages=True):
  out=[]
  for t in runs:
   if t['type']=='text':out.append(self.text(t['text'],lang,pages))
   elif t['type']=='emphasis':out.append(r'\emph{'+self.text(t['text'],lang,pages)+'}')
   elif t['type']=='verse':out.append(r'\par\smallskip{\small\noindent '+r'\\* '.join(self.text(l,lang,pages) for l in t['lines'])+r'\par}\smallskip\noindent ')
   elif t['type']=='note_ref':
    nid=t['note_id'];self.references[lang].add(nid)
    out.append(r'\hypertarget{ref-'+lang+'-'+nid+r'}{}\hyperlink{note-'+nid+r'}{\textsuperscript{'+str(self.note_map[nid]['number'])+'}}')
   else:raise ValueError(t)
  return ''.join(out)
 def component(self,c,lang,pages=True,continuation=False):
  return r'\hypertarget{'+lang+'-'+c['unit_id']+'}{}'+self.runs(c[lang+'_runs'],lang,pages)
 def components(self,cs,lang,pages=True):
  out=[]
  for i,c in enumerate(cs):
   if i:out.append(c['source_joiner' if lang=='de' else 'translation_joiner'])
   out.append(self.component(c,lang,pages))
  return ''.join(out)
 def close(self):
  if self.opened:self.out.append(r'\end{paracol}');self.opened=False
 def pair(self,zh,de,small=False):
  if self.bi:
   if not self.opened:self.out.append(r'\begin{paracol}{2}');self.opened=True
   if small:zh=r'{\small '+zh+'}';de=r'{\small '+de+'}'
   self.out.extend([zh+r'\par',r'\switchcolumn',de+r'\par',r'\switchcolumn*'])
  else:self.out.append((zh if self.mode=='zh' else de)+r'\par')
 def plain_pair(self,zh,de,small=False,pages=True):self.pair(self.text(zh,'zh',pages),self.text(de,'de',pages),small)
 def heading(self,zh,de,chapter=False,page=None,uid=None):
  self.close()
  if chapter:self.out.append(r'\clearpage')
  self.out.append(r'\needspace{7\baselineskip}')
  title=de if self.mode=='de' else zh
  z=(r'\hypertarget{zh-'+uid+'}{}' if uid else '')+self.text((f'⟦p.{page}⟧' if page else '')+zh,'zh')
  d=(r'\hypertarget{de-'+uid+'}{}' if uid else '')+self.text((f'⟦p.{page}⟧' if page else '')+de,'de')
  command='section' if chapter else 'subsection'
  self.out.append('\\'+command+'['+esc(title)+']{'+(z+r'\\{\normalsize '+d+'}' if self.bi else (z if self.mode=='zh' else d))+'}')
 def editorial(self,cs):
  for c in cs:
   for n in c['editorial_notes']:
    zh=n.get('note_zh') or n.get('translation_note') or n.get('text');de=n.get('note_de')
    assert zh and de,(c['unit_id'],'bilingual editorial explanation required')
    self.plain_pair('〔编者按〕'+zh,'[Redaktionelle Erläuterung] '+de,True,False)
 def endnotes(self,scope):
  ns=self.by_scope.get(scope,[])
  if not ns:return
  self.close();self.out.append(r'\needspace{6\baselineskip}\subsection*{原注 / Anmerkungen}')
  for n in ns:
   nid=n['id'];target=r'\hypertarget{note-'+nid+'}{}';label='–'.join([n['printed_pages'][0],n['printed_pages'][-1]]) if len(n['printed_pages'])>1 else n['printed_page']
   mark=r'{\small [S. '+esc(str(label))+r']} \textsuperscript{'+str(n['number'])+'} '
   zh=target+mark+self.components(n['components'],'zh',False)+r'~\hyperlink{ref-zh-'+nid+r'}{\textsuperscript{↑}}'
   de=(target if self.mode=='de' else '')+mark+self.components(n['components'],'de',False)+r'~\hyperlink{ref-de-'+nid+r'}{\textsuperscript{↑}}'
   if self.mode=='zh':zh+=r'\par{\small 原文：'+self.components(n['components'],'de',False)+'}'
   self.pair(zh,de,True)
  self.close()
 def front(self):
  f=self.d['front'];self.out += [r'\begin{titlepage}\centering\vspace*{25mm}{\Huge 认识的对象\par}\bigskip{\Large Der Gegenstand der Erkenntnis\par}\bigskip{\Large 先验哲学导论\par}\bigskip Einführung in die Transzendentalphilosophie\par\vspace{15mm}{\Large 海因里希·李凯尔特 / Heinrich Rickert\par}\vfill']
  self.out.append(self.text({'zh':'中文校订版','de':'Deutsche Leseausgabe','bilingual':'中德逐段对照版'}[self.mode]+(' · 排版试版 / Satzprobe' if self.prototype else ''),'zh',False))
  self.out.append(r'\par\bigskip '+self.text(f['title_block']['edition']+' / '+f['title_block']['edition_de'],'zh',False)+r'\par\bigskip Tübingen: J. C. B. Mohr (Paul Siebeck), 1915\par\end{titlepage}')
  self.plain_pair('页边“S.”为原书印刷页码，页底为本版页码；对照版页标沿中文栏定位。原注置于各节末，保留原页码及页内编号，可跳转与返回。中文原注附德文原文。','Die Randverweise „S.“ bezeichnen die Druckseiten des Originals; die Fußzeile zählt die Seiten dieser Ausgabe. In der zweisprachigen Ausgabe folgen die Randverweise der chinesischen Spalte. Originalanmerkungen stehen mit Seitenangabe und ursprünglicher Nummer am Abschnittsende; Verweise und Rückverweise sind verknüpft.',False,False)
  self.plain_pair(f['translator_note'],f['translator_note_de'],False,False)
  self.close();self.out.append(r'\clearpage\tableofcontents\clearpage')
  ep=f['epigraph'];self.heading('题词、版权与印刷所','Motti, Rechte und Druckvermerk')
  for i,(key,source_field) in enumerate([('kant','de'),('plato','el')]):
   t=ep[key];c=self.d['epigraphs'][i];self.pair('“'+self.component(c,'zh',False)+'”','„'+self.component(c,'de',False)+'“')
   self.plain_pair(t['ref'],'[Redaktionell ergänzte Quelle] '+('Kant, Kritik der reinen Vernunft, erste Auflage, AA IV, S. 133, Z. 14–19.' if key=='kant' else 'Platon, Politeia 509b.'),True,False)
  self.plain_pair(ep['rights']+' '+ep['printer'],ep['rights_de']+' '+ep['printer_de'],True,False)
  self.heading('献辞','Widmung');self.plain_pair(f['dedication']['zh'],f['dedication']['de'])
  for pf in self.d['prefaces']:
   self.heading(pf['title_zh'],pf['title_de'])
   for c in pf['units']:self.pair(self.component(c,'zh'),self.component(c,'de'))
   self.plain_pair(pf['date_zh'],pf['date_de'])
   if pf['signature_de']:self.plain_pair(pf['signature_zh'],pf['signature_de'])
  self.heading('原书目录（原书页码）','Inhalt des Originals (Originalseiten)',page='XV')
  for e in f['original_toc']['entries']:
   prefix='⟦p.XVI⟧' if e['target_id']=='p255-sec' else ''
   de=e['source_text'];zh=e['translation'];pg=e['printed_page'];self.plain_pair(prefix+zh+'　'+str(pg),prefix+de+'　'+str(pg),True,True)
  self.close()
 def render(self):
  selected={g['id'] for g in self.d['groups']}
  if self.prototype:
   selected={'p001-ch','p001-u0001','p012-u0022','p084-u0161','p143-u0261','p162-u0291','p251-u0456','p291-u0525','p292-u0529','p346-u0616','p378-u0675','p413-u0734','p443-u0783'}
   selected.add(next(g['id'] for g in self.d['groups'] if any(r.get('note_id')=='p167-n01' for c in g['components'] for r in c['de_runs'])))
  groups=[g for g in self.d['groups'] if g['id'] in selected];ids={c['unit_id'] for g in groups for c in g['components']}
  ns=[n for n in self.d['notes'] if n['body_unit_id'] in ids];self.note_map={n['id']:n for n in ns};self.by_scope=defaultdict(list)
  for n in ns:self.by_scope[n['chapter'],n['section']].append(n)
  geo='a4paper,inner=20mm,outer=23mm,top=21mm,bottom=23mm' if self.bi or self.mode=='de' else 'a4paper,margin=25mm'
  self.out=[PRE.replace('SIZE','10pt' if self.bi or self.mode=='de' else '11pt').replace('GEOMETRY',geo+',marginparwidth=16mm,marginparsep=3mm')]
  self.front();scope=None;ordinals={1:'Erstes',2:'Zweites',3:'Drittes',4:'Viertes',5:'Fünftes'}
  for g in groups:
   new=(g['chapter'],g['section'])
   if scope is not None and scope!=new:self.endnotes(scope)
   scope=new
   if g['kind'].endswith('heading'):
    x=self.units[g['id']];de=x['source_text'];ch=g['kind']=='chapter_heading'
    if ch:de=ordinals[g['chapter']]+' Kapitel. '+de
    self.heading(x['translation'],de,ch,(x.get('reviewed_printed_pages') or x['printed_pages'])[0],x['id'])
   else:
    self.pair(self.components(g['components'],'zh'),self.components(g['components'],'de'));self.editorial(g['components'])
  if scope is not None:self.endnotes(scope)
  self.close();self.out.append(r'\end{document}')
  for lang in (['zh','de'] if self.bi else [self.mode]):assert self.references[lang]==set(self.note_map),(lang,'note set')
  return '\n'.join(self.out)

def main():
 d=json.loads((R/'reading_projection.json').read_text(encoding='utf-8'))
 assert d['canonical_sha256']==sha(R/'translation_units.jsonl') and d['front_matter_sha256']==sha(R/'front_matter.json')
 prototype='--prototype' in sys.argv;modes=['bilingual'] if prototype else ['zh','de','bilingual'];report={}
 for mode in modes:
  renderer=Renderer(d,mode,prototype);tex=renderer.render();stem='rickert_gegenstand_'+('prototype' if prototype else mode);path=O/(stem+'.tex');path.write_text(tex,encoding='utf-8')
  report[mode]=dict(tex=str(path),tex_sha256=sha(path),source_page_marks=len(renderer.pages),notes=len(renderer.note_map))
  if '--compile' in sys.argv:
   for passno in [1,2]:
    cmd=['xelatex','-interaction=nonstopmode','-halt-on-error',path.name];p=subprocess.run(cmd,cwd=O,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (R/f'compile_{stem}_{passno}.log').write_bytes(p.stdout)
    if p.returncode:print(p.stdout.decode('utf-8',errors='replace')[-2500:]);raise SystemExit(p.returncode)
   report[mode]['pdf_sha256']=sha(O/(stem+'.pdf'));print(stem,'compiled',flush=True)
 template=R.parents[3]/'Philosophy/Gesammelte Schriften. I/work/review/build_reading_editions.py'
 reference=dict(path=str(template),sha256=sha(template),zh='A4 11pt Times New Roman / SimSun, 25mm margins',de_bilingual='A4 10pt, inner20/outer23/top21/bottom23mm,8mm columns; source S. in margins') if template.exists() else json.loads((R/'template_reference.json').read_text(encoding='utf-8'))
 manifest=dict(canonical_sha256=d['canonical_sha256'],front_matter_sha256=d['front_matter_sha256'],prototype=prototype,status='compiled_pending_render_and_text_checks' if '--compile' in sys.argv else 'TeX_generated',template=reference,editions=report)
 dump(R/('prototype_build_manifest.json' if prototype else 'edition_build_manifest.json'),manifest)
if __name__=='__main__':main()
