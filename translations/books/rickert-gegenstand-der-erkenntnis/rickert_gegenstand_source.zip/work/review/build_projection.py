"""Build lossless reading groups and explicit runs from reviewed canonical data.

No source/translation repair occurs here. All renderers consume this projection.
"""
from pathlib import Path
from collections import defaultdict,Counter
import json,re,hashlib
R=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,o):p.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def annotate(unit,lang,placements):
    field='source_text' if lang=='de' else 'translation';s=unit[field]
    spans=[];inserts=defaultdict(list)
    for p in placements:
        q=p['source_quote' if lang=='de' else 'translation_quote'];assert s.count(q)==1,(unit['id'],q)
        inserts[s.index(q)+len(q)].append(dict(type='note_ref',note_id=p['note_id']))
    for v in unit.get('verse_quotes',[]):
        q=v['source_quote' if lang=='de' else 'translation_quote'];assert s.count(q)==1,(unit['id'],'verse')
        spans.append((s.index(q),s.index(q)+len(q),dict(type='verse',text=q,lines=v['source_lines' if lang=='de' else 'translation_lines'])))
    if lang=='de':
        for e in unit.get('source_emphasis',[]):
            if isinstance(e,str):
                matches=list(re.finditer(r'(?<!\w)'+re.escape(e)+r'(?!\w)',s));assert matches,(unit['id'],e)
                spans.extend((m.start(),m.end(),dict(type='emphasis',text=m[0])) for m in matches)
            else:
                q=e['source_quote'];assert s.count(q)==1,(unit['id'],q)
                t=e['emphasized_part'];assert q.count(t)==1
                start=s.index(q)+q.index(t);spans.append((start,start+len(t),dict(type='emphasis',text=t)))
    spans.sort();assert all(a[1]<=b[0] for a,b in zip(spans,spans[1:])),unit['id']
    replacements={a:(b,t) for a,b,t in spans};out=[];pos=0
    while pos<=len(s):
        out.extend(inserts.get(pos,[]))
        if pos==len(s):break
        if pos in replacements:
            end,token=replacements[pos];assert not any(pos<k<end for k in inserts),(unit['id'],'nested note')
            out.append(token);pos=end;continue
        ends=[k for k in list(inserts)+list(replacements)+[len(s)] if k>pos]
        end=min(ends);out.append(dict(type='text',text=s[pos:end]));pos=end
    assert ''.join(t.get('text','') for t in out)==s,(unit['id'],'lossless')
    return out

def main():
    cp=json.loads((R/'checkpoint.json').read_text(encoding='utf-8'));assert cp['semantic_review']=='passed' and cp['source_coverage']=='passed'
    u=[json.loads(s) for s in (R/'translation_units.jsonl').read_text(encoding='utf-8').splitlines()];by={x['id']:x for x in u}
    f=json.loads((R/'front_matter.json').read_text(encoding='utf-8'));pl=json.loads((R/'note_placement.json').read_text(encoding='utf-8'))
    pp=defaultdict(list)
    for p in pl:pp[p['unit_id']].append(p)
    def component(x):return dict(unit_id=x['id'],de_runs=annotate(x,'de',pp[x['id']]),zh_runs=annotate(x,'zh',pp[x['id']]),
        source_joiner=x.get('source_joiner',' '),translation_joiner=x.get('translation_joiner',''),editorial_notes=x.get('editorial_notes',[]))
    groups=[];members=defaultdict(list);reading_section=None;scope_changes=[]
    for x in u:members[x.get('reading_group') or x['id']].append(x)
    for x in u:
        if x['kind']=='chapter_heading':reading_section=None
        elif x['kind']=='section_heading':
            reading_section=re.match(r'^([IVX]+)\.',x['source_text'])[1]
        if x['kind'] in ['note','note_continuation'] or x.get('join_previous'):continue
        components=members[x.get('reading_group') or x['id']]
        assert components[0]['id']==x['id'],x['id']
        if x.get('section')!=reading_section:scope_changes.append(dict(id=x['id'],source_metadata_section=x.get('section'),reading_section=reading_section))
        groups.append(dict(id=x['id'],kind=x['kind'],chapter=x['chapter'],section=reading_section,components=[component(z) for z in components]))
    host_groups={c['unit_id']:g for g in groups for c in g['components']}
    notes=[]
    for n in u:
        if n['kind']!='note':continue
        placement=next(p for p in pl if p['note_id']==n['id'])
        parts=[n]+[x for x in u if x.get('continuation_of')==n['id']]
        # Some historic records specify the reading group rather than continuation_of.
        parts=list({x['id']:x for x in parts+members[n.get('reading_group') or n['id']]}.values())
        page_labels=list(dict.fromkeys(str(p) for z in parts for p in (z.get('reviewed_printed_pages') or [int(m) for m in re.findall(r'⟦p\.(\d+)⟧',z['source_text'])] or z['printed_pages'])))
        host=host_groups[placement['unit_id']]
        notes.append(dict(id=n['id'],number=n.get('reviewed_note_index') or n['note_index'],printed_page=page_labels[0],printed_pages=page_labels,chapter=host['chapter'],section=host['section'],body_unit_id=placement['unit_id'],components=[component(z) for z in parts]))
    fronts=[]
    for i,pf in enumerate(f['prefaces'],1):
        fronts.append(dict(id=f'preface{i}',kind='preface_heading',title_zh=pf['title_zh'],title_de=pf['title_de'],units=[component(x) for x in pf['units']],date_zh=pf['date_zh'],date_de=pf['date_de'],signature_zh=pf.get('signature_zh'),signature_de=pf.get('signature_de')))
    assert len(notes)==184 and sum(len(g['components']) for g in groups)==646
    assert sum(g['kind']=='paragraph' for g in groups)==591
    assert sum(len(n['components']) for n in notes)==185
    refs={lang:[r['note_id'] for g in groups for c in g['components'] for r in c[lang+'_runs'] if r['type']=='note_ref'] for lang in ['zh','de']}
    for lang,ids in refs.items():assert len(ids)==len(set(ids))==184 and set(ids)=={n['id'] for n in notes},lang
    counts=Counter(r['type'] for g in groups for c in g['components'] for lang in ['zh','de'] for r in c[lang+'_runs'])
    epigraphs=[]
    for key,language in [('kant','de'),('plato','el')]:
        e=f['epigraph'][key];x=dict(id='fm-epigraph-'+key,source_text=e[language],translation=e['zh'],source_emphasis=e.get('source_emphasis',[]))
        epigraphs.append(component(x))
    out=dict(canonical_sha256=sha(R/'translation_units.jsonl'),front_matter_sha256=sha(R/'front_matter.json'),groups=groups,notes=notes,front=f,prefaces=fronts,epigraphs=epigraphs)
    dump(R/'reading_projection.json',out)
    dump(R/'reading_projection_check.json',dict(status='passed',canonical_sha256=out['canonical_sha256'],front_matter_sha256=out['front_matter_sha256'],body_paragraph_groups=591,body_components=646,primary_notes=184,note_components=185,preface_paragraphs=13,note_refs_per_language=184,run_counts=dict(counts),lossless='Each annotated component flattens exactly to canonical source/translation; no content repair in renderer.',reading_scope_rule='The actual ordered chapter/section headings determine scope. Old page-based section metadata cannot assign text before a heading to that following section.',source_metadata_scope_overrides=scope_changes))
    print('Projection: 591 body reading paragraphs, 47 headings, 184 notes, 13 preface paragraphs; lossless checks passed.')
if __name__=='__main__':main()
