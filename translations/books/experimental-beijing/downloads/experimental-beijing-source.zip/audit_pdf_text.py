import json,re,unicodedata,hashlib,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent/'delivery'
def norm(s):return ''.join(c for c in unicodedata.normalize('NFKC',s).casefold() if c.isalnum())
def flat(ts):return ''.join(t if isinstance(t,str) else flat(t['children']) if t['type']=='em' else t['id'].split('-')[-1] if t['type']=='note' else ' ' for t in ts)
report={}
reg=json.loads((P/'registration.json').read_text(encoding='utf-8'))
for mode in ['zh','bilingual']:
 pdf=P/f'print/{mode}.pdf';out=P/f'print/{mode}-raw.txt'
 subprocess.run(['pdftotext','-raw',str(pdf),str(out)],check=True)
 clean=[]
 for page in out.read_text(encoding='utf-8').split('\f'):
  lines=page.splitlines()
  lines=[l for l in lines if l.strip() not in ['实验北京','译校阅读稿'] and not ('实验北京' in l and '译校阅读稿' in l)]
  while lines and not lines[-1].strip():lines.pop()
  if lines and re.fullmatch(r'\s*\d+\s*',lines[-1]):lines.pop()
  clean.append('\n'.join(lines))
 text=norm(''.join(clean));checked=0;failed=[]
 for ch in reg['chapters']:
  d=json.loads((P/f"web/{ch['id']}.json").read_text(encoding='utf-8'))
  langs=['zh'] if mode=='zh' or ch['id'] in ['bibliography','index','editorial'] else ['en','zh']
  for row in d['body']:
   for lang in langs:
    target=norm(flat(row.get(lang,[])))
    if target:
     checked+=1
     if target not in text:failed.append(dict(id=row['id'],language=lang,begin=target[:80]))
  for id,n in d['notes'].items():
   for lang in langs:
    target=norm(flat(n[lang]));checked+=1
    if target not in text:failed.append(dict(id=id,language=lang,begin=target[:80]))
 report[mode]=dict(pdf_sha256=hashlib.sha256(pdf.read_bytes()).hexdigest(),checks=checked,passed=checked-len(failed),failed=failed)
(P/'pdf-text-audit.json').write_text(json.dumps(dict(method='Poppler raw text order; NFKC casefold alphanumeric comparison; remove known header lines and final page folio only. Layout extraction reordered mixed-font text so was not used as authoritative sequence.',results=report),ensure_ascii=False,indent=2),encoding='utf-8')
for mode,r in report.items():print(mode,r['checks'],r['passed'],r['failed'][:5])
