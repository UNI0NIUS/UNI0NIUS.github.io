# 原注

## 序言　世俗寓言

〔原书第275页〕

[1] 关于徐悲鸿的生平，见 Andrews and Shen, *The Art of Modern China*, 42, 66–69；Sullivan, *Art and Artists of Twentieth-Century China*, 68–72。

[2] 关于潘玉良的生平，见 *Pan Yuliang meishu zuopin xuanji*, 96–103；Khullar, "Parallel Tracks"；Sullivan, *Art and Artists of Twentieth-Century China*, 38, 203；Sung, *Redefining Female Talent*, 165–249；Xu, "Early 20th-Century Women Painters in Shanghai," 209–10。

[3] 徐悲鸿，"I Am Bewildered," 374。

[4] "Manifesto of the Art Movement Society," 373。

[5] Sullivan, *Art and Artists of Twentieth-Century China*, 84。

[6] Shi, *Hua hun*。

[7] Huang, *Hua hun*。

## 导论　扩展场域中的中国当代艺术

〔原书第275页〕

[1] 中国首次受邀参加威尼斯双年展是在1980年，但官员们要么不熟悉西方的当代艺术观念，要么执意宣扬"人民"艺术的社会主义信息，送去的是剪纸、挂毯等民间艺术。Francesca Dal Lago 在 "Papercuts, Colorful Pictures and Mountains of Shit" 中详述了这段历史；她还曾担任1993年双年展展览 *Passaggio a Oriente*（《东方之旅》）策展人阿基莱·博尼托·奥利瓦的顾问，该展包括中国和日本艺术家。1997年，中国政府送展的是学院风格绘画。

[2] 1999年双年展总监哈拉尔德·塞曼策划了包括这批艺术家在内的展览；见 Szeemann and Lavelli, *La Biennale di Venezia*。

[3] 建立国家馆的首次努力发生在2003年。由于那年夏天非典爆发，中国政府取消了在威尼斯的布展，改为在广东美术馆展出所选作品。关于2003年为2005年威尼斯中国馆奠定基础的过程史，见 Wang, "Officializing the Unofficial"。

[4] Kingston, "Far Pavilions"。

[5] 他多次公开批评，导致2010年被短暂软禁，随后于2011年被拘留三个月。

〔原书第276页〕

[6] 我对这一结合的思考借鉴了波维内利（Povinelli）在新自由主义语境中对晚期自由主义的理论化；见 *Economies of Abandonment*, 1–45。

[7] 关于这一时期官方对艺术的审查，另见 Barmé, *In the Red*, 201–4；Gao, "From Elite to Small Man"；以及 Wu, *Transience* 与 *Exhibiting Experimental Art in China*。

[8] Sassen, *The Global City*。

[9] 王能涛的《颠覆》被用作广东美术馆一场关于艺术与城市主义关系的展览图录封面；见 Zhang, *New Urbanism*。

[10] 其他探讨改革时代中国城市美学意识形态重要性的著作包括 Braester, *Painting the City Red*；以及 Visser, *Cities Surround the Countryside*。

[11] 详见 Wang, *High Culture Fever*。

[12] 我在此借鉴 Claypool 的 "Metadomesticity" 一文。她在文中主张，尹秀珍为社会学家马克·奥热对超现代性的阴郁定义提供了一个充满希望的对照："我所谓的'元家庭性'完全可以负面地设想——我们或可把它视为超现代世界中那些威胁性的、去人性化的模块化非场所的某一面向——但通过尹秀珍的视觉作品，我们可以窥见它如何也拥有重新想象世界的潜能，构建一种积极的过程，让家庭性渗入那些负面的非场所、那些张开大口的'黑洞'，重新赋予它们人的意义。"

[13] 另见 Mao, *Chopsticks*。

[14] 尹秀珍访谈。

[15] Gao, *Fengshou*, 21。

[16] 陈羚羊，艺术家自述。

[17] Lü, *Zhongguo dangdai yishu shi*；Gao, *The Wall*；Wu, *Contemporary Chinese Art*。

[18] 对这一不断增长的学术成果的回顾与反思，见 Hershatter, *Women in China's Long Twentieth Century*，以及 "Disquiet in the House of Gender"。

[19] 我关于政治语法及其在女性主义叙事中之重要性的思考，借鉴了 Hemming, *Why Stories Matter*。

[20] 中文词"流氓"由两个字组成："流"意为流动，"氓"指平民。它意味着一种"局外人"身份，即从家庭、群体或国家关系中脱落、因而具有潜在颠覆性的人。在《共产党宣言》的中译本里，德文词 *lumpenproletariat* 被译为"流氓无产者"。将流氓行为——如帮派斗殴、对妇女的性侵犯、扰乱公共秩序等活动——入罪，被写入1979年《中华人民共和国刑法》的一项条款，后来又用于管制男性之间的性行为。这种对异性恋规范亲属关系之外广泛男性活动的历史焦虑表明，有必要把性别化的男性与女性规范放在一起解构。Dutton, *Streetlife China*, 62–74；Kang, "The Decriminalization and Depathologization of Homosexuality in China"。

〔原书第277页〕

[21] Andrews and Gao, "The Avant-Garde's Challenge to Official Art"。

[22] Wu, *Contemporary Chinese Art*, 5–13。1980年代"文化热"时期，中国美术馆还举办过其他几场重要展览：1985年美国波普艺术人物罗伯特·劳森伯格与法国时装设计师伊夫·圣罗兰的回顾展，以及1988年文化部支持的一场裸体艺术展，后者在十八天内吸引了近二十五万名观众。

[23] 克劳斯（Kraus）批评这种把中国艺术框定为"哥斯拉模式"的做法不能令人满意，"因为它想象出一个既一以贯之又无所不能的中国国家，而记录显示的是一个内部远为分裂、反复无常且低效的政治体。谈到艺术家时，哥斯拉模式也好不了多少，它把艺术家浪漫化为英雄与反叛异见者"（*The Party and the Arty in China*, 143）。他提出了另一种叙述：艺术家为专业地位与保障进行长期斗争。在 "Arrière-pensée on an Avant-Garde" 中，白杰明（Barmé）愤世嫉俗地预言，中国艺术家对西方这种拜物化与市场需求作出的反应，将导致"一种新的定制前卫艺术：随取随用的异见"（82）。

[24] 关于这些海外展览的概览，见 Erickson, "The Reception in the West of Experimental Mainland Chinese Art of the 1990s"。

[25] 在《由内而外》之前，美国已有一些规模较小、焦点更集中的中国当代艺术展，包括 *Painting the Chinese Dream: Chinese Art Thirty Years After the Revolution*（布鲁克林博物馆，1983）；*"I Don't Want to Play Cards with Cézanne" and Other Works: Selections from the Chinese "New Wave" and "Avant-Garde" Art of the Eighties*（帕萨迪纳亚太博物馆，1991）；*Fragmented Memory: The Chinese Avant-Garde in Exile*（哥伦布威克斯纳艺术中心，1993）；以及 *China's New Art, Post-1989*（俄勒冈大学艺术博物馆、韦恩堡艺术博物馆、萨利纳艺术中心、芝加哥文化中心、圣何塞艺术博物馆，1995—1998）。

[26] 例如见 Cheng, "What Would Mao Think?"。

[27] Nochlin, "Why Have There Been No Great Women Artists?"。

[28] Hershatter, Honig, and Rofel, "Reflections on the Fourth World Conference of Women, Beijing and Huairou"；Welland, "What Women Will Have Been"。

[29] Lin, *Yuan nüxing yishu*；Liao, *Zhongguo dangdai yishu zhong de nüxing fangshi*。

[30] Jia, "Preface," 9。

[31] Werner, "The Half of the Sky," 37n3。

[32] Werner, "The Half of the Sky," 37n3。

[33] 与我交谈的一些艺术家贬斥使用毛主义图像等容易使作品被识别为"中国"的符号，认为那是懒惰地迎合外国市场。他们用"符号主义"一词描述这一潮流，但带有反讽意味，含义更接近"商标主义"。

[34] Yao, *In Production Mode*。

[35] 例如见 Abu-Lughod, *Writing Women's Worlds*；Behar and Gordon, *Women Writing Culture*；Tsing, *In the Realm of the Diamond Queen*；以及 Visweswaran, *Fictions of Feminist Ethnography*。Haraway 的 "Situated Knowledge" 影响了人类学中的这一女性主义转向。

〔原书第278页〕

[36] Faier, *Intimate Encounters*；Faier and Rofel, "Ethnographies of Encounter"。

[37] Krauss, "Sculpture in the Expanded Field," 32。

[38] Krauss, "Sculpture in the Expanded Field," 33。

[39] Krauss, "Sculpture in the Expanded Field," 34。

[40] 当代中国的艺术家使用的媒介比"当代艺术"这一解释所代表的更为广泛。书法家和水墨画家在当下继续实践这些"传统"形式——一些人认为它们更具中国性——因此也可被视为当代艺术家。然而，除了徐冰、谷文达等少数引人注目的跨界例外，他们往往被归入"新水墨画"或"国画"等类别，被理解为更牢固地扎根于中国及其离散社群。人们付出大量努力区分"当代"与"传统"形式，尽管艺术家常常两者兼作。"contemporary Chinese art"（当代中国的艺术）这一说法有强调艺术之中国性的风险，而我更感兴趣的是分析这种区分，而非将其物化。

[41] 这些杂志包括《艺术世界》（*Yishu shijie*）、*Xiandai yishu*（现代艺术，编者译为 Contemporary Art）、*Yishu dangdai*（艺术当代，编者译为 Art China）和《新潮》（*Xin chao*，编者译为 Next Wave）等。许多其他关于当代城市生活的通俗出版物也设有当代艺术专栏。

[42] Tsing, *Friction*。

[43] Said, *Orientalism*, 25。

[44] Danto, "The Artworld," 580。

[45] Becker, *Art Worlds*。

[46] Bourdieu, *The Field of Cultural Production*。

[47] Gell, *Art and Agency*。

[48] Tsing, "The Global Situation"。

[49] Clifford, *Routes*, 69。

[50] Nochlin, *Women, Art, and Power*；Parker and Pollock, *Old Mistresses*；Pollock, *Differencing the Canon*。

[51] Liu, Karl, and Ko, *The Birth of Chinese Feminism*, 53–71。中国历史学者常称她为何震，但她在发表作品时署名何殷震，将母姓纳入复姓。她现存著作最初都发表于倾向无政府主义的女性主义刊物《天义报》，该刊由何殷震在东京编辑。1908年，该刊还发表了《共产党宣言》的第一个中文译本。

[52] 关于"男女"作为一个分析范畴的细致讨论，见 Liu, Karl, and Ko, *Birth of Chinese Feminism* 导言，1–26。

[53] Welland, *Cruel/Loving Bodies* 与 *Cruel/Loving Bodies 2*。

[54] 这一女性主义艺术表述产生于我与 Sonal Khullar 的合作，我们为我们共同组织的国际会议"女性主义艺术的新地理：中国、亚洲与世界"撰写了开幕致辞；会议于2012年11月在华盛顿大学举行。史书美（Shu-mei Shih）在会议主题演讲中也以责任伦理来讨论女性主义艺术，其中"女性主义成为媒介，而不再仅仅是内容"。

〔原书第279页〕

[55] Sandoval, *Methodology of the Oppressed*, 110。

[56] Sandoval, *Methodology of the Oppressed*, 111。

[57] Judge, *The Precious Raft of History*, 87–95。

[58] Bateson, "Toward a Theory of Schizophrenia," 206–12。

[59] Jamieson, *Beyond the Double Bind*, 3–21。

[60] Khullar, *Worldly Affiliations*。

[61] Chen and Araeen, "A Conversation," 24。

[62] Heidegger, "The Origin of the Work of Art," 171。

[63] Taylor, *The Archive and the Repertoire*。

[64] Spivak, "Three Women's Texts and a Critique of Imperialism," 260；Heidegger, "The Origin of the Work of Art," 171。

[65] Spivak, "Three Women's Texts and a Critique of Imperialism," 243。

[66] Karl, *Staging the World*。

[67] 史书美在《现代的诱惑》（*The Lure of the Modern*）这部研究中国文学现代主义中半殖民文化政治的著作中，将半殖民主义定义为"多重帝国主义存在在中国产生的具体效果，及其碎片化的殖民地理（主要限于沿海城市）与控制，以及由此形成的社会与文化构形"（31）。

[68] 然而，这种关于殖民屈辱的民族叙事本身也可能服务于帝国主义倾向，因为它选择性地忽视中国国家在有争议的少数民族地区所进行的汉族霸权侵入。

[69] Hevia, "Looting Beijing: 1860, 1900," 198。

[70] 何伟亚（Hevia）指出，"loot"一词与英帝国扩张有着密切关联；它于18世纪从印地语经梵语进入英语（印地语 *lut, lutna*，源自梵语 *lunt(h)-*，意为抢劫）。

[71] 整个19世纪，中国和日本的图像作品都以"版画与素描"而非"东方物品"的名义进入大英博物馆目录。柯律格（Craig Clunas）在 "China in Britain" 中评论说，在中国陶瓷与古物成为"中国艺术"稳固支柱之前的这个过渡时刻，如今看来在分类上不合逻辑："在中国陶瓷至少在行政上还与独木舟和武器同类的时候，一幅广重版画与一幅伦勃朗版画也是同类"（45）。

[72] Clunas, "China in Britain," 47。

[73] 黛博拉·普尔（Deborah Poole）在 *Vision, Race, and Modernity* 中考察了这类摄影图像借以塑造现代"种族差异"观念的"视觉经济"。

[74] 这张明信片由比利时公司 Nels 制作，附有以下说明文字："年轻女孩的脚用布带缠紧，以获得'小脚'，这是中国女性美的要素之一。"在完整的原版明信片中（《北京青年报》文章刊出的是裁剪版），女子的照片与一张"中国乞丐"照片并置；后者是一位衣衫褴褛的老人，拄着手杖，端着一只乞讨碗。这种民族志式描绘作为世界各地寄送的流行明信片生产的一部分，把中国传统女性习俗等同于贫穷与衰败。两张明信片均见 Chen, *Jiu meng zhong jing*, 183–84。

〔原书第280页〕

[75] Chen, "Sheng zhuang de jixing"。

[76] Barlow, *The Question of Women in Chinese Feminism*。

[77] Andrews, *Painters and Politics in the People's Republic of China*, 215–16。1960年，这幅画出现在两本杂志封面上：8月号 *China Reconstructs* 和9月号 *Meishu*（《美术》）。

[78] Barlow, *The Question of Women in Chinese Feminism*。

[79] Engels, "Socialism: Utopian and Scientific," 690。

[80] Andrews, "Women Artists in Twentieth-Century China"；Zheng, "The Shanghai Fine Arts College: Art Education and Modern Women Artists in the 1920s and 1930s"。

[81] 1968年后的法国知识分子与文化批评家，是这种西方对毛泽东时代艺术态度的显著例外。例如见 *Cahiers du Cinema* 专号，236–37（1972年3—4月）。

[82] Guilbaut, *How New York Stole the Idea of Modern Art*。在 "Contemporary Asian Art and Its Western Reception" 中，Clarke 也指出，在美国流行的艺术史教科书中，对中国艺术的语境化仍存在一种殖民式世界营造的结构性延续。他对流行教材 *Gardner's Art through the Ages* 的分析表明，其作者如何"把中国艺术描绘成静止而同质的"（240）。

[83] Wu and Phillips, *Between Past and Future*, 203。

[84] Barlow, *The Question of Women in Chinese Feminism*。

[85] Barlow, *The Question of Women in Chinese Feminism*, 253–54。

[86] Dai, "A Scene in the Fog," 72。

## 第一章　先锋北京

〔原书第280页〕

[1] 亚洲艺术文献库的在线收藏包含这张邀请函的数字副本，www.aaa.org.hk（2017年访问）。

[2] Liu, *Translingual Practice*。

[3] Gao, *Total Modernity and the Avant-Garde*, 166。

[4] "实验"（shiyan）与"当代"（dangdai）等竞争性术语最终变得更加常见。

[5] 这份在天津出版的期刊于1999年至2002年间发行。

[6] 巫鸿在同名著作中提出了"再造北京"的观念，该书聚焦天安门广场作为政治空间与象征体系转型的场所。

[7] Benjamin, "N: On the Theory of Knowledge, Theory of Progress," 462。我的蒙太奇方法借鉴了本雅明拱廊计划的"N"卷，他在其中为整部著作发展了理论与方法框架。

[8] Dewar, "Beijing Report"。

[9] Wang, "Culture as Leisure and Culture as Capital," 88–89。

〔原书第281页〕

[10] Wang, "Culture as Leisure and Culture as Capital," 88。

[11] 1990年代中期城市规划者主张北京作为中国文化中心的首要地位，这与20世纪初把北京建设为现代大都市、通过展示中国传统而赢得世界声望的努力之间存在相似之处。在 "Defining Beiping" 中，董玥（Madeleine Dong）详述了1928年中国首都从北京迁往南京后，城市规划者如何寻求发展一种自给自足的经济。他们推动了1933年把北平变成旅游城市的计划，以及1935年另一项以北平为中心"建设中国本位文化"的计划，后者被视为"民族自信心的体现"。

[12] Anagnost, "The Corporeal Politics of Quality (Suzhi)"。她与其他研究中国城乡问题的民族志学者记录了这些话语与物质变迁的深刻影响：农村公民自称"死脑筋"，把乡村称为"死亡之地"。Liu, *In One's Own Shadow*；以及 Yan, "Spectralization of the Rural"。

[13] 正如张鹂在分析官方关于北京农民工政策时于 *Strangers in the City* 中所论，国家通过新的治理术形式施加影响。塑造公民行为的微观实践通过家庭关系、学校和市场等社会机构发生，因此国家与资本都不能被视为彼此外在的东西。

[14] Wang, "Culture as Leisure and Culture as Capital," 71–72。

[15] Shu, *Zhongguo yingxiang huihua*, 68。

[16] 毛泽东的宣告紧随赫鲁晓夫的声明：苏联工业产量将在十五年内超过美国。1959年，赫鲁晓夫与尼克松在莫斯科索科利尼基公园美国国家展览会上的激烈交锋后来被称为"厨房辩论"。Oldenziel and Zachmann, *Cold War Kitchen*。

[17] 这类画作中最著名的是董希文的巨幅《开国大典》，原绘于1952—1953年，随后在1955、1967、1972和1980年因人物被清洗与平反而修改、重绘。

[18] 叶永青访谈。

[19] Barlow, *The Question of Women in Chinese Feminism*, 213。

[20] Poggioli, *The Theory of the Avant-Garde*, 95。

[21] Bürger, *Theory of the Avant-Garde*。

[22] Gao, *Total Modernity and the Avant-Garde*, 1–4。

[23] 林文铮，"Shoudu meishu zhanlanhui zhi yiyi," 462。作为海外艺术运动的关键成员，林文铮刚从法国留学归国；见 Tang, *Origins of the Chinese Avant-Garde*, 36。

[24] Tang, *Origins of the Chinese Avant-Garde*, 59。

[25] "前卫"（qianwei）虽然与"先锋"（xianfeng）语义相近，却沿着不同的华语轨迹发展。1990年代，随着香港与台湾的艺术及理论写作进入大陆，"前卫"一词在中华人民共和国获得更广泛的流通。

[26] Liu, *Translingual Practice*, 189–90。

[27] Krauss, *The Originality of the Avant-Garde and Other Modernist Myths*, 157。

〔原书第282页〕

[28] 凡·高临摹歌川广重（Ando Hiroshige）日本木刻版画的作品，是这类借用最著名的例子之一。尽管有充分文献记录，这种影响通常不被叙述为他因袭模仿的证据，而被叙述为他为西方绘画开辟的创新方向。

[29] Hernández-Reguant, "Copyrighting Che," 9。

[30] 毛泽东，《毛泽东著作选读》，231。

[31] 毛泽东，《毛泽东著作选读》，403–4。

[32] Kraus, *Brushes with Power*, 96–108。

[33] 王庆松访谈。

[34] 几位在中国和海外代理中国当代艺术的画廊主，曾以随意的方式谈到教育艺术家理解市场惯例的问题。

[35] 这位发言者是"收藏亚洲当代艺术——赞助与艺术市场"专题讨论的成员；该讨论属于2002年11月8—9日在纽约亚洲协会举行的"展望：亚洲当代艺术对话"会议。

[36] Gao, "Foreword," viii。

[37] Xiao, *Dialogue*, 42。

[38] Zheng, "The Shanghai Fine Arts College"。

[39] Zheng, "Private Art Tutorial Schools in Shanghai"。

[40] Andrews and Shen, *The Art of Modern China*, 66–67。

[41] 这一粗略分期取自 Chow, *The May Fourth Movement*。

[42] 除了北京的中央美术学院和杭州的中国美术学院，进入美术院校"八大"的还有四川美术学院（重庆）、西安美术学院、湖北美术学院（武汉）、广州美术学院、天津美术学院和鲁迅美术学院（最初创办于延安，后迁至沈阳和大连）。

[43] 乔尔乔·瓦萨里（Giorgio Vasari）是一位画家和作家，以收集文艺复兴艺术家传记的《艺苑名人传》闻名；他创办了迪塞尼奥学院，要把艺术家的地位从工匠提升为由内在构想驱动的专业创造者。

[44] 在习近平领导下，党的领导层于2014年12月宣布一项旨在影响当代艺术生产的新计划，复兴了把艺术家送到乡下的做法。Qin, "China's Artists to Be Taught 'Correct View' in New Plan"。

[45] 张鸥访谈。

[46] 这张1960年照片的构图与题材，与欧洲描绘学院艺术理想的图像有惊人的相似：受过教育的专业人士聚集在一起研究裸体，以此作为启蒙理性的表征。例如，约翰·佐法尼（Johann Zoffany）的《皇家艺术学院院士》（1772）描绘了学院成员在伦敦河岸街写生教室的石膏像之间。他们的注意力集中在画面中央偏右一名男性裸体模特身上。正如帕克与波洛克在 *Old Mistresses*, 87–90 中所指出的，佐法尼的画作也记录了性别区隔。皇家艺术学院曾有两名女性成员，二人都是成就卓著的画家，其中一人还是创院院士，却不被允许在写生教室研究裸体模特。为了准确记录学院成员，佐法尼把这两位女性画成挂在模特身后墙上的两幅肖像。

〔原书第283页〕

[47] 前中央美术学院学生提供了这件事的细节。Tsao, "The Birth of the Goddess of Democracy" 是英文中对这座雕塑创作过程最完整的叙述。

[48] Barboza, "Schooling the Artists' Republic of China"。

[49] Anagnost, "The Corporeal Politics of Quality (Suzhi)" 追踪了1980年代末以来中国"素质"话语如何反映经济改革中价值与身体之间变化的关系。从制度性运动到通俗自助手册的各种技术，都劝诫公民通过提高自身"素质"来提高民族素质。阿纳格诺斯特主张，构成"有素质的人"的区分实践，依赖于新的消费形式以及中产阶级向上社会流动的欲望。Woronov 在 "The Eye of the Chicken" 中专门考察素质教育，论证北京的农民工子女如何被教育去认识自己在新空间与社会等级中的位置——相对于城市居民而言是落后的。

[50] 在讨论提高孩子素质时，父母们热切地采纳最细微的做法。一位母亲向我解释说，美国孩子不像中国孩子那样仰睡，而是侧睡，这会使他们的脸更瘦、更好看。

[51] 关于这些农民工聚居区的详细民族志叙述，见 Zhang, *Strangers in the City*。

[52] 吕澎在《中国当代艺术史》中称他们为"盲流艺术家"（mangliu yishujia），200。关于"盲流"的术语讨论，见 Guang, "Rural Taste, Urban Fashions"。

[53] Zhao and Shi, *We Are Here*。

[54] 关于东村生活的摄影记录，见艺术家邢丹文的 *Wo-Men: A Personal Diary of Chinese Avant-Garde Art in the 1990s*。

[55] 通州区网站，www.bjtz.cn/tongzhou.html（2000年访问）。关于描述通州艺术家社区的文章，见 Le, "Jingcheng liulang yishujia de xingfu shenghuo"；以及 Yang, "The Tongzhou Artists Community"。

[56] 见 Sasaki 项目页面，www.sasaki.com（2014年访问）。

[57] Wang, "Songzhuang yishujia de cunzai fangshi," 69。

[58] Wang, "Songzhuang yishujia de cunzai fangshi," 72。

[59] 工人们反复协商更高工资，才愿意做如此屈辱的事。拒绝脱衣或只脱一部分的人得到较低报酬。

[60] Chen, "Bu neng yi yishu de mingyi na qiongren kaixin," 9。

[61] 王南和（化名）访谈。

[62] Coleman, "Flux," 7。

[63] 张大力访谈。

[64] Du Bois, *The Souls of Black Folk*, 11。

[65] Du Bois, *The Souls of Black Folk*, 10。

〔原书第284页〕

[66] Shao, "Exhibiting the Modern"。

[67] 朱加早期的一件录像作品《永远》（1994）就是用类似方法拍摄的。他把摄像机绑在一辆自行车拖车的后轮上，骑车穿过北京。摄像机记录车轮的循环运动，在红绿灯前停下，并随机从不同角度捕捉城市景象。《永远》让关于一个地方的知识陷入后现代的旋转，扰乱了朱加在官方图像管理中的日常工作，也令人想起老舍的经典小说《骆驼祥子》；这部带有左翼倾向、批判个人主义的作品自1937年起连载。小说主人公拉着形形色色的乘客穿过北京——"肮脏的、美丽的、衰败的、活泼的、混乱的、安静的、迷人的"——为生存与尊严而挣扎。Lao, *Rickshaw Boy*, 290。

[68] 朱加访谈。

[69] 范迪安是1995年中国艺术博览会的总监，那一年博览会从广州迁至北京。

[70] 在图录中，艾未未与联合策展人冯博一摆出挑衅姿态："在今天的艺术中，'另类'位置意味着挑战和批判权力话语与流行惯例。它以不合作、不妥协的方式，自觉地抵抗同化与庸俗化的威胁。" Ai and Feng, *Fuck Off*, 9。

[71] Merewether, "The Spectre of Being Human," 58。

[72] 《人民日报》上 Sun 的 "Shenghuo zai cishi" 等文章报道说，这场展览"让人们看到中国当代艺术是创新的艺术"（chuangxin de yishu）。

[73] 这里把"民间"（minjian）用作与"官方"（guanfang）对立，与毛泽东时代指涉革命农村农民民俗传统的"民间"不同。他们把"民间"当作"非官方"的同义词，用来描述《不合作方式》等未获国家批准举办的展览，以及艺术家或策展人自费印刷、没有书号、无法在书店正式销售的图录。

[74] 这个建筑群在英文中称为 Grand MOMA，中文名则是"当代MOMA"。

[75] 跨页版面详细介绍了纽约洛克菲勒中心与时代华纳中心、东京六本木新城以及巴黎拉德芳斯区。

[76] Dangdai zhiye, *Dangdai moma by Steven Holl Architects*。

[77] 《舞蹈》（*La Danse*）是纽约现代艺术博物馆永久收藏的一部分。

[78] Tweedie, "Delirious Cities and Their Cinema," 386–87。

## 第二章　展示北京

〔原书第284页〕

[1] 见吴文光《和民工跳舞》最后的表演场景。哀歌中的"光棍"（guanggun）指没有子嗣的单身男子。关于光棍作为一个社会阶层的历史意义，另见 Mann, *Gender and Sexuality in Modern Chinese History*, 1–23。

[2] Yang, "Yu mingong yiqi wudao"；Xiao, "Yi chang nanyi dingyi de biaoyan"；Xiao, "Yu ling yi zhong shenti gongwu"；Cui, "Yici xing youxi"；Yin, "Yu mingong yiqi wudao."

〔原书第285页〕

[3] Yin, "Yu mingong," 5。

[4] Yang, "Yu mingong."

[5] 这场演出及吴文光关于它的录像纪录片中文标题为《和民工跳舞》，英文常译为 *Dance with Farm Workers*。在我看来，"farm worker"无法传达"民工"通常指在城市非正规体力劳动群体中工作的农村移民这一用法。因此我把标题译为 *Dancing with Mingong*。

[6] Rofel, *Desiring China*, 3。

[7] Abramson, "Urban Planning in China"；Zhang and Fang, "Is History Repeating Itself?"

[8] Wu, *Exhibiting Experimental Art in China*。展览《取消》（Cancelled，2000年11月19日—2001年1月7日）由芝加哥大学艺术史学者巫鸿策划，重新布置了冷林原在北京策划、却在开幕前一天被官员取消的一场群展。这一重新展出意在提出关于艺术自由、审查制度以及实验艺术与社会整体关系的问题。

[9] Dal Lago et al., "Space and Public"；Chau, "An Awful Mark."

[10] 一份以描述为主的远洋天地项目记述，最初发表于由 susan pui san lok 编辑的 *Journal of Visual Culture* 专号：Welland, "Ocean Paradise."

[11] Xie, "Beijing shi wei jiu fang gaizao de duo mubiao fenjie moshi."

[12] 关于北京建成环境的历史，见 Wu, *Remaking Beijing*。

[13] 邢丹文（见第一章）和陆昊等艺术家的作品探索比例模型的社会生活。陆昊的《北京万花筒》（2000—2001）是一件按比例缩小的微型模型，呈现千禧年之交北京传统城墙内的建筑；陆昊把它架在十二张大方桌上，观众可在桌间穿行。

[14] 例如，北京气派大道的选址并不总能促进交通流动或本地商业。同样，2008年奥林匹克公园被战略性地置于传统风水的南北中轴线上，使一条轴线穿过紫禁城直抵新的体育与展览建筑群。Abramson, "Urban Planning in China," 199。

[15] Buck-Morss, *Dreamworld and Catastrophe*, xi。

[16] 在北京历代城貌的第一段动画中，观众体验了从上方飞过、继而俯冲进入重要历史遗址的过程，例如天安门，两旁排列着计算机模拟的皇家卫兵。

[17] 这些统计数字来自管理博物馆的北京市文物局，包括国家、市、区、县和私人各行政级别的博物馆。取自《中国统计年鉴》、可获得的1999—2008十年全国数据显示，博物馆总数从1364座增至1893座，增长39%。1949年文物局初建时，只登记和管理全国21座博物馆。博物馆作为中国现代性标志的迅速发展，也体现在上海于2010年主办国际博物馆协会第22届大会，同年上海还举办了中国首届世界博览会。

〔原书第286页〕

[18] Kirshenblatt-Gimblett, *Destination Culture*, 51, 54。

[19] Ivy, *Discourses of the Vanishing*。

[20] Davis, "From Welfare Benefit to Capitalized Asset."

[21] Logan and Molotch, *Urban Fortunes*, 13。

[22] Logan and Molotch, *Urban Fortunes*, 13。

[23] Zhang and Fang, "Is History Repeating Itself?"

[24] Zhang, "Urban Development and a Socialist Pro-Growth Coalition in Shanghai"；Zhang, "Contesting Spatial Modernity in Late-Socialist China."

[25] 在她关于城市更新的民族志研究中，张鹂（Li Zhang）在 "Contesting Spatial Modernity in Late-Socialist China" 中主张，民众反对的形式即使被官方边缘化，也呈现出关于城市生活的另类愿景。

[26] Gao, "From Elite to Small Man," 161。

[27] 在对私人住宅作为表演新中产阶级身份空间的研究中，张鹂强调城市再开发中阶级主体性与空间分层的交织："中国中产阶级主体形成的核心，是基于品味、判断力以及通过消费实践获取文化资本，培养一种独特的'文化氛围'。" Zhang, "Private Homes, Distinct Lifestyles," 25。

[28] Li, "Qingnian yu nongcun," 149。

[29] Wu, *Remaking Beijing*, 28。

[30] "Talking of Women's Liberation," 13。

[31] "Beijing jing mian fangzhi jituan youxian zeren gongsi zongjingli Gu Weida fangtan"。

[32] Newman，私人交流。

[33] 其他标语写道："我们乐于忙碌。我们乐于休闲。我们热爱工作。我们做自己想做的事。我们喜欢做自己。青春人间，我们的生活。"

[34] Xu Qian 访谈。

[35] Li and Xu, *Yuanyang lixiang*, i–iii。

[36] Xu Qian 访谈。

[37] Chang, "East Modern Art Center," 139。

[38] 宋东访谈。

[39] 宋东原本想让民工挖开沙堆，把架在上面的建筑模型埋起来。cosred 的代表不允许，因为他们不想让模型被毁坏。

[40] 宋东访谈；关于该项目的完整记述另见 Yin, "Yu mingong yiqi wudao."

[41] Wu, *He mingong tiaowu*。这部纪录片聚焦文慧编排的舞蹈排练与演出，跟踪舞者在公演前一周逐日的进展。2002至2003年间，它在国际电影节（加拿大、英国、德国、新西兰和韩国）放映，2004年又作为纽约现代艺术博物馆电影系列的一部分在纽约放映。

[42] Wei Lai 访谈。

〔原书第287页〕

[43] 其中一位外国舞者是受文慧邀请参加表演的美国公民，当时为 CNN 在北京工作。她解释说，这套编舞既反映了与场地的身体互动，也反映了两个以身体为职业的群体——建筑工人与舞者——之间的合作。她描述自己在排练中与空间的即兴互动："我在建筑里爬行、翻滚、悬挂、攀附，凡是能塞进去、抱住、裹住、甩开、滚进去或滚出来的部分，我都试过了。" Friedman，电子邮件。

[44] 在 "Suku and the Self-Valorization of Chinese Women Workers" 及相关研究中，Shuxuan Zhou 记录了女性国企工人如何以高于男性的比例下岗、更难获得再就业机会，并以养老金或其他福利形式获得更少补偿。

[45] Yang, "Yu mingong yiqi wudao"；Xiao, "Yi chang nanyi dingyi de biaoyan"；Xiao, "Yu ling yi zhong shenti gongwu"；Cui, "Yici xing youxi"；Yin, "Yu mingong yiqi wudao."

[46] Xu Qian 访谈。

[47] 宋东访谈。

[48] 与作者的匿名私人交流，北京，2002年7月。

[49] Wei Lai 访谈。

[50] Li and Xu, *Yuanyang lixiang*, 82。

[51] 这次活动是王能涛此前在自家工作室举办聚会的延伸；这些聚会把不同背景的人聚在一起，模糊日常仪式与艺术生产之间的界线。

[52] 王能涛对海报作了数码修改，改写标语以反映21世纪中国的全球抱负。第一张是哈琼文1965年设计的，原句为："做一颗红色的种子：到祖国最需要的地方去生根、发芽、开花、结果！"第二张是 Lu Xinchen 与 Shen Lin 1958年设计的，原句宣称："十五年内我们一定要超过英国。"上面还列出了1972年钢、煤和电力的生产指标。

[53] 开发细节来自远洋（Sino-Ocean）网站，www.sinooceanland.com（2017年9月访问）。

[54] 1960年代末，领导层把原称718联合厂的企业拆分为若干分厂。其中798厂规模最大，这个数字最终与艺术区联系在一起。附近的草场地原是一个农业人民公社，也开始吸引艺术家，在798之后不久便出现在文化地图上。

[55] 郑阔的影片《798站》记录了这场斗争。

[56] 另见第一章的相关讨论。这些艺术家包括苍鑫、高氏兄弟、梁硕、宋东、王晋、王庆松、邢丹文、张大力和张念。

[57] 2002年，我与独立策展人张朝晖一起，就"民工艺术"潮流访谈了其中七位艺术家，以及一位曾在他们某个项目中担任模特和艺术家助手的民工。

〔原书第288页〕

[58] "Helping Migrants Belong in Cities."

[59] 这个私有住宅小区的汉字名为"苹果"（pingguo），英文名却是 Pingod。它与苹果电脑公司没有任何关系。

[60] Chang, "Pingod (Apple) Sales Center/Art Museum," 133。

[61] Wu, *Privatising Culture*。

[62] 张子康访谈。

[63] Zhang, "Contesting Spatial Modernity in Late-Socialist China."

[64] 2007年8月，我的伴侣与我在三环路堵车时注意到这处涂鸦。我们下了出租车，走到那栋楼前，与坐在楼前围墙上的人交谈。第二天我们回去补拍照片时，抗议标语已经被覆盖了。照片见 Tweedie, "Delirious Cities and Their Cinema."

[65] Chau, "An Awful Mark."

[66] Zhang, "Urban Development and a Socialist Pro-Growth Coalition in Shanghai"；Zhang, "Contesting Spatial Modernity in Late-Socialist China."

[67] Zhang and Fang, "Is History Repeating Itself?" 295。

## 第三章　围城

〔原书第288页〕

[1] Shi, "Wei Cheng: From an Elite Novel to a Popular Metaphor."

[2] 钱锺书引用的法国谚语是："Le mariage est comme une forteresse assiégée; / ceux qui sont dehors veulent y entrer, et / ceux qui sont dedans veulent en sortir."（婚姻就像一座被围困的城堡；城外的人想进去，城里的人想出来。）

[3] 乔纳森·斯彭斯（Jonathan Spence）在2004年英文版《围城》重印前言中指出，在钱锺书这部小说之前，一位中国诗人曾用"围城"一词描述第一次鸦片战争后被英军围困的南京，为它注入了一段耻辱与国族蒙羞的历史。Qian, *Fortress Besieged*, ix。

[4] Narayan, "How Native Is a 'Native' Anthropologist?" 弗雷德·迈尔斯（Fred Myers）特别谈到他在艺术交流这一跨文化空间中的民族志经验："在这些条件下工作对人类学家来说很困难，尤其是因为民族志知识本身的位置发生了奇异的改变——这种知识不可避免地成为它所再现之物的一部分。" *Painting Culture*, 8。

[5] Shih, "Towards an Ethics of Transnational Encounter."

[6] 关于分析术语"男女"（nannü）的解释，见导论；该术语由20世纪初无政府主义女性主义者何殷震提出。我沿用她著作的英译者做法，保留这个中文术语，而不以近似的英文形容词"gendered"取代。他们写道："把男女逐字直译为两个或数个英文词——nan 即'男人'，nü 即'女人'，合为'man and woman'或'male/female'——同样不能令人满意[就像'gender'一样]，因为直译可能违背何殷震的理论计划；她把男女视为单一的、兼具名词与形容词功能的概念机制，是一切父权抽象与区分标记的基础"（原书斜体）。Liu, Karl, and Ko, eds., *The Birth of Chinese Feminism*, 11。

[7] 巫鸿在 "A Chinese Dream" 中的分析同样指出了王晋作品中艺术合作与外包之间的微妙界限：王晋雇佣以精细针线活闻名的农村妇女制作他设计的艺术品。巫鸿描述了艺术身份如何作为交易的一部分被协商，以及当艺术物品进入高级艺术商业拍卖厅时，这种共同作者身份如何消失。

[8] McDougall, *Mao Zedong's "Talks at the Yan'an Conference on Literature and Art,"* 68。

[9] Liu, *Translingual Practice*, 1。

[10] 从1990年代开始，国际双年展开始激增，尤其是在西方之外；双年展成为国家发展的象征，类似于20世纪后半叶的"大坝"。

[11] Halbreich, "Foreword," 4。

[12] Vergne et al., "Just How Did Latitudes Become Forms?" 134。

[13] Liu, *Translingual Practice*, 26。

[14] Liu, *Translingual Practice*, 305。

[15] Liu, *Translingual Practice*, 236。

[16] Goethe and Eckermann, *Conversations with Eckermann*, 18。

[17] Liu, *Translingual Practice*, 188。

[18] de Guzman，电子邮件。

[19] de Guzman, "Something about the Bay."

[20] 关于围绕这家历史悠久的"市场街南"旅馆形成的丰富社区与抗议网络，见山下凯伦（Karen Tei Yamashita）的实验性小说 *I Hotel*；该旅馆从20世纪初起收容了数千名亚洲劳工，直到1977年被拆毁。

[21] Hartman, *City for Sale*。

〔原书第289页〕

[22] 尽管"非西方"标签常被加在奥奎·恩维佐（Okwui Enwezor）身上，但他自1983年以来主要生活在美国。

[23] Bauer, "Between Art and Politics," 后来在《读书》上发表、经编辑整理的中文讨论记录。

[24] Vergne et al., "Just How Did Latitudes Become Forms?"

[25] 可作比较的讨论见 Dominguez, "A Taste for the 'Other.'"

[26] Kimmelman, "A Few Artless Minutes on '60 Minutes,'" 以及 "At the Whitney, Sound, Fury, and Not Much Else"；Ryan, "The Whitney Fiasco and the Critics."

[27] 女剑客栾菊杰因训练刻苦、比赛坚韧而被称为"铁姑娘"，她在1984年洛杉矶夏季奥运会上为中国赢得第一枚击剑金牌。颜磊图像中击剑手的姿态令人想到1950年代以女工为主角的宣传画；举起的面罩与剑取代了焊工面罩与焊枪。

[28] Kraus, *The Party and the Arty in China*, 172。

[29] Song et al., *Zhongguo keyi shuo bu*。

[30] Ishihara and Morita, *The Japan That Can Say No*。

〔原书第290页〕

[31] Mahathir and Ishihara, *The Voice of Asia*。

[32] 王音用茶杯当船，进一步影射中国出口瓷器（其中瓷器 china 成为其产地中国的转喻）到欧洲的物质与象征贸易，以及18世纪初围绕景德镇真瓷的耶稣会工业间谍活动；见 Liu, "Robinson Crusoe's Earthenware Pot."用茶杯比喻出口市场上的中国艺术并不罕见。我不止一次听到艺术家把他们在国外的展览比作世界各地的唐人街小饰品店，在那里他们的艺术变成又一种"中国货"（Zhongguo huo）。

[33] Qian, *Fortress Besieged*, 43–44。

[34] Huang, "Biculturality in Modern China and in Chinese Studies."

[35] Kim, *Asian American Literature*；Lowe, *Immigrant Acts*。

[36] 我这里借鉴了阿布-卢戈德（Abu-Lughod）的 *Veiled Sentiments* 以及卡顿（Caton）的 "Peaks of Yemen I Summon" 关于文化诗学的著作，把他们对一个社会内部文化惯例的分析延伸到文化相遇地带。

[37] 我在这一过程中的共谋，以及试图介入却徒劳无功的努力，最终促使我策划了一场中国女性主义艺术展。《残酷／爱之身体》汇集了一群艺术家，他们的作品以各种具身方式探索中国身份与性别身份的交汇。这一框架拒绝就男人或女人是什么、应该是什么，或身为中国人意味着什么提出任何特定主张。它旨在促成来自中国大陆、香港和英国的艺术家就这些问题展开对话。展览于2004年6月在上海多伦现代美术馆开幕，并与一场女性主义思想会议相连；同年7月巡展至北京798空间，2006年又到香港艺术中心和——颇具讽刺意味地——歌德学院。Welland, "On Curating Cruel/Loving Bodies."

[38] Huang, "Yishu, wenti, cehuaren," 40。

[39] 艺术家王能涛和张鸥都曾以毛泽东讲话中这句名言为题创作系列作品。

## 第四章　女性主义艺术的腹地

〔原书第290页〕

[1] 查克拉巴蒂（Chakrabarty）在 *Provincializing Europe* 中称之为"历史主义的历史"（historicist history）。

[2] McDougall, *Mao Zedong's "Talks at the Yan'an Conference on Literature and Art,"* 68–69。

[3] Jing Wang, *Brand New China*。

[4] Long March Project, "Curatorial Plan: Site 6."

[5] 芝加哥的征稿启事译文最早于2002年4月28日出现在 arts.cn.tom.com 上。

[6] Visser, *Cities Surround the Countryside*。

[7] 关于雷燕与孙国娟前往泸沽湖踩点的这段叙述，取自她们的"前线报告"。

[8] Johnson, "The Secularization of the Sacred: Judy Chicago's Dinner Party and Feminist Spirituality," 88。

〔原书第291页〕

[9] 布鲁克林艺术博物馆于2002年购藏这件作品，并于2007年将其纳入永久收藏陈列；见 Smith, "For a Paean to Heroic Women, a Place at History's Table." 在线展览导览见 www.brooklynmuseum.org/exhibitions/dinner_party/（2017年9月访问）。

[10] Chicago, *The Dinner Party*, 57–61。

[11] 尽管艺术家Wu Weihe、Bai Chongmin最终说服我前往泸沽湖，我确实接受了卢杰和邱志杰的建议，在丽江——长征第五站——组织了一个地图绘制项目。从昆明去泸沽湖的路上，我们在这座纳西城市停留。1997年丽江古城被列为联合国教科文组织遗产地后，它日益成为热门旅游目的地。在我同行的几位艺术家帮助下，我请许多人——当地纳西居民、外国游客以及来自北京和上海的中国游客——根据他们的经验绘制丽江地图。长征组织者后来丢失了这些地图，但把这些地图作为丽江田野报告展一部分展出时的照片发布在网站上：www.longmarchproject.com/images/o-site5/czhd/ljtybg/e-index.htm（2017年9月访问）。

[12] Sheng Hai，录像记录。尽管芝加哥是对坐在她对面的中国艺术家讲话，她却通过我这个翻译用第三人称指称他们（"而他们抵制它"）。

[13] Gilmartin, *Engendering the Chinese Revolution*。

[14] Johnson, *Women, the Family, and Peasant Revolution in China*。

[15] 丁玲，《三八节有感》。

[16] 丁玲，《三八节有感》，318。

[17] Feuerwerker, *Ding Ling's Fiction*, 102。

[18] Walsh, "From Nü Guo to Nü'er Guo."

[19] Mullaney, "Ethnic Classification Writ Large," 207。

[20] Yan, "A Living Fossil of the Family."

[21] Walsh, "From Nü Guo to Nü'er Guo," 457。

[22] 例如，2002年我收到一封电子邮件邀请，参加"首届中国女性人类学与泸沽湖周边摩梭母权文化国际研讨会"。

[23] 在 *Scenes from Yongning* 中，Tami Blumenfield 给出落水村的数据：这个五百人的村庄在2005年接待了47.8万名游客（第24页）。她还记录了至少六十部在该地区拍摄的影片，不包括中国电视作品。在 "Documentaries South of the Clouds" 中，日本电影节组织者藤冈朝子（Fujioka Asako）写道："有个笑话是说，你在泸沽湖畔待上一年，会撞见一百个摄制组。"

[24] Walsh, "Living with the Myth of Matriarchy."

[25] Blumenfield, *Scenes from Yongning*。

[26] Long March Project, "Exhibition at Qidi shanzhuang."

[27] Mohanty, "Under Western Eyes," 53–54。

[28] Barlow, "International Feminism of the Future."

[29] Long March Project, "Curatorial Plan: Site 6."

[30] Kristeva, *About Chinese Women*, 61。

〔原书第292页〕

[31] 在《中国女性主义中的女性问题》中，白露断言"克里斯蒂娃强烈感到中国女性有某些东西可以提供给'西方'女性"（311）。斯皮瓦克在 *In Other Worlds* 中强调，克里斯蒂娃的东方主义焦点在于前现代母权制的连续性，而非社会主义在解放这一母权制方面的作用。对斯皮瓦克而言，克里斯蒂娃文本中的中国女性主要充当一面无名、沉默的镜子，映照法国女性主义理论的复杂思考。

[32] 关于参加长征的个体女性生平，详见 Gilmartin, *Engendering the Chinese Revolution*；Lee and Wiles, *Women of the Long March*；Young, *Choosing Revolution*；以及 King, *Unbound*。其中几位最著名者嫁给了高级别男性。与周恩来结婚的邓颖超就是一个典型例子。激进女性与丈夫离婚后，可能失去领导职位。例如，据 Gilmartin 详述，向警予离开蔡畅的兄长蔡和森后，被免去妇女部部长职务，并于1925年被送往莫斯科进一步"学习"。1928年，国民党将她逮捕并在武汉公开处决。官方公告特意渲染她的性关系与对婚姻的破坏。

[33] Jones, "The Sexual Politics of the Dinner Party."

[34] 中国妇女研究奠基者之一李小江，是后社会主义中国女性主义这一表述的代表人物。关于1995年联合国大会的背景，另见 Hershatter, Honig, and Rofel, "Reflections on the Fourth World Conference on Women, Beijing and Huairou."

[35] 针对美国类似的指责，芝加哥在 *Beyond the Flower* 中写道："我现在认识到，发出这一指责的人不了解工作室的真实性质和极为平等的品质。没错，《晚宴》是我的作品，但这并不意味着帮助我完成它的人受到剥削。恰恰相反，她们因这段经历而充实，不仅因为艺术创作，也因为我以大多数人从未享受过的尊重对待她们和她们的想法"（68）。

[36] 这段叙述反映了我与中国艺术家群体同行并拍摄的经历所塑造的视角。关于长征组织者对同一批事件的叙述，见 www.longmarchproject.com/e-progess6–1–1.htm。

[37] Kwon, *One Place after Another*。

[38] 关于《烈火中永生》（1965）——江姐故事的首次电影改编——的背景，见 Wang, *Finding Women in the State*, 196–98。

[39] 屠杀囚犯发生在1949年11月27日，这一历史事件通过1961年小说《红岩》的流传进入国民意识，《江姐》即取材于此。美军是否参与杀戮长期是中国公众争论的问题，也一直是学术调查与历史修正的对象。尽管中美合作所（SACO）确实向国民党提供了支持，其人员早在处决发生数年前就已离开重庆。见 Eberlein, "Another Kind of American History in Chongqing."

[40] Mani, *Contentious Traditions*。

〔原书第293页〕

[41] 尽管张伦原计划把系列扩展到七个地点，最终她只能在两个地方实现：落水与成都。

[42] Foster, *The Return of the Real*, 197。

[43] 廖雯，"'Women's Art' as Part of Contemporary Chinese Art since 1990," 60。

[44] 廖雯，《中国当代艺术中的女性艺术》，2。

[45] 廖雯，《女性主义作为方式》。

[46] Feng, "Limitless Difference," 66。

[47] Erickson, "The Rise of a Feminist Spirit in Contemporary Chinese Art," 65。

[48] Cotter, "China's Female Artists Quietly Emerge."

[49] Jia, "Preface," 9。

[50] Cotter, "China's Female Artists Quietly Emerge."

[51] Erickson, "The Rise of a Feminist Spirit in Contemporary Chinese Art."

[52] Chiu, "Thread, Concrete, and Ice," 50。

[53] Bateson, "Toward a Theory of Schizophrenia," 201。

[54] Barlow, *The Question of Women in Chinese Feminism*。

[55] Dooling, *Women's Literary Feminism in Twentieth-Century China*, 2。

[56] Barlow, *The Question of Women in Chinese Feminism*, 14。

[57] Xu, "Dialogue: The Awakening of Women's Consciousness," 19。

[58] Yang, "Zhuanbian zhong de Zhongguo nüxing yishu," 5。

[59] Erickson, "The Rise of a Feminist Spirit in Contemporary Chinese Art," 67。

[60] Kristeva, *About Chinese Women*, 16。

[61] Erickson, "The Rise of a Feminist Spirit in Contemporary Chinese Art," 71。

[62] Karetzky, *Femininity in Contemporary Asian Art*, 2。

[63] Jones, "The Sexual Politics of the Dinner Party," 105。在 *Through the Flower* 中，芝加哥反思了承认女性权威作为教育者与榜样的重要性："按我使用这个词的意义，做一个权威人物，就是成为某个特定主题的权威，并拥有对他人有价值的信息"（108）。

[64] Hernández-Reguant, "Copyrighting Che."

[65] Pang, "'China Who Makes and Fakes,'" 121。

[66] Rofel, *Desiring China*, 143。

[67] Chien, "Marginal Discourse and Pacific Rim Women's Arts," 667。

[68] 2010年，世界上最具影响力的艺术博物馆之一伦敦泰特现代美术馆展出了一条20与21世纪重要艺术运动及人物的时间线。在其"女性主义"——被划归1960年代的运动——条目下所列的艺术家，全部来自欧美主导中心。其他地区同代人的缺席，反映了西方女性主义艺术制度化所带来的一系列史学与政治问题。非西方语境中的女性主义艺术与艺术家遭到遮蔽，在2009年巴黎蓬皮杜中心展览《她们》（Elles）中也显而易见；该展策展人提出修订当代艺术的范畴，却只通过馆藏女性艺术家的作品来呈现它。同期在更全球尺度上考察女性主义艺术实践的尝试，部分挑战了泰特与蓬皮杜的叙述。《全球女性主义》（2007，布鲁克林艺术博物馆）与《Wack! 艺术与女性主义革命》（2007，洛杉矶当代艺术博物馆与纽约 PS1）都调用了后殖民或非西方女性艺术家的形象，然而其策展人却把多重女性主义历史纳入一个以西方为中心的单一总体叙事之中。

## 第五章　红色娘子军

〔原书第294页〕

[1] Chi, "The Red Detachment of Women," 154。

[2] Buck-Morss, *Dreamworld and Catastrophe*。

[3] 1950年代中华人民共和国成立后，国家民族学家建立了一套官方分类体系，确认五十五个少数民族（*xiaoshu minzu*）。北京的中央民族大学对来自这些群体的学生实行基于配额的优待录取，尽管也有汉族学生就读该校。李天翩的母亲是回族，属穆斯林少数民族。

[4] 把自己的艺术家自画像纳入整幅画作，令人想起委拉斯开兹在《宫娥》中的出场。正如福柯在这幅名画中所观察到的，不同主体位置的同时并存，以及观者在其间的往返移动，激发出一种现实与再现之间的悖谬关系（Foucault, *The Order of Things*, 3–16）。

[5] 李天翩访谈。

[6] 她用来指称现实主义的词是"写实"（*xieshi*，写实的描绘）。写实或写生（*xiesheng*，据实物描绘或绘画）的对立面，是中国传统水墨画中"写意"（*xieyi*，传达意念与情感）的观念；写意以松散、暗示性、有时近乎抽象的笔法为特征。在社会主义早期，写意画被等同于精英文人画，因而受到淡化。正如安雅兰（Julia Andrews）在《中华人民共和国的画家与政治》中所指出的，中国艺术教育在民国时期首先采纳了欧洲绘画风格："许多理想主义知识分子的预设是，西方媒介更适合现代、国际性的艺术，或者用五四运动的话说，更适合更科学的艺术"（48）。

[7] 例如，1953年至1956年间，二十四名隶属于中国学术机构的年轻艺术家被派往列宁格勒，在列宾美术学院接受为期六年的油画课程。

[8] Xie, *Hongse niangzi jun*。

[9] 中国的官方评论家早在1954年就开始赞扬这位19世纪法国画家，《自由引导人民》也成为中国美术学院教育中的历史画范本。艺术家陈逸飞和魏景山在1977年的《占领总统府》中借用了它的构图；这幅大型作品描绘中共击败国民党后升旗的场面。它受北京军事博物馆委托创作，至今仍悬挂在那里。

[10] Cui, *Women through the Lens*, 84。

[11] Cui, *Women through the Lens*, 84–85。崔淑琴（ShuQin Cui）在讨论洪常青时使用"崇高"一词，偏离了该词通常指不可再现、不可解释或压倒性之物的用法。她用这个词指称一个旨在代表集体的人物所具有的虚构现实性，个体向这个人物投注情感。

[12] Nedoshivin, "Lun huihua zhong de dianxing wenti," 41。

〔原书第295页〕

[13] Witke, *Comrade Chiang Ch'ing*, 120–21。

[14] Williams, *Marxism and Literature*, 78。他指出了把基础与上层建筑抽象为可分离领域的反讽，因为"马克思原初批评的力量，主要针对的是思想与活动'领域'的分离（如意识与物质生产的分离），以及与之相关的做法：通过强加抽象范畴来抽空具体内容——真实的人类活动"。

[15] Witke, *Comrade Chiang Ch'ing*, 405。

[16] China Ballet Troupe, *Red Detachment of Women*。

[17] 剧本用斜体标出舞蹈动作的术语。例如"背身跪步"（*bei shen gui bu*）指单膝跪地的弓步，躯干扭转，使舞者的背朝向观众，在此是为了展示她戏服背上画出的鞭痕。标准芭蕾动作则在中文术语之后附上法语术语。

[18] "亮相"（*liang xiang*）是中国戏曲的术语。它是演员或舞者在上下场时、有时也在完成一段舞蹈或武打动作之后，为鲜明凝练地呈现人物精神面貌而短暂保持的静止亮相姿态。

[19] Bowers, "For the Nixons, a Maoist Ballet."

[20] Wu, "A Great Victory in 'Making Foreign Things Serve China,'" 83。

[21] Wu, "A Great Victory in 'Making Foreign Things Serve China,'" 81。

[22] Benjamin, "Theses on the Philosophy of History," 261。

[23] 这种记忆的律令，逆转了鲁迅1925年短篇小说《伤逝》中第一人称叙述者的感叹。他在手记中写道，自己被迫写作，是为了忘记那个被他忽视又抛弃的爱人之死，从而重新开始生活："我想忘记。为了我自己，我不愿记住我为子君送葬所给予她的遗忘"（Lu, *Selected Stories*, 215）。关于这个故事性别动态的解读，另见刘禾（Lydia Liu）在 *Translingual Practice*, 164–71 中的分析。

## 第六章　打开长城

〔原书第295页〕

[1] Luttge, *HA Schult: Art Is Action*。

[2] Myers, *Painting Culture*, 8。

[3] 另一幅1979年的画作——油画研究会成员赵以雄的《塔里木的觉醒》——同样以一位斜卧在古今丝绸之路图像拼贴之上的女性裸体作为国家象征，此处象征的是中国西部新疆省塔克拉玛干沙漠的现代化。见 Cohen, *The New Chinese Painting*。

[4] Kraus, *The Party and the Arty in China*。

〔原书第296页〕

[5] 发布于 http://www.cn-lingerie.com/details.asp?detailpage =1&sendid=708 的一篇文章副本显示，它最初出现在 www.39.net 上（阅读编号9967）。其他版本张贴于 http://women.zhaohua.com /displayarticles.asp?artid=2855 和 http://www.zhcchina.com/html/Cat17/1648–1 .html（均于2017年访问）。

[6] Shui, "Kaifang Jinshanling."

[7] He Mai, "On He Chengyao."

[8] Gardner, "China Live."

[9] 何成瑶是我2004年在北京和上海策划、后于2006年巡展至香港的《残酷／爱之身体》展览参展艺术家之一。

[10] Cohen, "China's Flowering Galleries"；Cox, "The House that Lee Built"；Mooney, "Forgiveness Permitting."

[11] 原来的标牌上中英文都有这段文字。我略微改动了刻在标牌上的英文，使其更接近中文说明。

[12] 七年后，何成瑶又回到《头发》提出的交易性问题：购买他人身体的一部分意味着什么？2006年11月，她为在英国曼彻斯特华人艺术中心举办的"生命06：国际中国现场艺术节"创作了一件行为作品。这件名为《头发的可能性》的作品，是对她自己头发的现场拍卖——她为这次活动特意留了几年长发。她跪在地上，头别扭地向后仰，好让长辫展示在身后的桌上。一台从上方拍摄的实时录像投射在房间前方，观众则此起彼伏地叫价。旅居英国的中国艺术家蔡元赢得了拍卖，最后用一把剪刀从她头皮上剪下了头发。见 Fok, *Life and Death*, 174–75。

[13] 例如，他反复问何成瑶是否看过安·汉密尔顿（Ann Hamilton）的作品。这位艺术家以场地特定作品 *tropos* 闻名：该作在纽约一处工厂空间内，用成捆的马毛波浪覆盖了五千平方英尺的地面，令人回想起纽约早期的马毛产业。

[14] 在转写和翻译这次访谈时，我只作了最低限度的编辑。有时我会就自己不理解的地方提问，或鼓励她继续说下去。只有当有必要标明我的提问如何引导或影响了她的讲述时，我才保留自己的声音。对读者可能不熟悉的历史事件或其他具体细节，脚注中作了说明。

[15] 何成瑶是她的真名。我之所以在本章使用真名，只是因为在几个月后她撤回了匿名的请求，并催促我公开她的名字。这种对隐私与羞耻观念的彻底转变，成为她发展中的艺术实践与曝光身体政治的核心。

[16] 一种流行的后社会主义性话语，把"自然的"当代性表达描述为对社会主义"不自然的"性欲压抑的解放——后者曾把性欲视为资产阶级的、因而在政治上不道德的。何成瑶非婚出生的故事，反而揭示了性欲跨越不同时代的连续性，即使身处既定规范之外；它也提醒我们，问题不应是不同时期的性更多还是更少，而是性的具体形式、规制与社会解释如何在各时代有所不同。

[17] 大跃进是毛泽东自1958年至1961年领导的一场使国家迅速工业化的运动，在期间导致了普遍饥荒。

〔原书第297页〕

[18] 尽管何成瑶多次称她的家庭是传统的，她的家庭住户结构并不符合对中国传统亲属组织的常规描述。在这种组织的一种典型模式中，父系继嗣、父居制与父权制赋予男性世系首要地位，并强调男性亲属之间的宗族关系高于其他关系。关于性别与亲属关系的更多讨论，见 Croll, *Feminism and Socialism in China*；Johnson, *Women, the Family, and Peasant Revolution in China*；Ono, *Chinese Women in a Century of Revolution*；以及 Stacey, *Patriarchy and Socialist Revolution in China*。何成瑶叙述中的家庭，更接近一种称为入赘婚的替代性亲属形式：男子嫁入没有男性后代的家族世系，并随妻姓。不过，何成瑶的父亲与妻子和岳母同住，似乎主要是出于妻子患有精神疾病。

[19] 《聊斋志异》为蒲松龄（1640—1715）在明朝灭亡、清朝建立后不久所作。这些故事充满狐仙、鬼魂和其他精灵，它们对善恶凡人或赏或罚。蒲松龄以民间传说和民俗为素材，写作于一个审查严苛的时代。他重述自己搜集或友人寄来的神怪故事，间接地批判了新满族统治者的统治。

[20] 1964年2月，中共发起了一场群众运动，号召公民"学习解放军"，以他们为思想正确、技术过硬的典范，或用口号化的话说，是"又红又专"。这场政治运动源于围绕党军关系未来方向的一场冲突。到1950年代末，军队内部日益加剧的等级化与专业化——偏离毛泽东式的平等主义模式——已使军民关系以及指挥员与政治委员之间的关系趋于紧张。大跃进失败后，毛泽东力图重新巩固对党内"反动"温和派的控制，于是把解放军当作党外的权力基础来支持自己的立场。在林彪领导下，军队的专业化倾向因革命价值与政治在部队中的重申而受到遏制。例如，1963年林彪安排出版《毛主席语录》（"红宝书"），并在军队中广泛分发。在此后的文化大革命岁月里，解放军承担了比以往更广泛的行政与民事职能，尤其是在地方层面。部队复员进入解放军生产建设兵团、从事民用工程，在1960年代末和1970年代初达到高峰。在此期间，中共领导层以相互矛盾的方式调用解放军：既维持秩序，又鼓励革命活动，使军队在一个极端政治的时期充当平衡力量。有时他们期望解放军对红卫兵进行训练和指导，有时又用解放军控制红卫兵的激进主义，因为派系武斗有可能彻底破坏社会秩序。1968年，中央政府命令红卫兵向解放军交出武器，随后又用解放军在大学校园和工业企业开办学习班，"再教育"红卫兵。见 Dreyer, *China's Political System*；Joffe, "The Chinese Army in the Cultural Revolution"；Ruwitch, *Lei Feng and the "Learn from Lei Feng" Campaign of 1963*；以及 Shichor, "Demobilization."

[21] "学雷锋"成为这场普遍的"学习解放军"运动中最著名、最长寿的宣传作品；在这场运动中，单个士兵和整个解放军单位被推举为供全国效仿的思想符号。雷锋是一名普通士兵，湖南贫农的儿子。他身后出版的日记宣扬为革命、国家、同志，尤其是为毛泽东自我牺牲的服务。日本人杀害了他的父亲；母亲在被地主雇主的儿子强奸后自杀，使雷锋成为孤儿，由亲属抚养（原文为 aunt and uncle）。母亲自杀一年后，1949年8月，人民解放军解放了他们的村庄，雷锋进入学校。他最终参加解放军，成为班长和党员；这个普通士兵以纯粹的决心和对事业的忠诚弥补了自己身材的矮小。作为人民的勤务员，他宣称："我要做一颗永不生锈的螺丝钉，放到哪里就在哪里闪光。"1962年，他二十二岁时死于一场卡车事故。他死后不久，沈阳军区内部的军队领导人便宣传他的故事，勉励士兵"学雷锋、赶雷锋、超雷锋"。到1963年，党领导人出版了雷锋日记，作为更广泛传播的宣传工具。他在日记中记录的好事包括：把微薄的积蓄寄给一位同志在水灾中遭受重创的父母；为军官和新兵端茶送饭；在长途行军后为战友洗脚、补袜子。许多人怀疑，写下那本著名、可能虚构或至少经过加工的日记的未必是士兵雷锋，而是宣传工作者；这本日记后来使他的模范行为故事广为人知。见 Dreyer, *China's Political System*, 248；Landsberger, "Lei Feng"；Ruwitch, *Lei Feng and the "Learn from Lei Feng" Campaign of 1963*；Spence, *The Search for Modern China*, 597–99; 727。

[22] 这种小本经营，或称个体户生意，通常与1980年代开始的市场改革相联系，以区别于毛泽东时代的中央指令经济。何成瑶的父亲在1970年代经营的这门看似反常的生意，提出了关于整个社会主义时期地方市场实践之连续性的问题——在那一时期，个体户从未被完全废除。

[23] 何成瑶，电子邮件交流。

[24] 因创伤境遇而发疯的女人的故事，萦绕在中国传统说书曲目中。《白毛女》是一部关于地主压迫的受害者逃入山中的民间歌剧，后来成为共产党八部样板戏之一，以歌剧、芭蕾和电影的形式演出。Witke, *Comrade Chiang Ch'ing*, 430–32。相较之下，何成瑶的母亲是在受到其共产党工作单位的谴责后首次发作精神疾病的。

[25] He Chengyao, "In the Mirror."

〔原书第298页〕

[26] 在小野洋子的《Cut Piece》（1964）和玛丽娜·阿布拉莫维奇（Marina Abramović）的《节奏0》（1974）等行为作品中，艺术家把自己被动的身体交给观众，而观众的反应越来越具有侵略性。观众用一把剪刀把小野的衣服完全剪掉。阿布拉莫维奇提供了一张桌子，上面摆着七十二件物品，观众可以任意使用。在这场行为持续六小时的过程中，相遇的气氛变得暴力。

[27] Caplin, *Andy Warhol: Made in China*。

[28] 见 Wu, *Transience*, 30–35。毛泽东有句名言："不到长城非好汉。"

[29] 1988年，自称"行为艺术祖母"的常驻纽约的南斯拉夫艺术家玛丽娜·阿布拉莫维奇与她长期伴侣乌雷（Ulay），也在长城上实施了他们最后一件共同作品。在《长城行走》中，他们从长城两端出发，各自步行两千五百公里向对方走去；他们在中点相遇，然后道别。

[30] 2005年，高名潞策划了一场关于长城这一作用的展览。《墙：重塑中国当代艺术》是北京中华世纪坛艺术馆与布法罗纽约州立大学奥尔布赖特-诺克斯美术馆的合作项目。

[31] Merewether, "The Spectre of Being Human."

[32] 《下楼梯的裸体，第2号》以 E. 马雷（E. Marey）等人的定格摄影为基础。

[33] Tomkins, *Duchamp: A Biography*。

[34] 见 Jones, *Postmodernism and the En-Gendering of Marcel Duchamp*；Judovitz, *Unpacking Duchamp*；Krauss, *Bachelors*。例如，杜尚有时用默片明星莎拉·伯恩哈特（Sarah Bernhardt）的别名署名，或使用萝丝·塞拉维（Rrose Sélavy）的化名；在曼·雷（Man Ray）拍摄的一组题为《马塞尔·杜尚作为萝丝·塞拉维》（约1920—1921）的照片中，他以女性形象出现。"达达之父"这个称呼来自1952年4月《生活》杂志一期以杜尚为专题的跨页标题。

[35] Clifford, *The Predicament of Culture*。

[36] Wang, "Retheorizing the Personal."

## 第七章　被伪装的历史

〔原书第299页〕

[1] 《妇女时报》的封面插画师常从《妇女家庭杂志》（*Ladies' Home Journal*）等西方刊物中汲取灵感；后者的封面描绘女性从事运动与户外活动，有时还以望远镜和相机作为这些冒险的装备。另一幅1916年的插图发表于《上海时装图咏》，同样描绘了一个把望远镜举到眼前的女子。她身穿睡衣，站在高楼房子的阳台上，凝望星辰。Joan Judge 在 *Republican Lens* 中讨论了这两幅图像，以及《妇女时报》关于第一位女飞行家 Zhang Xiahun 的文章。

〔原书第300页〕

[2] Wu, *Wu Youru huabao*, vol. 3, part II, no. 14。

[3] 例如见梁启超与金天翮的文章，收于 Liu, Karl, and Ko, *The Birth of Chinese Feminism*。

[4] Liu, "Zhongguo zhi nü feixingjia."

[5] Barlow, *The Question of Women in Chinese Feminism*, 239。

[6] Barlow, *The Question of Women in Chinese Feminism*, 16。另见 Welland, "What Women Will Have Been."

[7] 她能在四十四岁退役，是因为参军时只有十四岁。

[8] 按照一项题为"四季"的四年计划，每场年度展览都以一个季节为主题。它们包括《2009年寒冬》（2009年1—2月）；《春》（2010年3月）；《夏》（2011年12月—2012年1月）；以及《秋》（2012年11—12月）。更多信息见 http://en.tcgnordica.com 与 http://blog.artintern.net/article/263558（2017年访问）。

[9] 谢冰莹的自传曾以多种版本和语言出版，例如 Xie, *A Woman Soldier's Own Story*。

[10] Xie, *A Woman Soldier's Own Story*, 64。

[11] 关于早期共产主义活动内部的性别等级，以及第一次国共合作破裂后的性暴力，详见 Gilmartin, *Engendering the Chinese Revolution*。关于毛泽东时代，见 Honig, "Socialist Sex: The Cultural Revolution Revisited."

[12] Lee, "Tradition and Modernity in the Writings of Lu Xun," 21–23。

[13] 该学院于1945年迁至沈阳，1958年更名为鲁迅美术学院。

[14] Wang, "The Red Guards' Fine Art Campaign."

[15] Jia, "Preface," 8–9。

[16] 吕澎，《中国当代艺术史》。

[17] Gilmartin, *Engendering the Chinese Revolution*；Bailey, *Women and Gender in Twentieth-Century China*, 95–99。

[18] 丁玲，《三八节有感》。娜拉是易卜生《玩偶之家》的女主人公，她挣扎着逃离传统家庭的束缚。易卜生的这部剧在20世纪初的中国改革者中被广泛翻译、上演和讨论。

[19] 丁玲，《三八节有感》，319。

[20] Lei, "Bingdong: baoliu jiyi de fangfa."

[21] 引自 Wang, "Gonggong lixing yu kuannüxingzhuyi." 译文为笔者所译。

[22] Wang, "Transfeminist Art."

[23] McRobbie, *The Aftermath of Feminism*；Hemmings, *Why Stories Matter*, 136–41。

[24] Appadurai, "The Thing Itself," 15。

[25] "八一"，即8月1日，是1927年解放军建军的日期。

[26] Lei, "Bingdong: baoliu jiyi de fangfa."

〔原书第301页〕

[27] Wu Hung, *Making History*, 125。

[28] 巫鸿把这些方法解释为"艺术家对中国历史时间性的浓厚兴趣"的反映，以及他们"重新想象国家的过去、现在与未来"的尝试。*Making History*, 128。

[29] 《冰封的青春》作为一种自画像，与巫鸿考察的另一件作品形成对照：由隋建国、展望和于凡布置的 *Women Here* 照片装置。该装置是作为1995年北京第四次世界妇女大会的"反事件"而创作的。这件作品由中央美术学院三位年轻男教师制作，包括他们从母亲和妻子那里收集的照片与纪念物。与男性同行直截了当的纪实手法——他们旨在向想象中的全球观众呈现"真实的中国女性"——相比，雷燕的再摄影体现了与更年轻、作为历史存在的自我形象之间更为主观的关系。

[30] 中越战争可以说是一个比文化大革命更受压抑、更被遗忘的历史事件；其影响也更具地区性。

[31] 例如见 Urbina, "U.S. Flouts Is Own Advice in Procuring Overseas Clothing."

[32] 这件作品让人联想到草间弥生的《积累》和玛莎·罗斯勒的《厨房符号学》等作品。在软雕塑《积累第1号》（1962）中，草间用缝制并填充的布制阳具状突起覆盖了一把扶手椅，把一件家具变成幽默地执着而具有侵略性的存在。在罗斯勒1975年的行为录像中，她按字母顺序演示了各种厨房用具；她面无表情的神态和暴烈的动作，戏仿了对"女人"的符号学控制——女人只是众多家庭化符号之一。

[33] Jacka, "Back to the Wok: Women and Employment in Chinese Industry in the 1980s."

[34] 胡锦涛主席于2006年提出政治口号"和谐社会"（*hexie shehui*）；在经济差距日益扩大的时期，这个口号常被用来压制异见和对社会不平等的批评。

[35] 随着千禧年之交以来中国当代艺术国际与国内市场的增长，一些批判这种泡沫经济及其评价与流通模式的艺术家，把实践转向社会纪实与行动主义，其项目聚焦于中国快速发展造成的危机：例如电子废物的有毒田野（邢丹文，《disConnexion》）、垃圾山（姚璐，《新景观》）、拾荒者（王久良，《垃圾围城》）、矿难（张建华，《矿难，矿难》）、艾滋病／HIV村落（陈为军，《好死不如赖活着》），以及三峡大坝移民（陈秋林，《告别狂想曲》；贾樟柯，《三峡好人》；刘小东，《温床》；庄辉，《东经109.88度，北纬31.09度》）。除了艾未未和雷燕回应汶川地震的作品，另见杜海滨的影片《1428》和张洹的《希望隧道》。关于艾未未的纪录片，见 Alison Klayman 导演的 *Ai Weiwei: Never Sorry*。

[36] Wu Hung, "Monumentality and Anti-monumentality in Gu Wenda's Forest of Stone Steles—A Retranslation and Rewriting of Tang Poetry," 51–52。

〔原书第302页〕

[37] Callahan, "Citizen Ai: Warrior, Jester, and Middleman," 906。

[38] Bourdieu, *The Field of Cultural Production*, 29–73。

[39] 这是斯皮瓦克对德里达"痕迹"概念的阐释。Spivak, "Translator's Preface," xxxvi。

[40] 在他2011年被拘留期间，世界各地的个人、组织和博物馆通过传统媒体与社交媒体渠道，参与了"释放艾未未"的运动。

[41] Bryson, *Looking at the Overlooked*, 61。

[42] Derrida, *The Truth in Painting*, 265。关于德里达围绕凡·高那幅破旧靴子画作所加入的阐释争论的谱系，见 Tweedie, "The Afterlife of Art and Objects," 68–71。

[43] Harman, *Tool-Being*, 18–20。

[44] He-Yin, "On Feminist Antimilitarism," 169–70。

## 尾声　递归的世俗寓言

〔原书第302页〕

[1] 更多内容见展览图录 *UCCA Wang Xingwei*，尤其是其中 Zhang Li 的评论文章《Side》。

[2] 展览按具象构图的背面、侧面、正面来组织，而非按年代顺序。展览的墙面文字说明指出，《无题（三个裸体）》是最后一个展厅的最后一幅画。

[3] 王兴伟了解这幅画的一个可能来源，是李天翩出版的一本关于油画人体技法掌握的教材。Li, *Youhua renti jifa rumen aomi*。

[4] Zhang, "Side," 70–71。

[5] 杨飞云也在笑谈之中，只是其性别方式不同。从中央美术学院毕业后，他留校任油画系教师，在中国美术馆展出，并通过大型拍卖行出售作品。他古典学院写实绘画的主要题材是女性人体，往往裸体，置身资产阶级家庭室内。他的妻子是他最常使用的模特。

[6] 随着裸体画在1980年代的中国正常化——杨飞云等艺术家正是在那时崭露头角——女性画室模特的再现劳动引发了道德政治与抗议。当中央美术学院画家的作品在1988年北京一场广受宣传的裸体艺术展上展出时，曾为他们摆姿势的模特遭到了骚扰。有几位威胁要对那些未经同意便把她们置于公众审视之下的人采取法律行动。Kraus, *The Party and the Arty in China*, 87–89。

[7] Boehler and Piao, "Xi Jinping's Speech on the Arts Is Released, One Year Later," 提供了部分英译。习近平讲话两个月后，国家新闻出版广电总局宣布了一项令人想起文化大革命的项目，把艺术家和电影工作者送到乡下，以便正确地表现人民。

[8] 见 Chumley, *Creativity Class*，这是一部关于中国艺术学生的民族志，考察中国视觉文化产业的发展与新的创造力意识形态。Wong, *Van Gogh on Demand* 与 Byler, "New Silk Road Artworlds" 分别提供了民族志叙述，说明中国不断扩张的文化产业如何询唤农村民工艺术家与少数民族艺术家，并试图以等级化的方式控制与容纳他们。

〔原书第303页〕

[9] Hernández, "With Odes to Military March."

[10] "第二人生"由林登实验室（Linden Lab）于2003年推出，是一个完全由用户创造的三维虚拟世界宇宙。数百万用户在这些世界中互动，并在"第二人生"经济中交易了数十亿美元。

[11] Quadrio, "A Dramatic 'Second Life' for Cao Fei," 38。

[12] Jim, "The Different Worlds of Cao Fei," 92–93。

[13] 《人民城寨歌剧》于2009年在意大利都灵 Artissima 艺术博览会上全球首演。

[14] 这段引文出自 William J. Mitchell, *Me++: The Cyborg Self and the Networked City*。

[15] Cao, *I watch that worlds pass by*, 191。
