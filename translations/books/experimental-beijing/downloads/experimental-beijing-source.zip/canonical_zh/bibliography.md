# 参考文献

书目保留原书著录原文；页码均指原书。

〔原书第305页〕

<!-- eb-bibliography-entry-0001 | PDF 326 -->
Abramson, Daniel. “Urban Planning in China: Continuity and Change.” *Journal of the American Planning Association* 16.2 (2006): 197–215.

<!-- eb-bibliography-entry-0002 | PDF 326 -->
Abu-Lughod, Lila. *Veiled Sentiments: Honor and Poetry in a Bedouin Society*. Berkeley: University of California Press, 1986.

<!-- eb-bibliography-entry-0003 | PDF 326 -->
———. *Writing Women’s Worlds: Bedouin Stories*. Berkeley: University of California Press, 1993.

<!-- eb-bibliography-entry-0004 | PDF 326 -->
Ai Weiwei and Feng Boyi. *Fuck Off* (Bu hezuo fangshi). Shanghai, unofficial publication, 2000.

<!-- eb-bibliography-entry-0005 | PDF 326 -->
Anagnost, Ann. “The Corporeal Politics of Quality (*Suzhi*).” *Public Culture* 16.2 (2004): 189–208.

<!-- eb-bibliography-entry-0006 | PDF 326 -->
Andrews, Julia F. *Painters and Politics in the People’s Republic of China*, *1949–1979*. Berkeley: University of California Press, 1994.

<!-- eb-bibliography-entry-0007 | PDF 326 -->
———. “Women Artists in Twentieth-Century China: A Prehistory of the Contemporary.” Keynote Address. Female Embodiment of the Visual World: Women’s Art in Contemporary China International Symposium. Bowdoin College, Brunswick, ME. September 27, 2013.

<!-- eb-bibliography-entry-0008 | PDF 326 -->
Andrews, Julia F., and Gao Minglu. “The Avant-Garde’s Challenge to Official Art.” In *Urban Spaces in Contemporary China: The Potential for Autonomy and Community in Post-Mao China*, ed. Deborah S. Davis, Richard Kraus, Barry Naughton, and Elizabeth Perry, 221–78. New York: Cambridge University Press, 1995.

<!-- eb-bibliography-entry-0009 | PDF 326 -->
Andrews, Julia F., and Kuiyi Shen. *The Art of Modern China*. Berkeley: University of California Press, 2012.

<!-- eb-bibliography-entry-0010 | PDF 326 -->
Appadurai, Arjun. “The Thing Itself.” *Public Culture* 18.1 (2006), 15–21.

<!-- eb-bibliography-entry-0011 | PDF 326 -->
Asako, Fujioka. “Documentaries South of the Clouds.” *Yamagata International Documentary Film Festival*. Accessed September 10, 2015. http://www.yidff.jp/docbox /23/box23–3-e.html.

<!-- eb-bibliography-entry-0012 | PDF 326 -->
Bailey, Paul. *Women and Gender in Twentieth-Century China*. New York: Palgrave Macmillan, 2012.

<!-- eb-bibliography-entry-0013 | PDF 326 -->
Barboza, David. “Schooling the Artists’ Republic of China.” *New York Times*, March 30, 2008.

<!-- eb-bibliography-entry-0014 | PDF 326 -->
Barlow, Tani E. “International Feminism of the Future.” *Signs: Journal of Women in Culture and Society* 25.4 (2000): 1099–105.

<!-- eb-bibliography-entry-0015 | PDF 326 -->
———. *The Question of Women in Chinese Feminism*. Durham, NC: Duke University Press, 2004.

〔原书第306页〕

<!-- eb-bibliography-entry-0016 | PDF 327 -->
Barmé, Geremie. “Arrière-pensée on an Avant-Garde: The Stars in Retrospect.” In *The Stars: 10 Years*. Hong Kong: Hanart tz Gallery, 1989.

<!-- eb-bibliography-entry-0017 | PDF 327 -->
———. *In the Red: On Contemporary Chinese Culture*. New York: Columbia University Press, 1999.

<!-- eb-bibliography-entry-0018 | PDF 327 -->
Bateson, Gregory. “Toward a Theory of Schizophrenia.” In *Steps to an Ecology of Mind*, 201–27. New York: Ballantine Books, 1972.

<!-- eb-bibliography-entry-0019 | PDF 327 -->
Bauer, Ute Meta. “Zai yishu yu zhengzhi zhijian: guanyu Kasai’er Wenjian de duihua” (Between art and politics: a dialogue about the Kassel Documenta exhibition). *Du shu* (Reading) 280 (2002): 75–81.

<!-- eb-bibliography-entry-0020 | PDF 327 -->
Becker, Howard. *Art Worlds*. Berkeley: University of California Press, 1982.

<!-- eb-bibliography-entry-0021 | PDF 327 -->
Behar, Ruth, and Deborah A. Gordon, eds. *Women Writing Culture*. Berkeley: University of California Press, 1995.

<!-- eb-bibliography-entry-0022 | PDF 327 -->
“Beijing jing mian fangzhi jituan youxian zeren gongsi zongjingli Gu Weida fangtan” (Interview with Gu Weida, general manager Beijing Capital Cotton Textile Group Limited Responsibility Corporation). *Zhongguo fangzhi bao* (China textile news), June 5, 2006.

<!-- eb-bibliography-entry-0023 | PDF 327 -->
Benjamin, Walter. “Theses on the Philosophy of History.” In *Illuminations*, ed. Hannah Arendt, trans. Harry Zohn, 253–64. New York: Schocken Books, 1968.

<!-- eb-bibliography-entry-0024 | PDF 327 -->
———. “N: On the Theory of Knowledge, Theory of Progress.” In *The Arcades Project*, ed. Rolf Tiedemann, trans. Howard Eiland and Kevin McLaughlin, 456–88. Cambridge, MA: Belknap, 1999.

<!-- eb-bibliography-entry-0025 | PDF 327 -->
Blumenfield, Tami. *Scenes from Yongning: Media Creation in China’s Na Villages*. PhD diss., University of Washington, 2010.

<!-- eb-bibliography-entry-0026 | PDF 327 -->
Boehler, Patrick and Vanessa Piao. “Xi Jinping’s Speech on the Arts Is Released, One Year Later.” *New York Times Sinosphere Blog*, October 15, 2015.

<!-- eb-bibliography-entry-0027 | PDF 327 -->
Bourdieu, Pierre. *The Field of Cultural Production*. New York: Columbia University Press, 1993.

<!-- eb-bibliography-entry-0028 | PDF 327 -->
Bowers, Faubion. “For the Nixons, a Maoist Ballet.” *New York Times*, February 23, 1972.

<!-- eb-bibliography-entry-0029 | PDF 327 -->
Braester, Yomi. *Painting the City Red: Chinese Cinema and the Urban Contract*. Durham, NC: Duke University Press, 2010.

<!-- eb-bibliography-entry-0030 | PDF 327 -->
Bryson, Norman. *Looking at the Overlooked: Four Essays on Still Life Painting*. Cambridge, MA: Harvard University Press, 1990.

<!-- eb-bibliography-entry-0031 | PDF 327 -->
Buck-Morss, Susan. *Dreamworld and Catastrophe: The Passing of Mass Utopia in East and West*. Cambridge, MA: mit Press, 2000.

<!-- eb-bibliography-entry-0032 | PDF 327 -->
Bürger, Peter. *Theory of the Avant-Garde*. Trans. Michael Shaw. Minneapolis: University of Minnesota Press, 1984.

<!-- eb-bibliography-entry-0033 | PDF 327 -->
Byler, Darren. “New Silk Road Artworlds: The Art of the Hybrid and the Marginal at the Xinjiang Conemporary Art Museum.” *Journal of Contemporary Chinese Art* 4.1 (2017): 27–43.

<!-- eb-bibliography-entry-0034 | PDF 327 -->
Callahan, William A. “Citizen Ai: Warrior, Jester, and Middleman.” *Journal of Asian Studies* 73.4 (2014): 899–920.

<!-- eb-bibliography-entry-0035 | PDF 327 -->
Cao Fei. *I watch that worlds pass by*. Ed. by Renate Wiehager, Christian Ganzenberg, and The Pavilion, Beijing. Berlin: Daimler Art Collection, 2015.

〔原书第307页〕

<!-- eb-bibliography-entry-0036 | PDF 328 -->
Caplin, Lee Evan. *Andy Warhol: Made in China*. St. Louis: Phoenix Learning Group, 1986. Videodisc, 29 min.

<!-- eb-bibliography-entry-0037 | PDF 328 -->
Caton, Steven C. “*Peaks of Yemen I Summon”: Poetry as Cultural Practice in a North Yemeni Tribe*. Berkeley: University of California Press, 1990.

<!-- eb-bibliography-entry-0038 | PDF 328 -->
Chakrabarty, Dipesh. *Provincializing Europe: Postcolonial Thought and Historical Difference*. Princeton: Princeton University Press, 2000.

<!-- eb-bibliography-entry-0039 | PDF 328 -->
Chang Yung Ho. “East Modern Art Center.” *a*+*u Architecture and Urbanism* 399 (2003): 138–42.

<!-- eb-bibliography-entry-0040 | PDF 328 -->
———. “Pingod (Apple) Sales Center/Art Museum.” *a*+*u Architecture and Urbanism* 399 (2003): 132–37.

<!-- eb-bibliography-entry-0041 | PDF 328 -->
Chau, Adam. “An Awful Mark: Symbolic Violence and Urban Renewal in Reform-Era China.” *Visual Studies* 23.3 (2008): 195–210.

<!-- eb-bibliography-entry-0042 | PDF 328 -->
Chen Fusheng. “Bu neng yi yishu de mingyi na qiongren kaixin” (One can’t make fun of poor people in the name of art). *Meishu* (Fine arts) 412 (April 2002): 9–11.

<!-- eb-bibliography-entry-0043 | PDF 328 -->
Chen Kuan-hsing and Rasheed Araeen. “A Conversation between Chen Kuan-hsing and Rasheed Araeen.” *Field Notes* 3 (2013): 21–34.

<!-- eb-bibliography-entry-0044 | PDF 328 -->
Chen Lingyang. Artist Statement. *Prague Biennale 1*, 2003. Accessed September 10, 2015. www.praguebiennale.org/artists/cina/chenglingyang.php.

<!-- eb-bibliography-entry-0045 | PDF 328 -->
Chen Shouxiang. *Jiu meng zhong jing: Fang Lin*, *Bei Ning cang qingdai mingxinpian xuanji* (The heavy shock of an old dream: selected Qing dynasty postcards from the collection of Fang Ling and Bei Ning). Nanjing: Guangxi meishu chubanshe, 1998.

<!-- eb-bibliography-entry-0046 | PDF 328 -->
———. “Sheng zhuang xia de jixing” (Deformity beneath a glorious costume). *Beijing qingnian bao* (Beijing youth news), May 23, 2001: 25.

<!-- eb-bibliography-entry-0047 | PDF 328 -->
Cheng, Scarlet. “What Would Mao Think?” *Los Angeles Times*, October 11, 1998.

<!-- eb-bibliography-entry-0048 | PDF 328 -->
Chi, Robert. “The Red Detachment of Women: Resenting, Regendering, Remembering.” In *Chinese Films in Focus: 25 New Takes*, ed. Chris Berry, 125–59. London: British Film Institute, 2003.

<!-- eb-bibliography-entry-0049 | PDF 328 -->
Chicago, Judy. *Beyond the Flower: The Autobiography of a Feminist Artist*. New York: Viking, 1996.

<!-- eb-bibliography-entry-0050 | PDF 328 -->
———. *The Dinner Party: A Symbol of Our Heritage*. Garden City: Anchor Press, 1979.

<!-- eb-bibliography-entry-0051 | PDF 328 -->
———. *Through the Flower: My Struggle as a Woman Artist*. New York: Authors Choice Press, 2006.

<!-- eb-bibliography-entry-0052 | PDF 328 -->
Chien Ying-Ying. “Marginal Discourse and Pacific Rim Women’s Arts.” *Signs: Journal of Women in Culture and Society* 29.2 (2004): 663–77.

<!-- eb-bibliography-entry-0053 | PDF 328 -->
China Ballet Troupe. *Red Detachment of Women: A Modern Revolutionary Ballet*. Beijing: Foreign Language Press, 1972.

<!-- eb-bibliography-entry-0054 | PDF 328 -->
Chiu, Melissa. “Thread, Concrete, and Ice: Women’s Installation Art in China.” *art* *AsiaPacific* 20 (1998): 50–57.

<!-- eb-bibliography-entry-0055 | PDF 328 -->
Chow Tse-tung. *The May Fourth Movement: Intellectual Revolution in Modern China*. Cambridge, MA: Harvard University Press, 1960.

<!-- eb-bibliography-entry-0056 | PDF 328 -->
Chumley, Lily. *Creativity Class: Art School and Culture Work in Postsocialist China*. Princeton: Princeton University Press, 2016.

〔原书第308页〕

<!-- eb-bibliography-entry-0057 | PDF 329 -->
Clarke, David. “Contemporary Asian Art and Its Western Reception.” *Third Text* 16.3 (2002): 237–42.

<!-- eb-bibliography-entry-0058 | PDF 329 -->
Claypool, Lisa. “Metadomesticity: The Visual Art of Yin Xiuzhen.” Female Embodiment of the Visual World: Women’s Art in Contemporary China International Symposium. Bowdoin College, Brunswick, ME. September 28, 2013. Conference Presentation.

<!-- eb-bibliography-entry-0059 | PDF 329 -->
Clifford, James. *The Predicament of Culture: Twentieth-Century Ethnography*, *Literature*, *and Art*. Cambridge, MA: Harvard University Press, 1988.

<!-- eb-bibliography-entry-0060 | PDF 329 -->
———. *Routes: Travel and Translation in the Late Twentieth Century*. Cambridge, MA: Harvard University Press, 1997.

<!-- eb-bibliography-entry-0061 | PDF 329 -->
Clunas, Craig. “China in Britain: The Imperial Collections.” In *Colonialism and the Object: Empire*, *Material Culture*, *and the Museum*, ed. Tim Barringer and Tom Flynn, 41–51. London: Routledge, 1998.

<!-- eb-bibliography-entry-0062 | PDF 329 -->
Cohen, Joan Lebold. “China’s Flowering Galleries.” *ARTnews* 96.9 (1997): 146–47.

<!-- eb-bibliography-entry-0063 | PDF 329 -->
———. *The New Chinese Painting*, *1949–1986*. New York: H. N. Abrams, 1987.

<!-- eb-bibliography-entry-0064 | PDF 329 -->
Coleman, Julie. “Flux.” In *Zhang Dali: Headlines*. London: Chinese Contemporary, 2002.

<!-- eb-bibliography-entry-0065 | PDF 329 -->
Cotter, Holland. “China’s Female Artists Quietly Emerge.” *New York Times*, July 30, 2008.

<!-- eb-bibliography-entry-0066 | PDF 329 -->
Cox, James. “The House that Lee Built.” *USA Today*, August 28, 1997.

<!-- eb-bibliography-entry-0067 | PDF 329 -->
Croll, Elizabeth. *Feminism and Socialism in China*. New York: Schocken Books, 1978.

<!-- eb-bibliography-entry-0068 | PDF 329 -->
Cui Shuqin. *Women through the Lens: Gender and Nation in a Century of Chinese Cinema*. Honolulu: University of Hawaii Press, 2003.

<!-- eb-bibliography-entry-0069 | PDF 329 -->
Cui Xiuwen. “Yici xing youxi” (One-time game). *Zhuiqiu* (Madame Figaro), October 2001, 39.

<!-- eb-bibliography-entry-0070 | PDF 329 -->
Dai Jinhua. “A Scene in the Fog: Reading the Sixth Generation Films.” In *Cinema and Desire: Feminist Marxism and Cultural Politics in the Work of Dai Jinhua*, ed. Jing Wang and Tani E. Barlow, trans. Yiman Wang, 71–78. New York: Verso, 2002.

<!-- eb-bibliography-entry-0071 | PDF 329 -->
Dal Lago, Francesca. “Papercuts, Colorful Pictures and Mountains of Shit: ‘China’ at the Venice Biennale, 1980–2007.” “China” on Display: Past and Present Practices of Selecting, Exhibiting, and Viewing Chinese Visual and Material Culture International Symposium. Leiden University, The Netherlands. December 8, 2007. Conference Presentation.

<!-- eb-bibliography-entry-0072 | PDF 329 -->
Dal Lago, Francesca, Song Dong, Zhang Dali, Zhang Wang, and Wang Jianwei. “Space and Public: Site Specificity in Beijing.” *Art Journal* 59.1 (2000): 75–87.

<!-- eb-bibliography-entry-0073 | PDF 329 -->
Dangdai zhiye, ed. *Dangdai* *moma* *by Steven Holl Architects* (promotional catalogue and dvd). Beijing: Beijing Publishing House, 2006.

<!-- eb-bibliography-entry-0074 | PDF 329 -->
Danto, Arthur. “The Artworld.” *Journal of Philosophy* 61.19 (1964): 571–84.

<!-- eb-bibliography-entry-0075 | PDF 329 -->
Davis, Deborah S. “From Welfare Benefit to Capitalized Asset: The Re-Commodification of Residential Space in Urban China.” In *Housing and Social Change: East-West Perspectives*, ed. Ray Forrest and James Lee, 183–98. New York: Routledge, 2003.

<!-- eb-bibliography-entry-0076 | PDF 329 -->
Derrida, Jacques. *The Truth in Painting*. Trans. Geoff Bennington and Ian McLeod. Chicago: University of Chicago Press, 1987.

〔原书第309页〕

<!-- eb-bibliography-entry-0077 | PDF 330 -->
Dewar, Susan. “Beijing Report.” *art* *Asia Pacific* 3.1 (1996): 101–2.

<!-- eb-bibliography-entry-0078 | PDF 330 -->
Ding Ling. “Thoughts on March 8.” In *I Myself Am a Woman: Selected Writings of Ding Ling*, ed. Tani E. Barlow with Gary J. Bjorge, 316–21. Boston: Beacon Press, 1989.

<!-- eb-bibliography-entry-0079 | PDF 330 -->
Dominguez, Virginia. “A Taste for the ‘Other’: Intellectual Complicity in Racializing Practices.” *Current Anthropology* 35.4 (1993): 333–48.

<!-- eb-bibliography-entry-0080 | PDF 330 -->
Dong, Madeleine Yue. “Defining Beiping: Urban Reconstruction and National Identity, 1928–1936.” In *Remaking the Chinese City: Modernity and National Identity*, *1900–1950*, ed. Joseph W. Esherick, 121–38. Honolulu: University of Hawaii Press, 1999.

<!-- eb-bibliography-entry-0081 | PDF 330 -->
Dooling, Amy. *Women’s Literary Feminism in Twentieth-Century China*. New York: Palgrave Macmillan, 2005.

<!-- eb-bibliography-entry-0082 | PDF 330 -->
Dreyer, June Teufel. *China’s Political System: Modernization and Tradition*. New York: Paragon House, 1993.

<!-- eb-bibliography-entry-0083 | PDF 330 -->
Duara, Prasenjit. *Rescuing History from the Nation: Questioning Narratives of Modern China*. Chicago: University of Chicago Press, 1995.

<!-- eb-bibliography-entry-0084 | PDF 330 -->
Du Bois, W. E. B. *The Souls of Black Folk*. Ed. by Henry Louis Gates Jr. with Terri Hume Oliver. New York: W. W. Norton, 1999.

<!-- eb-bibliography-entry-0085 | PDF 330 -->
Dutton, Michael. *Streetlife China*. Cambridge, MA: Cambridge University Press, 1998.

<!-- eb-bibliography-entry-0086 | PDF 330 -->
Eberlein, Xujun. “Another Kind of American History in Chongqing.” *The Atlantic*, January 31-February 4, 2011.

<!-- eb-bibliography-entry-0087 | PDF 330 -->
Engels, Friedrich. “Socialism: Utopian and Scientific.” In *The Marx-Engels Reader*, ed. Robert C. Tucker, 683–717. 1880; reprint New York: Norton, 1978.

<!-- eb-bibliography-entry-0088 | PDF 330 -->
Erickson, Britta. “The Reception in the West of Experimental Mainland Chinese Art of the 1990s.” In *Chinese Contemporary Art: Primary Documents*, ed. Wu Hung, 357–62. New York: Museum of Modern Art, 2010.

<!-- eb-bibliography-entry-0089 | PDF 330 -->
———. “The Rise of a Feminist Spirit in Contemporary Chinese Art.” *art* *AsiaPacific* 31 (2001): 64–71.

<!-- eb-bibliography-entry-0090 | PDF 330 -->
Faier, Lieba. *Intimate Encounters: Filipina Women and the Remaking of Rural Japan*. Berkeley: University of California Press, 2009.

<!-- eb-bibliography-entry-0091 | PDF 330 -->
Faier, Lieba, and Lisa Rofel. “Ethnographies of Encounter.” *Annual Review of Anthropology* 43 (2014): 363–77.

<!-- eb-bibliography-entry-0092 | PDF 330 -->
Fang Ke. *Dangdai Beijing jiucheng gengxin: diaocha*, *yanjiu*, *tansuo* (Contemporary conservation in the inner city of Beijing: survey, analysis, and investigation). Beijing: Zhongguo jianzhu gongye chubanshe, 2000.

<!-- eb-bibliography-entry-0093 | PDF 330 -->
Feng Jiali. “Limitless Difference: On Being a Chinese Woman Artist.” *art* *AsiaPacific* 31 (2001): 66–71.

<!-- eb-bibliography-entry-0094 | PDF 330 -->
Feuerwerker, Yi-tsi Mei. *Ding Ling’s Fiction: Ideology and Narrative in Modern Chinese Literature*. Cambridge, MA: Harvard University Press, 1982.

<!-- eb-bibliography-entry-0095 | PDF 330 -->
Fok, Silvia. *Life and Death: Art and the Body in Contemporary China*. Chicago: Intellect, 2013.

<!-- eb-bibliography-entry-0096 | PDF 330 -->
Foster, Hal. *The Return of the Real*. Cambridge, MA: mit Press, 1996.

<!-- eb-bibliography-entry-0097 | PDF 330 -->
Foucault, Michel. *The Order of Things: An Archaeology of the Human Sciences*. New York: Pantheon Books, 1971.

<!-- eb-bibliography-entry-0098 | PDF 330 -->
Friedman, Alison. E-mail communication. January 3, 2004.

〔原书第310页〕

<!-- eb-bibliography-entry-0099 | PDF 331 -->
Gao Minglu. “Foreword.” In *Dialogue*, Xiao Lu, trans. Archibald McKenzie, vii–xv. Hong Kong: Hong Kong University Press, 2010.

<!-- eb-bibliography-entry-0100 | PDF 331 -->
———. “From Elite to Small Man: The Many Faces of a Transitional Avant-Garde in Mainland China.” In *Inside Out: New Chinese Art*, 149–66. New York and San Francisco: Asia Society Galleries and San Francisco Museum of Modern Art, 1998.

<!-- eb-bibliography-entry-0101 | PDF 331 -->
———, ed. *Inside Out: New Chinese Art*. New York and San Francisco: Asia Society Galleries and San Francisco Museum of Modern Art, 1998.

<!-- eb-bibliography-entry-0102 | PDF 331 -->
———. Interview with Yin Xiuzhen. In *Fengshou: Dangdai yizhu zhang* (Harvest: Contemporary art exhibit). Beijing: National Agricultural Museum, 2002.

<!-- eb-bibliography-entry-0103 | PDF 331 -->
———. *Total Modernity and the Avant-Garde in Twentieth-Century Chinese Art*. Cambridge, MA: mit Press, 2011.

<!-- eb-bibliography-entry-0104 | PDF 331 -->
———. *The Wall: Reshaping Contemporary Chinese Art*. Buffalo and Beijing: Albright Knox Art Gallery, University of Buffalo Art Galleries, and Millennium Art Museum, 2005.

<!-- eb-bibliography-entry-0105 | PDF 331 -->
Gardner, Lyn. “China Live.” *The Guardian*, October 28, 2005.

<!-- eb-bibliography-entry-0106 | PDF 331 -->
Gell, Alfred. *Art and Agency: An Anthropological Theory*. New York: Oxford University Press, 1998.

<!-- eb-bibliography-entry-0107 | PDF 331 -->
Gilmartin, Christina. *Engendering the Chinese Revolution: Radical Women*, *Communist Politics*, *and Mass Movements in the 1920s*. Berkeley: University of California Press, 1995.

<!-- eb-bibliography-entry-0108 | PDF 331 -->
Goethe, Johann Wolfgang von, and Johann Peter Eckermann. *Conversations with Eckermann*. 1850; reprint San Francisco: North Point Press, 1984.

<!-- eb-bibliography-entry-0109 | PDF 331 -->
Guang, Lei. “Rural Taste, Urban Fashions: The Cultural Politics of Rural/Urban Difference in Contemporary China.” *positions: east asia cultures critique* 11.3 (2003): 613–46.

<!-- eb-bibliography-entry-0110 | PDF 331 -->
Guilbaut, Serge. *How New York Stole the Idea of Modern Art: Abstract Expressionism*, *Freedom*, *and the Cold War*. Chicago: University of Chicago Press, 1983.

<!-- eb-bibliography-entry-0111 | PDF 331 -->
de Guzman, René. E-mail communication. November 19, 2002.

<!-- eb-bibliography-entry-0112 | PDF 331 -->
———. “Something about the Bay.” *Time After Time: Asia and Our Moment* exhibition wall text, 2003.

<!-- eb-bibliography-entry-0113 | PDF 331 -->
Halbreich, Kathy. “Foreword.” In *How Latitudes Become Forms: Art in a Global Age*, ed. Philippe Vergne, Vasif Kortun and Hanru Hou, 4–5. Minneapolis: Walker Art Center, 2003.

<!-- eb-bibliography-entry-0114 | PDF 331 -->
Haraway, Donna. “Situated Knowledges: The Science Question in Feminism and the Privilege of Partial Perspective.” *Feminist Studies* 14.3 (1988): 575–99.

<!-- eb-bibliography-entry-0115 | PDF 331 -->
Harman, Graham. *Tool-Beijing: Heidegger and the Metaphysics of Objects*. Chicago: Open Court, 2002.

<!-- eb-bibliography-entry-0116 | PDF 331 -->
Hartman, Chester, with Sarah Carnochan. *City for Sale: The Transformation of San Francisco*. Berkeley: University of California Press, 2002.

<!-- eb-bibliography-entry-0117 | PDF 331 -->
He Chengyao. E-mail communication. March 2, 2003.

<!-- eb-bibliography-entry-0118 | PDF 331 -->
———. “In the Mirror.” *Chinese Contemporary Art* 4.5 (2001). Accessed August 7, 2006. www.chinese-art.com/Contemporary/volumefourissue5/beijing2_2 .htm.

〔原书第311页〕

<!-- eb-bibliography-entry-0119 | PDF 332 -->
He Mai. “On He Chengyao.” *Chinese Contemporary Art* 4.5 (2001). Accessed August 7, 2007. http://www.chinese-art.com/Contemporary/volumefourissue5/beijing2_2 .htm.

<!-- eb-bibliography-entry-0120 | PDF 332 -->
Heidegger, Martin. “The Origin of the Work of Art.” In *Basic Writings*, 149–87. New York: Harper & Row, 1977.

<!-- eb-bibliography-entry-0121 | PDF 332 -->
“Helping Migrants Belong in Cities.” *China Daily*, November 28, 2003. www.china daily.com.cn/en.

<!-- eb-bibliography-entry-0122 | PDF 332 -->
Hemming, Clare. *Why Stories Matter: The Political Grammar of Feminist Theory*. Durham, NC: Duke University Press, 2011.

<!-- eb-bibliography-entry-0123 | PDF 332 -->
Hernández, Javier C. “With Odes to Military March, China Puts Nationalism into Overdrive.” *New York Times*, November 14, 2016.

<!-- eb-bibliography-entry-0124 | PDF 332 -->
Hernández-Reguant, Ariana. “Copyrighting Che: Art and Authorship under Cuban Late Socialism.” *Public Culture* 16.1 (2004): 1–29.

<!-- eb-bibliography-entry-0125 | PDF 332 -->
Hershatter, Gail. “Disquiet in the House of Gender.” *Journal of Asian Studies* 71.4 (2012): 873–94.

<!-- eb-bibliography-entry-0126 | PDF 332 -->
———. *Women in China’s Long Twentieth Century*. Berkeley: University of California Press, 2007.

<!-- eb-bibliography-entry-0127 | PDF 332 -->
Hershatter, Gail, Emily Honig, and Lisa Rofel. “Reflections on the Fourth World Conference on Women, Beijing and Huairou.” *Social Justice* 23.1–2 (1995): 368–75.

<!-- eb-bibliography-entry-0128 | PDF 332 -->
Hevia, James. “Looting Beijing: 1860, 1900.” In *Tokens of Exchange: The Problem of Translation in Global Circulations*, ed. Lydia H. Liu, 192–213. Durham, NC: Duke University Press, 1999.

<!-- eb-bibliography-entry-0129 | PDF 332 -->
He-Yin Zhen. “On Feminist Antimilitarism.” In *The Birth of Chinese Feminism: Essential Texts in Transnational Theory*, ed. Lydia H. Liu, Rebecca E. Karl, and Dorothy Ko, 169–78. New York: Columbia University Press, 2013.

<!-- eb-bibliography-entry-0130 | PDF 332 -->
Honig, Emily. “Socialist Sex: The Cultural Revolution Revisited.” *Modern China* 29.2 (2003): 143–75.

<!-- eb-bibliography-entry-0131 | PDF 332 -->
Huang Du. “Yishu, wenti, cehuaren: si wei guoji zhuming cehuaren fangtan” (Art, questions, curators: discussions with four internationally renowned curators). *Jinri xianfeng* (Avant-garde today) 11 (2001): 39–64.

<!-- eb-bibliography-entry-0132 | PDF 332 -->
Huang, Philip C. C. “Biculturality in Modern China and in Chinese Studies.” *Modern China* 26.1 (2000): 3–31.

<!-- eb-bibliography-entry-0133 | PDF 332 -->
Huang Shuqin (director). *Hua hun* (A soul haunted by painting). 1994; reproduced Tappan, NY: Knight Mediacom, 2004.

<!-- eb-bibliography-entry-0134 | PDF 332 -->
Ishihara, Shintarō, and Akio Morita. *The Japan That Can Say No*. New York: Simon & Schuster, 1989.

<!-- eb-bibliography-entry-0135 | PDF 332 -->
Ivy, Marilyn. *Discourses of the Vanishing: Modernity*, *Phantasm*, *Japan*. Chicago: University of Chicago Press, 1995.

<!-- eb-bibliography-entry-0136 | PDF 332 -->
Jacka, Tamara. “Back to the Wok: Women and Employment in Chinese Industry in the 1980s.” *Australian Journal of Chinese Affairs* 24 (1990): 1–23.

<!-- eb-bibliography-entry-0137 | PDF 332 -->
Jamieson, Kathleen Hall. *Beyond the Double Bind: Women and Leadership*. New York: Oxford University Press, 1995.

<!-- eb-bibliography-entry-0138 | PDF 332 -->
Jia Fangzhou. “Preface.” In *Shijie nüxing* (Century Woman), 8–9. Hong Kong: Shijie huaren yishu chubanshe, 1998.

〔原书第312页〕

<!-- eb-bibliography-entry-0139 | PDF 333 -->
Jim, Alice Ming Wai. “The Different Worlds of Cao Fei.” In *Mass Effect: Art and the Internet in the Twenty-First Century*, ed. Lauren Cornell and Ed Halter, 89–97. Cambridge, MA: mit Press, 2015.

<!-- eb-bibliography-entry-0140 | PDF 333 -->
Joffe, Ellis. “The Chinese Army in the Cultural Revolution: The Politics of Intervention.” *Current Scene: Developments in Mainland China* 8.18 (1970): 1–25.

<!-- eb-bibliography-entry-0141 | PDF 333 -->
Johnson, Deborah. “The Secularization of the Sacred: Judy Chicago’s Dinner Party and Feminist Spirituality (1975–79).” In *Women Making Art: Women in the Visual*, *Literary*, *and Performing Arts Since 1960*, ed. Deborah Johnson and Wendy Oliver. New York: Peter Lang, 2001.

<!-- eb-bibliography-entry-0142 | PDF 333 -->
Johnson, Kay Ann. *Women*, *the Family*, *and Peasant Revolution in China*. Chicago: University of Chicago Press, 1983.

<!-- eb-bibliography-entry-0143 | PDF 333 -->
Jones, Amelia. *Postmodernism and the En-Gendering of Marcel Duchamp*. Cambridge: Cambridge University Press, 1994.

<!-- eb-bibliography-entry-0144 | PDF 333 -->
———. “The Sexual Politics of *The Dinner Party*: A Critical Context.” In *Sexual Politics: Judy Chicago’s* Dinner Party *in Feminist Art History*, ed. Amelia Jones, 82–118. Berkeley: University of California Press, 1996.

<!-- eb-bibliography-entry-0145 | PDF 333 -->
Judge, Joan. *The Precious Raft of History: The Past*, *the West*, *and the Woman Question in China*. Stanford: Stanford University Press, 2008.

<!-- eb-bibliography-entry-0146 | PDF 333 -->
———. *Republican Lens: Gender*, *Visuality*, *and Experience in the Early Chinese Periodical Press*. Berkeley: University of California Press, 2015.

<!-- eb-bibliography-entry-0147 | PDF 333 -->
Judovitz, Dalia. *Unpacking Duchamp: Art in Transit*. Berkeley: University of California Press, 1995.

<!-- eb-bibliography-entry-0148 | PDF 333 -->
Kang Wenqing. “The Decriminalization and Depathologization of Homosexuality in China.” In China in and beyond the Headlines, ed. Timothy B. Weston and Lionel M. Jensen, 231–248. Lanham, MD: Rowman & Littlefield, 2012.

<!-- eb-bibliography-entry-0149 | PDF 333 -->
Karetzky, Patricia Eichenbaum. *Femininity in Contemporary Asian Art: If the Shoe Fits and Vernal Visions*. New York: Lehman College Art Gallery, 2002.

<!-- eb-bibliography-entry-0150 | PDF 333 -->
Karl, Rebecca E. *Staging the World: Chinese Nationalism at the Turn of the Twentieth Century*. Durham, NC: Duke University Press, 2002.

<!-- eb-bibliography-entry-0151 | PDF 333 -->
Khullar, Sonal. “Parallel Tracks: Pan Yuliang and Amrita Sher-Gil in Paris.” In *Eurasian Encounters: Museums*, *Missions*, *Modernities*, ed. Carolien Stolte and Yoshiyuki Kikuchi, 73–102. Amsterdam: Amsterdam University Press, 2017.

<!-- eb-bibliography-entry-0152 | PDF 333 -->
———. *Worldly Affiliations: Artistic Practice*, *National Identity*, *and Modernism in India*, *1930–1990*. Berkeley: University of California Press, 2015.

<!-- eb-bibliography-entry-0153 | PDF 333 -->
Khullar, Sonal, and Sasha Su-Ling Welland. “New Geographies of Feminist Art: China, Asia, and the World International Conference.” University of Washington, Seattle. November 16, 2012. Introductory Address. depts.washington.edu/newgeos.

<!-- eb-bibliography-entry-0154 | PDF 333 -->
Kim, Elaine. *Asian American Literature: An Introduction to the Writings and Their Social Context*. Philadelphia: Temple University Press, 1982.

<!-- eb-bibliography-entry-0155 | PDF 333 -->
Kimmelmann, Michael. “At the Whitney, Sound, Fury and Little Else.” *New York Times*, April 25, 1993.

<!-- eb-bibliography-entry-0156 | PDF 333 -->
———. “A Few Artless Minutes on ‘60 Minutes.’ ” *New York Times*, October 17, 1993.

<!-- eb-bibliography-entry-0157 | PDF 333 -->
King, Dean. *Unbound: A True Story of War*, *Love*, *and Survival*. New York: Little, Brown, 2010.

〔原书第313页〕

<!-- eb-bibliography-entry-0158 | PDF 334 -->
Kingston, Tom. “Far Pavilions: Venice Biennale Opens Its Doors to the World.” *The Guardian*, January 5, 2011.

<!-- eb-bibliography-entry-0159 | PDF 334 -->
Kirshenblatt-Gimblett, Barbara. *Destination Culture: Tourism*, *Museums*, *and Heritage*. Berkeley: University of California Press, 1998.

<!-- eb-bibliography-entry-0160 | PDF 334 -->
Klayman, Alison. *Ai Weiwei: Never Sorry*. dvd. Orland Park, IL: mpi Media Group, 2012.

<!-- eb-bibliography-entry-0161 | PDF 334 -->
Kraus, Richard Curt. *Brushes with Power: Modern Politics and the Chinese Art of Calligraphy*. Berkeley: University of California Press, 1991.

<!-- eb-bibliography-entry-0162 | PDF 334 -->
———. *The Party and the Arty in China: The New Politics of Culture*. Lanham, MD: Rowman & Littlefield, 2004.

<!-- eb-bibliography-entry-0163 | PDF 334 -->
Krauss, Rosalind E. *Bachelors*. Cambridge, MA: mit Press, 1999.

<!-- eb-bibliography-entry-0164 | PDF 334 -->
———. *The Originality of the Avant-Garde and Other Modernist Myths*. Cambridge, MA: mit Press, 1994.

<!-- eb-bibliography-entry-0165 | PDF 334 -->
———. “Sculpture in the Expanded Field.” *October* 8 (1979): 30–44.

<!-- eb-bibliography-entry-0166 | PDF 334 -->
Kristeva, Julia. *About Chinese Women*. London: M. Boyars, 1977.

<!-- eb-bibliography-entry-0167 | PDF 334 -->
———. *Desire in Language: A Semiotic Approach to Literature and Art*. New York: Columbia University Press, 1980.

<!-- eb-bibliography-entry-0168 | PDF 334 -->
Kwon, Miwon. *One Place after Another: Site-Specific Art and Locational Identity*. Cambridge, MA: mit Press, 2002.

<!-- eb-bibliography-entry-0169 | PDF 334 -->
Landsberger, Stefan. “Lei Feng.” *Chinese Posters: Propaganda*, *Politics*, *History*, *Art*. Accessed September 11, 2015. http://chineseposters.net/themes/leifeng.php.

<!-- eb-bibliography-entry-0170 | PDF 334 -->
Lao She. *Rickshaw Boy*. Trans. Howard Goldblatt. New York: Harper Perennial, 2010.

<!-- eb-bibliography-entry-0171 | PDF 334 -->
Le Xianghai. “Jingcheng liulang yishujia de xingfu shenghuo” (The happy life of vagrant Beijing artists). *Dongfang yishu* (Oriental art) 47 (May 2001): 10–31.

<!-- eb-bibliography-entry-0172 | PDF 334 -->
Lee, Leo Ou-fan. “Tradition and Modernity in the Writings of Lu Xun.” In *Lu Xun and His Legacy*, ed. Leo Ou-fan Lee, 3–31. Berkeley: University of California Press, 1985.

<!-- eb-bibliography-entry-0173 | PDF 334 -->
Lee, Lily Xiao Hong, and Sue Wiles. *Women of the Long March*. St. Leonards: Allen & Unwin, 1999.

<!-- eb-bibliography-entry-0174 | PDF 334 -->
Lei Yan. “Bingdong: baoliu jiyi de fangfa” (Frozen: method of preserving memory), interview with Mao Xuhui. *Artintern* blog, January 6, 2001. Accessed September 11, 2015. http://blog.artintern.net/article/172527.

<!-- eb-bibliography-entry-0175 | PDF 334 -->
Li Dazhao. “Qingnian yu nongcun” (Youth and the countryside). In *Li Dazhao xuanji* (Selected works of Li Dazhao), 146–50. Beijing: Renmin chubanshe, 1959.

<!-- eb-bibliography-entry-0176 | PDF 334 -->
Li Ming and Xu Qian. *Yuanyang lixiang: yuanyang yishu zhongxin huigu ji* (A review of the East Modern Art Center). Beijing: Zuojia chubanshe, 2004.

<!-- eb-bibliography-entry-0177 | PDF 334 -->
Li Tianpian. *Youhua renti jifa rumen aomi* (Introduction to mastering figurative techniques in oil painting). Shenyang: Liaoning meishu chanbanshe, 1999.

<!-- eb-bibliography-entry-0178 | PDF 334 -->
———. Interview by author. Beijing. May 22, 2001.

<!-- eb-bibliography-entry-0179 | PDF 334 -->
Liao Wen. *Zhongguo dangdai yishu zhong de nüxing fangshi* (Women’s approach to Chinese contemporary art). Beijing: Beijing yishu bowuguan, 1995.

<!-- eb-bibliography-entry-0180 | PDF 334 -->
———. *Nüxingzhuyi zuowei fangshi: nüxing yishu* (Feminism as method: women’s art). Jilin: Jilin meishu chubanshe, 1999.

〔原书第314页〕

<!-- eb-bibliography-entry-0181 | PDF 335 -->
———. “ ‘Women’s Art’ as Part of Contemporary Chinese Art since 1990.” In *Reinterpretation: A Decade of Experimental Chinese Art* (*1990–2000*), ed. Wu Hung and Karen Smith, 60–66. Guangzhou: Guangdong Museum of Art, 2002.

<!-- eb-bibliography-entry-0182 | PDF 335 -->
Lin Wenzheng. “Shoudu meishu zhanlan hui zhi yiyi” (The significance of the *Capital Fine Arts Exhibition*). In *Xihu lun yi: Lin Fengmian jiqi tongshi yishu wenji* (The West Lake essays on art: Collection of essays on art by Lin Fengmian and his colleagues), ed. Zheng Chao, 461–4. 2 vols. Hangzhou: Zhongguo meishu xue yuan, 1999.

<!-- eb-bibliography-entry-0183 | PDF 335 -->
Lin Zi. *Yuan nüxing yishu* (Natural feminine art). Kunming: Yunnan meishu chubanshe, 1995.

<!-- eb-bibliography-entry-0184 | PDF 335 -->
Liu, Lydia H. *Translingual Practice: Literature*, *National Culture*, *and Translated Modernity—China*, *1900–1937*. Stanford: Stanford University Press, 1995.

<!-- eb-bibliography-entry-0185 | PDF 335 -->
———. “Robinson Crusoe’s Earthenware Pot.” *Critical Inquiry* 25.4 (1999): 728–57.

<!-- eb-bibliography-entry-0186 | PDF 335 -->
Liu, Lydia H., Rebecca E. Karl, and Dorothy Ko, eds. *The Birth of Chinese Feminism: Essential Texts in Transnational Theory*. New York: Columbia University Press, 2013.

<!-- eb-bibliography-entry-0187 | PDF 335 -->
Liu Minzhi. “Zhongguo zhi nü feixingjia” (China’s female pilot). *Funü* *shibao* (The women’s eastern times) 20 (October 1916): 81–83.

<!-- eb-bibliography-entry-0188 | PDF 335 -->
Liu Xin. *In One’s Own Shadow: An Ethnographic Account of the Condition of Post-reform Rural China*. Berkeley: University of California Press, 2000.

<!-- eb-bibliography-entry-0189 | PDF 335 -->
Logan, John R., and Harvey L. Molotch. *Urban Fortunes: The Political Economy of Place*. Berkeley: University of California Press, 1987.

<!-- eb-bibliography-entry-0190 | PDF 335 -->
Long March Project. “Curatorial Plan: Site 6.” Accessed September 10, 2015. www .longmarchproject.com/english/esite6.htm.

<!-- eb-bibliography-entry-0191 | PDF 335 -->
———. “Exhibition at Qidi shanzhuang.” Accessed September 10, 2015. http://www .longmarchproject.com/images/o-site6/yszp/qdsz/e-index.htm.

<!-- eb-bibliography-entry-0192 | PDF 335 -->
Lowe, Lisa. *Immigrant Acts: On Asian American Cultural Politics*. Durham, NC: Duke University Press, 1996.

<!-- eb-bibliography-entry-0193 | PDF 335 -->
Lü Peng. *Zhongguo dangdai yishu shi* (Chinese contemporary art history). Changsha: Hunan meishu chubanshe, 2000.

<!-- eb-bibliography-entry-0194 | PDF 335 -->
Lu Xun. *Lu Hsun Selected Stories*. Trans. Yang Hsien-yi and Gladys Yang. New York: W. W. Norton, 1977.

<!-- eb-bibliography-entry-0195 | PDF 335 -->
Luttge, Thomas. *HA Schult: Art is Action*. Berlin: Wasmuth, 2002.

<!-- eb-bibliography-entry-0196 | PDF 335 -->
Mahathir bin Mohamad, and Ishihara Shintarō. *The Voice of Asia: Two Leaders Discuss the Coming Century* (“Nō” to ieru Ajia). New York: Kodansha International, 1995.

<!-- eb-bibliography-entry-0197 | PDF 335 -->
Mani, Lata. *Contentious Traditions: The Debate on Sati in Colonial India*. Berkeley: University of California Press, 1998.

<!-- eb-bibliography-entry-0198 | PDF 335 -->
“Manifesto of the Art Movement Society.” In *Shanghai Modern*, *1919–1945*, ed. Jo-Anne Birnie Danzker, Ken Lum, and Shengtian Zheng, 373. 1929; reprint Ostfildern-Ruit: Hatje Cantz, 2004.

<!-- eb-bibliography-entry-0199 | PDF 335 -->
Mann, Susan. *Gender and Sexuality in Modern Chinese History*. New York: Cambridge University Press, 2011.

<!-- eb-bibliography-entry-0200 | PDF 335 -->
Mao, Christophe W., ed. *Chopsticks*. New York: Chambers Fine Art, 2002.

<!-- eb-bibliography-entry-0201 | PDF 335 -->
Mao Zedong. *Selected Readings from the Works of Mao Tse-tung*. Beijing: Foreign Languages Press, 1967.

〔原书第315页〕

<!-- eb-bibliography-entry-0202 | PDF 336 -->
McDougall, Bonnie S. *Mao Zedong’s “Talks at the Yan’an Conference on Literature and Art”: A Translation of the 1943 Text with Commentary*. Ann Arbor: University of Michigan Center for Chinese Studies, 1980.

<!-- eb-bibliography-entry-0203 | PDF 336 -->
McRobbie, Angela. *The Aftermath of Feminism: Gender*, *Culture*, *and Social Change*. London: Sage, 2008.

<!-- eb-bibliography-entry-0204 | PDF 336 -->
Merewether, Charles. “The Spectre of Being Human.” *Yishu: Journal of Contemporary Art* 2.2 (2003): 59–63.

<!-- eb-bibliography-entry-0205 | PDF 336 -->
Mohanty, Chandra Talpade. “Under Western Eyes: Feminist Scholarship and Colonial Discourses.” In *Third World Women and the Politics of Feminism*, ed. Chandra Talpade Mohanty, Ann Russo, and Lourdes Torres, 51–80. Bloomington: Indiana University Press, 1991.

<!-- eb-bibliography-entry-0206 | PDF 336 -->
Mooney, Paul. “Forgiveness Permitting.” *Silkroad* (Dragonair in-flight magazine) (May 1999): 6–8.

<!-- eb-bibliography-entry-0207 | PDF 336 -->
Mullaney, Thomas. “Ethnic Classification Writ Large.” *China Information* 18.2 (2004): 207–41.

<!-- eb-bibliography-entry-0208 | PDF 336 -->
Myers, Fred R. *Painting Culture: The Making of an Aboriginal High Art*. Durham, NC: Duke University Press, 2002.

<!-- eb-bibliography-entry-0209 | PDF 336 -->
Narayan, Kirin. “How Native is a ‘Native’ Anthropologist?” *American Anthropologist* 95.2 (1993): 671–86.

<!-- eb-bibliography-entry-0210 | PDF 336 -->
Nedoshivin, German. “Lun huihua zhong de dianxing wenti” (On the problem of the typical in painting). *Meishu* (Fine arts) 1 (1954): 41–50.

<!-- eb-bibliography-entry-0211 | PDF 336 -->
Newman, Elysse (visiting assistant professor, Washington University). Personal Communication. St. Louis. November 25, 2002.

<!-- eb-bibliography-entry-0212 | PDF 336 -->
Nochlin, Linda. “Why Have There Been No Great Women Artists?” *Art News* 69 ( January 1971): 22–39.

<!-- eb-bibliography-entry-0213 | PDF 336 -->
———. *Women*, *Art*, *and Power and Other Essays*. New York: Harper and Row, 1988.

<!-- eb-bibliography-entry-0214 | PDF 336 -->
Oldenziel, Ruth, and Karin Zachmann. *Cold War Kitchen: Americanization*, *Technology*, *and European Users*. Cambridge, MA: mit Press, 2009.

<!-- eb-bibliography-entry-0215 | PDF 336 -->
Ono, Kazuko. *Chinese Women in a Century of Revolution*. Trans. Joshua A. Fogel. Stanford: Stanford University Press, 1989.

<!-- eb-bibliography-entry-0216 | PDF 336 -->
*Pan Yuliang meishu zuopin xuanji* (Pan Yuliang selected artworks). Nanjing: Jiangsu meishu chubanshe, 1988.

<!-- eb-bibliography-entry-0217 | PDF 336 -->
Pang Laikwan. “ ‘China Who Makes and Fakes’: A Semiotics of the Counterfeit.” *Theory*, *Culture and Society* 25.6 (2008): 117–40.

<!-- eb-bibliography-entry-0218 | PDF 336 -->
Parker, Rozsika, and Griselda Pollock. *Old Mistresses: Women*, *Art*, *and Ideology*. New York: Pantheon Books, 1981.

<!-- eb-bibliography-entry-0219 | PDF 336 -->
Poggioli, Renato. *The Theory of the Avant-Garde*. Trans. Gerald Fitzgerald. Cambridge, MA: Belknap Press, 1968.

<!-- eb-bibliography-entry-0220 | PDF 336 -->
Pollock, Griselda. *Differencing the Canon: Feminist Desire and the Writing of Art’s Histories*. New York: Routledge, 1999.

<!-- eb-bibliography-entry-0221 | PDF 336 -->
Poole, Deborah. *Vision*, *Race*, *and Modernity: A Visual Economy of the Andean Image World*. Princeton: Princeton University Press, 1997.

<!-- eb-bibliography-entry-0222 | PDF 336 -->
Povinelli, Elizabeth A. *Economies of Abandonment: Social Belonging and Endurance in Late Liberalism*. Durham, NC: Duke University Press, 2011.

〔原书第316页〕

<!-- eb-bibliography-entry-0223 | PDF 337 -->
Pu Songling. *Selected Tales of Liaozhai*. Beijing: Panda Books, 1981.

<!-- eb-bibliography-entry-0224 | PDF 337 -->
Qian Zhongshu. *Fortress Besieged*. Trans. Jeanne Kelly and Nathan K. Mao. New York: New Directions, 2004.

<!-- eb-bibliography-entry-0225 | PDF 337 -->
Qin, Amy. “China’s Artists to Be Taught ‘Correct View’ in New Plan.” *New York Times Sinophere Blog*, December 2, 2014. sinosphere.blogs.nytimes.com.

<!-- eb-bibliography-entry-0226 | PDF 337 -->
Quadrio, Davide. “A Dramatic ‘Second Life’ for Cao Fei.” *Flash Art* 63.270 (2010): 38.

<!-- eb-bibliography-entry-0227 | PDF 337 -->
Rofel, Lisa. *Desiring China: Experiments in Neoliberalism*, *Sexuality*, *and Public Culture*. Durham, NC: Duke University Press, 2007.

<!-- eb-bibliography-entry-0228 | PDF 337 -->
Ruwitch, John W. *Lei Feng and the “Learn from Lei Feng” Campaign of 1963: Mao*, *P*.*R*.*C*. *Politics*, *and Hagiography as a Political Tool*. Master’s Thesis, University of California Santa Cruz, 1996.

<!-- eb-bibliography-entry-0229 | PDF 337 -->
Ryan, Richard. “The Whitney Fiasco and the Critics.” *Commentary* 96.1 (1993): 51–4.

<!-- eb-bibliography-entry-0230 | PDF 337 -->
Said, Edward W. *Orientalism*. New York: Vintage Books, 1979.

<!-- eb-bibliography-entry-0231 | PDF 337 -->
Sandoval, Chela. *Methodology of the Oppressed*. Minneapolis: University of Minnesota Press, 2000.

<!-- eb-bibliography-entry-0232 | PDF 337 -->
Sassen, Saskia. *The Global City: New York*, *London*, *Tokyo*. Princeton: Princeton University Press, 1991.

<!-- eb-bibliography-entry-0233 | PDF 337 -->
Shao Qin. “Exhibiting the Modern: The Creation of the First Chinese Museum, 1905–1930.” *China Quarterly* 179 (2004): 684–702.

<!-- eb-bibliography-entry-0234 | PDF 337 -->
Sheng Hai. Video recording of Judy Chicago in conversation with Chinese artists. Beijing. July 21, 2002.

<!-- eb-bibliography-entry-0235 | PDF 337 -->
Shi Nan. *Hua hun: Zhang Yuliang zhuan* (Soul of a painter: Biography of Zhang Yuliang). Beijing: Renmin wenxue chubanshe, 1983.

<!-- eb-bibliography-entry-0236 | PDF 337 -->
Shi Xia. “Wei Cheng: From an Elite Novel to a Popular Metaphor.” In *China in 2008: A Year of Great Significance*, ed. by Kate Merkel-Hess, Kenneth L. Pomeranz, and Jeffrey N. Wasserstrom, 248–51. Lanham, MD: Rowman & Littlefield, 2009.

<!-- eb-bibliography-entry-0237 | PDF 337 -->
Shichor, Yitzhak. “Demobilization: The Dialectics of pla Troop Reduction.” In *China’s Military in Transition*, ed. Richard H. Yang, 72–95. Oxford: Claredon Press, 1997.

<!-- eb-bibliography-entry-0238 | PDF 337 -->
Shih Shu-mei. “From World History to World Art: Reflections on the New Geographies of Feminist Art in Asia.” Keynote Address. New Geographies of Feminist Art: China, Asia, and the World International Conference. University of Washington, Seattle. November 15, 2012.

<!-- eb-bibliography-entry-0239 | PDF 337 -->
———. *The Lure of the Modern: Writing Modernism in Semicolonial China*, *1917–1937*. Berkeley: University of California Press, 2001.

<!-- eb-bibliography-entry-0240 | PDF 337 -->
———. “Towards and Ethics of Transnational Encounter, or ‘When’ Does a ‘Chinese’ Woman Become a ‘Feminist’?” *differences: A Journal of Feminist Cultural Studies* 13.2 (2002): 90–126.

<!-- eb-bibliography-entry-0241 | PDF 337 -->
Shu Yang. *Zhongguo yingxiang huihua* (China’s photographic painting). Hong Kong: Xianggang wenhua Zhongguo chubanshe, 2004.

<!-- eb-bibliography-entry-0242 | PDF 337 -->
Shui Chilian. “Kaifang Jinshanling” (Opening Jinshanling). *Shijue 21* (Vision 21) 4 (August 2001): 77.

<!-- eb-bibliography-entry-0243 | PDF 337 -->
Smith, Roberta. “For a Paean to Heroic Women, A Place at History’s Table.” *New York Times*, September 20, 2002, E34.

〔原书第317页〕

<!-- eb-bibliography-entry-0244 | PDF 338 -->
Song Dong. Interview by author. Beijing. February 21, 2002.

<!-- eb-bibliography-entry-0245 | PDF 338 -->
Song Qiang, Zhang Zangzang, and Bian Qiao. *Zhongguo keyi shuo bu: lengzhan hou shidai de zhengzhi yu qinggan jueze* (China can say no: a political and emotional choice of the post-Cold War era). Beijing: Zhonghua gongshang lianhe chubanshe, 1996.

<!-- eb-bibliography-entry-0246 | PDF 338 -->
Spence, Jonathan D. *The Search for Modern China*. New York: W. W. Norton, 1990.

<!-- eb-bibliography-entry-0247 | PDF 338 -->
Spivak, Gayatri Chakravorty. *In Other Worlds: Essays in Cultural Politics*. New York: Routledge, 1988.

<!-- eb-bibliography-entry-0248 | PDF 338 -->
———. “Three Women’s Texts and a Critique of Imperialism.” *Critical Inquiry* 12.1 (1985): 243–61.

<!-- eb-bibliography-entry-0249 | PDF 338 -->
———. “Translator’s Preface.” In *Of Grammatology*, Jacques Derrida, trans. Gayatri Chakravorty Spivak, xxvii-cxii. Baltimore: Johns Hopkins University Press, 2016.

<!-- eb-bibliography-entry-0250 | PDF 338 -->
Stacey, Judith. *Patriarchy and Socialist Revolution in China*. Berkeley: University of California Press, 1983

<!-- eb-bibliography-entry-0251 | PDF 338 -->
Sullivan, Michael. *Art and Artists of Twentieth-Century China*. Berkeley: University of California Press, 1996.

<!-- eb-bibliography-entry-0252 | PDF 338 -->
Sun Dongmin. “Shenghuo zai cishi” (Living in time). *Renmin ribao* (People’s daily), September 28, 2001.

<!-- eb-bibliography-entry-0253 | PDF 338 -->
Sung, Doris. *Redefining Female Talent: Chinese Women Artists in the National and Global Art Worlds*, *1900s-1970s*. PhD diss., York University, 2016.

<!-- eb-bibliography-entry-0254 | PDF 338 -->
Szeemann, Harald, and Cecilia Leveriero Lavelli, eds. *La Biennale di Venezia*, *48a Espozione Inernationale d’Art*. Venice: Marsilio, 1999.

<!-- eb-bibliography-entry-0255 | PDF 338 -->
“Talking of Women’s Liberation.” *Peking Review* 16.10 (1973): 12–15.

<!-- eb-bibliography-entry-0256 | PDF 338 -->
Tang Xiaobing. *Origins of the Chinese Avant-Garde: The Modern Woodcut Movement*. Berkeley: University of California Press, 2008.

<!-- eb-bibliography-entry-0257 | PDF 338 -->
Taylor, Diana. *The Archive and the Repertoire: Performing Cultural Memory in the Americas*. Durham, NC: Duke University Press, 2003.

<!-- eb-bibliography-entry-0258 | PDF 338 -->
Tomkins, Calvin. *Duchamp: A Biography*. New York: Henry Holt, 1996.

<!-- eb-bibliography-entry-0259 | PDF 338 -->
Tsao Tsing-yuan. “The Birth of the Goddess of Democracy.” In *Popular Protest and Political Culture in Modern China*, ed. Jeffrey N. Wasserstrom and Elizabeth J. Perry, 140–47. Boulder: Westview Press, 1994.

<!-- eb-bibliography-entry-0260 | PDF 338 -->
Tsing, Anna Lowenhaupt. *Friction: An Ethnography of Global Connection*. Princeton: Princeton University Press, 2005.

<!-- eb-bibliography-entry-0261 | PDF 338 -->
———. “The Global Situation.” *Cultural Anthropology* 15.3 (2000): 327–60.

<!-- eb-bibliography-entry-0262 | PDF 338 -->
———. *In the Realm of the Diamond Queen: Marginality in an Out-of-the-Way Place*. Princeton: Princeton University Press, 1993.

<!-- eb-bibliography-entry-0263 | PDF 338 -->
Tweedie, James. “The Afterlife of Art and Objects: Alain Cavalier’s ‘Thérèse.’ ” *SubStance* 33.3 (2004): 52–79.

<!-- eb-bibliography-entry-0264 | PDF 338 -->
———. “Delirious Cities and Their Cinema: On Koolhaas and Film Studies.” *Public Culture* 22.2 (2010): 369–97.

<!-- eb-bibliography-entry-0265 | PDF 338 -->
Urbina, Ian. “U.S. Flouts Is Own Advice in Procuring Overseas Clothing.” *New York Times*, December 22, 2013.

<!-- eb-bibliography-entry-0266 | PDF 338 -->
Ullens Center for Contemporary Art. *Wang Xingwei*. Beijing: Shijie tushu chuban gongsi, 2013.

〔原书第318页〕

<!-- eb-bibliography-entry-0267 | PDF 339 -->
Vasari, Giorgio. *The Lives of the Artists*. Trans. George Bull. 1550; reprint New York: Penguin Books, 1987.

<!-- eb-bibliography-entry-0268 | PDF 339 -->
Vergne, Philippe, Douglas Fogle, Olukemi Ilesanmi, and Aimee Chang. “Just How Did Latitudes Become Forms?” In *How Latitudes Become Forms: Art in a Global Age*, ed. Philippe Vergne, Vasif Kortun, and Hanru Hou, 130–42. Minneapolis: Walker Art Center, 2003.

<!-- eb-bibliography-entry-0269 | PDF 339 -->
Visser, Robin. *Cities Surround the Countryside: Urban Aesthetics in Post-Socialist China*. Durham, NC: Duke University Press, 2010.

<!-- eb-bibliography-entry-0270 | PDF 339 -->
Visweswaran, Kamala. *Fictions of Feminist Ethnography*. Minneapolis: University of Minnesota Press, 1994.

<!-- eb-bibliography-entry-0271 | PDF 339 -->
Walsh, Eileen Rose. “From Nü Guo to Nü’er Guo.” *Modern China* 31.4 (2005): 448–86.

<!-- eb-bibliography-entry-0272 | PDF 339 -->
———. “Living with the Myth of Matriarchy: The Mosuo and Tourism.” In *Tourism*, *Anthropology and China*, ed. Chee-Beng Tan, Sidney C. H. Cheung, and Hui Yang, 93–124. Bangkok: White Lotus Press, 2001.

<!-- eb-bibliography-entry-0273 | PDF 339 -->
Wang Jing. *Brand New China: Advertising*, *Media*, *and Commercial Culture*. Cambridge, MA: Harvard University Press, 2008.

<!-- eb-bibliography-entry-0274 | PDF 339 -->
———. “Culture as Leisure and Culture as Capital.” *positions: east asia cultures critique* 9.1 (2001): 69–104.

<!-- eb-bibliography-entry-0275 | PDF 339 -->
———. *High Culture Fever: Politics*, *Aesthetics*, *and Ideology in Deng’s China*. Berkeley: University of California Press, 1996.

<!-- eb-bibliography-entry-0276 | PDF 339 -->
Wang Lingzhen. “Retheorizing the Personal: Identity, Writing, and Gender in Yu Luojin’s Autobiographical Act.” *positions: east asia cultures critique* 6.2 (1998): 395–438.

<!-- eb-bibliography-entry-0277 | PDF 339 -->
Wang Meiqi. “Officializing the Unofficial: Presenting New Chinese Art to the World.” *Modern Chinese Literature and Culture* 21.1 (2009): 102–140.

<!-- eb-bibliography-entry-0278 | PDF 339 -->
Wang Min’an. “Songzhuang yishujia de cunzai fangshi” (The method of existence for Song village artists.” *Du shu* (Reading) 273 (2001): 69–73.

<!-- eb-bibliography-entry-0279 | PDF 339 -->
Wang Mingxian. “The Red Guards’ Fine Art Campaign.” In *Art and China’s Revolution*, ed. Melissa Chiu and Zheng Shengtian, 187–99. New York: Asia Society, 2008.

<!-- eb-bibliography-entry-0280 | PDF 339 -->
Wang Mingxian and Yan Shanchun. *Xin Zhongguo meishu tushi: 1966–1976* (The art history of the People’s Republic of China). Beijing: Zhongguo qingnian chubanshe, 2000.

<!-- eb-bibliography-entry-0281 | PDF 339 -->
Wang Nanhe (pseudonym). Interview by author. Beijing. August 11, 2002.

<!-- eb-bibliography-entry-0282 | PDF 339 -->
Wang Nanming. “Gonggong lixing yu kuannüxingzhuyi: Lei Yan de tupian ‘Zidan chuanguo nianqing de xin’ ” (Public reason and transfeminism: Lei Yan’s photograph *Bullet Shot through a Young Heart*). *Artintern* blog, September 10, 2011. Accessed September 11, 2015. http://blog.artintern.net/article/242794.

<!-- eb-bibliography-entry-0283 | PDF 339 -->
———. “Trans-feminist Art.” *The Research House for Asian Art*, February 10, 2013. Accessed September 11, 2015. http://www.xzine.org/rhaa/?p=966.

<!-- eb-bibliography-entry-0284 | PDF 339 -->
Wang Qingsong. Interview by author. Beijing. February 16, 2002.

<!-- eb-bibliography-entry-0285 | PDF 339 -->
Wang Zheng. *Finding Women in the State: A Socialist Feminist Revolution in the People’s Republic of China*, *1949–1964*. Oakland: University of California Press, 2017.

<!-- eb-bibliography-entry-0286 | PDF 339 -->
Wei Lai (project consultant, East Modern Art Center). Interview by author. Beijing. August 6, 2007.

〔原书第319页〕

<!-- eb-bibliography-entry-0287 | PDF 340 -->
Welland, Sasha Su-Ling. *Cruel/Loving Bodies* (Ku/ai shenti). Beijing and Shanghai: 798 Space and Duolun Museum of Modern Art, 2004.

<!-- eb-bibliography-entry-0288 | PDF 340 -->
———. *Cruel/Loving Bodies 2* (Ku/ai shenti 2). Hong Kong: Hong Kong Arts Centre and Goethe Institute, 2006.

<!-- eb-bibliography-entry-0289 | PDF 340 -->
———. “On Curating *Cruel/Loving Bodies*.” *Yishu: Journal of Contemporary Chinese Art* 4.1 (2005): 17–36.

<!-- eb-bibliography-entry-0290 | PDF 340 -->
———.“The Long March to Lugu Lake: A Dialogue with Judy Chicago.” *Yishu: Journal of Contemporary Chinese Art* 1.3 (2002): 69–75.

<!-- eb-bibliography-entry-0291 | PDF 340 -->
———. “Ocean Paradise.” *Journal of Visual Culture* 6.3 (2007): 420–35.

<!-- eb-bibliography-entry-0292 | PDF 340 -->
———. *A Thousand Miles of Dreams: The Journeys of Two Chinese Sisters*. Lanham, MD: Rowman & Littlefield, 2006.

<!-- eb-bibliography-entry-0293 | PDF 340 -->
———. “What Women Will Have Been: Reassessing Feminist Cultural Production in China.” *Signs: Journal of Women in Culture and Society* 31.4 (2006): 941–66.

<!-- eb-bibliography-entry-0294 | PDF 340 -->
Werner, Chris. “The Half of the Sky.” In *Die Hälfte des Himmels: chinesische Künstlerinnen der Gegenwart* (Half of the sky: contemporary Chinese women artists), ed. Chris Werner, Qiu Ping, and Marianne Pitzen, 32–7. Bonn: Frauen Museum, 1998.

<!-- eb-bibliography-entry-0295 | PDF 340 -->
Williams, Raymond. *Marxism and Literature*. Oxford: Oxford University Press, 1977.

<!-- eb-bibliography-entry-0296 | PDF 340 -->
Witke, Roxane. *Comrade Chiang Ch’ing*. Boston: Little, Brown, 1977.

<!-- eb-bibliography-entry-0297 | PDF 340 -->
Wong, Winnie Won Yin. *Van Gogh on Demand: China and the Readymade*. Chicago: University of Chicago Press, 2013.

<!-- eb-bibliography-entry-0298 | PDF 340 -->
Woronov, T. E. “In the Eye of the Chicken: Hierarchy and Marginality among Beijing’s Migrant Schoolchildren.” *Ethnography* 5.3 (2004): 289–313.

<!-- eb-bibliography-entry-0299 | PDF 340 -->
Wu Chin-tao. *Privatising Culture: Corporate Art Intervention since the 1980s*. New York: Verso, 2003.

<!-- eb-bibliography-entry-0300 | PDF 340 -->
Wu Hsiao-ching. “A Great Victory in ‘Making Foreign Things Serve China.’ ” *Chinese Literature* 5 (1969): 78–86.

<!-- eb-bibliography-entry-0301 | PDF 340 -->
Wu Hung. “A Chinese Dream by Wang Jin.” In *Globalization*, ed. Arjun Appadurai, 114–30. Durham, NC: Duke University Press, 2001.

<!-- eb-bibliography-entry-0302 | PDF 340 -->
———, ed. *Contemporary Chinese Art: Primary Documents*. New York: Museum of Modern Art, 2010.

<!-- eb-bibliography-entry-0303 | PDF 340 -->
———. *Exhibiting Experimental Art in China*. Chicago: Smart Museum, University of Chicago, 2000.

<!-- eb-bibliography-entry-0304 | PDF 340 -->
———. *Making History: Wu Hung on Contemporary Art*. Hong Kong: Timezone 8, 2008.

<!-- eb-bibliography-entry-0305 | PDF 340 -->
———. “Monumentality and Anti-monumentality in Gu Wenda’s *Forest of Stone Steles—A Retranslation and Rewriting of Tang Poetry*,” trans. David Mao. *Yishu: Journal of Contemporary Chinese Art* 4.4 (2005): 51–58.

<!-- eb-bibliography-entry-0306 | PDF 340 -->
———. *Remaking Beijing: Tiananmen Square and the Creation of a Political Space*. Chicago: University of Chicago Press, 2005.

<!-- eb-bibliography-entry-0307 | PDF 340 -->
———. *Transience: Chinese Experimental Art at the End of the Twentieth Century*. Chicago: Smart Museum, University of Chicago, 1999.

<!-- eb-bibliography-entry-0308 | PDF 340 -->
Wu Hung and Christopher Phillips. *Between Past and Future: New Photography and Video from China*. Chicago: Smart Museum, University of Chicago, 2004.

〔原书第320页〕

<!-- eb-bibliography-entry-0309 | PDF 341 -->
Wu Wenguang. *He mingong tiaowu* (Dance with farm workers). Beijing: Wu Documentary Studio, 2001. dvd, 60 min.

<!-- eb-bibliography-entry-0310 | PDF 341 -->
Wu Youru. *Wu Youru huabao* (Collected pictures of Wu Youru). 1908; reprint Shanghai: Shanghai guiji shudian, 1983.

<!-- eb-bibliography-entry-0311 | PDF 341 -->
Xiao Lu. *Dialogue*. Trans. Archibald McKenzie. Hong Kong: Hong Kong University Press, 2010.

<!-- eb-bibliography-entry-0312 | PDF 341 -->
Xiao Yang. “Yi chang nanyi dingyi de biaoyan” (A difficult-to-define performance). *Beijing qingnian* bao (Beijing youth daily), August 25, 2001.

<!-- eb-bibliography-entry-0313 | PDF 341 -->
Xiao Yu. “Yu ling yi zhong shenti gongwu” (Dancing with another kind of body). *Sanlian shenghuo zhoukan* (Sanlian life weekly), September 3, 2001.

<!-- eb-bibliography-entry-0314 | PDF 341 -->
Xie Bingying. *A Woman Soldier’s Own Story: The Autobiography of Xie Bingying*, trans. Lily Chia Brissman and Barry Brissman. New York: Columbia University Press, 2001.

<!-- eb-bibliography-entry-0315 | PDF 341 -->
Xie Dongxiao. “Beijing shi wei jiu fang gaizao de duo mubiao fenjie moshi” (Model for resolving multiple goals in Beijing’s old and dilapidated housing renewal). *Chengshi guihua* (City planning review) 31.5 (2007): 47–51, 77.

<!-- eb-bibliography-entry-0316 | PDF 341 -->
Xie Jin. *Hongse niangzi jun* (Red detachment of women). dvd. Shanghai: Shanghai dianying zhipian chang, 1961.

<!-- eb-bibliography-entry-0317 | PDF 341 -->
Xing Danwen. *Wo-men: A Personal Diary of Chinese Avant-Garde Art in the 1990s—Photographs*, *1993–1998*. Zurich: Scalo, 2004.

<!-- eb-bibliography-entry-0318 | PDF 341 -->
Xu Beihong. “I Am Bewildered.” In *Shanghai Modern*, *1919–1945*, ed. Jo-Anne Birnie Danzker, Ken Lum, and Shengtian Zheng, 373–74. 1929; reprint Ostfildern-Ruit: Hatje Cantz, 2004.

<!-- eb-bibliography-entry-0319 | PDF 341 -->
Xu Hong. “Dialogue: The Awakening of Women’s Consciousness.” In *Asian Women Artists*, ed. Dinah Dysart and Hannah Fink, 16–23. Roseville East, NSW: Craftsman House, 1996.

<!-- eb-bibliography-entry-0320 | PDF 341 -->
———. “Early 20th-Century Women Painters in Shanghai.” In *Shanghai Modern*, *1919–1945*, ed. Jo-Anne Birnie Danzker, Ken Lum, and Shengtian Zheng, 200–15. Ostfildern-Ruit: Hatje Cantz, 2004.

<!-- eb-bibliography-entry-0321 | PDF 341 -->
Xu Qian. Interview by author. Beijing. July 19, 2002.

<!-- eb-bibliography-entry-0322 | PDF 341 -->
Yamashita, Karen Tei. *I Hotel*. Minneapolis: Coffee House Press, 2010.

<!-- eb-bibliography-entry-0323 | PDF 341 -->
Yan Hairong. “Spectralization of the Rural: Reinterpreting the Labor Mobility of Rural Young Women in Post-Mao China.” *American Ethnologist* 30.4 (2003): 578–96.

<!-- eb-bibliography-entry-0324 | PDF 341 -->
Yan Ruxian. “A Living Fossil of the Family: A Study of the Family Structure of the Naxi Nationality in the Lugu Lake Region.” *Social Sciences in China* 3.4 (1982): 60–83.

<!-- eb-bibliography-entry-0325 | PDF 341 -->
Yang Li. “Zhuanbian zhong de Zhongguo nüxing yishu” (The metamorphosing Chinese female art). In *Zhuanbian zhong de nüxing* (The metamorphosing female), 4–7. Shanghai: Osage Gallery, 2008.

<!-- eb-bibliography-entry-0326 | PDF 341 -->
Yang Ruichun. “Yu mingong yiqi wudao” (Dancing with migrant workers). *Nanfang zhoumo* (Southern weekly), August 24, 2001.

<!-- eb-bibliography-entry-0327 | PDF 341 -->
Yang Yingshi. “The Tongzhou Artists Community.” *art* *Asia Pacific* 31 (2001): 72–75.

<!-- eb-bibliography-entry-0328 | PDF 341 -->
Yao, Pauline J. *In Production Mode: Contemporary Art in China* (Shengchan moshi: Toushi Zhongguo dangdai yishu). Beijing: Timezone 8, 2008.

〔原书第321页〕

<!-- eb-bibliography-entry-0329 | PDF 342 -->
Ye Xue. Interview by author. Beijing. February 24, 2001.

<!-- eb-bibliography-entry-0330 | PDF 342 -->
Yin Xiuzhen. Interview by author. Beijing. February 4, 2002.

<!-- eb-bibliography-entry-0331 | PDF 342 -->
Yin Yangzi. “Yu mingong yiqi wudao” (Dancing with migrant workers). *Xin chao* (Next wave), October 2001, 4–19.

<!-- eb-bibliography-entry-0332 | PDF 342 -->
Young, Helen Praeger. *Choosing Revolution: Chinese Women Soldiers on the Long March*. Champaign: University of Illinois Press, 2001.

<!-- eb-bibliography-entry-0333 | PDF 342 -->
Zhang Dali. Interview by author. Beijing. February 17, 2002.

<!-- eb-bibliography-entry-0334 | PDF 342 -->
Zhang Li. “Contesting Spatial Modernity in Late-Socialist China.” *Current Anthropology* 47.3 (2006): 461–84.

<!-- eb-bibliography-entry-0335 | PDF 342 -->
———. “Private Homes, Distinct Lifestyles: Performing a New Middle Class.” In *Privatizing China: Socialism from Afar*, ed. Li Zhang and Aihwa Ong, 23–40. Ithaca: Cornell University Press, 2008.

<!-- eb-bibliography-entry-0336 | PDF 342 -->
———. *Strangers in the City: Reconfigurations of Space*, *Power*, *and Social Networks within China’s Floating Population*. Stanford: Stanford University Press, 2001.

<!-- eb-bibliography-entry-0337 | PDF 342 -->
Zhang Li. “Side.” In *Wang Xingwei*, Ullens Center for Contemporary Art, 64–79. Beijing: Shijie tushu chuban gongsi, 2013.

<!-- eb-bibliography-entry-0338 | PDF 342 -->
Zhang Ou. Interview by author. London. April 22, 2002.

<!-- eb-bibliography-entry-0339 | PDF 342 -->
Zhang Tingwei. “Urban Development and a Socialist Pro-Growth Coalition in Shanghai.” *Urban Affairs Review* 37.4 (2002): 475–99.

<!-- eb-bibliography-entry-0340 | PDF 342 -->
Zhang Yan and Ke Fang. “Is History Repeating Itself? From Urban Renewal in the United States to Inner-City Redevelopment in China.” *Journal of Planning Education and Research* 23.3 (2004): 286–98.

<!-- eb-bibliography-entry-0341 | PDF 342 -->
Zhang Zhaohui, ed. *Xin dushizhuyi: Zhongguo dangdai yishu* (New urbanism: Chinese contemporary art). Aomen: Aomen chubanshe, 2002.

<!-- eb-bibliography-entry-0342 | PDF 342 -->
Zhang Zikang (director, Today Art Museum). Interview by author. Beijing. August 6, 2007.

<!-- eb-bibliography-entry-0343 | PDF 342 -->
Zhao Jin and Shi Tou. *We Are Here*. dvd. Beijing: independently produced documentary, 2015.

<!-- eb-bibliography-entry-0344 | PDF 342 -->
Zheng, Jane. “Private Tutorial Art Schools in the Shanghai Market Economy: The Shanghai Art School, 1913–1919.” *Modern China* 35.3 (2009): 313–43.

<!-- eb-bibliography-entry-0345 | PDF 342 -->
———. “The Shanghai Fine Arts College: Art Education and Modern Women Artists in the 1920s and 1930s.” *Modern Chinese Literature and Culture* 19.1 (2007): 192–235.

<!-- eb-bibliography-entry-0346 | PDF 342 -->
Zheng Kuo. *798 zhan* (798 station). dvd. Beijing: Zheng Kuo dianying, 2011.

<!-- eb-bibliography-entry-0347 | PDF 342 -->
Zhou Shuxuan. *The Gendered Landscape of Chinese Forestry Reform: Labor*, *Narrative*, *and Resistance*, *1950s-Current*. PhD diss., University of Washington, 2017.

<!-- eb-bibliography-entry-0348 | PDF 342 -->
———. “Suku and the Self-Valorization of Chinese Women Workers: Before, During, and After Enterprise Privatization.” *Frontiers of History in China* 10.1 (2015): 145–67.

<!-- eb-bibliography-entry-0349 | PDF 342 -->
Zhu Jia. Interview by author. Beijing. November 21, 2001.
