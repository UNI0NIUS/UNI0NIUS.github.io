# 索引

索引保留英文条目与原书页码；斜体页码表示插图、地图与图版。

〔原书第323页〕

<!-- eb-index-entry-0001 | PDF 344 -->
Abramović, Marina, 226, 299n26, 299n29

<!-- eb-index-entry-0002 | PDF 344 -->
abstraction: in art, 22, 35–36, 115, 294n6, 295n14; and Heidegger’s philosophical idea of world in relation to earth, 29–30; and Marx, 192, 295n14

<!-- eb-index-entry-0003 | PDF 344 -->
aesthetics: of collective political struggle, 50; competing views of, 2, 98, 113, 125; competing ideas of value of, 8, 23, 98, 125; of Cultural Revolution, 50; postsocialist urban aesthetics, 12, 78, 83, 88, 140; public aesthetics, 105; Western modernist forms of, 50; and zone of encounter of Chinese contemporary art, 10, 21–22, 44–45, 104–7, 113, 131–32, 139, 255, 260, 268–69, 270

<!-- eb-index-entry-0004 | PDF 344 -->
Ai Weiwei: *@Large: Ai Weiwei on Alcatraz,* 8; biographical details, 259–60; and China Art Archives and Warehouse, 230; contribution to spectacle of Beijing Olympics, 8, 257, 258, 260; *Fuck Off,* 8, 75; arrest and detention of, 8, 261, 268, 275n5, 302n40; Lei Yan’s work compared with, 238–39, 258–62, 269; political dissent of, 8, 258, 275n5; *Remembering,* 258, 259; *S.A.C.R.E.D,* 261; *Sichuan Name List,* 259; *Straight,* 258–59; *Study in Perspective,* 261; worldwide public museum spaces commanded by, 255, 260–61, 302n40

<!-- eb-index-entry-0005 | PDF 344 -->
Anagnost, Ann, 281n12, 283n49

<!-- eb-index-entry-0006 | PDF 344 -->
Andrews, Julia F., 34, 294n6

<!-- eb-index-entry-0007 | PDF 344 -->
anthropology: and art, 23, 113, 131–32; feminist, 267. *See also* cultural encounter; ethnography; feminist cultural encounter; worldings

<!-- eb-index-entry-0008 | PDF 344 -->
anticolonialism: anticolonial worldings, 30–31, 34–36; and artists as arbiters of world culture, 23

<!-- eb-index-entry-0009 | PDF 344 -->
apartment art: Gao Minglu’s coining of term, 88, 94; and privatization of property and lifestyle, 88–90

<!-- eb-index-entry-0010 | PDF 344 -->
Appadurai, Arjun, 250

<!-- eb-index-entry-0011 | PDF 344 -->
Araeen, Rasheed, 28

<!-- eb-index-entry-0012 | PDF 344 -->
architectural scale models: as element in *Dancing with Mingong,* 79, 95, 286n39; for Grand moma project, 76–77; seductive promise of, 107; and symbolic importance of Beijing’s built environment, 83, *84*, 285n13; in work of Lu Hao, 285n13; in work of Xing Danwen, 78, 273, 285n13

<!-- eb-index-entry-0013 | PDF 344 -->
avant-garde: ambivalence towards its use as label, 21, 50–52; French derivation of, 43, 53; Japanese art described as, 53–54; and Mao’s call to travel to rural and ethnic minority hinterlands, 69, 116; and myth of originality, 45, 54; and participation

〔原书第324页〕

<!-- eb-index-entry-0014 | PDF 345 -->
avant-garde (continued) in international art exhibitions, 69; *qianfeng* as term for, 53; *qianwei* (forward guard) as term for, 43–44, 53–54, 59, 281n25; *xiandai* (modern) contrasted with, 43. *See also* Beuys, Joseph; Chinese avant-garde; Duchamp, Marcel; vanguardism: *xianfeng*

<!-- eb-index-entry-0016 | PDF 345 -->
bad boy political dissent. See *liumang* (hooligan) attitude of rebellion and spiritual malaise

<!-- eb-index-entry-0017 | PDF 345 -->
Bai Chongmin, *148*, 291n11

<!-- eb-index-entry-0018 | PDF 345 -->
Barlow, Tani E., 32, 37, 52, 147, 168, 239, 241, 292n31

<!-- eb-index-entry-0019 | PDF 345 -->
Barmé, Geremie, 277n23

<!-- eb-index-entry-0020 | PDF 345 -->
Bauer, Ute Meta, 122–25

<!-- eb-index-entry-0021 | PDF 345 -->
Beautiful Garden housing estate, newspaper ads featuring imagery drawn from Western masterpieces, 88–89, *89*

<!-- eb-index-entry-0022 | PDF 345 -->
Becker, Howard, 23

<!-- eb-index-entry-0023 | PDF 345 -->
Beijing, *46*, *47*; Beijing 798 Art District, *47*, 103, 265, 287n54, 287n55, 290n37; as China’s “cultural center” (*wenhua zhongxin*), 10–13, 25, 46–49, 76, 84–85, 133; as growth machine, 87–88, 104; as museum, 83–86.

<!-- eb-index-entry-0024 | PDF 345 -->
Beijing Olympics (2008): “Bird’s Nest” (Olympics National Stadium), 8, *46*, *47*, 83, 257, 258, 260, 271; Olympic Green, *46*, *47*, *84*, 85, 285n14; and promotion of Chinese contemporary art, 9, 103

<!-- eb-index-entry-0025 | PDF 345 -->
Beijing Urban Planning Museum, *47*, 83–85, *84*

<!-- eb-index-entry-0026 | PDF 345 -->
belatedness: as double bind confronted by Chinese female artists, 171–72; and Chinese contemporary art, 21–22, 166; and promoters of Western modernism, 54

<!-- eb-index-entry-0027 | PDF 345 -->
Benjamin, Walter, 204, 280n7

<!-- eb-index-entry-0028 | PDF 345 -->
Berlin: *China Avant-Garde: Counter-Currents in Art and Culture* (1993)*,* 18, 164; *China Fest,* 75

<!-- eb-index-entry-0029 | PDF 345 -->
Beuys, Joseph: He Chengyao’s *A Salute to Mama* (*With Respect to Joseph Beuys*), 232, *232*; and Western historical avant-garde, 215, 230, 231–32, 265

<!-- eb-index-entry-0030 | PDF 345 -->
biennales: adoption as model by Chinese cities, 7. *See also* Shanghai Biennale; Venice Biennale; Whitney Biennial

<!-- eb-index-entry-0031 | PDF 345 -->
bitterness: eating, 143; speaking, 188, 224

<!-- eb-index-entry-0032 | PDF 345 -->
Blumenfield, Tami, 146, 291n23

<!-- eb-index-entry-0033 | PDF 345 -->
body (embodiment): and feminist performance art, 226, 299n26; somatic experience of *Dancing with Mingong,* 287n43. *See also* gender; *nannü* (male/female) relations; nudes and nudity; politics of exposure; sexuality

<!-- eb-index-entry-0034 | PDF 345 -->
Bourdieu, Pierre, 23, 260

<!-- eb-index-entry-0035 | PDF 345 -->
Bryson, Norman, 262

<!-- eb-index-entry-0036 | PDF 345 -->
Buck-Morss, Susan, 83, 179

<!-- eb-index-entry-0037 | PDF 345 -->
Bürger, Peter, 53

<!-- eb-index-entry-0038 | PDF 345 -->
Cao Fei (aka China Tracy), *Rabid Dogs–Hungry Dog,* 37, *37*

<!-- eb-index-entry-0039 | PDF 345 -->
—*rmb* *City*: China Tracy Pavilion at 2007 Venice Biennale, 271–72; creation in Second Life, 270–71; *Live in* *rmb* *City,* 272–73, *p19*

<!-- eb-index-entry-0040 | PDF 345 -->
Central Academy of Fine Arts (cafa), *47*; and China’s system of national art academies, 59, 282n42; contemporary art course attended by He Changyao at, 61, 207, 213, 225, 226–27; drawing from plaster casts taught at, 61–62, *62*; graduates. *See* Xing Danwen; Yang Feiyun, Zhu Jia; high school attached to, 58, 60, 197; location of, 47, *47*, 63. *See also* Fan Di’an, Xu Beihong

〔原书第325页〕

<!-- eb-index-entry-0041 | PDF 346 -->
Centre Pompidou, 293–94n68

<!-- eb-index-entry-0042 | PDF 346 -->
*Century Woman* (1998), 19–20, 243

<!-- eb-index-entry-0043 | PDF 346 -->
Chau, Adam, 106

<!-- eb-index-entry-0044 | PDF 346 -->
Chen Lingyang, *25*:*50*, *no*.*2,* 15–16, 40, 101, 270, 273, *p2*

<!-- eb-index-entry-0045 | PDF 346 -->
Chicago, Judy: on female authorities as educators and role models, 293n63; participation in *Lord of the Rim: In Herself/For Herself,* 175; on patriarchal suppression of primordial matriarchy, 148–49; *The Dinner Party,* 141–42, 149, 152, 292n35; *Womanhouse* installation (1972), 149, 152, 154–55, 253; and Zhang Lun’s *Lugu Lake–Happy Existence,* 161, *p12*

<!-- eb-index-entry-0046 | PDF 346 -->
—*What If Women Ruled the World*: proposal for, 135, 153; and *The Long March,* 146–49

<!-- eb-index-entry-0047 | PDF 346 -->
—*Womanhouse* installation at Lugu Lake: and limits of site-specific art practice, 154, 171–72; manifesto presented to her, 153–54, 172–75; and participation of Chinese female artists, 150–53; proposed site of, *136*

<!-- eb-index-entry-0048 | PDF 346 -->
Chien Ying-Ying, 175

<!-- eb-index-entry-0049 | PDF 346 -->
China Art Expo: He Chengyao’s booth at, 212; Ministry of Culture as sponsor of, 49; move from Guangzhou to Beiing, 48–49, 284n69

<!-- eb-index-entry-0050 | PDF 346 -->
*China/Avant-Garde* (1989): attention and notoriety of contemporary art practices brought by, 17; Gao Minglu’s co-curation of, 18, 43; and gendered evolution of Chinese avant-garde imagery, 57; “no U-turn” symbol for, 16, 43; Xiao Lu’s *Dialogue* at, 17, 57

<!-- eb-index-entry-0051 | PDF 346 -->
China Millennium Monument, *46*, 66, 76, 85, 299n30

<!-- eb-index-entry-0052 | PDF 346 -->
China National Children’s Center (*Zhongguo ertong zhongxin*), *46*; Young Pioneer Palaces contrasted with, 64–65. *See also* Teacher Zhao

<!-- eb-index-entry-0053 | PDF 346 -->
China Ocean Shipping Company (cosco): East Modern Art Center developed by, 81, 91–93; Sino-Ocean Land Limited as subsidiary of, 83, 91

<!-- eb-index-entry-0054 | PDF 346 -->
Chinese avant-garde: censoring by Cultural Bureau, 9; gendered evolution of its imagery, 57; and Lei Yan’s path to becoming an artist via military, 240–41; *liumang* attitude of rebellion and spiritual malaise associated with, 16, 18–19. *See also* avant-garde; *dangdai yishu* (contemporary art); vanguardism

<!-- eb-index-entry-0055 | PDF 346 -->
Chinese contemporary art. See *dangdai yishu*

<!-- eb-index-entry-0056 | PDF 346 -->
Chong, Doryun, 121, 122, 130, 131

<!-- eb-index-entry-0057 | PDF 346 -->
Clarke, David, 280n82

<!-- eb-index-entry-0058 | PDF 346 -->
class: and gender, 13, 24, 25, 77, 83, 144, 150, 175, 203, 244, 268; middle-class distinction, 9, 23, 37, 39, 82, 88, 102, 105, 283n49, 286n27; revolution, 10, 137, 187, 190, 197, 260

<!-- eb-index-entry-0059 | PDF 346 -->
Claypool, Lisa, 276n12

<!-- eb-index-entry-0060 | PDF 346 -->
Clifford, James, 232

<!-- eb-index-entry-0061 | PDF 346 -->
Clunas, Craig, 32, 279n71

<!-- eb-index-entry-0062 | PDF 346 -->
colonialism: and art institutions, 113; and avant-garde myth of originality, 45; colonial worlding of Chinese art, 30, 35, 280n82; park in Shanghai forbidding both Chinese and dogs, 37; and self-colonization, 119–20, 133–34; “third world difference” as form of, 147; and woman, 166, 238, 239. *See also* anticolonialism; decolonialism; semicolonialism

<!-- eb-index-entry-0063 | PDF 346 -->
commodification: and ethnic minority tourism, 146; outsourcing of production of art by male artists, 20–21, 45, 289n7; and women’s bodies, 37, 40, 44, 191, 209, 302n5. *See also* value

<!-- eb-index-entry-0064 | PDF 346 -->
commodity apartment (*shangpin fang*), 5, 111; art centers created as part of, 76–78, 80–83, 87–88, 133

〔原书第326页〕

<!-- eb-index-entry-0065 | PDF 347 -->
consumption: conspicuous consumption, 37, 68–69; domestic, 39; of ethnic difference, 143, 157; foreign consumption of work Chinese artists, 20, 277n33

<!-- eb-index-entry-0066 | PDF 347 -->
contemporary art. See *dangdai yishu*

<!-- eb-index-entry-0067 | PDF 347 -->
copyright: and manifesto presented via Lu Jie to Judy Chicago, 153, 172–75; and modern intellectual property regimes, 54, 173–74

<!-- eb-index-entry-0068 | PDF 347 -->
Cotter, Holland, 163–64, 171

<!-- eb-index-entry-0069 | PDF 347 -->
countryside: artists sent to, 140, 282n44, 302n7; and Chinese art education, 25, 60; in relation to city, 25, 71, 112; and postsocialist urban aesthetics, 140; production of art by hired apprentices from, 20–21, 45, 72–72, 114–15, 289n7; and sent-down youth, 12. *See also* migrants

<!-- eb-index-entry-0070 | PDF 347 -->
CourtYard Gallery, *47*, 211–12

<!-- eb-index-entry-0071 | PDF 347 -->
*Cruel/Loving Bodies* (Ku/ai shenti), xvii, 290n37, 296n9

<!-- eb-index-entry-0072 | PDF 347 -->
Cui Shuqin, 188, 294–95n11

<!-- eb-index-entry-0073 | PDF 347 -->
cultural encounter: and aesthetics of China’s new urbanism, 76–78; Chinese contemporary art as zone of, 10, 15–16, 21, 113, 210–11, 270–71; and ethnography, 21–24, 132, 290n36; and feminism. *See* double binds; feminist cultural encounter; and global capitalism, 55–56, 75–76; and language of art/*yishu,* 119–20; and “third world difference,” 147

<!-- eb-index-entry-0074 | PDF 347 -->
cultural production: and Bourdieu’s analytic framework, 23, 260; gendered dimensions of, 21, 24, 27–28; global dimensions of, 10–11, 22–24, 28–31, 118–19, 131–32; and work of Wang Xingwei, 266–67

<!-- eb-index-entry-0075 | PDF 347 -->
Cultural Revolution. *See* revolution

<!-- eb-index-entry-0076 | PDF 347 -->
Dai Jinhua, 40, 166

<!-- eb-index-entry-0077 | PDF 347 -->
Dal Lago, Francesca, 275n1

<!-- eb-index-entry-0078 | PDF 347 -->
*Dancing with Mingong,* 79–81, 94–97, *95*, 98

<!-- eb-index-entry-0079 | PDF 347 -->
*dangdai yishu* (contemporary art): cosmopolitan distinction signified by appreciation of it, 22–23; course offered at cafa, 207, 213, 225, 226–27; defined as term, 22, 278n40; and Maoist framing of culture, 52–53; in popular publications on contemporary urban life, 22–23, 278n41; and translingual practice, 120

<!-- eb-index-entry-0080 | PDF 347 -->
Danto, Arthur, 23

<!-- eb-index-entry-0081 | PDF 347 -->
decolonialism: art as decolonial method, 28–29, 74, 270; and Berne Convention, 54, 173; and the inclusion of Chinese contemporary art in Western art museums, 18

<!-- eb-index-entry-0082 | PDF 347 -->
de Guzman, René, 121–22, 131

<!-- eb-index-entry-0083 | PDF 347 -->
Delacroix, Eugène, 1, 211; *Liberty Leading the People,* 186, 209–10, 229, 273

<!-- eb-index-entry-0084 | PDF 347 -->
demolition (*chai*): artists response to *chaiqian* (demolition and relocation), 11, 81, 244–45; 270–71; *chai* painted on buildings slated for demolition, 106, 111; and competing ideas of aesthetic, cultural, and market value, 92; and emerging forms of activism, *106*, 106; museum development in response to, 85–86. *See also* Yin Xiuzhen, *Portable Cities-Beijing*

<!-- eb-index-entry-0085 | PDF 347 -->
Deng Xiaoping, 8, 91, 227; tour of the South, 12, 48, 173

<!-- eb-index-entry-0086 | PDF 347 -->
Derrida, Jacques, 262, 302n39

<!-- eb-index-entry-0087 | PDF 347 -->
dialectic: Chinese contemporary art as dialogic construction, 116, 132; colliding myths of progress and modernity, 45; double figure of Li Tianpian’s *Red Souvenir* as, 203–5; and historical materialism, 26; and monumental ephemeral, 25, 267; and revolution, 204, 239. *See also* cultural encounter

〔原书第327页〕

<!-- eb-index-entry-0088 | PDF 348 -->
Ding Ling: future anterior reading of her Maoist literary corpus, 239; joined Long March women at Yan’an, 149; “Thoughts on March 8,” 144–45, 244, 300n18

<!-- eb-index-entry-0089 | PDF 348 -->
Documenta: *Documenta 10* hoax created by Yan Lei and Hong Hao, 123–24; *Documenta 11,* 123, 124, 125–26; as global stage, 123, 124, 126

<!-- eb-index-entry-0090 | PDF 348 -->
Dong, Madeleine Yue, 281n11

<!-- eb-index-entry-0091 | PDF 348 -->
Dong Xiwen, *The Founding of the Nation*, 281n17

<!-- eb-index-entry-0092 | PDF 348 -->
double binds: art as way of confronting, 28, 173–74, 176, 253, 263; and art world social actors, 267; and Chinese and Western feminisms, 144, 148, 165–72; communication dilemma described by, 166; of Communist views of women, 144–45, 240, 244; and experience of Chinese female artists, 27–28, 170–72; and Kristeva’s concept of *écriture féminine,* 148

<!-- eb-index-entry-0093 | PDF 348 -->
Du Bois, W. E. B., 73–74

<!-- eb-index-entry-0094 | PDF 348 -->
Duchamp, Marcel, 265, 299n34; *Fountain,* 49, 50, *51*; idea of readymade, 50; *Nude Descending a Staircase,* 230, 299n32; *The Bride Stripped Bare by Her Bachelors, Even,* 231; and the Western historical avant-garde, 230, 265

<!-- eb-index-entry-0095 | PDF 348 -->
East Modern Art Center (Yuanyang yishu zhongxin), *47*; brief efflorescence of, 79–80, 102–3, 104–5, 107; and China Ocean Shipping Company (cosco), 81, 91–93; *Dancing with Mingong* at, 79–81, 94–97, *95*, 98; its layered history and architecture, 98–99, 101, 133; and Ocean Paradise Real Estate, 93–94, *94*, 102; Wang Nengtao’s *What a Wonderful World* installed at, 98, 99, *100*;*Yu* Hong’s *Witness to Growth* exhibited at, 99–101

<!-- eb-index-entry-0096 | PDF 348 -->
ephemerality: as aesthetic form, 176, 232, 235, 250–57, 263; of artistic experiments, 40, 80; in relation to monumentality, 9, 16, 25, 40, 176, 238, 257–62, 267. *See also* monumentality

<!-- eb-index-entry-0097 | PDF 348 -->
Erickson, Britta, 19, 163, 164–65

<!-- eb-index-entry-0098 | PDF 348 -->
ethnography: art world transition as focus of, 8, 21–22, 267; artist as ethnographer, 161–62, 240; author as ethnographic collaborator*,* 139, 143, 151, 291n11; author’s blurred role as ethnographer-interpreter, 113, 120, 131–32; of Beijing, 10–11, 268–69; ethnic classification of PRC’s *minzu,* 145, 294n3; fieldwork zone of encounter of, 24, 26–29, 121, 267–68; and intercultural space of arts exchange, 206, 288n4; and “museum effect,” 86; and surrealism, 232; representation of, 32, 179–80, 189, 215, 280n74. *See also* anthropology; cultural encounter; feminist cultural encounter; worldings

<!-- eb-index-entry-0099 | PDF 348 -->
Fan Di’an, 75, 284n69

<!-- eb-index-entry-0100 | PDF 348 -->
female subjectivity, 39–40, 169, 190, 241, 243; and performance of He Chengyao, 229; and painting of Pan Yuliang, 2, 243; and painting of Yu Hong, 101. *See also* double binds

<!-- eb-index-entry-0101 | PDF 348 -->
feminism: Chinese, 20, 34, 37, 145, 150, 166, 169, 243; Chinese translation of, 168; and field of cultural production, 8, 10, 16, 24–28, 259; French, 138, 147–48; and grammar of Lei Yan’s “what if” titles, 239–40; international U.S., 146–50; *liumang* (hooligan)/*nüxing yishu* (women’s art) binary, 16, 249, 259; Western model of, 19; transfeminism, 249; transnational feminism, 70, 137. *See also* double binds; *nannü* (male/female)

〔原书第328页〕

<!-- eb-index-entry-0102 | PDF 349 -->
feminist art: Chinese, 144, 162–65, 172; as epistemological field of practice, 27, 176, 270, 278n54; global, 139, 173, 174, 176, 241, 253, 269; translated as *nüxingzhuyi yishu*, 19, 168; U.S. movement, 135, 149, 163

<!-- eb-index-entry-0103 | PDF 349 -->
feminist cultural encounter, 26–28, 44–45, 162–65; and gendered evolution of Chinese avant-garde imagery, 57; and He Chengyao’s *Opening the Great Wall,* 207–11; and multidirectional tensions between colonial and decolonial forces, 268–70. *See also* double binds

<!-- eb-index-entry-0104 | PDF 349 -->
Feng Jiali, 163

<!-- eb-index-entry-0105 | PDF 349 -->
Fu Liya, *136*, 151, 153, 175

<!-- eb-index-entry-0106 | PDF 349 -->
*funü,* as national revolutionary female subject, 34, 37, 167, 168–69, 241

<!-- eb-index-entry-0107 | PDF 349 -->
*Funü* *shibao* (The Women’s Eastern Times), cover illustration, 236, *237*, 299–300n1

<!-- eb-index-entry-0108 | PDF 349 -->
Gao Brothers: staging of nude migrants for piece by, 72, 283n59; *The Condition of Chinese Avant-Garde Art, 44*

<!-- eb-index-entry-0109 | PDF 349 -->
Gao Minglu, 18, 43, 299n30; apartment art (*gongyu yishu*) coined as term by, 88, 94; theorization of China’s “total modernity,” 53

<!-- eb-index-entry-0110 | PDF 349 -->
Gell, Alfred, 23

<!-- eb-index-entry-0111 | PDF 349 -->
gender: and academic art ideal, 282–83n46; as dimension of cultural production, 21, 24, 27–28, 226; commodification of women’s bodies, 37, 40, 44, 191, 209; deconstruction of gender relationality in Duchamp’s work, 231; and development of Chinese global city, 25, 271; and evolution of post-1989 Chinese avant-garde imagery, 57; and global art market, 27; and imagery featuring sexualized female figures, 116; “iron girl” attitude of socialist gender formations, 34–35, 126, 289n27; and logic of *Wei Cheng,* 129–30; privileging of male avant-garde, 7, 121, 127; Maoist gender discourse, 20, 34–35; marginalization of demobilized female soe workers, 96–97, 287n44; nudity incorporated into art by male vs. female artists, 207–9; and outsourced labor, 252; and political position of women married to high-ranking men, 292n32; sexual violence and gender hierarchies in military, 242; and worlding, 31–40. *See also* female subjectivity; *funü*; masculinity; *nannü* (male/female); nudes and nudity; *nüxing*; politics of exposure; sexuality; women

<!-- eb-index-entry-0112 | PDF 349 -->
global art (*shijie yishu*): and emergence of Chinese contemporary art, 21–22, 137–38, 268; and gender, 27, 36, 139–40; and global feminism, 139–40, 269; and nationalism, 124–25, 131; and visions of diverse art worldings, 27, 29, 118–20, 143

<!-- eb-index-entry-0113 | PDF 349 -->
globalization: aspirations for cosmopolitan parity with global cities, 12, 86; and China’s bid to “link tracks with the world” (*yu shijie jiegui*), 11–13, 37, 63, 92, 203, 239, 269; and cultural production, 22–24, 28–31, 118–19, 131–32; and feminist art canon, 26–27, 176; and international U.S. feminism, 147; reconfigured by China’s connection with Asia and *Oumei,* 36; and translingual practice, 120; and visions of diverse art worldings, 27, 117–25, 130–34

<!-- eb-index-entry-0114 | PDF 349 -->
Goethe, Johann Wolfgang von, 120; Goethe Institute, 98, 123, 290n37

<!-- eb-index-entry-0115 | PDF 349 -->
Great Wall: and book cover of *China Can Say No,* 128; monumentality of, 257–58; as national symbol, 227

〔原书第329页〕

<!-- eb-index-entry-0116 | PDF 350 -->
Great Wall as Chinese avant-garde art institution, 82, 176, 227–29, 257–58, 299n30; Marina Abramović’s *The Great Wall Walk,* 299n29; He Chengyao, *Opening the Great Wall,* 206–11, 224–25, 229, *p15*; Yin Guangzhong, *Great Wall,* 207–8, *208*; and Zheng Lianjie’s *Binding the Lost Souls,* 227–28

<!-- eb-index-entry-0117 | PDF 350 -->
Great Wall and foreign artists: H.A. Schult’s installation at, 206, 207, 209–10, 229; Andy Warhol’s art performance on, 227

<!-- eb-index-entry-0118 | PDF 350 -->
growth machine cities: Beijing as, 87–88, 104–8; and commodity housing, 82–83, 87–88; social costs of, 106–7; theory of, 86–87

<!-- eb-index-entry-0119 | PDF 350 -->
Gu Wenda, 278n40

<!-- eb-index-entry-0120 | PDF 350 -->
Halbreich, Kathy, 118

<!-- eb-index-entry-0121 | PDF 350 -->
*Half of the Sky* (1998), 20, 165

<!-- eb-index-entry-0122 | PDF 350 -->
Hamilton, Ann, 296n13

<!-- eb-index-entry-0123 | PDF 350 -->
He Chengyao: birth of, 217, 296–97n16; childhood of, 216–18, 222–24; cafa contemporary art course attended by, 61, 207, 213, 225, 226–27; He Li as her childhood name, 218, 223; her mother’s sickness and death, 217–22; kinship organization of her family, 297n18; studies at Sichuan Academy of Fine Arts, 212, 213, 224; use of her real name, 296n15

<!-- eb-index-entry-0124 | PDF 350 -->
—works by: *Great Wall–Magnolia–Mama and Me,* 226–27, *228*; *Hair,* 214–15, *214*, 296n12; *High Noon–Prayer,* 213, *234*; *Illusion, 234*, 234–35; *Mama and Me,* 225–26, *226*; *99 Needles,* 233, *p16*; *Opening the Great Wall,* 206–11, 224–25, 229, *p15*; participation in *Cruel/Loving Bodies* (*Ku/ai shenti*), 296n9; *A Salute to Mama* (*With Respect to Joseph Beuys*), 232, *232*; *Testimony,* 225–26, *226*; *The Possibility of Hair,* 296n12; *With Marcel Duchamp as My Opponent,* 231, *231*; *With Respect to Marcel Duchamp, 229*, 230

<!-- eb-index-entry-0125 | PDF 350 -->
Heidegger, Martin, 29–30

<!-- eb-index-entry-0126 | PDF 350 -->
Hernández-Reguant, Ariana, 173–74

<!-- eb-index-entry-0127 | PDF 350 -->
Hevia, James, 31, 279n70

<!-- eb-index-entry-0128 | PDF 350 -->
He-Yin Zhen, 24–25, 264, 270, 278n51, 288–89n6

<!-- eb-index-entry-0129 | PDF 350 -->
Holl Steven, Linked Hybrid design for Grand MOMA, Beijing, 76–77, *p5*

<!-- eb-index-entry-0130 | PDF 350 -->
Hong Hao: *Documenta 10* hoax created with Yan Lei, 123–24; *Selected Scriptures*–*New Political World,* 29, *30*

<!-- eb-index-entry-0131 | PDF 350 -->
Huang Du: and curatorial discourses on globalization, 117–18, 127, 130, 131, 132; male avant-garde privileging by, 121, 127; ybca curators’ visit to Beijing guided by, 121–23

<!-- eb-index-entry-0132 | PDF 350 -->
Huang Ping, 103

<!-- eb-index-entry-0133 | PDF 350 -->
Huang Ru: *Open-Air Cinema,* 157, 159; participation in *The Long March* at Lugu Lake, *136*, 171

<!-- eb-index-entry-0134 | PDF 350 -->
Huang Yin, *Imitation Louis Vuitton Advertisement Series*–*Myth,* 37, *39*; participation in *The Long March* at Lugu Lake, *136*

<!-- eb-index-entry-0135 | PDF 350 -->
image worlds: Cao Fei’s exploration of, 272–73; as concept, 27–28, 267; of He Chengyao’s *Opening the Great Wall,* 229; of Lei Yan’s work, 236, 250, 259

<!-- eb-index-entry-0136 | PDF 350 -->
Ivy, Marilyn, 86

<!-- eb-index-entry-0137 | PDF 350 -->
Jia Fangzhou, 19–20, 164, 243

<!-- eb-index-entry-0138 | PDF 350 -->
Jiang Jie, 142

<!-- eb-index-entry-0139 | PDF 350 -->
Jiang Qing, 191–93. See also *Red Detachment of Women*.

<!-- eb-index-entry-0140 | PDF 350 -->
*Jinri xianfeng* (Avant-garde today), 44, 132

<!-- eb-index-entry-0141 | PDF 350 -->
Jin Shangyi and Wu Biduan, *Mao Zedong with the People of Asia, Africa, and Latin America,* 34, *35*

〔原书第330页〕

<!-- eb-index-entry-0142 | PDF 351 -->
Joo, Eungie: diversity nationalism articulated by, 125–26; “saying no” (*shuo bu*) articulated by, 127–29; West with an Asian face identified by, 130, 131; and ybca curators’ visit to Beijing, 121, 122

<!-- eb-index-entry-0143 | PDF 351 -->
Karetzky, Patricia Eichenbaum, 172

<!-- eb-index-entry-0144 | PDF 351 -->
Karl, Rebecca E., 31

<!-- eb-index-entry-0145 | PDF 351 -->
Khullar, Sonal, 278n54

<!-- eb-index-entry-0146 | PDF 351 -->
Kirshenblatt-Gimblett, Barbara, 86

<!-- eb-index-entry-0147 | PDF 351 -->
Kraus, Richard Curt, 127, 277n23

<!-- eb-index-entry-0148 | PDF 351 -->
Krauss, Rosalind E., 22, 54

<!-- eb-index-entry-0149 | PDF 351 -->
Kristeva, Julia: *About Chinese Women* by, 138, 147, 148–49, 171, 292n31; as canonical name in Western feminist theory, 147–48; theory of *écriture féminine,* 148, 166

<!-- eb-index-entry-0150 | PDF 351 -->
Kunming: site of *Natural Feminine Art*, 19; Upriver Loft (Chuang Ku) studio collective, 150, 240; Yunnan Art Academy, 175

<!-- eb-index-entry-0151 | PDF 351 -->
Kurahara Korehito, 53–54

<!-- eb-index-entry-0152 | PDF 351 -->
Kusama, Yayoi, 301n32

<!-- eb-index-entry-0153 | PDF 351 -->
Laoshan: battle site of Sino-Vietnamese War, 246; Malipo Martyrs Cemetery, 247

<!-- eb-index-entry-0154 | PDF 351 -->
Lao Wei, 79, 97

<!-- eb-index-entry-0155 | PDF 351 -->
late socialism-late liberalism: cultural conditions of, 8, 257; definition of, 8–9, 276n6; work of art in era of, 238, 260

<!-- eb-index-entry-0156 | PDF 351 -->
Lei Feng: “learn from Lei Feng” campaign, 220, 233, 298n21

<!-- eb-index-entry-0157 | PDF 351 -->
Lei Yan: Ai Weiwei’s work compared with, 238–39, 258–62; biographical details, 240; participation in *The Long March* at Lugu Lake, *136*, 140–41, 171, 240; as propagandist turned deconstructionist, 241; as transfeminist artist, 249–50

<!-- eb-index-entry-0158 | PDF 351 -->
—works by: *Bullet Shot through a Young Heart,* 246–48, *248*, 249, 251; *Camouflage Production,* 252–53, *253*; *Frozen Youth* series by, 251–52, *251*, 301n29; *How Do I Protect You?,* 254–55, 256, *256*, *256*, 257–58; *I Love Kitchen* by, 253–54; *Long March Battlefront Report*, *Issue #1,* 141, *141*; *On the Road,* 257; *A Place Where Dream Starts,* 254, *254*, 257; *Relic* (*Shengwu*), *No. 20*, 262–63, *263*; *Southern Border Dream,* 248–49, *p17*; *Ten Years of Dying Young,* 259; *Unnamed Tomb, p18*

<!-- eb-index-entry-0159 | PDF 351 -->
—*What If* series, 236, 238–39, 244, 264; binoculars in, 239, 251, 264; *What If Our Factory Were Still Here,* 244–45, *246*; *What If They Had Been Women,* 156–57, *158*, 236, 239–40, 243–44; *What If Woman Were Written by the Book,* 245–46; *What If the Long March Had Been a Women’s Rights Movement* by, 156–57, *158*, 236, 239–40, 243–44

<!-- eb-index-entry-0160 | PDF 351 -->
Lei Yan and Tang Zhigang, *Group Photo of an Era* by, 244, *245*

<!-- eb-index-entry-0161 | PDF 351 -->
Li Shurui, *Seeing Mountains, Seeing Water,* 155–56, 171, *p10*

<!-- eb-index-entry-0162 | PDF 351 -->
Li Tianpian: death of, 201–2, 204–5; friendship with Yuan Yaomin, 180, 183; narration of her life, 195–99; plans to travel to U.S., 200–201

<!-- eb-index-entry-0163 | PDF 351 -->
—work by: *Classic Beauty, 185*; incorporated into Wang Xingwei’s *Three Nudes,* 265, 267, 270–71; *Red Souvenir,* 181–83, 185, 200–201, 203–5, *204*, 266, *p14*

<!-- eb-index-entry-0164 | PDF 351 -->
Li Xiaojiang, 37, 39, 292n34

<!-- eb-index-entry-0165 | PDF 351 -->
Liao Wen, 19, 162–63, 169

<!-- eb-index-entry-0166 | PDF 351 -->
Lijiang Field Report Exhibit, 291n11

<!-- eb-index-entry-0167 | PDF 351 -->
Lin Tianmiao, 142, 163–64, 170–71

<!-- eb-index-entry-0168 | PDF 351 -->
Lin Wenzheng, 53

<!-- eb-index-entry-0169 | PDF 351 -->
Liu Hong, *Soliloquy* series, 169, *170*

<!-- eb-index-entry-0170 | PDF 351 -->
Liu, Lydia, 116, 119–20, 295n23

<!-- eb-index-entry-0171 | PDF 351,352 -->
*liumang* (hooligan) attitude of rebellion and spiritual malaise: Ai Weiwei as representative of, 8, 258; Chinese avant-garde associated with, 7, 18–19; defined as term, 276n20; He Chengyao’s mimesis of, 229; and heroic nationalism, 131; and *liumang*/*nüxing* binary, 16, 259

〔原书第331页〕

<!-- eb-index-entry-0172 | PDF 352 -->
*The Long March: A Walking Visual Display, 136*; curatorial plan for, 135–39, 142–43; discrepancies between art worldings demonstrated by, 134, 143; Judy Chicago’s participation in. *See* Chicago, Judy; as “seeding machine” as conceptualized by Lei Yan and Sun Guojuan, 140–41, 156; and “women’s art,” 142–43. *See also* Bai Chongmin; Fu Liya; Huang Ru; Huang Yin; Jiang Jie; Lei Yan; Li Shurui; Lin Tianmiao; Liu Hong; Song Yanping; Su Ruya; Sun Guojuan; Wu Weihe; Yin Xiuzhen, Zhang Lun

<!-- eb-index-entry-0173 | PDF 352 -->
Long March by the Communist Red Army, 136–38; restaging as an art event. See *The Long March: A Walking Visual Display*; women who participated in it, 149, 156

<!-- eb-index-entry-0174 | PDF 352 -->
Lu Hao, *Beijing’s Kaleidoscope,* 285n13

<!-- eb-index-entry-0175 | PDF 352 -->
Lu Jie: artists’ manifesto presented to Judy Chicago by, 153–54, 172–75; curatorial plan for *The Long March,* 135–39, 142–43; his inclusion of Judy Chicago in *The Long March,* 142, 147, 151, 161

<!-- eb-index-entry-0176 | PDF 352 -->
Lü Peng, 243, 283n52

<!-- eb-index-entry-0177 | PDF 352 -->
Lu Xun: avant-garde aesthetic advocated by, 54; literary gossip concerning, 52; portrayal in Tang Xiaoming’s *Never Give up the Struggle,* 55; “Regret for the Past,” 295n23; “Self Mockery,” 3, 55, 242

<!-- eb-index-entry-0178 | PDF 352 -->
Lu Xun Academy of Fine Arts, 50, 196, 243–44, 282n42, 300n13

<!-- eb-index-entry-0179 | PDF 352 -->
Luan Jujie, 289n27

<!-- eb-index-entry-0180 | PDF 352 -->
Lugu Lake restaging of the Long March. See *The Long March: A Walking Visual Display*

<!-- eb-index-entry-0181 | PDF 352 -->
Ma Liuming, 70, 208

<!-- eb-index-entry-0182 | PDF 352 -->
*mangliu yishujia* (blind floater artists), 70–71, 283n52

<!-- eb-index-entry-0183 | PDF 352 -->
Maoism: framing of culture by, 52–53; global 1960s circulation of, 138; “learn from Lei Feng” campaign, 220, 233, 298n21; “learn from pla” campaign, 297–98n20; and vanguardism, 44–45, 54–55

<!-- eb-index-entry-0184 | PDF 352 -->
Mao Ran, 94, 96

<!-- eb-index-entry-0185 | PDF 352 -->
Mao Zedong: and Great Wall, 299n28; official portrait of, 63, 227; pictured in Jin Shangyi and Wu Biduan, *Mao Zedong with the People of Asia, Africa, and Latin America,* 34, *35*; pictured in Lei Yan, *What If They Had Been* Women, 156; *158*; pictured in Xu Xiaobing, *Mao Zedong and Wang Renzhong Visit 1958 Exhibition,* 49, *51*; speech addressed to China’s youth (1957), 134, 290n39; talks on literature and art by (1942), 3, 55, 115–16, 137, 242, 268; “Women hold up half the sky” slogan of, 20, 34; worshipped as avant-garde artist, 50–52

<!-- eb-index-entry-0186 | PDF 352 -->
marketization: artists critical of China’s bubble economy, 301n35; artists’ negotiation of, 9, 12, 78, 203; and exotic commodification of Mosuo, 146; and late-socialist progrowth coalitions, 87; and market reform, 8, 12, 16, 48, 173; and museum development, 85–86

<!-- eb-index-entry-0187 | PDF 352 -->
Marxism: critique of colonialism, 34; and humanist criticism of destruction of individual agency under Mao, 37, 39, 166; and ethnic classification, 145; and gender, 167, 171; Japanese proletarian art movement, 53–54; Marx pictured in Cao Fei, *rmb* *City*, 271; Marx pictured in Wang Nengtao, *Met Old Chap Marx in Paris*, 99; and “Socialism with Chinese Characteristics,” 8; and understanding of culture, 55, 189–90, 192, 295n14

〔原书第332页〕

<!-- eb-index-entry-0188 | PDF 353 -->
masculinity: male corporeality of *Dancing with Mingong,* 94–97, *95*; and Mao Zedong on climbing Great Wall and, 299n28; masculinist avant-garde, 7, 16, 22, 55, 57, 233; portrayed in Yang Feiyun’s *Male Nude,* 265; women garbed in image of men as part of politics of liberatory revolution, 157. See also *liumang* (hooligan) attitude of rebellion and spiritual malaise; *nannü* (male/female) relations

<!-- eb-index-entry-0189 | PDF 353 -->
Matisse, Henri, 1, 77, 124

<!-- eb-index-entry-0190 | PDF 353 -->
migrants: and construction of Beijing as cultural center, 10–13, 25; double-consciousness experienced by female migrant, 73; and *mangliu yishujia* (blind floater artists), 69–71, 283n52; rural-to-urban migrants, 281n12, 281n13, 283n49. *See also* countryside

<!-- eb-index-entry-0191 | PDF 353 -->
—representation in work of contemporary artists, 25, 103; and He Changyao’s *Hair,* 214–15, *214*; male migrant workers (*mingong)* as focus of, 71–72; participation in *Dancing with Mingong,* 79, 94–97, *95*; staging of nude migrants for piece by Gao Brothers, 72, 283n59

<!-- eb-index-entry-0192 | PDF 353 -->
modernity: and alienation of modern megacity, 13; and art, 28, 50; China’s successive modernity projects, 30, 37, 40, 44, 82, 138; and dreamworlds of mass utopia, 83, 179; Gao Minglu’s theorization of China’s “total modernity,” 53; and gender, 25, 112, 238–39, 249, 270; and loss of cultural identity associated with global forms of, 86; and supermodernity, 276n12; translated modernity of early twentieth-century Chinese literature, 116, 119. *See also* belatedness

<!-- eb-index-entry-0193 | PDF 353 -->
Mohanty, Chandra Talpade, 147

<!-- eb-index-entry-0194 | PDF 353 -->
monumentality: antimonumental critique of, 257–58; Judy Chicago’s *The Dinner Party* as an example of, 142; and modernist sculptural production, 22; state socialist legacy of, 176. *See also* Beijing Olympics (2008); ephemerality

<!-- eb-index-entry-0195 | PDF 353 -->
Mosuo (Na): matrilineal culture of, 135, 138, 145; representation in work of *Long March* artists, 146–7, 155, 156, 157, 159–61; and state ethnic classification, 145–6, 161; and tourism, 146, 156, 157

<!-- eb-index-entry-0196 | PDF 353 -->
Mullaney, Thomas, 145

<!-- eb-index-entry-0197 | PDF 353 -->
museums: alternatives to. *See* site-specific art; and British institutional framings of Chinese art, 32; Cold War period display of Chinese antiquities in, 35; Duchamp’s *Fountain* as critique of, 50; as emblems of national modernity, 31, 74, 85–86, 285–86n17; as models for real estate projects, 76–78, 80–81, 87–88; “museum effect” of display practices, 86. *See also* Beijing Urban Planning Museum; China Millennium Monument; East Modern Art Center; National Art Museum of China; Today Art Museum

<!-- eb-index-entry-0198 | PDF 353 -->
Myers, Fred R., 206, 288n4

<!-- eb-index-entry-0199 | PDF 353 -->
*nannü* (male/female) relations: and class, 25, 144; exclusions resulting from, 113; He-Yin Zhen’s theorization of, 24–25, 264, 270, 288–89n6; and injustice, 241

<!-- eb-index-entry-0200 | PDF 353 -->
Nantong, 91; Nantong Museum, 74

<!-- eb-index-entry-0201 | PDF 353 -->
National Art Museum of China (namoc), *47*; *Century Woman* at, 19, 243; *China/Avant-Garde* exhibit at, 16–17, 43, 240; *Long Live the Victory of Chairman Mao’s Revolutionary Line* at*,* 243; and 1980s “culture fever,” 277n22; *Stars Art Exhibition* staged outside of, 16–17; viewed as retrograde by contemporary artists, 77, 98

<!-- eb-index-entry-0202 | PDF 353,354 -->
neoliberalism: andartists at Lugu Lake, 174; Chinese provincialization of Western beliefs in market capitalism, 8–9; and late liberalism, 276n6

〔原书第333页〕

<!-- eb-index-entry-0203 | PDF 354 -->
neologisms: *kuanüxingzhuyi yishu* (transfeminist art), 249; “saying no” (*shuo bu*) articulated by Eungie Joo, 127–29; terms for avant-garde, 44–45; *wei cheng,* 112–13, 288n3. See also *funü*; *nüxing*

<!-- eb-index-entry-0204 | PDF 354 -->
Nochlin, Linda, 19

<!-- eb-index-entry-0205 | PDF 354 -->
nudes and nudity: and academy training, 184, 191, 282–83n46; female nude as national symbol, 207–8, 295n3; Liu Haisu’s defense of Western technique of painting from, 59; Pan Yuliang as painter of, 2, 167; performance pieces by Ma Liuming, 70, 208; normalization of painting of, 302n6; staging of nude migrants for piece by Gao Brothers, 72, 283n59. *See also* He Chengyao,—works by

<!-- eb-index-entry-0206 | PDF 354 -->
*nüxing* (female): bourgeois self-obsession associated with, 34, 167; emergence as neologism, 241; *liumang*/*nüxing* binary, 16, 259; and market feminism, 37, 39–40; and painting of Pan Yuliang, 167. *See also* women

<!-- eb-index-entry-0207 | PDF 354 -->
*nüxing yishu* (feminine or women’s art): emergence of, 19, 39; and *liumang*/*nüxing* binary, 16, 259; as marginalizing category, 16, 19–20, 163–64, 169, 170–71, 241; and transfeminist art (*kuanüxingzhuyi yishu*), 249–50

<!-- eb-index-entry-0208 | PDF 354 -->
*nüxingzhuyi yishu*. See *nüxing yishu*

<!-- eb-index-entry-0209 | PDF 354 -->
Olympics. *See* Beijing Olympics

<!-- eb-index-entry-0210 | PDF 354 -->
One World Art Center, *47*, 80, 133

<!-- eb-index-entry-0211 | PDF 354 -->
Ono, Yoko, 226, 299n26

<!-- eb-index-entry-0212 | PDF 354 -->
originality: avant-garde myth of, 45, 54; and Chinese cultural production, 133, 173; and international property rights, 174; and romantic cult of individual creation, 23; Wang Yin’s experiments with, 114–15, 116, 132, 289n7

<!-- eb-index-entry-0213 | PDF 354 -->
Pan Jiajun, *I Am a “Seagull,”* 34–35, *36*

<!-- eb-index-entry-0214 | PDF 354 -->
Pan Yuliang, 2, 269, 270; *Nude in Front of Window, 167*

<!-- eb-index-entry-0215 | PDF 354 -->
Pang Laikwan, 174

<!-- eb-index-entry-0216 | PDF 354 -->
Pang Xuan, participation in *The Long March* at Lugu Lake, *136*

<!-- eb-index-entry-0217 | PDF 354 -->
Parker, Rozsika, and Griselda Pollock, 282–83n46

<!-- eb-index-entry-0218 | PDF 354 -->
People’s Liberation Army (pla): “learn from pla” campaign, 297–98n20; Lei Yan’s training as artist in 236, 241, 260; pla Arts Academy, 240, 243. *See also* Long March by Communist Red Army

<!-- eb-index-entry-0219 | PDF 354 -->
Picasso (Dongfeng Citroën car), 67–68, *67*

<!-- eb-index-entry-0220 | PDF 354 -->
Picasso, Pablo, exhibit of prints at China Millennium Monument, 66

<!-- eb-index-entry-0221 | PDF 354 -->
Poggioli, Renato, 53

<!-- eb-index-entry-0222 | PDF 354 -->
politics of exposure: and Ai Weiwei’s photographs of his wife, 260–61; He Chengyao’s use of her real name, 296n15; and He Chengyao’s *Opening the Great Wall* (*Kaifang changcheng*), 206–11; Qionghua’s exposure of her wounds in *The Red Detachment of Women,* 186–88, *189*, 224; and wounded-ness, 227, 233–34. *See also* nudes and nudity

<!-- eb-index-entry-0223 | PDF 354 -->
Poole, Deborah, 279n73

<!-- eb-index-entry-0224 | PDF 354 -->
privatization, 173; and apartment art, 88–89; of art academies and exhibition spaces, 12, 76, 78, 80; and urban housing reform, 81

<!-- eb-index-entry-0225 | PDF 354 -->
Pu Songling, *Tales of Liaozhai,* 219, 297n19

<!-- eb-index-entry-0226 | PDF 354 -->
Qian Zhongshu, *Fortress Besieged,* 288n3; French proverb used as epigraph to, 112, 129, 288n2; *Wei Cheng* television adaptation, 111–12, 129–30

<!-- eb-index-entry-0227 | PDF 354 -->
Qiu Zhijie, curatorial plan for *The Long March,* 136–39, 143

<!-- eb-index-entry-0228 | PDF 354 -->
Qi Zhilong, *China Girl, 44*, 44

〔原书第334页〕

<!-- eb-index-entry-0229 | PDF 355 -->
readymade art: Duchamp’s idea of, 50; Lei Yan’s returning of it back to the world, 252, 263

<!-- eb-index-entry-0230 | PDF 355 -->
*The Red Detachment of Women* (Hongse niangzi jun), 179; ballet version of, 192–95, *194*, *204*; and Li Tianpian’s *Red Souvenir,* 181–82, 203, 267; Shanghai film production of, *186*, 186–87, 210, 242; Wu Qionghua’s exposure of her wounds in, 188, *189*, 224

<!-- eb-index-entry-0231 | PDF 355 -->
revolution: Communist Revolution, 10, 136, 144, 150, 236; Cultural Revolution, 12, 17, 50, 55, 56, 69, 100, 179, 191, 207, 234, 243, 252, 302n7; French Revolution, 53, 209; Philippine Revolution, 31. *See also* Wang Huaiqing, *Revolution*

<!-- eb-index-entry-0232 | PDF 355 -->
Rofel, Lisa, 80, 174

<!-- eb-index-entry-0233 | PDF 355 -->
Rosler, Martha, 301n32

<!-- eb-index-entry-0234 | PDF 355 -->
Sandoval, Chela, 27

<!-- eb-index-entry-0235 | PDF 355 -->
Sasaki Takamaru, 53

<!-- eb-index-entry-0236 | PDF 355 -->
scale models. *See* architectural scale models

<!-- eb-index-entry-0237 | PDF 355 -->
Schult, H. A., installation at Great Wall, 206, 207, 209–10, 229

<!-- eb-index-entry-0238 | PDF 355 -->
semicolonialism: defined, 279n67; and translated modernity in China, 119; translingual practice fostered by, 53; worlding of, 31, 34

<!-- eb-index-entry-0239 | PDF 355 -->
sexuality: and female desire, 32, 234, 292n32; and Mosuo 145–46, 150, 159; and postsocialist discourse, 80, 116, 296–97n16; and violence, 58, 243, 276n20, 300n11. *See also* body (embodiment); gender; nudes and nudity; politics of exposure

<!-- eb-index-entry-0240 | PDF 355 -->
Shan Lianxiao, *To Be an Upright Person, Be This Kind of Person,* 167, *168*

<!-- eb-index-entry-0241 | PDF 355 -->
Shanghai, 24, 26, 191; and culture industry, 46–49; and print culture, 236–37; and semicolonialism, 37, 77, 112, 273; and women’s art education, 35, 59; World Expo, 9, 257

<!-- eb-index-entry-0242 | PDF 355 -->
Shanghai Art School, 59

<!-- eb-index-entry-0243 | PDF 355 -->
Shanghai Biennale: 1996, 165; 2000, 8, 75

<!-- eb-index-entry-0244 | PDF 355 -->
*shenru shenghuo* (to enter life), 11, 55, 60, 239

<!-- eb-index-entry-0245 | PDF 355 -->
Shen Yu, participation in *The Long March* at Lugu Lake, *136*, 150

<!-- eb-index-entry-0246 | PDF 355 -->
Shi Tou, 70

<!-- eb-index-entry-0247 | PDF 355 -->
Shi Xinning,*“Duchamp Retrospective Exhibition” in China,* 49–50, *51*, 53

<!-- eb-index-entry-0248 | PDF 355 -->
Shih Shu-mei, 278–79n54, 279n67

<!-- eb-index-entry-0249 | PDF 355 -->
Sichuan Fine Arts Institute (Chongqing), 59, 150; graduates. *See* Huang Ru; He Chengyao; Li Shurui; faculty. *See* Liu Hong

<!-- eb-index-entry-0250 | PDF 355 -->
Sino-American Cooperative Association (saco), 159, 292n39

<!-- eb-index-entry-0251 | PDF 355 -->
Sin-Vietnamese War, 240, 246–48, 251, 252, 301n30

<!-- eb-index-entry-0252 | PDF 355 -->
*Sister Jiang,* 159, 292n39

<!-- eb-index-entry-0253 | PDF 355 -->
site-specific art: as alternative to museum spaces, 81–82, 155; of Ann Hamilton, 296n13; of Asian artists in *Lord of the Rim: In Herself/For Herself,* 175; created for privatized museum sites, 105; of Lei Yan’s *What If* series, 156–57; as paradigm of community collaboration, 107, 161–62; as response to urban renewal, 11, 82, 106. *See also* Chicago, Judy,—*Womanhouse* installation at Lugu Lake; *Dancing with Mingong*; East Modern Art Center

<!-- eb-index-entry-0254 | PDF 355 -->
Song Dong: *Broken Mirror,* 96; and “Canceled”: Exhibiting Experimental Art in China, 81; and *Dancing with Mingong,* 81, 93–97, *95*; *hutong* shared with wife Yin Xiuzhen, 13; on limits of artists to affect social change, 97, 106

<!-- eb-index-entry-0255 | PDF 355 -->
Song Yanping: *Fire Extinguisher*, 159, *160*, 171; participation in *The Long March* at Lugu Lake, *136*

<!-- eb-index-entry-0256 | PDF 355 -->
Songzhuang Artist Village, 45, *47*, 70–71

〔原书第335页〕

<!-- eb-index-entry-0257 | PDF 356 -->
spectacularity: of Ai Weiwei’s *S.A.C.R.E.D,* 261; Duchamp’s deconstruction of gendered spectacularity, 230–31; He Changyao’s bodily reproduction of mass spectacularity, 232

<!-- eb-index-entry-0258 | PDF 356 -->
Spence, Jonathan D., 288n3

<!-- eb-index-entry-0259 | PDF 356 -->
Spivak, Gayatri Chakravorty, 29–30, 292n31

<!-- eb-index-entry-0260 | PDF 356 -->
state-owned enterprises (soes): demobilization of female soe workers, 91–92, 96–97, 287n44; and late socialist progrowth coalitions, 87; nationwide reform of, 81

<!-- eb-index-entry-0261 | PDF 356 -->
Statue of Liberty, 128; and “Goddess of Democracy” constructed in Tiananmen Square, 62–63, 229

<!-- eb-index-entry-0262 | PDF 356 -->
still life painting: in academy training, 60, 184; and human presence, 262

<!-- eb-index-entry-0263 | PDF 356 -->
Su Ruya: *Goddess Mountain,* 159, 171, *p11*; participation in *The Long March* at Lugu Lake, *136*

<!-- eb-index-entry-0264 | PDF 356 -->
Su Yabi, participation in *The Long March* at Lugu Lake, *136*

<!-- eb-index-entry-0265 | PDF 356 -->
subaltern women: oppression on Hainan, 190; and task of the sublime, 189, 294–95n11

<!-- eb-index-entry-0266 | PDF 356 -->
Sun Guojuan: exhibition at Yunnan Art Academy on their journey to Lugu Lake, 175; *Stuck to You,* 157, 172; and *The Long March* at Lugu Lake, *136*, 140–41, 153, 156, 240

<!-- eb-index-entry-0267 | PDF 356 -->
*suzhi* (quality): and market success as measure of individual and social value, 8; of rural citizens and migrants, 49, 93, 281n12

<!-- eb-index-entry-0268 | PDF 356 -->
*suzhi jiaoyu* (quality education), 64, 69, 283n49, 283n50

<!-- eb-index-entry-0269 | PDF 356 -->
Tang Song, 17, 57–58

<!-- eb-index-entry-0270 | PDF 356 -->
Tang Xiaobing, 57

<!-- eb-index-entry-0271 | PDF 356 -->
Tang Xiaoming, *Never Give Up the Struggle*, 55

<!-- eb-index-entry-0272 | PDF 356 -->
Tang Zhigang. *See* Lei Yan and Tang Zhigang, *Group Photo of an Era*

<!-- eb-index-entry-0273 | PDF 356 -->
Tate Modern, 260–61, 293–94n68

<!-- eb-index-entry-0274 | PDF 356 -->
Teacher Zhao: art as purchasable commodity stressed by, 67–68; criticism of conspicuous consumption, 68–69; painting by student of, *68*; teaching philosophy of, 65–66

<!-- eb-index-entry-0275 | PDF 356 -->
Tiananmen Square, *47*; featured in Ai Weiwei’s *Study in Perspective,* 261; featured in animations of Beijing, 285n16; featured in Yu Hong’s *Witness to Growth,* 100; “Goddess of Democracy” constructed in, 62–63, 229; 1989 crackdown on protests in, 9, 12, 17

<!-- eb-index-entry-0276 | PDF 356 -->
Today Art Museum, *47*, 80; progrowth culture cultivated by its founders, 104–5; *Together with Migrants* exhibit at, 103

<!-- eb-index-entry-0277 | PDF 356 -->
translingual practice: and conditions of semicolonialism, 53; and “global art,” 43, 44, 119–20

<!-- eb-index-entry-0278 | PDF 356 -->
trauma: of being robbed of expression, 224–26, 229, 233–34; women driven mad by, 298–99n24

<!-- eb-index-entry-0279 | PDF 356 -->
Tsing, Anna Lowenhaupt, 23

<!-- eb-index-entry-0280 | PDF 356 -->
Ullens Center for Contemporary Art (ucca), 265–66, 267

<!-- eb-index-entry-0281 | PDF 356 -->
urban renewal: and popular opposition, 87, 286n25; site-specific art as response to, 11, 82. *See also* Beijing Urban Planning Museum; demolition; growth machine cities

<!-- eb-index-entry-0282 | PDF 356 -->
value: art as purchasable commodity stressed by Teacher Zhao, 67–68; and competing ideas of aesthetic, cultural, and market value, 8, 92–93, 125; market success as measure of, 8. See also *suzhi* (quality)

<!-- eb-index-entry-0283 | PDF 356 -->
Van Gogh, Vincent, 282n28, 302n42

〔原书第336页〕

<!-- eb-index-entry-0284 | PDF 357 -->
vanguardism: and Maoist modernity, 44–45, 54–55; and participation in international art exhibitions, 69–70, 74–75, 118; *xianfeng* (vanguard) as term for, 43–45, 241; and Yuanmingyuan as an art village, 70. *See also* avant-garde

<!-- eb-index-entry-0285 | PDF 357 -->
Velázquez, Diego Rodríguez de Silva y, 294n9

<!-- eb-index-entry-0286 | PDF 357 -->
Venice Biennale: 1980, 275n1; 1993, 275n2; 1993 (*Passaggio a Oriente*), 275n1; 1999 (Forty-Eighth Biennale), 7; 2005, 7, 275n3; 2007, 271–72; 2011, 7; 2013, 261

<!-- eb-index-entry-0287 | PDF 357 -->
Vergne, Philippe, 117–18, 120–21, 122, 124–25

<!-- eb-index-entry-0288 | PDF 357 -->
Visser, Robin, 140

<!-- eb-index-entry-0289 | PDF 357 -->
Walsh, Eileen Rose, 146

<!-- eb-index-entry-0290 | PDF 357 -->
Wang Huaiqing, *Revolution,* 57

<!-- eb-index-entry-0291 | PDF 357 -->
Wang Lingzhen, 233–34

<!-- eb-index-entry-0292 | PDF 357 -->
Wang Nanming, 249

<!-- eb-index-entry-0293 | PDF 357 -->
Wang Nengtao, 290n39; *Dream World Music,* 99, *100*; *Subversion*–*Earth,* 10–11, 15, 40, 270, *p3*; *What a Wonderful World,* 98, 99, *100*

<!-- eb-index-entry-0294 | PDF 357 -->
Wang Qingsong: *Forum,* 36, *38*; *Take Hold of the Brush, Struggle to the End,* 55–56, 57, *p3*; Western art market experience of, 56

<!-- eb-index-entry-0295 | PDF 357 -->
Wang Xingwei: retrospective exhibit at ucca, 265–66, 267; *Untitled (Three Nudes),* 265–67, 269–70

<!-- eb-index-entry-0296 | PDF 357 -->
Wang Yin: experiments with authorship and originality, 114–15, 116, 132, 289n7; *Flower, 115*; heroic *liumang* nationalism of, 131; identification with protagonist of *Wei Cheng,* 129–30; One World Art Center exhibition curated by, 133; *Sandstorm,* 114–15, *p8*; *2000, No. 7,* 114

<!-- eb-index-entry-0297 | PDF 357 -->
Warhol, Andy, 215, 227

<!-- eb-index-entry-0298 | PDF 357 -->
Wen Hui, *Dancing with Mingong,* 93–96, *95*, 286n41, 287n43

<!-- eb-index-entry-0299 | PDF 357 -->
Whitney Biennial (1993), 125–26

<!-- eb-index-entry-0300 | PDF 357 -->
Williams, Raymond, 295n14

<!-- eb-index-entry-0301 | PDF 357 -->
woman: *cainü* (women of talent), 27–28; catachreses of woman soldier/art soldier/woman artist, 241, 249–50, 253, 264; new woman, 138, 236, 238, 239; representation of female artists in international exhibitions of Chinese contemporary art, 18–19, 163–65; representations of traditional Chinese woman, 32–33, 279–80n74; un Fourth World Conference on Women (1995), 70, 150, 170, 243, 301n29; woman artist, 20, 21, 243, 270, 293–94n68. *See also* gender; *nannü* (male/female); *nüxing* (female); *nüxing yishu* (feminine or women’s art)

<!-- eb-index-entry-0302 | PDF 357 -->
worlding: anticolonial worlding, 30–31, 34–36; art worldings’ diverse visions, 27, 29, 117–25, 130–34, 143; as theoretical concept, 29; colonial worlding and views of Chinese art, 30, 35, 280n82; revolutionary socialist worlding, 36; semicolonial worlding, 31, 34. *See also* image worlds

<!-- eb-index-entry-0303 | PDF 357 -->
worldly fables, 3, 269

<!-- eb-index-entry-0304 | PDF 357 -->
Wu Biduan. *See* Jin Shangyi

<!-- eb-index-entry-0305 | PDF 357 -->
Wu Hung, 280n6; exhibit *Cancelled* curated by, 285n8; on monumentality, 257; on peasant women hired to craft work for Wang Jin, 289n7; on use of old photos by Chinese contemporary artists, 252, 301nn28–29

<!-- eb-index-entry-0306 | PDF 357 -->
Wu Weihe, *148*, 151, 291n11

<!-- eb-index-entry-0307 | PDF 357 -->
Wu Wenguang, *Dancing with Mingong,* 93–95, *95*, 286n41

<!-- eb-index-entry-0308 | PDF 357 -->
Xi Jinping, 268, 282n44, 302n7

<!-- eb-index-entry-0309 | PDF 357 -->
Xiao Lu: *Dialogue,* 17, 57, 58; *Fifteen Shots, 58*

<!-- eb-index-entry-0310 | PDF 357 -->
Xiao Zhenya and Liu Enbin, *Take Hold of the Brush, Struggle to the End,* 55, 57, *p4*

〔原书第337页〕

<!-- eb-index-entry-0311 | PDF 358 -->
*xiesheng* (life drawing/painting), 181, 294n6

<!-- eb-index-entry-0312 | PDF 358 -->
Xing Danwen, 285n13; *Backstage,* 78; *Urban Fiction,* 78, 273, *p6*, *p7*

<!-- eb-index-entry-0313 | PDF 358 -->
Xu Beihong, 2–3, 61, 269, 270

<!-- eb-index-entry-0314 | PDF 358 -->
Xu Bing, 63, 227, 278n40

<!-- eb-index-entry-0315 | PDF 358 -->
Xu Xiaobing, *Mao Zedong and Wang Renzhong Visit 1958 Exhibition, 51*

<!-- eb-index-entry-0316 | PDF 358 -->
Yan’an: Communist guerrilla base, 136, 144, 149, 150, 242, 259; Conference on Art and Literature, 55, 72, 115–16, 137, 192, 268; and Ding Ling’s “Thoughts on March 8,” 144, 244; Lu Xun Arts Academy at, 242, 282n42

<!-- eb-index-entry-0317 | PDF 358 -->
Yan Lei: *Are You Among Those Invited to the German Exhibition* by, 126, 289n27, *p9*; *Documenta 10* hoax created with Hong Hao, 123

<!-- eb-index-entry-0318 | PDF 358 -->
Yang Feiyun, 302n5, 302n6; *Male Nude,* 265

<!-- eb-index-entry-0319 | PDF 358 -->
Yang Li, 169

<!-- eb-index-entry-0320 | PDF 358 -->
Yang Xinyi, *Together with Migrants* curated by, 103

<!-- eb-index-entry-0321 | PDF 358 -->
Yerba Buena Center for the Arts (ybca): curators’ visit to Beijing, 121–23, 127; San Francisco “South of Market” location of, 121–22; *Time After Time: Asia and Our Moment* (2003) exhibited at, 121, 133

<!-- eb-index-entry-0322 | PDF 358 -->
Yin Guangzhong, *Great Wall,* 207–8, *208*

<!-- eb-index-entry-0323 | PDF 358 -->
Yin Xiuzhen, 26, 93, 142; and *Dancing with Mingong,* 93–97, *95*; *Portable Cities,* 13–14, *14*, 15, *15*, 23, 40, 270, 276n12

<!-- eb-index-entry-0324 | PDF 358 -->
Young Pioneer Palaces (*shaonian gong*), 63–64

<!-- eb-index-entry-0325 | PDF 358 -->
Yu Hong: *1996, Thirty Years Old,* 100–101, *101*; *Witness to Growth,* 98, 99–101

<!-- eb-index-entry-0326 | PDF 358 -->
Yuanmingyuan, *46*; art village in, 69–70, 73; “clean up and reordering” campaign (1995) carried out in, 70

<!-- eb-index-entry-0327 | PDF 358 -->
Yuan Yaomin, 180, 183, 202

<!-- eb-index-entry-0328 | PDF 358 -->
Zhang Dali, *100 Chinese,* 72–73, *73*

<!-- eb-index-entry-0329 | PDF 358 -->
Zhang Huan, 70, 301n35

<!-- eb-index-entry-0330 | PDF 358 -->
Zhang Li (curator), 98, 101

<!-- eb-index-entry-0331 | PDF 358 -->
Zhang Li (anthropologist), 281n13, 286n25, 286n27

<!-- eb-index-entry-0332 | PDF 358 -->
Zhang Lun: *Lugu Lake–Happy Existence,* 160–61, 172, *p12–p13*; participation in *The Long March* at Lugu Lake, *136*, 143

<!-- eb-index-entry-0333 | PDF 358 -->
Zhang Ou, 290n39

<!-- eb-index-entry-0334 | PDF 358 -->
Zhang Yan and Ke Fang, 87

<!-- eb-index-entry-0335 | PDF 358 -->
Zheng Lianjie, *Binding the Lost Souls,* 227–28

<!-- eb-index-entry-0336 | PDF 358 -->
Zhou Shuxuan, 287n44

<!-- eb-index-entry-0337 | PDF 358 -->
Zhu Jia, 74–76, 118, 284n67

<!-- eb-index-entry-0338 | PDF 358 -->
Zhuang Hui, 301n35; *July 25th, Cha Shan Town*, 101–2

<!-- eb-index-entry-0339 | PDF 358 -->
Zoffany, Johann, 282–83n46
