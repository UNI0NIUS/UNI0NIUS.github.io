"""Build editable XeLaTeX and Markdown editions from the reviewed reader data."""
import json,re
from pathlib import Path
P=Path(__file__).resolve().parent
OUT=P/'delivery';WEB=OUT/'web'
registration=json.loads((OUT/'registration.json').read_text(encoding='utf-8'))
TEX=OUT/'print';TEX.mkdir(exist_ok=True)
def esc(s):
    table={'\\':r'\textbackslash{}','{':r'\{','}':r'\}','&':r'\&','%':r'\%','$':r'\$','#':r'\#','_':r'\_','~':r'\textasciitilde{}','^':r'\textasciicircum{}'}
    return ''.join(table.get(c,c)+(r'\allowbreak{}' if c in '/-' else '') for c in s)
def inline(tokens,lang):
    out=''
    for t in tokens:
        if isinstance(t,str):out+=esc(t)
        elif t['type']=='em':out+=r'\textit{'+inline(t['children'],lang)+'}'
        elif t['type']=='note':out+=r'\hypertarget{ref-'+lang+'-'+t['id']+r'}{}\textsuperscript{\hyperlink{note-'+lang+'-'+t['id']+'}{'+t['id'].split('-')[-1]+'}}'
        elif t['type']=='break':out+='\n\n'
        else:raise ValueError(t)
    return out
def plain(tokens,lang="zh"):
    return ''.join(t if isinstance(t,str) else '*'+plain(t['children'],lang)+'*' if t['type']=='em' else '[^'+lang+'-'+t['id']+']' if t['type']=='note' else '\n\n' for t in tokens)
header=r'''\documentclass[11pt,a4paper,oneside]{book}
\usepackage[margin=23mm,headheight=15pt]{geometry}
\usepackage{fontspec,xeCJK,graphicx,xcolor,hyperref,bookmark,needspace,fancyhdr}
\setmainfont{Times New Roman}
\setCJKmainfont{SimSun}[AutoFakeBold=2,AutoFakeSlant=.2]
\setCJKsansfont{SimHei}
\xeCJKDeclareCharClass{Default}{"2018,"2019,"201C,"201D}
\hypersetup{unicode=true,colorlinks=true,linkcolor=blue,urlcolor=blue,pdftitle={实验北京},pdfauthor={Sasha Su-Ling Welland}}
\setlength{\parindent}{0pt}\setlength{\parskip}{6pt}
\linespread{1.18}\emergencystretch=3em
\pagestyle{fancy}\fancyhf{}\fancyhead[L]{\small 实验北京}\fancyhead[R]{\small 译校阅读稿}\fancyfoot[C]{\thepage}
\renewcommand{\headrulewidth}{.3pt}
\newcommand{\sourcepage}[1]{\par\needspace{4\baselineskip}{\footnotesize\color{gray} 来源位置：#1}\par}
\begin{document}
'''
for mode in ['zh','bilingual']:
    langs=['zh'] if mode=='zh' else ['en','zh']
    tex=[header,r'\begin{titlepage}\centering\vspace*{30mm}{\Huge 实验北京\par}\vspace{12mm}{\Large 当代中国艺术中的性别与全球化\par}\vspace{15mm}{\large Sasha Su-Ling Welland\par}\vspace{15mm}'+('独立中文阅读稿' if mode=='zh' else '逐段中英对照阅读稿')+r'\par\vfill 依据2018年英文版译校。\par 原书页码另行标示。\par\end{titlepage}\renewcommand{\contentsname}{阅读目录}\tableofcontents']
    md=['# '+registration['title'],'\n'+registration['author']+'\n']
    for ch in registration['chapters']:
        d=json.loads((WEB/(ch['id']+'.json')).read_text(encoding='utf-8'))
        tex.append(r'\chapter*{'+esc(ch['title'])+r'}\addcontentsline{toc}{chapter}{'+esc(ch['title'])+'}')
        md.append('\n## '+ch['title']+'\n')
        for row in d['body']:
            if row['type'] in ['heading','subheading']:tex.append(r'\needspace{12\baselineskip}\begin{samepage}')
            tex.append(r'\hypertarget{'+row['id']+'}{}')
            if row.get('page'):tex.append(r'\sourcepage{'+esc(row['page'])+'}');md.append('\n〔原书 '+row['page']+'〕\n')
            if row.get('src'):
                image='../web/assets/'+row['src'].split('/')[-1]
                tex.append(r'\par\begin{center}\includegraphics[width=.88\linewidth,height=.68\textheight,keepaspectratio]{'+image+r'}\end{center}')
                md.append('!['+plain(row.get('zh',[])).replace('[','').replace(']','')+'](web/assets/'+row['src'].split('/')[-1]+')\n')
            selected=['zh'] if ch['id'] in ['bibliography','index','editorial'] else langs
            for lang in selected:
                if not row.get(lang):continue
                value=inline(row[lang],lang)
                if row['type'] in ['heading','subheading']:
                    tex.append(r'{\large\bfseries '+value+r'}\par\nopagebreak[4]')
                elif row['type']=='quote':tex.append(r'\begin{quote}'+value+r'\end{quote}')
                else:tex.append(value+'\par')
                md.append(plain(row[lang],lang)+'\n')
            if row['type'] in ['heading','subheading']:tex.append(r'\end{samepage}\nopagebreak[4]')
        if d['notes']:
            tex.append(r'\section*{原注}\addcontentsline{toc}{section}{原注}')
            md.append('\n### 原注\n')
            for id,n in d['notes'].items():
                tex.append(r'\needspace{4\baselineskip}')
                for lang in langs:
                    tex.append(r'\hypertarget{note-'+lang+'-'+id+r'}{}\noindent\textbf{'+id.split('-')[-1]+'.} '+inline(n[lang],lang)+r' \hyperlink{ref-'+lang+'-'+id+r'}{[返回]}\par')
                    md.append('[^'+lang+'-'+id+']: '+plain(n[lang],lang).replace('\n','\n    ')+'\n')
    tex.append(r'\end{document}')
    (TEX/(mode+'.tex')).write_text('\n\n'.join(tex),encoding='utf-8')
    (OUT/('experimental-beijing-'+mode+'.md')).write_text('\n'.join(md),encoding='utf-8')
print('Wrote two XeLaTeX sources and Markdown reading editions')
