"""Export reviewed book to the existing site's structured bilingual-reader format.
Writes only this book's isolated local delivery directory.
"""
import json,re,shutil,hashlib
from pathlib import Path
from PIL import Image
P=Path(__file__).resolve().parent
OUT=P/'delivery'
WEB=OUT/'web'
WEB.mkdir(parents=True,exist_ok=True)
(WEB/'assets').mkdir(exist_ok=True)
book=json.loads((P/'build/canonical_book.json').read_text(encoding='utf-8'))
BASE='translations/books/experimental-beijing/'

def tokens(text,section=None,styles=None,markdown=False):
    if styles:
        result=[];last=0
        for r in styles:
            assert text[r['start']:r['end']]==r['text']
            result+=tokens(text[last:r['start']],section,markdown=markdown)
            result.append(dict(type='em',children=tokens(r['text'],section)))
            last=r['end']
        return result+tokens(text[last:],section,markdown=markdown)
    pattern=r'(\[\d+\]|\n\n+|\n|\*[^*\n]+\*)' if markdown else r'(\[\d+\]|\n\n+|\n)'
    out=[]
    for part in re.split(pattern,text):
        if not part:continue
        if re.fullmatch(r'\[\d+\]',part) and section and f"note-{section}-{int(part[1:-1]):03d}" in note_ids:
            out.append(dict(type='note',id=f"{section}-{int(part[1:-1])}"))
        elif part.startswith('\n'):out.append(dict(type='break'))
        elif markdown and part.startswith('*') and part.endswith('*'):out.append(dict(type='em',children=[part[1:-1]]))
        else:out.append(part)
    return out

def image_asset(b):
    images=b['images']
    if len(images)==1:
        source=P/images[0]['path'];name=b['id']+source.suffix
        shutil.copy2(source,WEB/'assets'/name)
    else:
        # PDF249 horizontal triptych; PDF277 and364 vertical full/detail pairs.
        opened=[Image.open(P/x['path']).convert('RGB') for x in images]
        horizontal=b['id']=='ch06-b089'
        extent=max((im.height if horizontal else im.width) for im in opened)
        resized=[im.resize((round(im.width*extent/im.height),extent) if horizontal else (extent,round(im.height*extent/im.width)),Image.Resampling.LANCZOS) for im in opened]
        gap=max(16,extent//50)
        size=(sum(im.width for im in resized)+gap*(len(resized)-1),extent) if horizontal else (extent,sum(im.height for im in resized)+gap*(len(resized)-1))
        canvas=Image.new('RGB',size,'white');offset=0
        for im in resized:
            canvas.paste(im,(offset,0) if horizontal else (0,offset))
            offset+=(im.width if horizontal else im.height)+gap
        name=b['id']+'.png';canvas.save(WEB/'assets'/name)
    return BASE+'assets/'+name

note_ids={n['id'] for n in book['notes']}
chapters=[];exports={}
for s in book['sections']:
    sid=s['section'];rows=[];notes={}
    for n in book['notes']:
        if n['section']==sid:
            notes[f"{sid}-{n['number']}"]=dict(en=tokens(n['en'],styles=n['en_style_ranges']),zh=tokens(n['zh'],markdown=True),sourcePdfPages=n['source_refs'])
    for b in s['blocks']:
        kind={'blockquote':'quote','part_title':'heading','half_title':'heading','title':'heading','figure_glossary':'diagram'}.get(b['kind'],b['kind'])
        if kind not in ['heading','subheading','quote','diagram']:kind='paragraph'
        pages=list(dict.fromkeys(str(r['printed_page']) for r in b['source_refs'] if r.get('printed_page')))
        row=dict(id=b['id'],type=kind,page=', '.join(pages),en=tokens(b['en'],sid,b['en_style_ranges']),zh=tokens(b['zh'],sid,markdown=True),sourceRefs=b['source_refs'])
        if any(not re.fullmatch(r'[ivxlcdm]+|\d+',v,re.I) for v in pages):
            row['page']='PDF '+', '.join(dict.fromkeys(str(r['pdf_page']) for r in b['source_refs']))
            row['pageKind']='pdf'
        if b['images']:row.update(type='figure',src=image_asset(b))
        rows.append(row)
    title={'front':'前置材料','plates':'彩色图版'}.get(sid,s['blocks'][0]['zh'])
    en_title={'front':'Front Matter','plates':'Color Plates'}.get(sid,s['blocks'][0]['en'])
    chapters.append(dict(id=sid,title=title,originalTitle=en_title,dataUrl=BASE+sid+'.json'))
    exports[sid]=dict(title=title,originalTitle=en_title,body=rows,notes=notes,sourceLanguage='en',sourceLanguageLabel='English')
for sid,title,en_title in [('bibliography','参考文献（原文）','Bibliography'),('index','索引（原文）','Index')]:
    rows=[]
    for e in book['backmatter'][sid]['entries']:
        inline=[dict(type='em',children=[r['text']]) if r['italic'] else r['text'] for r in e['runs']]
        rows.append(dict(id=e['id'],type='paragraph',en=inline,zh=inline,page=', '.join(dict.fromkeys(str(r['printed_page']) for r in e['source_refs'])),sourceRefs=e['source_refs']))
    exports[sid]=dict(title=title,originalTitle=en_title,body=rows,notes={})
    chapters.append(dict(id=sid,title=title,originalTitle=en_title,dataUrl=BASE+sid+'.json'))
editorial=[]
for i,para in enumerate(book['editorial_note'].split('\n\n')):
    editorial.append(dict(id=f'editorial-{i}',type='heading' if para.startswith('# ') else 'paragraph',zh=tokens(para.removeprefix('# '),markdown=True),en=[]))
for i,e in enumerate(book['terminology']['entries']):
    editorial.append(dict(id=f'term-{i}',type='paragraph',zh=[e['en']+' — '+e['zh']+'。'+e['note']],en=[]))
exports['editorial']=dict(title='译校说明与术语',originalTitle='Editorial Notes',body=editorial,notes={})
chapters.append(dict(id='editorial',title='译校说明与术语',originalTitle='Editorial Notes',dataUrl=BASE+'editorial.json'))
cover=book['cover'];cover_path=P/cover['delivery_path']
shutil.copy2(cover_path,WEB/'assets'/('cover'+cover_path.suffix))
exports['front']['body'].insert(0,dict(id='cover',type='figure',page='',src=BASE+'assets/cover'+cover_path.suffix,en=['Original cover'],zh=['原书封面']))
for sid,d in exports.items():
    d['id']=sid
    (WEB/(sid+'.json')).write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8')
registration=dict(id='experimental-beijing',title=book['title_zh'],originalTitle=book['title_en'],author=book['author'],languagePair='English / 中文',language='zh-CN',bilingual=True,example=False,description='全书中英对照译校稿，含原注、图版、原书页码、参考文献与索引。',chapters=chapters,editionNotice='本稿依据2018年英文版PDF译校；页码标示指原书印刷页码。中文引文原则上为英文底本回译，详细说明见译校附录。')
registration['translator']='AI辅助翻译与校对'
registration['downloads']=[dict(label=label,url=BASE+'downloads/'+name) for label,name in [
('中文 PDF','experimental-beijing-zh.pdf'),('中英对照 PDF','experimental-beijing-bilingual.pdf'),('可复现源码包','experimental-beijing-source.zip'),('中文 Markdown','experimental-beijing-zh.md'),('中英 Markdown','experimental-beijing-bilingual.md')]]
(OUT/'registration.json').write_text(json.dumps(registration,ensure_ascii=False,indent=2),encoding='utf-8')
report=dict(input_sha256=hashlib.sha256((P/'build/canonical_book.json').read_bytes()).hexdigest(),chapters=len(exports),rows=sum(len(c['body']) for c in exports.values()),notes=sum(len(c['notes']) for c in exports.values()),images=len(list((WEB/'assets').iterdir())),status='exported; rendering and content acceptance pending')
(OUT/'export_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report))
