"""Render only the current canonical article.json; never recreate translation."""
from pathlib import Path
import json,re,shutil
base=next(Path(__file__).resolve().parent.glob('From *'));out=base/'output';out.mkdir(exist_ok=True)
a=json.loads((base/'work/article.json').read_text('utf-8'))
def esc(s):
    return ''.join({'\\':r'\textbackslash{}','&':r'\&','%':r'\%','$':r'\$','#':r'\#','_':r'\_','{':r'\{','}':r'\}','~':r'\textasciitilde{}','^':r'\textasciicircum{}'}.get(x,x) for x in s)
def tex(ts):
    return ''.join(esc(t) if isinstance(t,str) else r'\textit{'+tex(t['children'])+'}' if t['type']=='em' else r'\nobreak\textsuperscript{'+t['id'].rsplit('-',1)[1]+'}' for t in ts)
def md(ts):
    return ''.join(t if isinstance(t,str) else '*'+md(t['children'])+'*' if t['type']=='em' else '[^'+t['id']+']' for t in ts)
meta='Anthony Kaldellis · The Invention of Byzantium in Early Modern Europe · Dumbarton Oaks, 2021 · pp. 349–367'
pre=r'''\documentclass[10pt,a4paper]{article}
\usepackage{fontspec,xeCJK}
\setmainfont{Times New Roman}
\setCJKmainfont[AutoFakeBold=2,AutoFakeSlant=.2]{SimSun}
\setCJKmonofont{SimSun}
\usepackage[margin=20mm,top=22mm,bottom=22mm]{geometry}
\usepackage{paracol,graphicx,hyperref,xurl,fancyhdr,needspace,xcolor}
\hypersetup{unicode=true,hidelinks}\urlstyle{same}
\setlength{\columnsep}{8mm}\setlength{\parindent}{0pt}\setlength{\parskip}{5pt}
\setlength{\emergencystretch}{3em}\tolerance=2000
\widowpenalty=5000\clubpenalty=5000
\pagestyle{fancy}\fancyhf{}\fancyhead[L]{\small Kaldellis: From “Empire of the Greeks” to “Byzantium”}
\fancyfoot[C]{\thepage}\setlength{\headheight}{14pt}
\begin{document}
'''
for lang in ['zh','en']:
    parts=['# '+a['title' if lang=='zh' else 'originalTitle'],meta,a['editionNotice'],a['license']]
    for row in a['body']:
        parts+=['<!-- '+row['id']+' -->',f"〔原书 pp. {row['page']}–{row['endPage']}〕",('> ' if row['type']=='quote' else '')+md(row[lang])]
    parts+=['## 原注 / Original notes']
    parts+=['[^'+k+']: '+md(v[lang]) for k,v in a['notes'].items()]
    parts+=['## 校注 / Editorial notes',*a['editorialNotes']]
    (out/f'article_{lang}.md').write_text('\n\n'.join(parts)+'\n',encoding='utf-8')
for bi in [True,False]:
    parts=[pre,r'{\Large\bfseries '+esc(a['title' if bi else 'originalTitle'])+r'\par}\medskip']
    if bi:parts+=[esc(a['originalTitle'])+r'\par']
    parts+=[esc(meta)+r'\par',esc(a['editionNotice'] if bi else 'Reading edition of chapter 13. All 49 original notes retained. Page labels refer to the printed source; source text and quotations preserved, with separate editorial notes.')+r'\par',esc(a['license'] if bi else 'Original copyright belongs to the rights holders. This is an unofficial reading edition.')+r'\par\bigskip']
    if bi:parts+=[r'\begin{paracol}{2}']
    for row in a['body']:
        def entry(lang):
            text=tex(row[lang]);label=str(row['page'])+('–'+str(row['endPage']) if row['endPage']!=row['page'] else '')
            val=r'{\scriptsize\color{gray}[p. '+label+r']}\ '+text+r'\par'
            if row['type']=='quote':val=r'\begin{quote}'+val+r'\end{quote}'
            for token in row[lang]:
                if isinstance(token,dict) and token['type']=='note':
                    val+=r'{\small '+token['id'].rsplit('-',1)[1]+'. '+tex(a['notes'][token['id']][lang])+r'\par}'
            return val
        if bi:parts+=[entry('zh'),r'\switchcolumn',entry('en'),r'\switchcolumn*']
        else:parts+=[entry('en')]
    if bi:parts+=[r'\end{paracol}']
    parts+=[r'\Needspace{6\baselineskip}\section*{校注 / Editorial notes}']
    parts+=[esc(str(i)+'. '+n)+r'\par' for i,n in enumerate(a['editorialNotes'],1)]
    parts+=[r'\end{document}']
    (out/('article_bilingual.tex' if bi else 'article_en.tex')).write_text('\n'.join(parts),encoding='utf-8')
shutil.copy2(base/'work/article.json',out/'article.json')
print(out)
