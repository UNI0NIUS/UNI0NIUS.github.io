from pathlib import Path
import sys,json,re,unicodedata,hashlib
from collections import Counter
base=next(Path(__file__).resolve().parent.glob('From *'));sys.path.insert(0,str(base.parents[1]/'tools/python_libs'))
import pymupdf as fitz
from PIL import Image,ImageDraw
a=json.loads((base/'work/article.json').read_text('utf-8'));v=base/'work/visual';v.mkdir(exist_ok=True)
def plain(ts):return ''.join(t if isinstance(t,str) else plain(t['children']) if t['type']=='em' else t['id'].rsplit('-',1)[1] for t in ts)
def norm(s):return ''.join(c for c in unicodedata.normalize('NFKD',s) if c.isalnum())
report={}
for name,langs in [('article_bilingual',['zh','en']),('article_en',['en'])]:
    pdf=base/'output'/f'{name}.pdf';d=fitz.open(pdf)
    strings=[];outside=[]
    for n,page in enumerate(d):
        strings.append(page.get_text())
        for b in page.get_text('blocks'):
            if b[0]<45 or b[2]>page.rect.width-45 or b[1]<25 or b[3]>page.rect.height-25:outside.append([n+1,list(b[:4]),b[4][:60]])
        pix=page.get_pixmap(matrix=fitz.Matrix(1,1));pix.save(v/f'{name}-{n+1:02}.png')
    actual=norm(''.join(strings))
    # Whole-document character multiplicities expose missing text without assuming PDF block order.
    expected=''.join(plain(r[l]) for l in langs for r in a['body'])+''.join(plain(r[l]) for l in langs for r in a['notes'].values())
    deficit=Counter(norm(expected))-Counter(actual)
    log=(base/'output'/f'{name}.log').read_text('utf-8',errors='replace')
    report[name]=dict(pages=len(d),sha256=hashlib.sha256(pdf.read_bytes()).hexdigest(),character_deficit=dict(deficit),outside=outside,critical_log=[x for x in log.splitlines() if 'Missing character' in x or 'Overfull' in x or x.startswith('!')],visual_review='pending')
    for start in range(0,len(d),6):
        sheet=Image.new('RGB',(1200,1740),'#dddddd');draw=ImageDraw.Draw(sheet)
        for j in range(start,min(start+6,len(d))):
            im=Image.open(v/f'{name}-{j+1:02}.png');im.thumbnail((590,550))
            x=((j-start)%2)*600;y=((j-start)//2)*580
            sheet.paste(im,(x+(600-im.width)//2,y+22));draw.text((x+10,y+5),f'{name} p{j+1}',fill='black')
        sheet.save(v/f'{name}-sheet-{start//6+1}.jpg')
(base/'work/output-check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
