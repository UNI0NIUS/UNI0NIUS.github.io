from pathlib import Path
import sys,json,re,unicodedata,hashlib
base=next(Path(__file__).resolve().parent.glob('From *'));sys.path.insert(0,str(base.parents[1]/'tools/python_libs'))
import pymupdf as f
a=json.loads((base/'work/article.json').read_text('utf-8'))
def plain(ts):return ''.join(t if isinstance(t,str) else plain(t['children']) if t['type']=='em' else '' for t in ts)
def norm(s):return ''.join(c for c in unicodedata.normalize('NFKD',s) if c.isalpha())
out={}
for file,langs in [('article_bilingual',['zh','en']),('article_en',['en'])]:
 d=f.open(base/'output'/f'{file}.pdf');out[file]={}
 for lang in langs:
  strings=[]
  for p in d:
   left,right=(0,p.rect.width) if file=='article_en' else ((0,p.rect.width/2) if lang=='zh' else (p.rect.width/2,p.rect.width))
   strings.append(p.get_text(clip=f.Rect(left,55,right,790),sort=True))
  stream=norm(''.join(strings));missing=[]
  for key,row in [(r['id'],r) for r in a['body']]+list(a['notes'].items()):
   want=norm(plain(row[lang]))
   if want not in stream:missing.append(key)
  out[file][lang]={'units':89,'missing':missing,'method':'全文各栏按页接续，NFKD后保留字母（含汉字），逐一搜索40正文+49原注完整文本；数字另由字符计数检查覆盖。'}
(base/'work/readback.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(out,ensure_ascii=False,indent=2))
