# Ibn Khaldûn as a Colonial Archive: Toward an Epistemic Decolonization

Abdelmajid Hannoum. Anthropology, University of Kansas, Lawrence, Kansas, USA. Email: hannoum@gmail.com. Comparative Studies in Society and History (2026), 1–25. Published online: 16 October 2026.

https://doi.org/10.1017/S0010417526100693

据Cambridge University Press出版方HTML完整翻译，并与25页原刊PDF核对结构及段落起始页码。保留摘要、全部正文、致谢和94条原注；无独立书目或图表。论述性注释完整翻译，书目信息照录并附中文题名译释。© The Author(s), 2026；Cambridge University Press代表Society for the Comparative Study of Society and History出版。原文及本译文采用CC BY 4.0；须注明出处、许可与改动。翻译、译释及编者说明为本版新增；AI辅助工作译稿，不代表作者或出版社认可。

CC BY 4.0: https://creativecommons.org/licenses/by/4.0/

Keywords: Ibn Khaldûn; colonial translation; Orientalism; race and racialization; sociology of knowledge; colonial epistemology; historiography of the Maghreb; decolonization; non-Western social theory; knowledge production

<!-- ibn-khaldun-colonial-archive-001 -->

〔原刊 p. 1〕

## Abstract

<!-- ibn-khaldun-colonial-archive-002 -->

〔原刊 p. 1〕

This article examines Ibn Khaldûn not as a stable, timeless precursor of modern social science but as a figure constituted through colonial translation and reception. Focusing on nineteenth- and twentieth-century French and English translations of the *Muqaddimah*, it argues that Ibn Khaldûn emerged in modern scholarship as a colonial archive—a site where translation, race, and epistemic authority intersected to produce new forms of historical and sociological knowledge. Through close comparison of Arabic originals and their European translations, the article shows how colonial epistemologies reconfigured Ibn Khaldûn’s analytical categories—particularly those concerning tribe, generation, civilization, and climate—into racialized frameworks foreign to his medieval context. It further demonstrates how this translated Ibn Khaldûn became selectively relevant to European social science while remaining excluded from its canonical genealogies. Finally, the article critically reassesses the enduring claim that Ibn Khaldûn articulated racist views about Black populations, showing that this attribution itself belongs to the colonial archive generated through translation rather than to the epistemic logic of the original text. The article thus contributes to comparative histories of knowledge, colonial epistemology, and the global formation of the social sciences.

<!-- ibn-khaldun-colonial-archive-003 -->

〔原刊 p. 1〕

Among Muslim thinkers of the medieval era, Ibn Khaldûn occupies a distinct place not only in the medieval genealogy of historical knowledge but also in the modern one. In the context of the colonization of Algeria, Ibn Khaldûn emerged as a major thinker—first in French, through the translation of William McGuckin de Slane, and later in English, through the translation of Franz Rosenthal, which follows the French text.[^ibn-khaldun-colonial-archive-1] It is through these translations and their reception that Ibn Khaldûn came to be constituted as a major historical and sociological figure in modern European scholarship. His importance has been such that he is one of the very few medieval figures, if not the only one, who has relevance to the modern social sciences, especially at the time of their emergence in the nineteenth century.[^ibn-khaldun-colonial-archive-2] He garners recognition and respect and appears among the few thinkers from outside the Western tradition who are regularly quoted in the halls of academe. Moreover, he may be the only non-Western thinker to be placed alongside Georg Wilhelm Friedrich Hegel, Karl Marx, and Max Weber.[^ibn-khaldun-colonial-archive-3] Yet, paradoxically, this intriguing figure is also largely erased from the history of European thought even as he is sometimes compared to its iconic figures. He is absent from its genealogy even when his concepts resonate with the modern, foregrounding some of the perspectives and even theories of modern sociology.[^ibn-khaldun-colonial-archive-4] This article approaches the constitution of that relevance and authority, considering it not as a neutral process of transmission but as a colonial one, and asking how Ibn Khaldûn was transformed from a medieval author to a modern one who is himself a colonial archive.

<!-- ibn-khaldun-colonial-archive-004 -->

〔原刊 p. 2〕

Ibn Khaldûn is the author of a considerable historiographic work called the *Kitâb al-ʿIbar*, in three volumes, not all of which have gained the same attention.[^ibn-khaldun-colonial-archive-5] The first volume is the *Muqaddimah*, the text for which he is best known; it earned him a special place among world historians. The second volume is a history of the Berbers that, as translated by William de Slane in the mid-nineteenth century, serves as a foundational text on the history of the Maghreb—a major historiographic reference with a distinct discursive trajectory. Colonial historians relied on this volume not only to create a French historiography of the Maghreb but also to invent a new conception of the region.[^ibn-khaldun-colonial-archive-6] The third volume of Ibn Khaldûn’s *Kitâb al-ʿIbar*, which deals with the history of Islam and of Muslim dynasties in the East (*Mashriq*), was composed after his move to Egypt in 1382. By the turn of the twentieth century, scholars such as Reynold Alleyne Nicholson considered this volume less innovative than the *Muqaddimah*, noting that Ibn Khaldûn’s method is applied less systematically here. This view, repeated by Taha Hussein in 1918 and by others, reinforced the perception that the *Muqaddimah* is largely detached from the more traditional historiographic content of the third volume and even the second volume.[^ibn-khaldun-colonial-archive-7] Consequently, in Western academia, it has received comparatively little attention and has not been translated into English. Its neglect is particularly striking compared to both the *Muqaddimah* and the second volume, which, as noted earlier, was foundational for French colonial scholars of the Maghreb and, subsequently, North African national historians.[^ibn-khaldun-colonial-archive-8]

<!-- ibn-khaldun-colonial-archive-005 -->

〔原刊 p. 3〕

In this article, I propose to interrogate Ibn Khaldûn as a colonial archive—a site where knowledge about a medieval author is produced, transformed, and regulated through translation, reception, and disciplinary frameworks shaped by colonial and European epistemes. The colonial archive highlights not only the multiple authorial figures associated with Ibn Khaldûn but also the processes through which these figures are conflated, racialized, or erased.

<!-- ibn-khaldun-colonial-archive-006 -->

〔原刊 p. 3〕

My inquiry follows four intertwined threads: first, the translation of Ibn Khaldûn’s *Muqaddimah* and the conditions that produced Ibn Khaldûn as a colonial author; second, the ways in which this colonial author gained relevance and authority within European knowledge systems; third, how his text and ideas have been racialized and reframed through colonial interpretive practices; and finally, how, despite his recognition in Orientalist scholarship as an outstanding personality and even a genius, Ibn Khaldûn has often been excluded from histories of European sociological theory. Addressing these questions requires not only recovering the medieval author but also engaging in an epistemic decolonization—interrogating the assumptions, structures, and practices that have governed what counts as knowledge of him and about him. First, however, let me outline the intellectual context and multiple receptions of Ibn Khaldûn in order to situate the argument of this article, which focuses on the transformation of his thought through translation within a colonial epistemic framework.

<!-- ibn-khaldun-colonial-archive-007 -->

〔原刊 p. 3〕

## Before and Beyond the Colonial Archive

<!-- ibn-khaldun-colonial-archive-008 -->

〔原刊 p. 3〕

Ibn Khaldûn’s work must be situated within the intellectual and political milieu of the fourteenth-century Islamic West, particularly the Maghreb and al-Andalus, regions marked by both vibrant scholarly activity and acute political instability. Dynastic rivalries, shifting allegiances, and the far-reaching consequences of the Black Death created a world in which the fragility of power and the transformation of societies were constantly on display. These conditions were not merely background to Ibn Khaldûn’s thought but constituted the very material from which his historical analysis emerged. Several studies have examined this context, especially the work of Muhsin Mahdi, who situates Ibn Khaldûn in relation to Greek thought,[^ibn-khaldun-colonial-archive-9] and Abdessalem Cheddadi, who investigates both Ibn Khaldûn and his time as well as his modern receptions.[^ibn-khaldun-colonial-archive-10] Given the scope of this study—examining the emergence of Ibn Khaldûn as a colonial archive—I outline some important instances of reception, including those often neglected.

<!-- ibn-khaldun-colonial-archive-009 -->

〔原刊 p. 3〕

Intellectually, Ibn Khaldûn was formed within a well-established tradition that organized knowledge into the “traditional sciences” and the “rational sciences.” His education reflects this dual structure.[^ibn-khaldun-colonial-archive-11] What distinguishes him is the way he mobilized it. His exposure to philosophical thought—particularly through al-Abili and engagement with Avicenna, al-Razi, and Ibn Rushd—left a clear imprint on his analytical method, while his grounding in the religious sciences anchored his work within the broader Islamic scholarly tradition.[^ibn-khaldun-colonial-archive-12] This formation was inseparable from political experience. Ibn Khaldûn’s career—across Tunis, Fez, Granada, and Cairo—placed him in direct contact with rulers, jurists, and scholars, exposing him to the instability of dynasties and the role of social solidarities in sustaining authority.[^ibn-khaldun-colonial-archive-13]

<!-- ibn-khaldun-colonial-archive-010 -->

〔原刊 p. 4〕

The historiographical tradition he inherited relied heavily on transmission. Historians such as al-Tabari and al-Masʿudi compiled extensive chronicles but did not systematically interrogate the conditions that made historical events possible. Of these two historians, Ibn Khaldûn considers al-Tabari “the historian of the umma” (*mu’arrikh al-umma*). Meanwhile, Masʿudi (d. 956) is the author of a major book from which Ibn Khaldûn is likely to have drawn most of his material on human diversity and even his theory of climatic effects on humans, which Masʿudi himself borrowed from Galen. Yet Ibn Khaldûn vigorously critiqued Masʿudi’s views, especially in regard to Black populations, as I will show below. In his introduction, Ibn Khaldûn notes that his enterprise resembles those of Tabari and Masʿudi, consisting mainly in recording a moment of great historical change.

<!-- ibn-khaldun-colonial-archive-011 -->

〔原刊 p. 4〕

Ibn Khaldûn’s other inspirations include Ibn al-Khatîb, his close friend and author of a history of Granada, where one finds mentions of the concept of *ʿaṣabiyya.* Ibn Khaldûn integrated this concept into his explanation of how a tribe becomes a state. Another is his younger rival, Ibn Radwan, also an Andalusian from Tunis, author of a major book on courts and politics that constitutes an important source for Ibn Khaldûn.[^ibn-khaldun-colonial-archive-14] However, despite, or rather because of, these models, Ibn Khaldûn’s innovation in the *Muqaddimah*—particularly his analysis of *umrân* (often translated as “culture” or “civilization”) and *ʿaṣabiyya* (tribal solidarity)—introduced a critical and explanatory dimension that centered on the making of the state (*dawla*) and sought to uncover the underlying principles governing human societies.[^ibn-khaldun-colonial-archive-15]

<!-- ibn-khaldun-colonial-archive-012 -->

〔原刊 p. 4〕

Ibn Khaldûn’s work has been read differently across historical contexts. Early on, some of his contemporaries recognized the *Muqaddimah* as a new contribution. As a historian, he was highly regarded, and his work circulated through teaching and scholarly exchange. Figures such as al-Maqrizi and Ibn al-Azraq engaged with his concepts and extended aspects of his method. His historiography maintained a strong presence in Maghrebi intellectual traditions for centuries.[^ibn-khaldun-colonial-archive-16]

<!-- ibn-khaldun-colonial-archive-013 -->

〔原刊 p. 4〕

By the late sixteenth century, Ibn Khaldûn’s work reached the heart of the Ottoman Empire. In 1598, Veysî Efendi, the Ottoman scholar and poet, acquired a manuscript of the *Muqaddimah* in Cairo.[^ibn-khaldun-colonial-archive-17] However, ideas similar to those developed by Ibn Khaldûn in the *Muqaddimah* appear in the work of Mustafa Ali, an important sixteenth-century Ottoman intellectual. While copies of the *Muqaddimah* circulated in the Ottoman Empire throughout the sixteenth century, it was in the seventeenth century that Ibn Khaldûn was openly discussed, expanded on, and borrowed from by historians of the empire, especially those interested in the idea of the decline of dynastic powers and the administration of the states. Kâteb Çelebi *(Hajji Khalifa)* (d. 1657) and Mustafa Naima (d. 1716) are early figures who not only read and knew the *Muqaddimah* but also used its ideas in their writings on the Ottoman Empire.[^ibn-khaldun-colonial-archive-18] However, the *Muqaddimah* also had influence beyond academic circles, becoming important in the formation of the politicians, diplomats, intellectuals, and bureaucrats of the Empire.[^ibn-khaldun-colonial-archive-19]

<!-- ibn-khaldun-colonial-archive-014 -->

〔原刊 p. 5〕

Europe knew of Ibn Khaldûn at least as early as the sixteenth century, through another important text, written in Latin by a Moroccan diplomat and convert, Hassan al-Wazzan. He wrote *A Description of Africa* in 1550, translated into French in 1555 and into English in 1600.[^ibn-khaldun-colonial-archive-20] Ibn Khaldûn is cited throughout the book. A copy of the *Muqaddimah* existed in seventeenth-century Leiden.[^ibn-khaldun-colonial-archive-21] Meanwhile, Thomas Hobbes’s treatise on the necessity (and naturalness) of the state is reminiscent of the same discussion found in the *Muqaddimah.* Is this a coincidence? Perhaps—but the parallel is striking. Even if it is a coincidence, a historian of ideas would necessarily have explored the connections between thinkers examining something as important as the state—not necessarily to suggest that one borrowed from the other, but to highlight the political and philosophical conditions that made such reflection possible.

<!-- ibn-khaldun-colonial-archive-015 -->

〔原刊 p. 5〕

Be that as it may, in modern contexts, Ibn Khaldûn continued to be read through mediation. Engagements during the Arab renaissance of the twentieth century, such as that of Taha Hussein, relied heavily on the French translation of de Slane, treating it as a substitute for the Arabic text rather than as a colonial artifact in its own right. In the context of colonial domination, interest in Ibn Khaldûn also reflected a broader ideological need to mobilize major intellectual figures in response to Western cultural dominance.[^ibn-khaldun-colonial-archive-22] Across these diverse contexts, a common pattern emerges: Ibn Khaldûn’s work is rarely encountered on its own terms but is mediated through translations, ideological frameworks, and scholarly traditions that reshape its meaning for each audience. His reception extended beyond the Arab world: in Iran, for example, Ali Shariati read Ibn Khaldûn as a philosopher of history through categories influenced by European thought. In his reading, one encounters Émile Durkheim in Ibn Khaldûn more than Ibn Khaldûn in Durkheim. In other words, rather than searching for Ibn Khaldûn’s ideas in Durkheim, or arguing—as is often done—that Durkheim borrowed from the medieval historian, Shariati points out that Ibn Khaldûn, as a Muslim thinker, had already rethought the craft of history long before similar reflections emerged in the age of modernity. However, Shariati’s broader political concerns aligned more closely with the anticolonial immediacy of thinkers such as Frantz Fanon, while his engagement with Ibn Khaldûn centered primarily on questions of history, social change, and the rise and decline of civilizations.[^ibn-khaldun-colonial-archive-23]

<!-- ibn-khaldun-colonial-archive-016 -->

〔原刊 p. 6〕

Despite Ibn Khaldûn’s wide reception across disciplines and cultures, he has rarely been interrogated through a decolonial or postcolonial lens. Major figures of early decolonizing thought, such as Abdallah Laroui, Abdelkebir Khatibi, and Mohammed Abid al-Jabri, engage seriously with his work, yet they mobilize him primarily as a resource for rethinking modernity in the Arab context rather than making him the object of the kind of critique I propose here—one that interrogates the colonial/postcolonial constructions of Ibn Khaldûn we inherited, including the role of translation, Orientalist mediation, and editorial transmission.[^ibn-khaldun-colonial-archive-24] Mohamed Arkoun argues that the interest in Ibn Khaldûn is due, of course, to “the theoretical scope of the Muqaddima,” but also “the need of contemporary ideology to rely on major figures of the past in order to resist the ‘cultural aggression’ of the West.”[^ibn-khaldun-colonial-archive-25]

<!-- ibn-khaldun-colonial-archive-017 -->

〔原刊 p. 6〕

Likewise, within postcolonial studies—most prominently associated with Edward Said—Ibn Khaldûn appears often as a name, but only marginally. Beyond a few passing references to *ʿaṣabiyya* and one reference to secularism,[^ibn-khaldun-colonial-archive-26] Said does not engage either the medieval author or the afterlives of his work in colonial knowledge systems, including in Orientalist scholarship, where Ibn Khaldûn was effectively reconstituted as an object of European knowledge.

<!-- ibn-khaldun-colonial-archive-018 -->

〔原刊 p. 6〕

This absence is striking, especially given Said’s own admission of a long-standing intellectual interest in Ibn Khaldûn: “For at least thirty years,” he remarked in an interview, “I’ve been planning a seminar on Vico and Ibn Khaldûn, the great fourteenth-century historiographer and philosopher of history. But my sense of identity as a teacher of Western literature has excluded this other aspect of my activity so far as the classroom is concerned.”[^ibn-khaldun-colonial-archive-27] Such a stance presumes a stable division between “Western” and “Arabic” intellectual traditions. Yet this boundary becomes less tenable when one considers that Ibn Khaldûn’s *Muqaddimah* entered modern intellectual history through its nineteenth-century French translation—a foundational textual moment in the formation of French Orientalism.[^ibn-khaldun-colonial-archive-28] Had Said encountered Ibn Khaldûn within this Orientalist archive, the terms of disciplinary belonging—and thus of engagement—might have appeared differently.

<!-- ibn-khaldun-colonial-archive-019 -->

〔原刊 p. 6〕

Several factors explain Ibn Khaldûn’s noticeable absence from decolonial and postcolonial critique, linked to the historical trajectory through which his work entered modern scholarship. One concerns the problem of translation. Since Walter Benjamin, translation has been recognized as a central theoretical concern within literary studies, yet few postcolonial scholars have foregrounded it as a site of colonial and postcolonial intervention.[^ibn-khaldun-colonial-archive-29] Translation studies have often developed on a parallel track to postcolonial scholarship, despite their shared investments. Only more recently have postcolonial and decolonial approaches begun to examine translation systematically as a site of epistemic transformation.[^ibn-khaldun-colonial-archive-30] The translation of historiography in particular has remained under-theorized, especially during the consolidation of postcolonial studies in the 1990s, as scholars of Ibn Khaldûn frequently treated his translation as transparent rather than as a site of conceptual reconfiguration.

<!-- ibn-khaldun-colonial-archive-020 -->

〔原刊 p. 7〕

A related factor is that postcolonial studies, shaped in large part by Said’s *Orientalism*, have concentrated on Arabic literary studies but much less on Arabic historiography, which remains more closely aligned with the intellectual field that Said’s critique originally targeted.[^ibn-khaldun-colonial-archive-31] Translation was not then seen as a site of postcolonial investigation. Even the translation of Frantz Fanon into English was taken for granted, and it was only lately that it was examined as a site of postcolonial transformations.[^ibn-khaldun-colonial-archive-32] This pattern is reinforced by a broader tendency within both postcolonial and decolonial thought to foreground modern regimes of power while leaving the premodern comparatively under-theorized. The result is an assumption of epistemic innocence attached to premodern power and its figures. Ibn Khaldûn thus appears as a medieval thinker outside the primary terrain of critique, rather than as a figure actively reconstituted within colonial knowledge systems through translation. In this sense, even the frequent accusations of racism directed at Ibn Khaldûn are themselves effects of this colonial reconfiguration—a question to which I return below.

<!-- ibn-khaldun-colonial-archive-021 -->

〔原刊 p. 7〕

This article focuses on French and English translations and their place within a colonial genealogy. Its primary concern is the transformation of Ibn Khaldûn’s thought within colonial modernity, particularly in the context of Algeria from the mid-nineteenth century onward. Later English translations extended the afterlife of the French text but remained tied to a genealogy traceable to de Slane.

<!-- ibn-khaldun-colonial-archive-022 -->

〔原刊 p. 7〕

The colonial archive analyzed in this article should therefore be understood as one among several historically situated reconfigurations of Ibn Khaldûn’s thought. What distinguishes that archive is that it translates his categories into a racial episteme that fundamentally alters their meaning. It is this transformation—rather than the original Arabic text—that underlies many modern interpretations of his work, including the construction of Ibn Khaldûn as a racist author.

<!-- ibn-khaldun-colonial-archive-023 -->

〔原刊 p. 7〕

## Colonizing Ibn Khaldûn

<!-- ibn-khaldun-colonial-archive-024 -->

〔原刊 p. 7〕

Ibn Khaldûn’s reception in Europe unfolded within the broader framework of the Orientalist enterprise, closely tied to the systematic recovery and publication of Islamic manuscripts led by Silvestre de Sacy in the early 1800s. As Edward Said writes, “Sacy’s name is associated with the beginning of modern Orientalism…his work virtually put before the profession an entire systematic body of texts, a pedagogic practice, a scholarly tradition, and an important link between Oriental scholarship and public policy.”[^ibn-khaldun-colonial-archive-33] Within this newly constituted archive, Ibn Khaldûn occupied a central place.[^ibn-khaldun-colonial-archive-34] It may be, as I once wrote, the “greatest textual event in the history of French orientalism.[^ibn-khaldun-colonial-archive-35]

<!-- ibn-khaldun-colonial-archive-025 -->

〔原刊 p. 8〕

As noted in the preceding section of this article, there were numerous copies of Ibn Khaldûn’s work throughout the Ottoman Empire, including in North Africa. Europe appears to have been familiar with Ibn Khaldûn before the colonial era. Manuscripts were actively acquired, particularly during the nineteenth century, and copies existed in France at the *Bibliothèque nationale*, dating from the seventeenth or eighteenth century. The Ottoman Empire was a source of this knowledge, “a magnetic pole in the field of knowledge for scholarly Europe.”[^ibn-khaldun-colonial-archive-36] Ibn Khaldûn had long been present in Europe, including in Paris, before the conquest of Algiers in July 1830. De Sacy encountered Ibn Khaldûn through the Arabic manuscripts and scholarly resources available to him in Paris. According to Lucette Valensi, de Sacy brought Ibn Khaldûn to prominence by virtue of his institutional position and the resources it placed at his disposal.[^ibn-khaldun-colonial-archive-37] Yet this prominence reached its zenith under colonialism, which transformed Ibn Khaldûn’s status from that of a Muslim scholar, an Arab savant, into that of a colonial author whose work had a profound impact on the production of knowledge on the region and, beyond it, on colonial policy and the making of the colony.

<!-- ibn-khaldun-colonial-archive-026 -->

〔原刊 p. 8〕

De Sacy was indeed instrumental in bringing Ibn Khaldûn into European Orientalist scholarship. In 1806, he published the first excerpts from the *Muqaddimah*, followed by more substantial passages in 1810. In 1818, he returned to Ibn Khaldûn with a more comprehensive appraisal of the *Kitâb al-ʿIbar*, declaring that no Arabic historical work deserved publication more. This positioned Ibn Khaldûn as a major figure within European understandings of Arabic historiography. For his contemporaries, de Sacy presented him not only as an outstanding historian but also as the author of a text that was relevant to the study of Algeria and valuable for public policy—signaling early on the dual destiny that awaited him in Europe: celebrated for originality, yet reconstructed through translation, commentary, and appropriation to serve imperial projects.

<!-- ibn-khaldun-colonial-archive-027 -->

〔原刊 p. 8〕

Following de Sacy, his students and intellectual heirs undertook sustained efforts to disseminate Ibn Khaldûn’s ideas. In 1822, Joseph von Hammer-Purgstall published a detailed summary of the *Muqaddimah* in the *Journal Asiatique*, emphasizing the urgency of translation. This was followed by Garcin de Tassy’s supplementary review in 1824 and F. E. Schulz’s extensive critical discussion in 1825, consolidating Ibn Khaldûn’s status within Orientalist scholarship and laying the groundwork for his later canonization.

<!-- ibn-khaldun-colonial-archive-028 -->

〔原刊 p. 8〕

Before proceeding further, it is necessary to outline the general structure of Ibn Khaldûn’s work and to situate it within the historical circumstances of its composition—an account that Ibn Khaldûn himself provides in the concluding autobiographical section of the *ʿIbar*, entitled *al-Taʿrîf bi Ibn Khaldûn.*

<!-- ibn-khaldun-colonial-archive-029 -->

〔原刊 p. 9〕

To appreciate how profoundly this reinterpretation altered Ibn Khaldûn, it is worth recalling the scope of his original work. Writing in a fourteenth-century Maghreb marked, in his view, by Arab supremacy, Berber weakness, and the devastation of plague, he sought to record the transformations of his own age. His history of the Berbers—set within a broader Islamic and universal history—was a defense of their achievements, inserting the Berbers into world history alongside Arabs, Persians, Greeks, and Romans. He even traced their genealogy back to Canaan, son of Noah, embedding them within sacred history.[^ibn-khaldun-colonial-archive-38]

<!-- ibn-khaldun-colonial-archive-030 -->

〔原刊 p. 9〕

The *ʿIbar*, in its discursive totality, reveals Ibn Khaldûn’s vision and even Muslim historiographic imagination in medieval times: history is not a linear progression but a cyclical transformation. Tribes rise to power through *ʿaṣabiyya*, or social cohesion, underpinned by religion, and then establish dynasties. These dynasties, within at most four generations, decay under the weight of luxury, injustice, and complacency, and are eventually replaced by a new group, a new tribe that goes through the same process of dynastic formation—from *ʿaṣabiyya* to *dawla.* Power, in Ibn Khaldûn’s understanding, was always contingent. No nation, as evidenced by the histories of the Greeks, the Persians, the Arabs, the Israelites, and the Berbers, was permanently dominant, and no dynasty, regardless of its might, was permanent.[^ibn-khaldun-colonial-archive-39]

<!-- ibn-khaldun-colonial-archive-031 -->

〔原刊 p. 9〕

Ibn Khaldûn’s original categories reflected a cyclical and contingent vision of history, since dynasties are subjected to patterns they reproduce, and one of these patterns is precisely their contingency. The category of *jîl*, a key concept in his analysis, points to temporality and change. The term *jîl* meant a generation, a group of people bound together by time, genealogy, or way of life. He could speak of *al-jîl al-awwal li al-ʿarab* (the first generation of the Arabs) or *al-jîl al-thâni al-barbar* (the second generation of the Berbers), and he distinguished between *jîl al-badw* (the nomadic generation) and *jîl al-ḥaḍar* (the urban, sedentary stage). *Ṭabaqa* referred to strata or layers of society, while *umma* designated a community of faith—most prominently, the community of Islam—or a historical community like “the Persians” or “the Arabs.”[^ibn-khaldun-colonial-archive-40]

<!-- ibn-khaldun-colonial-archive-032 -->

〔原刊 p. 9〕

Again, what unites these categories is their temporality and fluidity. Groups differed in power, cohesion, and customs, but none was inherently fixed as superior or inferior. Inequality was real; it existed between tribes and between nations in terms of *ʿumrân* only, but it was never permanent. Ibn Khaldûn also explained differences in terms of environment and economy: climate affected skin color and temperament; livelihood shaped culture and customs. Above all, religion gave cohesion to a tribe’s *ʿaṣabiyya* and allowed it to extend its reach; yet even religiously empowered dynasties succumbed to the same cycle of rise and fall.

<!-- ibn-khaldun-colonial-archive-033 -->

〔原刊 p. 9〕

When de Sacy emphasized the need to translate the *Muqaddimah*, he also proposed its French title, *Prolégomènes historiques*, which later became the official title of the French translation by his student, de Slane. Joseph von Hammer-Purgstall, in contrast, stressed the urgency of translating the section concerning the history of the Berbers—that is, the second book of Ibn Khaldûn’s work. In 1847, de Slane, who served as the principal interpreter for the *Armée d’Afrique*, published the Arabic text of this section under the auspices of the Imprimerie du Gouvernement (Government Press). Seven years later, in 1854, he released the French translation under the title *L*’*histoire des Berbères.*

<!-- ibn-khaldun-colonial-archive-034 -->

〔原刊 p. 10〕

In 1858, Quatremère published the Arabic text of the *Muqaddimah*, which de Slane subsequently translated and published in 1863 under the title *Prolégomènes.* The two texts followed distinct trajectories: the *Muqaddimah* became a valuable resource for sociologists such as Émile Durkheim and Robert Montagne, while *L’histoire des Berbères* provided the structural foundation for the study of North African history.[^ibn-khaldun-colonial-archive-41] Notably, *L*’*histoire des Berbères* was commissioned and published by the Ministry of War, highlighting its perceived significance for the colonial administration. Joseph Reinaud remarked on this relevance: “*The History of the Berbers* of Ibn Khaldûn could not fail to draw the attention of the French government. With the establishment of the French in Algeria, daily relations, contacts of friendships, and war have been established between them and the tribes that occupy the interior of the country.”[^ibn-khaldun-colonial-archive-42]

<!-- ibn-khaldun-colonial-archive-035 -->

〔原刊 p. 10〕

One can see that the discovery of Ibn Khaldûn was inscribed within the larger project of the colonial enterprise, which made knowledge a cornerstone of its policies to rule and to govern, and, by the same token, created colonial archives in which knowledge and power, politics, and episteme, are intertwined. This Ibn Khaldûn was a central part of the colonial archives, whose existence was initiated through translation.

<!-- ibn-khaldun-colonial-archive-036 -->

〔原刊 p. 10〕

## Translation as the Birthplace of Colonial Ibn Khaldûn

<!-- ibn-khaldun-colonial-archive-037 -->

〔原刊 p. 10〕

Arguably the most significant textual event in the history of Orientalism, Ibn Khaldûn, the colonial author, was born gradually and in fragments.[^ibn-khaldun-colonial-archive-28] By 1850, however, this colonial author could be recognized in two distinct forms. The first is as the historian of a foundational text on North African history, *L’histoire des Berbères.* From the moment of its publication, this work became the central reference for French historians in constructing knowledge of the region that, from 1928 onward, came to be known as the Maghreb.

<!-- ibn-khaldun-colonial-archive-038 -->

〔原刊 p. 10〕

The second form is that of an epistemic authority—one who moves beyond narrating events to investigating their underlying causes, examining the formation of tribes, their rise to power, and the emergence of states that generate complex social structures, or *ʿumrân*, characterized by the creation of sciences, crafts, and state organization itself. In the context of the development of social science around Durkheim and his circle, Ibn Khaldûn came to transcend the colonial Algerian context, becoming a major intellectual figure invoked across disciplines such as anthropology, sociology, economics, and history.[^ibn-khaldun-colonial-archive-43] This emergence gave rise to what might be called “Khaldûnism,” analogous to the way we speak of Marxism—a discursive framework in which the authoritative colonial figure of Ibn Khaldûn eclipses the medieval scholar, largely through translation that reinterpreted him within a European epistemic paradigm.[^ibn-khaldun-colonial-archive-44]

<!-- ibn-khaldun-colonial-archive-039 -->

〔原刊 p. 11〕

De Slane’s translations were prefaced by long introductions that did more than summarize; they actively reinterpreted the works and thereby shaped how the translated texts would be read. He declared Ibn Khaldûn’s Arabic “verbose and repetitive”[^ibn-khaldun-colonial-archive-45] and in need of correction, positioning himself not as a mere translator but as a rectifier and commentator. In the introduction to his translation, de Slane provides what I call a historical narrative of a quest, a narrative with a plot—with heroes (Berbers) and villains (Arabs), and a narrative program consisting of the quest for liberation. Yet since this quest was not achieved within *L’histoire des Berbères* itself, the introduction that de Slane wrote and added comes, in light of the subsequent colonization of Algeria, to suggest an unspoken quest—one in which the French implicitly become the heroes. They appear as liberators of the Berbers from the “Arab yoke,” a liberation that the French claimed to have achieved through the conquest of Algeria in 1830.

<!-- ibn-khaldun-colonial-archive-040 -->

〔原刊 p. 11〕

If the introduction by de Slane is fused with a racial ideology that guides, if not shapes, the reader’s understanding of the text, the translated text is itself structured according to the racial ideology of the nineteenth century. De Slane translated Ibn Khaldûn’s categories into the racial semantics of nineteenth-century France. *Jîl* is translated as “race.” *Umma* becomes “nation.” A “generation of Arabs” becomes “the Arab race.” A “generation of Berbers” becomes “the Berber race.” The fluid and contingent communities of Ibn Khaldûn’s imagination were thus frozen into racial blocs defined by antagonism. His concept of *fatḥ*—commonly used among Arab historiographers to mean the “opening” of an era of Islam, and understood positively as divine favor and spiritual transformation—was rendered as “conquest” or “domination,” terms connoting forced subordination and colonialism.[^ibn-khaldun-colonial-archive-46]

<!-- ibn-khaldun-colonial-archive-041 -->

〔原刊 p. 11〕

De Slane’s translation created a discursive structure whereby the resulting text produced became a foundational colonial text while generating a variety of discourses—colonial, national, and postcolonial—still at work today. Ibn Khaldûn’s cyclical history of tribes became a racialized binary narrative of Arabs versus Berbers, domination versus resistance. His integrative defense of Berbers as equals to Arabs and other nations was transformed into a colonial ethnography in which Berbers were reimagined as originally European, white-skinned, democratic, heirs to Roman law, and therefore natural allies of France. Berbers were also defined in opposition to Arabs—nomadic, Oriental oppressors, destructive, and fanatical. Yet this translation, because it emerged in the colonial context, contained not only a binary opposition between Berbers and Arabs but also a tertiary relation in which the European is tacitly present and explicitly plays the role of a hero, a savior—the one who ended Arab domination with colonization and freed both the land, once Roman, and the Berbers, originally Europeans, from the hand of the villain, an Arab conqueror. The text of Ibn Khaldûn thus becomes a story of a quest, in which a new colonial narrative grammar is introduced, not just a new narrative syntax.[^ibn-khaldun-colonial-archive-47]

<!-- ibn-khaldun-colonial-archive-042 -->

〔原刊 p. 11〕

This transformation was made possible by the intellectual climate of nineteenth-century France, where race was treated as an essential category for understanding human diversity, condition, and development. It was the same climate that made history an undeniable mark of modernity itself,[^ibn-khaldun-colonial-archive-48] showing the unfolding of history and the rise of modern Europe as a universal civilization. Thinkers such as Arthur de Gobineau, Hippolyte Taine, and Ernest Renan defined history in terms of races and nations. For Gobineau, races were inherently unequal, with the Aryan race uniquely capable of creating civilization.[^ibn-khaldun-colonial-archive-49] Taine studied the “genius” of races as expressed in literature and art.[^ibn-khaldun-colonial-archive-50] Renan, who knew of Ibn Khaldûn, defined nations as communities built on shared memories and forgetting; he also insisted that Semitic peoples—Arabs and Jews alike—were incapable of science and liberal government.[^ibn-khaldun-colonial-archive-51]

<!-- ibn-khaldun-colonial-archive-043 -->

〔原刊 p. 12〕

De Slane’s translation turned the Arabic text into a racial text regulated by colonial and racial categories. Where Ibn Khaldûn saw contingent cycles of power, de Slane presented permanent racial antagonisms between Arabs and Berbers. Where Ibn Khaldûn emphasized environment, livelihood and solidarity, and fluidity, de Slane reduced difference to timeless racial essences. The result was a colonial narrative that not only explained the Arab conquest of North Africa but also made the French one appear as a natural correction of a historical mistake: the French returned to their Roman ancestral land. If Algeria had always been a land where Berbers resisted Arab domination, then France was simply the latest heir to Rome, liberating Berbers from the yoke of Semitic oppression, correcting history, and righting the wrong.

<!-- ibn-khaldun-colonial-archive-044 -->

〔原刊 p. 12〕

This logic was reinforced by colonial ethnography. French officials and scholars described Berbers as democratic, secular, and European in spirit. Census statistics portrayed Algeria as overwhelmingly Berber-European in origin, with Arabs a minority intrusion.[^ibn-khaldun-colonial-archive-52] The genealogical defense of Berbers that Ibn Khaldûn had articulated—tracing them to Canaan and integrating them into Islamic history—was dismissed as an error. In its place stood a myth of Berber whiteness and European kinship, a myth that conveniently aligned with French colonial policy.[^ibn-khaldun-colonial-archive-53]

<!-- ibn-khaldun-colonial-archive-045 -->

〔原刊 p. 12〕

Like any translation, the French text bears witness to the existence of an original voice—one that speaks in the language and logic of its time, deploying its own categories, assumptions, and conception of time, even its own narrative organization, which unfolds according to an order different from that of modern narrative.[^ibn-khaldun-colonial-archive-54] Ibn Khaldûn’s narrative in Arabic seems chaotic when in fact it was subject to a different medieval episteme, one in which language was believed not to translate the real but to tell it, as is. And since the real does not follow a linear logic, a narrative need not tell a story with a plot, a beginning, and an end. Hence, we have the textual phenomenon of repetition, often verbatim and without attribution, in the work of medieval historians. But Ibn Khaldûn’s seemingly chaotic organization was itself semiotically ordered first by the introduction of de Slane and later by subsequent colonial historians, most notably Ernest Mercier and Émile-Félix Gautier, at a time when the colony shifted toward being a historiographic state rather than an ethnographic one.[^ibn-khaldun-colonial-archive-55]

<!-- ibn-khaldun-colonial-archive-046 -->

〔原刊 p. 13〕

It is important to draw attention to the fact that the *Muqaddimah* was not only the birthplace of the opposition between Arabs and Berbers as exclusive races, rather than as tribal formations that change and transform through the dynamics of history, it was also a text on human diversity as it existed in Ibn Khaldûn’s time, and its translation transformed this understanding of human diversity as well.

<!-- ibn-khaldun-colonial-archive-047 -->

〔原刊 p. 13〕

To wit, for Ibn Khaldûn, human diversity is the result of climate—hot, temperate, and cold—depending on the region under discussion. The translated text, however, introduced nineteenth-century racial categories into this discussion. While Ibn Khaldûn speaks of the people of the Sudan as inhabitants of a hot climate, de Slane changed the category to “Negroes,” a nineteenth-century racial category associated with savagery and primitiveness. I shall return to this question shortly.

<!-- ibn-khaldun-colonial-archive-048 -->

〔原刊 p. 13〕

The question now is not simply how colonial Ibn Khaldûn gained an order of importance not given to other historians or thinkers in modern times, but why. My argument is that the importance created and bestowed upon an author through translation—thus transforming him into a colonial author—is itself a marker of coloniality that must be interrogated. Importance, therefore, should be understood as a site of discourse, distinct from yet related to the original discourse of Ibn Khaldûn, one that must be unpacked to reveal how colonial power constructs historiographic authority and imbues its representations with the quality of the real.

<!-- ibn-khaldun-colonial-archive-049 -->

〔原刊 p. 13〕

## Colonial Erasure and the Production of Relevance

<!-- ibn-khaldun-colonial-archive-050 -->

〔原刊 p. 13〕

Colonialism, as a cultural enterprise—relying not just on the use of force but also on harnessing knowledge to govern and rule—created for itself as a distinct knowledge, one different from the knowledge the bourgeois state developed in the metropole. Colonial knowledge was the direct encounter of the colonizer and the colonized, of power and its domain, its apparatus and its objects. Colonialism had its own epistemology, its own ways of knowing, grounded in a specific philosophy of knowledge, in which the colonial power operated with categories that were often inapplicable to the terrain of the metropole—race, inferiority, savagery, primitiveness—fueled by an epistemic arrogance that made colonial authorities believe that whatever lay beyond Europe was fully knowable through a European gaze. Colonial knowledge, through its texts, also had its own style, its own aesthetics, its own tone, and its own judgment. Colonialism also created its own conception of authorship, its own system of references, its own closed system of knowledge, its own logic and assumptions—in short, its own episteme connected to but different from the one that produced and organized knowledge in the metropole.[^ibn-khaldun-colonial-archive-56]

<!-- ibn-khaldun-colonial-archive-051 -->

〔原刊 p. 14〕

The translation of Ibn Khaldûn marked the birth of a major colonial author, one that overshadows all previous (and even future) historians from the region and of the region. The text of Ibn Khaldûn known as *L’histoire des Berbères* served as the foundation of colonial and, later, national and even postcolonial knowledge of North Africa. He has served as an author, in the Foucauldian sense, meaning someone who not only produced his own work but also “the possibility of other texts.”[^ibn-khaldun-colonial-archive-57] Yet, this colonial author is himself a transfiguration of the medieval Ibn Khaldûn. In modern times, he says more than what he meant in medieval times: in both French and English, he speaks a racial language in which Arabs and Berbers are constructed as two races in complete opposition to each other, and in which “Negroes” seem to occupy the lowest rung of the human racial hierarchy. In Arabic, by contrast, the text of Ibn Khaldûn is a chronicle in a historiographic tradition that takes the tribe, not the nation, as the focal point of its analysis. In this text, one reads narratives about different Arab and Berber tribes, all of them subject to the same pattern: either dominated by others or dominating them, either reaching the status of statehood through *ʿaṣabiyya* and *dîn* or remaining at the tribal level, perhaps waiting their turn to ascend to statehood if the conditions are favorable (that is, if the *ʿaṣabiyya* and the *dîn* are aligned to make such an ascension possible). In the Arabic text, people are assigned a geography that seems to affect everything about them, from color to culture. The French text turns these narratives into a narrative of a quest where Arabs and Berbers are constantly fighting over dominance, with the former always dominating and the latter always dominated. This is a Eurocentric narrative framework consisting of a racial antagonism that never ends. But it is this framework that dominates, to this day, the history of the Maghreb so much so that it has served as the basis for the construction of the Maghreb, an entity that is neither Africa nor the Middle East, but instead either Arab (in one nationalist discourse) or Berber (in another, antagonistic nationalist discourse, i.e., Berber/Amazigh).

<!-- ibn-khaldun-colonial-archive-052 -->

〔原刊 p. 14〕

Within all these discourses (colonial, national, even postcolonial), the name of Ibn Khaldûn functions as the highest historiographic authority. This functioning was made possible by colonial judgments on the man. For instance, R. A. Nicholson considers him “an extraordinary genius”[^ibn-khaldun-colonial-archive-58] whose “intellectual descendants are the great medieval and modern historians of Europe—Machiavelli and Vico and Gibbon.”[^ibn-khaldun-colonial-archive-59] French Orientalist Régis Blachère describes him as a “solitary” mind who “arose all of a sudden to explain the profound causes of history.”[^ibn-khaldun-colonial-archive-60] Blachère suggests that such a mind did not have an echo in a world that was not prepared to receive him. Jacques Berque rephrases the idea, calling Ibn Khaldûn “the genius who has long been ignored.”[^ibn-khaldun-colonial-archive-61] Robert Brunschvig phrases the stereotype differently: “As he had no predecessors in the Arabic language, he had no imitators or successors until the present era.”[^ibn-khaldun-colonial-archive-62] Brunschvig continues: “The paths were not ready yet in Islam to receive his methods and his free examination, and to apply scientific research to the evolution of humanity.”[^ibn-khaldun-colonial-archive-63] He then adds: “One of the most moving dramas, one of the most dramatic and significant pages in the history of Muslim culture, is that of the systematic incomprehension and resolute hostility that faced, in his own world, this genius and aberrant thinker.”[^ibn-khaldun-colonial-archive-64]

<!-- ibn-khaldun-colonial-archive-053 -->

〔原刊 p. 15〕

These judgments extend beyond the Maghreb to reappear in the Anglo-American tradition among historians, philosophers, and even economists. Arnold J. Toynbee speaks of Ibn Khaldûn as “an Arab genius”; he continues, “Ibn Khaldun’s star shines more brightly by contrast with the foil of darkness against which it flashes out,” and goes on to describe the *Muqaddimah* as “the greatest work of its kind that has ever yet been created by any mind in any time or place.”[^ibn-khaldun-colonial-archive-65] These formulations circulate widely. Charles Issawi, for instance, reproduces Toynbee’s statement as an epigraph, thereby reinscribing this evaluative framework within an Arab intellectual context. He cites Toynbee’s characterization of Ibn Khaldûn: “Ibn Khaldûn’s star shines the more brightly by contrast with the foil of darkness against which it flashes out.… He is indeed the one outstanding personality in the history of a civilization whose social life on the whole was solitary, poor, nasty, brutish, and short.”[^ibn-khaldun-colonial-archive-66]

<!-- ibn-khaldun-colonial-archive-054 -->

〔原刊 p. 15〕

Beyond these judgments, however, lies what is explicitly acknowledged—namely, Ibn Khaldûn’s excellence, if he indeed excelled—and what is also implicitly stated: the contrast between his achievement and the perceived mediocrity of his Arab-Muslim milieu and the medieval era in which he lived. He is the exception that confirms the rule, and the rule is that Muslim civilization is “solitary, poor, nasty, brutish, and short.” Ibn Khaldûn thus becomes a colonial signifier of a double cultural deficiency: he is outstanding in a poor civilization; he shines within its darkness. An unmistakable sign of this intrinsic darkness is the inability to recognize the light that was Ibn Khaldûn. One can see how Ibn Khaldûn has become a site of colonial judgments on Arab culture and a locus for making and reinforcing racial stereotypes. This is a cognitive *dispositif* that simultaneously asserts the superiority of the Orientalist instance of enunciation. He is certainly acknowledged, but this very acknowledgment often functions to detach him from his culture and his epoch. Such detachment opens the possibility of reattaching him to Europe—not only because Europe “discovered” him, but because Orientalist discourse can claim that he somehow belongs to it. After all, he was Andalusian and the al-Andalus is Europe. Gautier himself carries this logic to its most explicit conclusion, in al-Andalus, he wrote, “a breath of the Renaissance of the West reaches the oriental soul of Ibn Khaldun.”[^ibn-khaldun-colonial-archive-67]

<!-- ibn-khaldun-colonial-archive-055 -->

〔原刊 p. 15〕

Yet the complexity of the making of this historiographic figure does not allow for only one judgment to prevail; often there were also opposing views that celebrated him as outstanding while simultaneously excluding him from the sphere of Europe. In other words, the system of exclusion that constitutes the “Western tradition” as a white, upper-class, androcentric framework demands that even Ibn Khaldûn could not fully belong to it. He is outstanding “there,” but not “here.” The “here” is the terrain of Europe, and the colonial system of erasure encompasses Ibn Khaldûn himself, regardless of what Gautier, Toynbee, Blachère, Berque, Brunschvig, or Issawi might say about him. After all, Orientalist judgments are not binding outside their field, and that field remains at the margins of contemporary Western thought and the academy. Once highly influential, particularly during the nineteenth century, Oriental studies’ prominence has declined since the 1960s.[^ibn-khaldun-colonial-archive-68]

<!-- ibn-khaldun-colonial-archive-056 -->

〔原刊 p. 16〕

Outside Orientalist studies and the broader history of European thought, Ibn Khaldûn is largely absent from arenas reserved for figures such as Machiavelli, Hobbes, Durkheim, and even dissident thinkers like Karl Marx, Antonio Gramsci, and Pierre Bourdieu. In colonial discourse, he is confined to a regional niche, excluded from mainstream narratives of Western intellectual history. Although Durkheim was familiar with Ibn Khaldûn’s work, the similarities between their ideas are often minimized or deemed coincidental. Similarly, Ibn Khaldûn’s insights concerning how social status affects wealth, which anticipate Bourdieu’s concept of the “economy of symbolic goods,” have never received attention, despite Bourdieu’s reliance on colonial scholarship on Algeria, where Ibn Khaldûn was ubiquitous.

<!-- ibn-khaldun-colonial-archive-057 -->

〔原刊 p. 16〕

## Race and Blackness in Ibn Khaldûn’s Colonial Archive

<!-- ibn-khaldun-colonial-archive-058 -->

〔原刊 p. 16〕

As we have seen, the translation of the *Muqaddimah* transformed it into a racialized text governed by nineteenth-century categories that reclassified tribal formations as racial ones—for example, Berber tribes were recast as the “Berber race,” Arab tribes as the “Arab race,” and the peoples of the Sudan as “Negroes.” As a result, Ibn Khaldûn’s work, as it exists within the colonial archive, is permeated by racial semantics that are largely constitutive of that archive itself.

<!-- ibn-khaldun-colonial-archive-059 -->

〔原刊 p. 16〕

In the context of integrating the *Muqaddimah* into the curriculum of an African research institute (the Makerere Institute of Social Research in Kampala), Mahmood Mamdani asks: “Was Ibn Khaldûn a racist?”[^ibn-khaldun-colonial-archive-69] This question goes beyond Ibn Khaldûn himself. Underlying it is the issue of race: whether Islam historically recognized race and racism—whether the anti-Black prejudice observed in contemporary Arab societies is a European import brought with modernity, or whether Islam developed forms of racial hierarchy and anti-Black attitudes prior to Europe. In this debate, Ibn Khaldûn serves as a major reference, especially since he is considered “very much a representative of Arab culture,” particularly in domains pertaining to “his consideration of time, human psychology, and the nature of relationships.”[^ibn-khaldun-colonial-archive-70] His centrality as an Arab thinker explains why his work has become a key reference in racial studies, and more specifically Black studies, especially as they relate not only to the Maghreb, but also to Islam at large—and today more so, as the region has been experiencing significant Black migration en route to Europe.[^ibn-khaldun-colonial-archive-71] The racial language found in the *Muqaddimah* has become part of Ibn Khaldûn, the colonial archive.

<!-- ibn-khaldun-colonial-archive-060 -->

〔原刊 p. 17〕

Even before Franz Rosenthal’s English translation appeared in 1958, Cedric Dover had already concluded—in 1952, after claiming to have demonstrated Ibn Khaldûn’s racism—that “I know of no book more important to the history of racial ideas.”* [^ibn-khaldun-colonial-archive-72] * Bernard Lewis, looking at Charles Issawi’s translation—“Negroes [Sudan] are the only people who accept slavery”—notes that Rosenthal omits the word “only” in his translation. In other words, with “only” added, the statement becomes viscerally and unquestionably racist, thereby reinforcing Lewis’s broader claim that Arab culture is fundamentally anti-Black.[^ibn-khaldun-colonial-archive-73] It is worth noting here, however, that in the Arabic text, Ibn Khaldûn does not use the word “only,” which connotes exclusivity; had he done so, Ibn Khaldûn would appear undoubtedly racist against all Black people. Instead, he uses the opposite term, *fi al-ghalib* (in general), which signifies relativity. He writes: *innama tudhʿinu li al-riqq fi al*-*ghalib umamu al-sudan* (“Those who submit to slavery are generally the populations of Sudan”). The phrase includes no Arabic equivalent of “only” (e.g., *faqaṭ, faḥasb*, *waḥdahum, lâ ghayr*, etc.).[^ibn-khaldun-colonial-archive-74] Ibn Khaldûn was not making a judgment about the worth of this population; rather, he noted a historical pattern, a phenomenon known in his time that was the result of war and the slave trade. Ibn Khaldûn also notes other populations accepting slavery without being Black, albeit for different reasons—the Turks in the East, the infidel Galicians, and the Franks of al-Andalus who accepted slavery for titles and power. However, Ibn Khaldûn connects this idea about the people of Sudan with his earlier opinions that these populations submit to or accept slavery because they are “lacking in humanity” (*nuqs fi al*-*insâniya*) and that their traits (*aʿrâḍ*) are closer (*aqrab*) to those of “mute animals.” While these descriptions reflect his fourteenth-century worldview and his framework for understanding social differences—particularly the conditions that favor (or impede) the creation of *ʿumrân*—they must also be understood in the context of war, slavery, and the trans-Saharan slave trade, which shaped patterns of domination in his time.

<!-- ibn-khaldun-colonial-archive-061 -->

〔原刊 p. 17〕

The point here is not to defend Ibn Khaldûn or to accuse him, but to emphasize that his views reflect a worldview with a different epistemic register of difference. His views in the Arabic text lack systematicity. Populations of varying skin tones—*bayâḍ* (whiteness), *sawâd* (blackness), and intermediate shades indicated by the verb *yamîlu* (“tending toward *bayâḍ,*” e.g., north of Sudan)—are described similarly, with differences attributed to climate rather than biology.

<!-- ibn-khaldun-colonial-archive-062 -->

〔原刊 p. 17〕

In any case, in the article cited above, Mamdani, despite holding a sympathetic view of Ibn Khaldûn as a thinker, still argues that Ibn Khaldûn’s text expresses racial biases—namely, that Blacks do not possess civilization and are marked by savagery.[^ibn-khaldun-colonial-archive-75] Mamdani looks to the same passages often quoted by those who claim that Ibn Khaldûn expresses anti-Black views or, which amounts to the same thing, was racist or held racist biases. He cites from the translation of Rosenthal and comments:

<!-- ibn-khaldun-colonial-archive-063 -->

〔原刊 p. 18〕

Ibn Khaldûn writes that Negroes (sic) are “in general characterized by levity, excitability and great emotionalism”—as are coastal peoples like Egyptians in contrast to the inhabitants of Fez in the Maghreb. Two pages later, he adds nomadic Arabs to this list of the uncivilized (sic): “Another such people are the Arabs, who roam the waste regions.” The statement most offensive to a modern sensibility concerns Negroes, and not Slavs, nor Bedouins: “the Negro nations are, as a rule, submissive to slavery, because (Negroes) have little that is (essentially) human and possess attributes that are quite similar to those of dumb animals, as we have stated.”[^ibn-khaldun-colonial-archive-76]

<!-- ibn-khaldun-colonial-archive-064 -->

〔原刊 p. 18〕

It should be obvious that Ibn Khaldûn did not utter these words; and, of course, he could not express himself in English or in French, and therefore did not use the categories of race, Negroes, civilization, or savagery. These are colonial constructs, their meanings embedded within a broader system of the nineteenth-century racial ideology that shaped de Slane’s foundational French translation and later Rosenthal’s English one. This is precisely the colonial archive under discussion. In Arabic, Ibn Khaldûn uses the central concept of *ʿumrân* (often translated either as “civilization” or as “culture”;[^ibn-khaldun-colonial-archive-77] it is somewhat closer to the latter but not to the former, though it connotes more a social formation or organization).[^ibn-khaldun-colonial-archive-78] He also uses the concept of *haḍâra* (always translated as “civilization”), which does not carry the colonial connotation that makes civilization the exclusive product of the white race.[^ibn-khaldun-colonial-archive-79] In fact, Ibn Khaldûn uses the concept of *haḍâra* almost with a negative connotation; *haḍâra* happens only when the state is in decline, when *ʿumrân* is in excess. *Hadâra* for him is “*tafanun fi al* [refinement of the] *ʿumrân.*” But *haḍâra* is closely tied to decline and, as such, it announces the end of the state—hence, al-Jabri’s interpretation that “*haḍâra* corrupts the *ʿumrân.*”[^ibn-khaldun-colonial-archive-80]

<!-- ibn-khaldun-colonial-archive-065 -->

〔原刊 p. 18〕

ʿUmrân is an urban condition produced by a tribe through its *ʿaṣabiyya.* The state of nature, or more accurately bedouinism (*badâwa*), is the condition from which the urban condition emerges. What makes a tribe a tribe is not only its lineage, social organization, or hierarchy, but also a fundamental trait shared by any human group in the state of *badâwa*: *al-tawaḥḥush*, often translated as “savagery,” which evokes European notions of the “savage” used widely by anthropologists and European travelers during the colonial age. For Ibn Khaldûn, *tawaḥḥush* is a type of roughness, rawness, and resilience inherent in the state of *badâwa. Tawaḥḥush* is what enables a tribe to become dominant; it is the quality that enables it to achieve dynastic power. After all, in Ibn Khaldûn’s framework, the state is a tribe in power. Historians have often examined how, in Ibn Khaldûn’s view, *ʿaṣabiyya*, together with religion, enables the tribe to achieve dynastical power, but they have rarely paid attention to the quality of *tawaḥḥush* inherent to the state of *badâwa*, which enables the tribe to achieve power and even expand it. In a chapter entitled “The *Umma* Endowed with *Tawaḥḥush* Achieves an Expansive Dynastical Power,” Ibn Khaldûn writes that “They treat the local population as a predator treats brute [or mute] animals.”

<!-- ibn-khaldun-colonial-archive-066 -->

〔原刊 p. 19〕

The problem, however, is that the translation of *tawaḥḥush* as “savagery” assimilates Ibn Khaldûn’s concept to a distinctly colonial vocabulary. The colonial concept of savagery holds that savages are incapable of progress, irrational, and therefore trapped in a primitive stage of development.[^ibn-khaldun-colonial-archive-81]

<!-- ibn-khaldun-colonial-archive-067 -->

〔原刊 p. 19〕

To note that some people lack *ʿumrân* is to observe that they lack a state, not that they are intellectually incapable of producing one. The state creates the *ʿumrân. Tawaḥḥush* is a condition for the *ʿumrân;* its absence at a later stage of the state is indicative of decline. By contrast, *haḍâra* (as a civilization) is negative in Ibn Khaldûn’s view, not only because it announces the end of *ʿumrân* but also because it generates “excesses” of desires such as adultery (*zinâ*) and homosexuality (*liwâṭ*)—“the worst for the human species,” he writes, because it does not lead to procreation.[^ibn-khaldun-colonial-archive-82] Ibn Khaldûn condemns these not because they are religiously illicit, but because they are associated with the decline of *ʿumrân* and have no productive utility. Yet *ʿumrân* (culture) or its complement, *haḍâra* (civilization), are not the monopoly of any one people or a nation. They emerge in moderate climates, regardless of who inhabits them, including Blacks (as with Ghana); but they cannot emerge in extreme climates, regardless of who inhabits them, including Slavs (who are white).

<!-- ibn-khaldun-colonial-archive-068 -->

〔原刊 p. 19〕

In racial theories of the eighteenth and nineteenth centuries, Blacks (referred to as Negroes) were considered a “low race,” including in the view of the Enlightenment. Regardless of climate or geography, in racial thinking Blacks are Blacks. Kant asserts: “The Negroes of Africa have by nature no feeling that rises above the trifling. Mr. Hume challenges anyone to cite a single example in which a Negro has shown talents, and asserts that among the hundreds of thousands of blacks who are transported elsewhere from their countries, although many of them have even been set free, still not a single one was ever found who presented anything great in art and science or any other praise-worthy quality even though among the whites some continually rise aloft from the lowest rabble, and through superior gifts earn respect in the world. So fundamental is the difference between the two races of man, and it appears to be as great in regard to mental capacities as in colour.”[^ibn-khaldun-colonial-archive-83]

<!-- ibn-khaldun-colonial-archive-069 -->

〔原刊 p. 19〕

For nineteenth-century racial theorists—most notably the highly influential Arthur de Gobineau—human populations were hierarchically classified. Gobineau explicitly placed what he termed “the Negro race” at the bottom of this hierarchy, writing that “the negroid variety is the lowest and stands at the foot of the ladder.”[^ibn-khaldun-colonial-archive-84] By contrast, he identified “the white race”—by which he meant a particular Europe—as inherently superior in intelligence, beauty, and moral capacity, regardless of geography or historical circumstance.

<!-- ibn-khaldun-colonial-archive-070 -->

〔原刊 p. 20〕

Ibn Khaldûn does not use the concept of “Blacks” (or its Arabic equivalent, *al-sud*) as a universal or essentialist category. Rather, he describes populations in specific districts, noting differences from one region to another—for example, in Sudan, the northern areas lean toward *bayâḍ* (light skin), whereas the southern regions are marked by *sawâd* (darkness). His focus is on the people of particular regions, not on racial types. By contrast, the term “Negro” is a colonial construct, historically associated with assumptions of savagery, excitability, and lower intellect.

<!-- ibn-khaldun-colonial-archive-071 -->

〔原刊 p. 20〕

Taken together, these examples show that for Ibn Khaldûn, the people of Sudan (not all “Blacks,” and not even all inhabitants of Sudan) as well as the Slavs (who have lighter skin) are affected by extreme climates—hot or cold—which influence their temperament and even their skin color (*sawâd* or *bayâḍ*). These environmental effects produce conditions unfavorable to the development of *ʿumrân*, illustrating that Ibn Khaldûn understood these characteristics as context-dependent rather than innate racial traits.

<!-- ibn-khaldun-colonial-archive-072 -->

〔原刊 p. 20〕

Colonial Ibn Khaldûn, however, lacks these important nuances, and the text appears indeed racial and racist: “Their qualities of character, moreover, are close to those of dumb animals. It has even been reported that most of the Negroes of the first zone dwell in caves and thickets, eat herbs, live in savage isolation, do not congregate, and eat each other. *The same applies to the Slavs.*”[^ibn-khaldun-colonial-archive-85] (Italics mine.)

<!-- ibn-khaldun-colonial-archive-073 -->

〔原刊 p. 20〕

In this translation, the key phrase “the same applies to the Slavs” is omitted almost exclusively by those who claim that Ibn Khaldûn held racist views. The reason should be obvious. The statement cuts against racial thinking, since race—once posited as race—is supposed to remain fixed, not something that could be shared among different peoples with entirely different conditions, cultures, or civilizational statuses. Slavs are, of course, white, though “white” itself is a modern category.

<!-- ibn-khaldun-colonial-archive-074 -->

〔原刊 p. 20〕

If a negative stereotype targets a group of people who are white (not all white people) and another group who are Black (not all Black people), the stereotype—still offensive to both groups—operates according to a paradigm outside the racial episteme. Race is a form of biological classification, and racial thinking is systematic in that its key concept is race itself. A mode of thought that explains human difference primarily through geography and climate is doing something else entirely. It is climatic thinking, not racial thinking.

<!-- ibn-khaldun-colonial-archive-075 -->

〔原刊 p. 20〕

Climatic thinking can indeed produce hierarchical zones of geography, but not of biology. There is a fundamental difference between the climatic thinking of medieval Islam and the racial thinking of colonial modernity: the former produces an anthropology of environment, the latter a doctrine of racial superiority. In the Arabic text of Ibn Khaldûn, there is no claim of racial superiority, since dominance is contingent and never fixed.

<!-- ibn-khaldun-colonial-archive-076 -->

〔原刊 p. 20〕

What is significant, however, is that the conditions Ibn Khaldûn attributes to the inhabitants of extreme climates—such as cave-dwelling, dressing in leaves, and even cannibalism—are also reported by modern ethnographers across different cultures.[^ibn-khaldun-colonial-archive-86] For Ibn Khaldûn, these conditions are indicative of the limits imposed on human societies by climate, not of biological determinism. Biological hierarchies constitute fixed essences; climatic hierarchies are contingent and reversible. It is one thing to claim that a group is biologically inferior, and quite another to argue that particular environmental conditions constrain a group’s potential and limit its ability to produce *ʿumrân*, understood as the development of crafts, sciences, and rank. Moreover, *ʿumrân* itself does not appear to be Ibn Khaldûn’s preferred condition. He is often more appreciative of the state of *badâwa*, admiring its rawness and resilience (*tawaḥḥush*), as well as its ethos.[^ibn-khaldun-colonial-archive-87]

<!-- ibn-khaldun-colonial-archive-077 -->

〔原刊 p. 21〕

Another dimension of these concepts emerges when Ibn Khaldûn contrasts *insâniya* (sociability, translated as “humanity”) with *tawaḥḥush* (isolation, translated as “savagery”). He defines *ʿumrân* as “co-residence and settlement in a town or habitation, enabling sociability with companions and the satisfaction of needs.”[^ibn-khaldun-colonial-archive-88]

<!-- ibn-khaldun-colonial-archive-078 -->

〔原刊 p. 21〕

*Insâniya* comes from *ʿuns* (sociability), which is the opposite of isolation; it is therefore a beneficial quality, fostering solidarity and cooperation—both essential for the development of *ʿumrân.* [^ibn-khaldun-colonial-archive-89] By contrast, *tawaḥḥush* seems to be the opposite of *insâniya.* If *ʿuns* (and *insâniya*) is sociability, *tawaḥḥush* is dispersion, isolation, and the lack of, or minimal, sociability. More specifically, to have the quality of *tawaḥḥush* is to be “closer” (*qarība*)— not “similar,” as the French and English translations have it—to what Ibn Khaldûn calls *al-ḥayawânât al-ʿujm.* [^ibn-khaldun-colonial-archive-90] This expression is usually translated as “dumb animals,” whereas a closer rendering would be beings lacking articulate speech in an Aristotelian sense, not a racial category. The expression in Arabic also sounds like a pleonasm. “Closer” indicates a relational frame, a matter of degree within forms of sociality, language use, and crafts. It is not a permanent or essentialist trait. To say “similar,” as in Rosenthal’s translation, is to emphasize resemblance in traits or behavior; it is more static and lends itself to a biologically deterministic reading. Taken together, these distinctions show that Ibn Khaldûn grounds human difference in modes of settlement rather than in biological or racial distinction.

<!-- ibn-khaldun-colonial-archive-079 -->

〔原刊 p. 21〕

Nevertheless, Ibn Khaldûn does not hold that any single group—not even his own, the Arabs—is superior to others. In his text, Arabs are also described in ways similar to others, including the description of *tawaḥḥush* and lack of *ʿumrân* among some of them. He finds the Egyptians similar to Blacks living in hot climates; they too are more prone to joy and excitability. Between Arab tribes, he describes inequality of status due to *ʿaṣabiyya, ḥasab*, and *nasab.* Ibn Khaldûn also uses two other important categories: power (*shawkat*) and dominance (*ghalaba*). This he does especially in his attempt to understand how a tribe becomes a dynasty. Nothing is permanent, for him; everything changes. Some people accumulate power through *`asabiya*, *ḥasab,* and *nasab*; they achieve dominance, they exert it increasingly and then gradually lose it. Some of them never achieve any dominance; they endure the dominance of others, not because of some deficient, biological qualities, but because they were not favored by the climate and the environment, and they have not met the rather accidental conditions of *ʿaṣabiyya*: religion, or rather religious mission (*daʿwa dîniya*), size or number of members of the tribe (*ʿadad*), and nobility (*ḥasab).*

<!-- ibn-khaldun-colonial-archive-080 -->

〔原刊 p. 22〕

One may well argue that Ibn Khaldûn creates a hierarchy of geography, and thus ipso facto classifies what seems like a hierarchy of race. The problem with this argument is that a variety of peoples, not just Blacks, are favored by the climate, even as, at the same time, a variety of people, including Blacks, are disfavored by it. The problem with racial thinking, by contrast, is that one group is considered superior to all others, regardless of climate or geography (i.e., whites in eighteenth- and nineteenth-century racial theories);[^ibn-khaldun-colonial-archive-91] other groups are considered racially inferior, with Blacks seen as the most inferior of all, regardless of climate or environment. The differences are biological and irreversible. In racial thinking, the world is racially hierarchical, and its hierarchy is both natural and permanent. Moreover, “this prejudice,” as Lewis Gordon put it in his discussion of W. E. B. Du Bois, “centred the categories of universal man in terms of particularities that excluded racialized people and related ethnic typographies, with the result that a particular kind of man became the presumption of man.”[^ibn-khaldun-colonial-archive-92]

<!-- ibn-khaldun-colonial-archive-081 -->

〔原刊 p. 22〕

This is clearly not the perspective of Ibn Khaldûn. He does not make any one people the standard of humanity. His medieval worldview was more religiously centered than ethnocentric. Yet, although Ibn Khaldûn lived in a Muslim society and apparently espoused its ideology as both a believer and a subject, his work constitutes a rationalist investigation, clearly independent of and distinct from the theological framework of its time.[^ibn-khaldun-colonial-archive-93] The *Muqaddimah* explores how dynastic power is acquired, lost, and transferred between peoples, demonstrating that *umrân* emerges from within any group, given the suitable climatic and social conditions, and is never the monopoly of any single group. It constantly changes hands. While Ibn Khaldûn acknowledges the superiority of Islam as a faith, he argues that *umrân* (understood as the creation of sciences, crafts, and the rank associated with dynastic administration) is the product of human capacity and reasoning. His historical record includes chronicles of peoples who have achieved it and lost it, among them the Greeks, the Romans, the Persians, the Israelites, the Arabs, and the Blacks of Abyssinia. This capacity, however, requires the necessary environmental and climatic conditions to fully manifest.

<!-- ibn-khaldun-colonial-archive-082 -->

〔原刊 p. 22〕

It is in translation that Ibn Khaldûn’s thought is often reconfigured. Colonial translators and interpreters imposed racial categories foreign to both him and his time, producing a text that appears highly racialized, prejudicial, and offensive to modern sensibilities. In the Arabic original, these categories are instead climatic and environmental, describing the limits and possibilities for human societies without invoking fixed hierarchies of race. Reading Ibn Khaldûn within his historical and linguistic context reveals a thinker who analyzed human diversity in terms of social, environmental, and political conditions rather than biological determinism.

<!-- ibn-khaldun-colonial-archive-083 -->

〔原刊 p. 23〕

In these translations, Ibn Khaldûn’s language, categories, and even his judgments are reformulated into the language and categories of the eighteenth and nineteenth centuries. Unpacking the translations and confronting them, using a philological method, alongside the Arabic text reveals that the original work bears no resemblance to the racial texts or racial thinking of the translations.

<!-- ibn-khaldun-colonial-archive-084 -->

〔原刊 p. 23〕

His categories are climatic and environmental. This does not mean that they are unproblematic, neutral, or free of bias. It means, rather, that they belong to a different epistemic register, one that carries its own hierarchies but not the hierarchy of race. Nor are they embedded in forms of power organized around race in the modern sense or structured for purposes of conquest and rule. By contrast, the categories introduced through translation are fully consistent with a racial framework, one that emerged in the eighteenth and nineteenth centuries and that served to organize difference within projects of imperial domination. Reading him within his context, against the colonial archive, reveals a thinker who explained human diversity (as it pertains to *ʿumrân* as a social formation) in terms of environment, social organization, and historical circumstance, rather than fixed racial hierarchies. Comparing the translations with the original text thus recovers Ibn Khaldûn’s medieval epistemic framework and restores the analytical categories that colonial translators replaced with their own.

<!-- ibn-khaldun-colonial-archive-085 -->

〔原刊 p. 23〕

## Conclusion

<!-- ibn-khaldun-colonial-archive-086 -->

〔原刊 p. 23〕

Ibn Khaldûn as a problem, at its core, is a problem of how non-Western knowledge and its figures are appropriated through acts of translation that remake them into Western knowledge regulated by a Western episteme. This becomes a challenge in the sociology of knowledge, since research in this area often confronts a corpus whose author is ostensibly non-Western while its discourse has been remade within Western frameworks. Hence my argument in this article: that there is Ibn Khaldûn, the medieval author, and there is Ibn Khaldûn, the colonial author—the latter emerging within the colonial context as a product of the French translation that subsequently influenced the English one.

<!-- ibn-khaldun-colonial-archive-087 -->

〔原刊 p. 23〕

Ibn Khaldûn has largely circulated as a colonial author whose French and English texts are fraught with colonial categories, producing a discursivity on the Maghreb, Muslim historiography, and Muslim self-representation. In translation, Ibn Khaldûn appears as racist, especially in statements about what the translations call Negroes or *Nègres.* To read or hear his name is to think simultaneously of intellectual brilliance and of perceptions of cultural backwardness—the former often highlighting the latter. His name has come to overshadow much of the historiographic tradition of his time and afterward, shaping how later scholars engage with medieval Arab historiography. Some of this tradition developed directly from his work, while much of the rest emerged independently. Yet Ibn Khaldûn’s name “shines” against the context in which he emerged, perceived by later Orientalists as a light in what was thought to be darkness, much as a flame appears brightest at night.

<!-- ibn-khaldun-colonial-archive-088 -->

〔原刊 p. 24〕

Ibn Khaldûn in translation cannot be dismissed as merely “erroneous” or “distorted.” The colonial author exists in his own right. By himself, he constitutes a real colonial archive: a repository of racial judgments, ideological assumptions, and conceptual distortions. He has thrived and will continue to do so unless the act of translation itself is critically examined—unless we ask how these translations were shaped by racial ideology, power, and epistemic assumptions. Translation ideology is central to any translation, but especially in colonial contexts, where language, power, and race intersect.[^ibn-khaldun-colonial-archive-94] Even today, AI translation, often informed by existing Orientalist categories, risks reproducing these frameworks as seemingly objective knowledge.

<!-- ibn-khaldun-colonial-archive-089 -->

〔原刊 p. 24〕

Rather than disregarding the colonial Ibn Khaldûn, we ought to decolonize him—not only his work in translation but also the ensemble of ideas, judgments, and assumptions about him that extend beyond his original texts. Such an approach allows us to consider the history of how colonial powers turned the local into the colonial, produced knowledge about the Other, and instrumentalized this knowledge to create identities and histories, opening colonial horizons even in a postcolonial world. Formerly colonized peoples, despite later claims of independence, were caught in webs of colonial significance they did not themselves weave.

<!-- ibn-khaldun-colonial-archive-090 -->

〔原刊 p. 24〕

Because translation is an epistemic field—not only a locus of colonial otherness—decolonizing Ibn Khaldûn also means decolonizing European knowledge itself. It is an intellectual endeavor to rewrite the history of knowledge production in the colonies and, in doing so, to rethink European history and sociology within the larger context of colonial rule and difference. This perspective highlights that, during the formative years of social science, knowledge production was already at work through epistemic encounters. European sociology and history emerged not only from the metropole but also from the colonies themselves, at the linguistic and epistemic intersection with the then-colonial center.

<!-- ibn-khaldun-colonial-archive-091 -->

〔原刊 p. 24〕

Considering the intense focus on Ibn Khaldûn—the man, the statesman, and the author—decolonizing him also provides an example of how non-Western thinkers are co-opted and celebrated paradoxically: individual brilliance is recognized while the contributions of their cultural milieu are minimized, marginalized, or erased. This erasure is evident in his absence from the history of European and American sociology, despite the influence of his concepts on Durkheim and Bourdieu. Such absences contribute to the enduring perception of sociology as a predominantly European discipline, untouched by social thought from other traditions. Even when historians investigate the colonial origins of the social sciences, the intellectual traditions encountered, used, or appropriated by Europeans are often silenced. Decolonizing Ibn Khaldûn, therefore, means recovering an intellectual heritage that shaped European thought and opening the way to a plural history of sociology—not to diminish Durkheim, Bourdieu, or any other sociologist or anthropologist whose ideas resonate with Ibn Khaldûn, but to show how colonialism created a global field in which ideas circulated, unevenly structured by colonial power.

<!-- ibn-khaldun-colonial-archive-092 -->

〔原刊 p. 25〕

## Acknowledgments

<!-- ibn-khaldun-colonial-archive-093 -->

〔原刊 p. 25〕

An earlier version of this article was presented at the Faculty Seminar Series at the Africa Institute, Global Studies University, in Sharjah, UAE, where I benefited from a stimulating intellectual environment and generous hospitality. I am particularly grateful to Salah Hassan and Surafel Wondimu Abebe for their thoughtful comments and suggestions. I also thank the editor of *Comparative Studies in Society and History* and the two anonymous reviewers for their exceptionally careful, critical, and constructive engagement with the manuscript. Finally, I am especially grateful to Fayre Makeig for her careful reading and encouragement throughout the development of this article.

## 原注 / Original notes

[^ibn-khaldun-colonial-archive-1]: William de Slane, *Les Prolégomènes d’Ibn Khaldoun* (Paris: Imprimerie impériale, 1863); Franz Rosenthal, *The Muqaddimah: An Introduction to History* (Princeton: Princeton University Press, 1958).

[^ibn-khaldun-colonial-archive-2]: See Houari Touati, ed., *Ibn Khaldûn et les sciences humaines* (Paris: CERF, 2024).

[^ibn-khaldun-colonial-archive-3]: Among many others, see Ernest Gellner, “From Ibn Khaldun to Marx,” *The Political Quarterly* 32, 4 (1961): 385–92; Ernest Gellner, “Cohesion and Identity: The Maghreb from Ibn Khaldun to Emile Durkheim,” *Government and Opposition* 10, 2 (1975): 203–18. See also, more recently, Houari Touati, “Ibn Khaldûn et la médiation Durkheimienne,” in Touati*, Ibn Khaldûn et les sciences humaines*, 223–62.

[^ibn-khaldun-colonial-archive-4]: In an impressive book on the colonial origins of social science, Ibn Khaldûn is absent (save for one indirect reference) even in the context of the colonization of the Maghreb: George Steinmetz, *The Colonial Origins of Modern Social Thought* (Princeton: Princeton University Press, 2023).

[^ibn-khaldun-colonial-archive-5]: Ibn Khaldûn, *Kitāb al-ʿIbar wa-dîwān al-mubtadaʾ wa-l-khabar fī ayyām al-ʿarab wa-l-ʿajam wa-l-barbar, 8 vols.* (Beirut: Dar al-kutub al-*ʿ*ilmiya, 2020).

[^ibn-khaldun-colonial-archive-6]: See Abdelmajid Hannoum, *The Invention of the Maghreb: Between Africa and the Middle East* (Cambridge: Cambridge University Press, 2021).

[^ibn-khaldun-colonial-archive-7]: Reynold Alleyne Nicholson, *A Literary History of the Arabs* (London: T. Fisher Unwin, 1907); Taha Hussein, *La philosophie sociale d’Ibn Khaldoun* (Paris: Pedone, 1918).

[^ibn-khaldun-colonial-archive-8]: See Abdelmajid Hannoum, “Translation and the Colonial Imaginary: Ibn Khaldûn, Orientalist,” *History and Theory* 42, 1 (2003): 61–81; Hannoum, *The Invention of the Maghreb*, 170–205.

[^ibn-khaldun-colonial-archive-9]: Muhsin Mahdi, *Ibn Khaldûn’s Philosophy of History* (Chicago: University of Chicago Press, 1957).

[^ibn-khaldun-colonial-archive-10]: Abdessalem Cheddadi, *Ibn Khaldûn: L’homme et le théoricien de la civilisation* (Paris: Gallimard, 2006).

[^ibn-khaldun-colonial-archive-11]: Rosenthal, “Ibn Khaldûn’s Life,” in *The Muqaddimah.*

[^ibn-khaldun-colonial-archive-12]: Mahdi, *Ibn Khaldûn’s Philosophy of History.*

[^ibn-khaldun-colonial-archive-13]: For more details on his life and time, see, among others, Allen James Fromherz, *Ibn Khaldun, Life and Times* (Edinburgh: University of Edinburgh Press, 2010).

[^ibn-khaldun-colonial-archive-14]: See Abdelmajid Hannoum, “The Muqaddima of Ibn Khaldûn,” in *Bloomsbury History: Theory and Method* (online publication, 2022). At: https://www.bloomsburyhistorytheorymethod.com/article?docid=b-9781350915831&tocid=b-9781350915831-160.

[^ibn-khaldun-colonial-archive-15]: See, for more details, Hannoum, “The *Muqaddima* of Ibn Khaldûn.”

[^ibn-khaldun-colonial-archive-16]: See Ahmed Abdesselem, *Ibn Khaldûn et ses lecteurs (Paris: Presses universitaires de France, 1983).*

[^ibn-khaldun-colonial-archive-17]: Cornell Fleischer, “Royal Authority, Dynastic Cyclism, and ‘Ibn Khaldûnism’ in Sixteenth-Century Ottoman Letters,” in Bruce B. Lawrence, ed., *Ibn Khaldûn and Islamic Ideology* (Leiden: Brill, 1984), 47.

[^ibn-khaldun-colonial-archive-18]: Ibid., 46–48.

[^ibn-khaldun-colonial-archive-19]: Lucette Valensi, “La découverte d’un grand auteur en Europe: Le cas d’ Ibn Khaldun,” in Houari Touati, ed., *Figures d’Ibn Khaldûn: Réception, appropriation et usages* (Algiers: CNRPAH, 2010), 114.

[^ibn-khaldun-colonial-archive-20]: Natalie Zemon Davis, “Leo Africanus Presents Africa to Europeans,” in Joaneath Spicer, ed., *Revealing the African Presence in Renaissance Europe* (Baltimore: Walters Art Museum, 2012), 65.

[^ibn-khaldun-colonial-archive-21]: Valensi, “La découverte d’un grand auteur en Europe,” 115.

[^ibn-khaldun-colonial-archive-22]: For an early example of this work, see Sati al-Husri, *Dirâsat ʿan muqaddimat Ibn Khaldûn* (Beirut: Dar al-*ʿ*Ilm li al-Malayin, 1951).

[^ibn-khaldun-colonial-archive-23]: See Seyed Javad Miri Meynagh, “Ali Shariati’s Reading of Ibn Khaldun,” *Insan & Toplum, The Journal of Humanity and Society* 10, 3 (2020): 132–44. Also, Syed Farid Alatas, “Ibn Khaldun in Iran: The Case of Ali Shariati,” in Esmaeil Zeiny and Dustin Byrd, eds., *Beyond Eurocentric Social Theory: The Nomadic Intellectual on Religion, Culture and the State* (Leiden: Brill, 2026), 37–48.

[^ibn-khaldun-colonial-archive-24]: See Abdallah Laroui, *Islam et modernité* (Paris: La Découverte, 1987); Abdelkebir Khatibi, *Le Maghreb Pluriel* (Paris: Denoël, 1983); Mohammed Abid al-Jabri, *Fî Fikr Ibn Khaldûn: Ibn Khaldûn was al- ʿaṣabiyya.*

[^ibn-khaldun-colonial-archive-25]: See Mohamed Arkoun’s review of Aziz Azmeh’s two books on Ibn Khaldûn, published in *Arabica* 1985 (32): 245. See also the two books themselves: Aziz Azmeh, *Ibn Khaldûn in Modern Scholarship: A Study in Orientalism* (London: Third World Center, 1981); and *Ibn Khaldûn: An Essay in Reinterpretation* (London: Frank Cass, 1982).

[^ibn-khaldun-colonial-archive-26]: Hussein Ibish, “Nationalism, Secularism, and Postcoloniality: An Interview with Edward Said,” *Cultural Dynamics* 14, 1 (2002): 97–105.

[^ibn-khaldun-colonial-archive-27]: Edward Said, “Between Two Worlds,” *London Review of Books* 20, 9 (1998): 6–7.

[^ibn-khaldun-colonial-archive-28]: See Hannoum, “Translation and the Colonial Imaginary,” op. cit.

[^ibn-khaldun-colonial-archive-29]: Most notably, Gayatri Spivak, “The Politics of Translation,” in *Outside in the Teaching Machine* (New York: Routledge, 1993); Ngũgĩ wa Thiong’o, “Writing Against Neo-Colonialism,” in *Moving the Centre: The Struggle for Cultural Freedoms* (London: James Currey, 1993), 43–64.

[^ibn-khaldun-colonial-archive-30]: See Claire Chambers and Ipek Demir, eds., *Translation and Decolonization: Interdisciplinary Approaches* (New York: Routledge, 2024).

[^ibn-khaldun-colonial-archive-31]: Edward Said, *Orientalism* (New York: Pantheon Books, 1978).

[^ibn-khaldun-colonial-archive-32]: See Abdelmajid Hannoum, “Violence in Translation or Fanon Otherwise,” in Hannoum, *Secular Narrations and Transdisciplinary Knowledge*; Nigel Gibson, “Relative Opacity: A New Translation of Fanon’s *Wretched of the Earth*—Mission Betrayed or Fulfilled,” *Social Identities* 13, 1 (2007): 69–95.

[^ibn-khaldun-colonial-archive-33]: Edward Said, *Orientalism*, op.cit., 124.

[^ibn-khaldun-colonial-archive-34]: Hannoum, “Translation and the Colonial Imaginary,” op. cit.

[^ibn-khaldun-colonial-archive-35]: Ibid., 64.

[^ibn-khaldun-colonial-archive-36]: Lucette Valensi, “La découverte d’un grand auteur en Europe: Le cas d’ Ibn Khaldun,” in Houari Touati, ed., *Figures d’Ibn Khaldûn: Réception, appropriation et usages* (Algiers: CNRPAH, 2010), 11.

[^ibn-khaldun-colonial-archive-37]: Ibid., 131.

[^ibn-khaldun-colonial-archive-38]: See Maya Shatzmiller, *L’historiographie mérinide: Ibn Khaldun et ses contemporains* (Leiden: Brill, 1982).

[^ibn-khaldun-colonial-archive-39]: See Abdelmajid Hannoum, “The Muqaddima of Ibn Khaldûn,” op. cit.

[^ibn-khaldun-colonial-archive-40]: On the racialization of the Berbers, see Hannoum, “Translation and the Colonial Imaginary,” op. cit.

[^ibn-khaldun-colonial-archive-41]: See Hannoum, *The Invention of the Maghreb*, especially the section “Ibn Khaldûn, a Colonial Author,” 183–87.

[^ibn-khaldun-colonial-archive-42]: Joseph Reinaud, “Ibn Khaldûn,” in *Nouvelle biographie générale*, vol. 25 (Paris: Firmin Didot, 1854), 740–47.

[^ibn-khaldun-colonial-archive-43]: Some of these categorizations may be anachronisms. See an insightful critique by Lawrence Rosen of the idea of Ibn Khaldûn as an anthropologist in Ibn Khaldun (New York: Berghahn Books, 2026).

[^ibn-khaldun-colonial-archive-44]: Abdelmajid Hannoum, “La gouvernementalité coloniale et la naissance du Khaldûnisme,” in *Figures d’ Ibn Khaldûn*, 151–60.

[^ibn-khaldun-colonial-archive-45]: De Slane/Ibn Khaldûn, *Histoire des Berbères* (Alger: Imprimerie du Gouvernement, 1856), lxix.

[^ibn-khaldun-colonial-archive-46]: Ibid.

[^ibn-khaldun-colonial-archive-47]: See Abdelmajid Hannoum, “The Historiographic State: How Algeria Once Became French,” *History and Anthropology* 19, 2 (2008): 91–114.

[^ibn-khaldun-colonial-archive-48]: Nicholas Dirks, “History as a Sign of the Modern,” *Public Culture* 2 (1990): 25–32.

[^ibn-khaldun-colonial-archive-49]: Arthur de Gobineau, *Essai sur l’inégalité des races humaines* (Paris: Firmin Didot, 1853–55); English translation: Adrian Collins, *Essay on the Inequality of Human Races* (New York: H. Fertig, 1967).

[^ibn-khaldun-colonial-archive-50]: Hippolyte Taine, *Histoire de la littérature anglaise*, vol. 1 (Paris: Hachette, 1863).

[^ibn-khaldun-colonial-archive-51]: Ernest Renan, *De la part des peuples sémitiques dans l’histoire de la civilisation* (Paris: Michel Levy rères, 1862).

[^ibn-khaldun-colonial-archive-52]: Abdelmajid Hannoum, “Colonialism and Knowledge in Algeria: The Archives of the Arab Bureau,” *History and Anthropology* 12, 4 (2001): 343–79.

[^ibn-khaldun-colonial-archive-53]: Hannoum, “Translation and the Colonial Imaginary,” op. cit.

[^ibn-khaldun-colonial-archive-54]: For the modern narrative in history writing, see Paul Ricoeur, *Temps et récit*, vol. I (Paris: Seuil, 1983). For the medieval narrative, despite a rich tradition of semiotic theories, there are few examples of such analyses. See Aziz al-Azmeh, “Histoire et narration dans l’historiographie arabe,” *Annales: Histoire, Sciences, Sociales* 41, 2 (1986): 411–31; Houari Touati, “Approche sémiologique et historique d’un document hagiographique,” *Annales: Économies, Sociétés, Civilisations* 44, 5 (1989): 1205–28; Abdelmajid Hannoum, “Hagiographie et légende au Maghreb: La Kahina ou la production d’une mémoire,” *Annales: Histoire, Sciences, Sociales* 54, 3 (1999): 667–86.

[^ibn-khaldun-colonial-archive-55]: See Hannoum, “The Historiographic State”; Abdelmajid Hannoum, “Notes on the (Post) Colonial in the Maghreb,” *Critique of Anthropology* 29, 3 (2009): 324–44.

[^ibn-khaldun-colonial-archive-56]: See Edmond Burke III, *The Ethnographic State: France and the Invention of Moroccan Islam* (Berkeley: University of California Press, 2014); Steinmetz, *The Colonial Origins of Modern Social Thought.*

[^ibn-khaldun-colonial-archive-57]: Michel Foucault, “Qu’est-ce qu’un auteur?” *Bulletin de la Société française de philosophie* 63, 3 (1969): 73–104.

[^ibn-khaldun-colonial-archive-58]: Nicholson, *A Literary History of the Arabs*, 452.

[^ibn-khaldun-colonial-archive-59]: Ibid., 438–39.

[^ibn-khaldun-colonial-archive-60]: Régis Blachère, “Place d’Ibn Khaldun dans l’humanisme Arabo-islamique,” *Revue des Deux Mondes*, October 1972: 79.

[^ibn-khaldun-colonial-archive-61]: Jacques Berque, *L’intérieur du Maghreb* (Paris: Gallimard, 1978), 13.

[^ibn-khaldun-colonial-archive-62]: Robert Brunschvig, *La Berbérie orientale sous les Hafsides* (Paris: Adrien-Maisonneuve, 1982), vol. 2, 391.

[^ibn-khaldun-colonial-archive-63]: Brunschvig, *La Berbérie orientale sous les Hafsides.*

[^ibn-khaldun-colonial-archive-64]: Ibid.

[^ibn-khaldun-colonial-archive-65]: Arnold J. Toynbee, *A Study of History*, vol. III (London: Oxford University Press, 1955), 321–22.

[^ibn-khaldun-colonial-archive-66]: Charles Issawi, *An Arab Philosophy of History: Selections from the Prolegomena of Ibn Khaldun of Tunis (1332–1406)* (London: John Murray, 1950).

[^ibn-khaldun-colonial-archive-67]: Émile-Félix Gautier, “Le cadre géographique de l’histoire en Algérie,” in *Histoire et historiens de l’Algérie* (Paris: Librairie Félix Alcan, 1930), 17–35.

[^ibn-khaldun-colonial-archive-68]: In 1964, Anouar Abdel‑Malek already diagnosed its crisis. See Anouar Abdel‑Malek, “Orientalism in Crisis,” *Diogenes* 13, 50 (1964): 89–110; Daniel Reig, *Homo orientaliste (*(Maisonneuve et Larose, 1988); Hichem Djait, *Europe and Islam* (Berkeley: University of California Press, 1985). See also Abdelmajid Hannoum, “Faut‑il Brûler l’Orientalisme?” *Cultural Dynamics* 16, 1 (2004): 195.

[^ibn-khaldun-colonial-archive-69]: Mahmood Mamdani, “Reading Ibn Khaldun in Kampala,” *Journal of Historical Sociology* 30, 1 (2017): 7–26.

[^ibn-khaldun-colonial-archive-70]: Rosen, *Ibn Khaldun*, 122.

[^ibn-khaldun-colonial-archive-71]: See Abdelmajid Hannoum, *Living Tangier: Migration, Race, and Illegality in a Moroccan City* (Philadelphia: University of Pennsylvania Press, 2020); Isabella Alexander-Nathani, *Burning at Europe’s Borders: An Ethnography on the African Migrant Experience in Morocco* (Oxford: Oxford University Press, 2020); Chouki El Hamel, *Black Morocco: A History of Slavery, Race and Islam* (Cambridge: Cambridge University Press, 2014).

[^ibn-khaldun-colonial-archive-72]: Cedric Dover, “The Racial Philosophy of Ibn Khaldun,” *Phylon* 13, 2 (1952): 107–19.

[^ibn-khaldun-colonial-archive-73]: Bernard Lewis, *Race and Color in Islam* (New York: Harper and Row, 1971), 38.

[^ibn-khaldun-colonial-archive-74]: Ibn Khaldûn, *Muqaddimah*, 117.

[^ibn-khaldun-colonial-archive-75]: Mamdani, “Reading Ibn Khaldun in Kampala.”

[^ibn-khaldun-colonial-archive-76]: Ibid., 15.

[^ibn-khaldun-colonial-archive-77]: Despite the ambiguity of the term *culture*, which has over 150 definitions according to Alfred Kroeber and Clyde Kluckhohn; see *Culture: A Critical Review of Concepts and Definitions* (Cambridge, MA: Peabody Museum Press, 1952).

[^ibn-khaldun-colonial-archive-78]: On the concept of *ʿumrân* in the *Muqaddimah*, see Hannoum, “The Muqaddima of Ibn Khaldun.”

[^ibn-khaldun-colonial-archive-79]: On the colonial meaning of the modern concept of civilization, see Lucien Febvre, Émile Tonnelat, Marcel Mauss, Alfredo Niceforo, and Louis Weber, *Civilisation, le mot et l’idée* (Paris: La Renaissance du Livre, 1930).

[^ibn-khaldun-colonial-archive-80]: Mohammed Abid al-Jabri, *al-ʿAṣabiyya wa al-Dawla* (Casablanca: Markaz Dirasat al-Wahda al-*ʿ*Arabiyya, 1992), 157.

[^ibn-khaldun-colonial-archive-81]: Lévy-Bruhl uses and applies the same concept to any region not European, including China, Japan, and the populations of Africa, Asia, and the Americas. See Lucien Lévy-Bruhl, *La mentalité primitive* (Paris: Félix Alcan, 1922).

[^ibn-khaldun-colonial-archive-82]: Ibid., 161.

[^ibn-khaldun-colonial-archive-83]: Immanuel Kant, *Observations on the Feeling of the Beautiful and Sublime, trans. John T. Goldthwait* (Berkeley: University of California Press, 1965), 110.

[^ibn-khaldun-colonial-archive-84]: Arthur Gobineau, *The Inequality of Human Races* (London: William Heinemann, 1915), 205.

[^ibn-khaldun-colonial-archive-85]: Rosenthal/Ibn Khaldûn, *The Muqaddimah*, 199.

[^ibn-khaldun-colonial-archive-86]: This is a contested topic in anthropology. Modern ethnography reports practices such as cannibalism in different historical and regional contexts—see, for example, E. E. Evans-Pritchard, “Cannibalism: A Zande Text,” *Africa* 26, 1 (1956): 73–74. While some scholars have argued that cannibalism often functions as a colonial trope or a discourse (see W. Arens, *The Man-Eating Myth* [New York: Oxford University Press, 1979]; Gananath Obeyesekere, *Cannibal Talk* [Berkeley: University of California Press, 2005]), others have defended its existence in specific ecological or ritual settings (see P. Brown and D. Tuzin, *The Ethnography of Cannibalism* [Washington, D.C.: Society for Psychological Anthropology, 1983]; M. A. Elgar and B. J. Crespi, *Cannibalism: Ecology and Evolution of Cannibalism* [Oxford: Oxford University Press, 1992]; C. Turner and J. Turner, *Man Corn: Cannibalism and Violence in the Prehistoric American Southwest and Mexico* [Salt Lake City: University of Utah Press, 1999]).

[^ibn-khaldun-colonial-archive-87]: Ibn Khaldûn, *Muqaddimah*, 31.

[^ibn-khaldun-colonial-archive-88]: In the Arabic text, “*al-ʿumrân [note small diacritical mark change here] huwa al-tasakun wa al-tanazul fi misr aw hilla lil-aluns bi al-*ʾ*ashir wa iqtida*ʾ*al-hajat*,” (31). In this passage, Ibn Khaldûn defines *ʿumrân* in terms of co-residence and settlement (*tasākun*, *tanāzul*) in towns or habitations, linking sociability (*uns*) to the satisfaction of material needs.

[^ibn-khaldun-colonial-archive-89]: Ibn Khaldûn, *Muqaddimah*, 31.

[^ibn-khaldun-colonial-archive-90]: *“Aḫlāquhum qarība min ʾakhlāq al-ḥayawānāt,”* Ibn Khaldûn, *Muqaddimah*, 65.

[^ibn-khaldun-colonial-archive-91]: See Ivan Hannaford, *Race: The History of an Idea in the West* (Baltimore: Johns Hopkins University, 1996). For the eighteenth century, see Roxann Wheeler, *The Complexion of Race* (Philadelphia: University of Pennsylvania Press, 2000).

[^ibn-khaldun-colonial-archive-92]: Lewis Gordon, “Race in the Dialectics of Culture,” in Lewis R. Gordon, Rozena Maart, and Sayan Dey, eds., *Black Existentialism and Decolonizing Knowledge* (London: Bloomsbury Press, 2023), 43.

[^ibn-khaldun-colonial-archive-93]: Abdelmajid Hannoum, “Other Times, Other Places, Other Secularisms,” in Abdelmajid Hannoum, ed., *Secular Narrations and Transdisciplinary Knowledge*, 27–46 (New York: Routledge, 2023). Also, Nassif Nassar, *La pensée realiste d’Ibn Khaldûn* (Paris: Presses Universitaires de France, 1967).

[^ibn-khaldun-colonial-archive-94]: Abdelmajid Hannoum, “On Translation Ideology,” in Claire Chambers and Ipek Demir, eds., *Translation and Decolonization: Interdisciplinary Approaches* (New York: Routledge, 2024), 78–94.

## 编者说明 / Editorial notes

本版保留作者对殖民翻译的论证及其限定，尤其是对气候等级与种族等级的区分、对原文并非中立或无偏见的承认。关于伊本·赫勒敦、罗森塔尔及其他学者的判断属于本文作者的解释，不应将译文视作另行完成的阿拉伯语文献校勘。

episteme译为知识型，epistemology译为知识论，epistemic decolonization译为知识去殖民化，coloniality译为殖民性。ʿumrân、ʿaṣabiyya、haḍâra、badâwa、tawaḥḥush等是本文争论的对象，保留原文转写并依作者语境释义，不强行用一个现代概念覆盖全部用法。正文出现的umrân等转写变体按原文保留。

Muqaddimah译为《历史绪论》，Kitâb al-ʿIbar译为《鉴戒之书》。正文称后者三卷，注5所引版本为8卷，二者均照录。正文对Canaan与Noah关系的表述及《非洲描述》的写作语言、时间均按原文译出，未作无来源的历史订正。

本版用Negroes、Negro或Nègres保留原文所分析的历史种族称谓，必要处附中文释义；引述中的种族主义及其他贬抑判断均有明确归属，不是译者立场。Sudan在这些中世纪讨论中依语境译为苏丹地区，不自动等同于今日苏丹共和国。

原注82仅作Ibid., 161，紧接注81的列维—布留尔文献，存在指代疑点，本版保留而不自行改指注80。注24的was、注51的Levy rères、注68的重复括号及注88的变音符号编辑提示均见原文；英文保留，中文说明提示。原文不完整的书目不擅补。

原文关于1830、1847、1850、1854、1858及1863年的表述按原样保留；正文出版时间与注45所引1856年版本不强行合并。引文中遗漏的闭引号在中文中按语意补齐。题名译释供阅读与检索，不表示已有正式中译本。

原刊页码为段落起始页，跨页段落不拆分。网页原注可往返定位，PDF将原注置于引用段落之后；注28在正文出现两次，因此阅读版两处均列同一原注，独立原注总数仍为94。
