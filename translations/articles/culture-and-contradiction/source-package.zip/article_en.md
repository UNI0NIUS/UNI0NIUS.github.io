# Culture and Contradiction Before the End of History: From Socialist Legacies to Market Logics

Petrică Mogoș. Erasmus School of History, Culture and Communication, Erasmus University Rotterdam, Netherlands. Email: mogos@eshcc.eur.nl. Comparative Studies in Society and History (2026), 1–27. Published online: 14 October 2026.

https://doi.org/10.1017/S0010417526100656

据Cambridge University Press出版方HTML全文翻译，并与27页原刊PDF核对结构和原刊页码。保留完整摘要、正文、致谢、资助声明及97条原注；无独立书目或图表。原注中的论述完整翻译，书目检索信息保留并附中文题名译释。© The Author(s), 2026；Cambridge University Press代表Society for the Comparative Study of Society and History出版。原文及本译文采用CC BY 4.0。翻译、译释和编者说明为本版新增；AI辅助工作译稿，不代表作者或出版社认可。

CC BY 4.0: https://creativecommons.org/licenses/by/4.0/

Keywords: late socialism; crisis; austerity; debt; contradiction; self-financing; cultural production; cultural governance; autogestion; historical sociology

<!-- culture-and-contradiction-001 -->

〔原刊 p. 1〕

## Abstract

<!-- culture-and-contradiction-002 -->

〔原刊 p. 1〕

In late-socialist Romania, the state sought to govern economic crisis by demanding market-like conduct from cultural institutions while continuing to bind them to the political structures of socialism. Drawing on archival planning reports, media accounts, and post-socialist recollections, this article traces the emergence of a “self-financing regime” that reorganized cultural production around revenue generation, entrepreneurial conduct, and managerial accountability. I argue that self-financing constituted neither a retreat of socialism nor an incipient transition to capitalism, but an experiment in governing crisis by relocating the burdens of economic survival onto institutions themselves. This shift generated a contradictory institutional world: cultural actors were compelled to pursue economic self-sufficiency and become self-optimizing subjects even as markets remained ideologically repudiated, socialist obligations endured, and nominal decentralization extended bureaucratic oversight. Yet contradiction did not simply signal the incoherence of late socialism. As these tensions became embedded in everyday institutional practice, contradiction provided the very means through which austerity was rendered governable. The Romanian case thus shows how market-like rationalities could emerge from within socialist crisis management and crystallize into historically distinct forms of governance. By situating these entanglements before the so-called “end of history,” the article unsettles teleological narratives of socialist-capitalist rupture and reconsiders crisis as a historically contingent site where seemingly opposed political-economic logics can be made and remade in practice.

<!-- culture-and-contradiction-003 -->

〔原刊 p. 1〕

## Introduction

<!-- culture-and-contradiction-004 -->

〔原刊 p. 1〕

In a 1979 Communist Party committee meeting, Nicolae Ceaușescu declared, “We should stop making Romanian films if they don’t generate income, artists should be paid from the film’s revenue, like everywhere else in the world. Romanian cinema must become financially self-sustaining in and of itself.”[^culture-and-contradiction-1] His statement captured a constitutive tension at the heart of late-socialist cultural governance: an institutional configuration that demanded market-oriented conduct, in which artistic value was required to demonstrate economic viability while remaining embedded in a system that formally disavowed market logic.

<!-- culture-and-contradiction-005 -->

〔原刊 p. 2〕

By the time socialism had reached the brink of collapse, cultural institutions were already curbing dependence on state subsidies, translating their activities into measures of economic performance, and cultivating practices of financial self-reliance under conditions of austerity. Contrary to customary ideological framing, this transformation produced market-oriented logics within socialist governance long before any formal transition to the market, which gave shape to a distinct mode of cultural governance in which financial accountability became an internal principle of institutional life. Using an abductive approach, I trace moments where socialist state-planned governance and capitalist, market-like valuation logics intersected in practice, and where formal directives collided with everyday improvisation.[^culture-and-contradiction-2] At the center of this analysis is the self-financing regime imposed on cultural institutions, an “almost capitalist” fulcrum of economic behavior in a socialist economy.[^culture-and-contradiction-3] The measures taken in service of this reconfiguration were neither accidental by-products of austerity nor premature signs of transition toward capitalism, but integral to a framework that reorganized cultural institutional life under late socialism by negotiating its own contradictions and rendering them both operational and opaque.

<!-- culture-and-contradiction-006 -->

〔原刊 p. 2〕

Archival evidence concerning philharmonics, museums, and other cultural institutions reveals that artists and administrators devised ingenious strategies to keep cultural production afloat, often in ways that unsettle prevailing assumptions about how socialism and capitalism were thought to operate before the “end of history.”[^culture-and-contradiction-4] Much of the scholarship on state socialism has traditionally been organized around oppositional interpretive categories (state versus society, repression versus freedom, ideology versus resistance), which have shaped understandings of cultural life through prisms of ideology and censorship or artistic autonomy and dissent.[^culture-and-contradiction-5] Yet such frameworks tend to obscure a more consequential transformation that was unfolding at the level of organizational rationality itself, where hybrid governing logics became entangled in practice.

<!-- culture-and-contradiction-007 -->

〔原刊 p. 3〕

An important qualification is necessary in this context. As scholars of socialist political economy such as János Kornai, Martha Lampland, and Katherine Verdery have shown, socialist economies long incorporated mechanisms of revenue generation and enterprise responsibility, even if these operated under distinct property relations and budgetary conditions.[^culture-and-contradiction-6] If economic calculation was not foreign to socialism, then the significance of the Romanian case lies elsewhere: in how a crisis-ridden socialist state that continued to affirm the primacy of centralized planning progressively redefined culture through economic accountability. Under the pressure of austerity and broader crisis, economic performance ceased to be merely a technique of administration and became a principle of cultural evaluation. What was increasingly at stake, as a result, was how cultural value, professional legitimacy, and even institutional survival came to be assessed and made governable through the economic language of measurable outcome.

<!-- culture-and-contradiction-008 -->

〔原刊 p. 3〕

Therefore, rather than invoking capitalism as a totalizing category or casting late socialism as an inevitable march toward it—where socialism seamlessly collapsed into capitalism, ending ideological debate and “history” itself—the analysis reconstructs the hybrid institutional logics that made cultural governance and institutional rationalities operational prior to socialism’s demise. It traces how macro-political reforms (such as the self-financing regime) were articulated at the level of policy discourse and operationalized by central authorities. Furthermore, to understand how contradictions played out in practice, it then turns to how market-oriented logics materialized in the everyday operations of cultural institutions. Moving between these registers—policy deployed from above and practice enacted from below—the analysis shows how cultural governance functioned through the managed coexistence of clashing logics and rationalities. In this frictional space of hybridity, culture had to learn to sustain itself, and in doing so, it also worked *through* rather than resolved the contradictory conditions that structured its survival.

<!-- culture-and-contradiction-009 -->

〔原刊 p. 3〕

To untangle this empirical knot, I draw on a wide range of archival planning reports, administrative decrees, institutional statutes, and policy documents from the National State Archive of Romania and the legal gazette of Romania (*Monitorul Oficial*). I also draw from news bulletins and feature stories archived by the Arcanum database. Although such media archives are often dismissed as mere extensions of party propaganda, they offer more than their official veneer suggests. Embedded within them are fragments of grassroots reporting, micro-level interviews, and site-specific voices of discontent—sources that, when read “along the archival grain,” illuminate intersections of domination and adaptation.[^culture-and-contradiction-7] While my analysis centers on the final decade of socialism (1980–1989), earlier episodes are folded in to show how market logics were systematically and intentionally incorporated into socialist frameworks long before the crisis of the 1980s. Additionally, I weave post-socialist recollections into the narrative, since such testimonies reveal how cultural actors retrospectively made sense of their lived experiences during late socialism.[^culture-and-contradiction-8]

<!-- culture-and-contradiction-010 -->

〔原刊 p. 4〕

This nonlinear, longue durée perspective prioritizes continuities and sedimented logics over ahistorical fantasies of rupture. Drawing on a historical sociological perspective, I read the archives relationally in order to make visible how institutions, policies, and cultural actors co-constituted one another under crisis conditions and produced hybrid modes of organization. If decrees and transcripts of closed-door meetings codified norms from above, reports and news bulletins reveal how the prescriptions were negotiated and refracted in practice. I treat these records not as transparent windows into distant or exotic pasts but as situated sites of practice. In addition to documenting official directives and performing state narratives, they also expose frictions and enable the reconstruction of the micro-level mechanisms through which policies were implemented or repurposed on the ground.

<!-- culture-and-contradiction-011 -->

〔原刊 p. 4〕

To grasp how late socialism experimented with market-oriented forms of governance in the cultural sector, I propose an analytic framework attuned to these hybrid and often contradictory logics. The article identifies four constitutive contradictions of the self-financing regime, which manifest empirically as a series of institutional paradoxes. First, I explore how market rationality was inscribed without markets: cultural outputs were stratified by perceived commercial potential, and institutions were assessed through metrics of efficiency and self-generated income even as market infrastructures remained largely absent. Second, I examine entrepreneurial socialism as both policy and practice, in which cultural administrators, musicians, and pedagogues were encouraged to act entrepreneurially and enact a logic that remained ideologically suspect. Third, I reveal how state socialism sought to remedy the lack of entrepreneurial disposition through specialized retraining programs and thereby produced a distinctive hybrid of economic rationality and political loyalty that transformed cultural management from within. Fourth, I show how the promised decentralization produced its bureaucratic counterpart. Instead of enabling creative autonomy, it generated onerous paperwork and epistemic surveillance that imposed novel forms of individual accountability aimed at shoring up institutional budgets.

<!-- culture-and-contradiction-012 -->

〔原刊 p. 4〕

These four paradoxes are not symmetrical in scope or function. Analytically, they point to constitutive contradictions within the self-financing regime; empirically, they appeared as paradoxical configurations through which institutions experienced and negotiated demands. While the first paradox traces how these contradictions were articulated and deployed from above, the other three capture their ambivalent afterlives: simultaneous outcomes of policy and situated, improvised responses through which institutions navigated—and at times subverted—those very directives. In line with my abductive approach, each subsection begins with an archival puzzle that makes the contradictions of self-financing empirically tractable.

<!-- culture-and-contradiction-013 -->

〔原刊 p. 5〕

## Market Rationality Without Markets: Differentiated Sectors and Incremental Reform

<!-- culture-and-contradiction-014 -->

〔原刊 p. 5〕

Among the archival traces documenting Romania’s late socialist turn to self-financing, one testimony captures its contradictions with particular clarity. Constantin Ungureanu, director of the Craiova Opera in the 1980s, recalled the challenges that arose once the institution ceased to receive full state subsidies. By January 1984, salaries could only be paid at 80 percent, and by April, the performance capacity of the institution had plummeted to 25 percent. “To achieve what was demanded,” he noted, “I calculated we would need six full-house performances a day. An absurdity. We tried every way we could to make ends meet. We even did five shows a day on the road, touring to bring in money.” Shortly afterward, Ungureanu was dismissed: “I was told we should try with other, more merchant-like people.”[^culture-and-contradiction-9]

<!-- culture-and-contradiction-015 -->

〔原刊 p. 5〕

As this testimony indicates, institutions were pushed into seemingly impossible calculations of viability, where intensified demands for efficiency and output clashed with preexisting definitions of what cultural work was. Introduced under the banners of austerity and a “rational use of resources,”[^culture-and-contradiction-10] this logic took the form of a top-down reordering of institutional life that curtailed expenditure and quantified performance, generating forms of economic rationalization that coexisted with, rather than displaced, socialist governance. Within these conditions of material constraint and metricized performance, composer and critic Valentin Petculescu recalls numerous “unpaid concerts, with rehearsals at skating-rink temperatures,” conditions that led instrumentalists to what they came to call, not without irony, the “invention of the decade”: fingerless gloves, devised to allow performance in extreme cold.[^culture-and-contradiction-11]

<!-- culture-and-contradiction-016 -->

〔原刊 p. 5〕

Yet these anecdotes of everyday improvisation were not mere ad hoc responses to austerity. The self-financing regime itself emerged from a broader reconfiguration of socialist governance under the pressures of global financial crisis and Romania’s mounting external debt. By 1982, this debt had become unsustainable and prompted negotiations with the International Monetary Fund. In pursuit of economic sovereignty, Ceaușescu turned toward a unilateral strategy of accelerated debt repayment and intensified austerity, giving rise to a *sui generis* regime characterized by draconian internal constraints and a sweeping reorganization of administrative and economic governance across the socialist economy.[^culture-and-contradiction-12] Within this framework, logics of self-financing, decentralized managerial responsibility, and performance-based accountability were put into operation. They were not confined to the cultural sector but circulated across domains such as education, healthcare, or agro-industrial administration albeit with different intensities and institutional configurations. Ceaușescu himself framed the self-financing regime as a “unified development program,” insisting that all administrative units across the socialist economy operate under the principle that they should not “spend more than the resources [they] generate.”[^culture-and-contradiction-13]

<!-- culture-and-contradiction-017 -->

〔原刊 p. 6〕

Within this broader economic reorientation, the self-financing regime became a key instrument for both legitimizing austerity and increasing fiscal extraction capacity. Designed to make institutions (partially) responsible for their own budgets, it shifted the burden of economic viability onto local administrative units and compelled them to cut costs and justify expenditure through measurable outcomes. In effect, socialist institutions—cultural included—were reconstituted as semi-autonomous enterprises whose legitimacy depended on financial performance as much as on criteria such as ideological conformity or aesthetic value.

<!-- culture-and-contradiction-018 -->

〔原刊 p. 6〕

However, despite its ubiquity as a governing principle across the economy, self-financing acquired a distinct and uneven articulation in the cultural sector. Official discourse simultaneously reaffirmed culture as ideologically essential to socialist life and framed it as a domain of “limited resources” that required “prudence and rational allocation.”[^culture-and-contradiction-14] In institutional terms, this tension was translated into stringent budgetary controls that turned cultural organizations into laboratories for experimenting with economic discipline under conditions of scarcity. This reorientation is visible in state budgetary allocations. While agricultural funding rose by as much as 9 percent, cultural budgets were sharply reduced by 47 percent, falling from 1.16 billion lei in 1983 to 735.2 million in 1984.[^culture-and-contradiction-15] Although the 1986 budget appeared to signal recovery, with culture rising to 2.7 billion lei, it remained marginal relative to other sectors (education received 22 billion lei; social security 45 billion). More decisive than overall levels, however, was the restructuring of funding itself: only 23 percent of cultural expenditure was covered by the state (620 million lei), while the remaining 77 percent had to be generated autonomously by cultural institutions themselves.[^culture-and-contradiction-16] On the one hand, this inversion reflected the withdrawal of institutional safety nets and the shifting of financial responsibility onto cultural institutions. On the other, it laid the ideological and operational foundations for the entrenchment of self-financing into everyday practice, which effectively bound institutional survival to income generation.[^culture-and-contradiction-17]

<!-- culture-and-contradiction-019 -->

〔原刊 p. 7〕

The asymmetry of this implementation was exacerbated by a recurrent tension in official discourse, which oscillated between regarding culture as structurally “non-productive” and potentially “wasteful,” associated with “excessive expenditure”[^culture-and-contradiction-18] relative to measurable output, and simultaneously affirming its latent economic value as a domain that could be made more efficient and self-sustaining. Both public rhetoric and internal administrative reports—preserved in official bulletins and confidential documentation—mobilized this ambiguity to frame cultural spending as a site requiring optimization. In this way, rather than resolving the contradiction between cultural value and economic inefficiency, the regime rendered it productive as a justification for austerity measures in the sector. Claims of presumed extravagance—although archival records do not confirm the extent of such excess—thus persisted as a distortion to be corrected, in which culture remained singled out as a sphere in need of reform.[^culture-and-contradiction-19]

<!-- culture-and-contradiction-020 -->

〔原刊 p. 7〕

As early as 1981, Teodor Iovănescu—an economist who wrote and advised extensively on the introduction of self-financing in the cultural sector—warned of this necessity in times of crisis. In his report on the “optimization of cultural activity,” the state would aim to reduce central allocations while concurrently producing the necessary conditions for a transition “as urgently as possible, to a system of full self-financing.”[^culture-and-contradiction-20] Iovănescu framed this shift as a structural reconfiguration in which the very existence of cultural institutions would soon be tied to their economic performance. This followed the directives of Ceaușescu himself, who, one year prior, in 1980, called for a rapid restructuring of the cultural sector. In his words:

<!-- culture-and-contradiction-021 -->

〔原刊 p. 7〕

It is necessary that, in a short time, we base the entire activity on principles of self-management [*autoconducere*] and self-governance [*autogestiune*]. […] Each theater, cultural center, house of culture must have its own budget of revenues and expenditures, must know how much it can spend, and also what it must provide. Just as a worker works eight hours, those in social and cultural activities must know that they are required to work a certain number of hours and accomplish specific activities. This is also true for music, where we have a number of ensembles that must present to the working people a set number of concert hours per week. Everything can and must be organized according to the principles of self-management. (*Loud applause.*)[^culture-and-contradiction-21]

<!-- culture-and-contradiction-022 -->

〔原刊 p. 7〕

Nevertheless, the reform did not unfold overnight. Despite calls for “urgency,” the shift materialized incrementally as the product of cumulative policy layering that had piled up across nearly two decades. With the aim of curbing cultural expenditure and disciplining the sector, it fulfilled a long-standing ideological trajectory of legislation stretching back as far as 1971.[^culture-and-contradiction-22] New self-financing logics were implanted onto existing structures, culminating in *Law nr. 1* (1985), which mandated that virtually all (cultural) institutions assume some degree of self-reliance, albeit to uneven and institutionally differentiated extents.

<!-- culture-and-contradiction-023 -->

〔原刊 p. 8〕

The most visible effects of this layering of cultural policy were the imposition of economic targets and new expectations of output. With the exception of cinemas, theaters, and music institutions—which already quantified premieres and spectators—most cultural organizations entered the 1980s without predefined economic performance indicators. Gradually, however, official discourse acknowledged that cultural-artistic units required differentiated forms of evaluation and financing. By the late 1980s, the self-financing model had coagulated into a fully articulated system, complete with explicit economic targets and genre-specific benchmarks that reconditioned the operational logic of cultural institutions. Professional music institutions (operas, philharmonics, orchestras) saw their self-financing targets rise from 20 percent in 1981 to 75 percent in 1985 and 79 percent by 1988.[^culture-and-contradiction-23] From 1985, houses of culture *(* *case de cultură*) were required to achieve full (100 percent) self-financing, up from 85 percent in 1984. Local cultural centers (*cămine culturale*) and folk art schools (*școli populare de artă*) both transitioned to full self-financing in 1984.[^culture-and-contradiction-24]

<!-- culture-and-contradiction-024 -->

〔原刊 p. 8〕

Such targets were far from arbitrary and reflected entrenched cultural hierarchies that structured internal differentiation within the cultural field. Self-financing did not operate uniformly across cultural production but generated a graded system of expectations in which cultural genres and institutions were evaluated according to their perceived commercial potential, thereby transforming hierarchy into an operational principle of economic governance that distinguished institutions with greater revenue prospects from those deemed less profitable. Underlying this distinction was, in Iovănescu’s view, the idea that social recognition was increasingly contingent on institutional form, insofar as an organization’s capacity to survive independently of state subsidies was determined by its commercial viability.[^culture-and-contradiction-25] To be more precise, for commodifiable cultural outputs (Iovănescu mentions books, visual art, music records, and live performances), value was to be mediated by the possibility of market exchange: sales and revenues translated cultural effort into measurable output, while unsold inventories or withdrawn performances signaled limited societal recognition and required producers to adjust output to perceived consumer demand.

<!-- culture-and-contradiction-025 -->

〔原刊 p. 8〕

In practice, this demand subjected institutions to a form of quasi-market discipline, as they started being evaluated through consumption patterns and sales performance. Put differently, institutions were expected to recalibrate both administrative operations and cultural-curatorial programming to austerity conditions; they had to learn to anticipate and respond to demand signals as if operating according to market relations and under supply-and-demand mechanisms. Yet the expectation of economic self-reliance and market-like conduct unfolded without many of the institutional conditions associated with market coordination. As a result, while the reforms did not create market relations in any straightforward sense, they did expand the role of economic evaluation in a centrally administered system and compelled actors to pursue revenue and develop market sensibilities. This category included entities with legal personality and the commercial potential to sustain themselves: the main film studios (“București,” “Alexandru Sahia,” “Animafilm”), the Romanian Radio and Television Network, and the “Romaniafilm” distribution company. Likewise, fully self-financing institutions included commercial powerhouses like publishing houses and daily newspapers, and ARIA (Romanian Artistic Booking Agency). Partially self-financing institutions, such as theaters and philharmonics, covered their remaining expenses through allocations from local supervisory authorities or central state budgets.[^culture-and-contradiction-26]

<!-- culture-and-contradiction-026 -->

〔原刊 p. 9〕

The episode highlighted at the start of this article, when Ceaușescu insisted that cinema must financially sustain itself, foreshadowed this broader reconfiguration of culture. More than a mere signal of intent, it articulated a proto-market paradigm in which cultural value was measured through commercial success and quantifiable income. By requiring cultural institutions to fund their own operations, the regime destabilized the traditional autonomy of the cultural field and subjected it to the heteronomous logic of economic rationality. Rather than a simple displacement of socialist principles for capitalist ones, the result was the coexistence of two partially overlapping and often contradictory logics: one promising disinterested symbolic production for the socialist polity, the other demanding profitability and measurable returns—a friction that reconfigured both everyday institutional practice and the meaning of culture itself. In the next paragraphs I explore how this logic was refracted in practice, where it took distinct forms across institutional typologies.

<!-- culture-and-contradiction-027 -->

〔原刊 p. 9〕

For instance, in 1984, theaters and music institutions were explicitly told to “amplify and diversify activities,” increase revenues, and reduce expenditures. Rationalization translated into contraction and creative labor was subordinated to economic discipline to the extent that, between 1980 and 1987, personnel reductions reached up to 52 percent in certain arts and culture sectors, while music institutions alone accounted for a reduction of 1,660 staff positions.[^culture-and-contradiction-27] Yet most institutions still failed to meet financial targets, and some, like Ungureanu’s Opera, struggled to pay salaries. At the same time, output surged: 25,814 performances (7,500 more than the previous year), 234 premieres (a 42 percent increase), and a 22 percent growth in audiences.[^culture-and-contradiction-28] This contradiction reveals another paradox of late-socialist governance: survival relied on measurable output, yet austerity did not suppress cultural production. At least from the vantage point of the archival record—which is partial and itself performs state narratives—artistic activity appears to have intensified, as cultural production was increasingly organized through economic indicators of growth that expanded the operational scope of a cultural market in the making. In this context, output indicators came to function as proxies for economic performance and ideological vitality, and institutional legitimacy was conflated with both.

<!-- culture-and-contradiction-028 -->

〔原刊 p. 10〕

Notably, not all institutions were equally exposed to this logic, since the cultural sector was restratified along lines of institutional typology and perceived commercial potential. Certain public-service institutions (such as libraries or museums) were sheltered from the self-financing architecture. In contrast with the previous institutional categorization, the social value of the labor of these institutions (and their corresponding degree of insulation from exposure to economic discipline) was determined less by price than by broader civic functions. The services they offered were generally free of charge, and while not entirely exempt from self-financing requirements, such establishments faced lower thresholds and reduced economic expectations. For example, in 1985, museums were only expected to self-finance 39 percent of their activity. Despite some growth, by 1988, the rate had only reached 55 percent.[^culture-and-contradiction-29]

<!-- culture-and-contradiction-029 -->

〔原刊 p. 10〕

Ultimately, although differentiated, late-socialist reforms integrated parameters of austerity and economic rationalization into the very language of cultural governance. While the broader self-financing regime marked a profound shift in the sector, *Law nr. 1* (1985) was its decisive turning point. With it, financing ceased to be an administrative detail and became a governing principle of cultural life. It shaped budgets, institutional priorities, and the logic of cultural production itself. By introducing explicit economic targets and performance benchmarks, the law institutionalized a mode of evaluation oriented less around ideological fulfillment alone and more around metrics of revenue generation and measurable institutional outcomes.

<!-- culture-and-contradiction-030 -->

〔原刊 p. 10〕

In doing so, it codified sectoral distinctions, sharpened existing hierarchies, and—despite its gradual rollout—pushed cultural institutions and actors into a high-stakes process of continuous adaptation. This differentiation points in two directions. On the one hand, it suggests that socialist authorities resisted a uniform model and instead calibrated expectations according to institutional function and perceived economic potential, which also indicates an awareness of the tensions embedded in the policy design. On the other hand, it is precisely in this asymmetry that the politics of evaluation becomes visible: state socialism sought to preserve a hierarchical cultural order while simultaneously engineering new forms of economic viability within the same institutional field. In this way, differentiation became a stratifying mechanism that (re)produced hierarchies and their own uneven distribution of risk and responsibility.

<!-- culture-and-contradiction-031 -->

〔原刊 p. 10〕

In addition to imposing new economic expectations, the self-financing regime reshaped the subjectivities of cultural directors and artists, who were compelled to internalize managerial rationalities and fiscal discipline. As the next section shows, whether individuals navigated these pressures skillfully or struggled to keep pace, all were forced to adapt or risk marginalization. The result was a patchwork of institutional strategies, one that reveals how unevenly top-down mandates were translated into the daily realities of cultural work.

<!-- culture-and-contradiction-032 -->

〔原刊 p. 10〕

## Entrepreneurialism without Capitalism: Cultural Labor and The Path to the “First Million”

<!-- culture-and-contradiction-033 -->

〔原刊 p. 10〕

The pressures of late-socialist economic reform compelled cultural workers to adopt forms of entrepreneurialism that redefined artistic labor and professional security. For instance, music pedagogues—once a protected group of conservatory-trained specialists—now had to attract fee-paying students to secure their positions or risk dismissal. Previously subsidized with 5 million lei annually, Bucharest’s *Folk Art School* was required to meet a 95 percent self-financing target and was consequently forced to reduce its staff (to sixty-one teachers, forty-one of them on half-time) and raise tuition fees. While a total of 1,399 fee-paying pupils secured the institution’s future, a minimum of twelve such students justified a single half-time teaching post. In effect, the burden of institutional survival was displaced onto individual teaching staff, who were required to secure enrollments as a condition of maintaining employment. Among the casualties of this reorganization was internationally celebrated cellist and prize-winning composer Şerban Nichifor, who was dismissed and permitted to return only on the condition that he personally “recruit the required dozen students.”[^culture-and-contradiction-30]

<!-- culture-and-contradiction-034 -->

〔原刊 p. 11〕

If we can speak of a “Nichifor case,” it exemplifies how the late-socialist turn to self-financing generated a new evaluative grammar that blurred the line between cultural status and economic performance, and exacerbated preexisting forms of precarity. Under these conditions, initiative itself became a dominant mode of institutional survival. The same archival report further indicates that amateur music instructors—often more agile in recruiting students—gained an advantage over credentialed professionals, who had to balance teaching hours with the artistic duties of rehearsing, auditioning, performing, and composing that had secured their institutional standing in the first place.[^culture-and-contradiction-31] While this shift could be read as a democratization of access to formerly prestigious teaching positions, it also reveals how criteria of cultural authority and cultural labor more broadly were redefined under the strains of a quasi-market environment.

<!-- culture-and-contradiction-035 -->

〔原刊 p. 11〕

A similar dynamic is evident in the case of Ungureanu, director of the Craiova Opera, where institutional survival became contingent on entrepreneurial ingenuity and ad hoc revenue-generating initiatives. His successor set up a small video library with two televisions screening up to six VHS films a day for modest entry fees—a semi-legal arrangement tolerated insofar as it kept the opera afloat financially.[^culture-and-contradiction-32] Such adaptations show how, under measures of austerity, the prestige of high-art institutions was refracted through economic rationality; at the same time, they reveal a fragile choreography of necessity in which artistic legitimacy was renegotiated through revenue-making practices. In the shadow of late socialism’s pervasive contradictions, two interrelated transformations become visible: first, institutional evaluation shifted, with prestige and formal credentials gradually ceding ground to market responsiveness as the dominant criterion of success. Second, cultural labor became increasingly mediated by quantifiable metrics of self-financing (e.g., number of pupils, tuition revenues, income targets). As professional legitimacy was made conditional on economic performance, it may also be that institutional success came to rest less on *how* quotas were achieved than on the fact that they were achieved at all, however precariously or inventively they were met.

<!-- culture-and-contradiction-036 -->

〔原刊 p. 12〕

Beyond moments of turmoil, the archive registers a vivid atmosphere of entrepreneurial euphoria. News reports capture the translation of a seemingly unsettled moment into an episode of effervescence. Suddenly tasked with transforming cultural activity into revenue, the cultural directors of the 1980s proudly showcased their recipe for entrepreneurial success and their paths to the “first million.” At the Municipal Cultural House Brașov, for example, the 1984 shift to 85 percent self-financing yielded a 209,000 lei surplus, and by October 1985 revenues had reached 1.31 million lei against a 1.05 million lei plan.[^culture-and-contradiction-33] A similar account from 1987, published in the party newspaper *Scînteia*, saw the director of the Trade Union Cultural House in Târgu Jiu, Mihai Rață, proudly announce, “We’ve hit the million.”[^culture-and-contradiction-34] The same celebratory tone is evident in Florica Șerbănescu’s report, the chief cultural official for Galați County. There, in the first quarter of 1984, cultural institutions generated four times more revenue than the previous year, and as a result of new measures, self-financing theaters and music institutions were projected to raise their annual income by an additional two million lei.[^culture-and-contradiction-35]

<!-- culture-and-contradiction-037 -->

〔原刊 p. 12〕

Echoing the mythic productivity of socialist workers, cultural actors were now nudged toward a different, almost tongue-in-cheek horizon of aspiration: the seductive grammar of “hitting the first million.” In this seemingly paradoxical configuration, cultural institutions were simultaneously disciplined by logics of planned productivity and lured by market benchmarks of success, which revealed how ideological and economic performances collided yet remained mutually constitutive. Several key strategies of commodification can be noticed in their attempt to meet quotas: in Brașov, alongside strict cost-saving measures such as cutting electricity by 57 percent, expansion was centered on monetizing cultural knowledge and skills through fee-paying courses (including technical drawing, folk dance, photography, and apiculture) that attracted up to 1,100 participants.[^culture-and-contradiction-36] Rață’s success in Târgu Jiu relied on the commodification of cultural participation and entertainment through large-scale programming: its offerings ranged from live music and theater performances to cine-club screenings and public debates. Approximately 600 events were reported annually, attracting nearly 800,000 attendees, 20 percent of whom were active participants.[^culture-and-contradiction-37]

<!-- culture-and-contradiction-038 -->

〔原刊 p. 12〕

In the case of Șerbănescu’s Galați County, an alternative strategy can be noticed. Live performance institutions, such as theaters and philharmonics, were instructed to double their shows—from 1,086 in 1983 to 2,190 in 1984—and maintain attendance rates of up to 95 percent.[^culture-and-contradiction-38] Keeping such high attendance was no easy feat, so cultural authorities were concerned with retaining established audiences while also attracting new ones. Maintaining established audiences involved transforming attendance into a reliable source of revenue, and institutions introduced monthly subscriptions as a means to monetize loyalty. To attract new audiences, orchestras and theater troupes extended their mobility across the county, performing beyond urban centers in factories, staging open-air shows in parks and stadiums, and offering educational programs. This multifaceted strategy shows how cultural production was reconfigured to meet both financial and ideological-pedagogical imperatives. Most strikingly, institutions whose legitimacy was grounded in artistic creation marketed their own staff’s labor commercially. In doing so, they offered carpentry, tailoring, or interior-decorating services to the general public in a clear recoding of cultural labor as marketable craftsmanship.

<!-- culture-and-contradiction-039 -->

〔原刊 p. 13〕

According to the archival record, the measures appear to have worked, and this reworked “perform or perish” logic precipitated a distinct form of “socialist entrepreneurialism.” Authorities celebrated financial achievements as proof that culture could, quite literally, pay for itself, and more. Entrepreneurial behavior, when aligned with broader political objectives, was recast as a distinct socialist virtue. Cultural revenues were paraded as the regime’s success, and austerity itself was rebranded as triumph: in 1988 alone, at the peak of the self-financing regime, the nationwide 145 professional theater and music institutions staged nearly 47,000 performances for over 18 million spectators, up from 38,000 shows and 16 million attendees in 1983.[^culture-and-contradiction-39] Such soaring figures were not incidental but symptomatic of a radically redesigned cultural sector, in which institutions operated as productive enterprises and success was defined through the conversion of artistic production into quantified output and indicators of accelerated growth. The celebrated goal of “hitting the million” functioned as both an imposed economic target and a prized symbol of managerial competence. In consequence, financial performance was naturalized as the proxy for professional accomplishment. Culture was instrumentalized as the means, financial success the end.

<!-- culture-and-contradiction-040 -->

〔原刊 p. 13〕

Yet this impressive output masked deeper disillusionment, as cultural actors remained estranged from the financial rewards their labor generated. Ungureanu, director of Opera Craiova, recalled working tirelessly “for the institution to earn some money,” only to discover that the 475-lei bonus he had received (after a twenty-five-lei tax deduction) was a mistake; the payment was meant for a printing press technician who shared his name.[^culture-and-contradiction-40] Rather than a merely tragicomic episode, the incident illustrates the unstable moral economy of a system in which cultural labor was rapidly redefined through managerial and financial categories, and where “entrepreneurialism” emerged not as market freedom but as a state-imposed obligation to sustain institutional solvency.

<!-- culture-and-contradiction-041 -->

〔原刊 p. 13〕

Across institutions, this reconfiguration translated into intensified labor regimes in which success depended on the compression of time and the multiplication of output. As recalled by Alexandru Racu, choir master of the Oltenia Philharmonic (credited with over 350 premieres and more than 1,000 educational concerts), the self-financing years demanded “four or five lecture-concerts a day” and constant touring. “An exhausting effort,” he stated, “yet we survived.”[^culture-and-contradiction-41] At the Târgu-Mureș National Theatre, director Iulius Moldovan similarly observed that during the 1986 season actors performed three to four shows daily, totaling approximately 3,200 activities each, to exceed revenue quotas and the planned audience target of 290,000 spectators. In Moldovan’s words, to match “this generous ambition, the theater is for an actor a permanent condition, a second life lived in multiple roles.”[^culture-and-contradiction-42] Yet in addition to mere personal dedication, such recollections point to a systemic reliance on intensified labor: cultural production was sustained not through abundant resources, as authorities often lamented, but through the stretching of artistic work to meet revenue and output demands.

<!-- culture-and-contradiction-042 -->

〔原刊 p. 14〕

Beyond individualized experiences, cultural life in general was transformed into a race for revenue. As public subsidies declined and audience purchasing power remained arguably limited, institutions were drawn into new forms of resource competition: not a market competition among private actors but a struggle for financial viability within a socialist economy of scarcity. As Ungureanu later recalled, “We competed—Costin, Dincă, and I—over who among us directors could secure the largest contributions.”[^culture-and-contradiction-43] What emerges is less a shift away from artistic excellence than a reconfiguration of institutional success, a struggle to maintain entrepreneurial stamina by demonstrating cultural production’s capacity to generate income in conditions of austerity. Freed from managerial duties, Ungureanu seemed relieved, since he could finally go back to music conducting and “minding [his] own business.”[^culture-and-contradiction-44]

<!-- culture-and-contradiction-043 -->

〔原刊 p. 14〕

The reorganization of work relations often spilled beyond institutional boundaries into everyday life. Under the austere climate of late socialism, individuals were encouraged to adopt forms of economic self-reliance not only within their workplaces—factories, offices, or cultural institutions—but also in domestic and community settings, where resourcefulness and network-building became practical necessities.[^culture-and-contradiction-45] With an emphasis on social responsibility and local resource mobilization (*autogospodărire*), households gradually came to be imagined and managed as miniature enterprises.[^culture-and-contradiction-46] In this sense, practices associated with entrepreneurship under austerity can be read as a prelude to a longer, uneven entanglement of socialist governance with emergent market-oriented rationalities. Informal revenue-generating strategies, like charging for unofficial VHS screenings or bartering cultural goods for scarce consumer items,[^culture-and-contradiction-47] illustrate how micro-level practices of economic improvisation permeated everyday cultural life prior to the formal consolidation of market institutions.

<!-- culture-and-contradiction-044 -->

〔原刊 p. 14〕

The rise of such practices also points to a deeper complexity, namely that the competencies associated with entrepreneurial conduct—and the language of enterprise—were neither fully cultivated nor formally legitimized as a normative ideal after four decades of socialism. Rather, the socialist system simultaneously constrained and enabled forms of economic improvisation that developed in tension with its ideological rejection of the market. As Martha Lampland has shown in her analysis of the commodification of labor in rural Hungary, late-socialist economies were organized around a structural tension that is often misread as ideological inconsistency but is better understood as constrained economic rationality: while villagers strongly endorsed socialist guarantees such as full employment, healthcare, and pensions, everyday life was organized around highly individualized strategies of economistic calculation and a sharp distinction between public provision and private survival. What appears as “capitalism-like” behavior—bootstrapping, utilitarianism, opportunistic exchange—was thus not external to socialism but generated within its institutional constraints, where scarcity and entitlement co-produced forms of market-oriented reasoning.[^culture-and-contradiction-48] Katherine Verdery has further demonstrated that chronic shortages intensified these dynamics by pushing individuals toward an informal “second economy,” which—although not unique to socialism—meant that goods and services were secured through a vast repertoire of quasi-legal practices.[^culture-and-contradiction-49]

<!-- culture-and-contradiction-045 -->

〔原刊 p. 15〕

Elsewhere I have shown that such strategies extended deeply into the cultural field, where musicians often engaged in informal, sometimes illicit, practices while touring abroad. Members of the rock band *Romanticii* were charged with shoplifting in West Germany, Gheorghe Zamfir (later known for his contribution to the *Kill Bill* soundtrack) sold music to West German porn producers, and musicians from *Sfinx* smuggled foreign currency in amplifiers and car parts while using fictitious Danish contracts to extend tours and evade taxation back home.[^culture-and-contradiction-50] Documented by the *Securitate* as moral deviance or anti-socialist behavior, these activities can be understood as situated strategies to compensate for domestic material scarcities and state management inefficiencies. From this perspective, the entrepreneurial repertoires of the 1980s did not emerge *ex nihilo* but drew on preexisting, informal economies of adaptation, as previously clandestine practices were progressively absorbed into officially sanctioned forms of economic self-legitimation.

<!-- culture-and-contradiction-046 -->

〔原刊 p. 15〕

Amid contradictions and entanglements, not all cultural actors navigated this balancing act successfully. The archive, although never exhaustive, captures the uneven effects of institutional demands and preserves vivid evidence of failures as much as of successes. Several years before making his “first million,” Mihai Rață had drawn a sharp reprimand from socialist authorities for his passivity.[^culture-and-contradiction-51] By 1987, he had evidently mastered the managerial craft, but at the decade’s outset, the same cultural institution he supervised stood at a precarious crossroads, struggling to meet the new demands. Five years earlier, open-house initiatives were held monthly rather than the recommended weekly, and authorities observed that “attempts at meaningful collaboration with enterprise-level trade unions remained tentative, and beyond the routine *discotecă* nights, few initiatives had emerged.”[^culture-and-contradiction-52] What happened subsequently was an arc embodying a socialist success story in entrepreneurialism. Nevertheless, if in Rață’s case public criticism appeared to act as a motivating force, in other instances, directors of underperforming institutions were required to undertake further staff development via retraining programs, which linked the expectations of meeting self-financing quotas directly to managerial capacity building.

<!-- culture-and-contradiction-047 -->

〔原刊 p. 16〕

The following subsection examines the role of training programs in late socialism, showing how they sought to compensate for the absence of market-oriented skills and cultivate the performance-driven dispositions demanded by the self-financing regime.

<!-- culture-and-contradiction-048 -->

〔原刊 p. 16〕

## From Apparatchik to Cultural Manager: Training Market-Oriented Conduct in Socialism

<!-- culture-and-contradiction-049 -->

〔原刊 p. 16〕

In a 1988 interview in *Scînteia*, Zenovia Niculescu—trainer of cultural directors and head of a cadre training center in Bucharest—signaled a consequential shift in cultural administration under the self-financing regime. The role of directors was being redefined through a “rational combination of professional knowledge with research and practice,” while new management methodologies oriented toward “economic-financial realization” were introduced alongside standard political-ideological guidance.[^culture-and-contradiction-53] Yet this managerial retraining revealed a looming paradox: it sought to produce self-optimizing economic actors while simultaneously reaffirming their status as socialist functionaries bound by political-ideological loyalty. From this ambivalent process of reskilling emerged a hybrid figure that combined socialist rationalization with resource-driven technocratic logics and embodied a role previously absent from the socialist institutional landscape: the cultural manager.

<!-- culture-and-contradiction-050 -->

〔原刊 p. 16〕

The imperative to “perfect” personnel ran as a red thread through documents of the late-socialist era and framed workforce improvement as central to social and professional mobility. The 13th Congress’s five-year plan (1986–1990) introduced directives for retraining and upskilling the national workforce, while projecting labor reorientations up to the year 2000. Targeting roughly three million people annually, the new statute emphasized renewing professional knowledge, acquiring additional qualifications to offset obsolescence, and mastering new methods in “scientific organization and the management of production.”[^culture-and-contradiction-54] Building on these expansive retraining initiatives, Ceaușescu called for cadre “multi-development”—the fusion of technical-organizational competence with politico-ideological formation—reiterating the socialist ideal of the multilaterally developed individual.[^culture-and-contradiction-55] In practice, this principle recast ideological dedication as insufficient without managerial efficiency. The need for hybridity was thus articulated from the highest party echelons. The “good activist” was both competent manager and ideological caretaker. Within this framework, the traditional cultural director—once primarily oriented toward artistic and curatorial judgment—saw their authority displaced; they risked being supplanted by a managerial type whose legitimacy was derived from the ability to balance artistic authority and ideological compliance with financial performance and self-sufficiency.

<!-- culture-and-contradiction-051 -->

〔原刊 p. 17〕

To cultivate these dispositions, new regional training centers were established which, beyond artistic pedagogy and craft improvement, placed growing emphasis on economic and managerial literacy.[^culture-and-contradiction-56] Niculescu described how the center under her coordination systematically adjusted its curricula to align cultural training with new political and economic imperatives, seeing these shifting aptitudes as “indispensable to the future.”[^culture-and-contradiction-57] Her training model centered on the figure of the cultural administrator *angajat în actualitate* (“attuned to the current state of affairs”), qualified to identify economic potential and manage resources efficiently through what she called *gîndire economică* (“economic thinking”) intended to produce “positive effects in the optimization of cultural activity” in a “continuous state of learning.”[^culture-and-contradiction-58]

<!-- culture-and-contradiction-052 -->

〔原刊 p. 17〕

Training centers also oversaw the examination and certification of “freelance artists” (*liberi profesioniști*),[^culture-and-contradiction-59] organized courses for amateur artists willing to improve their craftsmanship,[^culture-and-contradiction-60] and offered intensive crash courses to performers who showed promise at renowned pop music festivals like *Mamaia* (from diction to general music theory, and makeup to costume design).[^culture-and-contradiction-61] In live performance specialization, for instance, participants in the 1986 *Estival* program were not only immersed in rehearsals and artistic mentoring but trained in metrics of efficiency and audience research.[^culture-and-contradiction-62] Across these training settings, artistic and ideological formation became increasingly subordinated to the logic of organizational performance, with economic and managerial competencies central to this reconfiguration. As a result, two “Ps”—“perfecting” (*perfecționare*) and “polyvalence” (*polivalență*)—became defining idioms of cultural labor in the 1980s that echoed the socialist ideal of “multiskilling” (*policalificare*) but now reoriented toward resourcefulness and self-management.

<!-- culture-and-contradiction-053 -->

〔原刊 p. 17〕

Although training initiatives are generally celebrated in the archives (especially for their role in “educating the educators”), some trainees critiqued their centralized design and limited applicability.[^culture-and-contradiction-63] Ilarie Curechianu, instructor of artistic brigades in Suceava, noted that irregular scheduling and brief sessions left little room to experiment with new methods. Similarly, Gheorghe Pițu, instructor of artistic ensembles, criticized the absence of practical templates and called for hands-on engagement with repertoires rather than purely theoretical lessons. Such critiques underscore the tension between centralized planning and local realities, but they also point to a methodological insight: media archives, often dismissed as instruments of propaganda, preserve glimpses of site-specific expressions of discontent that are otherwise underregistered in the historical record.

<!-- culture-and-contradiction-054 -->

〔原刊 p. 18〕

Other sources echo this broader dissatisfaction and indicate a persistent misalignment between workforce training and the needs of production. One report is particularly scathing: programs, described as “superficial and formalistic,” failed to develop personnel skills and simultaneously reinforced inefficiency and limited adaptability. Training practices reflected a “broader lack of accountability,” being “minor in scope by design, existing only on paper, or limited to brief meetings between a few employees and their section chief at the end of a shift, merely to communicate tasks for the following day.”[^culture-and-contradiction-64] The report linked shortcomings in training to persistent quota failures, high defective output, diminished efficiency, and a reduced capacity to adapt to the rapidly changing demands of the national economy.

<!-- culture-and-contradiction-055 -->

〔原刊 p. 18〕

To curb these weaknesses and align institutional behavior with economic objectives, “methodological manuals” (*îndrumare metodologice*) were introduced. Far from mere bureaucratic formalities, the manuals were designed to familiarize cultural directors with self-financing principles and translate daily operations into the language of economic rationality through step-by-step guidance. An early example of this managerial turn is Iovănescu’s volume *The Management of Cultural-Artistic Units*, which framed economic rationality not as an antithesis to creativity but as a necessary condition for it. By extending the language of rationalization across theaters, publishing houses, and museums, the manual embedded self-financing within the cultural field and effectively cast managerial competence as “the rational use of funds” and efficiency as the basis for producing “authentic values.”[^culture-and-contradiction-65]

<!-- culture-and-contradiction-056 -->

〔原刊 p. 18〕

Aimed at instructing institutions in meeting these requirements, another methodological manual defined the late-socialist cultural director as a paradigmatically polyvalent figure: at once scientific manager, public mobilizer, strategic planner, administrator, and pedagogue responsible for ideological alignment, staff coordination, and financial oversight.[^culture-and-contradiction-66] Niculescu herself co-authored a practical manual based on directors’ training reports, which codified “scientific management” principles for cultural leadership: from strategic planning and audience research to self-financing optimization and collective organization.[^culture-and-contradiction-67] Such manuals illustrate the technocratic reconfiguration of cultural labor under late socialism, where managerial competence became inseparable from, and increasingly defined through, economic performance.

<!-- culture-and-contradiction-057 -->

〔原刊 p. 18〕

To clarify the relationship of this emerging school of cultural management to market-oriented frameworks, it is useful to distinguish between intent, content, and practice. These reskilling efforts did not explicitly adopt neoliberal corporate models, nor were they designed as such; rather, they emerged within a state-directed and ideologically framed system oriented toward austerity management and administrative efficiency. Yet in practice they cultivated forms of reasoning and conduct that resonate with later managerial and performance-based logics. For instance, while the regime’s emphasis on “perfecting” could be understood in emancipatory terms—as part of the project of forming the “new socialist human” through self-improvement—it also produced a strong emphasis on self-optimization, as well as institutional accountability, that anticipated elements of governance later associated with post-socialist transformations, including individualized responsibility through efficiency-oriented forms of evaluation. This duality resonates with analyses of neoliberal subject formation, in which the individual becomes both manager and managed and internalizes efficiency imperatives as personal obligations.[^culture-and-contradiction-68] In this sense, socialist “perfectioning” operated simultaneously as a politically sanctioned moral project and as a mode of self-disciplining that foreshadowed post-socialist forms of entrepreneurial subjectivity.

<!-- culture-and-contradiction-058 -->

〔原刊 p. 19〕

Finally, this unconventional retraining transformed the role of the socialist cultural director into that of a cultural manager: a figure expected to mobilize scarce resources and reconcile fiscal discipline with ideological expectations. Evidence of this shift lies in the contingent, market-responsive labor regimes of institutions, as well as in the proliferation of managerial training programs and methodological manuals that attuned cadres to administrative efficiency and economic competence. Yet these measures of self-improvement were tightly bound to an expanding apparatus of bureaucratic oversight, which reveals how the self-financing regime depended on, and intensified, practices of (self-)documentation. Institutions were required to act entrepreneurially as well as to continuously record and demonstrate this entrepreneurial conduct before authorities.

<!-- culture-and-contradiction-059 -->

〔原刊 p. 19〕

As the next section shows, the outcome did not herald a retreat of the state, as decentralization promised on paper, but a fragmented reconfiguration of its presence.

<!-- culture-and-contradiction-060 -->

〔原刊 p. 19〕

## Decentralization without Autonomy: Tracing the Paper Trail and Keeping Institutions Accountable

<!-- culture-and-contradiction-061 -->

〔原刊 p. 19〕

In early 1988, authorities reporting their visit to the cultural center of Daia Română, a small village in Alba County, found themselves unable to carry out a proper evaluation: “there is no documentation of meeting schedules; there are no minutes of the meetings held, no records of analyses, or of any exchange of views.”[^culture-and-contradiction-69] Although two of the center’s nine committee members declared “permanent support” for the cultural agenda, the absence of consistent administrative records undermined these claims, which led inspectors to deem them unsubstantiated. The authorities, in turn, tied these administrative shortcomings to the center’s subpar artistic output and economic performance: they cited “modest achievements” in the *Cîntarea României* national festival, a series of “formalistic” events, and an unfulfilled self-financing plan. Much to their disappointment, between 1 December 1987 and 17 January 1988, with the exception of weddings (*nunți cu dar*), no artistic performances had been held.[^culture-and-contradiction-70]

<!-- culture-and-contradiction-062 -->

〔原刊 p. 20〕

If, at first glance, Daia Română’s failure appears administrative, presented as a standard case of mismanagement in a peripheral village, it exposes a deeper paradox of late socialism. What was framed as a step toward institutional autonomy soon revealed itself as a deepening of bureaucratic dependence. While decentralization was officially promoted as an empowering mechanism to grant cultural institutions greater freedom for managing resources and responding to local needs, this autonomy was both partial and conditional upon constant proof of compliance. A dense framework of mandatory reporting and periodic state inspections transformed the promise of decentralization into an audit regime. Instead of loosening control, the self-financing regime tightened the state’s grip through paperwork. Every local initiative aimed at meeting the expectations of self-financing had to be recorded and rendered legible to authorities.

<!-- culture-and-contradiction-063 -->

〔原刊 p. 20〕

In its new configuration, decentralization shifted oversight from central authorities to local and regional committees, both enabling and exposing failures, as in the case of Daia Română. Cultural institutions no longer reported directly to the center; their performance was instead assessed locally through a dispersed system of economic and ideological monitoring. Local popular councils were empowered to supervise institutional obligations and became the primary evaluators of reform implementation. In 1988, there were 2,989 such local councils nationally, comprising a total of 62,253 deputy members. Of these, nearly 44 percent were workers, technicians, teachers, doctors, and office employees, while 53 percent were peasants or rural laborers. More than 40 percent of the deputies were women.[^culture-and-contradiction-71]

<!-- culture-and-contradiction-064 -->

〔原刊 p. 20〕

In the same Alba County, for example, a fifty-nine-member cultural committee (comprising cultural activists, workers, and professional and amateur artists) was formed. As Ioan Sicoe, head of the county’s Committee for Culture and Socialist Education, noted, committee members were assigned to specific cultural establishments so that “on-site inspections would be carried out efficiently.”[^culture-and-contradiction-72] Methodological consultations were periodically organized, where members presented reports on their involvement in the institutions under their remit. If the stated aim was to “ensure active involvement and for the committee to function as a dynamic, democratic body, responsive to current demands,”[^culture-and-contradiction-73] the empowerment of local popular councils produced a twofold effect: it formally expanded participatory decision-making, yet in practice these mechanisms functioned as instruments of oversight, extending central authority through local intermediaries instead of merely redistributing power. Moreover, popular councils were entrusted with overseeing expenditures for socio-cultural activities, which, according to archival reports, accounted for a significant 51 percent of local budgets.[^culture-and-contradiction-74] This financial responsibility expanded their role in cultural administration, yet rather than representing an autonomous redistribution of power (and resources), it positioned local councils as key intermediaries through which centrally defined priorities were implemented and monitored.

<!-- culture-and-contradiction-065 -->

〔原刊 p. 20〕

Decentralization thus shifted risk and responsibility onto local bodies and, in doing so, exposed the limits of local organizational capacity. For instance, at the Tecuci House of Culture, an internal consultation (*consfătuire*) on the role of regional cultural houses was convened but, due to “superficial organization,” was attended by only a single participant—the host institution itself. Representatives from seven other regional institutions failed to appear, some invoking what inspecting authorities wryly noted as “the familiar excuse that the bus did not run that day.”[^culture-and-contradiction-75] The meeting ultimately failed to conclude with administrative deliberation but ended with a poetry recital by members of the local Calistrat Hogaș literary circle.

<!-- culture-and-contradiction-066 -->

〔原刊 p. 21〕

Beyond exposing such shortcomings, the retreat from socialism’s hallmark of centralized planning seemed to promise greater creative autonomy. Indeed, some degree of latitude did transpire, as cultural actors found the space to mobilize regional sponsorship networks, while archival traces point to a flourishing of genre experimentation, inter-institutional collaborations, and novel programming strategies across professional music institutions.[^culture-and-contradiction-76] This transformation was articulated through what celebrated writer Dumitru Radu Popescu called “demetropolization”—a “new culture” no longer anchored in a single privileged center but produced across a constellation of “local centers,” each capable of generating “culture” independently.[^culture-and-contradiction-77] Nevertheless, local autonomy remained carefully delimited by the same central authorities that authorized it. Rather than streamlining the notorious bureaucratic burdens for the managerial class or fostering creative freedom for practitioners, the self-financing regime distended nonessential administrative labor and intensified practices of (self-)monitoring.

<!-- culture-and-contradiction-067 -->

〔原刊 p. 21〕

Decentralization can thus be seen as a technology of socialist governance. It displaced responsibility downward, and it intensified participatory forms of self-monitoring and individual accountability, in a way that left local institutions with little choice but to document their own performance while remaining bound to central priorities anyway. This practice of self-monitoring became institutionalized as control no longer relied solely on episodic audits but was reinforced in everyday practice and through training programs. In 1988, for instance, one training center—led by the aforementioned Zenovia Niculescu—stressed the importance of (self-)reporting as a core competency of socialist cultural management.[^culture-and-contradiction-78] Cultural directors once again occupied a paradoxical subject position, yet this time power operated not only through external directives but through voluntary self-regulation, in which meeting targets and documenting their fulfillment became inseparable. Crucially, however, it was the continuous production of documentation—rendering such achievement verifiable and institutionally valid—that carried independent weight. In this sense, a regime of epistemic surveillance was not merely imposed from above but sustained through the routine production of reports and (self-)evaluations, which translated institutional life into an ongoing demonstration of economic and ideological alignment alike.

<!-- culture-and-contradiction-068 -->

〔原刊 p. 21〕

The Daia Română report elucidates something else on top of this. It concluded with the remark that this type of fiasco was not an isolated occurrence but indicative of systemic shortcomings in uneven local implementation and irregular oversight. In Sebeș, for instance, the director of the house of culture admitted that “the council does not meet as regularly as desired, but only when major actions are at stake,” adding that the issue would be addressed “in a future council meeting,” though without specifying when.[^culture-and-contradiction-79] Inspecting authorities noted such procedural approximation as a shortcoming in itself, alongside what they described as a tendency to work in a “sectarian” manner, with participation limited to only a few of the council’s seventeen members.

<!-- culture-and-contradiction-069 -->

〔原刊 p. 22〕

Deficiencies of this sort did not go unaddressed and set a circuit of disciplinary measures in motion. Authorities attributed them to broader weaknesses in the functioning of local popular councils, which, “lacking sufficient oversight from the party, have become merely formal structures.” As a remedy, inspectors recommended supplementary managerial training to correct ineffective leadership. They proposed that “successful practices developed at the County Committee for Culture and Socialist Education be extended to all cultural leadership councils across the county.”[^culture-and-contradiction-80] In addition to contradicting the implied autonomy of decentralization, such prescriptions reveal a cyclical dynamic in which organizational failures were framed as training deficits, which, in turn, justified further interventions and thereby reproduced the very managerial dependence and institutional fragility that reforms were meant to overcome.

<!-- culture-and-contradiction-070 -->

〔原刊 p. 22〕

Caught in this recursive bind—a self-iterative cycle of dependencies—cultural labor and the management of resources became inseparable from their own documentation. This conflation made the paper trail of financial targets as important as achieving them. Audits, reports, metrics, and formal planning procedures became integral to institutional practice rather than external checks upon it. More than simply instituting the principle of self-financing, the policies encoded a multilayered regime of performance accountability, in which excessive bureaucratization both reshaped and redistributed control, while inculcating accountability as an intrinsic feature of cultural administration. Bureaucratization thus ceased to be incidental to the self-financing regime and became its essence, with paperwork functioning as the abiding machinery of governance.

<!-- culture-and-contradiction-071 -->

〔原刊 p. 22〕

## Epilogue: From One Crisis to Another

<!-- culture-and-contradiction-072 -->

〔原刊 p. 22〕

What emerged in Romania’s cultural sector during the 1980s was neither the retreat of socialism nor the premature arrival of capitalism but a distinctive experiment in governing crisis. Introduced as a response to mounting external debt, the self-financing regime instituted novel forms of financial accountability, managerial retraining, and audit practices designed to render institutions responsible for their own economic viability and to contribute to the broader effort of stabilizing the national economy. While culture did not come to a standstill under these pressures (austerity reshaped creative practice rather than extinguishing it), the production of culture and the criteria that underpinned its legitimacy were nonetheless altered: revenue thresholds, productivity quotas, and audience figures served as revised measures of institutional success. Once translated into practice, however, these imperatives rarely operated coherently or uniformly. They were improvised and unevenly absorbed across institutions, and in doing so exposed the contradictions at the core of late-socialist governance.

<!-- culture-and-contradiction-073 -->

〔原刊 p. 23〕

Rather than a by-product of reform or evidence of systemic incoherence, contradiction functioned as the operative mechanism that made cultural governance workable in practice precisely by sustaining late socialism’s internal and external tensions: (1) institutions were expected to be economically self-sufficient while remaining embedded in socialist structures of redistribution; (2) cultural actors were compelled to act entrepreneurially within an ideological framework that formally disavowed profit and market competition; (3) managerial retraining sought to produce self-optimizing economic actors, yet did so within a system still grounded in political loyalty that kept actors accountable as socialist functionaries; and (4) decentralization promised greater autonomy, yet in practice it extended reporting obligations and intensified bureaucratic oversight, which made paperwork a condition of administrative survival.

<!-- culture-and-contradiction-074 -->

〔原刊 p. 23〕

Yet the very durability of these contradictions prompts a reconsideration of the terms through which they are understood. If the coexistence of late-socialist and proto-capitalist or quasi-market logics was, in some sense, a recurring feature of institutional life in the 1980s, can the “four paradoxes” identified here still be considered paradoxes? They are perhaps better conceived as “paradoxical normalcies,” or configurations in which contradiction becomes routinized as a stable condition of governance. Sociological analyses have shown how crises—whether pandemics, regime changes, or policy shifts—disrupt ordinary expectations and generate durable forms of adaptation in which instability itself becomes normalized, a condition increasingly described as characteristic of “post-normal times.”[^culture-and-contradiction-81] What appears as exception or breakdown operated instead as an enduring mode of coordination, in which governance was enacted through the very tensions it was presumed to resolve. Instead of providing temporary disruptions or solutions, these dynamics generated institutional practices that were concomitantly unstable and normalized. Alexei Yurchak describes this as the “hypernormalization” of late socialism, where contradictions between ideology and practice were not resolved but institutionalized. Actors continued to follow norms even when they no longer corresponded to lived reality and, consequently, produced a social order that was performatively stable yet structurally fragile.[^culture-and-contradiction-82]

<!-- culture-and-contradiction-075 -->

〔原刊 p. 23〕

Read more broadly, this observation opens onto wider theoretical and analytical questions about the implications of these findings. Comparatively, much scholarship on self-financing (often framed as “self-management” or “autogestion”) has focused on Hungarian or Yugoslav “market-socialism.” While these models are frequently celebrated as paradigms of worker emancipation and “third-way” politics,[^culture-and-contradiction-83] the Romanian case follows a markedly different path. Here, cultural institutions were charged with generating income and channeling earnings back into central and local coffers, thus wiring artistic labor into circuits of socialist austerity and economic redistribution. In the process, the conventional image of state socialism as an all-provident and paternalistic order begins to fracture, as state-artist relations shifted from assumptions of provision and entitlement toward ongoing negotiations over institutional survival. The Romanian experience thus challenges monolithic accounts of state socialism, since it shows that the same rhetoric of self-reliance could crystallize into divergent governance forms elsewhere: emancipatory in Yugoslavia’s self-management model, commodification-driven in Hungary’s “feasible socialism,”[^culture-and-contradiction-84] and, in Romania, galvanized by austerity and under intensified bureaucratic control.

<!-- culture-and-contradiction-076 -->

〔原刊 p. 24〕

This article also challenges binary readings of socialism and capitalism by showing how market-like rationalities—efficiency, decentralized responsibility, economic calculation, performance evaluation—were cultivated within a centrally planned system that formally repudiated the market. My findings show that market rationalities were already assembled within late-socialist governance itself, lending support to Katherine Verdery’s claim that “entrepreneurship [was] already present in embryo.”[^culture-and-contradiction-85] In comparative perspective, more explicit forms of market relations in Hungary revealed a “dual economy,” where centrally administered sectors coexisted with market-oriented initiatives. As Martha Lampland similarly argues for late-socialist Hungary, characteristics retrospectively identified as “capitalist”—individualism, utilitarianism, and economism—were not external to socialism but cultivated by it. The transition to capitalism, Lampland posits, was “significantly furthered by policies of the socialist state,” in which “the full commodification of labor, the final blossoming of commodity fetishism, was achieved by the policies and practices of Hungarian socialism.”[^culture-and-contradiction-86] While the Romanian case seemingly presents a similar story, it differs in that it deployed analogous techniques of governance yet never explicitly embraced the language of “market-socialism.” It is precisely this discursive tension between ideological repudiation and practical incorporation that makes Romania an especially productive empirical site for tracing how institutional change was envisioned from above and refracted in everyday practice.

<!-- culture-and-contradiction-077 -->

〔原刊 p. 24〕

With these insights in mind, this research also unsettles tidy narratives of rupture. As this article has shown, the seeds of market-oriented governance were sown within the very soil of Romanian socialist cultural administration, long before 1989. What we often describe as “neoliberalization” therefore did not emerge out of thin air in the 1990s and later but drew on repertoires already cultivated under late socialism. Seen from this vantage point, the socialist-to-capitalist transition appears less as a clean ideological break than a reconfiguration of preexisting logics, an ongoing process in which seemingly opposed logics were repurposed. This perspective challenges conventional frameworks of “transitology” and theories of “unsettled cultures” or “cultural lag,” and in doing so reveals the internal variegation and mutual entanglement of socialist-capitalist trajectories.[^culture-and-contradiction-87]

<!-- culture-and-contradiction-078 -->

〔原刊 p. 25〕

Under no circumstances should the entanglements at the center of this research be read as predetermined trajectories, as if the transition to capitalism was inevitable. The events of 1989, often retrospectively folded into narratives of transition, sit uneasily within teleological readings of change. Rather than a linear passage toward “the end of history,” late-socialist paradoxes reveal historically contingent processes in which economic rationalities and political strategies were actively made and remade in practice. In this sense, late socialism rehearsed (some of) the very logics that would later define post-socialist capitalism. My empirical material indicates that the architects of post-communist “transition economics” did not start from a *tabula rasa*. Instead, the expansion of the private sector in the 1990s was grounded in practices cultivated under the paradoxical governance of the 1980s, even if these practices were embedded in fundamentally different property regimes and institutional logics.[^culture-and-contradiction-88]

<!-- culture-and-contradiction-079 -->

〔原刊 p. 25〕

How cultural actors carried late-socialist dispositions into post-socialist capitalism is nevertheless less a question of linear continuity than of structural resonance: skills of improvisation and resource-seeking retained value after 1989, when the transition produced an even more exacerbated, contradiction-filled “Darwinist race” in which social differentiation deepened and inequality was more acutely reframed as individual responsibility.[^culture-and-contradiction-89] If neoliberal reforms drew not only on external pressures or Western models but also on dispositions formed under socialism, then a key analytical question concerns how these continuities were actively reproduced in practice. Although this line of inquiry lies beyond the scope of the present study, pursuing it would help clarify how capacities accumulated under late socialism enabled some actors to seize new opportunities while leaving others increasingly marginalized: what post-socialist society split into the transition’s proverbial winners and losers.

<!-- culture-and-contradiction-080 -->

〔原刊 p. 25〕

When read alongside recent debates in the sociology of crisis and social change, my findings underscore the importance of understanding large-scale transformations as relational and historically situated processes. In the late-socialist case, change unfolded amid intersecting crises of oil, energy, debt, and political legitimacy.[^culture-and-contradiction-90] Just as literary critic Costi Rogozanu places the aesthetics of Romanian postmodernism in the 1980s as inseparable from the oil crisis, the broader reorganization of cultural production must likewise be situated within this wider landscape of overlapping crises.[^culture-and-contradiction-91]

<!-- culture-and-contradiction-081 -->

〔原刊 p. 25〕

And crisis sits at the core of the four paradoxes, ultimately revealing how the self-financing regime was itself deeply entangled with it. Rather than a single external rupture, crisis both preceded the introduction of the self-financing regime (and, in part, precipitated it) and was reconfigured through its mechanisms, which at times temporarily contained it while at others generated new instabilities. This imbrication points to a mutually constitutive crisis formation, in which the self-financing regime both produced and was reproduced by the very economic and institutional logics it sought to manage. These dynamics operated in two directions at once: on the one hand, they made austerity governable; on the other, they helped generate the conditions under which the otherwise unimaginable collapse of socialism became thinkable. As Yurchak famously observed, “everything was forever, until it was no more,” thereby casting late socialism as at once “stagnating and immutable, fragile and vigorous, bleak and full of promise.”[^culture-and-contradiction-92]

<!-- culture-and-contradiction-082 -->

〔原刊 p. 26〕

Nevertheless, an important distinction deserves to be made. If Rogozanu argues that 1980s postmodern literature became “an ingenious solution for representation in times of austerity,”[^culture-and-contradiction-93] this research shows that transformations inside the late-socialist cultural field were not merely aesthetic or representational but profoundly material. To a similar end, scholars like Krisztina Fehérváry reveal that in late socialism “political subjectivities were shaped through daily experience with the state.”[^culture-and-contradiction-94] I extend this insight by arguing that cultural actors’ subjectivities were likewise formed through the daily, routinized experience of late-socialist austerity. In fact, their formation can be seen as a reaction to a broader political economy of scarcity in which administrators and artists navigated not just the self-financing regime but the austere rhythms of global capitalist turbulence.

<!-- culture-and-contradiction-083 -->

〔原刊 p. 26〕

Katherine Verdery’s analysis is once again useful here, particularly her insistence on deeper historicization. Her perspective highlights how socialism’s strategic reorganization was intricately entangled with global capitalism, which produced long-term and often unintended consequences. In this frame of reference, 1989 appears less as a point of rupture than as a node in a longer continuum of crisis management, whose pivotal fountainhead can be traced back to the late 1960s and early 1970s. This was “when global capitalism entered the cyclical crisis from which it is still struggling to extricate itself,”[^culture-and-contradiction-95] a structural upheaval whose effects reverberated across both socialist and capitalist forms of governance alike.

<!-- culture-and-contradiction-084 -->

〔原刊 p. 26〕

The article’s analytical strategy of reading institutional change through paradox helps highlight how states govern across ideological divides through similar logics of crisis management. Although the analysis does not address post-socialism directly, it traces the formation of a deeper capitalist genealogy, described as “a slow naturalization of free market culture,”[^culture-and-contradiction-96] and shows how techniques associated with neoliberal governance were already incubated within late socialism’s attempts to manage economic breakdown. In a somewhat ironic twist, Ceaușescu morphs into a kind of neoliberal austerity figure *avant la lettre*: his economic measures of the 1980s prefigured the crisis-management playbook of the 2000s more than they mirrored the Western neoliberalism of his own decade. Unlike Western neoliberal regimes of his time, such as Reagan’s United States, which combined deregulation with deficit-financed military and consumer expansion,[^culture-and-contradiction-97] Ceaușescu’s Romania saw salvation in radical contraction and pursued debt elimination at the direct expense of its own population. The drive to repay foreign debt through extreme austerity thus anticipated forms of fiscal restraint only later utilized in neoliberal crisis management.

<!-- culture-and-contradiction-085 -->

〔原刊 p. 27〕

In similar fashion, imperatives of accountability and efficiency once framed as socialist moral duties now operate as neoliberal techniques of governance. In contemporary capitalist cultural production, these norms persist as artistic and institutional value is routinely measured in terms of profitability and quantifiable outcomes. Ironically, the meanings we attach to these imperatives of success ripple and fracture across time and regimes. They reveal a fluid and contested terrain where governance, economy, and social life intersect. It is precisely in this oscillation of meaning across political and economic regimes that a lingering paradox once again unsettles the appearance of absolute schism: demands that the likes of Ungureanu once deemed “an absurdity” under late socialism have since become part of the normalized grammar of artistic and institutional success in contemporary cultural industries.

<!-- culture-and-contradiction-086 -->

〔原刊 p. 27〕

Neoliberal capitalism—or whatever contemporary mutant iteration currently operates under its name—has absorbed many of the technologies of governance it once claimed to supersede by rearticulating them in new regimes of value. Yet, as the late-socialist self-financing regime suggests, beyond entanglement and hybridity, and beyond shifting ideologies and institutional forms, there lies a more enduring condition: crisis itself. Less an episodic disruption than an enduring horizon of governance, crisis emerges as a remarkably persistent feature of everyday life, a continuous condition that individuals and institutions alike have to navigate across economic systems or shifting cultural regimes.

<!-- culture-and-contradiction-087 -->

〔原刊 p. 27〕

## Acknowledgements

<!-- culture-and-contradiction-088 -->

〔原刊 p. 27〕

I am grateful to Pauwke Berkers, Kristina Kolbe, Julian Schaap, Florin Poenaru, and Neal Gruer for their thoughtful comments on earlier versions of this manuscript, to Jatin Dua, editor of *Comparative Studies in Society and History*, and Lauren Kapsalakis, managing editor, for their valuable support throughout the editorial process, as well as to the anonymous reviewers for their generous feedback and suggestions.

<!-- culture-and-contradiction-089 -->

〔原刊 p. 27〕

## Funding statement

<!-- culture-and-contradiction-090 -->

〔原刊 p. 27〕

Open access funding provided by Erasmus University Rotterdam.

## 原注 / Original notes

[^culture-and-contradiction-1]: ANIC, Fond CC al PCR, Secția Cancelarie, dosar 1/1979, f. 21 (verso).

[^culture-and-contradiction-2]: Timmermans, Stefan and Tavory, Iddo, “Theory Construction in Qualitative Research: From Grounded Theory to Abductive Analysis,” Sociological Theory 30, 3 (2012): 167–86 DOI: 10.1177/0735275112457914.

[^culture-and-contradiction-3]: Although archival records describe this shift as a revised “economic-financial mechanism,” I refer to it here as the “self-financing regime.” The term captures three interlinked dimensions. First, it marks a new expectation that culture should sustain itself: institutions were required to internalize economic logics, meet income targets, and generate their own revenues. Second, the prefix self- (or *auto*-) signaled a turn toward personal responsibility, a form of accountability resonant with logics later associated with neoliberal responsibilization. Third, calling it a *regime* underscores that this was not a minor technical adjustment but a structured system of governance. Romanian reform discourse in the 1980s framed this system through the triptych *autoconducere*—*autogestiune*—*autofinanțare* (sometimes extended to include *autogospodărire*), a paradigm centered on autonomous self-management, institutional responsibility, financial self-sufficiency, and local resource mobilization.

[^culture-and-contradiction-4]: Although the “end of history” debate has been demystified and revisited by Fukuyama himself, the term continues to shape interpretations of socialism’s collapse, often naturalizing linear transitions and glossing over the contradictions of late socialism and the nonlinear, site-specific dynamics of post-socialist change. Fukuyama, Francis, “Reflections on the End of History, Five Years Later,” History and Theory 34, 2 (1995): 27–43 10.2307/2505433.

[^culture-and-contradiction-5]: For an extensive discussion of the oppositional categories that dominate post-socialist scholarship, see Yurchak, Alexei, Everything Was Forever, Until It Was No More: The Last Soviet Generation (Princeton University Press, 2005), esp. 4–8 . For examples of studies that focus on dissent, censorship, propaganda, see Dobrenko, Aleksandr, Political Economy of Socialist Realism (New Haven: Yale University Press, 2005); Falk, BJ, “Resistance and Dissent in Central and Eastern Europe: An Emerging Historiography,” East European Politics and Societies 25, 1 (2011): 1–27 10.1177/0888325410388408.

[^culture-and-contradiction-6]: Kornai, János, The Socialist System: The Political Economy of Communism (Princeton University Press, 1992); Lampland, Martha, The Object of Labor: Commodification in Socialist Hungary (University of Chicago Press, 1995); Vedery, Katherine, What Was Socialism, and What Comes Next? (Princeton University Press, 1996).

[^culture-and-contradiction-7]: Stoler, Ann Laura, Along the Archival Grain: Epistemic Anxieties and Colonial Common Sense (Princeton University Press, 2009); Skarpelis, AKM, “Life on File: Archival Epistemology and Theory,” Qualitative Sociology 43 (2020): 385–405 10.1007/s11133-020-09460-1.

[^culture-and-contradiction-8]: Following Yurchak’s account of late socialism, I too draw on both “contemporaneous” and “retrospective” materials. Contemporaneous sources (produced during late socialism) capture practices and tensions as they unfolded, while retrospective accounts (mainly from the first decade of post-socialism) reflect how individuals and institutions narrativize those same experiences *post factum.* Juxtaposing the two offers a unique vantage point into the gap between lived practice and later recollection. For his discussion, see Yurchak, *Everything Was Forever*, 29.

[^culture-and-contradiction-9]: Turbatu, Romulus, “M-am cam risipit, interviul nostru cu dirijorul și compozitorul Constantin Ungureanu,” Cuvîntul Libertății, 26 Nov. 1998, 3.

[^culture-and-contradiction-10]: “Legea nr. 1 din 15 noiembrie 1985 privind autoconducerea, autogestiunea economico-financiară și autofinanțarea unităților administrativ-teritoriale, emisă de Marea Adunare Națională,” *Buletinul Oficial*, nr. 62, 18 Nov. 1985, 1–8.

[^culture-and-contradiction-11]: Valentin Petculescu, “Panoramic XX—recital,” *Luceafărul*, 11 April 1990, 14.

[^culture-and-contradiction-12]: Fast-forward to April 1989, when Ceaușescu announced the complete liquidation of Romania’s external debt, hailed as a civilizational triumph that secured independence (“economic, political, and of thought”) from the IMF and the capitalist West. Ștefan Buzărnescu, “Convorbiri cu Dumitru Ghișe,” *Revista Orizont*, 10 November 1989, 3. Archival sources reinforced this exceptionalist narrative, contrasting Romania’s repayment of $21 billion (over $7 billion in interest) between 1975 and 1989 with the “fabulously high” $1,320 billion still owed by other countries. These documents do two things at once: record economic facts and perform the state’s preferred storyline: Romania succeeded where others failed because it found a way out. That “way out”—collective sacrifice coupled with economic rationalization through the self-financing regime—was presented as the foundation of a sovereigntist national teleology. Bojan, Ioan, “Independența economică și politică a României,” Revista Steaua, 1 May 1989, 1.

[^culture-and-contradiction-13]: “Cuvîntarea tovarășului Nicolae Ceaușescu la Congresul al III-lea al consiliilor populare,” *România Liberă*, 11 Sept. 1985, 2.

[^culture-and-contradiction-14]: Iovănescu, Teodor, “Autoconducerea şi autogestiunea, căi fertile pentru optimizarea socială a activităţii cultural-educative,” Contemporanul, 16 Jan. 1981, 3.

[^culture-and-contradiction-15]: “Legea Bugetului de stat al Republicii Socialiste România pe anul 1984,” *Buletinul Oficial*, 24 Dec. 1983, 18.

[^culture-and-contradiction-16]: “Legea Bugetului de stat al Republicii Socialiste România pe anul 1986,” *Buletinul Oficial*, 20 Dec. 1985, 15; ANIC, Fond CC al PCR, Secția Economică, dosar 46/1985, ff. 1–8.

[^culture-and-contradiction-17]: In a *Scînteia* address, Finance Minister Petre Gigea cast culture as both an economic asset and an instrument for legitimating austerity. Cultural institutions were expected to cultivate a “spirit of economy, prudence, restraint,” while educational initiatives promoted moderation and self-discipline. Reframing this ethos as “economizing in the interest of all and for the benefit of each,” Gigea highlighted national campaigns such as “The Week of Economic Prudence” and “The Day of the Economical Student,” which aimed to instill frugality as both personal duty and collective good. In the context of (inter)national austerity, scarcity itself was recast as civic virtue. Gigea, Petre, “Spiritul de economie, în folosul fiecăruia, în interesul general,” Scînteia, 25 Oct. 1985, 5.

[^culture-and-contradiction-18]: Popovici, Iulia, Actorul ca Minerul. Ratările Tranziției în Teatru (Editura Universității Lucian Blaga, 2024), 78.

[^culture-and-contradiction-19]: Nevertheless, the regime presented itself as fundamentally humanist, emphasizing its commitment to cultural spending; archival records note that “socio-cultural subsidies had increased twenty-onefold between 1950 and 1980.” “Cultura—un bun al fiecăruia dintre noi,” *Scînteia Tineretului*, 22 Aug. 1981, 4.

[^culture-and-contradiction-20]: Iovănescu, “Autoconducerea și autogestiunea,” 6.

[^culture-and-contradiction-21]: “Cuvântarea tovarășului Nicolae Ceaușescu la Şedinţa plenară lărgită a Consiliului Naţional al Oamenilor Muncii,” *Scînteia Tineretului*, 14 June 1980, 2.

[^culture-and-contradiction-22]: Legislation of this nature began with the notorious *July Theses* (1971) that ended the ideological thaw of the 1960s, a series of decrees and laws in the 1970s—*Decree 703* (1973, 1977); *Decree 150* (1975); *Law nr. 5* (1978)—before intensifying in the 1980s with the *Mangalia Theses* (1982), *Resolution 4 of the Great National Assembly* (1983), and, ultimately, *Law nr. 1* (1985).

[^culture-and-contradiction-23]: ANIC, Fond CC al PCR, Secția Propagandă și agitație, dosar 72/1987, f. 4; ANIC, Fond CC al PCR, Secția Cancelarie, dosar 6/1989, f. 4; Suciu, Gheorghe, “Cultură și eficiență,” Familia, 1 Februarie 1981, 5.

[^culture-and-contradiction-24]: Iuga, Cornel, “Perfecţionarea mecanismului economico-financiar,” Era Socialistă, January 10, 1987, 24–26 ; Pîrvu, Mihai, “Bugetele locale, instrument principal al autofinanțărilor administrativ-teritoriale,” Revista Economică, 22 March 1985, 15 ; Rădulescu, Șerban, “Autofinanțarea și autogestiunea casei de cultură,” Cîntarea României no. 3, 1 Mar. 1986, 18;

[^culture-and-contradiction-25]: Iovănescu, “Autoconducerea și autogestiunea,” 6.

[^culture-and-contradiction-26]: Iovănescu, “Autoconducerea și autogestiunea,” 3.

[^culture-and-contradiction-27]: ANIC, Fond CC al PCR, Secția Propagandă și Agitație, dosar 72/1987, f. 5.

[^culture-and-contradiction-28]: ANIC, Fond CC al PCR, Secția Cancelarie, dosar 61/1984, f. 114 (verso). Official statistics produced under late socialism require caution, as the inflation or strategic presentation of figures was a well-documented practice. Here, however, I treat these numbers less as transparent measures of activity than as indicators of the evaluative categories through which institutions were governed.

[^culture-and-contradiction-29]: ANIC, Fond CC al PCR, Secția Propagandă și Agitație, dosar 50/1987, f. 5.

[^culture-and-contradiction-30]: Tudor Octavian, “Ceva ce nu trebuia să se întâmple,” *Flacăra* no. 13, 1 Apr. 1983, 15.

[^culture-and-contradiction-31]: Octavian, “Ceva ce nu trebuia să se întâmple,” 15.

[^culture-and-contradiction-32]: Turbatu, “M-am cam risipit,” 3. For a more detailed discussion of how cultural institutions organized pirated VHS screenings, see Pârvulescu, Constantin and Copilaș, Emanuel, “Hollywood Peeks: The Rise and Fall of Videotheques in 1980s Romania,” East European Politics and Societies 27, 2 (2012): 241–259 10.1177/0888325412467054.

[^culture-and-contradiction-33]: Rădulescu, “Autofinațarea și autogestiunea casei de cultură,” 18.

[^culture-and-contradiction-34]: Cuibuș, Marta, “Azi, casa de cultură vă aparține!,” Scînteia, 7 Mar. 1987, 4.

[^culture-and-contradiction-35]: Mitroi, Gheorghe, “Prin eforturi proprii—mijloacele necesare pentru dezvoltarea propriei localități,” Scînteia, 29 May 1984, 2.

[^culture-and-contradiction-36]: Rădulescu, “Autofinațarea și autogestiunea,” 18.

[^culture-and-contradiction-37]: Cuibuș, “Azi, casa de cultură vă aparține!,” 4.

[^culture-and-contradiction-38]: Mitroi, “Prin eforturi proprii,” 2.

[^culture-and-contradiction-39]: Nicola, Ion, “Unitatea indisolubilă dintre politica economică și politica socială,” Era Socialistă, 10 Oct. 1989, 11.

[^culture-and-contradiction-40]: Turbatu, “M-am cam risipit,” 3.

[^culture-and-contradiction-41]: Dumitrescu, Virgil, “Pagină-interviu cu maestrul de cor Alexandru Racu,” Cuvîntul Libertății, 19 Jan. 1999, 3.

[^culture-and-contradiction-42]: Mureșan, Doru, “Teatrul—ca act de creație și angajare,” Steaua Roșie, 10 Jan. 1987, 3.

[^culture-and-contradiction-43]: Ungureanu points to two other influential cultural figures in mid-1980s Craiova: Teodor Costin, director of the Oltenia Philharmonic (1962–1986), and Alexandru Dincă, director of the Craiova National Theatre (1974–1988). Turbatu, “M-am cam risipit,” 3.

[^culture-and-contradiction-44]: Turbatu, “M-am cam risipit,” 3.

[^culture-and-contradiction-45]: The subject of informal networks and social ties in socialism is particularly rich, revealing how actors navigated official hierarchies and resource shortages. On why “network capital” tends to be stronger under communism than capitalism, see Sik, Endre, “Network Capital in Capitalist, Communist, Post-Communist Societies,” International Contributions to Labour Studies 4 (1994): 73–93.

[^culture-and-contradiction-46]: Under Law nr. 1 (1985), *autogospodărirea* required citizens to contribute annually—through labor or monetary payments—to local public-works projects, with levies scaled by household size. These mechanisms extended fiscal responsibility and embedded forms of everyday resource management into the sphere of social reproduction. *Buletinul Oficial*, nr. 71, 20 December 1985, 15; “Sarcini cetăţeneşti de mare importanță pentru înfrumusețarea şi mai buna gospodărire a municipiului,” *Flacăra Iașului*, 6 June 1986, 2.

[^culture-and-contradiction-47]: Fehérváry, Krisztina, “Goods and States: The Political Logic of State-Socialist Material Culture,” Comparative Studies in Society and History 51, 2 (2009): 455 10.1017/S0010417509000188.

[^culture-and-contradiction-48]: Lampland, *The Object of Labor*, 2.

[^culture-and-contradiction-49]: Vedery, *What Was Socialism*, 27.

[^culture-and-contradiction-50]: Mogoș, Petrică and Berkers, Pauwke, “Navigating the Margins between Consent and Dissent: Mechanisms of Creative Control and Rock Music in Late Socialist Romania,” East European Politics and Societies 32, 1 (2018): 56–77 10.1177/0888325417736807.

[^culture-and-contradiction-51]: Cuibuș, “Azi, casa de cultură vă aparține!,” 4; Parhon, Ion, “Dimensiunile timpului liber: Este casa de cultură a sindicatelor adevărat focar de îmbogățire a universului de cunoaștere a oamenilor muncii?,” Munca, 19 Mar. 1982, 6.

[^culture-and-contradiction-52]: Parhon, “Dimensiunile timpului liber,” 6.

[^culture-and-contradiction-53]: Oteanu, Smaranda, “Drumul spre competenţă al activistului cultural,” Scînteia, 24 Mar. 1988, 4.

[^culture-and-contradiction-54]: Luminosu, Doru S., “Noul statut cultural al oamenilor muncii,” Cîntarea României, 1 Mar. 1989, 30.

[^culture-and-contradiction-55]: Rădulescu, Șerban, “Un obiectiv de prim ordin: Optimizarea pregătirii și reciclării activului cultural,” Cîntarea României, 1 Jan. 1989, 44.

[^culture-and-contradiction-56]: In terms of curricula, theater directors and heads of music institutions could study “New Management Methodologies for Musical Institutions in the Context of Tasks and Requirements Related to Repertoire Policy and Economic-Financial Demands Imposed by the New Economic Mechanism of Self-Management and Self-Governance.” Museum curators and directors of cultural centers could undertake “Scientific Management and Organization of Cultural Personnel Activities in Light of the Requirements and Demands Promoted by the Party’s Programmatic Documents.” Oteanu, “Drumul spre competenţă al activistului cultural,” 4.

[^culture-and-contradiction-57]: Niculescu, Zenovia, “Cultură și competență,” Cîntarea României, 1 Aug. 1987, 12.

[^culture-and-contradiction-58]: Niculescu, Zenovia, “Dinamismul activităţii de perfecţionare,” Contemporanul, 8 Aug. 1986, 9.

[^culture-and-contradiction-59]: “Comisia centrală pentru atestarea calităţii de artist liber profesionist al C.C.E.S.,” *Cuvîntul Nou*, 13 Feb. 1986, 3.

[^culture-and-contradiction-60]: Oteanu, “Drumul spre competenţă al activistului cultural,” 4.

[^culture-and-contradiction-61]: Ursulescu, Octavian, “Avanpremieră: Mamaia ’86,” Contemporanul, 15 Aug. 1986, 12.

[^culture-and-contradiction-62]: Niculescu, “Dinamismul activităţii de perfecţionare,” 9.

[^culture-and-contradiction-63]: Costea, M., “Noi dimensiuni creatore activității cultural-educative, de formare a omului nou,” Scînteia, 21 Dec. 1988, 4.

[^culture-and-contradiction-64]: Militaru, Nicolae, “Perfecţionarea pregătirii profesionale,” Scînteia, 23 June 1989, 5.

[^culture-and-contradiction-65]: Iovănescu, Teodor, Gestiunea unităților cultural-artistice (Editura Științifică și Enciclopedică, 1980).

[^culture-and-contradiction-66]: Lupu, Ioana, “Recenzie: Îndrumar metodologic al directorului căminului cultural,” Cîntarea României, 1 June 1988, 33.

[^culture-and-contradiction-67]: Tăutu, Ioana, “Conducere și organizare,” Cîntarea României, 1 Sept. 1989, 39, 45.

[^culture-and-contradiction-68]: See O’Neill, Maggie, Spaces of Risk: Social Inequality and Neoliberal Government (Routledge, 2008); Rose, Nikolas, Powers of Freedom: Reframing Political Thought (Cambridge University Press, 1999) DOI: 10.1017/CBO9780511488856.

[^culture-and-contradiction-69]: Dinică, Ștefan, “Refrenul justificărilor n-are nicio justificare,” Scînteia, 24 Mar. 1988, 4.

[^culture-and-contradiction-70]: Dinică, “Refrenul justificărilor,” 4.

[^culture-and-contradiction-71]: Ceaușescu, Nicolae, “Cuvântarea tovarășului Nicolae Ceaușescu în cadrul celei de-a IV-a conferință pe țară a președinților consiliilor populare,” Scînteia, 4 Mar. 1988, 2.

[^culture-and-contradiction-72]: Dinică, “Refrenul justificărilor,” 4.

[^culture-and-contradiction-73]: Dinică, “Refrenul justificărilor,” 4.

[^culture-and-contradiction-74]: ANIC, Fond CC al PCR, Secția Economică, dosar 46/1985, f. 4 (verso).

[^culture-and-contradiction-75]: Plăeșu, Dan, “Casa de cultură—centru al activității politico-educative,” Scînteia, 17 February 1988, 4.

[^culture-and-contradiction-76]: The specific ways in which music institutions adapted their artistic output and programming strategies in response to these conditions of crisis fall beyond the scope of this article and are examined in a separate study: , Petrică Mogoș, et al., “Buffering Contradiction: How Competing Socialist and Market Logics Were Navigated in Romanian Classical Music,” Cultural Sociology (under review).

[^culture-and-contradiction-77]: Bârgău, Valeriu, “Sînt pentru demetropolizarea culturii: Interviu cu D. R. Popescu,” Astra, December 1, 1981, 9 ; Borțun, Dumitru, “Demetropolizarea culturii,” Astra, 1 Mar. 1982, 12.

[^culture-and-contradiction-78]: Oteanu, “Drumul spre competenţă al activistului cultural,” 4.

[^culture-and-contradiction-79]: Dinică, “Refrenul justificărilor,” 4.

[^culture-and-contradiction-80]: Dinică, “Refrenul justificărilor,” 4.

[^culture-and-contradiction-81]: Thorpe, Charles, Sociology in Post-Normal Times (New York: Lexington Books, 2022).

[^culture-and-contradiction-82]: Yurchak, *Everything was Forever*, 50–51.

[^culture-and-contradiction-83]: Štiks, Ivan and Horvat, Srećko, eds., Welcome to the Desert of Post-Socialism: Radical Politics After Yugoslavia (New York: Verso Books, 2015), esp. 21–65.

[^culture-and-contradiction-84]: In the case of Hungary’s market socialism, see Lampland, , *The Object of Labor*; Nigel Swain, *Hungary: The Rise and Fall of Feasible Socialism* (New York: Verso Books, 2002).

[^culture-and-contradiction-85]: Vedery, *What Was Socialism*, 27.

[^culture-and-contradiction-86]: Lampland, *The Object of Labor*, 5.

[^culture-and-contradiction-87]: Buden, Boris, “Children of Postcommunism,” Radical Philosophy 159 (2010): 18–25 ; Burawoy, Michael and Verdery, Katherine, Uncertain Transition: Ethnographies of Change in the Postsocialist World (New York: Bloomsbury Academic, 1999); Chari, Sharad and Verdery, Katherine, “Thinking Between the Posts: Postcolonialism, Postsocialism, and Ethnography After the Cold War,” Comparative Studies in Society and History 51, 1 (2009): 6–34 10.1017/S0010417509000024; Chelcea, Liviu, “Goodbye, Post-Socialism? Stranger Things Beyond the Global East,” Eurasian Geography and Economics 66, 7 (2025): 874–900 10.1080/15387216.2023.2236126.

[^culture-and-contradiction-88]: Bockman, Johanna and Eyal, Gil, “Eastern Europe as a Laboratory for Economic Knowledge: The Transnational Roots of Neoliberalism,” American Journal of Sociology 108, 2 (2002): 310–52 DOI: 10.1086/344411; Rona-Tas, Akos, “The First Shall Be Last? Entrepreneurship and Communist Cadres in the Transition from Socialism,” American Journal of Sociology 100, 1 (1994): 40–69 10.1086/230499.

[^culture-and-contradiction-89]: Poenaru, Florin, Locuri Comune (Tact, 2017): 9–10.

[^culture-and-contradiction-90]: Baghiu, Ștefan, “Anticolonial Protochronism and Self-Colonizing Postmodernism: Rethinking Cultural Strategies in Late Socialist Romania,” Studies in East European Thought (2025): 1–20 ; Ban, Cornel, “Sovereign Debt, Austerity, and Regime Change: The Case of Nicolae Ceausescu’s Romania,” East European Politics and Societies 26, 4 (2012): 743–76 DOI: 10.1177/0888325412465513.

[^culture-and-contradiction-91]: Rogozanu, Costi, “Postmodernismul Românesc s-a născut din Tezele din Iulie și din Crizele Petrolului,” Revista Transilvania 2 (2024): 1–7.

[^culture-and-contradiction-92]: Yurchak, *Everything was Forever*, 4.

[^culture-and-contradiction-93]: Rogozanu, “Postmodernismul Românesc,” 7.

[^culture-and-contradiction-94]: Fehérváry, “Goods and States,” 455.

[^culture-and-contradiction-95]: Verdery, *What Was Socialism*, 31.

[^culture-and-contradiction-96]: Bâlici, Mihnea, “Aspirational Postmodernism: The Slow Naturalization of the Free Market Culture in Late Socialist Romania,” Studies in Eastern European Thought 78 (2026): 577–95 DOI: 10.1007/s11212-025-09737-7.

[^culture-and-contradiction-97]: Bellofiore, Riccardo, Garibaldo, Francesco and Halevi, Joseph, “The Global Crisis and the Crisis of European Neomercantilism,” Socialist Register 47 (2011): 120–46.

## 编者说明 / Editorial notes

self-financing regime译为自筹经费体制；不译为自负盈亏，以免额外引入原文未必包含的亏损承担含义。entrepreneurial conduct译为企业家式行为，entrepreneurialism依语境译为企业家精神或企业经营。作者强调市场取向逻辑可在社会主义治理内部产生，并不据此认定资本主义转型不可避免。

autoconducere与autogestiune按原文英文释义分别译为自我管理、自我治理；autogestion在比较讨论中译为自治管理。epistemic surveillance译为知识层面的监视；abductive approach译为溯因方法。原文斜体、注号和段落结构保留，原刊页码指段落起始页；注释放在引用段落之后。

正文第18单元称文化预算下降47%，同时列出从11.6亿列伊降至7.352亿列伊。按所列金额计算降幅约36.6%，与47%不一致；本版保留原文数字，不代作者修正。正文第41单元关于每位演员约3,200项活动的表述亦按原文each保留，不改写为剧院总量。

原注6、49、85将Verdery写作Vedery；注24、33、36等处自筹经费一词存在拼写差异；注84有重复逗号，注76有多余标点。英文底本照录；中文只整理语句连接，不据外部资料替换作者、年份或页码。原注3与22等解释性内容均完整翻译。

原刊第27页的开放获取资助声明已补入。正文引用对官方产出统计的解释限制见注28：作者并不将数字视为透明、可靠的活动计量，而主要视为治理评价范畴的证据。本版保留这一限定。

罗马尼亚语书名、篇名及档案条目保留原始检索信息并附译释；译释不意味着存在正式中译本。档案叶码f./ff.和verso分别译释为叶及背面。HTML中粘连的DOI补加分隔符，不改DOI本身。
