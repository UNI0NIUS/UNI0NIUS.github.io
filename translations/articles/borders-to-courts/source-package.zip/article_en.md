# From borders to courts: assembling pushback cases in a hostile transnational setting

Alice Lacchei: Political and Social Sciences, University of Bologna, Bologna, Italy. Adel-Naim Reyhani: Ludwig Boltzmann Institute of Fundamental Human Rights, Vienna, Austria. Corresponding author: Alice Lacchei; alice.lacchei2@unibo.it. Law & Society Review (2026), 1–27. Received 29 October 2025 UTC; revised 26 March 2026 UTC; accepted 26 June 2026 UTC. Published online: 18 September 2026.

https://doi.org/10.1017/lsr.2026.10117

据 Cambridge University Press 出版方 HTML 全文翻译，并以同文原版 PDF 核对结构及段落起始页码。原文27页，保留摘要、全部正文、数据与资助声明、9项访谈清单、91条文献、7项判例、3项法规及两位作者简介。无编号脚注或图表。书目照录并附中文题名或条目译释。© The Author(s), 2026，Cambridge University Press 代表 Law and Society Association 出版；原文与本译文采用 CC BY 4.0。翻译、译释及编者说明为本版新增。AI辅助工作译稿，不代表作者或出版社认可。

CC BY 4.0: https://creativecommons.org/licenses/by/4.0/

Keywords: pushbacks; intermediaries; courts; refugees; justice

<!-- borders-to-courts-001 -->

〔原刊 p. 1〕

## Abstract

<!-- borders-to-courts-002 -->

〔原刊 p. 1〕

This article examines the work of legal intermediaries in moving cases from the border to the court, focusing on pushbacks from Italy and Austria to Slovenia and along the Balkan corridor. It demonstrates that these practices occurred within a hostile transnational setting that, from the outset, dispersed and destabilized potential claimants, traces, and the litigation path. Confronted with this immediate condition of misalignment, it shows that intermediaries engaged in constitutive and collaborative work across borders. The article conceptualizes this work as “case assembly” and analyzes it from a comparative perspective.

<!-- borders-to-courts-003 -->

〔原刊 p. 1〕

## Introduction

<!-- borders-to-courts-004 -->

〔原刊 p. 1〕

Court proceedings represent only the visible tip of the iceberg in legal disputes (Felstiner et al. 1981). Socio-legal scholarship has largely investigated the reasons why most potential litigants never reach the judicial stage, suggesting that it is necessary to investigate also what occurs before a problem becomes a court case, including particularly the political, cultural, and legal environment, as well as the actors involved (Olesen and Hammerslev 2023).

<!-- borders-to-courts-005 -->

〔原刊 p. 1〕

This issue is sharpened in the context of migration (Conant 2016) and becomes even more acute in cases related to access to asylum, in which judicial accountability is increasingly constrained, and courts can only address a very small fraction of harm (Costello and Mann 2020). Indeed, in contemporary migration governance, states across the globe are erecting diverse barriers to accessing their territories and asylum procedures (Lacchei and Moraru 2026) with a view to circumventing the law and avoiding accountability (Gammeltoft-hansen and Tan 2021; Moreno-lax 2024). For this purpose, they have expanded borders into fragmented, often intangible spaces (Tazzioli 2021), as illustrated by the phenomenon of shifting borders (Shachar 2020) and the rise of externalization policies, which manipulate state control in ways that can even produce rightlessness (Reyhani 2021).

<!-- borders-to-courts-006 -->

〔原刊 p. 2〕

Courts are one accountability venue among others to contest such practices. Moreover, even when legal action is chosen, actors do not always assume that the law will provide sufficient or sustained remedy (Costello and Mann 2020; Cummings 2020; Kawar 2015; Sterett 2016). Indeed, where courts intervene in the field of migration control, states may rework control practices and externalize them even further in ways producing a cat-and-mouse dynamic between the law and state adaptation (Lavenex 2022; Mann 2013).

<!-- borders-to-courts-007 -->

〔原刊 p. 2〕

From a socio-legal perspective, studying litigation over access to asylum is particularly valuable. Migration is a field in which courts and legal processes centrally govern inclusion and exclusion, even where formally guaranteed rights remain difficult to realize in practice (Sterett 2016). Access to courts in this field is further shaped by institutions, procedural routes, and unequal resources (Campbell 2020; Passalacqua 2022). This context can elucidate the intensity and complex or intricate nature of the work required to reach judicial institutions (Crooke 2024; Jacobs and Maryns 2022). Scholars note that, when migration cases occasionally do reach the courts, it is usually the result of efforts by a variety of actors, including lawyers, activists, and civil society organizations (Riva and Hoffstaedter 2021; Sterett 2016). They have referred to these actors in various terms. Here, we use the term legal intermediaries – i.e., those legal and nonlegal professionals who connect individuals with judicial institutions, seeking to move a concrete claim toward processing (Lejeune and Spire 2021).

<!-- borders-to-courts-008 -->

〔原刊 p. 2〕

Against this backdrop, we seek to advance understanding of the work of these intermediaries by studying a field marked by unusually adverse litigation conditions: pushbacks along the Balkan route. Understood as the forced removal of individuals from State territory without a prior assessment of risks or protection needs, pushbacks are by definition and from the start transnational. Moreover, along the Balkan route, they often come with cross-border chains based on informal police cooperation and readmission arrangements that undermine accountability and leverage legal opacity (Cantor et al. 2022; Casas-cortes et al. 2016; Moraru and Reyhani 2026). As a litigation setting, the field has moreover been characterized by opacity, weak traceability, and recurrent problems of evidentiary erasure (Alpes and Baranowska 2025; Baranowska et al. 2025). Finally, it has been shaped by the criminalization of migration and, at times, of solidarity itself (Trucco 2023).

<!-- borders-to-courts-009 -->

〔原刊 p. 2〕

Building on these insights, our study demonstrates that pushbacks are part of a hostile transnational setting that, from the very outset, disperses and destabilizes the basic components of cases, namely potential claimants, traces, and the litigation path. Confronted with this initial condition of *case misalignment*, it argues, intermediaries respond with constitutive and collaborative work across borders. We conceptualize this work as *case assembly* – i.e., the process of identifying, connecting, and stabilizing the elements of cases to advance their movement toward the court.

<!-- borders-to-courts-010 -->

〔原刊 p. 2〕

Our approach is comparative. We investigate cases of pushbacks litigated before domestic courts in Italy and Austria, each concerning pushbacks to Slovenia and often followed by onward removals further along the Balkan route. As elaborated in the “Case studies” “section, in both contexts, legal intermediaries had pursued strategic litigation that led courts to condemn the relevant practices. Moreover, while sharing the same transnational setting, the two countries relied on different practices and justifications and are characterized by distinct institutional and procedural configurations.

<!-- borders-to-courts-011 -->

〔原刊 p. 3〕

Scholarship has not yet engaged with this specific work of intermediaries. Nevertheless, our study can draw on existing work that already illuminates several parts of the terrain. In particular, research on legal intermediation in organizational and legal-administrative settings shows how intermediaries broker access, shape legal meaning, and route people through legal-administrative pathways (Bonizzoni and Odasso 2024; Pélisse 2019, 2019; Talesh 2015). Moreover, work on the dispute pyramid and the pre-dispute phase shows how recognized conflicts move, or fail to move, toward legal recourse and how intermediaries work in that progression (Lejeune and Spire 2021; Olesen and Hammerslev 2023). Work on immigration advocacy and asylum administration goes further by showing how narratives and evidentiary materials are translated so that they become records cognizable in the legal sphere (Cabot 2012; Coutin 2025; Coutin and Fortin 2023; Lakhani 2014; Pörtner 2021).

<!-- borders-to-courts-012 -->

〔原刊 p. 3〕

The article is structured as follows. “A hostile transnational setting” section explains the hostile transnational setting. “Legal intermediaries and their work” section conceptualizes the work of legal intermediaries and situates the article in the available literature. “Case studies” “Case studies”section introduces the case studies and their rationale. “Methods” section outlines the methodology, its scope, and limitations. “Empirical data” section presents empirical data on intermediaries’ work. Finally, before concluding, the “Discussion” section discusses the insights gained and their implications for understanding legal intermediation.

<!-- borders-to-courts-013 -->

〔原刊 p. 3〕

## A hostile transnational setting

<!-- borders-to-courts-014 -->

〔原刊 p. 3〕

Pushbacks are transnational by definition. They involve removal across an international border without access to asylum procedures or an individual assessment of protection needs (UN Special Rapporteur on the human rights of migrants 2021). At a minimum, a pushback links the state carrying out the removal and the state to which people are sent. In contemporary migration governance, the setting is often more extended. As border control becomes increasingly extraterritorial, the transnational scope of pushbacks expands accordingly. Externalization efforts, including informal cross-border police cooperation, are producing a chain of pushbacks along migratory routes (Giuffré 2020; Legomsky 2003). The Balkan route is a typical terrain for this phenomenon. Cooperation among states along the route has contributed to repeated onward removals across several states, as documented extensively by civil society and monitoring actors (Aulsebrook et al. 2021; Border Violence Monitoring Network 2024). In this setting, pushbacks are contested through refugee struggles, solidarity, monitoring networks, journalistic investigation, and diverse practices of documentation and counter-archiving, which seek to make border violence visible for multiple audiences and political purposes, only some of which later travel into litigation (Cantat 2020; Davies et al. 2023; El-shaarawi and Razsa 2019; Hameršak et al. 2020).

<!-- borders-to-courts-015 -->

〔原刊 p. 3〕

The litigation over pushbacks, as part of this wider ecosystem of contestation, is situated within a broader, hostile, and transnational environment. And, indeed, this setting has consequences for the legal and litigation dynamics at play.

<!-- borders-to-courts-016 -->

〔原刊 p. 4〕

Scholarship on externalization has shown how the encounter of people on the move with states is displaced, raising the question of whether legal obligations continue to travel with migration governance as control is outsourced beyond the territorial border (Gammeltoft-Hansen 2011). Accountability can become fractured across legal regimes and operational sites, making responsibility harder to map and harder to claim (Tan and Gammeltoft-Hansen 2020). Under more severe forms of externalization to disintegrating states, the law may at times become entirely unavailable or inapplicable (Reyhani 2021). Where courts intervene, states may rework control practices and externalize them even further in ways that preserve the appearance of compliance while weakening the practical force of legal constraint, producing a cat-and-mouse dynamic between legal judgment and state adaptation (Lavenex 2023; Mann 2013).

<!-- borders-to-courts-017 -->

〔原刊 p. 4〕

In litigation, the transnationality of pushbacks is also a practical concern for dispersal. In pushback cases, the claimant is immediately disconnected from the site of the event and the domestic judicial forum that could establish accountability. Similarly, the relevant event may stretch across several states, and traces or evidence may yet be located in another jurisdiction. What is more, violations have to be noticed, recorded, and pursued across border spaces marked by opacity, violence, and institutional informality (Fortarezza 2026; Hameršak et al. 2020). Finally, efforts are further complicated by the criminalization of migration and, at times, of solidarity itself, limiting access to people on the move and raising the costs of monitoring, documentation, and support (Kogovšek Šalamon 2020; Trucco 2023).

<!-- borders-to-courts-018 -->

〔原刊 p. 4〕

In the still emerging socio-legal literature on pushback litigation, which has so far focused mainly on international judicial remedies, these features appear in procedural form: evidentiary asymmetries, weak traceability, and state practices that deny or blur the event itself, narrow the space for civil society action, and impede judicial contestation. Alpes (2026) shows that the evidentiary regime of the European Court of Human Rights (ECtHR) often privileges state-produced facts precisely where states neither record nor allow the recording of pushbacks. Recent analysis further shows that “non-paper pushbacks,” phone confiscation, restricted access to border zones, and strategic non-cooperation can render key facts invisible to the ECtHR, as the Court has itself recognized (*A.R.E. and G.R.J. v. Greece*) (Baranowska et al. 2025). More broadly, this literature places litigation within its wider political environment and shows how that environment shapes what can reach the court (Alpes and Baranowska 2025; Cusumano and Villa 2021; Pijnenburg and Van der Pas 2022; Trucco 2023). By asking why so little of the extensive documentation of European border violence is reflected in ECtHR judgments, it also shows that the counter-archive assembled on the ground through monitoring networks rarely arrives before the court (Baranowska et al. 2025). What follows is a central distinction: visibility is not the same as legal usability. Border violence may be extensively documented and made publicly visible, yet still fail to appear before a court in forms that are procedurally usable or evidentially sufficient (Alpes and Baranowska 2025; Baranowska et al. 2025; Davies et al. 2023).

<!-- borders-to-courts-019 -->

〔原刊 p. 4〕

Some degree of mismatch between the position of claimants, the evidence, and the procedural route is not unusual in litigation. Nor is it unusual that the experience of harm itself can obstruct later accountability. What becomes visible here, however, is the dispersal and destabilization of basic case elements across borders within a hostile transnational setting. This condition, namely case misalignment, is generated by the very regime being contested.

<!-- borders-to-courts-020 -->

〔原刊 p. 5〕

## Legal intermediaries and their work

<!-- borders-to-courts-021 -->

〔原刊 p. 5〕

If hostile transnational conditions scatter and weaken the elements on which a pushback case depends, by whom and through what work do such cases first become possible and moveable at all? We see this as a question of legal intermediation in the early pre-claim phase of legal mobilization. However, the specificity of this article’s focus requires engagement with and dialogue between a set of further bodies of literature.

<!-- borders-to-courts-022 -->

〔原刊 p. 5〕

A first point of departure is work on the emergence and transformation of disputes. Scholarship has long shown that disputes emerge through selective and iterative processes of naming, blaming, and claiming, and that their trajectories branch rather than follow a single linear path (Albiston et al. 2014; Felstiner et al. 1981; Miller and Sarat 1980–1981; Olesen and Hammerslev 2023). Work on language and audience likewise shows how disputes are reshaped as they are framed before different institutions and publics (Mather and Yngvesson 1981). Together, this literature establishes the importance of the pre-claim phase, including both the legal institutions that must be activated and the third parties who intervene within this phase, variously described as brokers, gatekeepers, translators, and intermediaries (Olesen and Hammerslev 2023). It also highlights the power asymmetries and contradictory effects that mark such interventions, which may facilitate access to legal institutions while also reproducing exclusionary dynamics (Albiston et al. 2014; Michelson 2006). What it leaves less precisely specified, however, is the mechanism by which a problem acquires enough coherence to become actionable when its basic elements are dispersed across sites and institutions.

<!-- borders-to-courts-023 -->

〔原刊 p. 5〕

A related set of works examines legal translation by showing how experiences and supporting materials are reworked into forms that institutions will work with (Coutin 2025; Coutin and Fortin 2023; Cunningham 1992; Lakhani 2014). Research on asylum evidence and administration suggests, from a different angle, that evidentiary force depends on institutional forms, and authorized or accepted categories and modes of verification (Cabot 2012; Fassin and D’halluin 2005; Pörtner 2021). Similarly, Latour (2010) shows how legal reasoning depends on materials already profiled for legal use and on the fragile textual connections through which documents are related to legal categories, arguments, and precedents (Latour 2010). This body of scholarship is key to the present article. At the same time, much of it begins only once a viable basis for legal work is already in place, thus not yet sufficiently engaging with the conditions that precede and enable translation work.

<!-- borders-to-courts-024 -->

〔原刊 p. 5〕

Our analysis proceeds primarily through the lens of legal intermediation, understood here in functional rather than professional terms, given the interest in understanding the actors and practical work that can assemble the elements of an intensely misaligned case at its very initial stage, keeping in view problems of connection, routing, and selective case-making. Legal intermediaries are understood, then, as those who help move a potential case toward court by connecting not only people and judicial institutions but also people, traces, and documents, as well as procedural possibilities. The term is here operationalized to include both legal and nonlegal professionals, since the question is which work and processes directly bear on whether a potential pushback case can advance. In the present setting, this includes not only lawyers but also activists, journalists, nongovernmental organizations (NGOs), and monitoring actors. The focus, therefore, remains on a subset of actors and activities. Care, solidarity, or monitoring practices are included only when they directly influence the movement of a potential case toward court. It also follows, then, that the actors examined here cannot be treated as representative of anti-pushback contestation as a whole, still less of the orientations or capacities of people subjected to pushbacks. Rather, they occupy a position where they direct only some harms toward adjudication (Felstiner et al. 1981; Lejeune and Spire 2021; Miaz et al. 2021; Trucco et al. 2023).

<!-- borders-to-courts-025 -->

〔原刊 p. 6〕

Existing scholarship on intermediation already illuminates several upstream processes, though not at the same analytical level: movement from conflict toward legal recourse and into the dispute pyramid (Lejeune and Spire 2021), brokerage and legal-administrative navigation, and the shaping of legally relevant categories, routes, and records (Billows et al. 2019; Pélisse 2019; Talesh 2015). What remains less clearly specified across these literatures, again, is the linkage problem that arises when a possible case exists only in disaggregated form under conditions of transnational fragmentation.

<!-- borders-to-courts-026 -->

〔原刊 p. 6〕

Migration scholarship complements this picture by showing that access to migration law and administration is routinely mediated, sometimes opening routes and sometimes reproducing exclusion (Bonizzoni and Odasso 2024; Bonjour 2025; Johan et al. 2012; Könönen 2018; Miaz et al. 2021; Tuckett 2018). This scholarship is valuable as it establishes that the migration field is structured by chains of mediation. Yet, again, its center of gravity usually lies elsewhere, in brokerage, administrative navigation, legal-administrative intermediation, the everyday production of migration governance, and the ambivalent political agency of those who mediate it. The role of intermediaries in connecting people on the move with courts, however, is understudied here.

<!-- borders-to-courts-027 -->

〔原刊 p. 6〕

A related body of work studying why the movement toward the court is difficult, even when legal actors are present, helps to understand this intermediation function within a specific setting. Scholarship on transnational legal mobilization and movement lawyering shows that legal contestation depends on cross-site relations among legal, movement, and knowledge-producing actors (Cummings 2018, 2020; Kawar 2015, 2021). Research on support structures and legal opportunity structures further shows that legal action depends on organizational capacity and domestic procedural openings (Alagna 2025; Epp 1998, 2011; Southworth 2000; Van der Pas 2023; Vanhala 2012, 2018). Taken together, these literatures explain why contestation at the border is difficult, why distributed capacities are relevant, and why domestic legal settings shape what can ultimately be pursued. For our purposes, then, they help explain why a similar harm occurring may require different organizational forms or arrangements of intermediary work in different procedural settings.

<!-- borders-to-courts-028 -->

〔原刊 p. 6〕

Against this backdrop, a turn to law should not be read as naïve faith in courts. Research on support structures, legal mobilization, and movement lawyering suggests instead that legal action becomes thinkable and sustainable when organizational capacity, among other factors, makes it a usable repertoire among others, and when actors pursue effects that exceed immediate remedy, such as procedural and doctrinal change (Cummings 2020; Epp 1998; Kawar 2015; Southworth 2000; Vanhala 2012, 2018). Conversely, in a field marked by exhaustion, risk, precarious mobility, and the burdens of waiting, continued participation in litigation cannot be assumed, since people may instead prioritize onward movement, immediate safety, or other urgent needs over legal pursuit (Riva and Hoffstaedter 2021).

<!-- borders-to-courts-029 -->

〔原刊 p. 7〕

Finally, scholarship on the Balkan route situates pushbacks and litigation within the evolving European border regime and broader fields of contestation (Hameršak et al. 2020; El-Shaarawi and Razsa 2019; Cantat 2020; Jovanović 2020; Mitrović and Vilenica 2019). Closely related work examines grassroots documentation, highlighting the struggle to convert border knowledge into legally usable facts to combat opacity and erasure (Alpes and Baranowska 2025; Baranowska et al. 2025; Davies et al. 2023; Fortarezza 2026; Hameršak 2021). However, while this literature details how pushbacks are documented and made visible, it rarely explains the practical intermediation work required to ultimately turn them into legal cases.

<!-- borders-to-courts-030 -->

〔原刊 p. 7〕

Overall, then, this literature in many respects illuminates important pieces of the puzzle. It provides us with the basic categories and vocabulary required for the contribution of our study: to isolate and explain the initial intermediary work, before translation sets in, through which pushback cases, characterized by misalignment, become processable. For this analysis, the article conceptualizes the term “case assembly” as the work of identifying and connecting initial elements of cases, as well as stabilizing them in time and long enough, so that they can move toward judicial processing. On this basis, we can explore a set of more granular processes of case assembly. Moreover, we can engage with the collaborative organizational form of their engagement. As noted, when elements are dispersed across actors, places, and jurisdictions, such arrangements can become a necessity.

<!-- borders-to-courts-031 -->

〔原刊 p. 7〕

## Case studies

<!-- borders-to-courts-032 -->

〔原刊 p. 7〕

To understand how intermediaries assemble cases, this article compares litigation in Italy and Austria within the broader Balkan-route field of migration control. In both jurisdictions, domestic courts were asked to assess practices that contributed to pushbacks to Slovenia, and mostly also further to Croatia and Bosnia and Herzegovina. In both, people seeking international protection were exposed to, sometimes repeatedly, onward removals, violence, and denial of access to asylum. The comparison thus holds constant the wider hostile transnational setting. Moreover, in both cases, courts came to condemn the practice, thereby contributing to an end of systematic pushbacks toward Slovenia (Association for Legal Studies on Immigration 2025; Fortarezza 2026; Gahleitner-gertz 2025; Moraru and Reyhani 2026). However, they did not end the broader dynamics of containment and externalization (Bergesio and Bialasiewicz 2023; Fortarezza 2026; Zoppi and Puleri 2022). Moreover, as elaborated below, the comparison varies the specific practices states deployed, as well as the domestic legal systems and procedures. Differences in the available remedies, procedural routes, and conditions of legal representation shaped where cases became difficult to advance. The comparison thus allows our study to analyze the influence of distinct legal opportunities and constraints on the success or failure of litigation.

<!-- borders-to-courts-033 -->

〔原刊 p. 7〕

The first major point of variation concerns the legal form through which pushbacks were carried out. In Italy, pushbacks were executed as informal readmissions under a 1996 bilateral agreement with Slovenia, a practice that bypassed formal asylum procedures as regulated under national and EU law and affected at least 1240 people in 2020 (Facchini 2020). In a written statement, the Ministry declared that these readmissions also included asylum seekers (Italian Ministry of the Interior 2020), although it later changed its version in oral statements to the media and in front of the parliament, stating that they were applied only to those who had not claimed asylum at the border, a justification largely adopted by states (Italian Ministry of the Interior 2021). Pushbacks through the bilateral agreement with Slovenia are an example of the mix of formal and informal practices for border control (Fortarezza 2026). The state justified the pushback practice through a formal policy tool, the readmission agreement, whose implementation occurs within gray zones of law and opacity, for instance, by not providing any written decision by the state attesting to this readmission.

<!-- borders-to-courts-034 -->

〔原刊 p. 8〕

Notably, the Tribunal of Rome ruled against the government in 2021 and again in 2023 (Tribunale di Roma 2021a; 2023), questioning the legality of the readmission agreement with Slovenia and its consequences, including chain pushbacks to Croatia and Bosnia and Herzegovina, contrary to national and EU law and to international human rights obligations. The third relevant ruling arose from an appeal against the Tribunal of Rome’s 2021 decision (Tribunale di Roma 2021a). In this case (Tribunale di Roma 2021b), the government contested the initial decision, arguing the legitimacy of the readmissions and the lack of evidence that the appellant had personally entered Italy and was informally readmitted to Slovenia. The panel of judges did not refute the earlier findings on the illegality of readmissions under the bilateral agreement, but avoided discussing broader issues of chain pushbacks and non-refoulement. Instead, it overturned the favorable decision, stating that the appellant provided no individualized evidence. This decision demonstrated the challenges of presenting individual evidence in such cases and the complexities of legal proceedings involving pushback practices, which will be further explored in the following sections.

<!-- borders-to-courts-035 -->

〔原刊 p. 8〕

In Austria, by contrast, the relevant measures were framed by the authorities as lawful refusals of entry under the Schengen Borders Code and the Austrian Aliens Police Act. It presents a different mix of formality and informality. The state uses a formal mechanism, also leaving a paper trail behind. However, informal practices at the border led to the systematic denial of asylum. More specifically, the authorities claimed that the people concerned had not sought asylum at the border and could therefore be treated as subject to ordinary border enforcement. However, Austrian law contains no legal basis for the pushback of asylum seekers. On the contrary, it requires the acceptance and processing of asylum applications made on the territory or at the border. In decisions such as LVwG Steiermark (2021; 2022), later upheld in the related VwGH decisions of May 2022, Austrian courts found that articulated requests for protection had been ignored or not properly verified, and that the persons concerned were returned without the authorities first clarifying why they had entered Austria or whether they sought asylum. The LVwG further described the file as suggesting a broader pattern in which such “pushbacks” were systematic in their use, while the VwGH upheld the unlawfulness findings without treating that broader characterization as necessary to decide the case (LVwG Steiermark 2021, 2022, VwGH 2022a, 2022b; Gahleitner-gertz 2025). This variation relates to a growing trend within the European Union, where asylum law is increasingly proceduralized and harmonized. Yet, countries still circumvent the law to restrict access to asylum by mostly informal uni- and bilateral approaches (Moraru and Reyhani 2026).

<!-- borders-to-courts-036 -->

〔原刊 p. 9〕

A second major point of variation concerns forum, remedy, and procedure. In Italy, litigation unfolded primarily before civil courts. Claimants could proceed through urgent summary proceedings under Article 700 of the Italian Code of Civil Procedure or through damages claims. The available remedies were correspondingly broader and could include annulment of readmissions, humanitarian visas, and compensation for violations of fundamental rights. In the first Italian case, where the claimant remained stranded in Bosnia and Herzegovina after a chain pushback, urgent proceedings were especially significant because they offered a possible route to entry. In the second, the Tribunale di Roma judgment of 2023 awarded compensation for non-pecuniary harm caused by the unlawful readmission. In Austria, by contrast, the relevant cases were brought before provincial administrative courts through complaints against executive measures. The remedies were more limited, consisting chiefly of declarations of illegality and monetary compensation, and claimants were not granted a right to return lawfully. The complaint had to be lodged within a short six-week deadline. The central legal question was therefore whether people had been denied the chance to lodge asylum claims and had accordingly been unlawfully refused entry.

<!-- borders-to-courts-037 -->

〔原刊 p. 9〕

A third point of variation concerns claimant position. In Italy, the two key cases involved claimants in markedly different situations: one was a Pakistani citizen in irregular status, stranded in Bosnia and Herzegovina after a chain pushback from Italy to Slovenia and onward to Croatia, while the other was a Pakistani citizen who had already obtained refugee status in Italy after a prior pushback attempt. In Austria, by contrast, the litigants in LVwG Steiermark (2021, 2022) were people in irregular status who had been removed to Slovenia after being denied access to asylum at the Austrian border, including a minor.

<!-- borders-to-courts-038 -->

〔原刊 p. 9〕

Finally, rules for legal representation vary too: Austria, for pushback cases, lacks free legal aid and relies on pro bono legal representation (Gahleitner-gertz 2025), and Italy has free legal aid available but encounters difficulties in formalizing legal representation when the claimant is outside the jurisdiction due to strict procedural rules (Massimi 2026).

<!-- borders-to-courts-039 -->

〔原刊 p. 9〕

## Methods

<!-- borders-to-courts-040 -->

〔原刊 p. 9〕

The research combines desk research with semi-structured interviews with key legal intermediaries involved in judicial contestation of pushbacks along the Balkan route before Italian and Austrian courts. For information on the availability of the sources, please see the “Data availability statement.”

<!-- borders-to-courts-041 -->

〔原刊 p. 9〕

First, we qualitatively analyzed seven judgments on pushbacks from Italy and Austria to Slovenia, governments’ official statements, and additional sources from the media, websites, and reports. This allowed for understanding the overall constellation of legal intermediaries involved, the similarities and differences between them in the two contexts, and the selection of key stakeholders to be interviewed. Moreover, it enabled us to set the context by highlighting the organizational and institutional factors that may be relevant to our case studies, thereby facilitating an understanding of the strategies and actions intermediaries take to access national courts.

<!-- borders-to-courts-042 -->

〔原刊 p. 9〕

The second stage consisted of semi-structured expert interviews with the actors most directly involved in the litigated cases (Appendix). In Italy, this included two lawyers active in asylum and migration litigation, one activist with cross-border field experience and prior social-work involvement, and one journalist who had helped identify and document cases. In Austria, interviews covered the key actors involved in the two main court cases: two activists who built a hotline for first contact in case of pushbacks at the Austrian border, a lawyer and NGO coordinator who functioned as a contact point and organizer, and the attorney representing claimants in the cases. Given the transnational structure of the litigation, we also interviewed a Slovenian NGO lawyer whose work was relevant to both the Italian and Austrian files. In Austria, we further interviewed the judge who decided both cases in the first instance, in order to understand how intermediary efforts were received in adjudication. We were unable to interview the Italian judges, but their judgments provided a surrogate source on judicial uptake. We initially planned to interview claimants as well, but given the very few relevant court rulings and the resulting anonymity risks, we did not pursue this. Overall, moreover, the sample is designed to capture how litigation-facing intermediaries assembled and carried cases toward court, rather than to reconstruct the experience of all actors affected by pushbacks. The interviews followed a semi-structured format to guarantee open-ended answers from experts in the field, while also collecting comparable data (Ahlin 2019). Interview questions addressed strategies for accessing courts, including choices related to litigation in cases involving pushbacks to Slovenia at various stages, from monitoring and constructing the case to the courtroom. These were supplemented by inquiries into the reasons behind these strategies, as well as the challenges and strengths related to individual, organizational, and institutional dynamics. Moreover, interviews focused on interactions with other actors involved and their influence on litigation and on strategic choices.

<!-- borders-to-courts-043 -->

〔原刊 p. 10〕

Research ethics approval from the University of Bologna’s research ethics board has been received to conduct interviews, and all participants signed information and privacy consent forms, and the interview material was anonymized. Interviews lasted one hour and were conducted in Italian, German, and English. They were recorded and transcribed verbatim in the original language. Then, they were translated into English and analyzed through thematic coding using an abductive strategy (Timmermans and Tavory 2012). Data from documents and semi-structured interviews were analyzed using themes emerging from the existing literature, which were integrated with themes directly emerging from the interviews and texts.

<!-- borders-to-courts-044 -->

〔原刊 p. 10〕

Finally, some reflections on the interview sample are needed. First, because claimants were not interviewed, the claimant agency appears here only indirectly, through litigation-facing intermediary accounts. The reconstruction can therefore identify claimant action where interviewees describe it, for example, in decisions to proceed, withdraw, wait, move on, or remain only conditionally engaged, but it cannot recover claimant perspectives in their own voice. The sample is thus likely to foreground intermediary labor more strongly than claimant choice, refusal, tactical movement, or disengagement. Second, our interviews capture only a smaller segment of anti-pushback contestation: actors whose roles, organizational positions, and cross-border networks placed them close to rare legal openings and made them responsible, in practice, for deciding whether a possible case could be turned into a court file. The reconstruction is strongest for files that reached, or came close to reaching, court. It is thinner for the wider universe of possible cases that dropped out earlier and left fewer traces in the interview material.

<!-- borders-to-courts-045 -->

〔原刊 p. 11〕

## Empirical data

<!-- borders-to-courts-046 -->

〔原刊 p. 11〕

This section follows the work that made pushback cases processable before they moved further toward the courts. It is organized around the three basic areas of the assembly work of intermediaries, as suggested by interview data: on traces, relationships, and litigation paths. In addition, the section describes how adjudication tested the assembled cases and what came thereafter.

<!-- borders-to-courts-047 -->

〔原刊 p. 11〕

First, however, we provide the context preceding the engagement of legal intermediaries by reconstructing the main facts of the underlying cases from available court judgments. The Italian cases concern two applicants who reached Trieste after lengthy, repeated movements along the Balkan route. In the first case, later decided in Tribunale di Roma (2021a), an individual arrived in mid-July 2020 after violence at the Croatian border. In the second, the individual had already reached Bosnia and Herzegovina in 2019, had suffered nine Croatian and three Slovenian pushbacks, and made his first entry into Italy at Trieste in mid-October 2020 after a further attempt begun a few weeks before (Tribunale di Roma 2023). In both files, contact with Italian authorities followed almost immediately after arrival and the individuals were taken to police facilities, photographed or medically screened, asked for information, and made to sign papers whose content was not translated or explained. In the first case, phones were confiscated, and the group was handcuffed (Tribunale di Roma 2021a, 2023). They expressed a wish to seek asylum in Italy, but were nevertheless informally readmitted to Slovenia and then pushed onward to Croatia and Bosnia and Herzegovina, where violence accompanied the onward removal (Tribunale di Roma 2021a, 2023; Interview 1; Interview 3; Interview 9). In Bosnia and Herzegovina, the first applicant was left without reception after Lipa camp had no space and found shelter in an abandoned, war-damaged building in Sarajevo, while the second was later located in the informal settlement near Bihać (Tribunale di Roma 2021a, 2023).

<!-- borders-to-courts-048 -->

〔原刊 p. 11〕

In Austria, in the 2020 case, a group crossed the green border from Slovenia, tried to move inland because they feared immediate pushback if stopped near the border, and was eventually found near Sicheldorf, wet, dirty, and shivering (LVwG Steiermark 2021; VwGH 2022a; Interview 8). During transport and custody, the claimant and others repeatedly used the word asylum, but at Sicheldorf they were fully stripped, fingerprinted, denied food despite requests, not asked what they wanted in Austria, and then handed to the Slovenian police the same afternoon, after which the chain continued through Croatia to Bosnia and Herzegovina (LVwG Steiermark 2021; VwGH 2022a; Interview 7, Austria, judge; Interview 8; Interview 9). In the 2021 case, relating to a minor, the group again crossed on foot from Slovenia and sought contact with the Austrian police in order to ask for protection (LVwG Steiermark 2022; VwGH 2022b). He was nevertheless taken to Sicheldorf, subjected to Covid testing and identification, repeatedly told that the procedure would begin later, and after four to five hours handed back to Slovenian officers (LVwG Steiermark 2022; VwGH 2022b). Yet, unlike the 2020 claimant, he was not pushed onward to Bosnia and Herzegovina, because Slovenia opened an asylum procedure and he later obtained asylum there (LVwG Steiermark 2022; VwGH 2022b; Interview 7, Austria, judge).

<!-- borders-to-courts-049 -->

〔原刊 p. 12〕

## On traces

<!-- borders-to-courts-050 -->

〔原刊 p. 12〕

Given this reality, described here as a hostile transnational setting, pushbacks first appeared in fragments: testimonies gathered in Bosnia and Herzegovina, observations near the border, emergency calls, administrative inconsistencies, and documents produced in one jurisdiction that would later matter in another (Interview 9; Interview 1; Interview 5). At that point, the material produced a pool of possible cases and, gradually, the sense that these were not isolated events.

<!-- borders-to-courts-051 -->

〔原刊 p. 12〕

In Slovenia, the first alert came from a Slovenian journalist working in Bosnia. Follow-up interviews in Velika Kladuša and Bihać then produced testimonies and documents from people who said they had been pushed back from Slovenia to Croatia and then to Bosnia and Herzegovina (Interview 9). A network linking actors in Slovenia, Croatia, and Italy grew out of that work, “to notify each other about the violations and in order to find as much as we can cases that can then be processed before the courts” (Interview 9).

<!-- borders-to-courts-052 -->

〔原刊 p. 12〕

In Italy, a lawyer in Trieste recalls that reports on violence and abuse along the Balkan route made chain pushbacks through Slovenia, Croatia, and Bosnia and Herzegovina from Italian territory plausible, while later trips to Bosnia and Herzegovina and contacts with local NGOs began to fill in that picture (Amnesty International 2019; Interview 1). One Bosnia-based journalist described an early handoff like this: “I put some of these people who told me they had been illegally rejected by Italy in touch with *[the legal association]*, one person went through the whole process […] to verify […] and then from there everything started moving” (Interview 4). The journalist knew of the legal association’s litigation against pushbacks along the route only indirectly through media sources (Interview 4). The same interview points to the material that, collected for other reasons, later traveled with the file: “the photos all have the date and, if desired, the location in the metadata” and “the GPS coordinates of where this small informal camp is located” (Interview 4). On the Trieste side, reception actors began noticing a mismatch between what border police said and who actually arrived at the reception point. Lawyers then took the issue into urgent meetings, access-to-files requests, a parliamentary inquiry, and further testimony-gathering with the help of activists and contacts in Bosnia and Herzegovina (Interview 1; Association for Legal Studies on Immigration 2023).

<!-- borders-to-courts-053 -->

〔原刊 p. 12〕

In Austria, activists describe that there was often “no names, no location, nothing,” especially under a six-week filing deadline (Interview 5). Reports from local media and volunteers about large police operations in southern Styria only became useful once they were connected with information from people on the move networks and partner organizations in Croatia and Slovenia (Interview 6). Local NGOs worked as an intake point for those who noticed something at the border but did not know what to do next, while a network of activists set up a hotline through which people on Austrian territory could say that they wanted asylum and were being pushed back (Interview 5; Interview 6). Journalists, local actors, and other organizations also passed on contact numbers and other traces that the activists themselves had not generated (Interview 5; Interview 9). In the 2021 minor case, one trace survived in the case file itself: the group used smartphone GPS to reach Bad Radkersburg and actively sought the police station in order to ask for asylum, though the request was later denied or said not to have been heard (LVwG Steiermark 2022; VwGH 2022b).

<!-- borders-to-courts-054 -->

〔原刊 p. 13〕

The Austrian material also shows that these fragments were tested against place. Activists returned to the relevant border area, photographed the river, the border station, and local signs, and compared those surroundings with what claimants said had happened there. Local knowledge on the southern Styrian border helped make sense of fragmentary descriptions and decide whether they could hold together in a file (Interview 5).

<!-- borders-to-courts-055 -->

〔原刊 p. 13〕

Later use was already shaping what was being collected. Activists say they worked closely with the lawyer because he knew which details would matter in court. Place, sequence, uniforms, and the course of events were recorded with the help of translators rather than left at the level of a general story (Interview 5). As they put it, “it’s always about the details,” because otherwise a statement could later be dismissed as implausible (Interview 5).

<!-- borders-to-courts-056 -->

〔原刊 p. 13〕

Across both settings, Slovenian documentation often supplied a trace that other jurisdictions lacked. The Slovenian interviewee describes readmissions there as producing records showing that the person had in fact been processed on Slovenian territory, records that could later be used in litigation elsewhere, including in Italy and Austria, where state traces were absent, thinner, or otherwise less useful for accountability (Interview 9; Interview 5). Because Slovenian organizations could also represent people within asylum procedures, documentary access and person-specific follow-up could sometimes be combined there in ways that were not as readily available elsewhere (Interview 9). Even there, though, the issue remained whether there was “concrete proof that they were actually on Slovenian territory,” and whether “the documentation would coincide with their statements” (Interview 9).

<!-- borders-to-courts-057 -->

〔原刊 p. 13〕

## On relationships

<!-- borders-to-courts-058 -->

〔原刊 p. 13〕

The next problem was to establish, or re-establish, a working relation with a person who could still be found, might or might not be willing to proceed, and could remain in contact long enough for mandate, testimony, and filing to follow. In Austria, the first group arrived as phone numbers passed on by colleagues in Bosnia. One passage captures what followed:

<!-- borders-to-courts-059 -->

〔原刊 p. 13〕

we had to put in a lot of work to ensure that these cases even existed […] you have to find the people […] we put a lot of resources into really getting to know the people affected and explaining to them how the system works here […] four made statements, but only one person agreed to act as the complainant. (Interview 5)

<!-- borders-to-courts-060 -->

〔原刊 p. 13〕

The Italian material shows the same problem stretched across a greater distance and over a longer period of time. Intermediaries were in Italy while claimants were in Bosnia and Herzegovina, often in precarious and shifting conditions, so maintaining contact depended on what one lawyer called the whole chain “from Trieste down” (Interview 1). Bosnia-based activists and local contacts located claimants in camps, squats, or informal settlements, kept them in touch, accompanied them to appointments, and worked in an environment where phone numbers changed, people disappeared, and waiting itself could undo the file (Interview 2; Interview 1). One activist ties that waiting period to the need to secure food, accommodation, washing facilities, and clothing, while also keeping the claimant engaged as legal and bureaucratic steps were prepared elsewhere (Interview 2). The same work also involved explaining the proceedings, what might follow from them, and what they could not promise in the short term. In the urgent Italian route, the claimant had to remain in Bosnia long enough for that route to make sense, even though the wider environment kept pulling toward onward movement.

<!-- borders-to-courts-061 -->

〔原刊 p. 14〕

Not everyone first identified could later become a claimant for court. Some accounts dropped out because chronology and route could not be reconstructed consistently. Others fell away because documents could not be obtained, contact could not be maintained, or the person did not remain in place long enough for the file to be built (Interview 2; Interview 4). Yet attrition also reflected claimant priorities under severe constraint. The Slovenian interview states it was often easier to monitor what was happening than to find a person willing to pursue a case, because many people in Bosnia were more concerned with reaching the desired state than with initiating legal proceedings, and were difficult to follow as they moved (Interview 9). Austrian activists similarly describe how trust had to be built over repeated conversations before some details, including violent searches and forced stripping, were disclosed more fully (Interview 5). Across the material, the same practical questions recurred: would the person continue, could contact be maintained, and was there enough proof, or at least a plausible route to proof, that the person had been on Italian, Austrian, or Slovenian territory and then been pushed back (Interview 5; Interview 1; Interview 9). The pool thus became considerably smaller.

<!-- borders-to-courts-062 -->

〔原刊 p. 14〕

## On litigation paths

<!-- borders-to-courts-063 -->

〔原刊 p. 14〕

On the Italian side, one lawyer reduced the problem of authorization to this:

<!-- borders-to-courts-064 -->

〔原刊 p. 14〕

the power of attorney was certainly one of the most complex elements to manage […] This power of attorney must be signed before a notary or a public official, authenticated by the public official or notary, legalized and translated by the embassy […] from the moment you identify the person who shares their testimony with local activists and says they have been readmitted *[the claimant]* times from Italy, to the moment you are able to file the appeal, several months or at least several weeks can pass, because you need time to write the appeal, perhaps request access to the files, collect the power of attorney, etc. (Interview 3)

<!-- borders-to-courts-065 -->

〔原刊 p. 14〕

This long bureaucratic process has another major obstacle: the requirement for a valid client ID, which is rare among people on the migratory route (Interview 1).

<!-- borders-to-courts-066 -->

〔原刊 p. 14〕

In Bosnia, the same difficulty appears as a material chain. One activist describes it like this:

<!-- borders-to-courts-067 -->

〔原刊 p. 14〕

the strategy was to go together to a notary in Bosnia in Biaz who would confirm with a notarial deed the physical presence of this person in front of him […] I acted as guarantor for this person in order for a notarial deed to be recognized as usable in court proceedings, it must also have the apostille […] the fact that this guy was there with a notarized document proving that he was there, made the whole previous process of gathering information that saw him in Trieste in September make sense. (Interview 2)

<!-- borders-to-courts-068 -->

〔原刊 p. 15〕

In the same trajectory, documents moved through Sarajevo and Bihać, local accompaniment remained necessary at each step, and both activists and lawyers stress that without those local actors, the appeal would not have been possible in practice (Interview 2; Interview 3). The later Rome judgment recorded the mandate as “translated and apostilled […] in Bihać” (Tribunale di Roma 2023, p. 4).

<!-- borders-to-courts-069 -->

〔原刊 p. 15〕

In the Italian files, a recurring problem was sequencing. Lawyers sometimes had to decide whether to file before documentary access had been secured, even though that choice could later weaken the case. The practical lesson drawn from the interviews was that formalization and proof could not always be assembled at the same speed. In some files, filing early preserved urgency. In others, the case became stronger only once claimant-specific records could first be obtained and cross-referenced (Interview 1; Interview 3).

<!-- borders-to-courts-070 -->

〔原刊 p. 15〕

The route itself could also change while the file was still being assembled. In one Italian case, the claimant had to remain in Bosnia because the urgent route depended on that location. As the activist put it, “we send these documents through another person who takes them to Trieste, we get them to the lawyer. In the meantime, he had to stay there because this thing works, if you stay in the country” (Interview 2). That procedural logic also created a tension that the interviews themselves register. Waiting in Bosnia was not a neutral legal requirement, but a demand placed on a person whose own priority might instead be to continue the route (Interview 2). A Trieste lawyer describes how this could create shifts in the litigation strategy:

<!-- borders-to-courts-071 -->

〔原刊 p. 15〕

While we were about to file the appeal, he left […] we were practically there with the power of attorney already taken, when we were about to file the appeal, he was no longer responding. After a few days, he revealed that he was already in [northern Italian city] and we collected a different power of attorney. At that point, for compensation for damages directly. So, first he went before the Commission, then he was granted refugee status, and then we appealed. (Interview 1)

<!-- borders-to-courts-072 -->

〔原刊 p. 15〕

Many Italian files never reached filing at all. Lawyers began several appeals and then decided not to file most of them. One lawyer summarizes that attrition this way:

<!-- borders-to-courts-073 -->

〔原刊 p. 15〕

thanks to this access to documents, we were able to get started. We began to collect a lot of testimonies thanks to the collaboration with activists who were on the Balkan route. Unfortunately, many of them could not be turned into appeals because it was still necessary to obtain a formal power of attorney. (Interview 1)

<!-- borders-to-courts-074 -->

〔原刊 p. 15〕

The selection was also strategically driven:

<!-- borders-to-courts-075 -->

〔原刊 p. 15〕

We didn’t want to file an appeal that would end up going nowhere. We wanted to file a strong appeal, one that would be definitive. So, we started at least 15 cases, we prepared at least five appeals, but we didn’t file them because we weren’t sure. In the end, we only filed two. (Interview 1)

<!-- borders-to-courts-076 -->

〔原刊 p. 16〕

Austria compressed the same conversion work into a far shorter procedural window. Once one complainant had been identified and remained in contact, the task was to stabilize the account quickly enough for filing within six weeks. This meant anticipating likely questions with the lawyer, clarifying chronology and place through interpreters, and turning repeated conversations into a statement detailed enough to survive against a police-shaped record (Interview 5; Interview 8).

<!-- borders-to-courts-077 -->

〔原刊 p. 16〕

The Slovenian interview shows the same work from the other side of the corridor. As the interviewee put it,

<!-- borders-to-courts-078 -->

〔原刊 p. 16〕

we also included [coordinator] and his organization in our cross-team group with the purpose of finding cases to put before the national courts. We were basically able to get a lot of documentation for the Italians, and we were able to find cases for [coordinator] to push to the Austrian court. We would go to the asylum home and try to find them in order to get powers of attorney to start lawsuits. (Interview 9)

<!-- borders-to-courts-079 -->

〔原刊 p. 16〕

The relay was unequal. Journalists might have names and images but no mandate. Bosnia-based activists might have the claimant and local mobility, but not the Italian or Austrian forum. Slovenian actors might have documents and access to asylum homes, but not the final pleadings. Lawyers decided on route and filing, but depended on others for contact, documents, translation, and claimant stability. Interpreters, notaries, local counsel, and, later in some Italian files, embassy or airport actors entered only at particular points, but a missing step there could stop the chain just as surely as the loss of the claimant himself (Interview 2; Interview 3; Interview 5; Interview 9).

<!-- borders-to-courts-080 -->

〔原刊 p. 16〕

These relays were also thin and unevenly exposed. The interviews point to dependence on trusted local actors, very limited staffing, and differences between actors who could move more quickly in the field and organizations that had to weigh visibility, funding, or risks to their own operations. Bosnia-based local actors, in particular, appear to carry practical and social risks that better-positioned actors elsewhere did not (Interview 2; Interview 5; Interview 9).

<!-- borders-to-courts-081 -->

〔原刊 p. 16〕

## Judgment

<!-- borders-to-courts-082 -->

〔原刊 p. 16〕

Once the case was assembled and filed, adjudication before the court would test the work of the intermediaries. The first Italian case remained vulnerable because relevant records had not been secured before filing. When those records were eventually obtained, there was “no trace of this person,” other people who had been present were afraid to testify, and available visual material did not individualize the claimant strongly enough (Interview 1). One lawyer explains the same weakness from the standpoint of the procedure itself: in the urgent proceedings, “evidence cannot be added as you go along,” so that in the first case, the evidentiary problem became “an insurmountable fact” once the file was already before the court (Interview 3). The Rome appeal judgment makes the same point in more formal terms. The Ministry relied on a “total absence of any trace at all” of the claimant in the Italian and Slovenian archives and argued that he was “unknown both to the Italian authorities and to the Slovenian authorities,” while the collegial court held that there was still no sufficient proof “that the appellant personally underwent an informal pushback” and that the evidentiary picture was “insufficient” (Tribunale di Roma 2021b, pp. 1, 4–6). The same decision also held that the Border Violence Monitoring Network report and journalist article “cannot constitute the sole source of conviction” (Tribunale di Roma 2021b, p. 5).

<!-- borders-to-courts-083 -->

〔原刊 p. 17〕

The first Italian trajectory also reveals a more internal shift in standards. In the earlier urgent proceedings, the court had accepted the treatment as “proven according to the necessarily attenuated standard of proof that is typical of precautionary proceedings” (Tribunale di Roma 2021a, p. 2). On appeal, the issue became whether this claimant personally had undergone the narrated informal readmission, and the answer was negative (Tribunale di Roma 2021b, p. 6).

<!-- borders-to-courts-084 -->

〔原刊 p. 17〕

The later Italian case held together more effectively because the documentary sequence had been secured before filing and could be read by the court as one claimant-specific chain. The Rome court relied on the access-to-files materials from Trieste, including the multilingual identification sheet recording “Expression of the will to apply for international protection” with the answer “yes,” together with the same-day readmission request and the Slovenian custody and handover records (Tribunale di Roma 2023, p. 3). It stated that “The set of these documents demonstrates” both the readmission by Italy to Slovenia and the subsequent readmission to Croatia (Tribunale di Roma 2023, p. 3). Once that documentary sequence was in place, Bosnia-side witnesses and claimant-specific visual material could reinforce rather than substitute for the core proof. The court therefore received the file not as a general account of route violence but as an individualized sequence linking this claimant to Italian handling, Slovenian readmission, and onward removal (Tribunale di Roma 2023, pp. 3–4; Interview 1).

<!-- borders-to-courts-085 -->

〔原刊 p. 17〕

In Austria, the file that reached court had already been built through repeated interviewing, translation, and chronological clarification. Once before the court, the issue was whether that claimant-specific account could withstand a police record that was thin, incomplete, and already shaped by the authorities’ own version of events (Interview 5; Interview 8).

<!-- borders-to-courts-086 -->

〔原刊 p. 17〕

The Austrian judgments specify what the court later looked for. In the 2020 case, the first-instance court found that the claimant had “used the word ‘asylum’ several times audibly,” while no officer had asked why he had come to Austria (LVwG Steiermark 2021, p. 8). The VwGH then stated that the decisive requirement was that the officer must “make sure” whether asylum had been sought and must document the relevant statements so that later review was possible, and that “both were omitted” (VwGH 2022a, p. 6 para. 12). In the 2021 case, the LVwG similarly examined the hand protocol itself and held that “it does not emerge from the hand slip” whether anyone had asked what the group wanted in Austria or whether asylum had been requested (LVwG Steiermark 2022, p. 7).

<!-- borders-to-courts-087 -->

〔原刊 p. 17〕

The later Austrian file also came to court from a stronger position. Interviewees describe the case involving the minor as easier to sustain because he remained in Slovenia, could be visited there, and was linked to Slovenian-side documentation and legal representation. They also point to the cleaner event structure in that file, since the group had sought out the police station in order to ask for asylum, and to the later Slovenian protection status, which left less room to contest either route or intention (Interview 5; Interview 7, Austria, judge; Interview 9). Even so, Austrian interviewees also stress contingencies beyond the file itself, including contradictions in police testimony, judicial allocation, and the significance of the particular judge who heard the case (Interview 6; Interview 7, Austria, judge; Interview 8).

<!-- borders-to-courts-088 -->

〔原刊 p. 18〕

## Beyond judgment

<!-- borders-to-courts-089 -->

〔原刊 p. 18〕

What happens after judgment is equally illuminating, particularly as regards the limitations of litigation. In Italy, a favorable ruling did not itself bring the claimant back to Italy. Interview material describes further work around the judgment itself: phone coordination among those following the case, accompaniment to the airport, and intervention by the Italian ambassador in Bosnia and Herzegovina before entry was actually secured (Interview 2).

<!-- borders-to-courts-090 -->

〔原刊 p. 18〕

Furthermore, according to interviewees, what followed the judgments was adjustment by state actors. In Austria, interviewees link the cases to later ministry scrutiny and to a decree clarifying that asylum applications could also be made implicitly (Interview 6). The same interviewee describes the judgments as being closely studied inside the Ministry of the Interior with a view to changing future official conduct and limiting further exposure in court (Interview 6). In Italy, interviewees describe movement toward less traceable forms of control, including Schengen refusals, trilateral police cooperation, and interventions earlier in the chain. One lawyer remarks that, while informal readmissions were already difficult to prove, showing that Italian officers had participated in pushback operations in Croatia became “practically impossible” (Interview 3).

<!-- borders-to-courts-091 -->

〔原刊 p. 18〕

Furthermore, Austrian activists describe regular exchange after the rulings in order to follow changing practices and pass on information, while Slovenian and Italian interviewees describe longer-standing cross-border cooperation through which records, contacts, and evidentiary tactics circulated into later cases (Interview 5; Interview 3; Interview 9).

<!-- borders-to-courts-092 -->

〔原刊 p. 18〕

The interviews also place litigation within a wider repertoire of action. Austrian interviewees describe legal work alongside documentation, public reporting, and immediate intervention, and the NGO coordinator explicitly characterizes litigation as one vehicle among others for making pushbacks visible (Interview 5; Interview 6). The Italian activist similarly places legal procedure alongside public awareness work (Interview 2). At the same time, the infrastructure behind these cases remained thin, dependent on volunteer labor, trust, and relations that could weaken through turnover, exhaustion, or changing conditions on the route (Interview 2; Interview 3; Interview 5; Interview 9).

<!-- borders-to-courts-093 -->

〔原刊 p. 18〕

## Discussion

<!-- borders-to-courts-094 -->

〔原刊 p. 18〕

As our empirical data demonstrate, pushback litigation began from a condition of case misalignment because the very practice being challenged separated and unsettled the elements that must normally converge for a case to become actionable. The potential claimants were displaced from the forum, often moved onward across borders, exposed to exhaustion, insecurity, and changing priorities. The trace was likewise dispersed and destabilized. It was scattered across jurisdictions, institutions, phones, witness accounts, police files, health records, readmission papers, and informal documentation, while often remaining incomplete, inaccessible, deniable, or vulnerable to erasure. The litigation path, finally, was itself fragmented across places, actors, procedural steps, and legal systems, and it could become broken by the loss of contact, the absence of a mandate, a missed deadline, an evidentiary gap, or a change in the claimant’s location. Case misalignment, then, refers to a condition in which claimant, trace, and procedural route do not coincide in a form that cases can move toward courts. Before legal translation in the narrower sense can begin, intermediaries must therefore first undertake the work of identifying, reconnecting, and temporarily stabilizing these disaggregated elements. And the cases examined here indeed show that pushback cases often failed because the elements of potential cases could not be made to coincide. That difficulty was produced from the outset and under conditions of violence, exhaustion, opacity, and criminalization (Alpes and Baranowska 2025; Baranowska et al. 2025; Hameršak et al. 2020; Trucco 2023; Zocchi 2024). The findings, therefore, focus attention on the pre-claim and early-claim phases (Olesen and Hammerslev 2023).

<!-- borders-to-courts-095 -->

〔原刊 p. 19〕

Our empirical material indicates three main areas of intermediary work that relate to the basic elements of the cases they assemble, namely work on traces, relationships, and litigation paths. When read together, they indicate a staged, though not neatly linear, process with distinct practices that identify, connect, and stabilize those elements. Confronted with misalignment, intermediaries began by detecting, receiving, and screening possible cases from those points: a testimony, a phone number, a photograph, a readmission slip, a health record, or an inconsistency at a reception point. From there, a person had to be identified, reached, supported, kept in communication, thus stabilized, so that the next step could be attempted: connecting that person to a trace, often through documentary cross-referencing, place verification, or access-to-files requests, and converting that linkage into a forum-specific procedural form. Where that connection or alignment was stabilized, a file emerged that could be processed to some extent.

<!-- borders-to-courts-096 -->

〔原刊 p. 19〕

The comparison between Italy and Austria shows that the same basic mechanism operated under different domestic legal constraints and opportunities, and that these differences shifted the point at which the assembled case could move. In Italy, case assembly was stretched across a greater distance and usually over a longer period. The central pressures lay in mandate formalization, documentary access, and evidentiary timing. Because claimants were often outside Italian territory, authorization itself became a transnational chain of notarization, certification, legalization, translation, and physical accompaniment. At the same time, the stronger Italian files were those in which intermediaries could build a documentary sequence before filing, often by cross-referencing Italian and Slovenian records and exploiting documentary levers such as health-screening material. The Italian procedure thus created both obstacles and a limited opportunity: while some urgent routes were highly vulnerable if filed too early, other files could become stronger through delay, resequencing, or a later shift from a return-oriented remedy to a compensation claim. Austria compressed the same mechanism into a much shorter procedural period. There, the decisive pressures lay in the need to recover claims rapidly, in short filing deadlines, in narrow remedies, and in the anticipated need to contest an official record already shaped by the police. In this sense, legal opportunity structures became relevant early, and inside the assembly work itself.

<!-- borders-to-courts-097 -->

〔原刊 p. 20〕

Collaboration became the arrangement that intermediaries chose for case assembly, since the case itself was geographically and institutionally disassembled from the outset. Information and files moved through an unequal relay in which each actor supplied the element that the next actor lacked. Journalists and route-level actors often brought the first fragments to the fore. Reception and coordination actors turned other fragments of information into a pool of possible cases. Activists and journalists in locations to which claimants had been displaced, and local contacts, carried much of the hardest work, e.g., by finding claimants in camps, squats, and informal settlements, maintaining communication despite onward movement and changing numbers, explaining the process, accompanying people through practical challenges, and at times holding the file together simply by keeping a claimant reachable or later becoming witnesses. Slovenian actors occupied a structurally pivotal position because they could often reconnect individuals to bureaucratic records, readmission records, health forms, police files, and access to asylum homes, which anchored litigation in Italy and Austria. Another part of the chain consisted of translators, notaries, and local counsel, who stabilized authorizations. Finally, lawyers selected procedural routes, judged whether the assembled chain was strong enough, and turned it into pleadings, but depended on others for contact, documentation, and stabilization. In sum, the relay was therefore marked by asymmetrical dependence and uneven exposure. In Italy, it was longer and more mandate-heavy, and it stretched further. In Austria, it was more compressed and relied on rapid coordination among hotline actors, translators, NGOs, and a single lawyer, all within a short complaint window.

<!-- borders-to-courts-098 -->

〔原刊 p. 20〕

In some ways, then, the setting had also fragmented the capacities needed for legal action such that case assembly required collaboration among actors (Cummings 2020; Davies et al. 2023; Kawar 2015). Moreover, this collaboration had contributed to the emergence of a small and fragile infrastructure within a wider field that includes, e.g., monitoring, accompaniment, journalism, and denunciation, and where litigation thus appears as one repertoire among others (Alpes and Baranowska 2025; Cummings 2020; Hameršak et al. 2020; Kawar 2015; Trucco et al. 2023).

<!-- borders-to-courts-099 -->

〔原刊 p. 20〕

Our study further confirms that reaching the top of the iceberg remains exceptional, and it contributes to understanding why this is particularly so in pushback litigation. Beyond the general workings of the hostile setting itself, the material also reveals how legal mobilization itself filtered cases, since detection produced many possible cases, but most never became filed cases. Some failed because no claimant could be identified. Others failed because contact could not be maintained, claimants were no longer willing, documents could not be obtained, or the file no longer fit the procedural route available. Selection occurred through a mix of claimant priorities, the capacity of intermediaries, and judgments about whether the file could survive early scrutiny (Lejeune and Spire 2021; Miaz et al. 2021). In Italy, lawyers screened cases for sustainability and the strength of evidence, as weak claims risked collapsing the case and could undermine future litigation. In Austria, intermediaries attributed attrition more strongly to their limited organizational capacity and a very thin support structure, which recalls accounts according to which sustained rights litigation depends on infrastructures able to absorb the costs of pursuing cases (Epp 2011; Southworth 2000).

<!-- borders-to-courts-100 -->

〔原刊 p. 20〕

Furthermore, this pre-claim filtration connects legal mobilization research to studies on border documentation, reporting, and epistemic borderwork (Davies et al. 2023; Hameršak 2021; Hameršak et al. 2020). Our analysis suggests that visibility alone is insufficient. Monitoring, reporting, and route-level documentation were, at times, relevant starting points, but they were not enough on their own to turn to court. Their significance lay in their potential to be converted, at times, into litigation chains by actors on the ground who tied them to a claimant and a formal path. Moreover, existing humanitarian, monitoring, and activist infrastructures were sometimes selectively repurposed when actors identified a plausible court opportunity.

<!-- borders-to-courts-101 -->

〔原刊 p. 21〕

The group of actors visible in the interviews was thus also wider than the litigation-based sample would initially suggest. Litigation was nested within that wider and uneven field. The interviews also include, although only to a limited extent, data on why activists, journalists, and other non-lawyer intermediaries were potentially inclined to turn to law. Some had prior experience in the field, combined with repeated exposure to patterns of abuse that seemed unlikely to shift through denunciation alone. However, the interview corpus does not permit any statements about how far such an orientation toward litigation was shared across the wider Balkan-route solidarity field, still less among people affected by pushbacks themselves.

<!-- borders-to-courts-102 -->

〔原刊 p. 21〕

The interview data also contain insights into how the agency of people on the move was viewed and mediated. Since the interview sample did not include claimants or potential claimants, the material offers only indirect access to their attitudes toward litigation and courts. But the interviews do show repeated reprioritization, refusal, and tactical choice of claimants: people moved on or declined to wait, refused to testify, withdrew from proceedings, or chose to remain reachable, retrieve documents, and pursue litigation. What appears procedurally as attrition could therefore also be seen as an expression of agency under considerable constraint. At the same time, the material does reveal asymmetrical power relationships. Several interviewees explicitly rejected forcing people, accepted withdrawal, and recognized that many had priorities other than litigation. Yet, intermediaries also screened viability, selected procedural routes, judged whether risks were worth bearing, and sometimes encouraged participation in complaints whose value was partly political and systemic.

<!-- borders-to-courts-103 -->

〔原刊 p. 21〕

The stronger concern disclosed by the corpus, however, is thus not a broad form of “legal saviorism,” but a rather limited risk of representational asymmetry and occasional legal-centrism within a field where intermediaries necessarily shape which forms of claimant conduct become legally intelligible at all (Bonizzoni and Odasso 2024; Bonjour 2025). At the same time, the actors’ repeated resort to law should not be mistaken for a generalized faith in courts. They also situated litigation alongside prevention, hotline intervention, documentation, reception work, accompaniment, media work, and public reporting, and were often explicit about its limited direct payoff, the burdens it imposed, the fragility of claimant participation, and the ease with which authorities could adapt around adverse rulings. Indeed, in the account of legal intermediaries, judicial interventions led to a halt in systematic pushbacks toward Slovenia. But state actors also responded with less visible adaptations of migration control practices, reducing their exposure to future legal challenges (Thomas and Hathaway 2014; Lavenex 2023; Mann 2013). Finally, a legal victory did not necessarily produce a stable improvement in the individual claimant’s broader situation.

<!-- borders-to-courts-104 -->

〔原刊 p. 22〕

## Conclusion

<!-- borders-to-courts-105 -->

〔原刊 p. 22〕

This article has demonstrated that the difficulty of pushback litigation lies in the struggle to bring a case into being at all, before events or documents can be translated into a legal file. In a hostile transnational setting, the same regime that produces the harm also disperses and destabilizes the potential claimant, the trace, and the procedural path through which redress might be sought, such that legal contestation begins from a condition denoted as “case misalignment.” The concept of “case assembly” captures the distinct intermediary work required at this very early point to identify, reconnect, and temporarily stabilize the fractured elements of a claim. Legal intermediation in pushback cases is thus a matter of constituting the conditions under which adjudication becomes possible. The comparison between Italy and Austria further shows how this work is shaped by domestic procedural settings, while depending on cross-border collaboration.

<!-- borders-to-courts-106 -->

〔原刊 p. 22〕

## Data availability statement

<!-- borders-to-courts-107 -->

〔原刊 p. 22〕

Data have been collected within the ERC ACCESS project. Data collected through desk research are available on paper. Restrictions apply to the availability of data from interviews, which are not publicly available. However, Appendix contains the list of interviews conducted with some basic relevant information.

<!-- borders-to-courts-108 -->

〔原刊 p. 22〕

## Acknowledgements

<!-- borders-to-courts-109 -->

〔原刊 p. 22〕

We are grateful to the participants for their willingness to contribute to the research and the time they dedicated to us. We are also grateful to the colleagues who discussed and revised the draft versions of this paper, and particularly to Madalina Moraru, Sara Mariella Lambertini, Chiara Scissa, Stefen Thierse, and Anuscheh Farahat for their insightful comments and ideas. Finally, we sincerely thank the anonymous reviewers for their careful evaluation of this work and for their valuable suggestions, which have strengthened the manuscript.

<!-- borders-to-courts-110 -->

〔原刊 p. 22〕

## Funding statement

<!-- borders-to-courts-111 -->

〔原刊 p. 22〕

This work was funded by the European Research Council 2022 Starting Grant Gatekeepers to International Refugee Law – The Role of Courts in Shaping Access to Asylum (101078683). This research was funded in whole or in part by the Austrian Science Fund (FWF) 10.55776/PAT3567024.

<!-- borders-to-courts-112 -->

〔原刊 p. 22〕

## Conflicts of interest

<!-- borders-to-courts-113 -->

〔原刊 p. 22〕

There are no competing interests.

<!-- borders-to-courts-124 -->

〔原刊 p. 22〕

## References

<!-- borders-to-courts-125 -->

〔原刊 p. 22〕

Ahlin, Eileen M. 2019. “Semi-Structured Interviews with Expert Practitioners: Their Validity and Significant Contribution to Translational Research.” SAGE Research Methods Cases. DOI: 10.4135/9781526466037

<!-- borders-to-courts-126 -->

〔原刊 p. 22〕

Alagna, Federico. 2025. “Pro-migrant Civil Society Organisations and the Law: Patterns of Legal Mobilisation at EU Borders.” *International Migration Rev.* Research Note: 1–18.

<!-- borders-to-courts-127 -->

〔原刊 p. 22〕

Albiston, Catherine R., Edelman, Lauren B. and Milligan, Joy. 2014. “The Dispute Tree and the Legal Forest.” *Annual Rev. of Law and Social Science* 10: 105–31. doi:10.1146/annurev-lawsocsci-110413-030826.

<!-- borders-to-courts-128 -->

〔原刊 p. 22〕

Alpes, Maybritt Jill. 2026. “Truth-Claim Capital at Borders: The Role of Trust in the State at a Regional Human Rights Court.” *Social & Legal Studies* 35 (3) 313–330 doi:10.1177/09646639251364483.

<!-- borders-to-courts-129 -->

〔原刊 p. 22〕

Alpes, Maybritt Jill and Baranowska, Grażyna. 2025. “The Politics of Legal Facts: The Erasure of Pushback Evidence from the European Court of Human Rights.” *Law & Social Inquiry* 50(1): 225–48. doi:10.1017/lsi.2024.27.

<!-- borders-to-courts-130 -->

〔原刊 p. 22〕

Amnesty International. 2019. “Pushed to the edge: Violence and abuse against refugees and migrants along Balkan Route”. Index Number: EUR 05/9964/2019, March 2019, London, UK.

<!-- borders-to-courts-131 -->

〔原刊 p. 22〕

Association for Legal Studies on Immigration. 2023. “Gli interventi di cooperazione di polizia che “inibiscono” l’ingresso in Italia ai cittadini stranieri”. https://www.asgi.it/medea/gli-interventi-di-cooperazione-di-polizia-che-inibiscono-lingresso-in-italia-ai-cittadini-stranieri/ (accessed September 29 , 2025).

<!-- borders-to-courts-132 -->

〔原刊 p. 23〕

Association for Legal Studies on Immigration. 2025. “Country Report: Italy.” July 2025. Asylum Information Database.

<!-- borders-to-courts-133 -->

〔原刊 p. 23〕

Aulsebrook, Gigi, Gruber, Natalie and Pawson, Melissa. 2021. “Pushbacks on the Balkan Route: A Hallmark of EU Border Externalization.” *Forced Migration Rev.* 68: 13–15.

<!-- borders-to-courts-134 -->

〔原刊 p. 23〕

Baranowska, Grażyna, Alpes, Maybritt Jill and Kienzle, Isabel. 2025. “Making Pushback Facts Visible: A Review of Tools in Existing Case Law and the Procedural Framework of the European Court of Human Rights.” *The International J. of Human Rights* 29(10): 1925–50. doi:10.1080/13642987.2025.2531790.

<!-- borders-to-courts-135 -->

〔原刊 p. 23〕

Bergesio, Noemi and Bialasiewicz, Luiza. 2023. “The Entangled Geographies of Responsibility: Contested Policy Narratives of Migration Governance along the Balkan Route.” *Environment and Planning D: Society and Space* 41(1): 33–55. doi:10.1177/02637758221137345.

<!-- borders-to-courts-136 -->

〔原刊 p. 23〕

Billows, Sebastian, Buchter, Lisa and Pélisse, Jérôme. 2019. “Introduction: The Microfoundations of Legal Intermediation in Organizational Contexts.” In *Legal Intermediation: A Processual Approach to Law and Economic Activity*, edited by Sarat, Austin, 1–9. Bingley: Emerald.

<!-- borders-to-courts-137 -->

〔原刊 p. 23〕

Bonizzoni, Paola and Odasso, Laura. 2024. “Legal-Administrative Intermediation in the Migration Field: An Introduction.” *Etnografia e Ricerca Qualitativa* 17(2): 195–212.

<!-- borders-to-courts-138 -->

〔原刊 p. 23〕

Bonjour, Saskia. 2025. “Gatekeepers or Agents of Change? The Political Agency of Lawyers in the Dutch Family Migration Regime.” *J. of Ethnic and Migration Studies* 52(7): 1762–81. doi:10.1080/1369183X.2025.2504619.

<!-- borders-to-courts-139 -->

〔原刊 p. 23〕

Cabot, Heath. 2012. “The Governance of Things: Documenting Limbo in the Greek Asylum Procedure.” *PoLAR: Political and Legal Anthropology Rev.* 35(1): 11–29. doi:10.1111/j.1555-2934.2012.01177.x.

<!-- borders-to-courts-140 -->

〔原刊 p. 23〕

Campbell, John R. 2020. “The role of lawyers, judges, country experts and officials in British asylum and immigration law.” *International J. of Law in Context* 16(1): 1–16. doi:10.1017/S1744552320000038.

<!-- borders-to-courts-141 -->

〔原刊 p. 23〕

Cantat, Céline. 2020. “The Rise and Fall of Migration Solidarity in Belgrade.” *Movements: J. for Critical Migration and Border Regime Studies* 5(1): 97–124. doi:10.64081/mvmnts-5.1-2389.

<!-- borders-to-courts-142 -->

〔原刊 p. 23〕

Cantor, David, Tan, Nikolas Feith, Gkliati, Mariana, Mavropoulou, Elizabeth, Allinson, Kathryn, Chakrabarty, Sreetapa, Grundler, Maja, et al. 2022. “Externalization, Access to Territorial Asylum, and International Law.” *International J. of Refugee Law* 34(1): 120–56. doi:10.1093/ijrl/eeac023.

<!-- borders-to-courts-143 -->

〔原刊 p. 23〕

Casas-cortes, Maribel, Cobarrubias, Sebastian and Pickles, John. 2016. “‘Good Neighbours Make Good Fences’: Seahorse Operations, Border Externalization and Extra-Territoriality.” *European Urban and Regional Studies* 23(3): 231–51. doi:10.1177/0969776414541136.

<!-- borders-to-courts-144 -->

〔原刊 p. 23〕

Conant, Lisa. 2016. “Who Files Suit? Legal Mobilization and Torture Violations in Europe,” *Law & Policy* 38(4): 280–303. doi:10.1111/lapo.12055.

<!-- borders-to-courts-145 -->

〔原刊 p. 23〕

Costello, Cathryn and Mann, Itamar. 2020. “Border Justice: Migration and Accountability for Human Rights Violations.” *German Law J.* 21(3): 311–34. doi:10.1017/glj.2020.27.

<!-- borders-to-courts-146 -->

〔原刊 p. 23〕

Coutin, Susan Bibler. 2025. *On the Record: Papers, Immigration, and Legal Advocacy*. Oakland: University of California Press.

<!-- borders-to-courts-147 -->

〔原刊 p. 23〕

Coutin, Susan Bibler and Fortin, Véronique. 2023. “The Craft of Translation: Documentary Practices within Immigration Advocacy in the United States.” *PoLAR: Political and Legal Anthropology Rev.* 46(1): 24–38. doi:10.1111/plar.12531.

<!-- borders-to-courts-148 -->

〔原刊 p. 23〕

Crooke, Catherine 2024. “Frustration and Fidelity: How Public Interest Lawyers Navigate Procedure in the Direct Representation of Asylum Seekers.” *Law & Society Rev.* 58(2): 270–93. doi:10.1017/lsr.2024.20.

<!-- borders-to-courts-149 -->

〔原刊 p. 23〕

Cummings, Scott L. 2018. “The Social Movement Turn in Law.” *Law & Social Inquiry* 43(2): 360–416. doi:10.1111/lsi.12308.

<!-- borders-to-courts-150 -->

〔原刊 p. 23〕

Cummings, Scott L. 2020. “Movement Lawyering.” *Indiana J. of Global Legal Studies* 27(1): 87–130. doi:10.2979/indjglolegstu.27.1.0087.

<!-- borders-to-courts-151 -->

〔原刊 p. 23〕

Cunningham, Clark D. 1992. “Lawyer as Translator, Representation as Text: Towards an Ethnography of Legal Discourse.” *Cornell Law Rev.* 77(6): 1298–387.

<!-- borders-to-courts-152 -->

〔原刊 p. 23〕

Cusumano, Eugenio and Villa, Matteo. 2021. “From ‘Angels’ to ‘Vice Smugglers’: The Criminalization of Sea Rescue NGOs in Italy.” *European J. on Criminal Policy and Research* 27(1): 23–40. doi:10.1007/s10610-020-09464-1.

<!-- borders-to-courts-153 -->

〔原刊 p. 23〕

Davies, Thom, Isakjee, Arshad and Obradović-wochnik, Jelena. 2023. “Epistemic Borderwork: Violent Pushbacks, Refugees, and the Politics of Knowledge at the EU Border.” *Annals of the American Association of Geographers* 113(1): 169–88. doi:10.1080/24694452.2022.2077167.

<!-- borders-to-courts-154 -->

〔原刊 p. 24〕

El-Shaarawi, Nadine and Razsa, Maple. 2019. “Movements upon Movements: Refugee and Activist Struggles to Open the Balkan Route to Europe.” *History and Anthropology* 30(1): 91–112. doi:10.1080/02757206.2018.1530668.

<!-- borders-to-courts-155 -->

〔原刊 p. 24〕

Epp, Charles R. 1998. *The Rights Revolution: Lawyers, Activists, and Supreme Courts in Comparative Perspective*. Chicago: University of Chicago Press.

<!-- borders-to-courts-156 -->

〔原刊 p. 24〕

Epp, Charles R. 2011. “The Support Structure as a Necessary Condition for Sustained Judicial Attention to Rights: A Response.” *J. of Politics* 73(2): 406–09.doi: 10.1017/S0022381611000089.

<!-- borders-to-courts-157 -->

〔原刊 p. 24〕

Facchini, Duccio. 2020. “Rotta balcanica: Nel 2020 record di respingimenti dall’Italia verso la Slovenia.” Altreconomia, December 28 .

<!-- borders-to-courts-158 -->

〔原刊 p. 24〕

Fassin, Didier and D’halluin, Estelle. 2005. “The Truth from the Body: Medical Certificates as Ultimate Evidence for Asylum Seekers.” *American Anthropologist* 107(4): 597–608. doi:10.1525/aa.2005.107.4.597.

<!-- borders-to-courts-159 -->

〔原刊 p. 24〕

Felstiner, William L. F., Abel, Richard L. and Sarat, Austin. 1981. “The Emergence and Transformation of Disputes: Naming, Blaming, Claiming.” *Law & Society Rev.* 15: 631–54. doi:10.2307/3053505.

<!-- borders-to-courts-160 -->

〔原刊 p. 24〕

Fortarezza, Francesca. 2026. “Testing the Liberal Borders of the EU: (De)Constructing the Right of Asylum through Informality.” *Political Geography* 126: 103499. doi:10.1016/j.polgeo.2026.103499.

<!-- borders-to-courts-161 -->

〔原刊 p. 24〕

Gahleitner-gertz, Lukas. 2025. “Country Report: Austria. Update on 2024.” Asylum Information Database (AIDA), European Council on Refugees and Exiles, [https://asylumineurope.org/wp-content/uploads/2025/07/AIDA_AT_2024-Update.pdf] (accessed October 21 , 2025).

<!-- borders-to-courts-162 -->

〔原刊 p. 24〕

Gammeltoft-Hansen, Thomas. 2011. *Access to Asylum: International Refugee Law and the Globalisation of Migration Control*. Cambridge: Cambridge University Press. DOI: 10.1017/CBO9780511763403

<!-- borders-to-courts-163 -->

〔原刊 p. 24〕

Gammeltoft-hansen, Thomas and Tan, Nikolas Feith. 2021. “Extraterritorial Migration Control and Deterrence.” In *The Oxford Handbook of International Refugee Law*, edited by Costello, Cathryn, Foster, Michelle and McAdam, Jane, 502–17. Oxford: Oxford University Press. DOI: 10.1093/law/9780198848639.003.0028

<!-- borders-to-courts-164 -->

〔原刊 p. 24〕

Giuffré, Mariagiulia. 2020. *The Readmission of Asylum Seekers under International Law*. Oxford: Hart Publishing. DOI: 10.5040/9781509902514

<!-- borders-to-courts-165 -->

〔原刊 p. 24〕

Hameršak, Marijana. 2021. “Between Supporting and Reporting: Grassroots Textual Responses to the Pushbacks at the Fringes of EU.” *Intersections. East European J. of Society and Politics* 7(2): 49–72.

<!-- borders-to-courts-166 -->

〔原刊 p. 24〕

Hameršak, Marijana, Hess, Sabine, Speer, Marc and Stojić Mitrović, Marta. 2020. “The Forging of the Balkan Route: Contextualizing the Border Regime in the EU Periphery.” *Movements: J. for Critical Migration and Border Regime Studies* 5(1): 9–29. doi:10.64081/mvmnts-5.1-2385.

<!-- borders-to-courts-167 -->

〔原刊 p. 24〕

Italian Ministry of the Interior. 2020. “Question time alla Camera con il ministro Lamorgese”, [https://www.interno.gov.it/it/notizie/question-time-alla-camera-ministro-lamorgese-0] (accessed October 20 , 2025).

<!-- borders-to-courts-168 -->

〔原刊 p. 24〕

Italian Ministry of the Interior. 2021. Reply to the parliament inquiry. June 2020, https://www.asgi.it/wp-content/uploads/2020/08/Risposta-interpellanza-rotta-balcanica.pdf (accessed August 15 , 2025)

<!-- borders-to-courts-169 -->

〔原刊 p. 24〕

Jacobs, Marie and Maryns, Katrijn. 2022. “Managing narratives, managing identities: Language and credibility in legal consultations with asylum seekers.” *Language in Society* 51(3): 375–402. doi:10.1017/S0047404521000117.

<!-- borders-to-courts-170 -->

〔原刊 p. 24〕

Johan, Lindquist, Xiang, Biao and Yeoh, Brenda S. A.. 2012. “Opening the Black Box of Migration: Brokers, the Organization of Transnational Mobility and the Changing Political Economy in Asia.” *Pacific Affairs* 85(1): 7–19. doi:10.5509/20128517.

<!-- borders-to-courts-171 -->

〔原刊 p. 24〕

Jovanović, Teodora. 2020. “Transformations of Humanitarian Aid and Response Modes to Migration Movements: A Case Study of the Miksalište Center in Belgrade.” *Movements: J. for Critical Migration and Border Regime Studies* 5(1): 125–47. doi:10.64081/mvmnts-5.1-2390.

<!-- borders-to-courts-172 -->

〔原刊 p. 24〕

Kawar, Leila. 2015. *Contesting Immigration Policy in Court: Legal Activism and Its Radiating Effects in the United States and France*. Cambridge: Cambridge University Press. DOI: 10.1017/CBO9781107741980

<!-- borders-to-courts-173 -->

〔原刊 p. 24〕

Kawar, Leila. 2021. “Contesting Migration Governance through Legal Mobilization.” In *Handbook on the Governance and Politics of Migration*, edited by Carmel, Emma, Lenner, Katharina and Paul, Regine, 380–90. Cheltenham: Edward Elgar.

<!-- borders-to-courts-174 -->

〔原刊 p. 24〕

Kogovšek Šalamon, Neža, ed. 2020. *Causes and Consequences of Migrant Criminalization*. Cham: Springer. DOI: 10.1007/978-3-030-43732-9

<!-- borders-to-courts-175 -->

〔原刊 p. 24〕

Könönen, Jukka. 2018. “Border Struggles within the State: Administrative Bordering of Non-Citizens in Finland.” *Nordic J. of Migration Research* 8(3): 143–50. doi:10.2478/njmr-2018-0018.

<!-- borders-to-courts-176 -->

〔原刊 p. 24〕

Lacchei, Alice and Moraru, Madalina. 2026. “Asylum Access Adjudication: A Multi-Level Framework for Socio-Legal Research.” *J. of Refugee Studies* 39 (1) : 41–61. doi:10.1093/jrs/feaf069.

<!-- borders-to-courts-177 -->

〔原刊 p. 25〕

Lakhani, Sarah Morando. 2014. “From Problems of Living to Problems of Law: The Legal Translation and Documentation of Immigrant Abuse and Helpfulness.” *Law & Social Inquiry* 39(3): 643–65. doi:10.1111/lsi.12082.

<!-- borders-to-courts-178 -->

〔原刊 p. 25〕

Latour, Bruno. 2010. *The Making of Law: An Ethnography of the Conseil D’état*. Translated by Marina Brilman and Alain Pottage. Cambridge: Polity.

<!-- borders-to-courts-179 -->

〔原刊 p. 25〕

Lavenex, Sandra. 2022. The cat and mouse game of refugee externalisation policies. Between law and politics *Refugee Externalisation Policies. Responsibility, Legitimacy and Accountability* Azadeh Dastyari, Amy Nethery and Asher Hirsch 27–44. London: Routledge. DOI: 10.4324/9781003167273-3

<!-- borders-to-courts-180 -->

〔原刊 p. 25〕

Legomsky, Stephen H. 2003. “Secondary Refugee Movements and the Return of Asylum Seekers to Third Countries: The Meaning of Effective Protection.” *International J. of Refugee Law* 15(4): 567–677. doi:10.1093/ijrl/15.4.567.

<!-- borders-to-courts-181 -->

〔原刊 p. 25〕

Lejeune, Aude and Spire, Alexis. 2021. “The Role of Legal Intermediaries in the Dispute Pyramid: Inequalities before the French Legal System.” *International J. of Law in Context* 17(4): 455–72. doi:10.1017/S1744552321000513.

<!-- borders-to-courts-182 -->

〔原刊 p. 25〕

Mann, Itamar. 2013. “Dialectic of Transnationalism: Unauthorized Migration and Human Rights, 1993–2013.” *Harvard International Law J.* 54(2): 315–91.

<!-- borders-to-courts-183 -->

〔原刊 p. 25〕

Massimi, Adelaide. 2026. Guida pratica sul contenzioso strategico avverso i respingimenti nel Mediterraneo e per il diritto di ingresso. [https://www.asgi.it/wp-content/uploads/2026/01/guida-respingimenti-mediterraneo_DEF.pdf] (accessed March 25 , 2026).

<!-- borders-to-courts-184 -->

〔原刊 p. 25〕

Mather, Lynn and Yngvesson, Barbara. 1981. “Language, Audience, and the Transformation of Disputes.” *Law & Society Rev.* 15(3–4): 775–821. doi:10.2307/3053512.

<!-- borders-to-courts-185 -->

〔原刊 p. 25〕

Miaz, Jonathan, Odasso, Laura and Sabrié, Romane. 2021. “Le droit de la migration et ses intermédiaires: Usages sociopolitiques du droit et production des politiques migratoires. Présentation du dossier.” *Droit et Société* 107(1): 7–15. doi:10.3917/drs1.107.0007.

<!-- borders-to-courts-186 -->

〔原刊 p. 25〕

Michelson, Ethan. 2006. “The Practice of Law as an Obstacle to Justice: Chinese Lawyers at Work.” *Law & Society Rev.* 40(1):1–38. doi:10.1111/j.1540-5893.2006.00257.x.

<!-- borders-to-courts-187 -->

〔原刊 p. 25〕

Miller, Richard E. and Sarat, Austin. 1980–1981. “Grievances, Claims, and Disputes: Assessing the Adversary Culture.” *Law & Society Rev*. 15: 525–66. doi:10.2307/3053502.

<!-- borders-to-courts-188 -->

〔原刊 p. 25〕

Mitrović, Marta Stojić and Vilenica, Ana. 2019. “Enforcing and Disrupting Circular Movement in an EU Borderscape: Housingscaping in Serbia.” *Citizenship Studies* 23(6): 540–58. doi:10.1080/13621025.2019.1634368.

<!-- borders-to-courts-189 -->

〔原刊 p. 25〕

Moraru, Madalina and Reyhani, Adel-Naim. 2026. “Evading EU Law through Summary Returns at Internal Borders: Practice, Legality and the Role of Courts.” *Common Market Law Rev.* 63(2): 413–54. doi:10.54648/COLA2026001.

<!-- borders-to-courts-190 -->

〔原刊 p. 25〕

Moreno-lax, Violeta. 2024. “Meta-Borders and the Rule of Law: From Externalisation to ‘Responsibilisation’ in Systems of Contactless Control.” *Netherlands International Law Rev.* 71: 21–57. doi:10.1007/s40802-024-00257-5.

<!-- borders-to-courts-191 -->

〔原刊 p. 25〕

Border Violence Monitoring Network. 2024. Annual Report 2024, https://borderviolence.eu/uploads/publication/document/8/Annual_Report_2024.pdf (accessed March 24 , 2026).

<!-- borders-to-courts-192 -->

〔原刊 p. 25〕

Olesen, Annette and Hammerslev, Ole. 2023. “The Dynamic and Iterative Pre-Dispute Phase: The Transformation from a Justiciable Problem into a Legal Dispute.” *J. of Law and Society* 50(1): 120–38. doi:10.1111/jols.12411.

<!-- borders-to-courts-193 -->

〔原刊 p. 25〕

Passalacqua, Virginia. 2022. “Who Mobilizes the Court? Migrant Rights Defenders Before the Court of Justice of the EU.” *Law and Development Rev.* 15(2): 381–405. doi:10.1515/ldr-2021-0102.

<!-- borders-to-courts-194 -->

〔原刊 p. 25〕

Pélisse, Jérôme. 2019. “Varieties of Legal Intermediaries: When Nonlegal Professionals Act as Legal Intermediaries.” In *Legal Intermediation: A Processual Approach to Law and Economic Activity*, edited by Sarat, Austin, 101–28. Bingley: Emerald. DOI: 10.1108/S1059-433720190000081005

<!-- borders-to-courts-195 -->

〔原刊 p. 25〕

Pijnenburg, Annick and Van der Pas, Kris. 2022. “Strategic Litigation against European Migration Control Policies: The Legal Battleground of the Central Mediterranean Migration Route.” *European J. of Migration and Law* 24(3): 401–29. DOI: 10.1163/15718166-12340135

<!-- borders-to-courts-196 -->

〔原刊 p. 25〕

Pörtner, Ephraim. 2021. *Re-Cording Lives: Governing Asylum in Switzerland and the Need to Resolve*. Bielefeld: transcript Verlag. DOI: 10.14361/9783839453490

<!-- borders-to-courts-197 -->

〔原刊 p. 25〕

Reyhani, Adel-Naim. 2021. “Anomaly upon Anomaly: The 1951 Convention and State Disintegration.” *International J. of Refugee Law* 33(2): 277–99. doi:10.1093/ijrl/eeab042.

<!-- borders-to-courts-198 -->

〔原刊 p. 26〕

Riva, Sara and Hoffstaedter, Gerhard. 2021. “The Aporia of Refugee Rights in a Time of Crises: The Role of Brokers in Accessing Refugee Protection in Transit and at the Border.” *Comparative Migration Studies* 9(1): 1–17. DOI: 10.1186/s40878-020-00212-2

<!-- borders-to-courts-199 -->

〔原刊 p. 26〕

Shachar, Ayelet. 2020. *The Shifting Border: Legal Cartographies of Migration and Mobility*. Manchester: Manchester University Press. DOI: 10.7765/9781526145321

<!-- borders-to-courts-200 -->

〔原刊 p. 26〕

Southworth, Ann. 2000. “The Rights Revolution and Support Structures for Rights Advocacy.” *Law & Society Rev.* 34(4): 1203–19. DOI: 10.2307/3115134

<!-- borders-to-courts-201 -->

〔原刊 p. 26〕

Sterett, Susan M. 2016. “Legal Mobilization and Juridification: Migration as a Central Case.” *Law & Policy* 38(4): 273–79. DOI: 10.1111/lapo.12063

<!-- borders-to-courts-202 -->

〔原刊 p. 26〕

Talesh, Shauhin A. 2015. “Legal Intermediaries: How Insurance Companies Construct the Meaning of Compliance with Anti-Discrimination Laws.” *Law & Policy* 37(3): 209–39. DOI: 10.1111/lapo.12037

<!-- borders-to-courts-203 -->

〔原刊 p. 26〕

Tan, Nikolas Feith and Gammeltoft-Hansen, Thomas. 2020. “A Topographical Approach to Accountability for Human Rights Violations in Migration Control.” *German Law J.* 21(3): 335–54. doi:10.1017/glj.2020.31.

<!-- borders-to-courts-204 -->

〔原刊 p. 26〕

Tazzioli, Martina. 2021. “‘Choking without killing’: Opacity and the grey area of migration governmentality.” *Political Geography* 89: 102412. doi:10.1016/j.polgeo.2021.102412.

<!-- borders-to-courts-205 -->

〔原刊 p. 26〕

Thomas, Gammeltoft-Hansen and Hathaway, James C.. 2014. “Non-Refoulement in a World of Cooperative Deterrence.” *Columbia J. of Transnational Law* 53(2): 235–84.

<!-- borders-to-courts-206 -->

〔原刊 p. 26〕

Timmermans, Stefan and Tavory, Iddo. 2012. “Theory Construction in Qualitative Research: From Grounded Theory to Abductive Analysis.” *Sociological Theory* 30(3): 167–86. doi:10.1177/0735275112457914.

<!-- borders-to-courts-207 -->

〔原刊 p. 26〕

Trucco, Daniela. 2023. “The Criminalization of Border Solidarity and the Law as a Double-Edged Weapon.” *Partecipazione & Conflitto* 16(3): 470–89.

<!-- borders-to-courts-208 -->

〔原刊 p. 26〕

Trucco, Daniela, Lamarche, Karine and Philippe, Oriana. 2023. “À la frontière du droit: Usages du droit en solidarité avec les migrants aux frontières.” *Droit et Société* 113(1): 181–202. doi:10.3917/drs1.113.0181.

<!-- borders-to-courts-209 -->

〔原刊 p. 26〕

Tuckett, Anna. 2018. “Ethical Brokerage and Self-Fashioning in Italian Immigration Bureaucracy.” *Critique of Anthropology* 38(3): 245–64. doi:10.1177/0308275X18775199.

<!-- borders-to-courts-210 -->

〔原刊 p. 26〕

UN Special Rapporteur on the human rights of migrants. 2021. “Report on means to address the human rights impact of pushbacks of migrants on land and at sea. Report of the Special Rapporteur on the human rights of migrants.” A/HRC/47/30, 12 May 2021.

<!-- borders-to-courts-211 -->

〔原刊 p. 26〕

Van der Pas, Kris. 2023. “Legal Mobilization in the Field of Asylum Law: A Revival of Political Opportunity Structures?” *Recht der Werkelijkheid* 44(3): 14–31. doi:10.5553/RdW/138064242023044003002.

<!-- borders-to-courts-212 -->

〔原刊 p. 26〕

Vanhala, Lisa. 2012. “Legal Opportunity Structures and the Paradox of Legal Mobilization by the Environmental Movement in the UK.” *Law & Society Rev*. 46(3): 523–56. doi:10.1111/j.1540-5893.2012.00505.x.

<!-- borders-to-courts-213 -->

〔原刊 p. 26〕

Vanhala, Lisa. 2018. “Is Legal Mobilization for the Birds? Legal Opportunity Structures and Environmental Nongovernmental Organizations in the United Kingdom, France, Finland, and Italy.” *Comparative Political Studies* 51(3): 380–412. doi:10.1177/0010414017710257.

<!-- borders-to-courts-214 -->

〔原刊 p. 26〕

Zocchi, Benedetta. 2024. “The Game: Ritualized Exhaustion and Subversion on the Western Balkan Route.” *J. of Borderlands Studies* 39(5): 875–95. doi:10.1080/08865655.2023.2229846.

<!-- borders-to-courts-215 -->

〔原刊 p. 26〕

Zoppi, Marco and Puleri, Massimiliano. 2022. “The Balkan Route (and Its Afterlife): The New Normal in the European Politics of Migration.” *J. of Balkan and Near Eastern Studies* 24(3): 576–93 doi:10.1080/19448953.2021.2015658.

<!-- borders-to-courts-228 -->

〔原刊 p. 26〕

## Cases cited

<!-- borders-to-courts-216 -->

〔原刊 p. 26〕

## Italy:.

<!-- borders-to-courts-217 -->

〔原刊 p. 26〕

Tribunale di Roma, N.R.G. 56420/2020, 18 January 2021a.

<!-- borders-to-courts-218 -->

〔原刊 p. 26〕

Tribunale di Roma, N.R.G. 7045/2021, 27th April 2021b.

<!-- borders-to-courts-219 -->

〔原刊 p. 26〕

Tribunale di Roma, N.R.G. 3938/2022, 9th May 2023.

<!-- borders-to-courts-220 -->

〔原刊 p. 26〕

## Austria:.

<!-- borders-to-courts-221 -->

〔原刊 p. 26〕

Verwaltungsgerichtshof (VwGH), Ra 2021/21/0274, 5 May 2022a.

<!-- borders-to-courts-222 -->

〔原刊 p. 27〕

Verwaltungsgerichtshof (VwGH), Ra 2022/21/0074, 19 May 2022b.

<!-- borders-to-courts-223 -->

〔原刊 p. 27〕

Landesverwaltungsgericht Steiermark (LVwG), 20.3-2725/2020-86, 1 July 2021.

<!-- borders-to-courts-224 -->

〔原刊 p. 27〕

Landesverwaltungsgericht Steiermark (LVwG), 20.3-2621/2021-49, 16 February 2022.

<!-- borders-to-courts-229 -->

〔原刊 p. 27〕

## Statutes cited

<!-- borders-to-courts-225 -->

〔原刊 p. 27〕

Austria. 2005. Federal Act Concerning the Granting of Asylum (Asylgesetz 2005; AsylG 2005). Federal Law Gazette I No. 100/2005, section 15.

<!-- borders-to-courts-226 -->

〔原刊 p. 27〕

Italy. 1947. Constitution of the Italian Republic. Gazzetta Ufficiale della Repubblica Italiana, no. 298, 27 December 1947 (edizione straordinaria).

<!-- borders-to-courts-227 -->

〔原刊 p. 27〕

Italy. 1940. Codice di procedura civile. Regio Decreto 28 October 1940, no. 1443, art. 700.

<!-- borders-to-courts-114 -->

〔原刊 p. 27〕

## Appendix (list of interviews)

<!-- borders-to-courts-115 -->

〔原刊 p. 27〕

Interview 1. *Lawyer active in a national legal association, pursuing strategic litigation in the migration field, and a consultant for a local NGO*, Italy, 7 April 2025.

<!-- borders-to-courts-116 -->

〔原刊 p. 27〕

Interview 2. *Activist in a local NGO involved in advocacy and monitoring along the Balkan route*, Italy, 14 April 2025.

<!-- borders-to-courts-117 -->

〔原刊 p. 27〕

Interview 3. *Lawyer active in a national legal association, pursuing strategic litigation in the migration field.* Italy, 28 April 2025.

<!-- borders-to-courts-118 -->

〔原刊 p. 27〕

Interview 4. *Journalist and photo-reporter working for several international media*, Italy, 5 May.

<!-- borders-to-courts-119 -->

〔原刊 p. 27〕

Interview 5. Two *activists who established a national hotline for first contact in case of pushbacks*, Austria, 29 April 2025.

<!-- borders-to-courts-120 -->

〔原刊 p. 27〕

Interview 6. *Lawyer and national NGO coordinator, specialized in asylum and migration*, Austria, 23 July 2025.

<!-- borders-to-courts-121 -->

〔原刊 p. 27〕

Interview 7. *Former judge in a regional administrative court*, Austria, 22 June 2024.

<!-- borders-to-courts-122 -->

〔原刊 p. 27〕

Interview 8. *Lawyer and attorney specialized in asylum, migration, and police conduct*, Austria, 24 June 2024.

<!-- borders-to-courts-123 -->

〔原刊 p. 27〕

Interview 9. *Lawyer, within an NGO, specialized in asylum and migration*, Slovenia, 23 May 2025.

<!-- borders-to-courts-230 -->

〔原刊 p. 27〕

## About the authors

<!-- borders-to-courts-231 -->

〔原刊 p. 27〕

Alice Lacchei (corresponding author) is a postdoctoral researcher at the Department of Political and Social Sciences of the University of Bologna within the ERC Starting Grant “Gatekeepers to international refugee law? – The role of courts in shaping access to asylum” project, where she conducts research on the role of courts in shaping access to asylum in Greece. Her research interests include socio-legal research on migration and courts, migration policy implementation, and judicialization of migration policy. alice.lacchei2@unibo.it.

<!-- borders-to-courts-232 -->

〔原刊 p. 27〕

Adel-Naim Reyhani is a postdoctoral researcher at the Ludwig Boltzmann Institute of Fundamental and Human Rights (LBI-GMR), PI of the research project “Externalization and Rightlessness,” and scientific lead for the contribution of the LBI-GMR to the ERC Starting Grant ACCESS project. adel-naim.reyhani@univie.ac.at.

## 编者说明 / Editorial notes

pushback 译为推回，指原文界定的未经事先评估风险或保护需求而强制移出领土；non-refoulement 单独译为不推回原则。readmission 译为重新接收；case misalignment 译为案件错位；case assembly 译为案件组装；legal intermediaries 译为法律中介者。hostile setting 译为充满阻碍的环境，以表达文中对诉讼不利的制度与实际条件。

claimant 采用诉请人，具体引文中的 complainant 译为申诉人，applicant 译为申请人。原文在不同国内程序中使用 appeal，中文依语境译为上诉或提出诉请，避免把所有首次向法院提出的程序都误当作上诉。mandate 与 power of attorney 按语境译为授权或授权委托书；apostille 译为附加证明书。

英文以出版方 HTML 为底本，斜体照录。书目区的 Cases cited、Statutes cited 分组标题已恢复，Italy 与 Austria 按国家小标题处理；共91条文献、7项判例、3项法规。附录按照原刊 PDF 的顺序放在书目、判例和法规之后。两位作者简介从原刊第27页补回；‘作者简介’为本版添加的组织性标题。页码指原刊段落或条目的起始页，跨页内容不拆分。

书目保留原始检索信息，并附题名或条目译释；译释不意味着存在正式中译本。HTML 中与前文粘连的 DOI 补加分隔符。HTML 与 PDF 中部分合著者姓名次序不同，本版书目统一按 HTML 照录，不据此更改文内引文。

原文引言有重复的 Case studies、Pélisse 2019, 2019 及多余引号。英文保留；中文结构介绍按句意表达，重复年份仍保留。正文中的 Lavenex 2023 与书目中的2022未自行统一；Italian Ministry of the Interior 2021 条目内又写 June 2020，均照录。

访谈3引文出现 readmitted [the claimant] times 的异常占位形式，本译文保留为‘重新接收[诉请人]次’，不自行推定次数。访谈2引文将地点写作 Biaz，其他段落多为 Bihać；引文提及在的里雅斯特的月份为9月，前文个案叙述另有7月及10月，均保留原文写法。

附录访谈4仅列5月5日、未列年份，访谈7和8列2024年，其余多为2025年；本版不替作者补年份或统一日期。作者未访谈诉请人，因此有关诉请人能动性的材料为间接叙述；译文完整保留这一方法限制。数据可用性声明中的 on paper 按‘以纸面形式提供’译出，不推定为公开数据链接。
