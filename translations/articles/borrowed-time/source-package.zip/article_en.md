# Borrowed Time: Sovereign Debt and Temporal Disorder In Socialist Yugoslavia

James M Robertson. History, University of California Irvine, Irvine, California, USA. Email: jamesmr1@uci.edu. Comparative Studies in Society and History (2026), 1–22. Published online: 15 October 2026.

https://doi.org/10.1017/S0010417526100723

据Cambridge University Press出版方HTML完整翻译，并与22页原刊PDF核对结构及段落起始页码。保留摘要、全部正文、致谢及66条原注；无独立书目或图表。原注论述完整翻译，书目信息照录并附中文题名译释。© The Author(s), 2026；Cambridge University Press代表Society for the Comparative Study of Society and History出版。原文及本译文采用CC BY-NC 4.0，仅限非商业使用；商业使用须事先取得出版社或权利人书面许可。翻译、译释及编者说明为本版新增；AI辅助工作译稿，不代表作者或出版社认可。

CC BY-NC 4.0: https://creativecommons.org/licenses/by-nc/4.0/

Keywords: temporality; Cold War; Yugoslavia; debt; end of history; cinema; nationalism; Serbia; memory; regime of historicity

<!-- borrowed-time-001 -->

〔原刊 p. 1〕

## Abstract

<!-- borrowed-time-002 -->

〔原刊 p. 1〕

When Francis Fukuyama described the collapse of state socialism as marking the “end of history,” he captured the imagination of the post-Cold War moment, rendering the fall of the Berlin Wall a metonym for the definitive eclipse of communism and the advent of a new era of liberal capitalist hegemony. For Europe’s Left, the term became associated with a moment of profound demoralization. Fukuyama’s end of history, however, was only one moment of a longer and more expansive crisis in the socialist order of time. This crisis can be traced back to the global economic upheavals of the 1970s that impacted both social democracy in the West and state socialism in the East. A decade before crowds forced their way across a divided Berlin, socialism on both sides of the Iron Curtain had entered an existential decline. This article argues that the sovereign debt crises that beset European states in the final decade of the Cold War disrupted socialism’s regime of historicity. It develops this argument with reference to late-socialist Yugoslavia and demonstrates how the temporal conditions of sovereign indebtedness shaped popular culture. Through a reading of the films *Balkanski špijun* (1984) and *Već viđeno* (1987), the article argues that the erosion of socialism’s horizons of expectation fostered a new experience of historical time in which the past returned in uncanny, troubling, and ultimately destructive ways.

<!-- borrowed-time-003 -->

〔原刊 p. 1〕

## Introduction

<!-- borrowed-time-004 -->

〔原刊 p. 1〕

Srđan Dragojević’s 1996 war drama, *Lepa sela lepo gore* (*Pretty Village, Pretty Flame*), is one of the more ideologically fraught accounts of the violent breakup of Yugoslavia. The film depicts a Serb unit fighting in Eastern Bosnia, which is ambushed and forced to take shelter in an abandoned tunnel. While they await rescue, the plot explores the motivations that led each of the soldiers to join the war, and in the process traces their contradictory assessments of Yugoslavia and its legacy.

<!-- borrowed-time-005 -->

〔原刊 p. 2〕

One especially weighty scene sets up a striking contrast between the socialist myth of Yugoslavia and its cynical everyday reality. This contrast is staged through a confrontation between the unit’s aged commander, Captain Gvozden, played by the illustrious Bata Živojinović, and the conscripted soldier, Velja, played by the comedic heartthrob Nikola Kojo. Gvozden and Velja represent the myth and the reality of Yugoslavia. Gvozden is a one-time partisan commander, a symbol of the revolutionary idealism of the anti-fascist struggle of World War II. Velja, in contrast, is a symbol of Yugoslavia’s failed promise, a social outcast who has escaped a life of unemployment by emigrating to the West and pursuing a career in crime. When Gvozden berates Velja for “robbing little old grannies in Germany” of their “honorably earned money,” Velja responds with a bitter indictment of Gvozden and, by extension, the entire Yugoslav project:

<!-- borrowed-time-006 -->

〔原刊 p. 2〕

Your famous honor. You were always full of that shit about honor. Mr. Captain, do you think that a single one of their [Muslims’] houses that we burned, or of ours that they burned was honorably earned [*pošteno zarađena*]? Like hell they were. If they were honorably earned, then it wouldn’t be so easy to burn them.

<!-- borrowed-time-007 -->

〔原刊 p. 2〕

So long as that cripple Zagorac [President Tito] stuffed American dollars up your ass, you knew how to spout on about “brotherhood and unity” and smile at one another…. But then, then the time came to settle the bills [*svedete račune*]. No problem. But why didn’t you settle them earlier? Instead, you jerked off for fifty years, for fifty years you drove expensive cars and banged the best pussy…. And now, now that you can’t get it up [*sad kad se kita više ne diže*], now you concern yourselves with a little honor. Well, I mock that honor of yours, and your whole “honorable” generation.

<!-- borrowed-time-008 -->

〔原刊 p. 2〕

The monologue is a sudden change of tone for the character. For much of the film, Velja is presented as a suave and sly buffoon, carefree and flippant, bragging about his sexual and criminal escapades. This scene speaks to a deeper sense of bitterness and betrayal among a younger generation of working-class Yugoslavs who came of age in the final, crisis-stricken decade of the country.

<!-- borrowed-time-009 -->

〔原刊 p. 2〕

Velja’s account of socialist Yugoslavia as a naïve attempt to resolve the endemic nationalist hatreds of the region was a well-worn trope by the time the film was released. This ideological motif became widespread in the decade before the country was torn apart by ethnic war. Starting as early as 1981, opposition intellectuals began to interrogate the founding myths of the socialist state, especially those that anchored the unification of the multiethnic country in the anti-fascist struggle of World War II. These revisionist accounts often sought to discredit the regime’s socialist rhetoric of “brotherhood and unity” as cynical at best, dangerously utopian at worst. Velja’s suggestion that the creation of Yugoslavia had merely forestalled an inevitable ethnic reckoning among its constituent peoples was hardly novel.

<!-- borrowed-time-010 -->

〔原刊 p. 2〕

What is significant about the monologue, however, is the way in which it located the ethnic conflict of the 1990s in a particular experience of temporal disorder linked to sovereign debt. The war in Bosnia, to Velja’s mind, is a war deferred. The violence between Serbs, Muslims, and Croats in the 1990s was a resumption of a conflict that began in the 1940s. The opportunity to resolve the earlier conflicts of World War II, however, had been thwarted by the communists and their naïve ideas of multinational unity. Buoyed by their access to international loans, Yugoslavia’s communists had been able to forestall the ethnic war, to pervert the “natural” course of history. But when the debt came due, the state collapsed, and the violence of the past resumed. Framed through this strange temporal lens, socialist Yugoslavia was understood to have been a country living on *borrowed time.* In Velja’s telling, credit had the power to forestall history; events could be left unresolved, suspended in time, and the past always risked opening an abyss beneath the present.

<!-- borrowed-time-011 -->

〔原刊 p. 3〕

Velja’s monologue demonstrates how the breakup of Yugoslavia was rooted in a crisis of the socialist order of time. In this crisis, a temporal regime characterized by a powerful sense of historical progression and oriented toward a future of ethnic harmony gave way to an experience of historical stagnation, in which the ghosts of an unresolved and violent past haunted the present. Crucially, for this article, his image of a country living on borrowed time illustrated how Yugoslavia’s sovereign debt crisis brought about a new experience of historical time that eroded the ideological foundations of the socialist state.

<!-- borrowed-time-012 -->

〔原刊 p. 3〕

By attending to the temporal dimension of Yugoslavia’s debt crisis and by analyzing its articulation in the cultural production of late socialism, this article offers an answer to a major question in Yugoslav historiography: How were the social tensions unleashed by the economic crisis of the 1980s transposed into an ethnic conflict? While scholars have long pointed to the economic decline of the late-socialist period as the basis of the rise in nationalist sentiment, the precise ideological mechanisms by which this transposition was effected remain undertheorized.[^borrowed-time-1] I argue that this ideological transposition from the economic to the ethnic was made possible by the temporal dynamics of the sovereign debt crisis that beset Yugoslavia over the course of the 1980s. This crisis disrupted the temporal order that underpinned the socialist project. It narrowed the horizons of possibility, undermining the anticipated future toward which the ruling party had oriented society, and dredged up a past that had once seemed put to rest.

<!-- borrowed-time-013 -->

〔原刊 p. 3〕

The temporal disorientation that took root in late-socialist Yugoslavia was reflected in the explosion of historical revisionism during the 1980s that questioned the state’s official historiography and fostered a new cultural memory of World War II and its aftermath. This phenomenon has typically been read as evidence of a rising wave of nationalist discontent, given that these revisionist accounts so often served as a vehicle through which to articulate various ethnic grievances against the Yugoslav project.[^borrowed-time-2] However, this article argues that these nationalist attacks on the state’s historical memory were but one expression of a deeper and more pervasive rupture in the socialist regime of historicity that took place in the final decade of the Cold War.[^borrowed-time-3]

<!-- borrowed-time-014 -->

〔原刊 p. 4〕

To demonstrate this claim, I move away from the intellectual debates that have preoccupied historians of this era and instead turn to the field of popular culture where this new temporal condition found widespread expression in Yugoslav society. I examine two films that staged the temporal upheavals of the era outside a nationalist framing: Dušan Kovačević and Božidar Nikolić’s 1984 comedy, *Balkanski špijun* (*The Balkan Spy*), and Goran Marković’s 1987 psychological thriller, *Već viđeno* (*Déjà vu*). While both films demonstrate how the corrosive effects of foreign debt led to a preoccupation with interrogating the founding historical myths of the state itself, they eschewed the kind of nationalist tropes that characterized the historiographical debates of the 1980s. Nationalism, to put it more directly, was downstream of a more seismic fracturing of historical time brought on by the conditions of a sovereign debt crisis.

<!-- borrowed-time-015 -->

〔原刊 p. 4〕

Reinterpreting Yugoslavia’s dissolution as a breakdown of socialist historicity offers a new perspective on what has rather grandiosely come to be termed the “end of history.” Although Francis Fukuyama initially revived this Hegelian concept to describe the sense of ideological closure that attended the collapse of state socialism in Eastern Europe and the Soviet Union, there is good reason to reconceptualize the end of history and its place in the late-twentieth-century chronoscape.[^borrowed-time-4] I argue that Fukuyama’s thesis is better understood as evidence of a broader temporal condition that emerged in the aftermath of the global economic transformations of the 1970s. The fallout from this decade’s turbulence led to the massive influx of private capital into world financial markets and the subsequent growth of huge and, ultimately, unsustainable levels of foreign debt across Europe. As governments on both sides of the Iron Curtain were forced to pursue fiscal discipline and austerity, they blew apart both the Keynesian and state socialist political-economic models upon which their postwar orders had been built.[^borrowed-time-5]

<!-- borrowed-time-016 -->

〔原刊 p. 4〕

Precisely because it witnessed the abandonment of large-scale efforts to transform, regulate, or bypass the economic logics of capitalism, this historical juncture had a devastating effect on Europe’s Left, fostering a profound sense of political disorientation and disillusionment.[^borrowed-time-6] What this article hopes to demonstrate is that the collapse of socialism’s regime of historicity should not be dated to the revolutionary events of 1989 but situated within the longer temporal dynamics of the debt crises that followed the global economic shocks of the 1970s.

<!-- borrowed-time-017 -->

〔原刊 p. 4〕

Yugoslavia is often considered an outlier in the history of the Cold War in Europe. A socialist state that turned against the Soviet Union, it straddled the ideological and geopolitical division of the continent. Yet read through the lens of temporality and debt, the country’s experience is illustrative of the historical connections between the emergence of a new neoliberal mode of globalization and the ideological corrosion of socialist regimes in the final decade of the Cold War.[^borrowed-time-7] Far from being an outlier, Yugoslavia is especially illustrative of this historical process. Indeed, as a state governed by socialist ideology but deeply integrated in and sensitive to the dynamics of the global financial system, it offers a unique vantage point from which to examine debt’s role in disrupting and throwing into crisis socialism’s experience of historical time.

<!-- borrowed-time-018 -->

〔原刊 p. 5〕

## The End of History or a Crisis of Historicity?

<!-- borrowed-time-019 -->

〔原刊 p. 5〕

In 1992, the political theorist Francis Fukuyama famously described the collapse of state socialist regimes in Eastern Europe as marking the “end of history.” His phrase captured the imagination of the immediate post-Cold War moment, giving expression to a certain liberal triumphalism that celebrated the denouement of the ideological rivalry between capitalism and communism. The fall of the Berlin Wall became a metonym for the definitive eclipse of communism and the advent of a new era of liberal capitalist hegemony around the world.[^borrowed-time-8] For Europe’s Left, this was a moment of profound demoralization and ideological disorientation. Although many leftists around the world had long been disillusioned with the bureaucratic socialism of the Soviet Union and its satellites in Eastern Europe, the continued existence of these states seemed to affirm the viability of non-capitalist economic systems. So long as these states existed, they helped to sustain a field of possibilities in which alternative political and social forms might be imagined and pursued. The eclipse of state socialism radically narrowed that field, unmooring the Left’s utopian impulses from any sense of historical concreteness.[^borrowed-time-9]

<!-- borrowed-time-020 -->

〔原刊 p. 5〕

Yet the disillusionment and disorientation of Europe’s Left in this moment exceeds the framework of Fukuyama’s “end of history.” Well before crowds forced their way across a divided Berlin, social democracy in Western Europe had entered what would become an existential crisis.[^borrowed-time-10] The failure of Keynesian economics to resolve the stagflation of the late 1970s, the subsequent rise of Margaret Thatcher and Ronald Reagan, and the defeat of labor movements had shaken the Western Left to its core.[^borrowed-time-11] In this sense, the experience of the Left’s historical defeat clearly predated the revolutionary events of 1989 and must be located in processes that exceeded the breakdown of state socialism. Christopher Bickerton has recently observed that the decades that immediately bracketed the end of the Cold War witnessed the implosion of a range of political, economic, and cultural forms that had dominated European societies since the end of World War II. This implosion was not limited to the collapse of state socialist regimes in the East, but also the more gradual dismantling of Keynesian economies in the West and the hollowing out of mass political parties, trade unions, and civic associations that had anchored postwar political systems.[^borrowed-time-12] The years surrounding 1989, therefore, were a crucial historical juncture in the transformation of Europe’s societies, economies, and political orders.

<!-- borrowed-time-021 -->

〔原刊 p. 6〕

These transformations had a profound impact on the European Left’s experience of historical time. Far from a conclusive resolution of world history, as Fukuyama narrated it, this experience is perhaps better understood as the collapse of history as a site of meaning, purpose, and direction. During the final decade of the Cold War, the regime of historicity that had structured the European Left’s experience of historical time since the late nineteenth century broke down. Writing of this experience, Enzo Traverso describes the onset of a “left-wing melancholia” characterized by a pervasive sense of historical closure and an almost existential feeling of defeat.[^borrowed-time-13] The Left had, of course, experienced loss in the past. Indeed, much of left-wing culture in the twentieth century was characterized by an almost obsessive commemoration of earlier defeats, from the martyrs of the Paris Commune to the heroic death of Che Guevara in the jungles of Bolivia. But these earlier defeats had not disrupted socialism’s temporal horizons. Indeed, they often fueled the utopian impulses that gave momentum to its future-oriented experience of history. The profound sense of historical stagnation that beset the final decade of the Cold War, however, struck at the very foundations of socialism’s temporal order. As the horizons of possibility appeared to be exhausted by an increasingly unregulated capitalism, visions of alternative social orders appeared ever more vacant and ethereal.

<!-- borrowed-time-022 -->

〔原刊 p. 6〕

If in the West socialism’s crisis of historicity led to the disorientation of the parties of the Left, in Europe’s East it shook the ideological foundations of the state itself. State power offered socialists few resources with which to withstand the new temporal conditions or to rejuvenate their experience of historical time. On the contrary, the dissolution of socialism’s historical horizons compounded a deeper sense of bureaucratic stagnation and further undermined the ideological legitimacy of the party states. As the 1980s progressed, these regimes increasingly appeared anachronistic, out of sync with the temporal rhythms of the present.

<!-- borrowed-time-023 -->

〔原刊 p. 6〕

Across both sides of the Iron Curtain, this moment of temporal rupture was experienced not as the end of history so much as its traumatic, contentious, and unsettling *return.* The decades that bracketed the end of the Cold War witnessed a new preoccupation with historical memory.[^borrowed-time-14] In Western Europe, this centered on the horrors of the twentieth century, in particular the Holocaust and its place in European and national histories.[^borrowed-time-15] In Eastern Europe, the return of history was reflected in the explosion of strange nationalist rituals involving the excavation and reburial of controversial historical figures in the years surrounding 1989.[^borrowed-time-16] The explosion of historical revisionism in Yugoslavia in the 1980s should also be understood within this broader European context of the new culture of historical memory. It is hardly surprising that a crisis of historicity would foster a renewed concern with the past. With the closure of socialism’s horizon of expectation, the present became haunted by the specters of the past. As Traverso observes, “a world without utopias inevitably looks back.”[^borrowed-time-17] It is perhaps for this reason that during this period the Holocaust was universalized into a symbolic warning of the dangers posed by *all* utopian ideologies.[^borrowed-time-18] In this new culture of historical memory, socialism became reduced to the totalitarian violence of the twentieth century, further dissolving and discrediting the emancipatory hopes it had once sustained.[^borrowed-time-19]

<!-- borrowed-time-024 -->

〔原刊 p. 7〕

To take stock of the argument thus far, the final decade of the Cold War was characterized by a novel temporal condition that was felt with particular sensitivity by the European Left on both sides of the Iron Curtain. The onset of this condition preceded the revolutionary events of 1989 by almost a decade and was characterized by the narrowing of historical horizons, a profound sense of temporal stasis or stagnation, and a renewed concern with revisiting the traumatic events of the twentieth century. It led to a sense of temporal disorientation that precipitated deep political crises in both the electoral parties of the Western Left and the state socialist regimes of Eastern Europe. To what can we attribute this temporal crisis? What structures, processes, or events could precipitate a common experience of historical disorientation across Europe’s Cold War frontier? The answer, I believe, lies in the new conditions of sovereign indebtedness that followed the global economic turbulence of the 1970s.

<!-- borrowed-time-025 -->

〔原刊 p. 7〕

## Sovereign Debt and Temporal Disorder

<!-- borrowed-time-026 -->

〔原刊 p. 7〕

In a groundbreaking study of the end of the Cold War, Fritz Bartel has convincingly demonstrated how the crisis of state socialism in Eastern Europe was bound up with and exacerbated by the historical emergence of a neoliberal economic order at the end of the 1970s. His account foregrounds the impact of the OPEC oil embargo of 1973, which had two long-term consequences. First, it rapidly increased the price of oil, leading to generalized inflation across global supply chains.[^borrowed-time-20] Second, the sudden increase in oil revenues brought a flood of funds into international financial institutions that sought profitable investments. With easier access to cheap international credit, developing states, including those of socialist Eastern Europe, borrowed heavily to offset the costs incurred by rising inflation and to finance an expansion of industry. This wave of cheap credit masked a generalized crisis of profitability in the global capitalist system. It helped to sustain both Western social democratic and Eastern state socialist projects and to forestall the impact of the “long downturn” on their national economies.[^borrowed-time-21]

<!-- borrowed-time-027 -->

〔原刊 p. 8〕

These years of credit-fueled growth came to a sudden crash in 1979 when the chair of the U.S. Federal Reserve, Paul Volcker, raised interest rates on the dollar in an effort to control rising inflation. Overnight, governments around the world found themselves weighed down by unsustainable obligations on dollar-denominated loans. In Europe, the heavy rates of borrowing over the 1970s and the subsequent “Volcker Shock” precipitated deep economic crises in both capitalist and socialist economies. When faced with ballooning foreign debt payments, governments found themselves under pressure to break the social contract between labor and the state that had underpinned their economies since the end of World War II. Desperate to meet their loan obligations, debtor states were compelled to cut spending on generous social programs, reduce imports, and impose wage constraints. Across Europe, the effort to implement these policies exacerbated social inequality and, in the case of Britain and Poland, precipitated violent conflicts between trade unions and the state.[^borrowed-time-22] These global financial pressures eroded the foundations of the Left on both sides of the Iron Curtain. In the West, social democracy was increasingly discredited as political elites reconciled themselves to a new paradigm of neoliberal reform embodied most decisively in the figure of Margaret Thatcher. In the East, the effort to implement austerity corroded the ideological foundations of state socialism and ultimately led to the system’s collapse.[^borrowed-time-23] The breakdown of the postwar economic order also undercut those efforts by the global South and its European socialist supporters, like Yugoslavia, to reorganize the global economy according to more redistributive and developmentalist priorities. The sovereign debt crises that followed the Volcker Shock inaugurated an era of neoliberal structural adjustment across the global South.[^borrowed-time-24]

<!-- borrowed-time-028 -->

〔原刊 p. 8〕

Bartel’s account is a crucial framework for understanding the end of history as bound up with a wider crisis of historicity. It allows us to perceive the ways in which both the dissolution of state socialism in Eastern Europe and the ideological defeat of social democracy in Western Europe were entangled in the broader crises of energy and profitability that beset the global economy in the 1970s.[^borrowed-time-25] More specifically, it highlights the central role that sovereign debt played in the trajectory of socialism’s decline. That debt increasingly corroded the authority of national governments, forcing them to defer to global financial markets and radically recast their economies in ways that strengthened an emerging paradigm of neoliberal economics and delegitimized alternative economic models.[^borrowed-time-26]

<!-- borrowed-time-029 -->

〔原刊 p. 9〕

The pressures and limitations that the debt crises fostered in the field of politics shaped a new experience of time, disrupting the historical horizons of socialism across Europe. In her work on the contemporary culture of indebtedness, Annie McClanahan describes credit as a “temporal fix” to the capitalist impulse for growth. Credit, in other words, allows capital to escape its present limits through a projection of profitability into the future, “as if it has already happened.”[^borrowed-time-27] This anticipatory structure facilitates a mode of temporal deferral that obscures the present moment of production. Credit, then, is a mode of living on borrowed time in the sense that it mobilizes value whose realization is deferred to a future moment.[^borrowed-time-28] The present, in turn, is recast as a future past, one whose limitations seem to have been overcome.

<!-- borrowed-time-030 -->

〔原刊 p. 9〕

Under conditions of a debt crisis, however, this future dissolves and we are thrown back into an earlier moment of production with all of its constraints and failures. “When credit works,” McClanahan argues, “it lives only in the future, transfixing in its seemingly magical power to move itself ever forward. But when it fails, credit is pulled back into its own uncanny past, back into the reality of labor and production that it so desperately attempted to disavow, confronted with the material limits it thought it had overcome.”[^borrowed-time-29] If the temporal vector of credit is an anticipatory future, then that of debt is a spectral return of a past that has been repressed. With the sudden narrowing of temporal horizons, the present becomes unmoored from the future and finds itself riven through with shards of a traumatic past.[^borrowed-time-30] Debt crisis is, then, a moment of temporal upheaval in which the future past of credit abruptly gives way to a present past of stagnation and regression.

<!-- borrowed-time-031 -->

〔原刊 p. 9〕

The experience of the crises of sovereign indebtedness in Europe dramatically expands McClanahan’s analysis and offers a generative framework for understanding the late Cold War chronoscape. While her account is based on the study of U.S. household debt, I propose two theses in adapting this analysis to the conditions of sovereign debt, which are borne out by the Yugoslav experience. First, in a crisis of sovereign debt, the bearer is not the private individual or company but the state. Consequently, if debt disrupts a temporal order by puncturing the present with a repressed past, under conditions of sovereign debt the past that returns will likely be the foundational moments in the history of the state’s formation. This helps to explain why the years of sovereign debt crisis in Europe were accompanied by a new culture of historical memory that interrogated the history of the breakdown and re-founding of political order on the continent, particularly with regard to the violence of World War II.[^borrowed-time-31]

<!-- borrowed-time-032 -->

〔原刊 p. 10〕

Second, the temporal structure of credit resonated with socialism’s regime of historicity in ways that exacerbated the corrosive effects of the debt crisis on the Left. Both credit and socialist ideology were structured by a similar anticipatory temporality that anchored the present to a promised future. The promise of this future served as a point of orientation that could stabilize the present and drive its temporal momentum forward.[^borrowed-time-32] As with credit, so long as that horizon of expectation remained open, this ideological structure could function more or less smoothly. The sovereign debt crises that followed in the wake of the global economic turbulence of the 1970s, however, dissolved socialism’s future as a point of historical orientation, and the temporal engine that gave the present its sense of dynamism broke down. The debt crisis thereby corroded the ideological coordinates of the socialist project, introducing a sense of historical precarity and rootlessness.

<!-- borrowed-time-033 -->

〔原刊 p. 10〕

The dissolution of socialism’s horizons of expectation and the pervasive sense of temporal stagnation that accompanied it were precipitated by the sovereign debt crises that beset Europe in the final decade of the Cold War. The shared entanglements of national governments in the global financial system explain why this temporal crisis was felt with such existential force by the Left on *both* sides of the Iron Curtain. As governments across the continent faced the pressures of bond markets and rapidly growing debt payments, the credit that had once fueled social democratic and state socialist visions of future growth receded. The historical present was no longer experienced as dynamic and pregnant with future possibilities, but rather constrained and stagnant, stuck in a past from which it could not escape. Yugoslavia in the 1980s offers a rich case study through which to develop this argument.

<!-- borrowed-time-034 -->

〔原刊 p. 10〕

## Yugoslavia’s Sovereign Debt Crisis

<!-- borrowed-time-035 -->

〔原刊 p. 10〕

In Yugoslavia, a crisis of historicity took root in the early 1980s, when the country’s foreign debt crisis began to corrode the ideological and economic foundations of the socialist state. This corrosion was manifested in a new culture of historical memory that began to permeate society and eat away at the historical myths upon which the postwar state had founded its authority. Writing midway through this decade, Sabrina Ramet observed that Yugoslav society had begun to display signs of “apocalypse culture,” characterized by “strains of pessimism, gloom, resignation, escapism of various kinds,” a country that increasingly perceived itself to be at the “end of time.”[^borrowed-time-33] A crisis of indebtedness fostered a crisis of socialist historicity, as dissident intellectuals became preoccupied with recovering accounts of the country’s dark past that they believed had been repressed by the state.

<!-- borrowed-time-036 -->

〔原刊 p. 11〕

From its early years, Yugoslav socialism had been characterized by high levels of foreign debt.[^borrowed-time-34] Since the country’s break with the Soviet Union in 1948, the communist leadership had exploited its position between the two Cold War blocs to secure access to global markets and favorable lines of credit. To facilitate this strategy, they introduced reforms designed to decentralize the economy and move toward market socialism.[^borrowed-time-35] These reforms reached their peak in 1974–76 when the leadership radically devolved political-administrative power to national-republican institutions—curtailing the authority of the federal government—and created more forums for workers’ participation in the management of their enterprises.[^borrowed-time-36] This decentralization left the country especially ill-equipped to respond to the global economic upheavals of the 1970s. The oil shocks hit Yugoslavia especially hard. Since the mid-1960s, the country’s energy needs had increasingly shifted from coal and hydropower to imported oil.[^borrowed-time-37] The spike in global prices meant that by the early 1980s foreign petroleum accounted for almost a quarter of Yugoslav net import payments.[^borrowed-time-38] Meanwhile, the devolution of administrative powers made it impossible for the federal government to exercise oversight on foreign borrowing, which exploded during these years as enterprises met the challenge of rising inflation, energy costs, and wage increases by relying on their continued access to cheap foreign credit.[^borrowed-time-39] This influx of credit helped to paper over the general stagnation of the Yugoslav economy but generated a high level of foreign indebtedness that remained largely hidden from the federal government’s view.

<!-- borrowed-time-037 -->

〔原刊 p. 11〕

Yugoslavia’s heightened exposure to global financial markets meant that it was hit especially hard by the Volcker Shock of 1979. In 1980, the country’s foreign debt ballooned to USD $21 billion. Faced with the threat of bankruptcy, the federal government turned to the International Monetary Fund (IMF), eventually agreeing to an “enhanced surveillance” program that effectively compromised the country’s economic sovereignty.[^borrowed-time-40] In an early instance of the structural adjustment measures that would become a key characteristic of neoliberal programs in the developing world, the federal government pursued radical economic reforms intended to streamline enterprises by restricting wages, curbing price increases, reducing imports, and prioritizing exports. In 1983, the government initiated the “Long Term Program for Economic Stabilization,” which made clear that the economic contraction was not simply another brief stint of belt tightening but a more ingrained and prolonged crisis. The Volcker Shock pushed Yugoslav debt payments to unsustainable levels. According to one Yugoslav economist, between 1981 and 1988, the country’s foreign loan payments amounted to seven to ten percent of national income, a percentage that, he calculated, exceeded the reparations paid by Germany after World War I.[^borrowed-time-41]

<!-- borrowed-time-038 -->

〔原刊 p. 12〕

Such sums called for a savage cut to government spending, and the ensuing austerity measures had a dramatic impact on the living standards of everyday Yugoslavs. In an effort to restrict expensive foreign imports, the government abandoned subsidies and price controls, making basic items, including oil, coffee, laundry detergent, food, and fuel prohibitively expensive. Inflation grew to triple digits and unemployment rose to previously unseen heights.[^borrowed-time-42] To make matters worse, the reforms failed to achieve their intended outcome. With a near-stagnant economic growth rate of 0.5 percent throughout the 1980s, the country’s foreign debt remained at unsustainable levels by the decade’s end.[^borrowed-time-43]

<!-- borrowed-time-039 -->

〔原刊 p. 12〕

Although Yugoslav workers had grown accustomed to patterns of sudden exuberant expansion and subsequent austere downturn, the duration and extent of the crisis in the 1980s were unprecedented. One of the effects of this economic shock was to foster a widespread moral discourse that valorized austerity and criticized profligacy. In its early years, this popular discourse clearly operated within the horizons of a socialist historicity. As Goran Musić notes, many workers initially embraced the calls for austerity and sacrifice in ways that recalled the appeals to revolutionary optimism and national solidarity from an earlier, more heroic era of the socialist regime. A comment from a worker in the Slovene city of Maribor in 1983 illustrates this early spirit especially well: “The economic situation is grave indeed and it limits our purchasing power. I admit we were a bit spoiled during previous years and this sudden crisis caught us unprepared. The scarcity of items in the supermarket, higher prices, and similar stabilization measures had an effect on all of us. However, I am convinced that also this time around we will come out of the crisis by relying on our own capacities…. We should increase productivity and work discipline, shorten the time spent in meetings, cut back on personal and collective consumption.”[^borrowed-time-44]

<!-- borrowed-time-040 -->

〔原刊 p. 13〕

What is important to note here is that the worker’s moralizing language, her chastising of an earlier period of excess, is framed within the anticipatory horizons of socialist ideology. The present is not a condition of suffocating stagnation or regression into the past, but one in which a temporal momentum still moves forward to a brighter future of prosperity and productivity. Within this anticipatory temporal structure, the present impasse can be overcome through greater discipline, sacrifice, and collective effort. The contours of a socialist historicity are still felt in her reaction to the crisis.

<!-- borrowed-time-041 -->

〔原刊 p. 13〕

But by the second half of the 1980s, this moral rhetoric was configured within a new temporal order, one in which the anticipatory horizons of socialism were not just dissolved but increasingly repudiated as a dangerous illusion. The issue of Yugoslavia’s foreign debt was often a key factor in the transition to this new experience of time. In a series of essays from 1987, for instance, the Slovene philosopher Taras Kermauner criticized Yugoslavia’s socialist leaders for their ideological hubris and culture of excess, both of which had been enabled by the country’s reliance on foreign credit: “Thank God the creditors submitted the bill to us! Because only thanks to this did we start to sober up. That lavishly equipped Mercedes, which had been bought on credit and which seated the highest symbols of Yugoslavia, would have crashed into the abyss in mid-gallop before its drivers and the pseudo-aristocratic passengers even realized what was happening to them. That is, if that arrogant wagon had not first run out of gas and money and creditworthiness.”[^borrowed-time-45]

<!-- borrowed-time-042 -->

〔原刊 p. 13〕

Foreign credit, Kermauner insisted, had morally corroded Yugoslav socialism by fueling a revolutionary hubris that allowed the country’s leaders to project their ambitions beyond the state’s natural spatial and temporal horizons. Spatially, this was evidenced in the country’s leading role in the Non-Aligned Movement, an alliance of mostly Third World states that sought to steer a path between the two Cold War power blocs.[^borrowed-time-46] To Kermauner, these global ambitions were evidence of the regime’s delusions of grandeur. Cheap credit had allowed Yugoslav socialists to imagine that they could exceed their country’s humble place on the periphery of Europe. This unabashed Eurocentrist found his country’s ties with the Third World especially distasteful and, in blatantly orientalist fashion, blamed Yugoslavia’s alliance with the “East” for contributing to the excess, corruption, and degeneracy of the political class.[^borrowed-time-47] The intervention of the IMF, he insisted, had provided one last opportunity for the country to break with this eastern culture of profligacy and return to the borders of an austere and disciplined Europe.[^borrowed-time-48]

<!-- borrowed-time-043 -->

〔原刊 p. 13〕

Temporally, too, Kermauner believed that the state’s irresponsible foreign borrowing had sustained its “millenarian phantasmagorias.”[^borrowed-time-49] The anticipatory temporality of Yugoslav socialism, in this reading, was an immature fantasy and, far from guiding the country into the future, had made Yugoslavia an anachronism in the contemporary world. As a new global economy increasingly rendered the proletariat historically insignificant, Kermauner insisted, Yugoslav socialists had refused to come to terms with the new times and instead “barricade[d] [themselves] in defense of backward modes of production and productive-social relations.”[^borrowed-time-50] The revolutionary tempo of socialism was out of place in the more austere chronoscape of the 1980s. What was called for now, he intimated, was a humble presentism, a spiritual reassessment that was informed by a realistic appraisal of the narrow possibilities afforded a small nation in a rapidly globalizing world. According to Kermauner, this temporal humility would become a necessity now that Yugoslavia’s debt had come due and the cheap credit that had once sustained its revolutionary ambitions had dried up.

<!-- borrowed-time-044 -->

〔原刊 p. 14〕

Alongside this new moral rhetoric, the debt crisis and the temporal disorientation it fostered also gave rise to a new culture of historical memory, one that created the conditions for the growth of a nationalist counterculture. This was particularly pronounced in Serbia, where the liberalization of the public sphere gave these controversial views a greater airing than in the federation’s other national republics.[^borrowed-time-51] Starting as early as 1981 but really gathering pace in the middle of the decade, oppositional historians and writers began to interrogate the official narrative of World War II and the founding of the state. This wave of historical revisionism complicated the socialist state’s uncritical account of the partisan struggle, reassessing the legacy of the Serbian Chetnik movement in particular and reexamining the factional disputes that had divided the communist party (often along ethnic lines) during the war. The wartime genocide of Serbs at the hands of the Axis-aligned Croatian Ustasha became an especially fraught topic. Dissident historians accused the socialist regime of a conspiracy of silence regarding both the scale and ferocity of the slaughter and the ethnicity of the victims and perpetrators.[^borrowed-time-52] Images of wartime atrocities against Serbs, Jews, and Roma became widespread, trafficked by tabloids and academic organizations alike.[^borrowed-time-53] These themes resonated with a Europe-wide interrogation of the historical memory of World War II and its themes of victimhood, atrocity, and complicity.[^borrowed-time-54]

<!-- borrowed-time-045 -->

〔原刊 p. 14〕

The new nationalist culture of historical memory was often articulated through a paradigm of repressed traumas. Owing to their generic form, memoirs or autobiographical accounts of wartime ethnic violence or of persecution by the young communist regime that appeared during this decade frequently presented themselves as an effort to recover suppressed memories. But fictionalized accounts, too, often relied on this framing device. Vuk Drašković’s notorious 1982 novel, *Nož* (*The Knife*), for instance, centered on a Bosnian Muslim protagonist, whose research into his family’s past reveals a dark secret. The young man, we discover, was originally born a Serb whose family was murdered by their Muslim neighbors during the war. It was these very neighbors who took the young child in and raised him as one of their own.[^borrowed-time-55] In Drašković’s tale, the repressed memories of the wartime past could return to expose the lie of ethnic harmony in the present.

<!-- borrowed-time-046 -->

〔原刊 p. 15〕

Throughout the 1980s, then, the paradigm of historical trauma was wielded by Serbian opposition intellectuals who sought to evoke the past to disrupt the regime’s claim to the present. But why should opposition to the socialist regime have taken this specific temporal form? What about the conditions of economic crisis prompted a preoccupation with the history of World War II and its immediate aftermath? The answer lies in the temporal dynamics of Yugoslavia’s debt crisis. Debt is, as we observed, the disruptive return of the past to the present. As the anticipatory future of credit breaks down, we inhabit a present permeated by the debts of the past. Little wonder, then, that a crisis of sovereign debt would foster a culture of historical revisionism that targeted the state’s own founding myths.

<!-- borrowed-time-047 -->

〔原刊 p. 15〕

In Yugoslavia, the temporal disruptions that the debt crisis brought about fragmented the socialist state’s regime of historicity. It was out of this fragmentation that the politics of nationalist grievance and historical revisionism emerged. This is not to suggest that nationalist sentiments or the specific temporal regimes that structured ethnic grievances did not exist prior to the years of the debt crisis. They certainly formed part of postwar Yugoslavia’s temporal ecology.[^borrowed-time-56] What must be explained is why this previously latent conflict between the historical imagination of Yugoslav socialism and that of its various ethnonationalist rivals erupted at this precise historical moment. The rise of nationalist opposition politics was not the reappearance of irresolvable ethnic enmities but rather an expression of a deeper and more encompassing rupture in the hegemony of socialism’s temporal order. The nationalist counterculture of late-socialist Serbia was part of the chronoscape of the final decade of the Cold War in Europe. To further develop this argument, I will conclude by turning to examples of oppositional culture that explored the preoccupation with the return of repressed historical memories but that avoided the tropes of nationalism.

<!-- borrowed-time-048 -->

〔原刊 p. 15〕

## Debt Crisis Cinema

<!-- borrowed-time-049 -->

〔原刊 p. 15〕

The temporal dimension of Yugoslavia’s debt crisis was clearly expressed in the cinema of the 1980s. Two films, in particular, illustrate this point well: *Balkanski špijun* and *Već viđeno.* Both were very much films of the debt crisis. Not only did they dwell on widespread anxieties around economic insecurity, especially the precarity of homeownership, but they also voiced the abovementioned popular frustrations with the perceived profligacy of the socialist state. More crucially, these films registered the profound temporal crisis of the decade through their staging of the return of repressed traumatic memories. While scholars of Yugoslav cinema have already noted this concern with repressed traumas, they have not adequately explained why this theme should appear during this specific historical moment.[^borrowed-time-57] What I want to demonstrate is that the theme of the return of the repressed resonated with the uncanny temporality of the debt crisis that permeated late-socialist Yugoslavia. Importantly, neither of these films couched their historical revisionism in the language of nationalist grievance but instead examined the violence that attended the formation of the socialist state in the years immediately following World War II. They suggest, in other words, that a deeper temporal crisis was shaking the foundations of socialist Yugoslavia.

<!-- borrowed-time-050 -->

〔原刊 p. 16〕

*Balkanski špijun* was a dark comedy initially written for the stage by Dušan Kovačević in 1982 and subsequently made into a film by Kovačević and Božidar Nikolić two years later. The comedy centers on the character of Ilija Čvorović, a middle-aged man living with his wife, Danica, in the Belgrade suburbs. To deal with the declining economic situation in the country, Ilija and Danica have taken on a tenant, a foreign businessman who is eager to open a line of clothing stores in the country. Ilija, who is clearly under enormous stress due to the economic hardships, begins to get suspicious that his tenant is a Western spy intent on undermining the country. As an idealistic socialist and Yugoslav patriot, he decides to monitor the foreigner, undertaking an ill-advised and ridiculous surveillance operation. When his paranoia deepens, however, his slapstick antics become more and more sinister until the film reaches a dark and bloody ending.

<!-- borrowed-time-051 -->

〔原刊 p. 16〕

Ilija, we discover, was an *ibeovac*, one of the thousands of suspected pro-Stalinist party members who were persecuted during Yugoslavia’s break with the Soviet Union in 1948.[^borrowed-time-58] His suspicion of the foreign tenant is rooted in a deep-seated fear that his loyalty is once again being tested by the party leadership, a belief that prompts him to ever greater demonstrations of ideological conviction. Here the ghosts of Yugoslavia’s past are dredged back up into a present that is defined very much by the economic crisis and the government’s stabilization reforms. The film’s humor, too, turns on the temporal disorientation of the central character. Ilija is an absurd figure, whose paranoia consistently leads him to misinterpret his tenant’s innocent actions as part of a sinister plot against his homeland. Set against the backdrop of late-socialist Yugoslavia’s consumerism and ideological cynicism, Ilija appears anachronistic, a parody of an earlier revolutionary idealism that seems ridiculously out of time in the present.

<!-- borrowed-time-052 -->

〔原刊 p. 16〕

*Već viđeno* was directed by Goran Marković and released in 1987. The film follows a melancholic, introverted piano teacher, Mihailo, who is an instructor at the local workers’ university. When Olgica, a young ballet dancer, joins the university to teach modeling, he becomes obsessed with her and the two begin a sexual liaison. When the university enters a nationwide television competition, Olgica sees the event as a chance for social mobility; a win for the university, she reasons, may secure her membership in the party and then an apartment of her own, freeing her from the suffocating poverty of her father’s house. She takes charge of the work collective’s performance, which she envisions as an agit-prop event recalling the glories of the partisan struggle and the revolution. The climax of the performance will be Mihailo performing Chopin’s *Revolutionary Études.* This piece, however, brings up painful memories, and Mihailo is forced to confront a traumatic past, involving his father’s execution and the appropriation of his family’s apartment by the young communist regime. As these traumatic memories rupture more and more into his present, Mihailo breaks down and initiates a bloody killing spree.

<!-- borrowed-time-053 -->

〔原刊 p. 17〕

Both *Balkanski špijun* and *Već viđeno* illustrate the ways that the debt crisis shaped popular perceptions of the socialist state during the 1980s. Most immediately, they dwelled on widespread anxieties concerning economic insecurity. In *Balkanski špijun,* these themes are explicitly examined in the plot. As Ivan Velisavljević has noted, Ilija’s paranoia is rooted in the conditions of economic crisis: his declining wages, his and his wife’s health problems, the difficulties in finding or affording food, and their daughter’s long-term unemployment. Indeed, the entire plot turns on the fact that the economic crisis has forced Ilija and Danica to open their house to a stranger whose rent they need to help pay their mortgage. Immersed in his paranoia, Ilija perceives all of these hardships as part of the West’s scheme to undermine Yugoslav socialism.[^borrowed-time-59] The film is clear in identifying the economic crisis as the proximate cause of his psychological breakdown. One humorous scene is revealing for the miscommunication it stages. In a friendly conversation with a police official, the detective asks Ilija how he is faring given the economic hardships. Eager to demonstrate his fealty to the regime, Ilija announces that he is committed to “the plan.” The language he uses evokes the early revolutionary rhetoric of the immediate postwar years and its grand ambitions of five-year plans. This is a world away from the stabilization plan of the 1980s, a crippling austerity campaign designed to reassure foreign lenders and the IMF. If the five-year plan of the late 1940s announced the utopian horizons on which Yugoslav socialists set their sights, the stabilization plan registered the radical narrowing of those horizons. This early scene sets the stage for the film’s juxtaposition between a central protagonist who continues to inhabit the revolutionary past while bumbling his way through a historically static present.

<!-- borrowed-time-054 -->

〔原刊 p. 17〕

Although *Već viđeno* did not explicitly take up the conditions of economic crisis, it hinted at them through its preoccupation with housing. Housing was an overdetermined site of economic discontent in socialist Yugoslavia. Even before the hardships of the debt crisis, inequality in access to appropriate housing marked a sharp divide not only between the political elite and the rest of society but also within the working class itself. Rory Archer has shown that inequalities within the self-management system often turned on access to socially owned housing, which was always in short supply. Within the factory it was frequently the white-collar workers who were given privileged access to this key resource over their less educated blue-collar peers.[^borrowed-time-60] The economic crisis in the 1980s aggravated these social tensions, and housing became even more explicitly a symbol of precarity, social inequality, and the failures of the socialist state.

<!-- borrowed-time-055 -->

〔原刊 p. 18〕

Housing is a central thread of the narrative in *Već viđeno.* The desire to escape the claustrophobic atmosphere of her father’s house fuels Olgica’s ruthless ambition, prompting her to pressure Mihailo and bringing about his psychological breakdown. Meanwhile, the expropriation of Mihailo’s family apartment by the socialist government serves as a constant reminder of the execution of his father and the traumatic legacy of the partisan revolution. The apartment has now been subdivided, and Mihailo shares it with the family of a vulgar and brutal secret security officer, which contributes to the sense of claustrophobia and intrusion into his home life. He is, in other words, very much not at home, an uncanny condition that contributes to his psychological illness. Homes, in the film, are not sites of comfort and security but reminders of the historical brutality or failures of the socialist state.

<!-- borrowed-time-056 -->

〔原刊 p. 18〕

Both films can also be read as texts about the debt crisis in that they resonated with the widespread moral condemnation of the profligacy of political elites that pervaded the Yugoslav public of the time. To understand this development, we need to recall the growing class divergence within the Yugoslav self-management system—namely, between a more educated, older, and white-collar workforce, who had secured positions of privilege in the workplace and could manipulate the complicated mechanisms of self-management, and a less educated, younger, blue-collar workforce, who were often excluded from the perks of the system. The former were more likely to be engaged in social activism, to take up positions as delegates in various self-managing bodies, and to be members of the party. Because of this, they were also more likely to enjoy security of employment, housing, and access to imported consumer goods. The result was that those most visibly engaged in the socialist project were also more likely to be perceived as enjoying the country’s limited wealth. As blue-collar workers felt austerity cut deeper into their living conditions over the 1980s, they began to identify the politically engaged elite in their workplaces as responsible for the crisis and the inefficiencies and inequalities of the self-management system.[^borrowed-time-61] In these conditions, the country’s foreign debt increasingly came to be associated with a perceived wastefulness and profligacy of the elite, which over time began to corrode the party’s political legitimacy.

<!-- borrowed-time-057 -->

〔原刊 p. 18〕

*Balkanski špijun* and *Već viđeno* represented this frustration with the political elite by associating revolutionary idealism with financial profligacy. In both films, those most eager to demonstrate their commitment to the socialist cause are also the most irresponsible financially. As Ilija Čvorović sinks deeper and deeper into his conspiracy, he stops going to work so that he can focus more on his surveillance operation. While his wife scours the grocery store shelves or bemoans the family’s growing debt, Ilija spends money on various gadgets to better spy on his tenant. Ilija’s ill-conceived efforts to demonstrate his fealty to the state are not only wasteful; they also undermine his wife’s desperate attempts to get the family’s finances in order, a not-too-subtle jab at what the directors perceived as the political elite’s privileging of ideology over economic pragmatism.

<!-- borrowed-time-058 -->

〔原刊 p. 19〕

*Već viđeno* also links revolutionary idealism to profligacy, albeit through a more cynical lens. As self-appointed producer of her school’s competition entry, Olgica takes it upon herself to order millions of dinars worth of cloth for the set. When the director of the school denounces such wasteful misuse of their limited resources, she defends her excessive spending by evoking the heroic ideals of the revolution: “We from the Youth Organization do not think in such terms, comrade director. If we all played our cards so safely, then nothing would ever get done. We gladly give our enthusiasm for something we believe in. And if we fail, we are not sorry. We don’t do this for points but out of love!” The fact that we know Olgica’s goals to be self-serving only reinforces the film’s critique of the political elite. Waste, mismanagement, and inefficiency in these films are all to be associated with those most idealistic and most dedicated to the socialist cause, a criticism that certainly resonated with the views of opposition figures like Taras Kermauner.

<!-- borrowed-time-059 -->

〔原刊 p. 19〕

But it was in their staging of the return of past historical traumas that these two films best captured the temporal disorientation that Yugoslavia’s debt crisis precipitated. This representation was achieved through the use of the uncanny. As McClanahan argues, the uncanny is the aesthetic form most appropriate to the anxieties of indebtedness: “In its anxious, backward gaze, debt, like the uncanny, doubles, reverses, and returns. This feeling of being haunted explains what might feel uncanny about being in personal debt: it is the experience of being followed by something we left behind, of carrying our past with us like a dead weight.”[^borrowed-time-62] The uncanny, then, marks a traumatic reappearance of the past in a way that disrupts the present. Debt, in this sense, agitates the sediment of history, stirring up the past and muddying the waters of the present. The experience is one of unsettling disorientation. We have already noted how this uncanny sense of the past returning shaped historiographical debates in the last decade of Yugoslav socialism. But as these films demonstrate, this new culture of historical memory was not limited to the sphere of intellectual discourse but also permeated popular culture.

<!-- borrowed-time-060 -->

〔原刊 p. 19〕

The plot of both films relied on a narrative staging of the uncanny to reveal the roots of their protagonists’ respective psychological breakdowns. In *Balkanski špijun*, the depth and horror of Ilija’s paranoia only really become clear in an infamous scene in which the protagonist and his brother descend into the house’s basement. There they unearth weapons and a portrait of Stalin that has presumably been concealed since the regime’s anti-Stalinist purges in 1948. This is the moment that we realize Ilija’s paranoia is rooted in his persecution by the early socialist state for his pro-Soviet sympathies. As the basement is rendered a symbolic space of the unsettled past, both that of the two brothers and of Yugoslav socialism itself, the home becomes a site for the restaging of repressed historical traumas.[^borrowed-time-63] From this moment on, Ilija’s pathological fixation on the foreign tenant becomes clearer and also more ominous. *Već viđeno* stages this uncanny return of history through intermittent flashbacks that gradually reveal Mihailo’s past. As he prepares for Olgica’s concert, his traumatic childhood memories of his family’s persecution become more and more intrusive, contributing to his psychological breakdown. In both films the return of these repressed memories directly leads to the violence and degradation of the protagonists. In the final frames of *Balkanski špijun*, Ilija is reduced to crawling through the suburbs of Belgrade on all fours like a dog, babbling incoherently. Mihailo, after murdering Olgica, her father, and her lover, is admitted to an asylum, where he falls into a catatonic state. The intrusive and disorienting return of the past grinds the present to a halt, disorienting it to the point of psychosis. And because they spoke to a crisis of *sovereign* debt, the past that these films restaged consisted of crucial moments in the formation of the Yugoslav state: the initial communist seizure of power in 1945, the foundational break with the Soviet Union in 1948.

<!-- borrowed-time-061 -->

〔原刊 p. 20〕

What is crucial about these films is that neither staged the return of the past through the lens of nationalist grievance. Although both were produced in Serbia, where a more liberal political environment allowed a nationalist counterculture to flourish, neither film reflected these nationalist preoccupations. This helps us to better contextualize the nationalist rhetoric of the late-socialist period. It was not, as is often argued, that the rise of nationalist resentments led to a preoccupation with historical memory during the 1980s. Rather, the crisis in the socialist order of time agitated Yugoslav society’s historical memory, creating fertile ground from which alternative, oppositional historical narratives could take root. The restless interrogation of the state’s official historiography reflected a deeper crisis in the socialist regime of historicity, in which the promise of a future dissolved and the specters of the past returned. This temporal reconfiguration reflected the new experience of historical time that was brought on by the uncanny conditions of the sovereign debt crisis.

<!-- borrowed-time-062 -->

〔原刊 p. 20〕

## Conclusion

<!-- borrowed-time-063 -->

〔原刊 p. 20〕

The concluding scene of Dragojević’s *Lepa sela lepo gore* offers a darkly satirical view of national reconciliation in post-conflict Bosnia. A reel of mock news footage, set several years after the events of the film, celebrates the reopening of the tunnel that served as the claustrophobic setting for the Serbian soldiers. Rebuilt with funding from the European Union, the tunnel has been renamed the “Tunnel of Peace” and is said to symbolize the hopes of a new Bosnia of ethnic harmony and prosperity. Significantly, these scenes are a replay of the film’s prologue, when the same stock footage is used to depict the socialist-era opening of the “Tunnel of Brotherhood and Unity,” which party officials also celebrate as inaugurating a new epoch of peace and harmony for the peoples of Bosnia. The scenes establish a parallel between the utopian hopes of Yugoslav socialism in the 1960s and those of European liberalism in the 1990s, satirizing both ideologies for their naïveté and hollow promises. This parallel reinforces the film’s powerful sense of historical stagnation. History, it suggests, is doomed to repeat itself.

<!-- borrowed-time-064 -->

〔原刊 p. 20〕

Critics have often noted how Dragojević’s film produces a distinctly “Balkan time,” in which history is characterized by a cyclical pattern of violence and retribution. In this sense it reads as a cinematic expression of the “ancient ethnic hatreds” thesis, according to which the peoples of Southeast Europe are fated to bouts of nationalist violence. What this scholarship has overlooked, however, is the degree to which this cyclical understanding of history resonated with a much wider sense of temporal stagnation in Europe in the decades surrounding the end of the Cold War. Dragojević’s understanding of Balkan history as stuck in an eternal, violent loop resonates with Traverso’s description of the end of history as “a suspended time between an unmasterable past and a denied future, between a ‘past that won’t go away’ and a future that cannot be invented or predicted (except in terms of catastrophe).”[^borrowed-time-64] The film might be better understood as an effort to articulate the end of history in a post-Yugoslav vernacular.

<!-- borrowed-time-065 -->

〔原刊 p. 21〕

As I have sought to demonstrate, however, the end of history, as it is often conceived, is perhaps a misnomer. If Fukuyama envisioned the epic conclusion of a historical era and the triumphant birth of a new international order of liberal capitalism, in Yugoslavia and other parts of the socialist world, these years were moments of a protracted and disorienting crisis in the order of time. It is not simply that the condition of temporal stagnation and historical closure preceded the events of 1989–91 by a decade, but also that this period was often experienced not as an end but a *return* of history, albeit in a fragmented, non-linear, and uncanny way. What came to an end was a socialist regime of historicity in which the present was oriented toward a future and time moved forward linearly, sometimes in leaps and bounds, sometimes in stops and starts. The closure of this regime’s historical horizons disrupted the experience of the past, which reemerged in often unsettling ways.

<!-- borrowed-time-066 -->

〔原刊 p. 21〕

Over the course of the 1980s, the erosion of socialism’s horizons of expectation was registered in Yugoslav popular culture. Films such as *Balkanski špijun* and *Već viđeno* spoke to a new sense of the present as punctuated by the horrors of the past. In this new temporal environment, socialist ideology, with its specific mode of historical memory oriented toward an anticipated future, lost its purchase. Alternative ideologies, which were better suited to this new temporal condition, took root, including, but not limited to, nationalisms that fixated on the memory of the violence of World War II.

<!-- borrowed-time-067 -->

〔原刊 p. 21〕

Of course, the historical closure and temporal stagnation that this article has analyzed were only one experience in a diverse temporal ecology, albeit, I believe, a dominant and consequential one. Alongside this sense of temporal disorientation, historical pessimism, and crisis, Yugoslav society was also characterized by a vibrant youth culture that manifested itself in phenomena such as Yugoslav new wave or the Neue Slowenische Kunst. These movements testified to the robustness of a certain view of socialist modernity. Even here, though, we can detect echoes of the broader temporal paradigm this article has recovered. Sabrina Ramet, writing in the 1980s, for instance, interpreted this “feverish creativity” as an expression of a broader “apocalyptic” tone that animated the cultural life of late-socialist Yugoslavia.[^borrowed-time-65] The work of the Slovene band Laibach with its sly and ironic aesthetic references to the totalitarian regimes of the mid-twentieth century also clearly resonated with the wider agitation of historical memory during this period.[^borrowed-time-66] It is by no means obvious that the vitality of late-socialist youth culture escaped the temporal disorientation and disorder of the era, although it certainly represented this condition in creative and unexpected ways.

<!-- borrowed-time-068 -->

〔原刊 p. 22〕

Thinking the crisis of socialism’s regime of historicity through its relation to sovereign debt helps to explain the more generalized decline of socialist projects across both Eastern and Western Europe in the final decade of the Cold War. This decline had its proximate origins in the crisis of growth that beset the global economy during the 1970s. The economic turbulence of this decade disrupted the developmental frameworks through which postwar European states had pursued global integration and eventually discredited state-managed approaches to the economy on both sides of the Iron Curtain. As states sought international loans to ameliorate the social fallout of the decade of stagnation, an era of credit-fueled growth gave way to one of debt, austerity, and structural adjustment.

<!-- borrowed-time-069 -->

〔原刊 p. 22〕

Although it is true that the breakdown of postwar Keynesianism in the West impacted parties, governments, and ideologues across the political spectrum, the Left proved especially ill-prepared to respond to the challenges posed by the new global economic landscape. Unlike the Right, which reorganized around an alternative paradigm of neoliberalism, the Left’s sense of political confusion was compounded by a deeper experience of historical disorientation that was brought about by the disruption of socialism’s temporal order. Sovereign indebtedness, and the crises that it provoked, had a profound impact on socialism’s experience of historical time, which contributed significantly to the Left’s paralysis in the face of a momentous political challenge.

<!-- borrowed-time-070 -->

〔原刊 p. 22〕

Understanding the temporal disorder that took root in the final decade of the Cold War helps us to explain the disproportionate impact of the collapse of the Eastern bloc on socialism’s regime of historicity. By the 1980s, few among Europe’s Left continued to look to the authoritarian regimes of Eastern Europe as having realized the hopes of socialism. Even if the existence of these states suggested that an alternative to capitalism might be conceivable, they had long ceased to offer a viable model for emulation. The economic stagnation, political repression, and moral bankruptcy of these states had been on display since at least the crushing of the Prague Spring. The collapse of state socialism did not disillusion Europe’s Left so much as reinforce a preexisting and pervasive sense of historical disorientation. The fall of the Berlin Wall, in other words, did not inaugurate the “end of history.” Rather, it affirmed a broader experience of temporal stagnation that corresponded to an era in which the impressive growth of postwar global capitalism ran aground, giving way to a new stage of debt and austerity.

<!-- borrowed-time-071 -->

〔原刊 p. 22〕

## Acknowledgements

<!-- borrowed-time-072 -->

〔原刊 p. 22〕

I would like to thank Stipe Ćurković, Rossen Djagalov, Zachary Hicks, Liron Mor, Bojana Videkanić, Marla Zubel, and the three anonymous reviewers for their criticism on earlier versions of this article.

## 原注 / Original notes

[^borrowed-time-1]: Accounts that emphasize the link between the economic crisis of the 1980s and the rise in nationalist tensions include: Susan Woodward, *Balkan Tragedy: Chaos and Dissolution After the Cold War* (Washington D. C.: Brookings Institution, 1995); Dejan Jović, *Yugoslavia: A State that Withered Away* (West Lafayette: Purdue University Press, 2009), 141–70; John R. Lampe, *Yugoslavia as History: Twice There Was a Country* (Cambridge: Cambridge University Press, 2000), 315–64.

[^borrowed-time-2]: Jasna Dragović-Soso, *Saviors of the Nation: Serbia’s Intellectual Opposition and the Revival of Nationalism* (London: Hurst and Company, 2002), 64–114; Jovan Byford, *Picturing Genocide in the Independent State of Croatia: Atrocity Images and the Contested Memory of the Second World War in the Balkans* (London: Bloomsbury, 2020), 120–23; Marie-Janine Calic, *A History of Yugoslavia* (West Lafayette: Purdue University Press, 2019), 273–77.

[^borrowed-time-3]: The concept of a regime of historicity was developed by François Hartog to describe the ways in which a society experiences, becomes conscious of, and reflects on historical time. See François Hartog, *Regimes of Historicity: Presentism and Experiences of Time* (New York: Columbia University Press, 2015), 9.

[^borrowed-time-4]: Francis Fukuyama, *The End of History and the Last Man* (New York: Penguin, 1992). Two recent efforts to rethink the scope of the end of history are Alex Hochuli, George Hoare, and Philip Cunliffe, *The End of the End of History: Politics in the Twenty-First Century* (Winchester: Zero Books, 2021) and Christopher Bickerton, “Europe’s Long 1989,” *Contemporary European History* 34, 3 (August 2025), 767–84.

[^borrowed-time-5]: Although he does not deal explicitly with Yugoslavia, Fritz Bartel’s work offers a crucial framework for understanding the place of Eastern Europe’s socialist states in the global economic transformations of the 1970s. Fritz Bartel, *The Triumph of Broken Promises: The End of the Cold War and the Rise of Neoliberalism* (Cambridge: Harvard University Press, 2022). On this history, also see Stephen Kotkin, “The Kiss of Debt: The East Bloc Goes Borrowing” in Niall Ferguson, Charles Maier, Erez Manela, and Daniel Sargent, eds., *The Shock of the Global: The 1970s in Perspective* (Cambridge: Harvard University Press, 2010), 80–93.

[^borrowed-time-6]: Enzo Traverso, *Left-Wing Melancholia: Marxism, History, and Memory* (New York: Columbia University Press, 2016).

[^borrowed-time-7]: This periodization buttresses revisionist accounts of the Yugoslav wars that emphasize the global dynamics of this conflict rather than locate it in the supposedly endemic ethnic enmities of the region. The canonical work in this field is Woodward’s *Balkan Tragedy.*

[^borrowed-time-8]: Harry Harootunian, “Remembering the Historical Present,” *Critical Inquiry* 33, 3 (Spring, 2007): 472. See also Hochuli, Hoare, and Cunliffe, *The End of the End of History*, 19–25.

[^borrowed-time-9]: James Mark and his co-authors offer a wide-ranging account of the global reverberations of 1989 in *1989: A Global History of Eastern Europe* (Cambridge: Cambridge University Press, 2019), 231–37.

[^borrowed-time-10]: For evidence of this sense of historical defeat among the Western Left, see Adam Przeworski, *Capitalism and Social Democracy* (Cambridge: Cambridge University Press, 1985); Stuart Hall, *The Hard Road to Renewal: Thatcherism and the Crisis of the Left* (London: Verso, 1988).

[^borrowed-time-11]: Geoff Eley, *Defending Democracy: The History of the Left in Europe* (Oxford: Oxford University Press, 2002), 483–89.

[^borrowed-time-12]: Bickerton, “Europe’s Long 1989.” David Broder offers a wonderful account of this process as it played out in the Italian context in *First They Took Rome: How the Populist Right Conquered Italy* (London: Verso, 2020), 7–51.

[^borrowed-time-13]: Traverso, *Left-Wing Melancholia*, 19.

[^borrowed-time-14]: Hartog, *Regimes of Historicity*, 97–104, 146.

[^borrowed-time-15]: Traverso, *Left-Wing Melancholia*, 15–16. Hartog identifies the same phenomenon, noting that during the 1980s memory “became an all-embracing term, a metahistorical and even at times a theological category” that marked a profound transformation of the West’s experience of historical time. Hartog, *Regimes of Historicity*, 6–7.

[^borrowed-time-16]: Katherine Verdery, *The Political Lives of Dead Bodies: Reburial and Postsocialist Change* (New York: Columbia University Press, 1999); István Rév, *Retroactive Justice: Prehistory of Post-Communism* (Stanford: Stanford University Press, 2005); Maria Todorova, *Bones of Contention: The Living Archive of Vasil Levski and the Making of Bulgaria’s National Hero* (Budapest: Central European University Press, 2009).

[^borrowed-time-17]: Traverso, *Left-Wing Melancholia*, 9.

[^borrowed-time-18]: Jeffrey Alexander described this as the “tragic dramatization” of the historical memory of the Holocaust, which universalized the mass killing of Europe’s Jews as a story of moral responsibility. Importantly for my thesis here, Alexander argues that this “tragic” dramatization resonated with postmodernity’s “disquiet” and its suspicion of progressive understandings of history. Jeffrey C. Alexander, “The Social Construction of Moral Universals,” in Jeffrey C. Alexander, *et al., Remembering the Holocaust: A Debate* (Oxford: Oxford University Press, 2009), 31–5.

[^borrowed-time-19]: Traverso, *Left-Wing Melancholia*, 18–19.

[^borrowed-time-20]: Charles Maier, “‘Malaise’: The Crisis of Capitalism in the 1970s,” in *The Shock of the Global*, 30–31; Bartel, *The Triumph of Broken Promises*, 23–29.

[^borrowed-time-21]: Robert Brenner, *The Economics of Global Turbulence: The Advanced Capitalist Economies from Long Boom to Long Downturn, 1945–2005* (London: Verso, 2006), 38–41, 179–84. See also Giovanni Arrighi, *The Long Twentieth Century: Money, Power, and the Origins of our Times* (London: Verso, 2002), 300–24; Leo Panitch and Sam Gindin, *The Making of Global Capitalism: The Political Economy of American Empire* (London: Verso, 2012), 133–94; Bartel, *The Triumph of Broken Promises*, 23–50; David Harvey, *The Condition of Postmodernity: An Enquiry into the Origins of Cultural Change* (Cambridge: Blackwell, 1989) 141–72.

[^borrowed-time-22]: Bartel, *The Triumph of Broken Promises*, 75–109.

[^borrowed-time-23]: Ibid., 335–45.

[^borrowed-time-24]: Bret Benjamin, “Developmental Aspiration at the End of Accumulation: The New International Economic Order and the Antinomies of the Bandung Era,” *Mediations: Journal of the Marxist Literary Group* 32, 1 (Fall 2018), 37–70; Paul Stubbs, *The New International Economic Order: Lives and Afterlives* (London: Routledge, 2026), 68.

[^borrowed-time-25]: Panitch and Gindin, *The Making of Global Capitalism*, 133–59. Joshua Clover’s account of the decline of socialist and labor movements during the long downturn buttresses the argument and periodization I offer here. Joshua Clover, *Riot. Strike. Riot: The New Era of Global Uprisings* (London: Verso, 2019), 129–54.

[^borrowed-time-26]: Mark *et al*.*, 1989*, 38–42.

[^borrowed-time-27]: Annie McClanahan, *Dead Pledges: Debt, Crisis, and Twenty-First-Century Culture* (Stanford: Stanford University Press, 2017), 13.

[^borrowed-time-28]: On the anticipatory structure of credit, see Cédric Durand, *Fictitious Capital: How Finance is Appropriating Our Future* (London: Verso, 2017), 48–55; Wolfgang Streeck, *Buying Time: The Delayed Crisis of Democratic Capitalism* (London: Verso, 2014), 32–46.

[^borrowed-time-29]: McClanahan, *Dead Pledges*, 133.

[^borrowed-time-30]: Ibid., 132.

[^borrowed-time-31]: Traverso, *Left-Wing Melancholia*, 17–18.

[^borrowed-time-32]: Harootunian, “Remembering the Historical Present,” 489–90.

[^borrowed-time-33]: Pedro Ramet, “Apocalypse Culture and Social Change in Yugoslavia,” in Pedro Ramet, ed., *Yugoslavia in the 1980s* (Boulder: Westfield Press, 1985), 3.

[^borrowed-time-34]: Vladimir Unkovski-Korica, *The Economic Struggle of Power in Tito’s Yugoslavia: From World War Two to Non-Alignment* (London: I.B. Tauris, 2016), 220–21.

[^borrowed-time-35]: Johanna Bockman, *Markets in the Name of Socialism: The Left-Wing Origins of Neoliberalism* (Stanford: Stanford University Press, 2011), 76–104; Marko Grdešić and Mislav Žitko, *Socialist Economics in Yugoslavia: A Critical History* (London: Routledge, 2026), 23–48.

[^borrowed-time-36]: Dennison Rusinow, *The Yugoslav Experiment, 1948–1974* (Berkeley: University of California Press, 1978), 326–32; Sabrina Ramet, *Nationalism and Federalism in Yugoslavia, 1962–1991* (Bloomington: Indiana University Press, 1992), 70–75; Goran Musić, *Making and Breaking the Yugoslav Working Class: The Story of Two Self-Managed Factories* (Budapest: Central European University Press, 2021), 55–59; Jović, *Yugoslavia*, 72–83, 142–47.

[^borrowed-time-37]: Dragan Ðunda, “The Production of Power: Environmental and Energy Politics in Yugoslavia and Serbia” (PhD diss, Central European University, 2025), 99–102.

[^borrowed-time-38]: According to Lydall’s calculations, in 1973 petroleum imports accounted for 7.6 percent of Yugoslavia’s total payments, but that number jumped to 14.1 percent in 1974, and 23.8 percent in 1982, indicating the immense pressures the global spike in oil prices placed on the Yugoslav economy. Harold Lydall, *Yugoslavia in Crisis* (Oxford: Clarendon Press, 1989), 175.

[^borrowed-time-39]: John Lampe, Russell Prickett, and Ljubiša Adamović, *Yugoslav-American Economic Relations since World War II* (Durham: Duke University Press, 1990), 152–54; Adam Bennett, “Macroeconomic Stability and Enterprise Self-Management in Yugoslavia: An Impossible Marriage,” in Othon Anastasakis, Adam Bennett, David Madden, and Adis Merdžanović, eds., *The Legacy of Yugoslavia: Politics, Economics, and Society in the Modern Balkans* (London: IB Tauris, 2020), 147–48, Dragović-Soso, *Saviors of the Nation*, 65–66, Jović, *Yugoslavia*, 156.

[^borrowed-time-40]: Bennett, “Macroeconomic Stability and Enterprise Self-Management in Yugoslavia,” 153; Musić, *Making and Breaking the Yugoslav Working Class*, 114.

[^borrowed-time-41]: These figures, calculated by the Serbian economist Miladin Korać, are cited in Grdešić and Žitko, *Socialist Economics in Yugoslavia*, 113–14.

[^borrowed-time-42]: Bennett, “Macroeconomic Stability and Enterprise Self-Management in Yugoslavia,” 154; Rory Archer and Goran Musić, “The Belgrade Working Class from Tito to Milošević: New Geographies of Poverty and Evolving Expressions of Grievances in an Era of Crisis, 1979–1986,” *Revue d’études comparatives Est-Ouest* 50, 1 (2019): 59; Woodward, *Socialist Unemployment*, 207–8, 346–470.

[^borrowed-time-43]: Musić, *Making and Breaking the Yugoslav Working Class*, 114.

[^borrowed-time-44]: Ibid., 117–18.

[^borrowed-time-45]: Taras Kermauner, *Pisma srbskemu prijatelju* (Celovec: Založba Drava, 1989), 76.

[^borrowed-time-46]: On Yugoslavia’s place in the history of the Non-Aligned Movement, see Paul Stubbs, ed., *Socialist Yugoslavia and the Non-Aligned Movement: Social, Political, and Economic Imaginaries* (Montreal: McGill-Queen’s University Press, 2023).

[^borrowed-time-47]: Kermauner, *Pisma srbskemu prijatelju*, 161.

[^borrowed-time-48]: Ibid. Kermauner’s argument resonates with the “cultural overtones” through which neoliberal reforms were often presented during this period. Mark *et al., 1989*, 227–28.

[^borrowed-time-49]: Kermauner, *Pisma srbskemu prijatelju*, 76.

[^borrowed-time-50]: Ibid., 152.

[^borrowed-time-51]: Dragović-Soso, *Saviors of the Nation*, 12.

[^borrowed-time-52]: Ibid., 64–114.

[^borrowed-time-53]: Byford, *Picturing Genocide in the Independent State of Croatia*, 101–23.

[^borrowed-time-54]: Leveraging this Europe-wide preoccupation with the violence of World War Two, Serbian nationalist historians often explicitly drew connections between the wartime suffering of Jews and that of Serbs. Marko Živković, *Serbian Dreambook: National Imaginary in the Time of Milošević* (Bloomington: Indiana University Press, 2011), 198–210.

[^borrowed-time-55]: Dragović-Soso, *Saviors of the Nation*, 106–7. For a more extensive treatment of Drašković’s novel, see Andrew Wachtel, *Making a Nation, Breaking a Nation: Literature and Cultural Politics in Yugoslavia* (Stanford: Stanford University Press, 1998), 205–9.

[^borrowed-time-56]: As Dan Edelstein, Stefanos Geroulanos, and Natasha Wheatley remind us, we do not inhabit a single temporal order but rather “a dense ecology of times,” which are experienced in divergent ways. Dan Edelstein, Stefanos Geroulanos, and Natasha Wheatley, “Chronocenosis: An Introduction to Power and Time,” in Dan Edelstein, Stefanos Geroulanos, and Natasha Wheatley, eds., *Power and Time: Temporalities in Conflict and the Making of History* (Chicago: Chicago University Press, 2020), 35. Such layered and conflicting temporalities are illustrated in Max Bergholz’s account of the revision of historical memories in a small village in Bosnia. See Max Bergholz, *Violence as a Generative Force: Identity, Nationalism, and Memory in a Balkan Community* (Ithaca: Cornell University Press, 2016), 297–322.

[^borrowed-time-57]: Efforts to account for the historical emergence of these films typically point to the general liberalization of the cultural field in Serbia and Slovenia. See, for instance, Daniel J. Goulding, *Liberated Cinema: The Yugoslav Experience, 1945–2001* (Bloomington: Indiana University Press, 2002), 166–67.

[^borrowed-time-58]: Ivo Banac, *With Stalin, Against Tito: Cominformist Splits in Yugoslav Communism* (Ithaca: Cornell University Press, 1988). A revival of interest in the *ibeovci* and their experience in the notorious prison camp Goli Otok was a central element of the new culture of historical memory in 1980s Yugoslavia. See, for instance, Ramet, “Apocalypse Culture and Social Change in Yugoslavia,” 11–13.

[^borrowed-time-59]: Ivan Velisavljević, “Against Capitalism from the Stalinist Cellar: The Balkan Spy in the Post-Yugoslav Context,” in Dijana Jelača, Maša Kolanović, and Danijela Lugarić, eds., *The Cultural Life of Capitalism in Yugoslavia: (Post)Socialism and its Other* (Cham: Palgrave Macmillan, 2017), 163–64.

[^borrowed-time-60]: Rory Archer, “‘Paid for by the Workers, Occupied by the Bureaucrats’: Housing Inequalities in 1980s Belgrade,” in Rory Archer, Igor Duda and Paul Stubbs, eds., *Social Inequalities and Discontent in Yugoslav Socialism* (Abingdon: Routledge, 2016), 58–76.

[^borrowed-time-61]: Musić, *Making and Breaking the Yugoslav Working Class*, 149–57; Archer, “‘Paid for by the Workers, Occupied by the Bureaucrats,’” 64.

[^borrowed-time-62]: McClanahan, *Dead Pledges*, 132.

[^borrowed-time-63]: Velisavljević, “Against Capitalism from the Stalinist Cellar,” 168.

[^borrowed-time-64]: Traverso, *Left-Wing Melancholia*, 8.

[^borrowed-time-65]: Ramet, “Apocalypse Culture and Social Change in Yugoslavia,” 14–15,

[^borrowed-time-66]: Aleš Erjavec, “Neue Slowenische Kunst – New Slovenian Art: Slovenia, Yugoslavia, Self-Management, and the 1980s” in Aleš Erjavec, ed., *Postmodernism and the Postsocialist Condition: Politicized Art under Late Socialism* (Berkeley: University of California Press, 2003), 135–74.

## 编者说明 / Editorial notes

regime of historicity统一译为历史性体制，指社会体验、意识到并反思历史时间的方式，见原注3；horizon of expectation译为期待视域；chronoscape译为时间景观；temporal ecology译为时间生态；presentism译为当下主义。

credit按语境译为信贷，debt译为债务。temporal fix译为时间性修复，兼有通过未来收益延缓当下限制之意。future past译为未来的过去，present past译为当下的过去，保留作者对两种时间结构的对照。borrowed time既指借债支撑的时间，也带有延期存续之意。

uncanny译为诡异或诡异感，保留原文关于熟悉的过去以陌生、侵入方式回归的含义。原文关于住房、创伤和精神崩溃的论述是电影文本分析；引文中的族群仇恨与粗俗措辞属于人物台词，按原文保留，不作为译者立场。

电影名称采用本版直译并保留原语检索名称：《美丽的村庄，美丽的火焰》（Lepa sela lepo gore）、《巴尔干间谍》（Balkanski špijun）、《似曾相识》（Već viđeno）。中文片名不表示唯一正式译名。原文将肖邦曲名写作复数Revolutionary Études，中文按语境译为《革命练习曲》。

原注33以Pedro Ramet署名，正文以Sabrina Ramet称呼作者，各按原文保留。原注42的Socialist Unemployment为简略书目，未自行补出版社或年份；注34书名中的Economic Struggle of Power按原文照录。原文引述的数额、增长率、偿债比例和历史分期不作无来源修订。

本文解释债务危机、时间体验和民族主义之间的关系，同时明确承认多种时间体验并存，见正文及注56；本版完整保留这一限定。self-management译为自治管理，socially owned housing译为社会所有制住房，避免与普通私人自主管理混淆。

原刊页码标示段落起始页，跨页段落不拆分。注释置于引用段落之后，网页可往返定位。书目原始检索信息与题名译释并列；译释不表示相应著作存在正式中译本。原刊无独立参考文献列表，全部书目均在66条原注中。
